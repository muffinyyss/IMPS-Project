from zoneinfo import ZoneInfo
from fastapi import HTTPException
from pymongo import MongoClient
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime, timedelta, timezone
from bson.objectid import ObjectId
from bson.decimal128 import Decimal128
from jose import jwt
from dotenv import load_dotenv
import json, os, re
import paho.mqtt.client as mqtt

load_dotenv()

BROKER_HOST = os.getenv("MQTT_BROKER", "192.168.100.14")
BROKER_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "imps/setting")

mqtt_client = mqtt.Client()
try:
    mqtt_client.connect(BROKER_HOST, BROKER_PORT, 60)
    mqtt_client.loop_start()
except Exception:
    pass

# ─── JWT / Auth ──────────────────────────────────────────────
# SECRET_KEY ต้องตั้งผ่าน environment variable เท่านั้น (อย่าง hardcode secret ลงโค้ด)
# ใช้ค่าที่คาดเดายาก >= 32 ตัวอักษร เช่นสร้างด้วย: python -c "import secrets; print(secrets.token_urlsafe(48))"
SECRET_KEY = os.getenv("JWT_SECRET_KEY")
if not SECRET_KEY or len(SECRET_KEY) < 32:
    raise RuntimeError(
        "JWT_SECRET_KEY environment variable must be set to a strong secret (>= 32 chars)"
    )
ALGORITHM = "HS256"
# role เดิมที่ถูกเปลี่ยนชื่อ → ชื่อใหม่ (normalize ตอน login/decode JWT)
# "engineer" ถูกเปลี่ยนเป็น "planner" — user เก่าใน DB และ token ที่ออกไปแล้วยังใช้ได้ต่อ
LEGACY_ROLE_ALIASES = {"engineer": "planner"}


def canonical_role(role: str | None) -> str:
    """แปลงชื่อ role เดิมเป็นชื่อปัจจุบัน (ไม่ใช่ alias ก็คืนค่าเดิม)"""
    r = (role or "").strip()
    return LEGACY_ROLE_ALIASES.get(r.lower(), r)


# บทบาทสายปฏิบัติงาน — ใช้อายุ session แบบ technician (token 24 ชม. ไม่มี idle timeout)
STAFF_ROLES = ("technician", "cs", "planner")
# บทบาทที่ไม่จำกัดด้วย station_id — technician ของ EDS ยังถูกกรองตามยี่ห้อ FlexxFast
# ส่วน station_id ของ technician คงไว้เป็นข้อมูลเดิม ไม่ใช้จำกัดสิทธิ์อีกต่อไป
ALL_STATIONS_ROLES = ("admin", "cs", "planner", "technician")
# super admin — role จริงใน DB ทำได้เหมือน admin + สิทธิ์พิเศษ (สลับ role, จัดการผู้ใช้, ลบถาวร)
SUPER_ADMIN_ROLE = "super_admin"
SUPER_ADMIN_USERNAME = "thatsawan"
# role ที่ super admin สลับ (impersonate) ไปได้ผ่าน dropdown
SWITCHABLE_ROLES = ("super_admin", "admin", "owner", "cs", "planner", "technician")
# อายุ access token จริงคำนวณที่ session_expiry.py (หมดอายุตี 3 เวลาไทย) — 2 ค่านี้ไม่ได้ใช้แล้ว
ACCESS_TOKEN_EXPIRE_MINUTES_TECHNICIAN = 1440
ACCESS_TOKEN_EXPIRE_MINUTES_DEFAULT = 1440
SESSION_IDLE_MINUTES_TECHNICIAN = None
# ไม่ใช้ idle timeout กับทุกบทบาท — ผู้ใช้เปิดหน้า monitoring ค้างไว้ทั้งวันได้
# (ตั้งเป็นจำนวนนาทีถ้าต้องการเปิดใช้; /refresh เช็คจาก lastActiveAt ซึ่งอัปเดตเฉพาะตอน login/refresh)
SESSION_IDLE_MINUTES_DEFAULT = None
REFRESH_TOKEN_EXPIRE_DAYS = 7
th_tz = ZoneInfo("Asia/Bangkok")
ACCESS_COOKIE_NAME = "access_token"

# ─── SMTP ────────────────────────────────────────────────────
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "eds194655@gmail.com")
SMTP_PASS = os.getenv("SMTP_PASS", "")
SENDER_EMAIL = os.getenv("SENDER_EMAIL", "eds194655@gmail.com")

# ─── Frontend (ใช้สร้างลิงก์ในอีเมล เช่น reset password) ─────
FRONTEND_BASE_URL = os.getenv("FRONTEND_BASE_URL", "http://localhost:3001")

# ─── MongoDB ─────────────────────────────────────────────────
_MONGO_URI = os.getenv("MONGO_URI")
if not _MONGO_URI:
    raise RuntimeError("MONGO_URI environment variable is not set")
client1 = MongoClient(_MONGO_URI)
client = AsyncIOMotorClient(_MONGO_URI)

deviceDB = client["utilizationFactor"]
settingDB = client["settingParameter"]
errorDB = client["FaultStatus"]

db = client1["iMPS"]
users_collection = db["users"]
station_collection = db["stations"]
charger_collection = db["charger"]
companies_collection = db["companies"]  # ตัว sync ของ companies_coll_async — ใช้ใน routers/users.py

station_collection.create_index("station_id", unique=True)
charger_collection.create_index("station_id")
charger_collection.create_index("chargeBoxID")

charger_onoff = client["edgeboxStatus"]
charger_onoff_sync = client1["edgeboxStatus"]
# handle sync de settingParameter — sert à créer les index depuis du code non-async
settingDB_sync = client1["settingParameter"]
MDB_DB = client["MDB"]
MDB_realtime_DB = client["MDB_realtime"]
MDB_history_DB = client["MDB_history"]
CBM_DB = client["monitorCBM"]

PMReportDB = client["PMReport"]
PMUrlDB = client["PMReportURL"]
MDBPMReportDB = client["MDBPMReport"]
MDBPMUrlDB = client["MDBPMReportURL"]
CCBPMReportDB = client["CCBPMReport"]
CCBPMUrlDB = client["CCBPMReportURL"]
CBBOXPMReportDB = client["CBBOXPMReport"]
CBBOXPMUrlDB = client["CBBOXPMReportURL"]
DCTestReportDB = client["DCTestReport"]
DCUrlDB = client["DCUrl"]
ACTestReportDB = client["ACTestReport"]
ACUrlDB = client["ACUrl"]
stationPMReportDB = client["stationPMReport"]
stationPMUrlDB = client["stationPMReportURL"]
# ใบ PM สถานี "ใบเดียว 4 ส่วน" — เอกสารแม่ที่ถือเลขที่/สถานะรวมของ Station+MDB+CCB+CB_BOX
stationPMJobDB = client["stationPMJob"]
CMReportDB = client["CMReport"]
CMUrlDB = client["CMReportURL"]
# handle แบบ sync ของ CMReport — ใช้สร้าง index จากโค้ดที่ไม่ใช่ async (cmreport.py)
CMReportDB_sync = client1["CMReport"]

outputModule1 = client["OutputModule1"]
outputModule2 = client["OutputModule2"]
outputModule3 = client["OutputModule3"]
outputModule4 = client["OutputModule4"]
outputModule5 = client["OutputModule5"]
outputModule6 = client["OutputModule6"]
outputModule7 = client["OutputModule7"]

inputModule1 = client["module1MdbDustPrediction"]
inputModule2 = client["module2ChargerDustPrediction"]
inputModule3 = client["module3ChargerOfflineAnalysis"]
inputModule4 = client["module4AbnormalPowerPrediction"]
inputModule5 = client["module5NetworkProblemPrediction"]
inputModule6 = client["module6DcChargerRulPrediction"]
inputModule7 = client["module7ChargerPowerIssue"]

MODULES = ["module1", "module2", "module3", "module4", "module5", "module6", "module7"]

OUTPUT_DBS = {
    "module1": outputModule1, "module2": outputModule2, "module3": outputModule3,
    "module4": outputModule4, "module5": outputModule5, "module6": outputModule6,
    "module7": outputModule7,
}
INPUT_DBS = {
    "module1": inputModule1, "module2": inputModule2, "module3": inputModule3,
    "module4": inputModule4, "module5": inputModule5, "module6": inputModule6,
    "module7": inputModule7,
}

imps_db_async = client["iMPS"]
stations_coll_async = imps_db_async["stations"]
users_coll_async = imps_db_async["users"]
email_log_coll = imps_db_async["errorEmailLog"]
charger_coll_async = imps_db_async["charger"]
companies_coll_async = imps_db_async["companies"]  # รายชื่อบริษัท (เมนู Company: owner/vendor)

MDB_collection = MDB_DB["Klongluang3"]

# ─── Shared Helpers ──────────────────────────────────────────
def _validate_station_id(station_id: str):
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", str(station_id)):
        raise HTTPException(status_code=400, detail="Bad station_id")

def _validate_station_id_th(station_id: str):
    # Allows Thai characters (U+0E00-U+0E7F) in addition to ASCII alphanumerics, _ and -
    if not re.fullmatch(r"[A-Za-z0-9_\-฀-๿]+", str(station_id)):
        raise HTTPException(status_code=400, detail="Bad station_id")

def get_mdb_collection_for(station_id: str):
    if not re.fullmatch(r"[A-Za-z0-9_\-฀-๿]+", str(station_id)):
        raise HTTPException(status_code=400, detail="Bad station_id")
    return MDB_DB.get_collection(str(station_id))

class _MongoEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        if isinstance(o, Decimal128):
            return float(o.to_decimal())
        if isinstance(o, datetime):
            return o.isoformat()
        return super().default(o)

def to_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), cls=_MongoEncoder)

def _ensure_utc_iso(v):
    if isinstance(v, datetime):
        return v.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    if isinstance(v, str) and re.match(r'^\d{4}-\d{2}-\d{2}T', v) and not re.search(r'(Z|[+\-]\d{2}:\d{2})$', v):
        return v + 'Z'
    return v

def create_access_token(data: dict, expires_delta: int | timedelta = 15):
    to_encode = dict(data)
    expire = (datetime.now(timezone.utc) + (timedelta(minutes=expires_delta) if isinstance(expires_delta, int) else expires_delta))
    to_encode["exp"] = int(expire.timestamp())
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def parse_iso_dt(s: str) -> datetime:
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        raise HTTPException(status_code=400, detail=f"Bad datetime: {s}")

def _to_utc_dt(iso_str: str) -> datetime:
    s = iso_str
    if s.endswith("Z"):
        s = s.replace("Z", "+00:00")
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt

def to_float(x, default=0.0):
    try:
        if x is None: return default
        if isinstance(x, (int, float)): return float(x)
        if isinstance(x, Decimal128): return float(x.to_decimal())
        s = str(x).strip().replace(",", ".")
        return float(s)
    except Exception:
        return default

def normalize_pm_date(s: str) -> str:
    """แปลง date string (ISO/UTC/วันเปล่า) → 'YYYY-MM-DD' ตามเวลาไทย"""
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
        return s
    if s.endswith("Z") or re.search(r"[+\-]\d{2}:\d{2}$", s):
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    else:
        dt = datetime.fromisoformat(s).replace(tzinfo=th_tz)
    return dt.astimezone(th_tz).date().isoformat()

def floor_bin(dt: datetime, step_sec: int) -> datetime:
    epoch_ms = int(dt.timestamp() * 1000)
    bin_ms = epoch_ms - (epoch_ms % (step_sec * 1000))
    return datetime.fromtimestamp(bin_ms / 1000, tz=timezone.utc)

def get_eds_health_collection(sn: str):
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", str(sn)):
        raise HTTPException(status_code=400, detail="Bad sn")
    eds_db = client["eds_system_health"]  # ✅ แก้ตรงนี้
    return eds_db.get_collection(str(sn))
