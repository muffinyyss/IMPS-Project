"""
services/pm_maximo_out.py
=========================
ขาออกของฝั่ง PM: iMPS → Maximo  (คู่กับ routers/pm_maximo.py ที่เป็นขาเข้า)

ต่างจาก CM ตรงที่ PM **ไม่เปิด WO เอง** (ไม่มี IN01) และ **ไม่มี IN05 failure report**
— Maximo เป็นคนเปิดใบงาน WSCHD ส่งเข้ามาทาง IN06 แล้ว iMPS ยิงกลับตาม sequencing
ที่ตกลงกับ EGAT (Maximo x iMPS — PM):

  1. IN06  (ขาเข้า)                     Maximo สร้าง WO (WSCHD) → iMPS สร้างใบงาน OPEN
  2. IN02  update_wo_status(INPRG)      planner assign → ใบงานเข้าสถานะ In Progress
  3. IN03  attach_wo_link(url)          ช่างกรอกเสร็จ แนบลิงก์เอกสาร
  4. IN09  create_labtrans()            เวลาทำงานจริงของช่าง
  5. IN02  update_wo_status(CLOSED)     ปิดสถานะ ต้องเป็นเส้นสุดท้ายเสมอ

ขั้น 3–5 ยิงทีละเส้นเรียงกัน (ห้ามส่งพร้อมกัน) และ IN02 CLOSED ต้องอยู่ท้ายสุด
เพราะพอ WO ปิดแล้ว Maximo ไม่ให้แนบเอกสาร/ลงเวลาเพิ่มอีก

wonum มาจากฟิลด์ `wonum` บนเอกสาร PM ซึ่งผูกไว้ตอนช่างเปิดฟอร์มจากใบงานที่
planner assign — ใบที่ไม่มี wonum (สร้างเองไม่ได้มาจาก Maximo) จะข้ามไปเงียบ ๆ
"""

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote

from config import client
from services import maximo
from services.cm_maximo import CONTRACTOR_LABOR_CODE, resolve_labor_code
from services.maximo import MaximoError

log = logging.getLogger("pm_maximo_out")

# เปิด/ปิดแยกจากฝั่ง CM — เปิดใช้งานทีละระบบได้ตอนขึ้น production
PM_MAXIMO_ENABLED = os.getenv("PM_MAXIMO_ENABLED", "true").lower() == "true"

# ลิงก์ที่แนบเข้า Maximo ต้องเปิดจากภายนอกได้ — ไฟล์ใน iMPS เก็บเป็น path
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", os.getenv("FRONTEND_BASE_URL", "")).rstrip("/")

# ภาษาของ PDF ที่แนบเข้า Maximo (ใช้ค่าเดียวกับฝั่ง CM)
# ⚠️ ค่านี้ตกไปกับลิงก์ในรูป ?…&lang= ซึ่ง maximo_safe_url() ตัดทิ้งตอนยิงเข้า Maximo
#    ฝั่ง Maximo จึงได้ภาษาตาม default ของ route /pdf ("th") เสมอ ตั้งเป็น en เมื่อไหร่
#    ไฟล์ที่ pm_pdf ปั๊มไว้ล่วงหน้าจะคนละภาษากับที่ลิงก์เปิด (ยังเปิดได้ แต่ต้องรอเรนเดอร์สด)
PDF_LANG = os.getenv("MAXIMO_PDF_LANG", "th").strip() or "th"

# ชนิดใบงาน PM → template ของ route /pdf/{template}/{id}
PDF_TEMPLATE_OF = {
    "charger": "charger",
    "mdb": "mdb",
    "ccb": "ccb",
    "cbbox": "cbbox",
    "station": "station",
}

# สถานะที่ยิงตอนปิดงาน — ใช้ CLOSED เหมือน CM (EGAT ให้ปิดถึง CLOSED เลย ไม่หยุดที่ COMP)
# ⚠️ CLOSED ใน Maximo ปิดตาย แก้ไข/เติมข้อมูลย้อนหลังไม่ได้อีก IN03/IN09 จึงต้องผ่านครบก่อน
PM_CLOSE_STATUS = os.getenv("MAXIMO_PM_CLOSE_STATUS", "CLOSED").strip().upper()

# สถานะตอน planner assign งานให้ช่าง (ขั้น 2 ของ sequencing)
PM_INPROGRESS_STATUS = os.getenv("MAXIMO_PM_INPRG_STATUS", "INPRG").strip().upper()

# หน่วงระหว่าง interface ตอนปิดงาน — ใช้ค่าเดียวกับฝั่ง CM
# (EGAT ระบุว่าส่งพร้อมกันไม่ได้ ต้องรอ Maximo commit เส้นก่อนหน้าก่อน)
MAXIMO_STEP_DELAY = float(os.getenv("MAXIMO_STEP_DELAY", "2"))


async def _settle() -> None:
    """รอ Maximo commit เส้นที่เพิ่งยิงไป ก่อนยิงเส้นถัดไป"""
    if MAXIMO_STEP_DELAY > 0:
        await asyncio.sleep(MAXIMO_STEP_DELAY)


def _open_coll():
    """iMPS.maximo_pm_open — ใบงาน PM ที่ Maximo เปิดเข้ามา (มี assignees ของแผน)"""
    return client["iMPS"]["maximo_pm_open"]


async def _record(coll, report_id, interface: str, ok: bool, **detail) -> None:
    """จดผลลง maximo_sync.<interface> ของเอกสาร — ล้มตรงนี้ต้องไม่กระทบใบงาน"""
    entry = {
        "ok": ok,
        "at": datetime.now(timezone.utc),
        **{k: v for k, v in detail.items() if v is not None},
    }
    try:
        await coll.update_one({"_id": report_id}, {"$set": {f"maximo_sync.{interface}": entry}})
    except Exception as e:
        log.warning(f"  ⚠️ record maximo_sync.{interface} failed: {e}")


def _err_detail(e: Exception) -> str:
    """ข้อความ error + body ดิบจาก Maximo — body คือที่มีรหัส BMXAA บอกสาเหตุจริง"""
    msg = str(e)
    body = getattr(e, "body", "") or ""
    return f"{msg} | {body[:400]}" if body else msg


def _trace(trace: dict) -> dict:
    """ยัด request/response ที่คุยกับ Maximo ลง maximo_sync"""
    if not trace:
        return {}
    return {"maximo_request": trace.get("request"),
            "maximo_response": trace.get("response"),
            "http": trace.get("http")}


def _no_ok(detail: dict) -> dict:
    """
    ตัด key `ok` ออกก่อนกระจายเข้า _record()

    _fail()/_skip() คืน dict ที่มี `ok` อยู่แล้ว พอเอาไป `**result` ต่อท้าย
    _record(..., ok, **result) จะชน "got multiple values for argument 'ok'"
    (พังตั้งแต่ตอนเรียก ดักใน _record ไม่ทัน)
    """
    return {k: v for k, v in detail.items() if k != "ok"}


def _skip(reason: str) -> dict:
    return {"ok": False, "skipped": True, "reason": reason}


# ใบงานที่เปิดเองใน iMPS (หน้า PM List → "เพิ่มใบงาน") — ไม่มีเลขนี้อยู่ใน Maximo
# ยิงอะไรไปก็โดนตีกลับ (BMXAA1496E) จึงไม่ส่ง API ไปหา Maximo เลยทุกเส้น
# ต้องตรงกับ MANUAL_WO_ORIGIN ใน routers/pm_maximo.py (import ตรงไม่ได้ — วนกัน)
MANUAL_WO_ORIGIN = "imps-manual"
MANUAL_SKIP_REASON = "ใบงานเปิดเองใน iMPS — ไม่ส่งเข้า Maximo"


async def is_manual_wonum(wonum: str) -> bool:
    """ใบงานเลขนี้เปิดเองใน iMPS หรือไม่ (ดู origin ใน maximo_pm_open)"""
    wonum = (wonum or "").strip()
    if not wonum:
        return False
    wo = await _open_coll().find_one({"wonum": wonum}, {"origin": 1}) or {}
    return str(wo.get("origin") or "").strip().lower() == MANUAL_WO_ORIGIN


def _fail(e: Exception) -> dict:
    detail: dict[str, Any] = {"ok": False, "error": str(e)}
    if isinstance(e, MaximoError) and e.body:
        detail["body"] = e.body
    return detail


def public_url(path: str) -> str:
    """path ของไฟล์/หน้าใน iMPS → URL เต็มที่ Maximo เปิดได้"""
    p = (path or "").strip()
    if not p or p.startswith(("http://", "https://")):
        return p
    if not PUBLIC_BASE_URL:
        return ""
    return f"{PUBLIC_BASE_URL}/{p.lstrip('/')}"


def report_url(report: dict, report_id: Any, kind: str = "charger", coll_key: str = "") -> str:
    """
    ลิงก์ PDF เอกสาร PM — ใช้แนบเข้า Maximo (IN03)

    แนบตัวเอกสาร PDF ไม่ใช่หน้าเว็บ คนที่เปิดจาก Maximo จะได้ไฟล์เลย
    ยิงตอนปิดงานเท่านั้น ตอนนั้น PDF ถึงจะมีเนื้อหาครบ

    coll_key = ชื่อคอลเลกชันที่ใบงานอยู่จริง (charger/ac/dc = SN, ที่เหลือ = station_id)
    route /pdf หาเอกสารจากชื่อคอลเลกชัน ไม่ใช่ฟิลด์ในเอกสาร — เดาจากฟิลด์เมื่อไหร่
    ใบที่ไม่มี sn/station_id เก็บไว้ในตัวเอกสารจะได้ลิงก์ที่เปิดแล้ว 400/404
    ทั้งที่ใบงานมีอยู่จริง

    ลิงก์ตรงนี้เต็มเหมือนเดิม (มี lang/dl) — Maximo กิน & ไม่ได้ แต่ไปตัดตอนยิงออก
    ที่ maximo.maximo_safe_url() แทน จะได้ไม่กระทบลิงก์ที่ฝั่ง iMPS ใช้เอง
    """
    if not PUBLIC_BASE_URL:
        return ""
    # template ต้องตรงกับชนิดใบงาน ไม่งั้น route /pdf ไปเปิดคนละคอลเลกชันแล้ว 404
    template = PDF_TEMPLATE_OF.get(kind, "charger")
    key = (coll_key or "").strip()
    if template in ("charger", "ac", "dc"):
        param, key = "sn", key or (report.get("sn") or "").strip()
    else:
        param, key = "station_id", key or (report.get("station_id") or "").strip()
    if not key:
        return ""
    qs = f"{param}={quote(key, safe='')}&lang={PDF_LANG}&dl=true"
    issue_id = str(report.get("issue_id") or "").strip()
    # ลิงก์ตรงไปที่ไฟล์ (.pdf) — /export เป็นแค่ตัว 307 redirect มาที่นี่อีกที
    if issue_id:
        return f"{PUBLIC_BASE_URL}/pdf/{template}/{report_id}/{quote(issue_id, safe='')}.pdf?{qs}"
    return f"{PUBLIC_BASE_URL}/pdf/{template}/{report_id}/export?{qs}"


async def push_labor_entries(coll, report_id, report: dict) -> dict:
    """
    IN09 ของใบ PM สถานี — ลงเวลาแยกตามแต่ละฝ่ายที่ส่งงาน (work_entries ของใบ)

    ใบเดียวมีหลายฝ่ายทำงานคนละช่วงเวลาได้ (เช่น EGAT ทำ Station/MDB, EDS ทำตู้ชาร์จ)
    แต่ละฝ่ายกรอกเวลา + laborcode ของตัวเองตอนกด "ส่งงาน" → ยิง labtrans แยกต่อฝ่าย
    (Maximo รับ IN09 หลายครั้งต่อ WO ได้)

    ยิงซ้ำได้ปลอดภัย: laborcode ที่ลงไปแล้วของแต่ละฝ่ายจดไว้ที่ work_entries.N.maximo.sent_codes
    รอบถัดไปข้ามตัวที่ลงแล้ว — labtrans เป็น POST create ยิงซ้ำ = ชั่วโมงถูกนับซ้ำ
    """
    wonum = (report.get("wonum") or "").strip()
    if not wonum:
        return _skip("เอกสารนี้ไม่ได้ผูกกับใบงาน Maximo")

    wo = await _open_coll().find_one({"wonum": wonum}, {"location": 1}) or {}
    location = wo.get("location") or None
    issue = str(report.get("issue_id") or "").strip()

    results: list[dict] = []
    trace: dict = {}
    all_ok, any_sent, any_entry = True, 0, False
    for idx, entry in enumerate(report.get("work_entries") or []):
        if not isinstance(entry, dict) or not entry.get("submitted"):
            continue
        party = str(entry.get("party") or "").strip()
        codes = [str(c).strip() for c in (entry.get("maximo_labor") or []) if str(c or "").strip()]
        start = str(entry.get("work_start") or "").strip()
        finish = str(entry.get("work_finish") or "").strip()
        if not codes or not start:
            # ฝ่ายนี้ไม่ได้เลือก laborcode (เช่นโหลดรายชื่อไม่ได้ตอนส่ง) — ไม่มีอะไรให้ลง ไม่บล็อกการปิด WO
            results.append({"party": party, "skipped": True, "reason": "ไม่มี laborcode / เวลาเริ่มงาน"})
            continue
        any_entry = True
        prev = entry.get("maximo") or {}
        done = {str(c).upper() for c in (prev.get("sent_codes") or [])}
        contractor = str(entry.get("maximo_contractor") or "").strip()
        sent_codes = list(prev.get("sent_codes") or [])
        errors: list[str] = []
        for labor in codes:
            if labor.upper() in done:
                continue
            memo = f"iMPS PM {issue}" + (f" — {party}" if party else "")
            if labor.upper() == CONTRACTOR_LABOR_CODE and contractor:
                memo = f"{memo} — {contractor}"
            try:
                await maximo.create_labtrans(
                    wonum, labor, start=start, finish=finish or None,
                    location=location, memo=memo, trace=trace,
                )
                sent_codes.append(labor)
                any_sent += 1
            except MaximoError as e:
                log.warning(f"  ⚠️ IN09 labtrans failed (WO {wonum} / {party} / {labor}): {_err_detail(e)}")
                errors.append(f"{labor}: {_err_detail(e)}")
        ok = not errors
        all_ok = all_ok and ok
        state = {"ok": ok, "sent_codes": sent_codes, "errors": errors or None,
                 "at": datetime.now(timezone.utc)}
        try:
            await coll.update_one({"_id": report_id}, {"$set": {f"work_entries.{idx}.maximo": state}})
        except Exception as e:
            log.warning(f"  ⚠️ record work_entries.{idx}.maximo failed: {e}")
        results.append({"party": party, "ok": ok, "sent": len(sent_codes), "total": len(codes),
                        **({"errors": errors} if errors else {})})

    if not any_entry:
        result = _skip("ยังไม่มีฝ่ายไหนเลือก laborcode ไว้")
        await _record(coll, report_id, "IN09", False, wonum=wonum, **_no_ok(result))
        return result
    errors_all = [f"{r['party']}: {err}" for r in results for err in r.get("errors") or []]
    await _record(coll, report_id, "IN09", all_ok, wonum=wonum, source="work_entries",
                  entries=results, errors=errors_all or None, **_trace(trace))
    return {"ok": all_ok, "wonum": wonum, "sent": any_sent, "entries": results}


def job_pdf_url(job: dict, station_id: str) -> str:
    """
    ลิงก์ PDF ของใบ PM สถานี (รวมทุกส่วน + ตู้ทุกตู้เป็นไฟล์เดียว) — ใช้แนบเข้า Maximo (IN03)
    เปิดได้โดยไม่ต้องล็อกอินผ่าน /pdf/stationpmjob/... (pdf_routes1) เฉพาะใบที่อนุมัติแล้ว
    """
    if not PUBLIC_BASE_URL or not station_id:
        return ""
    qs = f"station_id={quote(station_id, safe='')}&lang={PDF_LANG}&dl=true"
    issue_id = str(job.get("issue_id") or "").strip() or str(job.get("_id"))
    return f"{PUBLIC_BASE_URL}/pdf/stationpmjob/{job.get('_id')}/{quote(issue_id.replace('/', '-'), safe='')}.pdf?{qs}"


async def push_status(
    coll, report_id, report: dict, *, status: str = "", memo: str = ""
) -> dict:
    """IN02 — ส่งสถานะ WO ไป Maximo (ไม่ระบุ status = สถานะปิดงาน)"""
    wonum = (report.get("wonum") or "").strip()
    if not wonum:
        return _skip("เอกสารนี้ไม่ได้ผูกกับใบงาน Maximo")

    target = (status or PM_CLOSE_STATUS).strip().upper()

    # ยิงซ้ำสถานะเดิมไม่มีประโยชน์ และ Maximo error ว่าเปลี่ยนเป็นค่าเดิมไม่ได้
    # ต้องดู ok ด้วย — _record จด status ไว้แม้ยิงไม่ผ่าน ถ้าเทียบแค่ status
    # การส่งใหม่ (ปุ่ม / auto-retry) จะตอบ "ผ่าน" ทั้งที่ Maximo ยังไม่เคยรับ
    prev = (report.get("maximo_sync") or {}).get("IN02", {})
    if prev.get("status") == target and prev.get("ok"):
        return {"ok": True, "status": target, "unchanged": True}

    trace: dict = {}
    try:
        await maximo.update_wo_status(wonum, target, memo=memo, trace=trace)
    except MaximoError as e:
        log.warning(f"  ⚠️ IN02 status push failed (WO {wonum} → {target}): {e}")
        result = _fail(e)
        await _record(coll, report_id, "IN02", False, wonum=wonum, status=target,
                      **_no_ok(result), **_trace(trace))
        return result

    await _record(coll, report_id, "IN02", True, wonum=wonum, status=target, **_trace(trace))
    return {"ok": True, "wonum": wonum, "status": target}


async def push_attachment(
    coll, report_id, report: dict, url: str, *, name: str = "", description: str = ""
) -> dict:
    """IN03 — แนบลิงก์เอกสาร PM เข้ากับ WO"""
    wonum = (report.get("wonum") or "").strip()
    if not wonum:
        return _skip("เอกสารนี้ไม่ได้ผูกกับใบงาน Maximo")

    # จด/ส่งด้วยค่าเดียวกับที่ Maximo ได้รับจริง (ตัด query ที่เกิน param แรกทิ้ง)
    link = maximo.maximo_safe_url(public_url(url))
    if not link:
        return _skip("ตั้งค่า PUBLIC_BASE_URL ก่อน ถึงจะสร้างลิงก์ที่ Maximo เปิดได้")

    trace: dict = {}
    try:
        await maximo.attach_wo_link(
            wonum, link,
            name=name or f"{report.get('issue_id') or 'PM'}.pdf",
            description=description or f"iMPS PM {report.get('doc_name') or ''}".strip(),
            trace=trace,
        )
    except MaximoError as e:
        log.warning(f"  ⚠️ IN03 attach failed (WO {wonum}): {e}")
        result = _fail(e)
        await _record(coll, report_id, "IN03", False, wonum=wonum, url=link,
                      **_no_ok(result), **_trace(trace))
        return result

    await _record(coll, report_id, "IN03", True, wonum=wonum, url=link, **_trace(trace))
    return {"ok": True, "wonum": wonum, "url": link}


async def push_labor_time(coll, report_id, report: dict) -> dict:
    """
    IN09 — ลงเวลาช่างที่ planner assign ไว้ในใบงาน

    PM ไม่ได้เก็บเวลาเข้า-ออกงานรายคนแบบ CM จึงใช้ช่วงเวลาของเอกสารแทน:
      start/finish = work_start / work_finish ที่ช่างกรอกในฟอร์ม Post-PM
      (เอกสารเก่าที่ไม่มีช่องนี้ ถอยไปใช้ timestamp / submittedAt ของเอกสาร)
    ช่างมาจาก assignees ของแผนใน maximo_pm_open — ไม่มีก็ถอยไปใช้ inspector
    """
    wonum = (report.get("wonum") or "").strip()
    if not wonum:
        return _skip("เอกสารนี้ไม่ได้ผูกกับใบงาน Maximo")

    def _iso(v: Any) -> str:
        if isinstance(v, datetime):
            return v.astimezone(timezone.utc).isoformat()
        return str(v or "").strip()

    # ช่างกรอกเวลาทำงานจริงไว้ในฟอร์ม Post-PM — ใช้ตัวนี้ก่อนเสมอ
    # ที่เหลือเป็น fallback ของเอกสารเก่าที่บันทึกก่อนมีช่องกรอกเวลา
    start = str(report.get("work_start") or "").strip()         or _iso(report.get("timestamp")) or str(report.get("pm_date") or "").strip()
    finish = str(report.get("work_finish") or "").strip()         or _iso(report.get("submittedAt")) or _iso(report.get("timestamp_post"))
    if not start:
        return _skip("ยังไม่มีวันเวลาเริ่มงาน")

    wo = await _open_coll().find_one(
        {"wonum": wonum}, {"assignees": 1, "vendor_plans": 1, "location": 1}
    ) or {}
    location = wo.get("location") or None

    # ช่างเลือก laborcode เองในฟอร์ม = ใช้ตรง ๆ ไม่ต้อง map จาก username
    picked = [str(c).strip() for c in (report.get("maximo_labor") or []) if str(c or "").strip()]
    if picked:
        contractor = str(report.get("maximo_contractor") or "").strip()
        sent, errors = 0, []
        trace: dict = {}
        for labor in picked:
            memo = f"iMPS PM {report.get('issue_id') or ''}"
            # รหัสกลางของผู้รับเหมา — ต่อชื่อจริงเข้าไปใน memo
            if labor.upper() == CONTRACTOR_LABOR_CODE and contractor:
                memo = f"{memo} — {contractor}"
            try:
                await maximo.create_labtrans(
                    wonum, labor, start=start, finish=finish or None,
                    location=location, memo=memo, trace=trace,
                )
                sent += 1
            except MaximoError as e:
                log.warning(f"  ⚠️ IN09 labtrans failed (WO {wonum} / {labor}): {_err_detail(e)}")
                errors.append(f"{labor}: {_err_detail(e)}")
        ok = sent > 0 and not errors
        await _record(coll, report_id, "IN09", ok, wonum=wonum, sent=sent,
                      total=len(picked), errors=errors or None, source="form", **_trace(trace))
        if ok:
            return {"ok": True, "wonum": wonum, "sent": sent}
        return {"ok": False, "wonum": wonum, "sent": sent, "total": len(picked), "errors": errors}

    # ช่างของ planner ต้นทาง + ช่างที่ vendor (เช่น EDS) ส่งเข้าหน้างานในแผนรอบ 2
    names = list(wo.get("assignees") or [])
    for vp in wo.get("vendor_plans") or []:
        names.extend(vp.get("assignees") or [])
    assignees = list(dict.fromkeys(str(a).strip() for a in names if str(a or "").strip()))
    if not assignees:
        inspector = str(report.get("inspector") or "").strip()
        assignees = [inspector] if inspector else []
    if not assignees:
        return _skip("ใบงานยังไม่มีช่างที่รับผิดชอบ")

    sent, errors, unmapped = 0, [], []
    trace: dict = {}
    for username in assignees:
        labor = resolve_labor_code(username)
        if not labor:
            # ยังไม่ได้ผูก users.maximo_laborcode — ยิงไปก็โดน BMXAA2627E เปล่า ๆ
            unmapped.append(username)
            continue
        try:
            await maximo.create_labtrans(
                wonum, labor,
                start=start, finish=finish or None,
                location=location,
                memo=f"iMPS PM {report.get('issue_id') or ''}",
                trace=trace,
            )
            sent += 1
        except MaximoError as e:
            log.warning(f"  ⚠️ IN09 labtrans failed (WO {wonum} / {labor}): {_err_detail(e)}")
            errors.append(f"{username}: {_err_detail(e)}")

    ok = sent > 0 and not errors and not unmapped
    await _record(coll, report_id, "IN09", ok, wonum=wonum, sent=sent,
                  total=len(assignees), errors=errors or None, unmapped=unmapped or None,
                  **_trace(trace))
    if ok:
        return {"ok": True, "wonum": wonum, "sent": sent}
    return {"ok": False, "wonum": wonum, "sent": sent, "total": len(assignees),
            "errors": errors, "unmapped": unmapped}


async def sync_in_progress(wonum: str, *, memo: str = "") -> dict:
    """
    ขั้น 2 — planner assign เสร็จ ใบงานเข้าสถานะ In Progress

    ตอนนี้ยังไม่มีเอกสาร PM (ช่างยังไม่เริ่มกรอก) จึงจดผลไว้ที่ตัวใบงาน
    ใน maximo_pm_open แทน
    """
    if not PM_MAXIMO_ENABLED:
        return {"skipped": "PM_MAXIMO_ENABLED=false"}

    wonum = (wonum or "").strip()
    if not wonum:
        return _skip("wonum ว่าง")

    coll = _open_coll()
    wo = await coll.find_one({"wonum": wonum}) or {}
    if not wo:
        return _skip(f"ไม่พบใบงาน wonum={wonum}")
    if str(wo.get("origin") or "").strip().lower() == MANUAL_WO_ORIGIN:
        return _skip(MANUAL_SKIP_REASON)

    return await push_status(
        coll, wo["_id"], {**wo, "wonum": wonum},
        status=PM_INPROGRESS_STATUS, memo=memo,
    )


async def safe_sync_in_progress(wonum: str, *, memo: str = "") -> dict:
    """sync_in_progress แบบกลืน exception — Maximo ล่มต้องไม่ทำให้ assign ล้ม"""
    try:
        return await sync_in_progress(wonum, memo=memo)
    except Exception as e:
        log.warning(f"  ⚠️ PM Maximo INPRG error ({wonum}): {e}")
        return {"error": str(e)}


def _blocking_failures(results: dict) -> list[str]:
    """
    เส้นที่ "ยิงแล้วไม่ผ่าน" ก่อนถึงขั้นปิดสถานะ

    แยกจาก skipped: skipped = ไม่มีอะไรให้ส่ง (เช่นยังไม่ตั้ง PUBLIC_BASE_URL,
    ใบงานไม่มีช่าง) ปล่อยผ่านได้ ส่วน failed = Maximo ปฏิเสธ ต้องแก้แล้วยิงซ้ำ
    ก่อน ไม่งั้นพอ WO ปิดแล้วจะเติมย้อนหลังไม่ได้อีกเลย
    """
    return [
        name for name, r in results.items()
        if isinstance(r, dict) and not r.get("ok") and not r.get("skipped")
    ]


async def sync_closed(
    coll, report_id, report: dict, *, memo: str = "", kind: str = "charger", link: str = "",
    per_party_labor: bool = False,
) -> dict:
    """
    ขั้น 3–5 ของ sequencing — ยิงทีละเส้นเรียงกัน เรียกซ้ำได้ปลอดภัย
    (IN02 กันยิงซ้ำสถานะเดิม, IN03 แนบครั้งเดียวพอ)
    """
    if not PM_MAXIMO_ENABLED:
        return {"skipped": "PM_MAXIMO_ENABLED=false"}

    # ใบงานเปิดเอง = ไม่มีใน Maximo → ปิดงานฝั่ง iMPS อย่างเดียว ไม่ยิง IN03/IN09/IN02
    if await is_manual_wonum(report.get("wonum") or ""):
        log.info(f"  ⏭️  ข้าม Maximo — {report.get('wonum')} เป็นใบงานที่เปิดเองใน iMPS")
        return {"skipped": MANUAL_SKIP_REASON}

    out: dict[str, Any] = {}

    # ── 3. IN03 แนบลิงก์เอกสาร (ครั้งเดียวพอ) ──
    if not (report.get("maximo_sync") or {}).get("IN03", {}).get("ok"):
        # link ส่งมาเอง = ใบ PM สถานี (PDF รวมทุกส่วน) — ไม่ส่ง = เอกสารใบเดี่ยวตามชนิด
        link = link or report_url(report, report_id, kind, coll_key=getattr(coll, "name", "") or "")
        out["IN03"] = await push_attachment(coll, report_id, report, link)

    # ── 4. IN09 เวลาทำงานจริงของช่าง ──
    # ใบ PM สถานีที่แต่ละฝ่ายส่งเวลาของตัวเอง — ลงแยกต่อฝ่าย (กันซ้ำรายฝ่ายอยู่ในตัว)
    if per_party_labor:
        await _settle()
        out["IN09"] = await push_labor_entries(coll, report_id, report)
    # ยิงครั้งเดียวพอ — labtrans เป็น POST create ยิงซ้ำ = ชั่วโมงถูกนับซ้ำ
    elif (report.get("maximo_sync") or {}).get("IN09", {}).get("ok"):
        out["IN09"] = {"ok": True, "skipped": True, "reason": "ลงเวลาไปแล้ว ไม่ยิงซ้ำ"}
    else:
        await _settle()
        out["IN09"] = await push_labor_time(coll, report_id, report)

    # ── 5. IN02 ปิดสถานะเป็นเส้นสุดท้าย ──
    # ต้องยิง 3–4 ให้ครบก่อน มีเส้นไหนไม่ผ่านห้ามปิด WO
    # (ปิดแล้ว Maximo ไม่ให้แนบเอกสาร/ลงเวลาเพิ่มอีก)
    failed = _blocking_failures(out)
    if failed:
        log.warning(
            f"  ⏸️  ไม่ปิด WO {report.get('wonum')} — {', '.join(failed)} ยังไม่ผ่าน"
        )
        out["IN02"] = _skip(f"รอ {', '.join(failed)} ผ่านก่อนถึงจะปิด WO ได้")
        return out

    await _settle()
    out["IN02"] = await push_status(coll, report_id, report, memo=memo)

    return out


async def safe_sync_closed(
    coll, report_id, report: dict, *, memo: str = "", kind: str = "charger", link: str = "",
    per_party_labor: bool = False,
) -> dict:
    """sync_closed แบบกลืนทุก exception — Maximo ล่มต้องไม่ทำให้ปิดใบงานล้ม"""
    try:
        return await sync_closed(coll, report_id, report, memo=memo, kind=kind, link=link,
                                 per_party_labor=per_party_labor)
    except Exception as e:
        log.warning(f"  ⚠️ PM Maximo sync error ({report.get('issue_id')}): {e}")
        return {"error": str(e)}
