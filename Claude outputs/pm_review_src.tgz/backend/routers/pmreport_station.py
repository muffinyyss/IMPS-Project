"""PM Report routes for Station-level"""
from fastapi import APIRouter, HTTPException, Depends, Query, Request, UploadFile, File, Form, Path
from fastapi.responses import Response, JSONResponse, StreamingResponse
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from datetime import datetime, timedelta, timezone, date
from dateutil.relativedelta import relativedelta
from bson.objectid import ObjectId
from bson.errors import InvalidId
from bson.decimal128 import Decimal128
from zoneinfo import ZoneInfo
from typing import List, Dict, Any, Optional, Literal
import re, json, uuid, pathlib, secrets, os, asyncio
import zipfile

from config import (
    normalize_pm_date, stationPMReportDB, stationPMUrlDB,
    station_collection, _validate_station_id_th, th_tz, _ensure_utc_iso,
)
from deps import UserClaims, get_current_user
from routers import pm_scope
from routers import pm_flow
from services import pm_maximo_out, pm_pdf
from uploads_access import assert_station_access, assert_sn_access
from routers.pm_helpers import (
    UPLOADS_ROOT,
    ALLOWED_EXTS,
    MAX_FILE_MB,
    _safe_name,
    _ext,
    parse_iso_any_tz,
    get_stationpmreport_collection_for,
    get_stationpmurl_coll_upload,
    _latest_issue_id_anywhere,
    _next_issue_id,
    _next_issue_id_no_conflict,
    _latest_doc_name_from_pmreport,
    _latest_doc_name_anywhere,
    _next_year_seq,
    _resolve_issue_and_doc,
)

from PIL import Image
from image_convert import normalize_image_bytes, ImageConversionError
from io import BytesIO


# เดิมแต่ละ router มี resize_image_bytes ของตัวเอง (ซ้ำกัน 5 ที่) ซึ่ง `except: return data`
# กลืนเคส "เปิด HEIC ไม่ได้" ไปเงียบ ๆ ตอนนี้ย้ายไปรวมที่ image_convert.normalize_image_bytes
# ที่แปลงเป็น JPEG เสมอ และ raise เมื่อแปลงไม่ได้จริง ๆ
def resize_image_bytes(data: bytes, max_width: int = 1920, quality: int = 85) -> bytes:
    """คงชื่อเดิมไว้เผื่อมีโค้ดอื่นเรียก — ผลลัพธ์เป็น JPEG ที่เบราว์เซอร์เปิดได้เสมอ"""
    return normalize_image_bytes(data, max_width=max_width, quality=quality)[0]


router = APIRouter()

# ── ผูกกับใบ PM สถานี "ใบเดียว 4 ส่วน" ────────────────────────────
async def _job_link(station_id: str, job_id: str | None) -> dict:
    """ข้อมูลเลขที่เอกสารของใบแม่ — ไม่ได้ส่ง job_id มา = ใบเดี่ยวแบบเดิม คืน {}"""
    if not (job_id or "").strip():
        return {}
    from routers.pmreport_station_job import job_numbering
    return await job_numbering(station_id, job_id)



# ============================================
# Helpers
# ============================================

async def _get_station_by_id(station_id: str) -> dict:
    """Get station document by station_id, raise 404 if not found"""
    station = station_collection.find_one({"station_id": station_id})
    if not station:
        raise HTTPException(status_code=404, detail=f"Station with ID '{station_id}' not found")
    return station


def _compute_next_pm_date_str(pm_date_str: str | None) -> str | None:
    if not pm_date_str:
        return None
    try:
        d = datetime.fromisoformat(pm_date_str).date()
    except ValueError:
        return None
    next_d = d + relativedelta(months=+6)
    return next_d.isoformat()


async def _latest_pm_date_from_stationpmreport(station_id: str) -> dict | None:
    _validate_station_id_th(station_id)
    coll = stationPMReportDB.get_collection(str(station_id))

    pipeline = [
        {"$addFields": {
            "_ts": {
                "$ifNull": [
                    {
                        "$cond": [
                            {"$eq": [{"$type": "$createdAt"}, "date"]},
                            "$createdAt",
                            {"$toDate": "$_id"}
                        ]
                    },
                    {"$toDate": "$_id"}
                ]
            }
        }},
        {"$sort": {"_ts": -1, "_id": -1}},
        {"$limit": 1},
        {"$project": {"_id": 1, "pm_date": 1, "createdAt": 1}}
    ]

    cursor = coll.aggregate(pipeline)
    docs = await cursor.to_list(length=1)
    return docs[0] if docs else None


async def _stationpmreport_latest_core(station_id: str, current: UserClaims):
    """Get latest PM report info for a Station by station_id"""
    _validate_station_id_th(station_id)

    station = await _get_station_by_id(station_id)

    pm_latest = await _latest_pm_date_from_stationpmreport(station_id)
    pm_date = pm_latest.get("pm_date") if pm_latest else None

    ts_raw = (pm_latest.get("createdAt") if pm_latest else None) or station.get("createdAt")

    ts_dt = (parse_iso_any_tz(ts_raw) if isinstance(ts_raw, str)
             else (ts_raw if isinstance(ts_raw, datetime) else None))
    ts_utc = ts_dt.astimezone(ZoneInfo("UTC")).isoformat() if ts_dt else None
    ts_th  = ts_dt.astimezone(ZoneInfo("Asia/Bangkok")).isoformat() if ts_dt else None

    pm_next_date = _compute_next_pm_date_str(pm_date)

    return {
        "_id": str(station["_id"]),
        "station_id": station_id,
        "pm_date": pm_date,
        "pm_next_date": pm_next_date,
        "timestamp": ts_raw,
        "timestamp_utc": ts_utc,
        "timestamp_th": ts_th,
        "source": "stations + stationPMReportDB",
    }


def serialize_doc(doc):
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_doc(d) for d in doc]
    if isinstance(doc, dict):
        result = {}
        for k, v in doc.items():
            if isinstance(v, ObjectId):
                result[k] = str(v)
            elif isinstance(v, datetime):
                result[k] = v.isoformat()
            elif isinstance(v, Decimal128):
                result[k] = float(v.to_decimal())
            else:
                result[k] = serialize_doc(v)
        return result
    return doc


def parse_report_date_to_utc(s: str) -> datetime:
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
        tz_th = ZoneInfo("Asia/Bangkok")
        dt_th = datetime.fromisoformat(s + "T00:00:00").replace(tzinfo=tz_th)
        return dt_th.astimezone(timezone.utc)
    if s.endswith("Z"):
        return datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(timezone.utc)
    if re.search(r"[+\-]\d{2}:\d{2}$", s):
        return datetime.fromisoformat(s).astimezone(timezone.utc)
    return datetime.fromisoformat(s + "+07:00").astimezone(timezone.utc)


# ============================================
# Pydantic Models
# ============================================

class stationPMPostIn(BaseModel):
    report_id: str | None = None
    station_id: str
    # ใบนี้เป็นส่วนหนึ่งของใบ PM สถานี "ใบเดียว 4 ส่วน" (stationPMJob) หรือไม่
    job_id: Optional[str] = None
    rows: dict
    summary: str
    summaryCheck: str | None = None
    # เวลาทำงานจริงของช่าง (ส่งเข้า Maximo ทาง IN09) + ใบงาน Maximo ที่ผูกไว้
    work_start: Optional[str] = None
    work_finish: Optional[str] = None
    wonum: Optional[str] = None
    side: Literal["post", "after"]
    # laborcode ฝั่ง Maximo ที่ช่างเลือกเอง (ใช้ส่งเวลาทำงาน IN09)
    maximo_labor: Optional[List[str]] = None
    maximo_contractor: Optional[str] = None
    # ── ข้อมูลหัวเอกสาร ────────────────────────────────────────────────
    # ฟอร์มกรอกรอบเดียวแล้ว (ไม่มีด่าน Pre-PM) /submit จึงเป็นตัวสร้างเอกสาร
    # เองเมื่อยังไม่มี report_id — ฟิลด์ชุดนี้เคยส่งมาที่ /pre/submit
    job: Optional[Dict[str, Any]] = None
    pm_date: Optional[str] = None
    issue_id: Optional[str] = None
    doc_name: Optional[str] = None
    inspector: Optional[str] = None


# ============================================
# Preview endpoints
# ============================================

@router.get("/stationpmreport/preview-issueid")
async def stationpmreport_preview_issueid(
    station_id: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Preview next issue_id without actually generating it"""
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    pm_type = "ST"
    latest = await _latest_issue_id_anywhere(station_id, pm_type, d, source="station")

    yymm = f"{d.year % 100:02d}{d.month:02d}"
    prefix = f"PM-{pm_type}-{yymm}-"

    if not latest:
        next_issue = f"{prefix}01"
    else:
        m = re.search(r"(\d+)$", latest)
        cur = int(m.group(1)) if m else 0
        next_issue = f"{prefix}{cur+1:02d}"

    return {"issue_id": next_issue}


@router.get("/stationpmreport/latest-docname")
async def stationpmreport_latest_docname(
    station_id: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Get latest doc_name for calculating next number at frontend"""
    latest = await _latest_doc_name_from_pmreport(station_id, pm_date, source="station")
    return {
        "doc_name": latest.get("doc_name") if latest else None,
        "station_id": station_id,
        "pm_date": pm_date,
    }


@router.get("/stationpmreport/preview-docname")
async def preview_docname(
    station_id: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Preview next doc_name without actually generating it"""
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    year = d.year
    latest = await _latest_doc_name_anywhere(station_id, year, source="station")

    if not latest:
        next_doc = f"{station_id}_1/{year}"
    else:
        m = re.search(r"_(\d+)/\d{4}$", latest)
        current_num = int(m.group(1)) if m else 0
        next_doc = f"{station_id}_{current_num + 1}/{year}"

    return {"doc_name": next_doc}


# ============================================
# Get / List / Latest
# ============================================

@router.get("/stationpmreport/get")
async def stationpmreport_get(
    station_id: str,
    report_id: str,
    current: UserClaims = Depends(get_current_user),
):
    """Get report - returns all fields including rows_pre and comment_pre"""
    coll = get_stationpmreport_collection_for(station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")

    return serialize_doc(doc)


@router.get("/stationpmreport/list")
async def stationpmreport_list(
    station_id: str = Query(...),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    status: str | None = Query(None, description="กรองตามสถานะ คั่นหลายค่าด้วย ,"),
    current: UserClaims = Depends(get_current_user),
):
    """List PM reports for a Station by station_id"""
    coll = get_stationpmreport_collection_for(station_id)
    skip = (page - 1) * pageSize

    query: dict = {}
    if status and (conds := pm_flow.status_or_conditions(status)):
        query["$or"] = conds

    cursor = coll.find(
        query,
        {"_id": 1, "issue_id": 1, "doc_name": 1, "pm_date": 1, "inspector": 1,
         "side": 1, "has_photos": 1, "createdAt": 1,
         "status": 1, "stage": 1, "wonum": 1, "approved_by": 1,
         "approved_at": 1, "reject_remark": 1, "rejected_by": 1, "submittedAt": 1,
        },
    ).sort([("createdAt", -1), ("_id", -1)]).skip(skip).limit(pageSize)

    items_raw = await cursor.to_list(length=pageSize)
    total = await coll.count_documents(query)

    pm_dates = [it.get("pm_date") for it in items_raw if it.get("pm_date")]
    url_by_day: Dict[str, str] = {}

    if pm_dates:
        ucoll = get_stationpmurl_coll_upload(station_id)
        ucur = ucoll.find({"pm_date": {"$in": pm_dates}}, {"pm_date": 1, "urls": 1})
        url_docs = await ucur.to_list(length=10_000)
        for u in url_docs:
            day = u.get("pm_date")
            first_url = (u.get("urls") or [None])[0]
            if day and first_url and day not in url_by_day:
                url_by_day[day] = first_url

    items = [{
        "id": str(it["_id"]),
        "issue_id": it.get("issue_id"),
        "doc_name": it.get("doc_name"),
        "pm_date": it.get("pm_date"),
        "side": it.get("side"),
        "inspector": it.get("inspector"),
        "createdAt": _ensure_utc_iso(it.get("createdAt")),
        "file_url": url_by_day.get(it.get("pm_date") or "", ""),
        "has_photos": True if it.get("has_photos") else None,
        **pm_flow.list_fields(it, _ensure_utc_iso),
    } for it in items_raw]

    pm_date_arr = [it.get("pm_date") for it in items_raw if it.get("pm_date")]
    return {
        "items": items,
        "pm_date": pm_date_arr,
        "page": page,
        "pageSize": pageSize,
        "total": total,
    }


@router.get("/stationpmreport/latest/{station_id}")
async def stationpmreport_latest_by_path(
    station_id: str = Path(..., description="Station ID"),
    current: UserClaims = Depends(get_current_user),
):
    """Get latest PM info for a Station by station_id (path param)"""
    return await _stationpmreport_latest_core(station_id, current)


# ============================================
# Post-PM Submit
# ============================================

@router.post("/stationpmreport/submit")
async def stationpmreport_post_submit(
    body: stationPMPostIn,
    current: UserClaims = Depends(get_current_user),
):
    """Post mode submission"""
    station_id = body.station_id.strip()
    coll = get_stationpmreport_collection_for(station_id)
    # ใบ PM สถานีที่แบ่งงานกับ vendor — กรอกได้เฉพาะส่วนของบริษัทตัวเอง (routers/pm_scope.py)
    await pm_scope.guard(current, "station", coll, report_id=body.report_id, job_id=body.job_id, station_id=station_id)

    if body.report_id:
        try:
            oid = ObjectId(body.report_id)
        except InvalidId:
            raise HTTPException(status_code=400, detail="invalid report_id")

        existing = await coll.find_one({"_id": oid, "station_id": station_id})
        if not existing:
            raise HTTPException(status_code=404, detail="Report not found")

        update_fields = {
            "rows": body.rows,
            "summary": body.summary,
            "summaryCheck": body.summaryCheck,
            **pm_flow.post_submit_fields(body),
            **({"job_id": body.job_id} if body.job_id else {}),
            "side": "post",
            "updatedAt": datetime.now(timezone.utc),
        }

        await coll.update_one({"_id": oid}, {"$set": update_fields})
        return {"ok": True, "report_id": body.report_id}

    # Auto-discover latest draft
    # ผูกกับใบแม่แล้วต้องไม่ไปเขียนทับ draft ของใบอื่นในสถานีเดียวกัน
    existing_draft = await coll.find_one(
        {"station_id": station_id, "job_id": body.job_id, "status": "draft"}
        if body.job_id else
        {"station_id": station_id, "side": "post", "status": "draft"},
        {"_id": 1},
        sort=[("createdAt", -1)],
    )

    update_fields = {
        "rows": body.rows,
        "summary": body.summary,
        "summaryCheck": body.summaryCheck,
        **pm_flow.post_submit_fields(body),
        **({"job_id": body.job_id} if body.job_id else {}),
        "side": "post",
        "updatedAt": datetime.now(timezone.utc),
    }

    # หัวเอกสาร (เดิมบันทึกตอน Pre-PM) — ส่งมาเท่าไรเก็บเท่านั้น
    header: dict = {}
    if body.job is not None:
        header["job"] = {**body.job, "pm_type": str(body.job.get("pm_type") or "ST").upper()}
    if (body.pm_date or "").strip():
        header["pm_date"] = body.pm_date.strip()
    if body.inspector is not None:
        header["inspector"] = body.inspector

    if existing_draft:
        await coll.update_one({"_id": existing_draft["_id"]}, {"$set": {**update_fields, **header}})
        return {"ok": True, "report_id": str(existing_draft["_id"])}

    # ── ใบใหม่: จองเลข issue_id / doc_name ให้เลย ─────────────────────────
    pm_date = header.get("pm_date") or datetime.now(th_tz).strftime("%Y-%m-%d")
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")
    pm_type = str((header.get("job") or {}).get("pm_type") or "ST").upper()

    link = await _job_link(station_id, body.job_id)
    if link:
        # ส่วนหนึ่งของใบ PM สถานีใบเดียว — ใช้เลขที่/ชื่อเอกสารของใบแม่
        issue_id, doc_name = link["issue_id"], link["doc_name"]
    else:
        issue_id, doc_name = await _resolve_issue_and_doc(
            coll, get_stationpmurl_coll_upload(station_id), coll.database, station_id, pm_type, d,
            body.issue_id, body.doc_name,
        )

    doc = {
        "station_id": station_id,
        "doc_name": doc_name,
        "issue_id": issue_id,
        "pm_date": pm_date,
        **update_fields,
        **header,
        **({"job_id": link["job_id"]} if link else {}),
        "photos": {},
        "status": "draft",
        "createdAt": datetime.now(timezone.utc),
    }
    res = await coll.insert_one(doc)
    return {
        "ok": True,
        "report_id": str(res.inserted_id),
        "issue_id": issue_id,
        "doc_name": doc_name,
    }


# ============================================
# Photo Upload (Post)
# ============================================

# Station group pattern: r1, r2, r3, ...
# pre_r1/pre_r2 = ข้อ 1-2 (สภาพก่อนเริ่มงาน) เป็นคำถามของใบ Post ตั้งแต่ตัดด่าน Pre-PM ออก
PHOTO_GROUP_PATTERN = re.compile(r"^(pre_)?r\d+$")

# หน้าฟอร์มให้แนบได้ 10 รูป "ต่อข้อย่อย" แต่ server เก็บรูปรวมก้อนเดียวต่อข้อหลัก
# เพดานของข้อที่มีข้อย่อยจึงต้องคูณจำนวนข้อย่อย — เดิมจำกัด 10 ต่อข้อ ข้อ 3 (MDB มี 4 ข้อย่อย)
# แนบเกิน 10 รูปเมื่อไหร่ server ตอบ ok แต่ทิ้งรูปเงียบ ๆ
STATION_GROUP_SUBITEMS = {"r103": 4, "r7": 2, "r8": 2, "r9": 2, "r10": 3}
MAX_PHOTOS_PER_ITEM = 10


@router.post("/stationpmreport/{report_id}/post/photos")
async def stationpmreport_upload_post_photos(
    report_id: str,
    station_id: str = Form(...),
    group: str = Form(...),
    files: List[UploadFile] = File(...),
    remark: Optional[str] = Form(None),
    item: Optional[str] = Form(None),
    current: UserClaims = Depends(get_current_user),
):
    """Upload Post-PM photos for a Station report"""
    # item = ข้อย่อยที่รูปนี้แนบมา (เช่น r103_2) — server เก็บรูปรวมก้อนเดียวต่อข้อหลัก
    # ถ้าไม่จำไว้ ตอนเปิดใบกลับมารูปทุกข้อย่อยจะไปกองอยู่ที่ข้อย่อยแรก
    if item is not None and not re.fullmatch(rf"{re.escape(group)}_\d+", item):
        item = None
    # ตรวจสิทธิ์สถานีก่อนแตะข้อมูล — เดิมเช็คแค่ว่า field ตรงกับ document
    # ซึ่งผู้เรียกคุมได้ทั้งคู่ จึงยิงข้ามสถานีได้
    assert_station_access(current, station_id)
    if not PHOTO_GROUP_PATTERN.match(group):
        raise HTTPException(status_code=400, detail="Bad group key")

    coll = get_stationpmreport_collection_for(station_id)
    # ใบ PM สถานีที่แบ่งงานกับ vendor — กรอกได้เฉพาะส่วนของบริษัทตัวเอง (routers/pm_scope.py)
    await pm_scope.guard(current, "station", coll, report_id=report_id, station_id=station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one(
        {"_id": oid},
        {"_id": 1, "station_id": 1, f"photos.{group}": 1},
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")
    if doc.get("station_id") != station_id:
        raise HTTPException(status_code=400, detail="station_id mismatch")

    MAX_PHOTOS_PER_GROUP = MAX_PHOTOS_PER_ITEM * STATION_GROUP_SUBITEMS.get(group, 1)
    existing_count = len((doc.get("photos") or {}).get(group, []))
    remaining = MAX_PHOTOS_PER_GROUP - existing_count
    if remaining <= 0:
        return {"ok": True, "count": 0, "group": group, "files": [], "skipped": "group_full"}
    files = files[:remaining]

    dest_dir = pathlib.Path(UPLOADS_ROOT) / "stationpm" / station_id / report_id / "post" / group
    dest_dir.mkdir(parents=True, exist_ok=True)

    saved = []
    for f in files:
        ext = _ext(f.filename or "")
        if ext not in ALLOWED_EXTS:
            raise HTTPException(status_code=400, detail=f"File type not allowed: {ext}")

        data = await f.read()
        if len(data) == 0:
            raise HTTPException(status_code=400, detail=f"Empty file: {f.filename}")
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"File too large (> {MAX_FILE_MB} MB)")

        # บังคับให้เป็น JPEG เสมอ — iPhone ส่ง HEIC มาซึ่ง Chrome/Edge/Firefox เปิดไม่ได้
        # ของเดิม (resize_image_bytes) เปิด HEIC ไม่ได้แล้วคืนไบต์เดิมเงียบ ๆ จึงได้ไฟล์
        # "ไบต์ HEIC ในชื่อ .jpg" ที่เปิดไม่ขึ้นทั้งบนเว็บและใน PDF
        try:
            data, out_ext = normalize_image_bytes(data, f.filename or "", max_width=1280, quality=75)
        except ImageConversionError as e:
            raise HTTPException(status_code=400, detail=str(e))

        out_ext = out_ext or "jpg"
        fname = _safe_name(f.filename or f"image_{secrets.token_hex(3)}.{out_ext}")
        fname = pathlib.Path(fname).stem + "." + out_ext
        path = dest_dir / fname
        with open(path, "wb") as out:
            out.write(data)

        url_path = f"/uploads/stationpm/{station_id}/{report_id}/post/{group}/{fname}"
        saved.append({
            "filename": fname,
            "url": url_path,
            "remark": remark or "",
            **({"item": item} if item else {}),
            "uploadedAt": datetime.now(timezone.utc),
        })

    await coll.update_one(
        {"_id": oid},
        {
            "$push": {f"photos.{group}": {"$each": saved}},
            "$set": {"has_photos": True, "updatedAt": datetime.now(timezone.utc)},
        },
    )
    if not saved:
        raise HTTPException(status_code=400, detail="No files were saved")

    return {"ok": True, "count": len(saved), "group": group, "files": saved}


# ============================================
# Finalize
# ============================================

@router.post("/stationpmreport/{report_id}/finalize")
async def stationpmreport_finalize(
    report_id: str,
    station_id: str = Form(...),
    current: UserClaims = Depends(get_current_user),
):
    coll = get_stationpmreport_collection_for(station_id)
    # ใบ PM สถานีที่แบ่งงานกับ vendor — กรอกได้เฉพาะส่วนของบริษัทตัวเอง (routers/pm_scope.py)
    await pm_scope.guard(current, "station", coll, report_id=report_id, station_id=station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    # ช่างกดส่ง = เข้าคิวรอ planner อนุมัติ (ตรวจเวลาทำงานให้ด้วย)
    await pm_flow.finalize(coll, oid, {"station_id": station_id})

    # ลบ PDF cache เผื่อมีค้างอยู่
    for lang in ("th", "en"):
        cache_path = pathlib.Path(UPLOADS_ROOT) / "pdf_cache" / station_id / f"{report_id}_{lang}.pdf"
        if cache_path.exists():
            cache_path.unlink()

    return {"ok": True, "report_id": report_id}


# ============================================
# Station PM URL (PDF Upload + List)
# ============================================

@router.post("/stationpmreport/{report_id}/approve")
async def stationpmreport_approve(
    report_id: str,
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """planner/admin อนุมัติปิดใบงาน แล้วส่งต่อให้ Maximo (IN03 → IN09 → IN02 CLOSED)"""
    station_id = station_id.strip()
    coll = get_stationpmreport_collection_for(station_id)
    oid = pm_flow.to_oid(report_id)

    result = await pm_flow.approve(coll, oid, {"station_id": station_id}, current)

    # อ่านใบงานหลังบันทึกเพื่อให้ข้อมูลที่ส่งไปตรงกับที่เก็บจริง
    fresh = await coll.find_one({"_id": oid}) or {}

    # ใบงานปิดแล้ว = เนื้อหานิ่ง สร้าง PDF เก็บไว้เลยตั้งแต่ตอนนี้
    # ลิงก์ที่ IN03 แนบเข้า Maximo จะได้เปิดปุ๊บได้ไฟล์ ไม่ใช่ให้คนกดเป็นคนรอเรนเดอร์
    pdf_result = await pm_pdf.ensure_report_pdf("station", station_id, report_id)

    # ใบงาน Maximo 1 ใบครอบหลายอุปกรณ์ — ปิดครบทุกตัวก่อนถึงจะยิงปิด WO
    progress = await pm_flow.wo_completion(fresh.get("wonum") or "")
    if not progress["complete"]:
        return {**result, "pdf": pdf_result, "maximo": {"skipped": "ยังกรอกไม่ครบทุกอุปกรณ์ในใบงาน"},
                "progress": progress}

    maximo_result = await pm_maximo_out.safe_sync_closed(
        coll, oid, fresh, memo=f"closed by {current.username}", kind="station"
    )
    return {**result, "pdf": pdf_result, "maximo": maximo_result, "progress": progress}


@router.post("/stationpmreport/{report_id}/reject")
async def stationpmreport_reject(
    report_id: str,
    body: pm_flow.PMRejectIn,
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """planner/admin ตีกลับใบงานให้ช่างแก้"""
    station_id = station_id.strip()
    coll = get_stationpmreport_collection_for(station_id)
    oid = pm_flow.to_oid(report_id)
    return await pm_flow.reject(coll, oid, {"station_id": station_id}, current, body.remark)


@router.post("/stationpmurl/upload-files", status_code=201)
async def stationpmurl_upload_files(
    station_id: str = Form(...),
    reportDate: str = Form(...),
    files: List[UploadFile] = File(...),
    issue_id: Optional[str] = Form(None),
    doc_name: Optional[str] = Form(None),
    inspector: Optional[str] = Form(None),
    current: UserClaims = Depends(get_current_user),
):
    """Upload PM PDF files for a Station"""
    # ตรวจสิทธิ์สถานีก่อนแตะข้อมูล — เดิมเช็คแค่ว่า field ตรงกับ document
    # ซึ่งผู้เรียกคุมได้ทั้งคู่ จึงยิงข้ามสถานีได้
    assert_station_access(current, station_id)
    coll = get_stationpmurl_coll_upload(station_id)
    rep_coll = get_stationpmreport_collection_for(station_id)

    pm_date = normalize_pm_date(reportDate)
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="reportDate/pm_date must be YYYY-MM-DD")

    pm_type = "ST"

    # Resolve issue_id
    final_issue_id: str | None = None
    client_issue = (issue_id or "").strip()

    if client_issue:
        yymm = f"{d.year % 100:02d}{d.month:02d}"
        prefix = f"PM-{pm_type}-{yymm}-"
        valid_fmt = client_issue.startswith(prefix)

        url_exists = await coll.find_one({"issue_id": client_issue})
        rep_exists = await rep_coll.find_one({"issue_id": client_issue})
        unique = not (url_exists or rep_exists)

        if valid_fmt and unique:
            final_issue_id = client_issue

    if not final_issue_id:
        final_issue_id = await _next_issue_id_no_conflict(
            coll.database, rep_coll, coll, station_id, pm_type, d, pad=2
        )

    # Reuse year_seq from existing report if possible
    year_seq: int | None = None
    rep = await rep_coll.find_one(
        {"issue_id": final_issue_id},
        {"year_seq": 1, "pm_date": 1},
    )
    if rep and rep.get("year_seq") is not None:
        year_seq = int(rep["year_seq"])

    if year_seq is None:
        year_seq = await _next_year_seq(coll.database, station_id, pm_type, d)

    year = d.year

    # Resolve doc_name
    final_doc_name: str | None = None
    if doc_name:
        candidate = doc_name.strip()
        ok_format = candidate.startswith(f"{station_id}_")

        rep_exists = await rep_coll.find_one({"doc_name": candidate})
        url_exists = await coll.find_one({"doc_name": candidate})
        unique = not (rep_exists or url_exists)

        if ok_format and unique:
            final_doc_name = candidate

    if not final_doc_name:
        final_doc_name = f"{station_id}_{year_seq}/{year}"

    # Save files
    dest_dir = pathlib.Path(UPLOADS_ROOT) / "stationpmurl" / station_id / pm_date
    dest_dir.mkdir(parents=True, exist_ok=True)

    urls: list[str] = []
    metas: list[dict] = []

    for f in files:
        ext = (f.filename.rsplit(".", 1)[-1].lower() if f.filename and "." in f.filename else "")
        if ext != "pdf":
            raise HTTPException(status_code=400, detail=f"Only PDF allowed, got: {ext}")

        data = await f.read()
        if len(data) == 0:
            raise HTTPException(status_code=400, detail=f"Empty file: {f.filename}")
        if not data[:5].startswith(b"%PDF-"):
            raise HTTPException(status_code=400, detail=f"Invalid PDF file: {f.filename}")
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"File too large (> {MAX_FILE_MB} MB)")

        fname = _safe_name(f.filename or f"file_{secrets.token_hex(3)}.pdf")
        dest = dest_dir / fname
        with open(dest, "wb") as out:
            out.write(data)

        urls.append(f"/uploads/stationpmurl/{station_id}/{pm_date}/{fname}")
        metas.append({"name": f.filename, "size": len(data)})

    inspector_clean = (inspector or "").strip() or None

    now = datetime.now(timezone.utc)
    doc = {
        "station_id": station_id,
        "pm_date": pm_date,
        "issue_id": final_issue_id,
        "inspector": inspector_clean,
        "year": year,
        "year_seq": year_seq,
        "doc_name": final_doc_name,
        "urls": urls,
        "meta": {"files": metas},
        "source": "upload-files",
        "createdAt": now,
        "updatedAt": now,
    }
    res = await coll.insert_one(doc)

    return {
        "ok": True,
        "inserted_id": str(res.inserted_id),
        "count": len(urls),
        "urls": urls,
        "issue_id": final_issue_id,
        "year_seq": year_seq,
        "doc_name": final_doc_name,
        "inspector": inspector_clean,
    }


@router.get("/stationpmurl/list")
async def stationpmurl_list(
    station_id: str = Query(...),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    current: UserClaims = Depends(get_current_user),
):
    """List PM URL documents for a Station"""
    coll = get_stationpmurl_coll_upload(station_id)
    skip = (page - 1) * pageSize

    cursor = coll.find(
        {},
        {"_id": 1, "issue_id": 1, "doc_name": 1, "inspector": 1,
         "pm_date": 1, "reportDate": 1, "urls": 1, "createdAt": 1},
    ).sort([("createdAt", -1), ("_id", -1)]).skip(skip).limit(pageSize)

    items_raw = await cursor.to_list(length=pageSize)
    total = await coll.count_documents({})

    def _pm_date_from(doc: dict) -> str | None:
        s = doc.get("pm_date")
        if isinstance(s, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
            return s
        rd = doc.get("reportDate")
        if isinstance(rd, datetime):
            return rd.astimezone(th_tz).date().isoformat()
        if isinstance(rd, str):
            try:
                dt = datetime.fromisoformat(rd.replace("Z", "+00:00"))
            except Exception:
                try:
                    dt = datetime.fromisoformat(rd).replace(tzinfo=th_tz)
                except Exception:
                    return None
            return dt.astimezone(th_tz).date().isoformat()
        return None

    items = []
    pm_date_arr = []

    for it in items_raw:
        pm_date_str = _pm_date_from(it)
        if pm_date_str:
            pm_date_arr.append(pm_date_str)

        urls = it.get("urls") or []
        first_url = urls[0] if urls else ""

        items.append({
            "id": str(it["_id"]),
            "pm_date": pm_date_str,
            "issue_id": it.get("issue_id"),
            "inspector": it.get("inspector"),
            "doc_name": it.get("doc_name"),
            "createdAt": _ensure_utc_iso(it.get("createdAt")),
            "file_url": first_url,
            "urls": urls,
        })

    return {
        "items": items,
        "pm_date": [d for d in pm_date_arr if d],
        "page": page,
        "pageSize": pageSize,
        "total": total,
    }


# ============================================
# Migration & Photos ZIP
# ============================================

@router.post("/stationpmreport/migrate/has-photos")
async def migrate_has_photos_endpoint(
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """One-time migration: set has_photos=True for docs that have photos but missing the flag"""
    coll = get_stationpmreport_collection_for(station_id)
    result = await coll.update_many(
        {
            "has_photos": {"$exists": False},
            "$or": [
                {"photos_pre": {"$ne": {}, "$exists": True}},
                {"photos": {"$ne": {}, "$exists": True}},
            ],
        },
        {"$set": {"has_photos": True}},
    )
    return {"ok": True, "modified": result.modified_count}


@router.get("/stationpmreport/{report_id}/photos/zip")
async def download_photos_zip(
    report_id: str,
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Download all Pre & Post photos of a report as a single ZIP file"""
    coll = get_stationpmreport_collection_for(station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one(
        {"_id": oid, "station_id": station_id},
        {"photos_pre": 1, "photos": 1, "has_photos": 1},
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")

    if not doc.get("has_photos"):
        raise HTTPException(status_code=404, detail="No photos found")

    # รวม photos_pre และ photos เข้าด้วยกัน
    all_photos: list[tuple[str, str]] = []  # (zip_path, disk_path)

    photos_pre: dict = doc.get("photos_pre") or {}
    for group, items in photos_pre.items():
        for item in (items or []):
            fname = item.get("filename", "")
            if not fname:
                continue
            disk_path = pathlib.Path(UPLOADS_ROOT) / "stationpm" / station_id / report_id / "pre" / group / fname
            all_photos.append((f"pre/{group}/{fname}", str(disk_path)))

    photos_post: dict = doc.get("photos") or {}
    for group, items in photos_post.items():
        for item in (items or []):
            fname = item.get("filename", "")
            if not fname:
                continue
            disk_path = pathlib.Path(UPLOADS_ROOT) / "stationpm" / station_id / report_id / "post" / group / fname
            all_photos.append((f"post/{group}/{fname}", str(disk_path)))

    if not all_photos:
        raise HTTPException(status_code=404, detail="No photos found")

    # สร้าง ZIP ใน memory
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for zip_path, disk_path in all_photos:
            p = pathlib.Path(disk_path)
            if p.exists():
                zf.write(p, arcname=zip_path)

    zip_buffer.seek(0)
    zip_filename = f"photos_{station_id}_{report_id}.zip"

    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{zip_filename}"'},
    )