"""
routers/pm_maximo.py
====================
รับใบงาน PM ที่เปิดจาก Maximo เข้ามาแสดงในหน้า PM report ของแต่ละ tab
(charger / mdb / ccb / cb-box / station)

รับได้ 2 ทาง:
  1) pull  — iMPS ยิง GET ไปถาม Maximo เอง (services.maximo.query_workorders)
  2) push  — Maximo ยิง POST /maximo/pm-workorder เข้ามาตอนเปิดใบงาน (webhook)

ทั้งสองทางลงที่ collection เดียวกัน: iMPS.maximo_pm_workorders (unique key = wonum)
แล้ว frontend อ่านผ่าน GET /pm-maximo/work-orders

หมายเหตุ: iMPS ไม่ยิงไปเปิดใบงานที่ Maximo — การกด "เพิ่ม PM report" ในระบบ
เป็นงานฝั่ง iMPS ล้วน ๆ
"""

import json
import logging
import os
import re
from datetime import datetime, timezone
from typing import Any, Literal, Optional

from bson.objectid import ObjectId
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from pydantic import BaseModel, Field

from config import client, station_collection, charger_collection
from deps import get_current_user, UserClaims
from services import maximo as maximo_svc
from routers import pm_flow
from services.maximo import query_workorders

log = logging.getLogger("pm_maximo")
router = APIRouter(tags=["pm-maximo"])

PMSource = Literal["charger", "mdb", "ccb", "cbbox", "station"]

# secret ที่ Maximo ต้องแนบมาใน header X-Maximo-Token เวลายิง webhook เข้ามา
MAXIMO_WEBHOOK_SECRET = os.getenv("MAXIMO_WEBHOOK_SECRET", "")

# สถานะที่ถือว่า "ใบงานยังเปิดอยู่"
# OPEN = ค่า default ของ IN06 (Maximo → iMPS), ที่เหลือเป็นสถานะมาตรฐานฝั่ง Maximo
OPEN_WO_STATUSES = {"OPEN", "WAPPR", "APPR", "INPRG", "WMATL", "WSCH"}

# ── PM type → tab ──
# pm_type เป็นตัวชี้ว่าใบงานนี้เป็นของ tab ไหน (location อย่างเดียวแยกไม่ได้
# เพราะ mdb/ccb/cb-box/station ใช้ location ของสถานีร่วมกัน)
PM_TYPE_TO_SOURCE: dict[str, str] = {
    "CG": "charger",
    "MB": "mdb",
    "CC": "ccb",
    "CB": "cbbox",
    "ST": "station",
}
SOURCE_TO_PM_TYPE = {v: k for k, v in PM_TYPE_TO_SOURCE.items()}


def _norm_pm_type(value: Any) -> str:
    """รับ pm_type จาก Maximo — รองรับทั้ง 'CG' และชื่อเต็ม 'charger'"""
    s = str(value or "").strip().upper()
    if s in PM_TYPE_TO_SOURCE:
        return s
    return SOURCE_TO_PM_TYPE.get(s.lower(), "")


def _norm_pm_date(value: Any) -> str:
    """normalize เป็น YYYY-MM-DD — รองรับ ISO datetime ที่ Maximo ส่งมา"""
    s = str(value or "").strip()
    if not s:
        return ""
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).date().isoformat()
    except ValueError:
        return s[:10]


def _wo_coll():
    """iMPS.maximo_pm_workorders — motor async collection"""
    return client["iMPS"]["maximo_pm_workorders"]


# ══════════════════════════════════════════════════════════════════
# Location resolve
# ══════════════════════════════════════════════════════════════════
def _locations_for(source: str, identifier: str) -> tuple[list[str], str]:
    """
    หา maximo location ที่เกี่ยวข้องกับ tab/อุปกรณ์ที่กำลังดูอยู่

    charger → location ของตู้ (SN นั้น)
    ที่เหลือ → location ของสถานี

    Returns: (locations, station_id)
    """
    if source == "charger":
        charger = charger_collection.find_one(
            {"SN": identifier}, {"station_id": 1, "maximo_location": 1}
        ) or {}
        station_id = charger.get("station_id") or ""
        loc = charger.get("maximo_location") or ""
        if loc:
            return [loc], station_id
    else:
        station_id = identifier

    st = station_collection.find_one(
        {"station_id": station_id}, {"maximo_location": 1}
    ) or {}
    loc = st.get("maximo_location") or ""
    return ([loc] if loc else []), station_id


def _station_scope(source: str, identifier: str) -> tuple[str, str]:
    """
    หา station_id + maximo location "ระดับสถานี" ของ tab/อุปกรณ์ที่กำลังดูอยู่

    ใบงาน IN06 เปิดมาระดับสถานี — tab charger ที่ส่ง SN มา จึงต้อง map SN
    กลับเป็นสถานีก่อน ไม่งั้นจะไปเทียบกับ location ของตู้ (คนละระดับกัน)

    Returns: (station_id, station_location)
    """
    if source == "charger":
        charger = charger_collection.find_one(
            {"SN": identifier}, {"station_id": 1}
        ) or {}
        station_id = charger.get("station_id") or ""
    else:
        station_id = identifier

    if not station_id:
        return "", ""

    st = station_collection.find_one(
        {"station_id": station_id}, {"maximo_location": 1}
    ) or {}
    return station_id, (st.get("maximo_location") or "")


def _location_variants(location: str) -> list[str]:
    """
    รหัส location เดียวกันแต่เขียนต่างกัน — Maximo ส่ง "PTG0001-EV" มาได้ ขณะที่
    iMPS อาจเก็บ station root "PTG0001" ไว้ (หรือกลับกัน) เทียบตรง ๆ จะไม่เจอกัน
    แล้วใบงานจะเข้ามาแต่ไม่โผล่ในหน้า PM report

    Returns: [ตัวเดิม, แบบไม่มี -EV, แบบมี -EV] (ไม่ซ้ำ)
    """
    loc = (location or "").strip()
    if not loc:
        return []

    out = [loc]

    # location ระดับตู้ที่ Maximo ส่งมา เช่น "HMP0002-EV-BTL01GU001" หรือ
    # "ZOO0001-ES-WAC21GU001" — ตัดหางให้เหลือระดับสถานี ("HMP0002-EV")
    # ไม่งั้น reverse lookup ไม่เจอสถานี แล้วใบงานจะไม่โผล่ในหน้า PM report
    m = re.match(r"^(?P<station>.+?-(?:EV|ES))-.+$", loc, re.IGNORECASE)
    if m:
        out.append(m.group("station"))

    # ระดับสถานีลองทั้งแบบมีและไม่มี -EV ต่อท้าย (iMPS กับ Maximo เขียนคนละแบบได้)
    # ไม่ขยายให้ location ระดับตู้ เพราะ "…-BTL01GU001-EV" ไม่มีทางตรงกับอะไร
    station_level = [x for x in out if x.upper().endswith("-EV")] or [loc]
    for base in station_level:
        root = base[:-3] if base.upper().endswith("-EV") else base
        out.extend([root, f"{root}-EV"])

    return list(dict.fromkeys(x for x in out if x))


def _resolve_owner(location: str) -> dict:
    """
    map location ที่ Maximo ส่งมา → station_id / sn ของ iMPS (reverse lookup)
    """
    variants = _location_variants(location)
    if not variants:
        return {}

    # เทียบแบบไม่สนตัวพิมพ์เล็ก/ใหญ่ และเผื่อช่องว่างหัวท้ายที่ติดมาจากการพิมพ์
    # (เคสจริง: ตั้ง maximo_location เป็น "hmp0002-ev " แล้วหาไม่เจอทั้งที่ตั้งถูก)
    cond = {"$or": [
        {"maximo_location": {"$regex": rf"^\s*{re.escape(v)}\s*$", "$options": "i"}}
        for v in variants
    ]}

    charger = charger_collection.find_one(cond, {"SN": 1, "station_id": 1})
    if charger:
        return {"station_id": charger.get("station_id"), "sn": charger.get("SN")}

    st = station_collection.find_one(cond, {"station_id": 1})
    if st:
        return {"station_id": st.get("station_id"), "sn": None}

    log.warning(
        "  ⚠️  Maximo location %r ไม่ตรงกับ maximo_location ของสถานี/ตู้ไหนเลย "
        "— ใบงานจะเก็บไว้แต่ไม่ผูกกับ station_id (ลองแล้ว: %s)",
        location, variants,
    )
    return {}


# ══════════════════════════════════════════════════════════════════
# Normalize + upsert
# ══════════════════════════════════════════════════════════════════
def _normalize(raw: dict, origin: str) -> dict | None:
    """
    แปลง WO ดิบจาก Maximo เป็น shape ที่ iMPS ใช้

    3 field ที่ต้องมี: pm_type, location, pm_date
    (pm_date ยอมให้ fallback มาจาก targstartdate/schedstart ที่ Maximo ส่งมาด้วย)
    คืน None ถ้าขาดตัวใดตัวหนึ่ง → นับเป็น skipped
    """
    pm_type = _norm_pm_type(raw.get("pm_type") or raw.get("pmtype") or raw.get("zpmtype"))
    location = str(raw.get("location") or "").strip()
    pm_date = _norm_pm_date(
        raw.get("pm_date")
        or raw.get("pmdate")
        or raw.get("targstartdate")
        or raw.get("schedstart")
    )

    if not (pm_type and location and pm_date):
        return None

    owner = _resolve_owner(location)

    return {
        # ── 3 ตัวหลักจาก Maximo ──
        "pm_type": pm_type,
        "location": location,
        "pm_date": pm_date,
        "source": PM_TYPE_TO_SOURCE[pm_type],   # tab ที่ใบงานนี้สังกัด
        # ── ข้อมูลประกอบ (ถ้า Maximo ส่งมาด้วย) ──
        "wonum": str(raw.get("wonum") or "").strip() or None,
        "description": raw.get("description"),
        "status": raw.get("status"),
        "worktype": raw.get("worktype"),
        "targcompdate": raw.get("targcompdate"),
        # ── map กลับเข้าระบบ iMPS ──
        "station_id": owner.get("station_id"),
        "sn": owner.get("sn"),
        "origin": origin,             # "pull" | "webhook"
        "raw": raw,
        "updatedAt": datetime.now(timezone.utc),
    }


def _dedup_key(doc: dict) -> dict:
    """wonum ถ้ามี — ไม่มีก็ใช้ 3 ตัวหลักเป็น key แทน"""
    if doc.get("wonum"):
        return {"wonum": doc["wonum"]}
    return {
        "pm_type": doc["pm_type"],
        "location": doc["location"],
        "pm_date": doc["pm_date"],
    }


async def _upsert_many(items: list[dict], origin: str) -> dict:
    coll = _wo_coll()
    try:
        await coll.create_index("wonum", sparse=True)
        await coll.create_index([("pm_type", 1), ("location", 1), ("pm_date", 1)])
        await coll.create_index([("station_id", 1), ("source", 1), ("status", 1)])
    except Exception:
        pass

    inserted = updated = skipped = 0
    for raw in items:
        doc = _normalize(raw, origin)
        if not doc:
            skipped += 1
            continue
        res = await coll.update_one(
            _dedup_key(doc),
            {"$set": doc, "$setOnInsert": {"receivedAt": datetime.now(timezone.utc)}},
            upsert=True,
        )
        if res.upserted_id:
            inserted += 1
        elif res.modified_count:
            updated += 1

    return {"inserted": inserted, "updated": updated, "skipped": skipped}


# ══════════════════════════════════════════════════════════════════
# 1) Webhook — Maximo ยิงเข้ามาตอนเปิดใบงาน
# ══════════════════════════════════════════════════════════════════
class MaximoWorkOrderIn(BaseModel):
    """
    3 field ที่ต้องส่งมา:
      pm_type  — CG (charger) / MB (mdb) / CC (ccb) / CB (cb-box) / ST (station)
      location — รหัส Maximo location เช่น "PTG0001-EV-BTL01GU201"
      pm_date  — วันที่ทำ PM (YYYY-MM-DD หรือ ISO datetime)
    ที่เหลือเป็น optional — ส่งมาก็เก็บให้ ไม่ส่งก็ได้
    """
    pm_type: str
    location: str
    pm_date: str

    wonum: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    worktype: Optional[str] = None
    targcompdate: Optional[str] = None

    class Config:
        extra = "allow"


class MaximoWorkOrderBatchIn(BaseModel):
    workorders: list[MaximoWorkOrderIn] = Field(default_factory=list)


@router.post("/maximo/pm-workorder")
async def maximo_pm_workorder_webhook(
    body: MaximoWorkOrderIn | MaximoWorkOrderBatchIn,
    x_maximo_token: str | None = Header(default=None, alias="X-Maximo-Token"),
):
    """
    รับใบงาน PM ที่ Maximo เปิด — ยิงได้ทั้งใบเดียวและเป็น batch {"workorders": [...]}
    ป้องกันด้วย shared secret ใน header X-Maximo-Token (env MAXIMO_WEBHOOK_SECRET)
    """
    if not MAXIMO_WEBHOOK_SECRET:
        raise HTTPException(
            status_code=503,
            detail="MAXIMO_WEBHOOK_SECRET is not configured on this server",
        )
    if x_maximo_token != MAXIMO_WEBHOOK_SECRET:
        raise HTTPException(status_code=401, detail="invalid X-Maximo-Token")

    if isinstance(body, MaximoWorkOrderBatchIn):
        items = [w.model_dump() for w in body.workorders]
    else:
        items = [body.model_dump()]

    if not items:
        return {"ok": True, "received": 0, "inserted": 0, "updated": 0, "skipped": 0}

    bad = [
        str(it.get("pm_type"))
        for it in items
        if not _norm_pm_type(it.get("pm_type"))
    ]
    if bad:
        raise HTTPException(
            status_code=400,
            detail=f"pm_type ไม่ถูกต้อง: {', '.join(sorted(set(bad)))} "
                   f"— ต้องเป็น {', '.join(PM_TYPE_TO_SOURCE)}",
        )

    stats = await _upsert_many(items, origin="webhook")
    log.info(f"  📥 Maximo webhook: {stats} ({len(items)} received)")
    return {"ok": True, "received": len(items), **stats}


# ══════════════════════════════════════════════════════════════════
# 2) Pull — iMPS ไปดึงจาก Maximo เอง
# ══════════════════════════════════════════════════════════════════
async def sync_workorders(locations: list[str] | None = None) -> dict:
    """ดึง WO จาก Maximo แล้ว upsert ลง DB — คืน stats"""
    members = await query_workorders(locations=locations)
    if members is None:
        return {"ok": False, "reason": "maximo_unavailable"}
    stats = await _upsert_many(members, origin="pull")
    return {"ok": True, "fetched": len(members), **stats}


@router.post("/pm-maximo/sync")
async def pm_maximo_sync(
    source: Optional[PMSource] = Query(None),
    identifier: Optional[str] = Query(None),
    current: UserClaims = Depends(get_current_user),
):
    """
    ดึงใบงาน PM จาก Maximo เข้ามาเก็บใน iMPS
    - ไม่ส่ง source/identifier = ดึงทุก location
    - ส่งมา = ดึงเฉพาะ location ของ tab/อุปกรณ์นั้น
    """
    locations = None
    if source and identifier:
        locations, _ = _locations_for(source, identifier.strip())
        if not locations:
            raise HTTPException(
                status_code=400, detail="อุปกรณ์/สถานีนี้ยังไม่ได้ผูก Maximo location"
            )

    result = await sync_workorders(locations)
    if not result.get("ok"):
        raise HTTPException(status_code=502, detail="เรียก Maximo ไม่สำเร็จ")
    return result


# ══════════════════════════════════════════════════════════════════
# 3) Read — frontend อ่านใบงานที่รับเข้ามา
# ══════════════════════════════════════════════════════════════════
def _serialize(doc: dict) -> dict:
    return {
        "pm_type": doc.get("pm_type"),
        "location": doc.get("location"),
        "pm_date": doc.get("pm_date"),
        "source": doc.get("source"),
        "wonum": doc.get("wonum"),
        "description": doc.get("description"),
        "status": doc.get("status"),
        "worktype": doc.get("worktype"),
        "targcompdate": doc.get("targcompdate"),
        "station_id": doc.get("station_id"),
        "sn": doc.get("sn"),
        "origin": doc.get("origin"),
        "receivedAt": (
            doc["receivedAt"].isoformat() if isinstance(doc.get("receivedAt"), datetime) else None
        ),
    }


@router.get("/pm-maximo/work-orders")
async def pm_maximo_work_orders(
    source: PMSource = Query(...),
    identifier: str = Query(..., description="SN สำหรับ charger, station_id สำหรับ tab อื่น"),
    only_open: bool = Query(True, description="เอาเฉพาะใบงานที่ยังเปิดอยู่"),
    refresh: bool = Query(False, description="ดึงจาก Maximo ใหม่ก่อนอ่าน"),
    limit: int = Query(50, ge=1, le=200),
    current: UserClaims = Depends(get_current_user),
):
    """ใบงาน PM จาก Maximo ของ tab/อุปกรณ์ที่กำลังดูอยู่"""
    identifier = (identifier or "").strip()
    if not identifier:
        raise HTTPException(status_code=400, detail="identifier is required")

    locations, station_id = _locations_for(source, identifier)

    if refresh and locations:
        await sync_workorders(locations)

    # pm_type คือตัวแยก tab — location ของ mdb/ccb/cb-box/station เป็นตัวเดียวกัน
    q: dict[str, Any] = {"pm_type": SOURCE_TO_PM_TYPE[source]}
    if locations:
        q["location"] = {"$in": locations}
    elif source == "charger":
        q["sn"] = identifier
    else:
        q["station_id"] = station_id

    if only_open:
        # ใบงานที่ Maximo ไม่ได้ส่ง status มา ถือว่ายังเปิดอยู่
        q["$or"] = [
            {"status": {"$in": list(OPEN_WO_STATUSES)}},
            {"status": {"$in": [None, ""]}},
        ]

    cursor = _wo_coll().find(q).sort([("pm_date", -1), ("_id", -1)]).limit(limit)
    docs = await cursor.to_list(length=limit)

    return {
        "items": [_serialize(d) for d in docs],
        "total": len(docs),
        "locations": locations,
        "station_id": station_id,
    }


# ══════════════════════════════════════════════════════════════════
# 4) Open — Maximo ยิงเข้ามาตอน "เปิดใบงาน PM"  (IN06)
#     field ที่ iMPS รับ: location, pm_date, wonum, status, company (+description)
#     บังคับจริงแค่ location — ที่เหลือขาดได้ (จะเตือนกลับไปใน response.warnings)
#
#    รับ payload แบบยืดหยุ่นโดยตั้งใจ: ชื่อฟิลด์ไม่สนตัวพิมพ์เล็ก/ใหญ่ รับชื่อพ้อง
#    (targstartdate/schedstart → pm_date) และรับได้ทั้ง object เดียว, array,
#    {"workorders":[…]} และ {"member":[…]} — เพราะ integration ฝั่ง Maximo
#    เปลี่ยนทรง payload ได้ตามที่ตั้งค่าไว้ เราไม่อยากให้ล้มทั้งใบเพราะ 422
#
#    ⚠️ location ที่ Maximo ส่งมาเป็น "ระดับสถานี" (station-level) — 1 ใบงาน
#    ต่อ 1 สถานี ไม่ได้ระบุอุปกรณ์ ผู้ใช้ต้องมาเลือกใน iMPS เองว่าจะ PM
#    อุปกรณ์ตัวไหนบ้าง (เลือกได้หลายตัว) → เก็บที่ field selected_equipment
#    ผ่าน POST /maximo/pm/{wonum}/equipment (ไม่ได้มาจาก Maximo)
#
#    ลงที่ collection iMPS.maximo_pm_open (แยกจาก maximo_pm_workorders
#    ของ pull/webhook เดิม เพื่อไม่ให้ 2 contract ปนกัน) — dedup ด้วย wonum
# ══════════════════════════════════════════════════════════════════
def _open_coll():
    """iMPS.maximo_pm_open — motor async collection"""
    return client["iMPS"]["maximo_pm_open"]


# ประเภทอุปกรณ์ที่เลือก PM ได้ในสถานีหนึ่ง ๆ (ตรงกับ tab ใน PM report)
EQUIP_TYPES = {"charger", "mdb", "ccb", "cbbox", "station"}
PM_PLANNING_ROLES = {"admin", "owner", "planner"}
# alias ที่ frontend/Maximo อาจส่งมา → normalize เป็น key มาตรฐาน
EQUIP_ALIASES = {"cb_box": "cbbox", "cbbox": "cbbox", "cb-box": "cbbox"}


# ── ชื่อฟิลด์ที่ Maximo (หรือ IESB) อาจส่งมา → key มาตรฐานของ iMPS ──
# เทียบแบบ case-insensitive และตัด _ / - / ช่องว่างออกก่อน เพราะ Maximo ส่ง
# attribute เป็นตัวพิมพ์ใหญ่ (LOCATION) บ้าง camelCase บ้าง แล้วแต่ integration
_FIELD_ALIASES: dict[str, str] = {
    # location (ระดับสถานี)
    "location": "location", "loc": "location", "zlocation": "location",
    "locationnum": "location", "siteloc": "location",
    # pm_date — Maximo เรียกวันนัดงานได้หลายชื่อแล้วแต่ object structure
    "pmdate": "pm_date", "zpmdate": "pm_date",
    "targstartdate": "pm_date", "targetstart": "pm_date",
    "schedstart": "pm_date", "startdate": "pm_date", "scheduledate": "pm_date",
    # wonum
    "wonum": "wonum", "wonumber": "wonum", "workorderid": "wonum",
    "woid": "wonum", "zwonum": "wonum",
    # status
    "status": "status", "wostatus": "status", "zstatus": "status",
    # company
    "company": "company", "companyname": "company", "zcompany": "company",
    # description
    "description": "description", "desc": "description",
    "zdescription": "description", "shortdesc": "description",
}

# key ที่ Maximo อาจใช้ห่อ list ของใบงานมา (batch)
_BATCH_KEYS = ("workorders", "workorder", "member", "wo", "data", "items")


def _alias_key(key: str) -> str:
    """'TARG_START_DATE' → 'targstartdate' → 'pm_date' (ไม่รู้จักก็คืนชื่อเดิม lowercase)"""
    flat = re.sub(r"[\s_\-.]", "", str(key)).lower()
    return _FIELD_ALIASES.get(flat, str(key).strip().lower())


def _canon(raw: Any) -> dict:
    """
    ทำ payload 1 ใบงานให้เป็น key มาตรฐาน

    - ชื่อฟิลด์ case-insensitive + ตัด _ - . ออก (LOCATION / Location / pm-date)
    - ค่า scalar ที่ไม่ใช่ string (เช่น status ส่งมาเป็นตัวเลข) แปลงเป็น string ให้
    - key ที่ไม่รู้จัก เก็บไว้ตามเดิม ไม่ทิ้ง
    """
    if not isinstance(raw, dict):
        return {}

    def _coerce(v: Any) -> Any:
        # status/company ที่ส่งมาเป็นตัวเลขล้วน ไม่ควรตกไปเพราะ type ไม่ตรง
        return str(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else v

    out: dict[str, Any] = {}
    # รอบแรก: ชื่อพ้อง (targstartdate → pm_date) — ใครมาก่อนได้ก่อน
    for k, v in raw.items():
        key = _alias_key(k)
        if out.get(key) in (None, ""):
            out[key] = _coerce(v)
    # รอบสอง: ชื่อจริงทับชื่อพ้องเสมอ — ถ้าส่ง targstartdate มาพร้อม pm_date
    # ต้องได้ค่าจาก pm_date ไม่ใช่ค่าที่ alias เขียนทิ้งไว้
    for k, v in raw.items():
        key = re.sub(r"[\s\-.]", "_", str(k).strip()).lower()
        if key in _FIELD_ALIASES.values() and v not in (None, ""):
            out[key] = _coerce(v)
    return out


def _extract_items(payload: Any) -> list[dict]:
    """
    ดึง list ของใบงานออกจาก body — รองรับทุกทรงที่ Maximo ยิงมาได้

      {...}                       ใบเดียว
      [{...}, {...}]              array ตรง ๆ (bulk ของ Maximo REST)
      {"workorders": [...]}       batch ตามสัญญาเดิม
      {"member": [...]}           ทรงมาตรฐานของ Maximo OSLC
      {"ZAPIWO": {"member": [...]}}  publish channel ที่ห่ออีกชั้น
    """
    if isinstance(payload, list):
        return [_canon(x) for x in payload if isinstance(x, dict)]

    if not isinstance(payload, dict):
        return []

    lowered = {str(k).strip().lower(): v for k, v in payload.items()}
    for key in _BATCH_KEYS:
        val = lowered.get(key)
        if isinstance(val, list):
            return [_canon(x) for x in val if isinstance(x, dict)]
        if isinstance(val, dict):
            # ห่ออีกชั้น เช่น {"ZAPIWO": {"member": [...]}} — ไล่เข้าไปข้างใน
            return _extract_items(val)

    # envelope ชั้นเดียวที่ key เป็นชื่อ object structure: {"ZAPIWO": {...}}
    if len(payload) == 1:
        only = next(iter(payload.values()))
        if isinstance(only, (list, dict)):
            inner = _extract_items(only)
            if inner:
                return inner

    return [_canon(payload)]


def _normalize_open(raw: dict) -> dict | None:
    """แปลง WO ที่ Maximo ส่งมาเป็น shape ที่เก็บ — คืน None ถ้าไม่มี location"""
    location = str(raw.get("location") or "").strip()
    if not location:
        return None

    owner = _resolve_owner(location)

    def _text(key: str) -> str | None:
        v = raw.get(key)
        return str(v).strip() or None if v not in (None, "") else None

    def _upper(key: str) -> str | None:
        """wonum/status สเปกระบุ type = UPPER — เก็บเป็นตัวพิมพ์ใหญ่เสมอ
        ไม่งั้น status ตัวเล็กจะไม่ match OPEN_WO_STATUSES แล้วใบงานหายจากหน้า PM"""
        v = _text(key)
        return v.upper() if v else None

    return {
        "location": location,
        "description": _text("description"),
        "pm_date": _norm_pm_date(raw.get("pm_date")),
        "wonum": _upper("wonum"),
        # สเปก IN06 กำหนด Default = OPEN เมื่อ Maximo ไม่ได้ส่ง status มา
        "status": _upper("status") or "OPEN",
        "company": _text("company"),
        # ── map กลับเข้าระบบ iMPS ──
        "station_id": owner.get("station_id"),
        "sn": owner.get("sn"),
        "origin": "maximo-open",
        "raw": raw,
        "updatedAt": datetime.now(timezone.utc),
    }


def _open_dedup_key(doc: dict) -> dict:
    """ใช้ wonum เป็น key กันซ้ำ (ยิง wonum เดิมซ้ำ = อัปเดตใบเดิม)"""
    if doc.get("wonum"):
        return {"wonum": doc["wonum"]}
    # กันเหนียว: ถ้าไม่มี wonum ใช้ location + pm_date
    return {"location": doc["location"], "pm_date": doc.get("pm_date")}


async def _upsert_open(items: list[dict], inbound: dict | None = None) -> dict:
    coll = _open_coll()
    try:
        await coll.create_index("wonum", sparse=True)
        await coll.create_index([("location", 1), ("pm_date", -1)])
        await coll.create_index([("station_id", 1), ("status", 1)])
    except Exception:
        pass

    inserted = updated = skipped = 0
    for raw in items:
        doc = _normalize_open(raw)
        if not doc:
            skipped += 1
            continue
        # เก็บของดิบที่ Maximo ยิงมา + สิ่งที่เราตอบกลับ ไว้ดูย้อนหลังได้
        # (ที่ผ่านมามีแต่ log ฝั่ง server ซึ่งหมุนทิ้งแล้วตามไม่ได้)
        set_doc = dict(doc)
        if inbound is not None:
            set_doc["maximo_inbound"] = {**inbound, "item": raw}

        res = await coll.update_one(
            _open_dedup_key(doc),
            {
                "$set": set_doc,
                # selected_equipment เป็นค่าที่ผู้ใช้เลือกฝั่ง iMPS — ตั้งค่าเริ่มต้น
                # เฉพาะตอน insert เท่านั้น เพื่อไม่ให้ Maximo ยิงซ้ำมาล้างของที่เลือกไว้
                "$setOnInsert": {
                    "receivedAt": datetime.now(timezone.utc),
                    "selected_equipment": [],
                },
            },
            upsert=True,
        )
        if res.upserted_id:
            inserted += 1
        elif res.modified_count:
            updated += 1

    return {"inserted": inserted, "updated": updated, "skipped": skipped}


# header ที่รับ shared secret ได้ — Maximo/IESB บาง integration ตั้ง custom header
# ไม่ได้ เลยรับ apikey / Authorization: Bearer ให้ด้วย (ค่าเดียวกัน ไม่ได้ลดความปลอดภัย)
_TOKEN_HEADERS = ("x-maximo-token", "apikey", "x-api-key", "authorization")


def _extract_token(request: Request) -> tuple[str, list[str]]:
    """คืน (token ที่เจอ, ชื่อ header ที่ client ส่งมาจริง) — ไว้ log ตอน auth ไม่ผ่าน"""
    seen: list[str] = []
    token = ""
    for name in _TOKEN_HEADERS:
        val = (request.headers.get(name) or "").strip()
        if not val:
            continue
        seen.append(name)
        if name == "authorization":
            val = re.sub(r"^Bearer\s+", "", val, flags=re.IGNORECASE).strip()
        if not token:
            token = val
    return token, seen


@router.post("/maximo/pm/open")
@router.post("/maximo/pm/open/")   # กัน client ที่เติม / ท้าย URL แล้วไม่ตาม 307 redirect
async def maximo_pm_open(
    request: Request,
    verbose: bool = Query(False, description="ตอบรายละเอียด inserted/updated/warnings ด้วย (ใช้ตอนดีบัก)"),
):
    """
    รับใบงาน PM ที่ Maximo เปิด (push/webhook — IN06)

    ยิงได้ทั้งใบเดียว (location = ระดับสถานี):
        {
          "location": "PTG0001-EV",
          "pm_date": "2026-07-22",
          "wonum": "WO26070001",
          "status": "APPR",
          "company": "PTG"
        }
    เป็น batch: { "workorders": [ {…}, {…} ] } หรือ array ตรง ๆ [ {…}, {…} ]

    ตั้งใจรับแบบยืดหยุ่น — ชื่อฟิลด์ไม่สนตัวพิมพ์เล็ก/ใหญ่, รับชื่อพ้อง
    (targstartdate/schedstart → pm_date, workorderid → wonum ฯลฯ), field เดียว
    ที่ขาดไม่ได้คือ location ส่วน pm_date/wonum/status/company ขาดได้แต่จะเตือนกลับไป
    เพื่อไม่ให้ integration ล้มทั้งใบเพราะฟิลด์ประกอบตัวเดียว

    ป้องกันด้วย shared secret (env MAXIMO_WEBHOOK_SECRET) ส่งมาทาง header
    X-Maximo-Token / apikey / X-API-Key / Authorization: Bearer <secret>
    """
    ctype = request.headers.get("content-type") or "-"
    body_bytes = await request.body()

    if not MAXIMO_WEBHOOK_SECRET:
        log.error("  ❌ IN06 rejected: MAXIMO_WEBHOOK_SECRET ไม่ได้ตั้งค่าบน server นี้")
        raise HTTPException(
            status_code=503,
            detail="MAXIMO_WEBHOOK_SECRET is not configured on this server",
        )

    token, seen_headers = _extract_token(request)
    if token != MAXIMO_WEBHOOK_SECRET:
        log.warning(
            "  🔒 IN06 auth failed — token headers ที่ได้รับ=%s (ต้องส่ง X-Maximo-Token), "
            "content-type=%r, %d bytes",
            seen_headers or "ไม่มีเลย", ctype, len(body_bytes),
        )
        raise HTTPException(
            status_code=401,
            detail="invalid or missing shared secret — ส่งมาทาง header X-Maximo-Token",
        )

    # parse เอง ไม่ผ่าน pydantic body model: Maximo จะได้ไม่โดน 422 ที่อ่านไม่รู้เรื่อง
    # และ log เห็น body จริงทุกครั้งแม้ payload ผิดทรง (422 ของ FastAPI ไม่เข้ามาถึงตรงนี้)
    try:
        payload = json.loads(body_bytes or b"")
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        log.warning(
            "  ❌ IN06 body ไม่ใช่ JSON: %s | content-type=%r | body=%r",
            e, ctype, body_bytes[:500],
        )
        raise HTTPException(status_code=400, detail=f"body ต้องเป็น JSON: {e}")

    items = _extract_items(payload)
    log.info(
        "  📥 IN06 received: %d item(s) | content-type=%r | body=%s",
        len(items), ctype, (body_bytes[:1000].decode("utf-8", "replace") or "-"),
    )

    if not items:
        raise HTTPException(
            status_code=400,
            detail="ไม่พบใบงานใน body — ส่งเป็น object ใบเดียว, array "
                   'หรือ {"workorders": [...]}',
        )

    no_location = [i for i, it in enumerate(items) if not str(it.get("location") or "").strip()]
    if no_location:
        got = sorted({k for it in items for k in it})
        log.warning("  ❌ IN06 ขาด location ในลำดับ %s | key ที่ได้รับ=%s", no_location, got)
        raise HTTPException(
            status_code=400,
            detail=f"location จำเป็นต้องมี — ขาดในรายการลำดับ {no_location} "
                   f"(key ที่ได้รับ: {', '.join(got) or 'ไม่มี'})",
        )

    # field ที่สเปกระบุ Required=Y แต่ไม่ได้ส่งมา — รับเข้าไปก่อน ไม่ปฏิเสธทั้งใบ
    # (company สเปกเป็น Required=N จึงไม่นับ)
    warnings = [
        f"item[{i}] ไม่ได้ส่ง {f}"
        for i, it in enumerate(items)
        for f in ("pm_date", "wonum", "status")
        if not str(it.get(f) or "").strip()
    ]
    if warnings:
        log.warning("  ⚠️  IN06 field ไม่ครบ: %s", "; ".join(warnings))

    response_body = {"status": "OK"}
    inbound = {
        "at": datetime.now(timezone.utc),
        "content_type": ctype,
        "token_headers": seen_headers or None,
        # body ดิบทั้งก้อน (ตัดที่ 4000 ตัว) — เห็นว่าเขาส่งมาจริง ๆ หน้าตาแบบไหน
        "raw_body": (body_bytes[:4000].decode("utf-8", "replace") or None),
        "received": len(items),
        "warnings": warnings or None,
        "response": response_body,
    }

    stats = await _upsert_open(items, inbound=inbound)
    log.info(f"  ✅ IN06 stored: {stats} ({len(items)} received)")

    # สเปก IN06 กำหนด response ไว้แค่ {"status": "OK"} — ตอบเกินไปกว่านี้ไม่ได้
    # เผื่อฝั่ง EGAT validate schema ตอน UAT. รายละเอียดดูจาก log หรือ ?verbose=1
    if verbose:
        return {"status": "OK", "received": len(items), **stats, "warnings": warnings}
    return {"status": "OK"}


@router.get("/maximo/pm/ping")
@router.post("/maximo/pm/ping")
async def maximo_pm_ping(request: Request):
    """
    ให้ฝั่ง Maximo ทดสอบได้เองว่าติดตรงไหน โดยไม่ต้องยิงใบงานจริงเข้ามา

      404/timeout → ยิงไม่ถึง iMPS (network / nginx / URL ผิด)
      503         → ถึงแล้ว แต่ server ยังไม่ได้ตั้ง MAXIMO_WEBHOOK_SECRET
      401         → ถึงแล้ว แต่ token ผิด/ไม่ได้ส่ง (ดู token_headers_received)
      200         → เชื่อมต่อ + auth ผ่าน เหลือแค่รูป payload
    """
    token, seen_headers = _extract_token(request)
    if not MAXIMO_WEBHOOK_SECRET:
        raise HTTPException(
            status_code=503,
            detail="MAXIMO_WEBHOOK_SECRET is not configured on this server",
        )
    if token != MAXIMO_WEBHOOK_SECRET:
        raise HTTPException(
            status_code=401,
            detail={
                "message": "invalid or missing shared secret",
                "token_headers_received": seen_headers,
                "expected_header": "X-Maximo-Token",
            },
        )
    return {
        "status": "OK",
        "endpoint": "POST /maximo/pm/open",
        "required_fields": ["location"],
        "optional_fields": ["pm_date", "wonum", "status", "company", "description"],
    }


def _serialize_open(doc: dict) -> dict:
    return {
        "location": doc.get("location"),
        "description": doc.get("description"),
        "pm_date": doc.get("pm_date"),
        "wonum": doc.get("wonum"),
        "status": doc.get("status"),
        "company": doc.get("company"),
        "station_id": doc.get("station_id"),
        "sn": doc.get("sn"),
        "origin": doc.get("origin"),
        # อุปกรณ์ที่ผู้ใช้เลือกจะ PM ในฝั่ง iMPS (เลือกได้หลายตัว)
        "selected_equipment": doc.get("selected_equipment") or [],
        "selected_at": (
            doc["selected_at"].isoformat() if isinstance(doc.get("selected_at"), datetime) else None
        ),
        "selected_by": doc.get("selected_by"),
        "assignees": doc.get("assignees") or [],
        # ส่งต่อให้ vendor วางแผนอีกรอบ — แผนของ planner ต้นทางด้านบนไม่ถูกแก้
        "vendor_plans": [
            {
                "vendor": v.get("vendor") or "",
                "status": v.get("status") or "pending",
                "planned_by": v.get("planned_by") or "",
                "planned_at": v.get("planned_at") or "",
                "sched_start": v.get("sched_start") or "",
                "sched_finish": v.get("sched_finish") or "",
                "assignees": v.get("assignees") or [],
                "edited_by": v.get("edited_by") or "",
                "edited_at": v.get("edited_at") or "",
                # อุปกรณ์ที่เป็นงานของ vendor รายนี้ (ผู้ทำ PM ที่ planner เลือก)
                # chargers = SN ของตู้, sections = ส่วนระดับสถานี — ว่างทั้งคู่ = ส่งต่อทั้งใบแบบเดิม
                "chargers": v.get("chargers") or [],
                "sections": v.get("sections") or [],
            }
            for v in (doc.get("vendor_plans") or [])
        ],
        "planned_at": doc.get("planned_at"),
        "planned_by": doc.get("planned_by"),
        # แก้แผนหลังวางแผนครั้งแรก (แก้ได้จนกว่าช่างจะกดเริ่ม PM)
        "plan_edited_at": (
            doc["plan_edited_at"].isoformat() if isinstance(doc.get("plan_edited_at"), datetime)
            else doc.get("plan_edited_at")
        ),
        "plan_edited_by": doc.get("plan_edited_by"),
        "planner_company": doc.get("planner_company") or "",
        "sched_start": doc.get("sched_start"),
        "sched_finish": doc.get("sched_finish"),
        "planning_status": doc.get("planning_status") or "pending",
        "receivedAt": (
            doc["receivedAt"].isoformat() if isinstance(doc.get("receivedAt"), datetime) else None
        ),
    }


def _attach_owner_info(items: list[dict]) -> None:
    """เติม charger_brand / company ให้ใบงาน Maximo (in-place)

    PM Dashboard กรองตาม BRAND กับ COMPANY เหมือน CM Dashboard แต่ใบงานที่ Maximo
    ส่งมาไม่มี 2 field นี้ — หาให้จาก iMPS ทีเดียวทั้งชุด (2 query ไม่ว่าจะกี่ใบ):
      brand   ← ตู้ตาม SN ; ใบระดับสถานีใช้ยี่ห้อสถานีได้เฉพาะตอนทุกตู้ยี่ห้อเดียวกัน
      company ← สถานีเจ้าของใบงาน (ทับค่า company ที่ Maximo ส่งมาไม่ได้ จึงใช้ต่อเมื่อว่าง)
    ล้มเหลว = ปล่อยผ่าน ใบงานยังแสดงได้ แค่ไม่มียี่ห้อ
    """
    station_ids = {str(i.get("station_id") or "").strip() for i in items}
    station_ids.discard("")
    if not station_ids:
        return
    try:
        chargers = list(charger_collection.find(
            {"station_id": {"$in": list(station_ids)}},
            {"_id": 0, "SN": 1, "station_id": 1, "brand": 1},
        ))
        stations = list(station_collection.find(
            {"station_id": {"$in": list(station_ids)}},
            {"_id": 0, "station_id": 1, "station_name": 1, "company": 1},
        ))
    except Exception as e:
        log.warning(f"  ⚠️ หา brand/company ของใบงาน Maximo ไม่สำเร็จ: {e}")
        return

    sn_brand: dict[str, str] = {}
    brands_by_station: dict[str, list[str]] = {}
    for c in chargers:
        brand = str(c.get("brand") or "").strip()
        if not brand:
            continue
        sn = str(c.get("SN") or "").strip()
        if sn:
            sn_brand[sn] = brand
        sid = str(c.get("station_id") or "").strip()
        if sid:
            seen = brands_by_station.setdefault(sid, [])
            if brand not in seen:
                seen.append(brand)
    station_brand = {sid: b[0] for sid, b in brands_by_station.items() if len(b) == 1}
    station_company = {
        str(s.get("station_id") or ""): str(s.get("company") or "") for s in stations
    }
    # ชื่อสถานีที่คนอ่านรู้เรื่อง — ไม่มีใน collection ใบงาน ต้องหยิบจาก iMPS.stations
    station_name = {
        str(s.get("station_id") or ""): str(s.get("station_name") or "") for s in stations
    }

    for i in items:
        sid = str(i.get("station_id") or "").strip()
        i["charger_brand"] = sn_brand.get(str(i.get("sn") or "").strip()) or station_brand.get(sid, "")
        if not str(i.get("company") or "").strip():
            i["company"] = station_company.get(sid, "")
        if station_name.get(sid):
            i["station_name"] = station_name[sid]


@router.get("/maximo/pm/open")
async def list_maximo_pm_open(
    source: Optional[PMSource] = Query(None, description="tab ที่กำลังดูอยู่ใน PM report"),
    identifier: Optional[str] = Query(
        None, description="SN สำหรับ charger, station_id สำหรับ tab อื่น"
    ),
    location: Optional[str] = Query(None, description="กรองตาม Maximo location"),
    station_id: Optional[str] = Query(None, description="กรองตาม station_id ของ iMPS"),
    only_open: bool = Query(True, description="เอาเฉพาะใบงานที่ยังเปิดอยู่"),
    verify: bool = Query(True, description="เช็คกับ Maximo ว่า wonum มีอยู่จริงไหม"),
    # หน้า PM List ดึงรวมทุกสถานีในครั้งเดียว จึงต้องเพดานสูงกว่าหน้า tab เดี่ยว
    limit: int = Query(50, ge=1, le=1000),
    current: UserClaims = Depends(get_current_user),
):
    """
    อ่านใบงาน PM ที่ Maximo เปิดเข้ามาทาง IN06 (protected — ต้อง login)

    กรองได้ 2 แบบ:
      - source + identifier — ใช้จากหน้า PM report แต่ละ tab (charger ส่ง SN มา
        ระบบจะ map กลับเป็นสถานีให้เอง เพราะใบงาน IN06 เป็นระดับสถานี)
      - location / station_id — กรองตรง ๆ
    ไม่ส่งอะไรมาเลย = เอาทุกใบ
    """
    and_clauses: list[dict[str, Any]] = []

    if source and (identifier or "").strip():
        sid, station_location = _station_scope(source, identifier.strip())
        if not (sid or station_location):
            # อุปกรณ์/สถานีนี้ยังผูกกับ Maximo ไม่ได้ — ไม่มีใบงานให้แสดง
            return {"items": [], "total": 0}
        # station_id ของ WO มาจาก reverse lookup ตอนรับเข้า ซึ่งจะว่างถ้าสถานี
        # ยังไม่ได้ตั้ง maximo_location → เทียบ location ควบไว้ด้วยกันเหนียว
        scope = [{"station_id": sid}] if sid else []
        if station_location:
            # เทียบทั้ง "PTG0001" และ "PTG0001-EV" — Maximo กับ iMPS เขียนคนละแบบได้
            scope.append({"location": {"$in": _location_variants(station_location)}})
        and_clauses.append({"$or": scope})

    if location:
        and_clauses.append({"location": location.strip()})
    if station_id:
        and_clauses.append({"station_id": station_id.strip()})
    if only_open:
        # ใบงานที่ Maximo ไม่ได้ส่ง status มา ถือว่ายังเปิดอยู่
        and_clauses.append({
            "$or": [
                {"status": {"$in": list(OPEN_WO_STATUSES)}},
                {"status": {"$in": [None, ""]}},
            ]
        })

    q: dict[str, Any] = {"$and": and_clauses} if and_clauses else {}

    cursor = _open_coll().find(q).sort([("pm_date", -1), ("_id", -1)]).limit(limit)
    docs = await cursor.to_list(length=limit)

    # ── กรองตามอุปกรณ์ที่ planner เลือกไว้ ──
    # ใบงาน Maximo เป็นระดับสถานี ถ้าไม่กรอง ใบเดียวจะโผล่ครบทุก tab และทุกตู้
    # ในสถานี ทั้งที่ planner เลือก PM แค่บางตัว
    #   ยังไม่ได้วางแผน (selected_equipment ว่าง) → โชว์ทุก tab ให้ planner หาเจอ
    #   วางแผนแล้ว → โชว์เฉพาะ tab/ตู้ ที่ถูกเลือก
    if source:
        want = _norm_equip_type(source)
        ident = (identifier or "").strip()

        def _picked(d: dict) -> bool:
            items = d.get("selected_equipment") or []
            if not items:
                return True
            for e in items:
                if _norm_equip_type(e.get("type")) != want:
                    continue
                if want != "charger":
                    return True
                # charger เจาะจงถึงตู้ — ไม่ระบุ identifier ก็ถือว่าเอาหมด
                if not ident or str(e.get("sn") or "").strip() == ident:
                    return True
            return False

        docs = [d for d in docs if _picked(d)]

    # ใบที่รับเข้ามาตอนสถานียังไม่ได้ตั้ง maximo_location จะมี station_id ว่างค้างอยู่
    # ลองหาใหม่ตอนอ่าน แล้วเขียนกลับให้ถาวร (ไม่ต้องรอ Maximo ยิงซ้ำ)
    for d in docs:
        if not (d.get("station_id") or "").strip():
            sid = _station_id_of_wo(d)
            if sid:
                d["station_id"] = sid
                try:
                    await _open_coll().update_one({"_id": d["_id"]}, {"$set": {"station_id": sid}})
                except Exception as e:
                    log.warning(f"  ⚠️ backfill station_id ของ {d.get('wonum')} ไม่สำเร็จ: {e}")

    items = [_serialize_open(d) for d in docs]
    _attach_owner_info(items)

    # เช็คว่าใบไหนมีอยู่จริงใน Maximo — ถามทีเดียวทั้งชุด
    # ล้มก็ปล่อยผ่าน (คืน exists_in_maximo = None = ยังไม่รู้) ไม่บล็อกการแสดงผล
    if verify:
        try:
            # ใบที่เปิดเองใน iMPS ไม่เคยมีใน Maximo โดยตั้งใจ — ไม่ต้องถามและไม่ต้องเตือน
            found = await maximo_svc.workorders_exist(
                [i.get("wonum") for i in items if not _is_manual_wo(i)]
            )
            for i in items:
                wn = str(i.get("wonum") or "").strip()
                hit = found.get(wn)
                i["exists_in_maximo"] = None if _is_manual_wo(i) else (bool(hit) if wn else None)
                if hit:
                    i["maximo_status"] = hit.get("status")
                    i["maximo_worktype"] = hit.get("worktype")
        except Exception as e:
            log.warning(f"  ⚠️ เช็ค wonum กับ Maximo ไม่สำเร็จ: {e}")
            for i in items:
                i["exists_in_maximo"] = None

    return {"items": items, "total": len(items)}


# ══════════════════════════════════════════════════════════════════
# 5) Select equipment — ผู้ใช้เลือกอุปกรณ์ที่จะ PM ในฝั่ง iMPS
#    Maximo ส่งใบงานมาระดับสถานี → ผู้ใช้เลือกได้หลายอุปกรณ์ต่อ 1 ใบงาน
# ══════════════════════════════════════════════════════════════════
def _norm_equip_type(value: Any) -> str:
    s = str(value or "").strip().lower()
    return EQUIP_ALIASES.get(s, s)


class EquipmentItem(BaseModel):
    """1 อุปกรณ์ที่เลือกจะ PM — charger ระบุ sn ด้วย, อุปกรณ์ระดับสถานีใส่แค่ type"""
    type: str                          # charger / mdb / ccb / cbbox / station
    sn: Optional[str] = None           # สำหรับ charger (ระบุตู้)
    location: Optional[str] = None     # maximo location ของอุปกรณ์ (ถ้ามี)
    label: Optional[str] = None        # ชื่อไว้โชว์
    # ผู้ทำ PM อุปกรณ์ชิ้นนี้ในใบงานนี้ (ทุกชนิด รวม Station/MDB/CCB/CB_BOX) — ชื่อ vendor /
    # outsource จากหน้า Company; ว่าง = ทีมของ planner เอง (เช่น EGAT)
    # planner เลือกทุกใบงาน ไม่ได้อิงช่อง Vendor ของตู้
    by: Optional[str] = None


class SelectEquipmentIn(BaseModel):
    # None = ไม่แตะรายการอุปกรณ์เดิม (หน้าวางแผน PM ไม่ได้ให้เลือกอุปกรณ์แล้ว)
    # []   = ล้างรายการทิ้ง
    equipment: Optional[list[EquipmentItem]] = None
    planned_at: Optional[str] = None
    sched_start: Optional[str] = None
    sched_finish: Optional[str] = None
    assignees: list[str] = Field(default_factory=list)


async def _find_open_wo(wonum: str) -> dict | None:
    return await _open_coll().find_one({"wonum": wonum})


# ══════════════════════════════════════════════════════════════════
# ส่งต่อให้ vendor วางแผนอีกรอบ
#   planner (เช่น EGAT) เลือก vendor (เช่น EDS) เป็น "ผู้ทำ PM" ของอุปกรณ์ และ vendor นั้นมี
#   planner ของตัวเองในระบบ → ใบงานไปขึ้นที่หน้า PM List ของ vendor ให้ planner ของ
#   vendor วางแผนอีกรอบ (เลือกช่างของตัวเอง + กำหนดการ) แผนของ planner ต้นทางยังอยู่ครบ
#   ส่งต่อได้ทางเดียวคือผ่านผู้ทำ PM ของอุปกรณ์ — ติ๊ก vendor ในลิสต์ผู้รับผิดชอบไม่ได้แล้ว
#   (เดิมติ๊กแล้วได้ใบส่งต่อแบบไม่ผูกอุปกรณ์ = ไม่ได้ล็อกส่วนไหนเลย ใครก็กรอกได้ทั้งใบ)
#   จ้าง vendor ทำทั้งสถานี = เลือก vendor เป็นผู้ทำ PM ทุกชิ้น (รวม Station/MDB/CCB/CB_BOX)
#   เก็บที่ใบงาน: vendor_plans = [{vendor, status: pending|planned, planned_by, planned_at,
#   sched_start, sched_finish, assignees}]
# ══════════════════════════════════════════════════════════════════

def _company_of(current: UserClaims) -> str:
    """company ของคนที่ login — อ่านสดจาก DB (JWT อาจเก่ากว่า profile ที่เพิ่งแก้)"""
    from config import users_collection

    company = str(current.company or "").strip()
    if current.user_id:
        try:
            me = users_collection.find_one({"_id": ObjectId(current.user_id)}, {"company": 1})
            company = str((me or {}).get("company") or company).strip()
        except Exception:
            pass
    return company


def _vendor_companies_with_planner(names: list[str], exclude_company: str) -> list[str]:
    """
    ชื่อผู้รับผิดชอบที่เป็นบริษัท (vendor) ซึ่งมีบัญชี planner ของตัวเองในระบบ
    คืนตามตัวสะกดที่ planner ต้นทางเลือกไว้ — บริษัทของคนวางแผนเองไม่นับ
    """
    from config import users_collection

    wanted = {n.strip().lower(): n.strip() for n in names if str(n or "").strip()}
    wanted.pop(exclude_company.strip().lower(), None)
    if not wanted:
        return []
    pattern = "^(" + "|".join(re.escape(k) for k in wanted) + ")$"
    try:
        companies = users_collection.distinct(
            "company", {"role": "planner", "company": {"$regex": pattern, "$options": "i"}}
        )
    except Exception as e:
        log.warning(f"  ⚠️ หา planner ของ vendor {list(wanted.values())} ไม่สำเร็จ: {e}")
        return []
    found = {str(c or "").strip().lower() for c in companies}
    return [orig for key, orig in wanted.items() if key in found]


def _merge_vendor_plans(existing: list[dict] | None, vendors: list[str]) -> list[dict]:
    """
    ใบส่งต่อชุดใหม่ตาม vendor ที่เลือกรอบนี้ — vendor ที่วางแผนไปแล้วเก็บแผนเดิมไว้
    vendor ที่ไม่ได้เลือกแล้วตัดทิ้ง (ยังไม่ได้วางแผนเท่านั้น — วางแผนแล้วคงไว้เป็นประวัติ)
    """
    by_key = {str(v.get("vendor") or "").strip().lower(): v for v in (existing or [])}
    out: list[dict] = []
    for name in vendors:
        key = name.strip().lower()
        out.append(by_key.pop(key, None) or {"vendor": name.strip(), "status": "pending"})
    out.extend(v for v in by_key.values() if v.get("status") == "planned")
    return out


# ══════════════════════════════════════════════════════════════════
# แก้แผนหลังวางแผนแล้ว
#   planner ต้นทาง (เช่น EGAT) แก้แผนได้ตราบใดที่ช่างยังไม่กดเริ่ม PM
#     และ vendor ที่ส่งต่อไป (เช่น EDS) ยังไม่ได้วางแผนของตัวเอง
#     (vendor วางแผนตามแผนต้นทางไปแล้ว — แก้ทีหลังจะทำให้แผนของ vendor ไม่ตรง)
#   planner ของ vendor แก้แผนของบริษัทตัวเองได้ตราบใดที่ช่างยังไม่กดเริ่ม PM
#   "เริ่ม PM" = มีใบ PM สถานีของใบงานนี้แล้ว (หรือเอกสาร PM ใบเดี่ยวรุ่นเก่าที่ผูก wonum)
# ══════════════════════════════════════════════════════════════════
PLAN_BYPASS_ROLES = {"admin", "owner"}

# ล็อกหน้าวางแผน — planner สองคนแก้แผนใบเดียวกันพร้อมกันไม่ได้ (routers/pm_lock.py)
PLAN_LOCK_FIELD = "plan_lock"


@router.post("/maximo/pm/{wonum}/plan-lock")
async def lock_pm_plan(wonum: str, current: UserClaims = Depends(get_current_user)):
    """ขอ/ต่ออายุสิทธิ์แก้แผน — หน้าวางแผนยิงตอนอยู่ในโหมดกรอก แล้วต่ออายุทุก 30 วิ"""
    from routers import pm_lock
    if (current.role or "").strip().lower() not in PM_PLANNING_ROLES:
        raise HTTPException(status_code=403, detail="เฉพาะ planner ที่วางแผนใบงานได้")
    wo = await _find_open_wo((wonum or "").strip())
    if not wo:
        raise HTTPException(status_code=404, detail=f"ไม่พบใบงาน wonum={wonum}")
    return await pm_lock.acquire(_open_coll(), {"_id": wo["_id"]}, PLAN_LOCK_FIELD, current)


@router.delete("/maximo/pm/{wonum}/plan-lock")
async def unlock_pm_plan(wonum: str, current: UserClaims = Depends(get_current_user)):
    """ปล่อยสิทธิ์แก้แผน — ไม่ยิงก็แค่รอหมดอายุเอง"""
    from routers import pm_lock
    wo = await _find_open_wo((wonum or "").strip())
    if not wo:
        return {"ok": True}
    return await pm_lock.release(_open_coll(), {"_id": wo["_id"]}, PLAN_LOCK_FIELD, current)


async def _wo_started(wo: dict) -> bool:
    """ช่างกดเริ่ม PM ใบงานนี้แล้วหรือยัง"""
    wonum = str(wo.get("wonum") or "").strip()
    if not wonum:
        return False
    station_id = _station_id_of_wo(wo)
    if station_id:
        try:
            from routers.pm_helpers import get_stationpmjob_collection_for
            if await get_stationpmjob_collection_for(station_id).find_one({"wonum": wonum}, {"_id": 1}):
                return True
        except Exception as e:
            log.warning(f"  ⚠️ เช็คใบ PM ของ {wonum} ไม่สำเร็จ: {e}")
    try:
        return bool(await pm_flow.wo_reports(wonum))
    except Exception as e:
        log.warning(f"  ⚠️ เช็คเอกสาร PM ของ {wonum} ไม่สำเร็จ: {e}")
        return False


def _planned_vendors(wo: dict) -> list[str]:
    return [
        str(v.get("vendor") or "").strip()
        for v in (wo.get("vendor_plans") or [])
        if str(v.get("status") or "").strip().lower() == "planned"
    ]


async def _plan_edit_state(wo: dict, current: UserClaims, *, started: Optional[bool] = None) -> dict:
    """
    ใครแก้แผนอะไรได้บ้างตอนนี้ — หน้าวางแผนใช้ตัดสินว่าจะโชว์ปุ่ม "แก้ไขแผน" หรือไม่
    และ endpoint บันทึกแผนใช้ตัวเดียวกันตรวจซ้ำ (reason = เหตุผลที่แก้ไม่ได้ ไว้โชว์ผู้ใช้)
    """
    role = (current.role or "").strip().lower()
    company = _company_of(current)
    if started is None:
        started = await _wo_started(wo)
    planned = str(wo.get("planning_status") or "").strip().lower() == "planned"
    planner_company = str(wo.get("planner_company") or "").strip()
    vendors_done = _planned_vendors(wo)

    plan_reason = ""
    if role not in PM_PLANNING_ROLES:
        plan_reason = "เฉพาะ planner ที่วางแผนใบงานได้"
    elif planned and started:
        plan_reason = "ช่างกดเริ่ม PM แล้ว แก้แผนไม่ได้"
    elif planned and vendors_done:
        plan_reason = f"{', '.join(vendors_done)} วางแผนตามแผนนี้ไปแล้ว แก้แผนไม่ได้"
    elif (planned and planner_company and role not in PLAN_BYPASS_ROLES
          and company.strip().lower() != planner_company.lower()):
        plan_reason = f"แผนนี้เป็นของ {planner_company} — แก้ได้เฉพาะ planner ของบริษัทนั้น"

    mine = next(
        (v for v in (wo.get("vendor_plans") or [])
         if company and str(v.get("vendor") or "").strip().lower() == company.strip().lower()),
        None,
    )
    vendor_reason = ""
    if role not in PM_PLANNING_ROLES:
        vendor_reason = "เฉพาะ planner ที่วางแผนใบงานได้"
    elif not mine or str(mine.get("status") or "").strip().lower() != "planned":
        vendor_reason = "ยังไม่ได้วางแผนของบริษัทคุณ"
    elif started:
        vendor_reason = "ช่างกดเริ่ม PM แล้ว แก้แผนไม่ได้"

    return {
        "started": started,
        "planned": planned,
        # planner ต้นทางแก้แผนที่บันทึกแล้วได้ไหม (ยังไม่วางแผน = วางแผนครั้งแรก ไม่ใช่การแก้)
        "can_edit_plan": planned and not plan_reason,
        "plan_reason": plan_reason,
        # planner ของ vendor แก้แผนของบริษัทตัวเองที่บันทึกแล้วได้ไหม
        "can_edit_vendor_plan": not vendor_reason,
        "vendor_plan_reason": vendor_reason,
    }


async def _validate_equipment_by(items: list[dict], current: UserClaims) -> None:
    """ผู้ทำ PM ของอุปกรณ์ต้องเป็น vendor / outsource ของบริษัทคนวางแผน (ชุดเดียวกับ /companies/pm-options)"""
    names = {str(i.get("by") or "").strip() for i in items if str(i.get("by") or "").strip()}
    if not names:
        return
    from routers.company import pm_assignee_options

    options = await pm_assignee_options(current)
    allowed = {n.lower() for group in ("vendors", "outsources") for n in options.get(group) or []}
    outside = sorted(n for n in names if n.lower() not in allowed)
    if outside:
        raise HTTPException(
            status_code=400,
            detail=f"ผู้ทำ PM ต้องเป็น vendor / outsource ของบริษัทคุณ (ตั้งที่หน้า Company): {', '.join(outside)}",
        )


def _with_equipment_parties(assignees: list[str], items: list[dict]) -> list[str]:
    """เติมผู้ทำ PM ของอุปกรณ์แต่ละชิ้นเข้าไปในผู้รับผิดชอบของใบงาน (ไม่ซ้ำ ไม่สนตัวพิมพ์)"""
    out = list(assignees)
    seen = {a.lower() for a in out}
    for i in items:
        by = str(i.get("by") or "").strip()
        if by and by.lower() not in seen:
            out.append(by)
            seen.add(by.lower())
    return out


async def _plan_assignees(raw: list[str], items: list[dict], current: UserClaims) -> list[str]:
    """
    ผู้รับผิดชอบของแผนต้นทาง = ช่าง / outsource ที่ planner ติ๊กมา + ผู้ทำ PM ของอุปกรณ์แต่ละชิ้น

    vendor เลือกได้ทางเดียวคือ "ผู้ทำ PM" ของอุปกรณ์ ชื่อ vendor ที่ติ๊กมาในลิสต์ (client รุ่นเก่า /
    ค้างจากแผนเดิม) ถูกตัดทิ้ง — ไม่งั้นเปลี่ยนอุปกรณ์กลับเป็นทีมเราแล้ว vendor ยังเป็นผู้รับผิดชอบ
    ทั้งใบอยู่ ถ้ายังมีอุปกรณ์ให้รายนั้นทำ _with_equipment_parties เติมกลับให้เอง
    ชื่อที่เป็นทั้ง vendor และ technician / outsource ไม่ตัด (ฝั่งหน้าเว็บ: vendorOnlyNames)
    """
    from routers.company import pm_assignee_options

    if not raw:
        return _with_equipment_parties([], items)
    options = await pm_assignee_options(current)
    keep = {n.lower() for group in ("technicians", "outsources") for n in options.get(group) or []}
    vendor_only = {n.lower() for n in options.get("vendors") or []} - keep
    picked = [a for a in raw if a.lower() not in vendor_only]
    return _with_equipment_parties(picked, items)


def _build_vendor_plans(
    existing: list[dict] | None,
    planner_company: str,
    station_id: str,
    items: list[dict],
) -> list[dict]:
    """
    ใบส่งต่อ vendor ของแผนรอบนี้ + อุปกรณ์ที่ส่งต่อให้แต่ละราย
    (field chargers = SN ของตู้, sections = ส่วนระดับสถานี เช่น ["station", "mdb"])

    vendor ที่ได้ใบส่งต่อ = ผู้ทำ PM ที่ planner เลือกให้อุปกรณ์แต่ละชิ้น (item.by) เท่านั้น
    — เฉพาะรายที่มี planner ของตัวเองในระบบ ใบส่งต่อจึงผูกอุปกรณ์เสมอ
    (ผู้รับผิดชอบที่ติ๊กในลิสต์ไม่ทำให้เกิดใบส่งต่อ — ไม่งั้นได้ใบไม่ผูกอุปกรณ์ = ไม่ล็อกส่วนไหนเลย)
    (outsource ปกติไม่มี planner จึงไม่ได้ใบส่งต่อ — planner ต้นทางมอบหมายตรง)
    (ไม่มี planner = ไม่มีคนรับไปวางแผนต่อ ทีมต้นทางทำเองทั้งหมดเหมือนเดิม)
    ใบส่งต่อเดิมที่ vendor วางแผนไปแล้วเก็บไว้เป็นประวัติพร้อมอุปกรณ์เดิม (_merge_vendor_plans)
    อุปกรณ์ของ vendor รายนั้นจะกลายเป็นงานของ vendor — ดูกติกาที่ routers/pm_scope.py
    """
    from routers import pm_scope

    by_vendor = pm_scope.items_by_party(items or [])
    names = [name for name, _sns, _secs in by_vendor.values()]
    vendors = _vendor_companies_with_planner(names, planner_company)
    plans = _merge_vendor_plans(existing, vendors)
    for p in plans:
        mine = by_vendor.get(str(p.get("vendor") or "").strip().lower())
        if mine:
            p["chargers"] = list(mine[1])
            p["sections"] = list(mine[2])
    return plans


def _pending_vendors(doc: dict) -> list[str]:
    """
    vendor ที่ถูกส่งต่อแต่ยังไม่ได้วางแผน = ยังไม่ได้ส่งทีม/ช่างเข้าหน้างาน
    ตราบใดที่ยังเหลือ ใบงานยังไม่ถือว่าเริ่มงานจริง (ยังไม่ยิง INPRG เข้า Maximo)
    """
    return [
        str(v.get("vendor") or "").strip()
        for v in (doc.get("vendor_plans") or [])
        if str(v.get("status") or "").strip().lower() != "planned"
    ]


def _all_assignees(doc: dict) -> list[str]:
    """ผู้รับผิดชอบทั้งหมดของใบงาน = ของ planner ต้นทาง + ช่างที่ vendor มอบหมายเพิ่ม (ไม่ซ้ำ)"""
    out: list[str] = []
    names = list(doc.get("assignees") or [])
    for v in doc.get("vendor_plans") or []:
        names.extend(v.get("assignees") or [])
    for n in names:
        s = str(n or "").strip()
        if s and s not in out:
            out.append(s)
    return out


def _station_id_of_wo(wo: dict) -> str:
    """
    station_id ของใบงาน — ถ้าตอนรับเข้า reverse lookup ไม่ติด (สถานี/ตู้ยังไม่ได้ตั้ง
    maximo_location ตอนนั้น) ให้ลองหาจาก location ซ้ำอีกรอบ ไม่งั้นรายการอุปกรณ์
    จะว่างเปล่าทั้งที่สถานีมีตู้อยู่
    """
    sid = (wo.get("station_id") or "").strip()
    if sid:
        return sid
    return (_resolve_owner(wo.get("location") or "") or {}).get("station_id") or ""


# ══════════════════════════════════════════════════════════════════
# สถานะการ sync ของเอกสาร PM + ยิงซ้ำ (คู่กับ /cm-maximo/{id}/sync ของฝั่ง CM)
# ══════════════════════════════════════════════════════════════════
PM_SYNC_ROLES: set[str] = {"admin", "owner", "planner"}


def _serialize_sync(doc: dict) -> dict:
    """maximo_sync ของเอกสาร → JSON (datetime → ISO)"""
    out: dict[str, Any] = {}
    for key, entry in (doc.get("maximo_sync") or {}).items():
        if not isinstance(entry, dict):
            continue
        at = entry.get("at")
        out[key] = {
            **{k: v for k, v in entry.items() if k != "at"},
            "at": at.isoformat() if isinstance(at, datetime) else None,
        }
    return out


async def _load_pm_report(report_id: str, sn: str):
    """เอกสาร PM ของ charger + collection ของ SN นั้น"""
    from routers.pm_helpers import get_pmreport_collection_for

    coll = get_pmreport_collection_for(sn)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")
    doc = await coll.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")
    return coll, oid, doc


@router.get("/pm-maximo/wo/{wonum}/sync")
async def pm_wo_sync_status(
    wonum: str,
    current: UserClaims = Depends(get_current_user),
):
    """
    ใบงาน PM 1 ใบ: Maximo ส่งอะไรเข้ามา (IN06) และเรายิงอะไรกลับไปแล้วบ้าง

    ใช้ได้ตั้งแต่ยังไม่มีเอกสาร PM (ด่านวางแผนของ planner) ต่างจาก
    /pm-maximo/{report_id}/sync ที่ต้องมีเอกสารก่อน
    """
    wonum = (wonum or "").strip()
    wo = await _find_open_wo(wonum)
    if not wo:
        raise HTTPException(status_code=404, detail=f"ไม่พบใบงาน wonum={wonum}")

    inbound = dict(wo.get("maximo_inbound") or {})
    if isinstance(inbound.get("at"), datetime):
        inbound["at"] = inbound["at"].isoformat()

    # None = เช็คกับ Maximo ไม่ได้ (ไม่ใช่ "ไม่มี")
    # ใบงานเปิดเองใน iMPS ไม่มีใน Maximo อยู่แล้วโดยตั้งใจ — ไม่ต้องไปถาม
    exists, in_maximo = None, None
    if not _is_manual_wo(wo):
        try:
            found = await maximo_svc.workorders_exist([wonum])
            exists = wonum in found
            in_maximo = found.get(wonum) or None
        except Exception as e:
            log.warning(f"  ⚠️ เช็ค wonum {wonum} กับ Maximo ไม่สำเร็จ: {e}")

    # IN03/IN09/IN02(CLOSED) จดไว้บนเอกสาร PM ไม่ใช่บนใบงาน — ใบงานมีแต่ IN02(INPRG)
    # ถ้าอ่านแค่ใบงาน หน้านี้จะค้างอยู่ที่ INPRG ตลอดกาลทั้งที่ปิดงานไปแล้ว
    reports = await pm_flow.wo_reports(wonum)

    merged = _serialize_sync(wo)
    for rep in reports:
        rep["interfaces"] = _serialize_sync(rep)
        rep.pop("maximo_sync", None)
        # เอกสารเป็นตัวยิงจริง ทับของใบงานได้เลยเมื่อชนกัน (IN02 CLOSED มาทีหลัง INPRG)
        merged.update(rep["interfaces"])

    # ใบ PM สถานี (รวมทุกส่วนเป็นใบเดียว) ยิงชุดปิดงานจากตัวใบเอง — ผลจดอยู่บนใบ ไม่ใช่บนเอกสารรายส่วน
    station_id = _station_id_of_wo(wo)
    if station_id:
        try:
            from routers.pm_helpers import get_stationpmjob_collection_for
            job = await get_stationpmjob_collection_for(station_id).find_one({"wonum": wonum})
        except Exception:
            job = None
        if job:
            job_sync = _serialize_sync(job)
            reports.append({
                "equipment": "ใบ PM สถานี",
                "type": "station_job",
                "report_id": str(job["_id"]),
                "issue_id": job.get("issue_id") or "",
                "status": job.get("status") or "",
                "interfaces": job_sync,
            })
            merged.update(job_sync)

    return {
        "wonum": wonum,
        "exists_in_maximo": exists,
        "maximo_workorder": in_maximo,
        "location": wo.get("location") or "",
        "station_id": _station_id_of_wo(wo),
        "planning_status": wo.get("planning_status") or "pending",
        # ช่างของ planner ต้นทาง + ช่างที่ vendor (เช่น EDS) ส่งเข้าหน้างาน
        "assignees": _all_assignees(wo),
        "vendor_plans": _serialize_open(wo)["vendor_plans"],
        "pending_vendors": _pending_vendors(wo),
        # ขาเข้า: IN06 ที่ Maximo ยิงมา + response ที่เราตอบกลับ
        "inbound": inbound or None,
        # ขาออก: รวมของใบงาน (IN02 INPRG ตอน assign) กับของเอกสารทุกใบในใบงานนี้
        "interfaces": merged,
        # แยกรายเอกสารไว้ด้วย ใบงานเดียวมีได้หลายอุปกรณ์
        "reports": reports,
        "progress": await pm_flow.wo_completion(wonum),
    }


@router.get("/pm-maximo/{report_id}/sync")
async def pm_sync_status(
    report_id: str,
    sn: str = Query(..., description="SN ของตู้ (เอกสาร PM charger เก็บแยกตาม SN)"),
    current: UserClaims = Depends(get_current_user),
):
    """
    ดูว่าเอกสาร PM ใบนี้ยิงอะไรเข้า Maximo ไปแล้วบ้าง

    รวม 2 ที่ไว้ให้ในครั้งเดียว:
      report    — IN03 / IN09 / IN02 (CLOSED) ที่จดไว้บนเอกสาร PM
      workorder — IN02 (INPRG) ที่จดไว้บนใบงานใน maximo_pm_open ตอน planner assign
    """
    _, _, doc = await _load_pm_report(report_id, sn.strip())
    wonum = (doc.get("wonum") or "").strip()

    wo_sync: dict = {}
    if wonum:
        wo = await _open_coll().find_one({"wonum": wonum}) or {}
        wo_sync = _serialize_sync(wo)

    return {
        "issue_id": doc.get("issue_id") or "",
        "doc_name": doc.get("doc_name") or "",
        "status": doc.get("status") or "",
        "wonum": wonum,
        "sn": sn,
        "station_id": doc.get("station_id") or "",
        "interfaces": _serialize_sync(doc),
        "workorder_interfaces": wo_sync,
    }


@router.post("/pm-maximo/{report_id}/sync")
async def pm_sync_retry(
    report_id: str,
    sn: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """ยิงชุดปิดงาน (IN03 → IN09 → IN02 CLOSED) ใหม่ — ใช้เมื่อรอบก่อนล้ม"""
    role = (current.role or "").strip().lower()
    if role not in PM_SYNC_ROLES and not getattr(current, "is_super_admin", False):
        raise HTTPException(status_code=403, detail="Only planner, owner or admin can re-sync")

    coll, oid, doc = await _load_pm_report(report_id, sn.strip())

    from services import pm_maximo_out
    result = await pm_maximo_out.safe_sync_closed(
        coll, oid, doc, memo=f"manual re-sync by {current.username}"
    )
    fresh = await coll.find_one({"_id": oid}) or {}
    return {"ok": True, "result": result, "interfaces": _serialize_sync(fresh)}


def _station_equipment_choices(station_id: str) -> tuple[list[dict], list[dict]]:
    """
    (ตู้ชาร์จ, อุปกรณ์ระดับสถานี) ที่เลือก PM ได้ในสถานีหนึ่ง

    ใช้ร่วมกันระหว่างใบงานที่ Maximo เปิดมา (มี wonum แล้ว) กับฟอร์มเพิ่มใบงานเอง
    ในหน้า PM List ที่ยังไม่มี wonum — เลือกสถานีแล้วต้องได้รายการชุดเดียวกัน
    """
    chargers: list[dict] = []
    if station_id:
        # charger_collection เป็น pymongo (sync) — วนตรง ๆ ได้
        cursor = charger_collection.find(
            {"station_id": station_id},
            {"_id": 0, "SN": 1, "chargeBoxID": 1, "name": 1, "charger_name": 1,
             "maximo_location": 1, "chargerNo": 1, "vendor": 1},
        ).sort([("chargerNo", 1), ("SN", 1)])
        for idx, c in enumerate(cursor, start=1):
            # ตู้ที่ไม่มี SN เลือกไปก็บันทึกไม่ผ่าน (type charger บังคับ sn) — ไม่ต้องเสนอ
            if not str(c.get("SN") or "").strip() or c.get("SN") == "-":
                continue
            # ป้ายชื่อใช้หมายเลขตู้ ("Charger 1", "Charger 2") ไม่ใช่ location ของ Maximo
            # ซึ่งเป็นรหัสที่ผู้ใช้อ่านแล้วไม่รู้ว่าเป็นตู้ไหน — ไม่มี chargerNo ก็ไล่ตามลำดับ
            charger_no = c.get("chargerNo") or idx
            chargers.append({
                "type": "charger",
                "sn": c.get("SN"),
                "label": f"Charger {charger_no}",
                "location": c.get("maximo_location"),
                # vendor ที่ดูแลตู้ (ช่อง Vendor ในหน้า EV Stations) — ตู้ที่มี vendor ที่มี planner
                # จะถูกส่งต่อเป็นงานของ vendor นั้นตอนบันทึกแผน (routers/pm_scope.py)
                "vendor": str(c.get("vendor") or "").strip(),
            })

    fixed = [{"type": t} for t in ("mdb", "ccb", "cbbox", "station")]
    return chargers, fixed


def _build_equipment_items(station_id: str, equipment: list["EquipmentItem"]) -> list[dict]:
    """
    ตรวจ + ทำให้เป็นรูปที่เก็บลง selected_equipment ของใบงาน

    ใช้ทั้งตอนวางแผนใบงานที่ Maximo เปิดมา และตอนเปิดใบงานเองในหน้า PM List
    กติกาเดียวกัน: type ต้องอยู่ใน EQUIP_TYPES, charger ต้องมี sn ของตู้ที่อยู่ในสถานีนั้นจริง
    และห้ามเลือกอุปกรณ์ตัวเดิมซ้ำในใบเดียว — by (ผู้ทำ PM) ตรวจแยกที่ _validate_equipment_by
    """
    items: list[dict] = []
    seen: set[str] = set()
    for e in equipment:
        etype = _norm_equip_type(e.type)
        if etype not in EQUIP_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"ประเภทอุปกรณ์ไม่ถูกต้อง: {e.type} — ต้องเป็น {', '.join(sorted(EQUIP_TYPES))}",
            )
        if etype == "charger" and not (e.sn or "").strip():
            raise HTTPException(
                status_code=400, detail="charger ต้องระบุ sn ของตู้ที่จะ PM"
            )
        key = f"charger:{(e.sn or '').strip()}" if etype == "charger" else etype
        if key in seen:
            raise HTTPException(status_code=400, detail="Duplicate equipment in PM plan")
        seen.add(key)

        item = {"type": etype}
        if etype == "charger":
            if not station_id:
                raise HTTPException(
                    status_code=409,
                    detail="This PM work order is not mapped to an iMPS station",
                )
            sn = (e.sn or "").strip()
            charger = charger_collection.find_one(
                {"station_id": station_id, "SN": sn},
                {"SN": 1, "chargeBoxID": 1, "name": 1, "charger_name": 1, "maximo_location": 1},
            )
            if not charger:
                raise HTTPException(
                    status_code=400,
                    detail=f"Charger SN={sn} is not in this work order station",
                )
            item["sn"] = sn
            item["location"] = (charger.get("maximo_location") or "").strip() or None
            item["label"] = (
                charger.get("name")
                or charger.get("charger_name")
                or charger.get("chargeBoxID")
                or sn
            )
        else:
            if e.location:
                item["location"] = e.location.strip()
            if e.label:
                item["label"] = e.label
        # ผู้ทำ PM ของอุปกรณ์ชิ้นนี้ (ทุกชนิด) — ว่าง = ทีมของ planner เอง
        by = (e.by or "").strip()
        if by:
            item["by"] = by
        items.append(item)
    return items


@router.get("/maximo/pm/{wonum}/equipment-choices")
async def pm_equipment_choices(
    wonum: str,
    current: UserClaims = Depends(get_current_user),
):
    """
    รายการอุปกรณ์ที่เลือก PM ได้ภายใต้สถานีของใบงานนี้
    (ตู้ชาร์จทุกตู้ในสถานี + อุปกรณ์ระดับสถานี mdb/ccb/cbbox/station)
    ให้ frontend เอาไปทำ checkbox เลือกหลายตัว
    """
    wonum = (wonum or "").strip()
    doc = await _find_open_wo(wonum)
    if not doc:
        raise HTTPException(status_code=404, detail=f"ไม่พบใบงาน wonum={wonum}")

    station_id = _station_id_of_wo(doc)
    chargers, fixed = _station_equipment_choices(station_id)

    return {
        "wonum": wonum,
        "station_id": station_id,
        "location": doc.get("location"),
        "chargers": chargers,          # เลือกได้หลายตู้
        "fixed": fixed,                # อุปกรณ์ระดับสถานี
        "selected_equipment": doc.get("selected_equipment") or [],
        # ใครแก้แผนได้ตอนนี้ — หน้าวางแผนใช้โชว์ปุ่ม "แก้ไขแผน"
        "plan_state": await _plan_edit_state(doc, current),
    }


@router.delete("/maximo/pm/{wonum}")
async def delete_pm_wo(
    wonum: str,
    current: UserClaims = Depends(get_current_user),
):
    """
    ลบใบงาน PM ออกจาก iMPS — super admin เท่านั้น
    ใบ PM สถานีที่เปิดจากใบงานนี้ (ถ้ามี) ถูกลบพร้อมเอกสารทุกส่วนด้วย ไม่ให้ค้างเป็นใบกำพร้า
    ใบงานจาก Maximo: ลบได้แค่ฝั่ง iMPS — ถ้า Maximo ยังส่งใบนี้มาตอน sync จะกลับมาอีก
    """
    from routers.pmreport_station_job import (
        assert_super_admin, delete_job_cascade, delete_wo_doc,
    )
    from routers.pm_helpers import get_stationpmjob_collection_for

    assert_super_admin(current)
    wonum = (wonum or "").strip()
    doc = await _open_coll().find_one({"wonum": wonum})
    if not doc:
        raise HTTPException(status_code=404, detail=f"ไม่พบใบงาน wonum={wonum}")

    jobs_removed = 0
    station_id = _station_id_of_wo(doc)
    if station_id:
        jobs = get_stationpmjob_collection_for(station_id)
        async for job in jobs.find({"wonum": wonum}):
            await delete_job_cascade(station_id, job)
            jobs_removed += 1
    removed = await delete_wo_doc(wonum)
    log.info(f"  🗑️ ลบใบงาน PM {wonum} ({station_id or '-'}) ใบ PM={jobs_removed} โดย {current.username or current.sub}")
    return {"ok": True, "deleted_wo": removed, "deleted_jobs": jobs_removed}


class VendorPlanIn(BaseModel):
    """แผนรอบที่ 2 ของ vendor — แผนของ planner ต้นทางไม่ถูกแตะ"""
    planned_at: Optional[str] = None
    sched_start: str
    sched_finish: str
    assignees: list[str] = Field(default_factory=list)


@router.post("/maximo/pm/{wonum}/vendor-plan")
async def set_pm_vendor_plan(
    wonum: str,
    body: VendorPlanIn,
    current: UserClaims = Depends(get_current_user),
):
    """
    planner ของ vendor วางแผนใบงานที่ planner ต้นทางส่งมาให้ (vendor_plans ของบริษัทตัวเอง)

    ช่างที่เลือกต้องเป็นตัวเลือกของบริษัทตัวเอง (ชุดเดียวกับ /companies/pm-options)
    วางแผนแล้วแก้ได้จนกว่าช่างจะกดเริ่ม PM (ดู _plan_edit_state)
    """
    from routers.company import pm_assignee_options

    role = (current.role or "").strip().lower()
    if role not in PM_PLANNING_ROLES:
        raise HTTPException(status_code=403, detail="เฉพาะ planner ที่วางแผนใบงานได้")

    wonum = (wonum or "").strip()
    wo = await _find_open_wo(wonum)
    if not wo:
        raise HTTPException(status_code=404, detail=f"ไม่พบใบงาน wonum={wonum}")

    company = _company_of(current).lower()
    plans = list(wo.get("vendor_plans") or [])
    idx = next((i for i, v in enumerate(plans) if str(v.get("vendor") or "").strip().lower() == company), -1)
    # ใบงานที่ planner ต้นทางเลือกบริษัทเราไว้ แต่ไม่มีใบส่งต่อเก็บไว้ (Assign ก่อนมีฟีเจอร์นี้
    # หรือตอนนั้นบริษัทเรายังไม่มีบัญชี planner) — ยังเป็นงานของเรา สร้างใบส่งต่อให้ตอนนี้
    if company and idx < 0 and str(wo.get("planning_status") or "").strip().lower() == "planned":
        named = next(
            (str(n).strip() for n in (wo.get("assignees") or []) if str(n or "").strip().lower() == company),
            "",
        )
        if named:
            from routers import pm_scope
            _name, sns, secs = pm_scope.items_by_party(wo.get("selected_equipment") or []).get(
                named.lower(), ("", [], [])
            )
            plans.append({"vendor": named, "status": "pending", "chargers": list(sns), "sections": list(secs)})
            idx = len(plans) - 1
    if not company or idx < 0:
        raise HTTPException(status_code=403, detail="ใบงานนี้ไม่ได้ส่งต่อให้บริษัทของคุณวางแผน")
    from routers import pm_lock
    await pm_lock.assert_free(_open_coll(), {"_id": wo["_id"]}, PLAN_LOCK_FIELD, current, "แผนของใบงานนี้")

    is_edit = plans[idx].get("status") == "planned"
    if is_edit:
        state = await _plan_edit_state(wo, current)
        if not state["can_edit_vendor_plan"]:
            raise HTTPException(status_code=409, detail=state["vendor_plan_reason"])

    sched_start = (body.sched_start or "").strip()
    sched_finish = (body.sched_finish or "").strip()
    if not sched_start or not sched_finish:
        raise HTTPException(status_code=400, detail="กรุณาระบุวันที่เริ่มและวันที่เสร็จตามแผน")
    if sched_finish < sched_start:
        raise HTTPException(status_code=400, detail="วันที่เสร็จตามแผนต้องไม่มาก่อนวันที่เริ่ม")

    assignees = list(dict.fromkeys(str(x).strip() for x in body.assignees if str(x or "").strip()))
    if not assignees:
        raise HTTPException(status_code=400, detail="กรุณาเลือกช่างอย่างน้อย 1 คน")
    options = await pm_assignee_options(current)
    allowed = {
        n.lower() for group in ("technicians", "vendors", "outsources") for n in options.get(group) or []
    }
    outside = [n for n in assignees if n.lower() not in allowed]
    if outside:
        raise HTTPException(status_code=400, detail=f"ไม่ใช่ผู้รับผิดชอบในบริษัทของคุณ: {', '.join(outside)}")

    who = current.username or current.sub
    plans[idx] = {
        **plans[idx],
        "status": "planned",
        "sched_start": sched_start,
        "sched_finish": sched_finish,
        "assignees": assignees,
    }
    if is_edit:
        plans[idx]["edited_by"] = who
        plans[idx]["edited_at"] = datetime.now(timezone.utc).isoformat()
    else:
        plans[idx]["planned_by"] = who
        plans[idx]["planned_at"] = (body.planned_at or datetime.now(timezone.utc).isoformat()).strip()
    await _open_coll().update_one({"_id": wo["_id"]}, {"$set": {"vendor_plans": plans}})
    log.info(f"  ✅ vendor {plans[idx]['vendor']} วางแผนใบงาน {wonum}: {assignees} โดย {who}")
    from brand_scope import invalidate_assigned_work
    invalidate_assigned_work()

    saved = await _find_open_wo(wonum) or {**wo, "vendor_plans": plans}

    # vendor รายสุดท้ายส่งทีมแล้ว = งานเริ่มจริง → ขั้น 2 ของ sequencing (IN02 INPRG)
    # ที่ถูกพักไว้ตอน planner ต้นทาง Assign (ดู set_pm_equipment)
    maximo_result = None
    if (
        not _pending_vendors(saved)
        and str(saved.get("planning_status") or "").strip().lower() == "planned"
        and not _is_manual_wo(saved)
    ):
        from services import pm_maximo_out
        maximo_result = await pm_maximo_out.safe_sync_in_progress(
            wonum, memo=f"assigned by {who} ({plans[idx]['vendor']})"
        )

    return {"ok": True, "wonum": wonum, "item": _serialize_open(saved), "maximo": maximo_result}


@router.post("/maximo/pm/{wonum}/equipment")
async def set_pm_equipment(
    wonum: str,
    body: SelectEquipmentIn,
    current: UserClaims = Depends(get_current_user),
):
    """
    บันทึกอุปกรณ์ที่ผู้ใช้เลือกจะ PM (เลือกได้หลายตัว) ผูกกับใบงาน Maximo ระดับสถานี
    ยิงทับได้ — ส่ง list ใหม่มาแทนของเดิมทั้งชุด
    """
    wonum = (wonum or "").strip()
    if not wonum:
        raise HTTPException(status_code=400, detail="wonum is required")

    role = (current.role or "").strip().lower()
    if role not in PM_PLANNING_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Only planner, owner or admin can plan PM equipment",
        )

    wo = await _find_open_wo(wonum)
    if not wo:
        raise HTTPException(status_code=404, detail=f"PM work order not found: {wonum}")

    # มี planner คนอื่นเปิดหน้าวางแผนใบนี้ค้างอยู่ (ถือล็อก) = ห้ามบันทึกทับ
    from routers import pm_lock
    await pm_lock.assert_free(_open_coll(), {"_id": wo["_id"]}, PLAN_LOCK_FIELD, current, "แผนของใบงานนี้")

    # วางแผนไปแล้ว = เป็นการแก้แผน — แก้ได้จนกว่าช่างจะกดเริ่ม PM / vendor จะวางแผนตาม
    is_edit = str(wo.get("planning_status") or "").strip().lower() == "planned"
    if is_edit:
        state = await _plan_edit_state(wo, current)
        if not state["can_edit_plan"]:
            raise HTTPException(status_code=409, detail=state["plan_reason"])

    # ใบที่เลขไม่มีอยู่จริงใน Maximo วางแผนไปก็ยิงสถานะกลับไม่ได้ (BMXAA1496E)
    # เตือนตั้งแต่ตอนกด Assign ดีกว่าไปพังตอนปิดงาน
    # เช็คกับ Maximo ไม่ได้ (ล่ม/เน็ตมีปัญหา) = ปล่อยผ่าน ไม่บล็อกงาน
    # ใบที่เปิดเองใน iMPS ไม่มีเลขใน Maximo อยู่แล้วโดยตั้งใจ — ข้ามการเช็คไปเลย
    try:
        found = {wonum: {}} if _is_manual_wo(wo) else await maximo_svc.workorders_exist([wonum])
    except Exception as e:
        log.warning(f"  ⚠️ เช็ค wonum {wonum} กับ Maximo ไม่สำเร็จ ปล่อยผ่าน: {e}")
        found = {wonum: {}}
    if wonum not in found:
        raise HTTPException(
            status_code=409,
            detail=f"ใบงาน {wonum} ไม่มีอยู่จริงใน Maximo — วางแผนแล้วส่งสถานะกลับไม่ได้ "
                   f"(อาจเป็น payload ทดสอบที่ยิงเข้ามา) กรุณาตรวจกับฝั่ง Maximo ก่อน",
        )

    # ไม่รู้ว่าเป็นสถานีไหนใน iMPS = สร้างเอกสาร PM ไม่ได้ (ทุกชนิด key ด้วย station_id
    # หรือ SN ของตู้ในสถานี) วางแผนไปก็ทำงานต่อไม่ได้ — กันตั้งแต่ตรงนี้
    if not _station_id_of_wo(wo):
        raise HTTPException(
            status_code=409,
            detail=f"location {wo.get('location') or '-'} ไม่ตรงกับสถานีไหนใน iMPS — "
                   f"ถ้าเป็นสถานีที่เราดูแล ให้ตั้ง maximo_location ที่หน้า EV Stations ก่อน "
                   f"ถ้าไม่ใช่ ให้ข้ามใบงานนี้ไป",
        )

    items = _build_equipment_items(_station_id_of_wo(wo), body.equipment or [])
    await _validate_equipment_by(items, current)

    now = datetime.now(timezone.utc)
    planned_at_value = (body.planned_at or now.isoformat()).strip()
    sched_start_value = (body.sched_start or "").strip()
    sched_finish_value = (body.sched_finish or "").strip()
    assignees = [str(x).strip() for x in body.assignees if str(x or "").strip()]
    planner_company = _company_of(current)

    # ไม่ส่ง equipment มา = คงรายการเดิมไว้ (ผู้เรียกที่ยังมี picker ส่ง list มาเหมือนเดิม)
    keep_equipment = body.equipment is None
    effective_items = (wo.get("selected_equipment") or []) if keep_equipment else items
    # ผู้ทำ PM ของอุปกรณ์แต่ละชิ้นเป็นผู้รับผิดชอบใบงานด้วย (เห็นใบงานในคิวของตัวเองเหมือนเลือกจากลิสต์)
    # vendor ที่ติ๊กมาในลิสต์ตรง ๆ ถูกตัด — ส่งต่อได้ผ่านผู้ทำ PM ของอุปกรณ์เท่านั้น
    assignees = await _plan_assignees(assignees, effective_items, current)

    # วางแผนเสร็จเมื่อเลือกอุปกรณ์แล้ว "หรือ" มีกำหนดการ + ช่างครบ
    # (หน้าวางแผน PM มอบหมายด้วยกำหนดการ+ช่างอย่างเดียว ไม่ได้เลือกอุปกรณ์)
    schedule_complete = bool(sched_start_value and sched_finish_value and assignees)
    planning_status = "planned" if (effective_items or schedule_complete) else "pending"

    update: dict = {
        "selected_at": now,
        "selected_by": current.username or current.sub,
        "planning_status": planning_status,
        "planned_at": planned_at_value,
        "planned_by": current.username or current.sub,
        "sched_start": sched_start_value,
        "sched_finish": sched_finish_value,
        "assignees": assignees,
        # คนแก้แผนอาจเป็น admin/owner — บริษัทเจ้าของแผนคงเดิม
        "planner_company": (str(wo.get("planner_company") or "").strip() if is_edit else "") or planner_company,
        # ผู้ทำ PM ของอุปกรณ์ในแผนที่มี planner ของตัวเอง → ส่งต่อให้วางแผนอีกรอบ
        # พร้อมอุปกรณ์ที่เป็นงานของ vendor รายนั้น
        "vendor_plans": _build_vendor_plans(
            wo.get("vendor_plans"), planner_company,
            _station_id_of_wo(wo), effective_items,
        ),
    }
    if not keep_equipment:
        update["selected_equipment"] = items
    if is_edit:
        # วางแผนครั้งแรกเก็บไว้ที่ planned_at/planned_by — การแก้จดแยกไว้
        update.pop("planned_at", None)
        update.pop("planned_by", None)
        update["plan_edited_at"] = now
        update["plan_edited_by"] = current.username or current.sub

    res = await _open_coll().update_one({"wonum": wonum}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail=f"ไม่พบใบงาน wonum={wonum}")

    doc = await _find_open_wo(wonum)
    log.info(f"  ✅ PM plan saved for {wonum}: {len(effective_items)} equipment item(s), status={planning_status}")
    # ผู้ทำ PM รายชิ้นเปลี่ยน → สถานี/ตู้ที่ vendor (เช่น EDS) เห็นได้เปลี่ยนตาม (brand_scope)
    from brand_scope import invalidate_assigned_work
    invalidate_assigned_work()

    # ── ขั้น 2 ของ sequencing: assign เสร็จ = ใบงานเข้าสถานะ In Progress ──
    # ยิงเฉพาะตอนวางแผนครบจริง ไม่ใช่ทุกครั้งที่กดบันทึก
    # ส่งต่อให้ vendor (เช่น EDS) วางแผนอีกรอบ = ยังไม่มีทีมเข้าหน้างานจริง
    # → พัก INPRG ไว้ก่อน ไปยิงตอน vendor รายสุดท้ายวางแผนเสร็จ (set_pm_vendor_plan)
    maximo_result = None
    pending_vendors = _pending_vendors(doc or {})
    if planning_status == "planned" and not _is_manual_wo(wo):
        if pending_vendors:
            maximo_result = {"skipped": f"รอ {', '.join(pending_vendors)} วางแผนส่งทีมก่อน"}
        else:
            from services import pm_maximo_out
            maximo_result = await pm_maximo_out.safe_sync_in_progress(
                wonum, memo=f"assigned by {current.username or current.sub}"
            )

    return {"ok": True, "wonum": wonum, "item": _serialize_open(doc), "maximo": maximo_result}


# ══════════════════════════════════════════════════════════════════
# 6) ใบงาน PM ที่เปิดเองใน iMPS (ไม่ได้มาจาก Maximo)
#    หน้า PM List → ปุ่ม "เพิ่มใบงาน" → ฟอร์มเดียวกับหน้าวางแผน แต่เลือกสถานีเองได้
#    เก็บลง collection เดียวกับใบงาน IN06 (iMPS.maximo_pm_open) เพื่อให้ทุกหน้า
#    ที่อ่านใบงาน PM อยู่แล้วเห็นใบนี้ทันทีโดยไม่ต้องแก้ — ต่างกันแค่ field origin
# ══════════════════════════════════════════════════════════════════
MANUAL_WO_ORIGIN = "imps-manual"  # ต้องตรงกับ services/pm_maximo_out.MANUAL_WO_ORIGIN


def _is_manual_wo(doc: dict) -> bool:
    """ใบงานที่เปิดเองในระบบ — ไม่มีเลขนี้อยู่ใน Maximo จึงไม่ต้องไปถามหา"""
    return str(doc.get("origin") or "").strip().lower() == MANUAL_WO_ORIGIN


async def _next_manual_wonum() -> str:
    """เลขใบงานของใบที่เปิดเอง — PM<ปีเดือน><running 4 หลัก> เช่น PM26090001"""
    prefix = f"PM{datetime.now(timezone.utc).strftime('%y%m')}"
    latest = await _open_coll().find_one(
        {"wonum": {"$regex": rf"^{prefix}\d{{4}}$"}},
        {"wonum": 1},
        sort=[("wonum", -1)],
    )
    seq = 0
    if latest:
        try:
            seq = int(str(latest.get("wonum") or "")[len(prefix):])
        except ValueError:
            seq = 0
    return f"{prefix}{seq + 1:04d}"


def _pm_station_query(current: UserClaims) -> Optional[dict]:
    """ขอบเขตสถานีของ user คนนี้ — ชุดเดียวกับหน้า EV Stations (role + ยี่ห้อที่ดูแล)"""
    from routers.stations import station_match_query  # import ตรงนี้กัน import วนกัน
    return station_match_query(current)


@router.get("/maximo/pm/stations")
async def list_pm_stations(current: UserClaims = Depends(get_current_user)):
    """
    สถานีที่ผู้ใช้คนนี้เปิดใบงาน PM ได้ — ใช้เติม dropdown "สถานี" ในฟอร์มเพิ่มใบงาน
    (หน้าวางแผนของใบงาน Maximo ไม่ต้องใช้ เพราะสถานีมากับ location ของใบงานอยู่แล้ว)
    """
    q = _pm_station_query(current)
    if q is None:
        return {"stations": [], "total": 0}

    docs = station_collection.find(
        q,
        {"_id": 0, "station_id": 1, "station_name": 1, "maximo_location": 1, "company": 1},
    ).sort([("station_name", 1)])

    stations = [
        {
            "station_id": str(d.get("station_id") or ""),
            "station_name": str(d.get("station_name") or d.get("station_id") or ""),
            "maximo_location": (str(d.get("maximo_location") or "").strip() or None),
            "company": (str(d.get("company") or "").strip() or None),
        }
        for d in docs
        if str(d.get("station_id") or "").strip()
    ]
    return {"stations": stations, "total": len(stations)}


@router.get("/maximo/pm/equipment-choices")
async def pm_equipment_choices_by_station(
    station_id: str = Query(..., description="station_id ของ iMPS"),
    current: UserClaims = Depends(get_current_user),
):
    """
    รายการอุปกรณ์ที่เลือก PM ได้ในสถานีหนึ่ง โดยยังไม่ต้องมีใบงาน
    (ฟอร์มเพิ่มใบงานใช้ตอนผู้ใช้เลือกสถานี — ทรง response เดียวกับของใบงานที่มี wonum)
    """
    sid = (station_id or "").strip()
    station = station_collection.find_one(
        {"station_id": sid}, {"_id": 0, "station_id": 1, "maximo_location": 1}
    )
    if not station:
        raise HTTPException(status_code=404, detail=f"ไม่พบสถานี station_id={sid}")

    chargers, fixed = _station_equipment_choices(sid)
    return {
        "wonum": None,
        "station_id": sid,
        "location": (str(station.get("maximo_location") or "").strip() or None),
        "chargers": chargers,
        "fixed": fixed,
        "selected_equipment": [],
    }


class CreatePmWorkOrderIn(BaseModel):
    """ใบงาน PM ที่ผู้ใช้เปิดเองจากหน้า PM List"""
    station_id: str
    pm_date: Optional[str] = None
    description: Optional[str] = None
    equipment: list[EquipmentItem] = Field(default_factory=list)
    planned_at: Optional[str] = None
    sched_start: Optional[str] = None
    sched_finish: Optional[str] = None
    assignees: list[str] = Field(default_factory=list)


@router.post("/maximo/pm/work-orders")
async def create_pm_work_order(
    body: CreatePmWorkOrderIn,
    current: UserClaims = Depends(get_current_user),
):
    """
    เปิดใบงาน PM ใหม่ในระบบ iMPS (ไม่ยิงไป Maximo)

    ใช้ตอนงาน PM ไม่ได้ถูกเปิดมาจาก Maximo — planner เลือกสถานีเอง แล้ววางแผน
    (กำหนดการ + ช่าง + อุปกรณ์) ในฟอร์มเดียวกับหน้าวางแผนใบงานของ Maximo
    เลขใบงานระบบออกให้เอง (PM<ปีเดือน><running>) ไม่ทับกับเลขที่ Maximo ส่งมา
    """
    role = (current.role or "").strip().lower()
    if role not in PM_PLANNING_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Only planner, owner or admin can create PM work orders",
        )

    sid = (body.station_id or "").strip()
    if not sid:
        raise HTTPException(status_code=400, detail="กรุณาเลือกสถานี")

    # สถานีต้องอยู่ในขอบเขตที่ user คนนี้ดูแล — ไม่งั้นเปิดใบงานข้ามบริษัทได้
    scope = _pm_station_query(current)
    if scope is None:
        raise HTTPException(status_code=403, detail="ไม่มีสิทธิ์เปิดใบงานของสถานีนี้")
    query: dict[str, Any] = {"$and": [scope, {"station_id": sid}]} if scope else {"station_id": sid}
    station = station_collection.find_one(
        query,
        {"_id": 0, "station_id": 1, "station_name": 1, "maximo_location": 1, "company": 1},
    )
    if not station:
        raise HTTPException(status_code=404, detail=f"ไม่พบสถานี station_id={sid}")

    sched_start = (body.sched_start or "").strip()
    sched_finish = (body.sched_finish or "").strip()
    # เทียบเป็น string ได้เพราะ datetime-local เรียงตัวอักษรตรงกับเรียงเวลา
    if sched_start and sched_finish and sched_finish < sched_start:
        raise HTTPException(
            status_code=400, detail="วันที่เสร็จตามแผนต้องไม่มาก่อนวันที่เริ่ม"
        )

    items = _build_equipment_items(sid, body.equipment or [])
    await _validate_equipment_by(items, current)
    assignees = await _plan_assignees(
        [str(x).strip() for x in body.assignees if str(x or "").strip()], items, current
    )

    now = datetime.now(timezone.utc)
    # ไม่ได้ตั้ง maximo_location ไว้ = ใช้ station_id แทน ใบงานจะได้ยังผูกกับสถานีได้
    location = str(station.get("maximo_location") or "").strip() or sid
    # เกณฑ์เดียวกับหน้าวางแผน: เลือกอุปกรณ์แล้ว หรือมีกำหนดการ + ช่างครบ = วางแผนเสร็จ
    planning_status = (
        "planned" if (items or (sched_start and sched_finish and assignees)) else "pending"
    )
    who = current.username or current.sub

    doc: dict[str, Any] = {
        "location": location,
        "description": (body.description or "").strip()
        or f"PM {station.get('station_name') or sid}",
        "pm_date": _norm_pm_date(body.pm_date) or now.date().isoformat(),
        "status": "OPEN",
        "company": (str(station.get("company") or "").strip() or None),
        "station_id": sid,
        "sn": None,
        "origin": MANUAL_WO_ORIGIN,
        "created_by": who,
        "receivedAt": now,
        "updatedAt": now,
        "selected_equipment": items,
        "selected_at": now,
        "selected_by": who,
        "planning_status": planning_status,
        "planned_at": (body.planned_at or now.isoformat()).strip(),
        "planned_by": who,
        "sched_start": sched_start,
        "sched_finish": sched_finish,
        "assignees": assignees,
        "planner_company": _company_of(current),
        "vendor_plans": _build_vendor_plans(None, _company_of(current), sid, items),
    }

    # กดพร้อมกันแล้วได้เลขซ้ำ — ลองเลขถัดไปไม่กี่รอบก่อนยอมแพ้
    for _ in range(5):
        wonum = await _next_manual_wonum()
        if await _open_coll().find_one({"wonum": wonum}, {"_id": 1}):
            continue
        try:
            await _open_coll().insert_one({**doc, "wonum": wonum})
        except Exception as e:
            log.warning(f"  ⚠️ เปิดใบงาน PM {wonum} ไม่สำเร็จ ลองเลขถัดไป: {e}")
            continue
        saved = await _find_open_wo(wonum) or {**doc, "wonum": wonum}
        log.info(
            f"  ✅ เปิดใบงาน PM เอง {wonum} (station={sid}, {len(items)} อุปกรณ์, "
            f"status={planning_status}) โดย {who}"
        )
        return {"ok": True, "wonum": wonum, "item": _serialize_open(saved)}

    raise HTTPException(status_code=500, detail="ออกเลขใบงานไม่สำเร็จ กรุณาลองใหม่อีกครั้ง")
