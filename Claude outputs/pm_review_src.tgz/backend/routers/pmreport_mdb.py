"""PM Report routes for MDB (station_id-based)"""
from fastapi import APIRouter, HTTPException, Depends, Query, Request, UploadFile, File, Form, Path
from fastapi.responses import Response, JSONResponse, StreamingResponse
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from datetime import datetime, timedelta, timezone, date
from dateutil.relativedelta import relativedelta
from bson.objectid import ObjectId
from bson.errors import InvalidId
from bson.decimal128 import Decimal128
from zoneinfo import ZoneInfo
from typing import List, Dict, Any, Optional, Literal
import re, json, uuid, pathlib, secrets, os, asyncio
import zipfile

from config import (
    MDBPMReportDB, MDBPMUrlDB, station_collection,
    _validate_station_id_th, th_tz, _ensure_utc_iso,
)
from deps import UserClaims, get_current_user
from routers import pm_scope
from routers import pm_flow
from services import pm_maximo_out, pm_pdf
from uploads_access import assert_station_access, assert_sn_access
from routers.pm_helpers import (
    UPLOADS_ROOT,
    ALLOWED_EXTS,
    MAX_FILE_MB,
    _safe_name,
    _ext,
    parse_iso_any_tz,
    get_mdbpmreport_collection_for,
    get_mdbpmurl_coll_upload,
    _latest_issue_id_anywhere,
    _next_issue_id,
    _next_issue_id_no_conflict,
    _latest_doc_name_anywhere,
    _next_year_seq,
)

from PIL import Image
from image_convert import normalize_image_bytes, ImageConversionError
from io import BytesIO


# เวอร์ชันชุดหัวข้อของฟอร์ม MDB
#   1 = ชุดเดิม 13 ข้อ
#   2 = เพิ่ม "ตรวจสอบสภาพทั่วไป / อุปกรณ์ชำรุดเสียหาย (ก่อนบำรุงรักษา)" เป็นข้อ 1-2
#       ข้อเดิมเลื่อนเป็น 3-15 → คีย์ rows/photos ของใบ v1 กับ v2 คนละความหมายกัน
#       ทั้งฟอร์มและ PDF อ่านค่านี้เพื่อเลือกชุดหัวข้อให้ตรงกับใบ
FORM_VERSION = 2


# เดิมแต่ละ router มี resize_image_bytes ของตัวเอง (ซ้ำกัน 5 ที่) ซึ่ง `except: return data`
# กลืนเคส "เปิด HEIC ไม่ได้" ไปเงียบ ๆ ตอนนี้ย้ายไปรวมที่ image_convert.normalize_image_bytes
# ที่แปลงเป็น JPEG เสมอ และ raise เมื่อแปลงไม่ได้จริง ๆ
def resize_image_bytes(data: bytes, max_width: int = 1920, quality: int = 85) -> bytes:
    """คงชื่อเดิมไว้เผื่อมีโค้ดอื่นเรียก — ผลลัพธ์เป็น JPEG ที่เบราว์เซอร์เปิดได้เสมอ"""
    return normalize_image_bytes(data, max_width=max_width, quality=quality)[0]


router = APIRouter()

# ── ผูกกับใบ PM สถานี "ใบเดียว 4 ส่วน" ────────────────────────────
async def _job_link(station_id: str, job_id: str | None) -> dict:
    """ข้อมูลเลขที่เอกสารของใบแม่ — ไม่ได้ส่ง job_id มา = ใบเดี่ยวแบบเดิม คืน {}"""
    if not (job_id or "").strip():
        return {}
    from routers.pmreport_station_job import job_numbering
    return await job_numbering(station_id, job_id)



# ============================================
# Helpers
# ============================================

async def _get_station_by_id(station_id: str) -> dict:
    """Get station document by station_id, raise 404 if not found"""
    station = station_collection.find_one({"station_id": station_id})
    if not station:
        raise HTTPException(status_code=404, detail=f"Station with ID '{station_id}' not found")
    return station


def _compute_next_pm_date_str(pm_date_str: str | None) -> str | None:
    if not pm_date_str:
        return None
    try:
        d = datetime.fromisoformat(pm_date_str).date()
    except ValueError:
        return None
    next_d = d + relativedelta(months=+6)
    return next_d.isoformat()


async def _latest_pm_date_from_mdbpmreport(station_id: str) -> dict | None:
    _validate_station_id_th(station_id)
    coll = MDBPMReportDB.get_collection(str(station_id))

    pipeline = [
        {"$addFields": {
            "_ts": {
                "$ifNull": [
                    {
                        "$cond": [
                            {"$eq": [{"$type": "$timestamp"}, "string"]},
                            {"$dateFromString": {
                                "dateString": "$timestamp",
                                "timezone": "UTC",
                                "onError": None,
                                "onNull": None
                            }},
                            "$timestamp"
                        ]
                    },
                    {"$toDate": "$_id"}
                ]
            }
        }},
        {"$sort": {"_ts": -1, "_id": -1}},
        {"$limit": 1},
        {"$project": {"_id": 1, "pm_date": 1, "timestamp": 1}}
    ]

    cursor = coll.aggregate(pipeline)
    docs = await cursor.to_list(length=1)
    return docs[0] if docs else None


async def _mdbpmreport_latest_core(station_id: str, current: UserClaims):
    """Get latest PM report info for an MDB by station_id"""
    _validate_station_id_th(station_id)

    station = await _get_station_by_id(station_id)

    pm_latest = await _latest_pm_date_from_mdbpmreport(station_id)
    pm_date = pm_latest.get("pm_date") if pm_latest else None

    ts_raw = (pm_latest.get("timestamp") if pm_latest else None) or station.get("createdAt")

    ts_dt = (parse_iso_any_tz(ts_raw) if isinstance(ts_raw, str)
             else (ts_raw if isinstance(ts_raw, datetime) else None))
    ts_utc = ts_dt.astimezone(ZoneInfo("UTC")).isoformat() if ts_dt else None
    ts_th = ts_dt.astimezone(ZoneInfo("Asia/Bangkok")).isoformat() if ts_dt else None

    pm_next_date = _compute_next_pm_date_str(pm_date)

    return {
        "_id": str(station["_id"]),
        "station_id": station_id,
        "pm_date": pm_date,
        "pm_next_date": pm_next_date,
        "timestamp": ts_raw,
        "timestamp_utc": ts_utc,
        "timestamp_th": ts_th,
        "source": "stations + MDBPMReportDB",
    }


def serialize_doc(doc):
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_doc(d) for d in doc]
    if isinstance(doc, dict):
        result = {}
        for k, v in doc.items():
            if isinstance(v, ObjectId):
                result[k] = str(v)
            elif isinstance(v, datetime):
                result[k] = v.isoformat()
            elif isinstance(v, Decimal128):
                result[k] = float(v.to_decimal())
            else:
                result[k] = serialize_doc(v)
        return result
    return doc


def parse_report_date_to_utc(s: str) -> datetime:
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
        tz_th = ZoneInfo("Asia/Bangkok")
        dt_th = datetime.fromisoformat(s + "T00:00:00").replace(tzinfo=tz_th)
        return dt_th.astimezone(timezone.utc)
    if s.endswith("Z"):
        return datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(timezone.utc)
    if re.search(r"[+\-]\d{2}:\d{2}$", s):
        return datetime.fromisoformat(s).astimezone(timezone.utc)
    return datetime.fromisoformat(s + "+07:00").astimezone(timezone.utc)


def normalize_pm_date(s: str) -> str:
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
        return s
    if s.endswith("Z") or re.search(r"[+\-]\d{2}:\d{2}$", s):
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    else:
        dt = datetime.fromisoformat(s).replace(tzinfo=th_tz)
    return dt.astimezone(th_tz).date().isoformat()


# ============================================
# Preview endpoints
# ============================================

@router.get("/mdbpmreport/preview-issueid")
async def mdbpmreport_preview_issueid(
    station_id: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Preview next issue_id without actually generating it"""
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    pm_type = "MB"
    latest = await _latest_issue_id_anywhere(station_id, pm_type, d, source="mdb")

    yymm = f"{d.year % 100:02d}{d.month:02d}"
    prefix = f"PM-{pm_type}-{yymm}-"

    if not latest:
        next_issue = f"{prefix}01"
    else:
        m = re.search(r"(\d+)$", latest)
        cur = int(m.group(1)) if m else 0
        next_issue = f"{prefix}{cur+1:02d}"

    return {"issue_id": next_issue}


@router.get("/mdbpmreport/latest-docname")
async def mdbpmreport_latest_docname(
    station_id: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Get latest doc_name for calculating next number at frontend"""
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    latest = await _latest_doc_name_anywhere(station_id, d.year, source="mdb")
    return {
        "doc_name": latest,
        "station_id": station_id,
        "pm_date": pm_date,
    }


@router.get("/mdbpmreport/preview-docname")
async def preview_docname(
    station_id: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Preview next doc_name without actually generating it"""
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    year = d.year
    latest = await _latest_doc_name_anywhere(station_id, year, source="mdb")

    if not latest:
        next_doc = f"{station_id}_1/{year}"
    else:
        m = re.search(r"_(\d+)/\d{4}$", latest)
        current_num = int(m.group(1)) if m else 0
        next_doc = f"{station_id}_{current_num + 1}/{year}"

    return {"doc_name": next_doc}


# ============================================
# Pydantic Models
# ============================================

class MDBPMPostIn(BaseModel):
    report_id: Optional[str] = None
    station_id: str
    # ใบนี้เป็นส่วนหนึ่งของใบ PM สถานี "ใบเดียว 4 ส่วน" (stationPMJob) หรือไม่
    job_id: Optional[str] = None
    rows: Dict[str, Any]
    measures: Dict[str, Any]
    summary: str
    summaryCheck: Optional[str] = None
    dust_filter: Optional[Dict[str, bool]] = None
    # เวลาทำงานจริงของช่าง (ส่งเข้า Maximo ทาง IN09) + ใบงาน Maximo ที่ผูกไว้
    work_start: Optional[str] = None
    work_finish: Optional[str] = None
    wonum: Optional[str] = None
    side: Literal["post", "after"]
    # laborcode ฝั่ง Maximo ที่ช่างเลือกเอง (ใช้ส่งเวลาทำงาน IN09)
    maximo_labor: Optional[List[str]] = None
    maximo_contractor: Optional[str] = None
    # ── ข้อมูลหัวเอกสาร ────────────────────────────────────────────────
    # ฟอร์มกรอกรอบเดียวแล้ว (ไม่มีด่าน "ก่อน PM") /submit จึงเป็นตัวสร้าง
    # เอกสารเองเมื่อยังไม่มี report_id — ฟิลด์ชุดนี้เคยส่งมาที่ /pre/submit
    job: Optional[Dict[str, Any]] = None
    # q4_items / q6_items = ชื่อฟิลด์เดิมใน DB (สมัยที่ Breaker Main อยู่ข้อ 4
    # และ Breaker CCB อยู่ข้อ 6) ตอนนี้เป็นข้อ 6 กับ 8 แต่คงชื่อฟิลด์ไว้
    # จะได้ไม่ต้อง migrate ใบเก่า
    pm_date: Optional[str] = None
    issue_id: Optional[str] = None
    doc_name: Optional[str] = None
    inspector: Optional[str] = None
    q4_items: Optional[List[Dict[str, str]]] = None
    q6_items: Optional[List[Dict[str, str]]] = None
    charger_count: Optional[int] = None


# ============================================
# Get / List / Latest
# ============================================

@router.get("/mdbpmreport/get")
async def mdbpmreport_get(
    station_id: str,
    report_id: str,
    current: UserClaims = Depends(get_current_user),
):
    coll = get_mdbpmreport_collection_for(station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")

    # backward compatibility
    if "q4_items" not in doc:
        doc["q4_items"] = [{"key": "r4_1", "label": "4.1) Breaker Main ตัวที่ 1"}]
    if "charger_count" not in doc:
        doc["charger_count"] = 1
    if "rows_pre" not in doc:
        doc["rows_pre"] = {}
    if "q6_items" not in doc:
        doc["q6_items"] = [{"key": "r6_1", "label": "6.1) Breaker CCB ตัวที่ 1"}]

    return serialize_doc(doc)


@router.get("/mdbpmreport/list")
async def mdbpmreport_list(
    station_id: str = Query(...),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    status: str | None = Query(None, description="กรองตามสถานะ คั่นหลายค่าด้วย ,"),
    current: UserClaims = Depends(get_current_user),
):
    """List PM reports for an MDB by station_id"""
    coll = get_mdbpmreport_collection_for(station_id)
    skip = (page - 1) * pageSize

    query: dict = {}
    if status and (conds := pm_flow.status_or_conditions(status)):
        query["$or"] = conds

    cursor = coll.find(
        query,
        {"_id": 1, "issue_id": 1, "doc_name": 1, "pm_date": 1, "inspector": 1,
         "side": 1, "has_photos": 1, "createdAt": 1, "charger_count": 1,
         "status": 1, "stage": 1, "wonum": 1, "approved_by": 1,
         "approved_at": 1, "reject_remark": 1, "rejected_by": 1, "submittedAt": 1,
        },
    ).sort([("createdAt", -1), ("_id", -1)]).skip(skip).limit(pageSize)

    items_raw = await cursor.to_list(length=pageSize)
    total = await coll.count_documents(query)

    pm_dates = [it.get("pm_date") for it in items_raw if it.get("pm_date")]
    url_coll = get_mdbpmurl_coll_upload(station_id)
    url_by_day: Dict[str, str] = {}

    if pm_dates:
        ucur = url_coll.find({"pm_date": {"$in": pm_dates}}, {"pm_date": 1, "urls": 1})
        url_docs = await ucur.to_list(length=10_000)
        for u in url_docs:
            day = u.get("pm_date")
            first_url = (u.get("urls") or [None])[0]
            if day and first_url and day not in url_by_day:
                url_by_day[day] = first_url

    items = [{
        "id": str(it["_id"]),
        "issue_id": it.get("issue_id"),
        "doc_name": it.get("doc_name"),
        "pm_date": it.get("pm_date"),
        "inspector": it.get("inspector"),
        "side": it.get("side"),
        "charger_count": it.get("charger_count", 1),
        "createdAt": _ensure_utc_iso(it.get("createdAt")),
        "file_url": url_by_day.get(it.get("pm_date") or "", ""),
        "has_photos": True if it.get("has_photos") else None,
        **pm_flow.list_fields(it, _ensure_utc_iso),
    } for it in items_raw]

    pm_date_arr = [it.get("pm_date") for it in items_raw if it.get("pm_date")]
    return {
        "items": items,
        "pm_date": pm_date_arr,
        "page": page,
        "pageSize": pageSize,
        "total": total,
    }


@router.get("/mdbpmreport/latest/{station_id}")
async def mdbpmreport_latest_by_path(
    station_id: str = Path(..., description="Station ID"),
    current: UserClaims = Depends(get_current_user),
):
    """Get latest PM info for an MDB by station_id (path param)"""
    return await _mdbpmreport_latest_core(station_id, current)


# ============================================
# Issue ID / Doc Name allocation
# ============================================

async def _resolve_issue_and_doc(
    coll, url_coll, db, station_id: str, pm_type: str, d: date,
    client_issue: str | None, client_doc: str | None,
) -> tuple[str, str]:
    """
    จองเลข issue_id / doc_name ให้ใบใหม่

    ฝั่งฟอร์มพรีวิวเลขไว้ล่วงหน้า (preview-issueid / preview-docname) ถ้าเลขนั้น
    ยังว่างอยู่จริงตอนกดบันทึกก็ใช้ตามนั้น ไม่งั้นออกเลขถัดไปให้ใหม่
    """
    tasks: list = []
    prefix = ""

    if client_issue:
        yymm = f"{d.year % 100:02d}{d.month:02d}"
        prefix = f"PM-{pm_type}-{yymm}-"
        if client_issue.startswith(prefix):
            tasks.append(coll.find_one({"issue_id": client_issue}, {"_id": 1}))
            tasks.append(url_coll.find_one({"issue_id": client_issue}, {"_id": 1}))
        else:
            tasks.append(asyncio.sleep(0))
            tasks.append(asyncio.sleep(0))
    else:
        tasks.append(asyncio.sleep(0))
        tasks.append(asyncio.sleep(0))

    if client_doc:
        tasks.append(coll.find_one({"doc_name": client_doc}, {"_id": 1}))
        tasks.append(url_coll.find_one({"doc_name": client_doc}, {"_id": 1}))
    else:
        tasks.append(asyncio.sleep(0))
        tasks.append(asyncio.sleep(0))

    results = await asyncio.gather(*tasks)

    issue_id: str | None = None
    if client_issue and client_issue.startswith(prefix):
        rep_exists, url_exists = results[0], results[1]
        if not rep_exists and not url_exists:
            issue_id = client_issue
    if not issue_id:
        issue_id = await _next_issue_id_no_conflict(db, coll, url_coll, station_id, pm_type, d)

    doc_name: str | None = None
    if client_doc and client_doc.startswith(f"{station_id}_"):
        rep_exists, url_exists = results[2], results[3]
        if not rep_exists and not url_exists:
            doc_name = client_doc
    if not doc_name:
        year_seq = await _next_year_seq(db, station_id, pm_type, d)
        doc_name = f"{station_id}_{year_seq}/{d.year}"

    return issue_id, doc_name


# ============================================
# Post-PM Submit
# ============================================

@router.post("/mdbpmreport/submit")
async def mdbpmreport_post_submit(
    body: MDBPMPostIn,
    current: UserClaims = Depends(get_current_user),
):
    """
    บันทึกใบ PM ของ MDB (ฟอร์มกรอกรอบเดียว)

    มี report_id = อัปเดตใบเดิม (ใบที่โดนตีกลับ / ใบเก่าที่ยังเป็น draft)
    ไม่มี = สร้างใบใหม่พร้อมจองเลข issue_id / doc_name ให้เลย
    """
    station_id = body.station_id.strip()
    coll = get_mdbpmreport_collection_for(station_id)
    # ใบ PM สถานีที่แบ่งงานกับ vendor — กรอกได้เฉพาะส่วนของบริษัทตัวเอง (routers/pm_scope.py)
    await pm_scope.guard(current, "mdb", coll, report_id=body.report_id, job_id=body.job_id, station_id=station_id)

    update_fields = {
        "rows": body.rows,
        "measures": body.measures,
        "summary": body.summary,
        "summaryCheck": body.summaryCheck,
        "dust_filter": body.dust_filter,
        **pm_flow.post_submit_fields(body),
        **({"job_id": body.job_id} if body.job_id else {}),
        "side": "post",
        "timestamp_post": datetime.now(timezone.utc),
    }

    if body.report_id:
        try:
            oid = ObjectId(body.report_id)
        except InvalidId:
            raise HTTPException(status_code=400, detail="invalid report_id")

        existing = await coll.find_one({"_id": oid, "station_id": station_id})
        if not existing:
            raise HTTPException(status_code=404, detail="Report not found")

        # จำนวน Breaker Main / CCB ช่างปรับได้ในฟอร์ม ต้องเก็บตามที่ส่งมาล่าสุด
        # ไม่งั้น PDF กับตารางเทียบจะยังใช้ชุดเดิมของตอนสร้างใบ
        if body.q4_items:
            update_fields["q4_items"] = body.q4_items
        if body.q6_items:
            update_fields["q6_items"] = body.q6_items
        if body.charger_count:
            update_fields["charger_count"] = body.charger_count

        await coll.update_one({"_id": oid}, {"$set": update_fields})
        return {
            "ok": True,
            "report_id": body.report_id,
            "issue_id": existing.get("issue_id"),
            "doc_name": existing.get("doc_name"),
        }

    # ── ใบใหม่ ────────────────────────────────────────────────────────
    pm_date = (body.pm_date or "").strip()
    if not pm_date:
        raise HTTPException(status_code=400, detail="pm_date is required for a new report")
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    job = dict(body.job or {})
    pm_type = str(job.get("pm_type") or "MB").upper()
    job["pm_type"] = pm_type

    url_coll = get_mdbpmurl_coll_upload(station_id)
    db = coll.database

    # กดบันทึกซ้ำ (เน็ตหลุดกลางทาง / อัปรูปไม่ผ่านแล้วกดใหม่) ต้องลงใบเดิม
    # ไม่ใช่ออกเลขเอกสารใหม่ทุกครั้ง
    # ใบที่ผูกกับใบแม่: ส่วน MDB ของใบแม่มีได้ใบเดียว หาเจอด้วย job_id ตรง ๆ
    link = await _job_link(station_id, body.job_id)
    draft_filter = (
        {"station_id": station_id, "job_id": link["job_id"]}
        if link else
        {"station_id": station_id, "pm_date": pm_date, "status": "draft"}
    )
    existing_draft = await coll.find_one(
        draft_filter,
        {"_id": 1, "issue_id": 1, "doc_name": 1},
        sort=[("timestamp", -1)],
    )

    common = {
        **update_fields,
        "job": job,
        "pm_date": pm_date,
        **({"job_id": link["job_id"]} if link else {}),
        "inspector": body.inspector,
        "q4_items": body.q4_items or [{"key": "r6_1", "label": "6.1) Breaker Main ตัวที่ 1"}],
        "q6_items": body.q6_items or [{"key": "r8_1", "label": "8.1) Breaker CCB ตัวที่ 1"}],
        "charger_count": body.charger_count or 1,
        "form_version": FORM_VERSION,
    }

    if existing_draft:
        await coll.update_one({"_id": existing_draft["_id"]}, {"$set": common})
        return {
            "ok": True,
            "report_id": str(existing_draft["_id"]),
            "issue_id": existing_draft.get("issue_id"),
            "doc_name": existing_draft.get("doc_name"),
        }

    if link:
        # ส่วนหนึ่งของใบแม่ = ใช้เลขที่/ชื่อเอกสารใบเดียวกับแม่ ไม่ออกเลขใหม่
        issue_id, doc_name = link["issue_id"], link["doc_name"]
    else:
        issue_id, doc_name = await _resolve_issue_and_doc(
            coll, url_coll, db, station_id, pm_type, d, body.issue_id, body.doc_name,
        )

    doc = {
        "station_id": station_id,
        "doc_name": doc_name,
        "issue_id": issue_id,
        **common,
        "photos": {},
        "status": "draft",
        "timestamp": datetime.now(timezone.utc),
    }
    res = await coll.insert_one(doc)
    return {
        "ok": True,
        "report_id": str(res.inserted_id),
        "issue_id": issue_id,
        "doc_name": doc_name,
    }


# ============================================
# Photo Upload
# ============================================

# g{n} = ข้อหลัก, r{n}_{i} = ข้อย่อยตัวเลข (r6_1), r{n}_{name} = ข้อย่อยแบบตั้งชื่อ
# (ข้อ 3 แหล่งจ่ายไฟ: r3_power_main_cb / r3_power_cb / r3_power_meter / r3_power_transformer)
# ห้ามมี "." หรือ "$" เพราะใช้เป็นชื่อ field ใน Mongo และชื่อโฟลเดอร์
PHOTO_GROUP_PATTERN = r"(g\d+|r\d+_[a-z0-9]+(?:_[a-z0-9]+)*)"


@router.post("/mdbpmreport/{report_id}/post/photos")
async def mdbpmreport_upload_photos_post(
    report_id: str,
    station_id: str = Form(...),
    group: str = Form(...),
    files: List[UploadFile] = File(...),
    remark: Optional[str] = Form(None),
    current: UserClaims = Depends(get_current_user),
):
    """Upload Post-PM photos for an MDB report"""
    # ตรวจสิทธิ์สถานีก่อนแตะข้อมูล — เดิมเช็คแค่ว่า field ตรงกับ document
    # ซึ่งผู้เรียกคุมได้ทั้งคู่ จึงยิงข้ามสถานีได้
    assert_station_access(current, station_id)
    if not re.fullmatch(PHOTO_GROUP_PATTERN, group):
        raise HTTPException(status_code=400, detail=f"Bad group key format: {group}")

    storage_key = group

    coll = get_mdbpmreport_collection_for(station_id)
    # ใบ PM สถานีที่แบ่งงานกับ vendor — กรอกได้เฉพาะส่วนของบริษัทตัวเอง (routers/pm_scope.py)
    await pm_scope.guard(current, "mdb", coll, report_id=report_id, station_id=station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one(
        {"_id": oid},
        {"_id": 1, "station_id": 1, f"photos.{storage_key}": 1},
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")
    if doc.get("station_id") != station_id:
        raise HTTPException(status_code=400, detail="station_id mismatch")

    MAX_PHOTOS_PER_GROUP = 10
    existing_count = len((doc.get("photos") or {}).get(storage_key, []))
    remaining = MAX_PHOTOS_PER_GROUP - existing_count
    if remaining <= 0:
        return {"ok": True, "count": 0, "group": group, "storage_key": storage_key, "files": [], "skipped": "group_full"}
    files = files[:remaining]

    dest_dir = pathlib.Path(UPLOADS_ROOT) / "mdbpm" / station_id / report_id / "post" / storage_key
    dest_dir.mkdir(parents=True, exist_ok=True)

    saved = []
    for f in files:
        ext = _ext(f.filename or "")
        if ext not in ALLOWED_EXTS:
            raise HTTPException(status_code=400, detail=f"File type not allowed: {ext}")

        data = await f.read()
        if len(data) == 0:
            raise HTTPException(status_code=400, detail=f"Empty file: {f.filename}")
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"File too large (> {MAX_FILE_MB} MB)")

        # บังคับให้เป็น JPEG เสมอ — iPhone ส่ง HEIC มาซึ่ง Chrome/Edge/Firefox เปิดไม่ได้
        # ของเดิม (resize_image_bytes) เปิด HEIC ไม่ได้แล้วคืนไบต์เดิมเงียบ ๆ จึงได้ไฟล์
        # "ไบต์ HEIC ในชื่อ .jpg" ที่เปิดไม่ขึ้นทั้งบนเว็บและใน PDF
        try:
            data, out_ext = normalize_image_bytes(data, f.filename or "", max_width=1280, quality=75)
        except ImageConversionError as e:
            raise HTTPException(status_code=400, detail=str(e))

        out_ext = out_ext or "jpg"
        fname = _safe_name(f.filename or f"image_{secrets.token_hex(3)}.{out_ext}")
        fname = pathlib.Path(fname).stem + "." + out_ext
        path = dest_dir / fname
        with open(path, "wb") as out:
            out.write(data)

        url_path = f"/uploads/mdbpm/{station_id}/{report_id}/post/{storage_key}/{fname}"
        saved.append({
            "filename": fname,
            "url": url_path,
            "remark": remark or "",
            "uploadedAt": datetime.now(timezone.utc),
        })

    await coll.update_one(
        {"_id": oid},
        {
            "$push": {f"photos.{storage_key}": {"$each": saved}},
            "$set": {"has_photos": True, "updatedAt": datetime.now(timezone.utc)},
        },
    )
    if not saved:
        raise HTTPException(status_code=400, detail="No files were saved")

    return {"ok": True, "count": len(saved), "group": group, "storage_key": storage_key, "files": saved}


# ============================================
# Finalize
# ============================================

@router.post("/mdbpmreport/{report_id}/finalize")
async def mdbpmreport_finalize(
    report_id: str,
    station_id: str = Form(...),
    current: UserClaims = Depends(get_current_user),
):
    coll = get_mdbpmreport_collection_for(station_id)
    # ใบ PM สถานีที่แบ่งงานกับ vendor — กรอกได้เฉพาะส่วนของบริษัทตัวเอง (routers/pm_scope.py)
    await pm_scope.guard(current, "mdb", coll, report_id=report_id, station_id=station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    # ช่างกดส่ง = เข้าคิวรอ planner อนุมัติ (ตรวจเวลาทำงานให้ด้วย)
    await pm_flow.finalize(coll, oid, {"station_id": station_id})

    # ลบ PDF cache เผื่อมีค้างอยู่
    for lang in ("th", "en"):
        cache_path = pathlib.Path(UPLOADS_ROOT) / "pdf_cache" / station_id / f"{report_id}_{lang}.pdf"
        if cache_path.exists():
            cache_path.unlink()

    return {"ok": True, "report_id": report_id}


# ============================================
# MDB PM URL (PDF Upload + List)
# ============================================

@router.post("/mdbpmreport/{report_id}/approve")
async def mdbpmreport_approve(
    report_id: str,
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """planner/admin อนุมัติปิดใบงาน แล้วส่งต่อให้ Maximo (IN03 → IN09 → IN02 CLOSED)"""
    station_id = station_id.strip()
    coll = get_mdbpmreport_collection_for(station_id)
    oid = pm_flow.to_oid(report_id)

    result = await pm_flow.approve(coll, oid, {"station_id": station_id}, current)

    # อ่านใบงานหลังบันทึกเพื่อให้ข้อมูลที่ส่งไปตรงกับที่เก็บจริง
    fresh = await coll.find_one({"_id": oid}) or {}

    # ใบงานปิดแล้ว = เนื้อหานิ่ง สร้าง PDF เก็บไว้เลยตั้งแต่ตอนนี้
    # ลิงก์ที่ IN03 แนบเข้า Maximo จะได้เปิดปุ๊บได้ไฟล์ ไม่ใช่ให้คนกดเป็นคนรอเรนเดอร์
    pdf_result = await pm_pdf.ensure_report_pdf("mdb", station_id, report_id)

    # ใบงาน Maximo 1 ใบครอบหลายอุปกรณ์ — ปิดครบทุกตัวก่อนถึงจะยิงปิด WO
    progress = await pm_flow.wo_completion(fresh.get("wonum") or "")
    if not progress["complete"]:
        return {**result, "pdf": pdf_result, "maximo": {"skipped": "ยังกรอกไม่ครบทุกอุปกรณ์ในใบงาน"},
                "progress": progress}

    maximo_result = await pm_maximo_out.safe_sync_closed(
        coll, oid, fresh, memo=f"closed by {current.username}", kind="mdb"
    )
    return {**result, "pdf": pdf_result, "maximo": maximo_result, "progress": progress}


@router.post("/mdbpmreport/{report_id}/reject")
async def mdbpmreport_reject(
    report_id: str,
    body: pm_flow.PMRejectIn,
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """planner/admin ตีกลับใบงานให้ช่างแก้"""
    station_id = station_id.strip()
    coll = get_mdbpmreport_collection_for(station_id)
    oid = pm_flow.to_oid(report_id)
    return await pm_flow.reject(coll, oid, {"station_id": station_id}, current, body.remark)


@router.post("/mdbpmurl/upload-files", status_code=201)
async def mdbpmurl_upload_files(
    station_id: str = Form(...),
    reportDate: str = Form(...),
    files: List[UploadFile] = File(...),
    issue_id: Optional[str] = Form(None),
    doc_name: Optional[str] = Form(None),
    inspector: Optional[str] = Form(None),
    current: UserClaims = Depends(get_current_user),
):
    """Upload PM PDF files for an MDB"""
    # ตรวจสิทธิ์สถานีก่อนแตะข้อมูล — เดิมเช็คแค่ว่า field ตรงกับ document
    # ซึ่งผู้เรียกคุมได้ทั้งคู่ จึงยิงข้ามสถานีได้
    assert_station_access(current, station_id)
    coll = get_mdbpmurl_coll_upload(station_id)
    rep_coll = get_mdbpmreport_collection_for(station_id)

    pm_date = normalize_pm_date(reportDate)
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="reportDate/pm_date must be YYYY-MM-DD")

    pm_type = "MB"

    # Resolve issue_id
    final_issue_id: str | None = None
    client_issue = (issue_id or "").strip()

    if client_issue:
        yymm = f"{d.year % 100:02d}{d.month:02d}"
        prefix = f"PM-{pm_type}-{yymm}-"
        valid_fmt = client_issue.startswith(prefix)

        url_exists = await coll.find_one({"issue_id": client_issue})
        rep_exists = await rep_coll.find_one({"issue_id": client_issue})
        unique = not (url_exists or rep_exists)

        if valid_fmt and unique:
            final_issue_id = client_issue

    if not final_issue_id:
        final_issue_id = await _next_issue_id_no_conflict(
            coll.database, rep_coll, coll, station_id, pm_type, d, pad=2
        )

    # Resolve year_seq (reuse from existing report if possible)
    year_seq: int | None = None
    rep = await rep_coll.find_one(
        {"issue_id": final_issue_id},
        {"year_seq": 1, "pm_date": 1},
    )
    if rep and rep.get("year_seq") is not None:
        year_seq = int(rep["year_seq"])

    if year_seq is None:
        year_seq = await _next_year_seq(coll.database, station_id, pm_type, d)

    year = d.year

    # Resolve doc_name
    final_doc_name: str | None = None
    if doc_name:
        candidate = doc_name.strip()
        ok_format = candidate.startswith(f"{station_id}_")

        rep_exists = await rep_coll.find_one({"doc_name": candidate})
        url_exists = await coll.find_one({"doc_name": candidate})
        unique = not (rep_exists or url_exists)

        if ok_format and unique:
            final_doc_name = candidate

    if not final_doc_name:
        final_doc_name = f"{station_id}_{year_seq}/{year}"

    # Save files
    subdir = pm_date
    dest_dir = pathlib.Path(UPLOADS_ROOT) / "mdbpmurl" / station_id / subdir
    dest_dir.mkdir(parents=True, exist_ok=True)

    urls: list[str] = []
    metas: list[dict] = []

    for f in files:
        ext = (f.filename.rsplit(".", 1)[-1].lower() if f.filename and "." in f.filename else "")
        if ext != "pdf":
            raise HTTPException(status_code=400, detail=f"Only PDF allowed, got: {ext}")

        data = await f.read()
        if len(data) == 0:
            raise HTTPException(status_code=400, detail=f"Empty file: {f.filename}")
        if not data[:5].startswith(b"%PDF-"):
            raise HTTPException(status_code=400, detail=f"Invalid PDF file: {f.filename}")
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"File too large (> {MAX_FILE_MB} MB)")

        safe = _safe_name(f.filename or f"file_{secrets.token_hex(3)}.pdf")
        dest = dest_dir / safe
        with open(dest, "wb") as out:
            out.write(data)

        urls.append(f"/uploads/mdbpmurl/{station_id}/{subdir}/{safe}")
        metas.append({"name": f.filename, "size": len(data)})

    inspector_clean = (inspector or "").strip() or None

    now = datetime.now(timezone.utc)
    doc = {
        "station_id": station_id,
        "pm_date": pm_date,
        "issue_id": final_issue_id,
        "inspector": inspector_clean,
        "year": year,
        "year_seq": year_seq,
        "doc_name": final_doc_name,
        "urls": urls,
        "meta": {"files": metas},
        "source": "upload-files",
        "createdAt": now,
        "updatedAt": now,
    }
    res = await coll.insert_one(doc)

    return {
        "ok": True,
        "inserted_id": str(res.inserted_id),
        "count": len(urls),
        "urls": urls,
        "issue_id": final_issue_id,
        "year_seq": year_seq,
        "doc_name": final_doc_name,
        "inspector": inspector_clean,
    }


@router.get("/mdbpmurl/list")
async def mdbpmurl_list(
    station_id: str = Query(...),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    current: UserClaims = Depends(get_current_user),
):
    """List PM URL documents for an MDB"""
    coll = get_mdbpmurl_coll_upload(station_id)
    skip = (page - 1) * pageSize

    cursor = coll.find(
        {},
        {"_id": 1, "issue_id": 1, "doc_name": 1, "inspector": 1,
         "pm_date": 1, "reportDate": 1, "urls": 1, "createdAt": 1},
    ).sort([("createdAt", -1), ("_id", -1)]).skip(skip).limit(pageSize)

    items_raw = await cursor.to_list(length=pageSize)
    total = await coll.count_documents({})

    def _pm_date_from(doc: dict) -> str | None:
        s = doc.get("pm_date")
        if isinstance(s, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
            return s
        rd = doc.get("reportDate")
        if isinstance(rd, datetime):
            return rd.astimezone(th_tz).date().isoformat()
        if isinstance(rd, str):
            try:
                dt = datetime.fromisoformat(rd.replace("Z", "+00:00"))
            except Exception:
                try:
                    dt = datetime.fromisoformat(rd).replace(tzinfo=th_tz)
                except Exception:
                    return None
            return dt.astimezone(th_tz).date().isoformat()
        return None

    items = []
    pm_date_arr = []

    for it in items_raw:
        pm_date_str = _pm_date_from(it)
        if pm_date_str:
            pm_date_arr.append(pm_date_str)

        urls = it.get("urls") or []
        first_url = urls[0] if urls else ""

        items.append({
            "id": str(it["_id"]),
            "pm_date": pm_date_str,
            "inspector": it.get("inspector"),
            "doc_name": it.get("doc_name"),
            "issue_id": it.get("issue_id"),
            "createdAt": _ensure_utc_iso(it.get("createdAt")),
            "file_url": first_url,
            "urls": urls,
        })

    return {
        "items": items,
        "pm_date": [d for d in pm_date_arr if d],
        "page": page,
        "pageSize": pageSize,
        "total": total,
    }


# ============================================
# Migration & Photos ZIP
# ============================================

@router.post("/mdbpmreport/migrate/has-photos")
async def migrate_has_photos_endpoint(
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """One-time migration: set has_photos=True for docs that have photos but missing the flag"""
    coll = get_mdbpmreport_collection_for(station_id)
    result = await coll.update_many(
        {
            "has_photos": {"$exists": False},
            "$or": [
                {"photos_pre": {"$ne": {}, "$exists": True}},
                {"photos": {"$ne": {}, "$exists": True}},
            ],
        },
        {"$set": {"has_photos": True}},
    )
    return {"ok": True, "modified": result.modified_count}


@router.get("/mdbpmreport/{report_id}/photos/zip")
async def download_photos_zip(
    report_id: str,
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Download all Pre & Post photos of a report as a single ZIP file"""
    coll = get_mdbpmreport_collection_for(station_id)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one(
        {"_id": oid, "station_id": station_id},
        {"photos_pre": 1, "photos": 1, "has_photos": 1},
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")

    if not doc.get("has_photos"):
        raise HTTPException(status_code=404, detail="No photos found")

    # รวม photos_pre และ photos เข้าด้วยกัน
    all_photos: list[tuple[str, str]] = []  # (zip_path, disk_path)

    photos_pre: dict = doc.get("photos_pre") or {}
    for group, items in photos_pre.items():
        for item in (items or []):
            fname = item.get("filename", "")
            if not fname:
                continue
            disk_path = pathlib.Path(UPLOADS_ROOT) / "mdbpm" / station_id / report_id / "pre" / group / fname
            zip_path = f"pre/{group}/{fname}"
            all_photos.append((zip_path, str(disk_path)))

    photos_post: dict = doc.get("photos") or {}
    for group, items in photos_post.items():
        for item in (items or []):
            fname = item.get("filename", "")
            if not fname:
                continue
            disk_path = pathlib.Path(UPLOADS_ROOT) / "mdbpm" / station_id / report_id / "post" / group / fname
            zip_path = f"post/{group}/{fname}"
            all_photos.append((zip_path, str(disk_path)))

    if not all_photos:
        raise HTTPException(status_code=404, detail="No photos found")

    # สร้าง ZIP ใน memory
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for zip_path, disk_path in all_photos:
            p = pathlib.Path(disk_path)
            if p.exists():
                zf.write(p, arcname=zip_path)

    zip_buffer.seek(0)
    zip_filename = f"photos_{station_id}_{report_id}.zip"

    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{zip_filename}"'},
    )