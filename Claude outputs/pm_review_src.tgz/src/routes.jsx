"use client";
import React, { useEffect, useState } from "react";
import { onSelectionChange } from "@/utils/selection-events";

/** 1) เมนูแม่แบบ + สิทธิ์ที่เห็นเมนูนั้น ๆ */
const baseRoutes = [
  {
    name: "admin",                       // ← จะถูกเปลี่ยนเป็นชื่อคนที่ล็อกอิน
    icon: <i className="fa fa-user" />,
    divider: true,
    allow: ["admin", "owner", "technician", "cs", "planner"],
    showMode: "both", // แสดงทั้งสองโหมด
    pages: [
      {
        layout: "dashboard",
        icon: <i className="fa fa-user" />,
        name: "My profile",
        path: "/dashboard/profile/settings",
        allow: ["*"], // ทุก role เห็นได้
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-question-circle" />,
        name: "Help",
        path: "/dashboard/help",
        allow: ["*"], // ทุก role เห็นได้
      },
      {
        layout: "auth",
        icon: <i className="fa fa-sign-out" />,
        name: "logout",
        path: "/auth/signin/basic",
        allow: ["*"],
      },
    ],
  },
  // { name: "EV Stations", icon: <i className="fa fa-map-marker-alt" />, path: "/dashboard/stations", allow: ["admin", "owner", "technician"], showMode: "both" },
  {
    name: "EV Stations",
    icon: <i className="fa fa-map-marker-alt" />,
    allow: ["admin", "owner", "technician", "cs", "planner"],
    showMode: "both",  // แสดงตลอด
    pages: [
      {
        layout: "dashboard",
        icon: <i className="fa fa-map-marker-alt" />,
        name: "EV Stations (All)",
        path: "/dashboard/stations",
        allow: ["admin", "owner", "technician", "cs", "planner"],
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-robot" />,
        name: "Ai Module",
        path: "/dashboard/ai",
        allow: ["admin", "owner", "planner"],
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-chart-pie" />,
        // หน้าวิเคราะห์ PM — คู่กับ CM Dashboard, ข้อมูลชุดเดียวกับ PM List
        // cs/technician ไม่เห็นส่วนวิเคราะห์ (ถ้าเข้า URL ตรง เพจจะพาไป PM List ให้เอง)
        name: "PM Dashboard",
        path: "/dashboard/pm-dashboard",
        allow: ["admin", "owner", "planner"],
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-table-list" />,
        // ตารางใบงาน PM รวมทุกสถานี — แพทเทิร์นเดียวกับ CM List
        // technician ต้องเห็นด้วย (เหมือน CM List) จะได้ตามงานที่ถูกมอบหมายได้
        name: "PM List",
        path: "/dashboard/pm-list",
        allow: ["admin", "owner", "planner", "technician"],
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-chart-pie" />,
        name: "CM Dashboard",
        path: "/dashboard/cm-dashboard",
        // cs/technician ไม่เห็นส่วนวิเคราะห์ — เมนูของ role นี้คือ CM List ด้านล่าง
        // (ถ้าเข้า URL ตรง หน้าเพจจะพาไป CM List ให้เอง)
        allow: ["admin", "owner", "planner"],
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-table-list" />,
        name: "CM List",
        // ตารางใบงาน CM ที่แยกออกมาจาก CM Dashboard — กรอง In Progress เป็นค่าเริ่มต้น
        path: "/dashboard/cm-list",
        allow: ["admin", "owner", "planner", "cs", "technician"],
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-chart-pie" />,
        name: "Test Dashboard",
        path: "/dashboard/test-dashboard",
        allow: ["admin", "owner", "planner"],
      },
      {
        layout: "dashboard",
        icon: <i className="fa fa-table-list" />,
        name: "Test List",
        path: "/dashboard/test-list",
        allow: ["admin", "owner", "technician", "planner"],
      },
    ],
  },
  { name: "Solar Plant", icon: <i className="fa fa-solar-panel" />, path: "/dashboard/solar-plant", allow: ["admin", "owner", "planner"], showMode: "before" },
  { name: "Power Plant", icon: <i className="fa fa-industry" />, path: "/dashboard/power-plant", allow: ["admin", "owner", "planner"], showMode: "before" },
  // เมนู Company — super_admin / admin จัดการได้ทุกแท็บ, planner เฉพาะ Vendor / Outsource ของบริษัทตัวเอง
  { name: "Company Profile", icon: <i className="fa fa-building" />, path: "/dashboard/company", allow: ["super_admin", "admin", "planner"], showMode: "before" },
  // Users — admin จัดการได้ทุกคน, planner เพิ่ม/แก้ technician / cs / planner ของบริษัทตัวเอง + outsource ของตัวเอง
  { name: "Users Management", icon: <i className="fa fa-users" />, path: "/dashboard/users", allow: ["admin", "planner"], showMode: "before" },
  {
    name: "My Charger",
    icon: <i className="fa fa-charging-station" />,
    allow: ["admin", "owner", "technician", "cs", "planner"],
    showMode: "after",
    pages: [
      { name: "My Charger", icon: <i className="fa fa-charging-station" />, path: "/dashboard/chargers", allow: ["admin", "owner"], showMode: "after" },
      { name: "Device", icon: <i className="fa fa-microchip" />, path: "/dashboard/device", allow: ["admin", "owner", "planner"], showMode: "after" },
      { name: "Configuration", icon: <i className="fa fa-cog" />, path: "/dashboard/setting", allow: ["admin", "owner", "planner"], showMode: "after" },
      { name: "Condition-base", icon: <i className="fa fa-desktop" />, path: "/dashboard/cbm", allow: ["admin", "owner", "planner"], showMode: "after" },
      { name: "MDB/CCB", icon: <i className="fa fa-database" />, path: "/dashboard/mdb", allow: ["admin", "owner", "planner"], showMode: "after" },
      { name: "PM report", icon: <i className="fa fa-file-alt" />, path: "/dashboard/pm-report", allow: ["admin", "owner", "technician", "planner"], showMode: "after" },
      { name: "CM report", icon: <i className="far fa-file" />, path: "/dashboard/cm-report", allow: ["admin", "owner", "technician", "cs", "planner"], showMode: "after" },
      { name: "Test report", icon: <i className="fa fa-check-square" />, path: "/dashboard/test-report", allow: ["admin", "owner", "technician", "planner"], showMode: "after" },
      { name: "AI Fault Intelligence", icon: <i className="fa fa-robot" />, path: "/dashboard/ai/fault-detection", allow: ["admin", "owner", "planner"], showMode: "after" },
    ],
  },
];

/** 2) อ่าน user/role จาก localStorage (ตาม payload ที่ backend ส่งมาใน /login) */
function readAuthFromStorage() {
  try {
    const raw = localStorage.getItem("user") || localStorage.getItem("auth") || "";
    if (!raw) return {};
    const obj = JSON.parse(raw);
    const user = obj?.user ?? obj ?? {};
    return {
      username: user.username || "",
      email: user.email || "",
      role: user.role || "",
      ai_package: user.ai_package ?? null, // ← เพิ่ม
    };
  } catch {
    return {};
  }
}

function getRolesFromStorage() {
  const { role } = readAuthFromStorage();
  if (!role) return [];
  // super_admin เห็นเมนู admin ทั้งหมด + เมนูเฉพาะ super_admin (เช่น Users)
  if (String(role) === "super_admin") return ["super_admin", "admin"];
  return [String(role)];
}

/** 3) กรองตาม allow */
const canSee = (allow, roles = []) => {
  if (!allow) return false;
  if (allow.includes("*")) return true;
  return roles.some(r => allow.includes(r));
};

/** 4) กรองตาม showMode 
 * - "before": แสดงเฉพาะเมื่อยังไม่เลือก charger (Stations, Users)
 * - "after": แสดงเฉพาะเมื่อเลือก charger แล้ว (เมนูอื่นๆ)
 * - "both" หรือ undefined: แสดงทั้งสองโหมด
 */
const canSeeByMode = (showMode, hasChargerSelected) => {
  if (!showMode || showMode === "both") return true;
  if (showMode === "before") return !hasChargerSelected;
  if (showMode === "after") return hasChargerSelected;
  return true;
};

function removeAiModule(items) {
  return items
    .filter(item => !(typeof item.path === "string" && (item.path === "/dashboard/ai" || item.path.startsWith("/dashboard/ai/"))))
    .map(item => ({
      ...item,
      pages: Array.isArray(item.pages) ? removeAiModule(item.pages) : item.pages,
    }));
}

function prune(items, roles, hasChargerSelected = false) {
  return items
    .filter(r => canSee(r.allow ?? ["*"], roles))
    .filter(r => canSeeByMode(r.showMode, hasChargerSelected))
    .map(r => {
      if (Array.isArray(r.pages)) {
        const pages = prune(r.pages, roles, hasChargerSelected);
        return { ...r, pages };
      }
      return r;
    });
}

/** 5) เปลี่ยนชื่อเมนู 'admin' → เป็นชื่อผู้ใช้ที่ล็อกอิน (เช่น username) */
function personalize(items) {
  const { username, email } = readAuthFromStorage();
  const displayName =
    username?.trim() ||
    (email ? String(email).split("@")[0] : "") ||
    ""; // fallback เป็นค่าว่าง ถ้าไม่มี

  return items.map((r) => {
    let name = r.name;
    // เงื่อนไขปรับชื่อ: เดิมตั้งต้นเป็น "admin"
    if (typeof name === "string" && name.toLowerCase() === "admin" && displayName) {
      name = displayName;
    }
    return {
      ...r,
      name,
      pages: Array.isArray(r.pages) ? personalize(r.pages) : r.pages,
    };
  });
}

/** 5.1) ต่อท้าย sn & station_id ให้ path ภายใน (ข้าม external link) */
function withStationParams(path, sn, stationId) {
  if (!path || !sn || !stationId) return path;
  if (/^https?:\/\//i.test(path)) return path; // external link ไม่ต้องแตะ
  const [base, existingQuery = ""] = path.split("?");
  const params = new URLSearchParams(existingQuery);
  params.set("sn", sn);
  params.set("station_id", stationId);
  return `${base}?${params.toString()}`;
}

/** 5.2) ใส่ sn & station_id ให้เมนูที่เป็น per-station (showMode === "after") เท่านั้น
 * เมนูกลุ่ม before/both (Stations, Users ฯลฯ) ไม่ผูกกับสถานี จึงไม่ต่อ params
 */
function applyStationParams(items, stationParams) {
  const sn = stationParams?.sn || "";
  const stationId = stationParams?.stationId || "";
  if (!sn || !stationId) return items;
  return items.map((r) => {
    const next = r.showMode === "after" && r.path
      ? { ...r, path: withStationParams(r.path, sn, stationId) }
      : r;
    return Array.isArray(next.pages)
      ? { ...next, pages: applyStationParams(next.pages, stationParams) }
      : next;
  });
}

/** 6) คำนวณเมนูตาม role + showMode + ใส่ชื่อผู้ใช้ */
export function getRoutes(roles, hasChargerSelected = false, stationParams = null) {
  const r = roles && roles.length ? roles : getRolesFromStorage();
  let filtered = prune(baseRoutes, r, hasChargerSelected);

  const { role, ai_package } = readAuthFromStorage();

  // ถ้า role = owner และ ai_package.enabled != true → ซ่อน Ai Module
  if (role === "owner" && !ai_package?.enabled) {
    filtered = removeAiModule(filtered).filter(
      item => item.path !== "http://203.154.130.132:8001/dashboard"
        && item.path !== "/dashboard/cbm"
    );
  }

  return applyStationParams(personalize(filtered), stationParams);
}


/** 7) React Hook - ตรวจสอบ URL params หรือ localStorage และคำนวณเมนู */
export function useRoutes(rolesFromApp) {
  const [hasChargerSelected, setHasChargerSelected] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(false); // ← เพิ่ม
  const [stationParams, setStationParams] = useState({ sn: "", stationId: "" }); // ← sn/station_id ปัจจุบัน

  useEffect(() => {
    // อ่าน ai_package จาก storage ทุกครั้งที่ storage เปลี่ยน
    const syncAi = () => {
      const { ai_package } = readAuthFromStorage();
      setAiEnabled(!!ai_package?.enabled);
    };
    syncAi();
    window.addEventListener("storage", syncAi);
    return () => window.removeEventListener("storage", syncAi);
  }, []);

  // Check URL params OR localStorage for sn and station_id
  useEffect(() => {
    const checkChargerSelection = () => {
      if (typeof window === "undefined") return;

      // Check URL params first
      const params = new URLSearchParams(window.location.search);
      const snFromUrl = params.get("sn");
      const stationIdFromUrl = params.get("station_id");

      // Also check localStorage - only need selected_sn to indicate charger is selected
      const snFromStorage = localStorage.getItem("selected_sn");
      const stationIdFromStorage = localStorage.getItem("selected_station_id");

      // Has charger if URL has both OR localStorage has sn
      const hasFromUrl = !!snFromUrl && !!stationIdFromUrl;
      const hasFromStorage = !!snFromStorage;

      setHasChargerSelected(hasFromUrl || hasFromStorage);

      // เก็บ sn/station_id ปัจจุบันไว้ต่อท้าย path เมนู (URL ก่อน → localStorage)
      const sn = snFromUrl || snFromStorage || "";
      const stationId = stationIdFromUrl || stationIdFromStorage || "";
      setStationParams((prev) =>
        prev.sn === sn && prev.stationId === stationId ? prev : { sn, stationId }
      );
    };

    // Check on mount
    checkChargerSelection();

    // เดิมที่นี่มี setInterval ทุก 500 ms เพราะ pushState ของ Next.js ไม่ยิง popstate
    // ตอนนี้ selection-events patch pushState/localStorage ให้แล้ว จึงฟัง event เดียวพอ
    return onSelectionChange(checkChargerSelection);
  }, []);

  const routes = React.useMemo(() => {
    let result = getRoutes(rolesFromApp, hasChargerSelected, stationParams);

    return result;
  }, [rolesFromApp, hasChargerSelected, aiEnabled, stationParams]);

  return routes;
}

export { baseRoutes }; // สำหรับ debug/เทสเมนูเต็ม
