"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  flexRender,
  type ColumnDef,
  type CellContext,
  type SortingState,
} from "@tanstack/react-table";
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Input,
  Typography,
} from "@material-tailwind/react";
import { ChevronLeftIcon, ChevronRightIcon, ChevronUpDownIcon } from "@heroicons/react/24/solid";
import { ArrowUpTrayIcon, DocumentArrowDownIcon, PhotoIcon } from "@heroicons/react/24/outline";
import { Dialog, DialogHeader, DialogBody, DialogFooter } from "@material-tailwind/react";
import CCBPMForm from "@/app/dashboard/pm-report/ccb/input_PMreport/components/checkList";
import { apiFetch } from "@/utils/api";
import { useLanguage, type Lang } from "@/utils/useLanguage";
import LoadingOverlay from "@/app/dashboard/components/Loadingoverlay";
import PmPlanForm from "@/app/dashboard/pm-report/components/PmPlanForm";
import PmWorkOrderInfo from "@/app/dashboard/pm-report/components/PmWorkOrderInfo";
import { pmBackRoute } from "@/app/dashboard/pm-report/lib/origin";

// ใบที่เปิดดูหน้าตรวจได้: รออนุมัติ (ยังตัดสินใจได้) และปิดแล้ว (ดูย้อนหลัง)
const REVIEWABLE: ReturnType<typeof toPmFlow>[] = ["wait_approve", "closed"];

import {
  usePmFlow, toPmFlow, woToRow, dropWosWithReport,
  PmStatusBadge, PmFlowTabs, FLOW_TAB_OF, FLOW_TABS,
  type FlowTab,
} from "@/app/dashboard/pm-report/components/flow";
import TableSkeletonRows from "@/components/TableSkeletonRows";
// ==================== TRANSLATIONS ====================
const T = {
  pageTitle: { th: "Preventive Maintenance Checklist - CCB", en: "Preventive Maintenance Checklist - CCB" },
  pageSubtitle: { th: "ค้นหาและดาวน์โหลดเอกสารรายงานการบำรุงรักษา (PM report)", en: "Search and download maintenance reports (PM Report)" },
  upload: { th: "อัปโหลด", en: "Upload" },
  add: { th: "+เพิ่ม", en: "+Add" },
  postPm: { th: "Post-PM", en: "Post-PM" },
  cancel: { th: "ยกเลิก", en: "Cancel" },
  uploadBtn: { th: "อัปโหลด", en: "Upload" },
  colNo: { th: "ลำดับ", en: "No." },
  colDocName: { th: "ชื่อเอกสาร", en: "Document Name" },
  colIssueId: { th: "รหัสเอกสาร", en: "Issue ID" },
  colPmDate: { th: "วันที่ PM", en: "PM Date" },
  colInspector: { th: "ผู้ตรวจสอบ", en: "Inspector" },
  colPdf: { th: "PDF", en: "PDF" },
  entriesPerPage: { th: "รายการต่อหน้า", en: "entries per page" },
  page: { th: "หน้า", en: "Page" },
  of: { th: "จาก", en: "of" },
  search: { th: "ค้นหา", en: "Search" },
  loading: { th: "กำลังโหลด…", en: "Loading…" },
  noData: { th: "ไม่มีข้อมูล", en: "No data" },
  selectStationFirst: { th: "กรุณาเลือกสถานีจากแถบบนก่อน", en: "Please select a station first" },
  noFile: { th: "ไม่มีไฟล์", en: "No file" },
  dialogTitle: { th: "เลือกวันที่รายงาน (PM Report)", en: "Select Report Date (PM Report)" },
  docNameLabel: { th: "Document Name / ชื่อเอกสาร", en: "Document Name" },
  issueIdLabel: { th: "Issue id / รหัสเอกสาร", en: "Issue ID" },
  inspectorLabel: { th: "Inspector / ผู้ตรวจสอบ", en: "Inspector" },
  pmDateLabel: { th: "PM Date / วันที่ตรวจสอบ", en: "PM Date" },
  filesSelected: { th: "ไฟล์ที่เลือก:", en: "Files selected:" },
  filesUnit: { th: "ไฟล์", en: "file(s)" },
  alertSelectStation: { th: "กรุณาเลือกสถานีก่อน", en: "Please select a station first" },
  alertPdfOnly: { th: "รองรับเฉพาะไฟล์ PDF เท่านั้น", en: "Only PDF files are supported" },
  alertInvalidDate: { th: "รูปแบบวันที่ไม่ถูกต้อง (ควรเป็น YYYY-MM-DD)", en: "Invalid date format (should be YYYY-MM-DD)" },
  alertUploadFailed: { th: "อัปโหลดไม่สำเร็จ:", en: "Upload failed:" },
  alertUploadSuccess: { th: "อัปโหลดสำเร็จ", en: "Upload successful" },
  alertUploadError: { th: "เกิดข้อผิดพลาดระหว่างอัปโหลด", en: "Error during upload" },
  uploadPdf: { th: "อัปโหลด PDF", en: "Upload PDF" },
  preview: { th: "พรีวิว", en: "Preview" },
  downloadPhotos: { th: "ดาวน์โหลดรูปภาพ", en: "Download Photos" },
  loadingData: { th: "กำลังโหลดข้อมูล...", en: "Loading data..." },
  colStatus: { th: "สถานะ", en: "Status" },
  woFromMaximo: { th: "ใบงานจาก Maximo", en: "Work order from Maximo" },
  fillPmBtn: { th: "กรอก PM", en: "Fill PM" },
  fixAndResubmit: { th: "แก้ไข", en: "Fix" },
  approve: { th: "อนุมัติ", en: "Approve" },
  viewReport: { th: "ดูข้อมูล", en: "View" },
  reject: { th: "ตีกลับ", en: "Reject" },
  approveTitle: { th: "อนุมัติปิดใบงาน PM", en: "Approve and close PM work order" },
  approveConfirm: { th: "ยืนยันอนุมัติปิดใบงานนี้หรือไม่?", en: "Close this work order?" },
  rejectTitle: { th: "ตีกลับใบงานให้ช่างแก้", en: "Send back to technician" },
  rejectRemarkLabel: { th: "เหตุผลที่ตีกลับ", en: "Reason" },
  rejectRemarkRequired: { th: "กรุณาระบุเหตุผลที่ตีกลับ", en: "A reason is required" },
  approvedBy: { th: "อนุมัติโดย", en: "Approved by" },
  rejectedBy: { th: "ตีกลับโดย", en: "Sent back by" },
  approveSuccess: { th: "อนุมัติปิดใบงานแล้ว", en: "Work order closed" },
  rejectSuccess: { th: "ตีกลับใบงานให้ช่างแล้ว", en: "Sent back to technician" },
  approveFailed: { th: "อนุมัติไม่สำเร็จ:", en: "Approve failed:" },
  rejectFailed: { th: "ตีกลับไม่สำเร็จ:", en: "Reject failed:" },
  confirmBtn: { th: "ยืนยัน", en: "Confirm" },
  planSaved: { th: "บันทึกแผนแล้ว", en: "Plan saved" },
};

const t = (key: keyof typeof T, lang: Lang): string => T[key][lang];

type TData = {
  id?: string;
  issue_id?: string;
  doc_name?: string;
  pm_date?: string;
  position: string;
  office: string;
  inspector?: string;
  side?: string;
  has_photos?: boolean;
  status?: string;
  reject_remark?: string;
  rejected_by?: string;
  approved_by?: string;
  /** แถวใบงาน Maximo ที่ยังไม่มีเอกสาร PM — ด่าน Open ของ flow */
  kind?: "report" | "wo";
  wonum?: string;
  planning_status?: string;
  selected_equipment_label?: string;
  /** ช่างที่ planner มอบหมาย — คนละอย่างกับ inspector ที่เป็นคนกรอกจริง */
  assignees_label?: string;
};

type Props = { token?: string; apiBase?: string; };

const BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";
const REPORT_PREFIX = "ccbpmreport";
const URL_PREFIX = "ccbpmurl";
const PM_TYPE_CODE = "CC";

function makePrefix(typeCode: string, dateISO: string) {
  const d = new Date(dateISO || new Date().toISOString().slice(0, 10));
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `PM-${typeCode}-${yy}${mm}-`;
}

function nextIssueIdFor(typeCode: string, dateISO: string, latestFromDb?: string) {
  const prefix = makePrefix(typeCode, dateISO);
  const s = String(latestFromDb || "").trim();
  if (!s || !s.startsWith(prefix)) return `${prefix}01`;
  const m = s.match(/(\d+)$/);
  const pad = m ? m[1].length : 2;
  const n = (m ? parseInt(m[1], 10) : 0) + 1;
  return `${prefix}${n.toString().padStart(pad, "0")}`;
}

async function fetchLatestIssueIdAcrossLists(stationId: string, dateISO: string, apiBase: string, fetchOpts: RequestInit) {
  const build = (path: string) => {
    const u = new URL(`${apiBase}${path}`);
    u.searchParams.set("station_id", stationId);
    u.searchParams.set("page", "1");
    u.searchParams.set("pageSize", "50");
    u.searchParams.set("_ts", String(Date.now()));
    return u.toString();
  };

  const [a, b] = await Promise.allSettled([
    apiFetch(build(`/${REPORT_PREFIX}/list`), fetchOpts),
    apiFetch(build(`/${URL_PREFIX}/list`), fetchOpts),
  ]);

  let ids: string[] = [];
  for (const r of [a, b]) {
    if (r.status === "fulfilled" && r.value.ok) {
      const j = await r.value.json();
      const items: any[] = Array.isArray(j?.items) ? j.items : [];
      ids = ids.concat(items.map((it) => String(it?.issue_id || "")).filter(Boolean));
    }
  }

  const prefix = makePrefix(PM_TYPE_CODE, dateISO);
  const same = ids.filter((x) => x.startsWith(prefix));
  if (!same.length) return null;

  const toTail = (s: string) => {
    const m = s.match(/(\d+)$/);
    return m ? parseInt(m[1], 10) : -1;
  };
  return same.reduce((acc, cur) => (toTail(cur) > toTail(acc) ? cur : acc), same[0]);
}

function makeDocNameParts(stationId: string, dateISO: string) {
  const d = new Date(dateISO || new Date().toISOString().slice(0, 10));
  const year = d.getFullYear();
  const prefix = `${stationId}_`;
  const suffix = `/${year}`;
  return { year, prefix, suffix };
}

function nextDocNameFor(stationId: string, dateISO: string, latestFromDb?: string) {
  const { prefix, suffix } = makeDocNameParts(stationId, dateISO);
  const s = String(latestFromDb || "").trim();
  if (!s || !s.startsWith(prefix) || !s.endsWith(suffix)) {
    return `${prefix}1${suffix}`;
  }
  const inside = s.slice(prefix.length, s.length - suffix.length);
  const cur = parseInt(inside, 10);
  const nextIndex = isNaN(cur) ? 1 : cur + 1;
  return `${prefix}${nextIndex}${suffix}`;
}

async function fetchPreviewDocName(stationId: string, pmDate: string): Promise<string | null> {
  const u = new URL(`${BASE}/ccbpmreport/preview-docname`);
  u.searchParams.set("station_id", stationId);
  u.searchParams.set("pm_date", pmDate);
  const r = await apiFetch(u.toString(), { credentials: "include" });
  if (!r.ok) return null;
  const j = await r.json();
  return (j && typeof j.doc_name === "string") ? j.doc_name : null;
}

async function fetchLatestDocName(stationId: string, dateISO: string): Promise<string | null> {
  const u = new URL(`${BASE}/ccbpmreport/latest-docname`);
  u.searchParams.set("station_id", stationId);
  u.searchParams.set("pm_date", dateISO);
  u.searchParams.set("_ts", String(Date.now()));
  const r = await apiFetch(u.toString(), { credentials: "include", cache: "no-store" });
  if (!r.ok) return null;
  const j = await r.json();
  return (j && typeof j.doc_name === "string") ? j.doc_name : null;
}

type Me = { id: string; username: string; email: string; role: string; company: string; tel: string; };

export default function SearchDataTables({ token, apiBase = BASE }: Props) {
  const { lang } = useLanguage();
  // true au depart : le squelette doit occuper la hauteur finale des le premier
  // rendu, sinon le tableau grandit de 0 a N lignes quand les donnees arrivent.
  const [loading, setLoading] = useState(true);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [data, setData] = useState<TData[]>([]);
  const [filtering, setFiltering] = useState("");
  const [issueId, setIssueId] = useState<string>("");
  const searchParams = useSearchParams();
  const [stationId, setStationId] = useState<string | null>(null);
  const [docName, setDocName] = useState<string>("");
  const [me, setMe] = useState<Me | null>(null);
  const [inspector, setInspector] = useState<string>("");
  const [pageLoading, setPageLoading] = useState(true);
  const [toast, setToast] = useState<{ show: boolean; type: "success" | "error" | "warning" | "info"; message: string }>({ show: false, type: "info", message: "" });
  const showToast = (type: "success" | "error" | "warning" | "info", message: string, duration = 4000) => {
    setToast({ show: true, type, message });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), duration);
  };

  const todayStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }, []);

  useEffect(() => {
    const sidFromUrl = searchParams.get("station_id");
    if (sidFromUrl) { setStationId(sidFromUrl); localStorage.setItem("selected_station_id", sidFromUrl); return; }
    setStationId(localStorage.getItem("selected_station_id"));
  }, [searchParams]);

  useEffect(() => {
    (async () => {
      try {
        const res = await apiFetch(`${apiBase}/me`, { method: "GET", credentials: "include" });
        if (!res.ok) return;
        const data: Me = await res.json();
        setMe(data);
        setInspector((prev) => prev || data.username || "");
      } catch (err) { console.error("fetch /me error:", err); }
    })();
  }, [apiBase]);

  const router = useRouter();
  const pathname = usePathname();
  const editId = searchParams.get("edit_id") ?? "";
  const mode: "list" | "form" = (searchParams.get("view") === "form" || !!editId) ? "form" : "list";

  const setView = (view: "list" | "form", { replace = false } = {}) => {
    const params = new URLSearchParams(searchParams.toString());
    if (view === "form") { params.set("view", "form"); params.delete("pmtab"); }
    else { params.delete("view"); params.delete("edit_id"); params.delete("pmtab"); }
    router[replace ? "replace" : "push"](`${pathname}?${params.toString()}`, { scroll: false });
  };

  const useHttpOnlyCookie = true;
  function makeHeaders(): Record<string, string> {
    const h: Record<string, string> = { "Content-Type": "application/json" };
    if (!useHttpOnlyCookie) {
    }
    return h;
  }
  const FetchOpts: RequestInit = { headers: makeHeaders(), ...(useHttpOnlyCookie ? { credentials: "include" as const } : {}), cache: "no-store" };

  function formatDate(iso?: string, currentLang: Lang = lang) {
    if (!iso) return "-";
    const d = /^\d{4}-\d{2}-\d{2}$/.test(iso) ? new Date(iso + "T00:00:00Z") : new Date(iso);
    if (isNaN(d.getTime())) return "-";
    return d.toLocaleDateString(currentLang === "en" ? "en-GB" : "th-TH-u-ca-gregory", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "UTC" });
  }

  function toISODateOnly(s?: string) {
    if (!s) return "";
    try {
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
      const d = new Date(s);
      if (isNaN(d.getTime())) return "";
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    } catch { return ""; }
  }

  function resolveFileHref(v: any, apiBase: string) {
    if (!v) return "";
    if (typeof v === "object") return resolveFileHref(v.url ?? v.href ?? v.link ?? "", apiBase);
    const s = String(v).trim();
    if (!s) return "";
    try { return new URL(s).toString(); } catch { }
    if (s.startsWith("/")) return `${apiBase}${s}`;
    if (/^[a-f0-9]{24}$/i.test(s)) return `${apiBase}/files/${s}`;
    return `${apiBase}/${s}`;
  }

  function normalizeAnyDate(v: any): string {
    if (!v) return "";
    if (typeof v === "object" && v.$date) return toISODateOnly(String(v.$date));
    if (v instanceof Date) return toISODateOnly(v.toISOString());
    if (typeof v === "number") return toISODateOnly(new Date(v).toISOString());
    if (typeof v === "string") return toISODateOnly(v);
    return "";
  }

  function pickDateFromItem(it: any): string {
    for (const v of [it?.pm_date, it?.reportDate, it?.job?.date, it?.submittedAt, it?.timestamp, it?.createdAt, it?.updatedAt, it?.date]) {
      const d = normalizeAnyDate(v);
      if (d) return d;
    }
    return "";
  }

  function extractDocIdFromAnything(x: any): string {
    if (!x) return "";
    const raw = (x._id !== undefined ? x._id : x.id) ?? "";
    let id = "";
    if (raw && typeof raw === "object") id = raw.$oid || raw.oid || raw.$id || "";
    else id = String(raw || "");
    if (/^[a-fA-F0-9]{24}$/.test(id)) return id;
    const s = typeof x === "string" ? x : JSON.stringify(x);
    const m = s.match(/[A-Fa-f0-9]{24}/);
    return m ? m[0] : "";
  }

  const { wos, reloadWos, canApprove, canPlan, flowTab, setFlowTab } = usePmFlow("ccb", stationId);

  // ==================== APPROVE / REJECT (planner, admin) ====================
  const [approveRow, setApproveRow] = useState<TData | null>(null);
  const [rejectRow, setRejectRow] = useState<TData | null>(null);
  const [rejectRemark, setRejectRemark] = useState("");
  const [acting, setActing] = useState(false);

  const onApprove = async () => {
    if (!approveRow?.id || !stationId || acting) return;
    setActing(true);
    try {
      const res = await apiFetch(
        `${apiBase}/ccbpmreport/${encodeURIComponent(approveRow.id)}/approve?station_id=${encodeURIComponent(stationId)}`,
        { method: "POST", credentials: "include" }
      );
      if (!res.ok) { const j = await res.json().catch(() => ({})); throw new Error(j?.detail || `HTTP ${res.status}`); }
      setApproveRow(null);
      showToast("success", t("approveSuccess", lang));
      await fetchRows();
    } catch (e: any) {
      showToast("error", `${t("approveFailed", lang)} ${e?.message ?? e}`);
    } finally { setActing(false); }
  };

  const onReject = async () => {
    if (!rejectRow?.id || !stationId || acting) return;
    const remark = rejectRemark.trim();
    if (!remark) { showToast("warning", t("rejectRemarkRequired", lang)); return; }
    setActing(true);
    try {
      const res = await apiFetch(
        `${apiBase}/ccbpmreport/${encodeURIComponent(rejectRow.id)}/reject?station_id=${encodeURIComponent(stationId)}`,
        { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ remark }) }
      );
      if (!res.ok) { const j = await res.json().catch(() => ({})); throw new Error(j?.detail || `HTTP ${res.status}`); }
      setRejectRow(null); setRejectRemark("");
      showToast("success", t("rejectSuccess", lang));
      await fetchRows();
    } catch (e: any) {
      showToast("error", `${t("rejectFailed", lang)} ${e?.message ?? e}`);
    } finally { setActing(false); }
  };

  // ด่านวางแผน — เข้าจากแถวในตารางเหมือน CM (?view=form&planning=1&wonum=…)
  const planningWonum = searchParams.get("planning") === "1" ? (searchParams.get("wonum") ?? "") : "";

  // หน้าข้อมูลใบงานก่อนเริ่มกรอก (?wo_info=1)
  const woInfoWonum = searchParams.get("wo_info") === "1" ? (searchParams.get("wonum") ?? "") : "";

  // กด "เริ่ม PM" → เปิดฟอร์มกรอก (started=1 กันไม่ให้ถามซ้ำในฟอร์ม)
  const startPmFromInfo = (snFromWo?: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.delete("wo_info");

    params.set("started", "1");
    params.delete("pmtab");
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  const leaveWoInfo = () => {
    // มาจากหน้า PM List → กลับไปหน้านั้น ไม่ใช่ตาราง tab ที่ผู้ใช้ไม่เคยเปิด
    const back = pmBackRoute(searchParams);
    if (back) {
      router.push(back);
      return;
    }
    const params = new URLSearchParams(searchParams.toString());
    ["view", "wo_info", "wonum", "started", "pmtab"].forEach((k) => params.delete(k));
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  const goPlan = (row: TData) => {
    if (!row.wonum) return;
    const params = new URLSearchParams(searchParams.toString());
    params.set("view", "form"); params.set("planning", "1"); params.set("wonum", row.wonum);
    params.delete("edit_id");
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  // ช่างเริ่มกรอกเอกสารจากใบงานที่วางแผนแล้ว
  const goFillPm = (row: TData) => {
    const params = new URLSearchParams(searchParams.toString());
    // เปิดหน้าข้อมูลใบงาน (อ่านอย่างเดียว) ก่อน ช่างกด "เริ่ม PM" ถึงจะเข้าฟอร์ม
    params.set("view", "form"); params.set("wo_info", "1");
    params.delete("planning"); params.delete("edit_id");
    if (row.wonum) params.set("wonum", row.wonum);
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  // เปิดเอกสารที่ช่างส่งมาเพื่อตรวจก่อนอนุมัติ
  const goReview = (row: TData) => {
    if (!row.id) return;
    const params = new URLSearchParams(searchParams.toString());
    params.set("view", "form"); params.set("edit_id", row.id);
    // โหมดอนุมัติ (มีปุ่ม Reject/Approve) เฉพาะผู้มีสิทธิ์ + ใบที่ยังรออนุมัติอยู่
    // ใบที่ปิดไปแล้วไม่มีอะไรให้ตัดสินใจ เปิดดูอย่างเดียวเหมือนกันทุก role
    const canDecide = canApprove && toPmFlow(row) === "wait_approve";
    params.set(canDecide ? "approve" : "review", "1");
    params.delete("action"); params.delete("pmtab");
    params.delete("planning"); params.delete("wo_info"); params.delete("wonum");
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  const leavePlanning = () => {
    const back = pmBackRoute(searchParams);
    if (back) { router.push(back); return; }
    const params = new URLSearchParams(searchParams.toString());
    ["view", "planning", "wonum", "edit_id"].forEach((k) => params.delete(k));
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  const fetchRows = async (signal?: AbortSignal) => {
    if (!stationId) { setData([]); setLoading(false); setPageLoading(false); return; }
    setLoading(true);
    try {
      const makeURL = (path: string) => {
        const u = new URL(`${apiBase}${path}`);
        u.searchParams.set("station_id", stationId);
        u.searchParams.set("page", "1");
        u.searchParams.set("pageSize", "50");
        u.searchParams.set("_ts", String(Date.now()));
        return u.toString();
      };
      const [pmRes, urlRes] = await Promise.allSettled([
        apiFetch(makeURL(`/${REPORT_PREFIX}/list`), FetchOpts),
        apiFetch(makeURL(`/${URL_PREFIX}/list`), FetchOpts),
      ]);

      let pmItems: any[] = [], urlItems: any[] = [];
      if (pmRes.status === "fulfilled" && pmRes.value.ok) { const j = await pmRes.value.json(); if (Array.isArray(j?.items)) pmItems = j.items; }
      if (urlRes.status === "fulfilled" && urlRes.value.ok) { const j = await urlRes.value.json(); if (Array.isArray(j?.items)) urlItems = j.items; }

      const pmRows: TData[] = pmItems.map((it: any) => {
        const isoDay = pickDateFromItem(it);
        const rawUploaded = it.file_url ?? (Array.isArray(it.urls) ? (it.urls[0]?.url ?? it.urls[0]) : it.url) ?? it.file ?? it.path;
        const uploadedUrl = resolveFileHref(rawUploaded, apiBase);
        function extractId(x: any): string {
          if (!x) return "";
          const raw = (x._id !== undefined ? x._id : x.id) ?? "";
          if (raw && typeof raw === "object") return raw.$oid || raw.oid || raw.$id || "";
          const s = String(raw || "");
          return /^[a-fA-F0-9]{24}$/.test(s) ? s : "";
        }
        const id = extractId(it);
        const generatedUrl = id ? `${apiBase}/pdf/ccb/${encodeURIComponent(id)}/export` : "";
        const fileUrl = uploadedUrl || generatedUrl;
        return { id, issue_id: (it.issue_id ? String(it.issue_id) : "") || extractDocIdFromAnything(fileUrl) || "", doc_name: it.doc_name ? String(it.doc_name) : "", pm_date: isoDay, position: isoDay, office: fileUrl, inspector: (it.inspector ?? it.job?.inspector ?? "") as string, side: (it.side ?? it.job?.side ?? "") as string, has_photos: Boolean(it.has_photos), wonum: (it.wonum ?? "") as string, status: (it.status ?? "") as string, reject_remark: (it.reject_remark ?? "") as string, rejected_by: (it.rejected_by ?? "") as string, approved_by: (it.approved_by ?? "") as string } as TData;
      });

      const urlRows: TData[] = urlItems.map((it: any) => {
        const isoDay = pickDateFromItem(it);
        const raw = it.file_url ?? (Array.isArray(it.urls) ? (it.urls[0]?.url ?? it.urls[0]) : it.url) ?? it.file ?? it.path;
        const href = resolveFileHref(raw, apiBase);
        return { issue_id: (it.issue_id ? String(it.issue_id) : "") || extractDocIdFromAnything(href) || "", doc_name: it.doc_name ? String(it.doc_name) : "", pm_date: isoDay, position: isoDay, office: href, inspector: (it.inspector ?? it.job?.inspector ?? "") as string, side: (it.side ?? it.job?.side ?? "") as string } as TData;
      });

      // ใบงาน Maximo = ด่านแรกของ flow — โชว์รวมในตารางเดียวกัน
      const woRows: TData[] = dropWosWithReport(
        wos.map((w) => ({ ...woToRow(w, t("woFromMaximo", lang)), position: w.pm_date ?? "", office: "" } as TData)),
        pmRows
      );

      const allRows = [...woRows, ...pmRows, ...urlRows].sort((a, b) => {
        const da = (a.position ?? "") as string, db = (b.position ?? "") as string;
        if (!da && !db) return 0; if (!da) return 1; if (!db) return -1;
        return da < db ? 1 : da > db ? -1 : 0;
      });
      setData(allRows);
    } catch (err: any) { if (err?.name !== "AbortError") { console.error("fetch error:", err); setData([]); } }
    finally { setLoading(false); setPageLoading(false); }
  };

  useEffect(() => { fetchRows(); }, [apiBase, stationId]);
  useEffect(() => { const ac = new AbortController(); fetchRows(ac.signal); return () => ac.abort(); }, [apiBase, stationId, searchParams.toString()]);

  function appendParam(u: string, key: string, val?: string) {
    if (!val) return u;
    const url = new URL(u, apiBase);
    if (!url.searchParams.has(key)) url.searchParams.set(key, val);
    return url.toString();
  }

  function buildHtmlLinks(baseUrl?: string) {
    const u = (baseUrl || "").trim();
    if (!u) return { previewHref: "", isPdfEndpoint: false };
    const isPdfEndpoint = /\/pdf\/(charger|mdb|ccb|cbbox|station)\/[A-Fa-f0-9]{24}\/export(?:\b|$)/.test(u);
    if (isPdfEndpoint) {
      let finalUrl = u;
      if (stationId) finalUrl = appendParam(finalUrl, "station_id", stationId);
      finalUrl = appendParam(finalUrl, "lang", lang);
      const photosBase = (process.env.NEXT_PUBLIC_PHOTOS_BASE_URL as string) || (typeof window !== "undefined" ? window.location.origin : "");
      if (photosBase) finalUrl = appendParam(finalUrl, "photos_base_url", photosBase);
      finalUrl = appendParam(finalUrl, "dl", "0");
      return { previewHref: finalUrl, isPdfEndpoint: true };
    }
    return { previewHref: u, isPdfEndpoint: false };
  }

  const columns: ColumnDef<TData, unknown>[] = useMemo(() => [
    {
      id: "no", header: () => t("colNo", lang), enableSorting: false, size: 60, minSize: 50, maxSize: 80,
      cell: (info: CellContext<TData, unknown>) => { const { pageIndex, pageSize } = info.table.getState().pagination; return pageIndex * pageSize + info.row.index + 1; },
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.doc_name || "—", id: "name", header: () => t("colDocName", lang),
      cell: (info: CellContext<TData, unknown>) => (<span className="tw-block tw-truncate" title={info.getValue() as string}>{info.getValue() as React.ReactNode}</span>),
      size: 150, minSize: 100, maxSize: 200, meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      // เลขใบงาน Maximo — ใบเก่าที่ยังไม่ผูก wonum ถอยไปใช้ issue_id เดิม
      accessorFn: (row) => row.wonum || row.issue_id || "—", id: "issue_id", header: () => t("colIssueId", lang),
      cell: (info) => (<span className="tw-block tw-truncate" title={info.getValue() as string}>{info.getValue() as React.ReactNode}</span>),
      size: 140, minSize: 100, maxSize: 180, meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.pm_date, id: "date", header: () => t("colPmDate", lang),
      cell: (info) => (<span className="tw-whitespace-nowrap">{formatDate(info.getValue() as string, lang)}</span>),
      size: 120, minSize: 100, maxSize: 150, meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.inspector || "-", id: "inspector", header: () => t("colInspector", lang),
      cell: (info: CellContext<TData, unknown>) => (<span className="tw-block tw-truncate" title={info.getValue() as string}>{info.getValue() as React.ReactNode}</span>),
      size: 120, minSize: 80, maxSize: 160, meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => toPmFlow(row), id: "status", header: () => t("colStatus", lang),
      cell: (info: CellContext<TData, unknown>) => {
        const row = info.row.original;
        const flow = toPmFlow(row);
        // ผู้ที่ตัดสินใจล่าสุดสำคัญกว่าตัวสถานะเปล่า ๆ — ใส่ไว้ใน tooltip
        const hint = row.kind === "wo"
          ? [row.selected_equipment_label, row.assignees_label].filter(Boolean).join(" — ") || undefined
          : flow === "closed" && row.approved_by
            ? `${t("approvedBy", lang)}: ${row.approved_by}`
            : flow === "rejected" && row.reject_remark
              ? `${t("rejectedBy", lang)}: ${row.rejected_by || "-"} — ${row.reject_remark}`
              : undefined;
        return <PmStatusBadge flow={flow} title={hint} />;
      },
      size: 130, minSize: 100, maxSize: 170, meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.office, id: "pdf", header: () => t("colPdf", lang), enableSorting: false,
      cell: (info: CellContext<TData, unknown>) => {
        const row = info.row.original;

        // แถวใบงาน Maximo — เข้าหน้าวางแผนด้วยการคลิกที่แถว เหลือปุ่ม "กรอก PM" อย่างเดียว
        if (row.kind === "wo") {
          if (toPmFlow(row) !== "wo_planned") return <span className="tw-text-blue-gray-300">—</span>;
          return (
            <div className="tw-flex tw-items-center tw-justify-center">
              <Button size="sm" color="blue" variant="outlined"
                className="tw-shrink-0 tw-text-[10px] sm:tw-text-xs tw-px-2 sm:tw-px-3 tw-py-1 tw-min-h-0 tw-h-auto tw-font-medium tw-rounded-md"
                onClick={(e) => { e.stopPropagation(); goFillPm(row); }}>
                {t("fillPmBtn", lang)}
              </Button>
            </div>
          );
        }

        const url = info.getValue() as string | undefined;
        const hasUrl = typeof url === "string" && url.length > 0;
        if (!hasUrl) return <span className="tw-text-blue-gray-300" title={t("noFile", lang)}>—</span>;
        const { previewHref } = buildHtmlLinks(url);
        const rowSide = info.row.original.side;
        // ใบเก่าที่ค้างอยู่ด่าน Pre (ก่อนตัด Pre-PM ออก) — เปิดฟอร์มเดิมกรอกต่อให้จบ
        if (rowSide === "pre") {
          return (
            <div className="tw-flex tw-items-center tw-justify-center">
              <Button size="sm" color="blue" variant="outlined"
                className="tw-shrink-0 tw-text-[10px] sm:tw-text-xs lg:tw-text-sm tw-px-2 sm:tw-px-3 lg:tw-px-4 tw-py-1 sm:tw-py-1.5 tw-min-h-0 tw-h-auto tw-font-medium tw-rounded-md"
                onClick={() => {
                  const params = new URLSearchParams(searchParams.toString());
                  params.set("view", "form"); params.set("edit_id", info.row.original.id || ""); params.delete("action"); params.delete("pmtab");
                  router.push(`${pathname}?${params.toString()}`, { scroll: false });
                }}>{t("postPm", lang)}</Button>
            </div>
          );
        } else {
          return (
            <div className="tw-flex tw-items-center tw-justify-center tw-gap-1">
              {/* ด่านอนุมัติปิดงาน — เห็นเฉพาะ planner/admin และเฉพาะใบที่ช่างส่งมาแล้ว */}
              {canApprove && toPmFlow(info.row.original) === "wait_approve" && (
                <>
                  <Button size="sm" color="green" variant="outlined"
                    className="tw-shrink-0 tw-text-[10px] sm:tw-text-xs tw-px-2 sm:tw-px-3 tw-py-1 tw-min-h-0 tw-h-auto tw-font-medium tw-rounded-md"
                    onClick={() => goReview(info.row.original)}>{t("approve", lang)}</Button>
                  <Button size="sm" color="amber" variant="outlined"
                    className="tw-shrink-0 tw-text-[10px] sm:tw-text-xs tw-px-2 sm:tw-px-3 tw-py-1 tw-min-h-0 tw-h-auto tw-font-medium tw-rounded-md"
                    onClick={() => { setRejectRemark(""); setRejectRow(info.row.original); }}>{t("reject", lang)}</Button>
                </>
              )}
              {/* ยังไม่มีสิทธิ์อนุมัติ (เช่นช่างเจ้าของงาน) → เปิดดูใบเดิมได้แบบอ่านอย่างเดียว */}
              {REVIEWABLE.includes(toPmFlow(info.row.original))
                && !(canApprove && toPmFlow(info.row.original) === "wait_approve") && (
                <Button size="sm" color="blue-gray" variant="outlined"
                  className="tw-shrink-0 tw-text-[10px] sm:tw-text-xs tw-px-2 sm:tw-px-3 tw-py-1 tw-min-h-0 tw-h-auto tw-font-medium tw-rounded-md"
                  onClick={() => goReview(info.row.original)}>{t("viewReport", lang)}</Button>
              )}
              {/* โดนตีกลับ → ช่างเปิดฟอร์มเดิมกลับเข้าไปแก้แล้วส่งใหม่ */}
              {toPmFlow(info.row.original) === "rejected" && (
                <Button size="sm" color="amber" variant="outlined"
                  className="tw-shrink-0 tw-text-[10px] sm:tw-text-xs tw-px-2 sm:tw-px-3 tw-py-1 tw-min-h-0 tw-h-auto tw-font-medium tw-rounded-md"
                  title={info.row.original.reject_remark || ""}
                  onClick={() => goFillPm(info.row.original)}>{t("fixAndResubmit", lang)}</Button>
              )}
              <a
                aria-label={t("preview", lang)}
                href={previewHref}
                target="_blank"
                rel="noopener noreferrer"
                className="tw-inline-flex tw-items-center tw-justify-center tw-rounded-md tw-p-1.5 sm:tw-p-2 tw-text-red-600 hover:tw-text-red-800 hover:tw-bg-red-50 tw-transition-colors"
                title={t("preview", lang)}
              >
                <DocumentArrowDownIcon className="tw-h-5 tw-w-5 sm:tw-h-6 sm:tw-w-6" />
              </a>
              {info.row.original.has_photos && (
                <a
                  aria-label={t("downloadPhotos", lang)}
                  href={`${BASE}/ccbpmreport/${info.row.original.id}/photos/zip?station_id=${encodeURIComponent(stationId || "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="tw-inline-flex tw-items-center tw-justify-center tw-rounded-md tw-p-1.5 sm:tw-p-2 tw-text-green-600 hover:tw-text-green-800 hover:tw-bg-green-50 tw-transition-colors"
                  title={t("downloadPhotos", lang)}
                >
                  <PhotoIcon className="tw-h-5 tw-w-5 sm:tw-h-6 sm:tw-w-6" />
                </a>
              )}
            </div>
          );
        }
      },
      size: 100, minSize: 80, maxSize: 140, meta: { headerAlign: "center", cellAlign: "center" },
    },
  ], [lang, searchParams, pathname, router, stationId, canApprove, canPlan]);

  function sameUser(a?: string, b?: string) { return String(a ?? "").trim().toLowerCase() === String(b ?? "").trim().toLowerCase(); }

  const visibleData = useMemo(() => {
    const username = me?.username;
    return data.filter((row) => {
      if (FLOW_TAB_OF[toPmFlow(row)] !== flowTab) return false;
      if (row.side !== "pre") return true;
      if (!username) return false;
      return sameUser(row.inspector, username);
    });
  }, [data, me?.username, flowTab]);

  // แท็บ Open มีแต่ใบงานที่ยังไม่ได้มอบหมาย — ยังไม่มีผู้ตรวจสอบให้แสดง
  const visibleColumns = useMemo(
    () => (flowTab === "open" ? columns.filter((c) => c.id !== "inspector") : columns),
    [columns, flowTab]
  );

  const table = useReactTable({
    data: visibleData, columns: visibleColumns,
    state: { globalFilter: filtering, sorting },
    onSortingChange: setSorting, onGlobalFilterChange: setFiltering,
    getCoreRowModel: getCoreRowModel(), getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(), getPaginationRowModel: getPaginationRowModel(),
    columnResizeMode: "onChange",
  });

  const pdfInputRef = useRef<HTMLInputElement>(null);
  const [dateOpen, setDateOpen] = useState(false);
  const [reportDate, setReportDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);

  const handlePdfChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.currentTarget.value = "";
    if (!files.length) return;
    const pdfs = files.filter((f) => f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf"));
    if (!pdfs.length) { showToast("error", t("alertPdfOnly", lang)); return; }
    const validPdfs: File[] = [];
    for (const f of pdfs) {
      const header = await f.slice(0, 5).text();
      if (header.startsWith("%PDF-")) validPdfs.push(f);
    }
    if (validPdfs.length === 0) { showToast("error", lang === "th" ? "ไฟล์ที่เลือกไม่ใช่ PDF จริง" : "Selected files are not valid PDFs"); return; }
    setPendingFiles(validPdfs);
    setDateOpen(true);
  };

  async function uploadPdfs() {
    try {
      if (!stationId) { showToast("warning", t("alertSelectStation", lang)); return; }
      if (!pendingFiles.length) { setDateOpen(false); return; }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(reportDate)) { showToast("error", t("alertInvalidDate", lang)); return; }
      const fd = new FormData();
      fd.append("station_id", stationId); fd.append("reportDate", reportDate); fd.append("issue_id", issueId);
      fd.append("doc_name", docName || ""); fd.append("inspector", inspector || "");
      pendingFiles.forEach((f) => fd.append("files", f));
      const res = await fetch(`${apiBase}/${URL_PREFIX}/upload-files`, { method: "POST", body: fd, credentials: "include" });
      if (!res.ok) { const txt = await res.text(); showToast("error", `${t("alertUploadFailed", lang)} ${txt}`); return; }
      await res.json();
      setPendingFiles([]); setDateOpen(false);
      showToast("success", t("alertUploadSuccess", lang));
      await fetchRows();
    } catch (err) { showToast("error", t("alertUploadError", lang)); }
  }

  useEffect(() => {
    if (!dateOpen || !stationId || !reportDate) return;
    let canceled = false;
    (async () => {
      try {
        const preview = await fetchPreviewDocName(stationId, reportDate);
        if (!canceled && preview) { setDocName(preview); return; }
        const latest = await fetchLatestDocName(stationId, reportDate);
        if (!canceled) { setDocName(nextDocNameFor(stationId, reportDate, latest || undefined)); }
      } catch (e) { if (!canceled) { setDocName(nextDocNameFor(stationId, reportDate)); } }
    })();
    return () => { canceled = true; };
  }, [dateOpen, stationId, reportDate]);

  useEffect(() => {
    if (!dateOpen || !stationId || !reportDate) return;
    let canceled = false;
    (async () => {
      try {
        const latest = await fetchLatestIssueIdAcrossLists(stationId, reportDate, apiBase, FetchOpts);
        if (!canceled) setIssueId(nextIssueIdFor(PM_TYPE_CODE, reportDate, latest || ""));
      } catch { if (!canceled) setIssueId(nextIssueIdFor(PM_TYPE_CODE, reportDate, "")); }
    })();
    return () => { canceled = true; };
  }, [dateOpen, stationId, reportDate]);

  const goAdd = () => setView("form");

  if (mode === "form") {
    // ช่างกดเข้าใบงานที่ถูก assign → เห็นข้อมูลก่อน ยังไม่เปิดฟอร์ม
    if (woInfoWonum) {
      return (
        <PmWorkOrderInfo
          source="ccb" identifier={stationId} wonum={woInfoWonum}
          onStart={startPmFromInfo} onCancel={leaveWoInfo}
        />
      );
    }
    // planning=1 → ฟอร์มวางแผนของ planner ไม่ใช่ฟอร์มกรอก PM ของช่าง
    if (planningWonum) {
      return (
        <PmPlanForm
          source="ccb" identifier={stationId} wonum={planningWonum}
          onSaved={() => { showToast("success", t("planSaved", lang)); reloadWos(); leavePlanning(); }}
          onCancel={leavePlanning}
        />
      );
    }
    return (<div className="tw-mt-4 sm:tw-mt-6 lg:tw-mt-8"><CCBPMForm /></div>);
  }

  return (
    <>
      <LoadingOverlay show={pageLoading} text={t("loadingData", lang)} />
      {toast.show && (
        <div className="tw-fixed tw-top-4 tw-left-1/2 tw--translate-x-1/2 tw-z-[9999] tw-max-w-md tw-w-[calc(100%-2rem)]">
          <div className={`tw-flex tw-items-start tw-gap-3 tw-px-4 tw-py-3 tw-rounded-xl tw-shadow-2xl tw-border ${toast.type === "success" ? "tw-bg-green-50 tw-border-green-200" : toast.type === "error" ? "tw-bg-red-50 tw-border-red-200" : toast.type === "warning" ? "tw-bg-amber-50 tw-border-amber-200" : "tw-bg-blue-50 tw-border-blue-200"}`}>
            <div className={`tw-flex-shrink-0 tw-w-8 tw-h-8 tw-rounded-full tw-flex tw-items-center tw-justify-center ${toast.type === "success" ? "tw-bg-green-500" : toast.type === "error" ? "tw-bg-red-500" : toast.type === "warning" ? "tw-bg-amber-500" : "tw-bg-blue-500"}`}>
              {toast.type === "success" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" /></svg>}
              {toast.type === "error" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>}
              {toast.type === "warning" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01" /></svg>}
              {toast.type === "info" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 16h-1v-4h-1m1-4h.01" /></svg>}
            </div>
            <p className={`tw-text-sm tw-font-medium tw-flex-1 tw-pt-1 ${toast.type === "success" ? "tw-text-green-800" : toast.type === "error" ? "tw-text-red-800" : toast.type === "warning" ? "tw-text-amber-800" : "tw-text-blue-800"}`}>{toast.message}</p>
            <button onClick={() => setToast(prev => ({ ...prev, show: false }))} className="tw-flex-shrink-0 tw-p-1 tw-rounded-full tw-text-gray-400 hover:tw-text-gray-600 hover:tw-bg-gray-100 tw-transition-colors">
              <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        </div>
      )}
      <Card className="tw-border tw-border-blue-gray-100 tw-shadow-sm tw-mt-4 sm:tw-mt-6 lg:tw-mt-8 tw-mx-2 sm:tw-mx-4 lg:tw-mx-0 tw-rounded-xl lg:tw-rounded-2xl tw-overflow-hidden">
        {/* <CardHeader floated={false} shadow={false} className="tw-p-3 sm:tw-p-4 lg:tw-p-6 tw-rounded-none tw-m-0"> */}
        <CardHeader floated={false} shadow={false} className="tw-p-3 sm:tw-p-4 lg:tw-p-6 tw-rounded-none tw-m-0 tw-bg-gradient-to-r tw-from-white tw-to-blue-gray-50/30">
          <div className="tw-flex tw-flex-col sm:tw-flex-row sm:tw-items-center sm:tw-justify-between tw-gap-3 sm:tw-gap-4">
            <div className="tw-min-w-0 tw-flex-1">
              <Typography variant="h5" color="blue-gray" className="tw-text-sm sm:tw-text-base lg:tw-text-lg tw-leading-tight tw-font-semibold">{t("pageTitle", lang)}</Typography>
              <Typography variant="small" className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-leading-relaxed tw-font-normal tw-text-blue-gray-400 tw-mt-0.5">{t("pageSubtitle", lang)}</Typography>
              <PmFlowTabs value={flowTab} onChange={setFlowTab} lang={lang}
                counts={FLOW_TABS.reduce((acc, tb) => ({ ...acc, [tb.id]: data.filter((r) => FLOW_TAB_OF[toPmFlow(r)] === tb.id).length }), {} as Record<FlowTab, number>)} />
            </div>
            <div className="tw-flex tw-items-center tw-gap-2 tw-flex-shrink-0">
              <input ref={pdfInputRef} type="file" accept="application/pdf,.pdf" multiple className="tw-hidden" onChange={handlePdfChange} />
              <Button variant="outlined" size="sm" disabled={!stationId} onClick={() => pdfInputRef.current?.click()}
                className="tw-h-7 sm:tw-h-8 lg:tw-h-9 tw-rounded-lg tw-px-2.5 sm:tw-px-3 lg:tw-px-4 tw-flex tw-items-center tw-justify-center tw-gap-1 sm:tw-gap-1.5 tw-border-blue-gray-200 tw-font-medium hover:tw-bg-blue-gray-50 tw-transition-colors"
                title={t("uploadPdf", lang)}>
                <ArrowUpTrayIcon className="tw-h-3.5 tw-w-3.5 sm:tw-h-4 sm:tw-w-4 tw-flex-shrink-0" />
                <span className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm">{t("upload", lang)}</span>
              </Button>
              <Button size="sm" onClick={goAdd} disabled={!stationId}
                // className={`tw-h-7 sm:tw-h-8 lg:tw-h-9 tw-rounded-lg tw-px-2.5 sm:tw-px-3 lg:tw-px-4 tw-flex tw-items-center tw-justify-center tw-font-medium ${!stationId ? "tw-bg-gray-300 tw-text-white tw-cursor-not-allowed" : "tw-bg-gradient-to-b tw-from-neutral-800 tw-to-neutral-900 hover:tw-to-black tw-text-white"} tw-shadow-md tw-transition-all`}
                className={`tw-h-7 sm:tw-h-8 lg:tw-h-9 tw-rounded-xl tw-px-3 sm:tw-px-4 lg:tw-px-5 tw-flex tw-items-center tw-justify-center tw-font-semibold tw-tracking-wide ${!stationId ? "tw-bg-gray-300 tw-text-white tw-cursor-not-allowed" : "tw-bg-gray-900 hover:tw-bg-black tw-text-white"} tw-shadow-lg tw-transition-all`}
                title={stationId ? "" : t("selectStationFirst", lang)}>
                <span className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm">{t("add", lang)}</span>
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardBody className="tw-px-3 sm:tw-px-4 lg:tw-px-6 tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-border-t tw-border-blue-gray-50">
          <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-stretch sm:tw-items-center tw-gap-2.5 sm:tw-gap-3 lg:tw-gap-4">
            <div className="tw-flex tw-items-center tw-gap-1.5 sm:tw-gap-2 tw-flex-shrink-0">
              <select value={table.getState().pagination.pageSize} onChange={(e) => table.setPageSize(Number(e.target.value))}
                className="tw-border tw-border-blue-gray-200 tw-py-1.5 sm:tw-py-2 tw-px-2 sm:tw-px-3 tw-rounded-lg tw-text-xs sm:tw-text-sm tw-w-14 sm:tw-w-16 lg:tw-w-20 tw-bg-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-500 focus:tw-border-transparent tw-cursor-pointer">
                {[5, 10, 15, 20, 25, 50].map((n) => (<option key={n} value={n}>{n}</option>))}
              </select>
              <Typography variant="small" className="tw-text-blue-gray-500 tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-whitespace-nowrap">{t("entriesPerPage", lang)}</Typography>
            </div>
            <div className="tw-flex-1 tw-hidden sm:tw-block" />
            <div className="tw-w-full sm:tw-w-48 lg:tw-w-64">
              <Input value={filtering} onChange={(e) => setFiltering(e.target.value)} label={t("search", lang)} crossOrigin={undefined} />
            </div>
          </div>
        </CardBody>

        <CardFooter className="tw-px-3 sm:tw-px-4 lg:tw-px-6 tw-py-3 sm:tw-py-4">
          <div className="tw-overflow-x-auto tw-w-full tw-rounded-xl tw-border tw-border-blue-gray-100 tw-shadow-sm">
            <table className="tw-w-full tw-text-left tw-min-w-[700px]">
              {/* <thead className="tw-bg-gray-50/80 tw-sticky tw-top-0 tw-backdrop-blur-sm"> */}
              <thead className="tw-bg-gradient-to-r tw-from-gray-900 tw-to-gray-800 tw-sticky tw-top-0">
                {table.getHeaderGroups().map((hg) => (
                  <tr key={hg.id}>
                    {hg.headers.map((header) => {
                      const canSort = header.column.getCanSort();
                      const align = (header.column.columnDef as any).meta?.headerAlign ?? "left";
                      return (
                        <th key={header.id} onClick={canSort ? header.column.getToggleSortingHandler() : undefined}
                          // className={`tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4 tw-uppercase !tw-text-blue-gray-500 !tw-font-semibold tw-whitespace-nowrap tw-border-b tw-border-blue-gray-100 ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"} ${canSort ? "tw-cursor-pointer hover:tw-bg-gray-100 tw-transition-colors tw-select-none" : ""}`}>
                          className={`tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4 tw-uppercase !tw-font-semibold tw-whitespace-nowrap tw-border-b tw-border-gray-700 ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"} ${canSort ? "tw-cursor-pointer hover:tw-bg-gray-700 tw-transition-colors tw-select-none" : ""}`}>
                          {canSort ? (
                            <Typography color="blue-gray"
                              // className={`tw-flex tw-items-center tw-gap-0.5 sm:tw-gap-1 tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-60 ${align === "center" ? "tw-justify-center" : align === "right" ? "tw-justify-end" : "tw-justify-start"}`}>
                              className={`tw-flex tw-items-center tw-gap-0.5 sm:tw-gap-1 tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white ${align === "center" ? "tw-justify-center" : align === "right" ? "tw-justify-end" : "tw-justify-start"}`}>

                              {flexRender(header.column.columnDef.header, header.getContext())}
                              {/* <ChevronUpDownIcon strokeWidth={2} className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5 lg:tw-h-4 lg:tw-w-4 tw-flex-shrink-0" /> */}
                              <ChevronUpDownIcon strokeWidth={2} className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5 lg:tw-h-4 lg:tw-w-4 tw-flex-shrink-0 tw-text-white/60" />
                            </Typography>
                          ) : (
                            <Typography color="blue-gray"
                              // className={`tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-60 ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}`}>
                              className={`tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}`}>
                              {flexRender(header.column.columnDef.header, header.getContext())}
                            </Typography>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                ))}
              </thead>
              <tbody className="tw-divide-y tw-divide-blue-gray-50">
                {loading ? (
                  /* โครงร่างสูงเท่าหน้าจริง — กัน layout shift ตอนข้อมูลมาถึง */
                  <TableSkeletonRows rows={table.getState().pagination.pageSize} cols={visibleColumns.length} />
                ) : table.getRowModel().rows.length ? (
                  table.getRowModel().rows.map((row, index) => (
                    // <tr key={row.id} className={`tw-transition-colors hover:tw-bg-blue-50/50 ${index % 2 === 0 ? 'tw-bg-white' : 'tw-bg-gray-50/30'}`}>
                    <tr key={row.id} className={`tw-transition-colors hover:tw-bg-blue-50/40 hover:tw-shadow-[inset_3px_0_0_0_#2196F3] ${index % 2 === 0 ? 'tw-bg-white' : 'tw-bg-blue-gray-50/30'}`}>
                      {row.getVisibleCells().map((cell) => {
                        const align = (cell.column.columnDef as any).meta?.cellAlign ?? "left";
                        return (
                          <td key={cell.id} className={`tw-align-middle tw-border-0 tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4 ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}`}>
                            <Typography as="div" variant="small" className="!tw-font-normal !tw-text-blue-gray-700 tw-text-[11px] sm:tw-text-xs lg:tw-text-sm">
                              {flexRender(cell.column.columnDef.cell, cell.getContext())}
                            </Typography>
                          </td>
                        );
                      })}
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={visibleColumns.length} className="tw-text-center tw-py-10 sm:tw-py-12 lg:tw-py-16">
                    <div className="tw-flex tw-flex-col tw-items-center tw-gap-2 sm:tw-gap-3">
                      <div className="tw-w-10 tw-h-10 sm:tw-w-12 sm:tw-h-12 lg:tw-w-16 lg:tw-h-16 tw-rounded-full tw-bg-blue-gray-50 tw-flex tw-items-center tw-justify-center">
                        <DocumentArrowDownIcon className="tw-w-5 tw-h-5 sm:tw-w-6 sm:tw-h-6 lg:tw-w-8 lg:tw-h-8 tw-text-blue-gray-300" />
                      </div>
                      <span className="tw-text-blue-gray-400 tw-text-xs sm:tw-text-sm tw-font-medium">{!stationId ? t("selectStationFirst", lang) : t("noData", lang)}</span>
                    </div>
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </CardFooter>

        {/* <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-center tw-justify-between tw-gap-2 sm:tw-gap-3 tw-p-2.5 sm:tw-p-3 lg:tw-p-4 tw-border-t tw-border-blue-gray-50 tw-bg-gray-50/30"> */}
        <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-center tw-justify-between tw-gap-2 sm:tw-gap-3 tw-p-2.5 sm:tw-p-3 lg:tw-p-4 tw-border-t tw-border-blue-gray-100">
          <Typography variant="small" className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-text-blue-gray-600 tw-order-2 sm:tw-order-1">
            {t("page", lang)} <strong className="tw-text-blue-gray-800">{table.getState().pagination.pageIndex + 1}</strong> {t("of", lang)} <strong className="tw-text-blue-gray-800">{table.getPageCount() || 1}</strong>
          </Typography>
          <div className="tw-flex tw-gap-1.5 sm:tw-gap-2 tw-order-1 sm:tw-order-2">
            <Button size="sm" variant="outlined" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}
              className="tw-p-1.5 sm:tw-p-2 tw-min-w-0 tw-rounded-lg disabled:tw-opacity-40 disabled:tw-cursor-not-allowed tw-border-blue-gray-200 hover:tw-bg-blue-gray-50 tw-transition-colors">
              <ChevronLeftIcon className="tw-h-3.5 tw-w-3.5 sm:tw-h-4 sm:tw-w-4 lg:tw-h-5 lg:tw-w-5" />
            </Button>
            <Button size="sm" variant="outlined" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}
              className="tw-p-1.5 sm:tw-p-2 tw-min-w-0 tw-rounded-lg disabled:tw-opacity-40 disabled:tw-cursor-not-allowed tw-border-blue-gray-200 hover:tw-bg-blue-gray-50 tw-transition-colors">
              <ChevronRightIcon className="tw-h-3.5 tw-w-3.5 sm:tw-h-4 sm:tw-w-4 lg:tw-h-5 lg:tw-w-5" />
            </Button>
          </div>
        </div>
      </Card>

      <Dialog open={dateOpen} handler={setDateOpen} size="sm" className="tw-mx-4 tw-max-w-[calc(100vw-2rem)] sm:tw-max-w-md tw-rounded-xl sm:tw-rounded-2xl">
        <DialogHeader className="tw-text-base sm:tw-text-lg lg:tw-text-xl tw-font-semibold tw-px-4 sm:tw-px-6 tw-pt-5 sm:tw-pt-6 tw-pb-2">{t("dialogTitle", lang)}</DialogHeader>
        <DialogBody className="tw-space-y-4 tw-px-4 sm:tw-px-6 tw-py-4">
          <div><Input label={t("docNameLabel", lang)} value={docName} onChange={(e) => setDocName(e.target.value)} crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full !tw-bg-blue-gray-50 !tw-text-sm" labelProps={{ className: "!tw-text-sm" }} readOnly /></div>
          <div><Input label={t("issueIdLabel", lang)} value={issueId} onChange={(e) => setIssueId(e.target.value)} crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full !tw-bg-blue-gray-50 !tw-text-sm" labelProps={{ className: "!tw-text-sm" }} readOnly /></div>
          <div><Input label={t("inspectorLabel", lang)} value={inspector} onChange={(e) => setInspector(e.target.value)} crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full !tw-bg-blue-gray-50 !tw-text-sm" labelProps={{ className: "!tw-text-sm" }} readOnly /></div>
          <div><Input type="date" value={reportDate} max={todayStr} onChange={(e) => setReportDate(e.target.value)} label={t("pmDateLabel", lang)} crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-text-sm" labelProps={{ className: "!tw-text-sm" }} /></div>
          <div className="tw-bg-blue-50 tw-rounded-lg tw-p-3 sm:tw-p-4">
            <Typography variant="small" className="tw-text-blue-gray-600 tw-text-xs sm:tw-text-sm">{t("filesSelected", lang)} <strong className="tw-text-blue-600">{pendingFiles.length}</strong> {t("filesUnit", lang)}</Typography>
          </div>
        </DialogBody>
        <DialogFooter className="tw-gap-2 sm:tw-gap-3 tw-px-4 sm:tw-px-6 tw-pb-5 sm:tw-pb-6 tw-pt-2">
          <Button variant="text" size="sm" onClick={() => { setPendingFiles([]); setDateOpen(false); }} className="tw-text-xs sm:tw-text-sm tw-px-4 sm:tw-px-5 tw-py-2 sm:tw-py-2.5 tw-font-medium tw-text-blue-gray-600 hover:tw-bg-blue-gray-50 tw-transition-colors tw-rounded-lg">{t("cancel", lang)}</Button>
          <Button onClick={uploadPdfs} size="sm" className="tw-bg-gradient-to-b tw-from-neutral-800 tw-to-neutral-900 hover:tw-to-black tw-text-xs sm:tw-text-sm tw-px-5 sm:tw-px-6 tw-py-2 sm:tw-py-2.5 tw-font-medium tw-rounded-lg tw-shadow-md tw-transition-all">{t("uploadBtn", lang)}</Button>
        </DialogFooter>
      </Dialog>

      {/* ยืนยันอนุมัติปิดใบงาน PM */}
      <Dialog open={!!approveRow} handler={() => setApproveRow(null)} size="xs">
        <DialogHeader className="tw-text-base sm:tw-text-lg tw-font-semibold">{t("approveTitle", lang)}</DialogHeader>
        <DialogBody className="tw-space-y-2 tw-text-sm">
          <p className="tw-text-blue-gray-700">{t("approveConfirm", lang)}</p>
          <p className="tw-font-medium tw-text-blue-gray-900">{approveRow?.doc_name || approveRow?.issue_id || "-"}</p>
        </DialogBody>
        <DialogFooter className="tw-gap-2">
          <Button variant="text" size="sm" onClick={() => setApproveRow(null)} disabled={acting}>{t("cancel", lang)}</Button>
          <Button color="green" size="sm" onClick={onApprove} disabled={acting}>{t("confirmBtn", lang)}</Button>
        </DialogFooter>
      </Dialog>

      {/* ตีกลับใบงานให้ช่างแก้ — ต้องมีเหตุผลเสมอ */}
      <Dialog open={!!rejectRow} handler={() => setRejectRow(null)} size="xs">
        <DialogHeader className="tw-text-base sm:tw-text-lg tw-font-semibold">{t("rejectTitle", lang)}</DialogHeader>
        <DialogBody className="tw-space-y-3 tw-text-sm">
          <p className="tw-font-medium tw-text-blue-gray-900">{rejectRow?.doc_name || rejectRow?.issue_id || "-"}</p>
          <Input crossOrigin="" label={t("rejectRemarkLabel", lang)} value={rejectRemark} onChange={(e) => setRejectRemark(e.target.value)} />
        </DialogBody>
        <DialogFooter className="tw-gap-2">
          <Button variant="text" size="sm" onClick={() => setRejectRow(null)} disabled={acting}>{t("cancel", lang)}</Button>
          <Button color="amber" size="sm" onClick={onReject} disabled={acting || !rejectRemark.trim()}>{t("confirmBtn", lang)}</Button>
        </DialogFooter>
      </Dialog>
    </>
  );
}