"use client";

import React, { useMemo, useCallback, useRef, useState, useEffect } from "react";
import { Button, Input, Typography, Textarea, Tooltip } from "@material-tailwind/react";
import { draftKey, saveDraftLocal, loadDraftLocal, clearDraftLocal } from "@/app/dashboard/pm-report/cb-box/input_PMreport/lib/draft";
import { useRouter, useSearchParams } from "next/navigation";
import PmApprovalBar from "@/app/dashboard/pm-report/components/PmApprovalBar";
import Image from "next/image";
import { ArrowLeftIcon } from "@heroicons/react/24/solid";
import { putPhoto, getPhotoByDbKey, delPhoto, type PhotoRef } from "../lib/draftPhotos";
import { isFileReadable, isImageDecodable, resolveUsableFile, reportMissingDraftPhoto, reportPhotoStorageFailure } from "@/utils/upload-safety";
import { ensureViewableImage } from "@/utils/heic";
import { collectPending, unrecoverablePhotos, expectedCountByGroup, findShortfall, shortfallMessage, pendingMessage, unrecoverableMessage } from "@/utils/pm-photo-sync";
import { useLanguage, type Lang } from "@/utils/useLanguage";
import { pmFormReturnRoute } from "@/app/dashboard/pm-report/lib/origin";
import { registerDraftDiscard } from "@/app/dashboard/pm-report/lib/discardDraft";
import { apiFetch } from "@/utils/api";
import { serverPhotosToForm, formKeyFromForward, measureAsText, mergeDraftPhotos, deleteRemovedServerPhotos, isServerPhoto, type ViewPhoto } from "@/app/dashboard/pm-report/lib/reviewData";
import { useJobDocIds } from "@/app/dashboard/pm-report/lib/useJobDocIds";
import { useDebouncedEffect } from "@/app/dashboard/pm-report/lib/useDebouncedEffect";
import { usePmCancelEdit, usePmReviewAction } from "@/app/dashboard/pm-report/lib/reviewAction";

const T = {
    pageTitle: { th: "Preventive Maintenance Checklist - Safety Switch / Circuit Breaker - Box", en: "Preventive Maintenance Checklist - Safety Switch / Circuit Breaker - Box" },
    companyName: { th: "Electricity Generating Authority of Thailand (EGAT)", en: "Electricity Generating Authority of Thailand (EGAT)" },
    companyAddress: { th: "53 Moo 2 Charansanitwong Road, Bang Kruai, Nonthaburi 11130, Thailand", en: "53 Moo 2 Charansanitwong Road, Bang Kruai, Nonthaburi 11130, Thailand" },
    companyAddressShort: { th: "Bang Kruai, Nonthaburi 11130", en: "Bang Kruai, Nonthaburi 11130" },
    callCenter: { th: "Call Center Tel. 02-114-3350", en: "Call Center Tel. 02-114-3350" },
    docName: { th: "ชื่อเอกสาร", en: "Document Name" },
    issueId: { th: "Issue ID", en: "Issue ID" },
    location: { th: "สถานที่", en: "Location" },
    inspector: { th: "ผู้ตรวจสอบ", en: "Inspector" },
    pmDate: { th: "วันที่ PM", en: "PM Date" },
    save: { th: "บันทึก", en: "Save" },
    saving: { th: "กำลังบันทึก...", en: "Saving..." },
    attachPhoto: { th: "แนบรูป / ถ่ายรูป", en: "Attach / Take Photo" },
    na: { th: "N/A", en: "N/A" },
    pass: { th: "PASS", en: "PASS" },
    fail: { th: "FAIL", en: "FAIL" },
    backToList: { th: "กลับไปหน้า List", en: "Back to List" },
    maxPhotos: { th: "สูงสุด", en: "Max" },
    photos: { th: "รูป", en: "photos" },
    cameraSupported: { th: "รองรับการถ่ายจากกล้องบนมือถือ", en: "Camera supported on mobile" },
    noPhotos: { th: "ยังไม่มีรูปแนบ", en: "No photos attached" },
    remark: { th: "หมายเหตุ", en: "Remark" },
    testResult: { th: "ผลการทดสอบ", en: "Test Result" },
    comment: { th: "Comment", en: "Comment" },
    summaryResult: { th: "สรุปผลการตรวจสอบ", en: "Inspection Summary" },
    summaryPassLabel: { th: "Pass", en: "Pass" },
    summaryFailLabel: { th: "Fail", en: "Fail" },
    summaryNALabel: { th: "N/A", en: "N/A" },
    selectPowerSource: { th: "-- เลือกแหล่งรับไฟ --", en: "-- Select power source --" },
    selectDevice: { th: "-- เลือกอุปกรณ์ --", en: "-- Select device --" },
    powerSource: { th: "แหล่งรับไฟ", en: "Power source" },
    circuitDevice: { th: "อุปกรณ์ตัดวงจรไฟฟ้า", en: "Circuit breaker device" },
    validationPhotoTitle: { th: "1) ตรวจสอบการแนบรูปภาพ", en: "1) Photo Attachments" },
    validationInputTitle: { th: "2) อินพุตข้อ 7", en: "2) Input Item 7" },
    validationRemarkTitle: { th: "3) หมายเหตุ", en: "3) Remarks" },
    validationPFTitle: { th: "3) ระดับผลการตรวจ / N/A", en: "3) Inspection rating / N/A" },
    validationRemarkTitlePost: { th: "4) หมายเหตุ", en: "4) Remarks" },
    validationSummaryTitle: { th: "5) สรุปผลการตรวจสอบ", en: "5) Inspection Summary" },
    allComplete: { th: "ครบเรียบร้อย ✅", en: "Complete ✅" },
    missingPhoto: { th: "ยังไม่ได้แนบรูปข้อ:", en: "Missing photos for:" },
    missingInput: { th: "ยังขาดข้อ:", en: "Missing:" },
    missingPF: { th: "ยังไม่ได้เลือกข้อ:", en: "Not selected:" },
    missingSummaryText: { th: "ยังไม่ได้กรอก Comment", en: "Comment not filled" },
    missingSummaryStatus: { th: "ยังไม่ได้เลือกสถานะสรุปผล", en: "Summary status not selected" },
    alertNoStation: { th: "ยังไม่ทราบ station_id", en: "Station ID not found" },
    alertFillPhoto: { th: "กรุณาแนบรูปในทุกข้อก่อนบันทึก", en: "Please attach photos for all items" },
    alertSaveFailed: { th: "บันทึกไม่สำเร็จ:", en: "Save failed:" },
    alertCompleteAll: { th: "กรุณากรอกข้อมูลและแนบรูปให้ครบก่อนบันทึก", en: "Please complete all fields" },
    alertInputNotComplete: { th: "กรุณากรอกค่าข้อ 7 ให้ครบ", en: "Please fill in Item 7" },
    // PMValidationCard translations
    itemLabel: { th: "ข้อ", en: "Item" },
    formStatus: { th: "สถานะการกรอกข้อมูล", en: "Form Completion Status" },
    allCompleteReady: { th: "กรอกข้อมูลครบถ้วนแล้ว พร้อมบันทึก ✓", en: "All fields completed. Ready to save ✓" },
    remaining: { th: "ยังขาดอีก {n} รายการ", en: "{n} items remaining" },
    items: { th: "รายการ", en: "items" },
    workTime: { th: "เวลาทำงานจริง", en: "Actual work time" },
    workStart: { th: "เวลาเริ่มงาน", en: "Start time" },
    workFinish: { th: "เวลาเสร็จงาน", en: "Finish time" },
    workTimeHint: { th: "ใช้ส่งเวลาทำงานของช่างเข้า Maximo", en: "Sent to Maximo as actual labor time" },
    alertWorkTime: { th: "กรุณากรอกเวลาเริ่มงานและเวลาเสร็จงาน", en: "Please fill in the start and finish time" },
    alertWorkTimeOrder: { th: "เวลาเสร็จงานต้องไม่ก่อนเวลาเริ่มงาน", en: "Finish time must not be before the start time" },
    alertWorkTimeFuture: { th: "เวลาทำงานต้องไม่เป็นเวลาในอนาคต — Maximo ไม่รับเวลาที่ยังมาไม่ถึง", en: "Work time cannot be in the future — Maximo rejects labor times that have not happened yet" },
    maximoLabor: { th: "ช่างที่ลงเวลากับ Maximo", en: "Technicians for Maximo time log" },
    maximoLaborHint: {
        th: "เลือกคนที่จะลงเวลาทำงานเข้า Maximo (IN09) — ไม่เลือกจะใช้ช่างที่ผู้วางแผนมอบหมายแทน",
        en: "Who gets an actual-labor record in Maximo (IN09) — leave empty to fall back to the assigned technicians",
    },
    maximoLaborEmpty: { th: "ยังไม่มีรหัสช่างจาก Maximo", en: "No Maximo labor codes available" },
    maximoLaborNone: { th: "ช่างไม่ได้เลือกใครไว้", en: "No technician selected" },
    contractorName: { th: "ชื่อผู้รับเหมา", en: "Contractor name" },
    contractorPlaceholder: { th: "ระบุชื่อผู้รับเหมาที่มาทำงานจริง", en: "Name of the contractor who did the work" },
    contractorRequired: { th: "เลือกผู้รับเหมาแล้วต้องระบุชื่อด้วย", en: "Enter the contractor name" },
};

let _cachedLocation: { text: string; timestamp: number } | null = null;
let _locationFetching = false;
const LOCATION_CACHE_MAX_AGE = 5 * 60 * 1000;

async function getCurrentGPS(): Promise<{ lat: number; lng: number } | null> {
    if (!navigator.geolocation) return null;
    if (window.isSecureContext === false) return null;
    const fast = await new Promise<{ lat: number; lng: number } | null>((resolve) => {
        const timer = setTimeout(() => resolve(null), 2000);
        navigator.geolocation.getCurrentPosition(
            (pos) => { clearTimeout(timer); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
            () => { clearTimeout(timer); resolve(null); },
            { enableHighAccuracy: false, timeout: 1500, maximumAge: 300000 }
        );
    });
    if (fast) return fast;
    return new Promise((resolve) => {
        const timer = setTimeout(() => resolve(null), 8000);
        navigator.geolocation.getCurrentPosition(
            (pos) => { clearTimeout(timer); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
            () => { clearTimeout(timer); resolve(null); },
            { enableHighAccuracy: true, timeout: 7000, maximumAge: 30000 }
        );
    });
}

const GOOGLE_MAPS_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY ?? "";

async function reverseGeocodeGoogle(lat: number, lng: number): Promise<string | null> {
    if (!GOOGLE_MAPS_KEY) return null;
    try {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 5000);
        const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&language=th&result_type=street_address|route|premise&key=${GOOGLE_MAPS_KEY}`;
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(tid);
        if (!res.ok) return null;
        const data = await res.json();
        if (data.status !== "OK" || !data.results?.length) return null;
        const best = data.results[0];
        const c = best.address_components || [];
        const get = (type: string) => c.find((x: any) => x.types?.includes(type))?.long_name || "";
        const parts: string[] = [];
        const premise = get("premise"); if (premise) parts.push(premise);
        const hn = get("street_number"), road = get("route");
        if (hn && road) parts.push(`${hn} ${road}`); else if (road) parts.push(road);
        const sub2 = get("sublocality_level_2"); if (sub2 && !parts.some(p => p.includes(sub2))) parts.push(sub2);
        const sub1 = get("sublocality_level_1"); if (sub1 && !parts.some(p => p.includes(sub1))) parts.push(sub1);
        const dist = get("locality") || get("administrative_area_level_2"); if (dist && !parts.some(p => p.includes(dist))) parts.push(dist);
        const prov = get("administrative_area_level_1"); if (prov && !parts.some(p => p.includes(prov))) parts.push(prov);
        if (parts.length > 0) { let r = parts.join(" "); return r.length > 80 ? r.substring(0, 77) + "..." : r; }
        if (best.formatted_address) { const a = best.formatted_address.replace(/\s*\d{5}\s*/, " ").replace(/ประเทศไทย/g, "").trim(); return a.length > 80 ? a.substring(0, 77) + "..." : a; }
        return null;
    } catch { return null; }
}

async function reverseGeocodeNominatim(lat: number, lng: number): Promise<string> {
    try {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 5000);
        const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=th&zoom=21&addressdetails=1`;
        const res = await fetch(url, { headers: { "User-Agent": "PM-Checklist-App/1.0" }, signal: controller.signal });
        clearTimeout(tid);
        if (!res.ok) return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
        const data = await res.json();
        const addr = data.address || {};
        const poi = addr.amenity || addr.building || addr.shop || addr.tourism || "";
        let roadPart = "";
        const hn = addr.house_number || "", road = addr.road || addr.pedestrian || "";
        if (hn && road) roadPart = `${hn} ${road}`; else if (road) roadPart = road;
        const village = addr.village || addr.neighbourhood || addr.residential || "";
        const subdistrict = addr.subdistrict || addr.suburb || "";
        const district = addr.district || addr.city_district || "";
        const province = addr.province || addr.state || addr.city || "";
        const rawParts = [poi, roadPart, village, subdistrict, district, province].filter(Boolean);
        const parts: string[] = [];
        for (const p of rawParts) { if (!parts.some(e => e.includes(p) || p.includes(e))) parts.push(p); }
        if (parts.length > 0) { let r = parts.slice(0, 4).join(" "); return r.length > 70 ? r.substring(0, 67) + "..." : r; }
        if (data.display_name) { const s = data.display_name.split(",").slice(0, 4).join(",").trim(); return s.length > 70 ? s.substring(0, 67) + "..." : s; }
        return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
    } catch { return `${lat.toFixed(6)}, ${lng.toFixed(6)}`; }
}

async function reverseGeocode(lat: number, lng: number): Promise<string> {
    const google = await reverseGeocodeGoogle(lat, lng);
    if (google) return google;
    return reverseGeocodeNominatim(lat, lng);
}

async function prefetchLocation(): Promise<void> {
    if (_locationFetching) return;
    _locationFetching = true;
    try {
        const gps = await getCurrentGPS();
        if (gps) {
            const text = await reverseGeocode(gps.lat, gps.lng);
            _cachedLocation = { text, timestamp: Date.now() };
        }
    } catch { /* silent */ }
    finally { _locationFetching = false; }
}

async function getCachedLocation(): Promise<string> {
    if (_cachedLocation && (Date.now() - _cachedLocation.timestamp) < LOCATION_CACHE_MAX_AGE) {
        void prefetchLocation();
        return _cachedLocation.text;
    }
    await Promise.race([
        prefetchLocation(),
        new Promise<void>(resolve => setTimeout(resolve, 2000))
    ]);
    return _cachedLocation?.text || "ไม่สามารถระบุตำแหน่งได้";
}


// ⚡ FIX 422: ชื่อไฟล์จากกล้อง/แกลเลอรีบางเครื่องมี " หรือ newline ปนมา ทำให้ header
// Content-Disposition ของ multipart เพี้ยน → server parse body ไม่ออก ตอบ 422 โดยที่
// station_id/group/files หายพร้อมกันทั้งหมด จึงเหลือไว้เฉพาะอักขระที่ปลอดภัยเสมอ
function ensureJpgFilename(name: string): string {
    const base = (name || "").replace(/\.[^.]*$/, "");
    const safe = base.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._-]+/, "").slice(0, 80);
    return safe ? `${safe}.jpg` : `image_${Date.now()}.jpg`;
}

// บีบรูปก่อนอัปโหลด — การันตีว่าผลลัพธ์เล็กกว่า targetBytes
// แก้คอมเมนต์ 2026-09-23: เพดานจริงของ nginx คือ 30M ไม่ใช่ ~1MB ตามที่เคยเขียนไว้
// (ตรวจแล้วที่ /etc/nginx/conf.d/imps-upload.conf — client_max_body_size 30M)
// targetBytes 900KB ยังคงไว้เพราะจงใจ: ช่างอัปจากมือถือผ่าน 4G ทีละ 10 รูป
// ไฟล์เล็กกว่า = อัปเร็วกว่าและเปลืองพื้นที่เซิร์ฟเวอร์น้อยกว่า ไม่ใช่ข้อจำกัดของ nginx
// ไฟล์ที่เล็กกว่าเป้าอยู่แล้วจะคืนค่าเดิมทันที (nginx จำกัดที่ "ขนาดไฟล์" ไม่ใช่ความละเอียด)
async function compressImage(
    file: File,
    maxWidth = 1600,
    quality = 0.8,
    targetBytes = 900 * 1024,
): Promise<File> {
    if (!file.type.startsWith("image/") || file.size <= targetBytes) return file;

    const img = await new Promise<HTMLImageElement | null>((resolve) => {
        const im = document.createElement("img");
        im.onload = () => resolve(im);
        im.onerror = () => resolve(null);
        im.src = URL.createObjectURL(file);
    });
    if (!img) return file;
    URL.revokeObjectURL(img.src);

    let { width, height } = img;
    if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
    }

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(img, 0, 0, width, height);

    const toBlob = (q: number) =>
        new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", q));

    // วนลดคุณภาพทีละขั้นจนกว่าไฟล์จะเล็กกว่าเป้า (หรือถึงคุณภาพต่ำสุดที่ยอมรับได้)
    let q = quality;
    let blob = await toBlob(q);
    while (blob && blob.size > targetBytes && q > 0.4) {
        q = Math.round((q - 0.1) * 10) / 10;
        blob = await toBlob(q);
    }

    if (!blob || blob.size >= file.size) return file; // toBlob ล้มเหลว หรือไม่เล็กลง → ใช้ไฟล์เดิม
    return new File([blob], ensureJpgFilename(file.name), { type: "image/jpeg" });
}

async function addTimestampToImage(file: File, locationText: string): Promise<File> {
    return new Promise((resolve) => {
        const img = document.createElement("img");
        img.onload = () => {
            try {
                URL.revokeObjectURL(img.src);
                const canvas = document.createElement("canvas");
                canvas.width = img.width; canvas.height = img.height;
                const ctx = canvas.getContext("2d");
                if (!ctx) { resolve(file); return; }
                ctx.drawImage(img, 0, 0);
                const now = new Date();
                const timestamp = now.toLocaleString("th-TH", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
                const fontSize = Math.max(14, Math.floor(img.width * 0.022));
                const padding = Math.floor(fontSize * 0.5);
                const lineHeight = fontSize * 1.3;
                ctx.font = `bold ${fontSize}px Arial, sans-serif`;
                const tsWidth = ctx.measureText(timestamp).width;
                const locDisplay = `📍 ${locationText}`;
                const locWidth = ctx.measureText(locDisplay).width;
                const totalHeight = lineHeight * 2;
                const boxWidth = Math.max(Math.floor(img.width * 0.6), Math.max(tsWidth, locWidth) + padding * 2);
                const bgX = 10, bgY = Math.max(0, img.height - totalHeight - padding * 2 - 10);
                ctx.fillStyle = "rgba(0,0,0,0.65)";
                ctx.fillRect(bgX, bgY, boxWidth, totalHeight + padding * 2);
                ctx.fillStyle = "#FFFFFF"; ctx.textBaseline = "top";
                ctx.fillText(timestamp, bgX + padding, bgY + padding);
                let locText = locDisplay;
                while (ctx.measureText(locText).width > boxWidth - padding * 2 && locText.length > 10) locText = locText.slice(0, -4) + "...";
                ctx.fillText(locText, bgX + padding, bgY + padding + lineHeight);
                canvas.toBlob((blob) => {
                    if (blob) resolve(new File([blob], ensureJpgFilename(file.name), { type: "image/jpeg" }));
                    else resolve(file);
                }, "image/jpeg", 0.9);
            } catch { resolve(file); }
        };
        img.onerror = () => { URL.revokeObjectURL(img.src); resolve(file); };
        img.src = URL.createObjectURL(file);
    });
}

function getImageDimensions(file: File): Promise<{ width: number; height: number }> {
    return new Promise((resolve, reject) => {
        const img = new window.Image();
        img.onload = () => { resolve({ width: img.naturalWidth, height: img.naturalHeight }); URL.revokeObjectURL(img.src); };
        img.onerror = () => { reject(new Error("Cannot read image")); URL.revokeObjectURL(img.src); };
        img.src = URL.createObjectURL(file);
    });
}

function isMobileDevice(): boolean {
    if (typeof navigator === "undefined") return false;
    return /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
        || ("ontouchstart" in window && navigator.maxTouchPoints > 0);
}

const t = (key: keyof typeof T, lang: Lang): string => T[key][lang];

// Helper functions to generate scroll IDs
const ID_PREFIX = "cbbox-pm";

const getPhotoIdFromKey = (key: string | number): string => {
    return `${ID_PREFIX}-photo-${key}`;
};

const getRemarkIdFromKey = (key: string | number): string => {
    if (typeof key === "number") return `${ID_PREFIX}-remark-${key}`;
    const match = String(key).match(/^r(\d+)$/);
    if (match) return `${ID_PREFIX}-remark-${match[1]}`;
    return `${ID_PREFIX}-remark-${key}`;
};

const getInputIdFromKey = (qNo: number, fieldKey: string): string => {
    return `${ID_PREFIX}-input-${qNo}-${fieldKey}`;
};

const getPfIdFromKey = (key: string | number): string => {
    if (typeof key === "number") return `${ID_PREFIX}-pf-${key}`;
    const match = String(key).match(/^r(\d+)$/);
    if (match) return `${ID_PREFIX}-pf-${match[1]}`;
    return `${ID_PREFIX}-pf-${key}`;
};

const QUESTIONS_DATA = [
    { no: 101, key: "pre_r1", label: { th: "1) ตรวจสอบสภาพทั่วไป (ก่อนบำรุงรักษา)", en: "1) General condition (before maintenance)" }, kind: "simple", hasPhoto: true, tooltip: { th: "บันทึกสภาพกล่องก่อนเริ่มบำรุงรักษา", en: "Record the box condition before maintenance" } },
    { no: 102, key: "pre_r2", label: { th: "2) อุปกรณ์ชำรุดเสียหาย (ก่อนบำรุงรักษา)", en: "2) Damaged equipment (before maintenance)" }, kind: "simple", hasPhoto: true, tooltip: { th: "บันทึกอุปกรณ์ที่ชำรุดเสียหายก่อนเริ่มบำรุงรักษา", en: "Record damaged equipment before maintenance" } },
    {
        no: 103, key: "r103", label: { th: "3) ตรวจสอบสภาพแหล่งจ่ายไฟ MDB", en: "3) Inspect MDB power supply condition" }, kind: "group", hasPhoto: true,
        tooltip: { th: "ตรวจสอบสภาพอุปกรณ์แหล่งจ่ายไฟของตู้ CB Box", en: "Inspect the CB Box power supply equipment" },
        items: [
            { key: "r103_1", label: { th: "3.1) Main CB", en: "3.1) Main CB" } },
            { key: "r103_2", label: { th: "3.2) CB", en: "3.2) CB" } },
            { key: "r103_3", label: { th: "3.3) Power Meter (Voltage)", en: "3.3) Power Meter (Voltage)" } },
            { key: "r103_4", label: { th: "3.4) Transformer", en: "3.4) Transformer" } },
        ],
    },
    { no: 1, key: "r1", label: { th: "1) การไฟฟ้าฝ่ายจำหน่าย", en: "1) Power distribution authority" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบระบบจำหน่าย", en: "Check distribution system" } },
    { no: 2, key: "r2", label: { th: "2) ตรวจสอบอุปกรณ์ตัดวงจรไฟฟ้า", en: "2) Check circuit breaker device" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบอุปกรณ์ตัดตอน", en: "Inspect circuit breaker" } },
    { no: 3, key: "r3", label: { th: "3) ตรวจสอบสภาพทั่วไป", en: "3) General condition inspection" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบความแข็งแรงของตู้", en: "Check cabinet integrity" } },
    { no: 4, key: "r4", label: { th: "4) ตรวจสอบสภาพดักซีล,ซิลิโคนกันซึม", en: "4) Check sealant and silicone" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบสภาพดักซีล", en: "Check sealant condition" } },
    { no: 5, key: "r5", label: { th: "5) ตรวจสอบแรงดันอุปกรณ์ตัดวงจรไฟฟ้า", en: "5) Check voltage of circuit breaker" }, kind: "measure", hasPhoto: true, tooltip: { th: "วัดค่าแรงดันไฟฟ้า", en: "Measure input voltage" } },
    { no: 6, key: "r6", label: { th: "6) ปุ่มฉุกเฉิน", en: "6) Emergency button" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบปุ่มหยุดฉุกเฉิน", en: "Check emergency button" } },
    { no: 7, key: "r7", label: { th: "7) ทดสอบปุ่ม Trip Test", en: "7) Test Trip Test button" }, kind: "simple", hasPhoto: true, tooltip: { th: "กดปุ่ม Test", en: "Press Test button" } },
    { no: 8, key: "r8", label: { th: "8) ตรวจสอบจุดต่อทางไฟฟ้าและขันแน่น", en: "8) Check electrical connections" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบการขันแน่น", en: "Check bolt tightness" } },
    { no: 9, key: "r9", label: { th: "9) ทำความสะอาดตู้อุปกรณ์", en: "9) Clean equipment cabinet" }, kind: "simple", hasPhoto: true, tooltip: { th: "ทำความสะอาด", en: "Clean cabinet" } },
] as const;

const DROPDOWN_Q1_OPTIONS = [
    { value: "การไฟฟ้านครหลวง", th: "การไฟฟ้านครหลวง", en: "Metropolitan Electricity Authority" },
    { value: "การไฟฟ้าส่วนภูมิภาค", th: "การไฟฟ้าส่วนภูมิภาค", en: "Provincial Electricity Authority" },
    { value: "ระบบไฟฟ้าในพื้นที่", th: "ระบบไฟฟ้าในพื้นที่", en: "Local electrical system" },
] as const;

const DROPDOWN_Q2_OPTIONS = [
    { value: "Disconnecting Switch", th: "Disconnecting Switch", en: "Disconnecting Switch" },
    { value: "Breaker", th: "Breaker", en: "Breaker" },
    { value: "N/A", th: "N/A", en: "N/A" },
] as const;


const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";
const LOGO_SRC = "/img/logo_egat.png";

type Me = { id: string; username: string; email: string; role: string; company: string; tel: string };
type PhotoItem = { id: string; file?: File; preview?: string; remark?: string; uploaded?: boolean; ref?: PhotoRef; isNA?: boolean; createdAt?: string; location?: string };

/** หาไฟล์ที่อัปโหลดได้จริงของรูปหนึ่งใบ — กู้จาก IndexedDB ให้เองถ้าไฟล์ใน memory ใช้ไม่ได้แล้ว */
function resolveUploadFile(p: PhotoItem): Promise<File> {
    const dbKey = p.ref?.dbKey;
    return resolveUsableFile(p.file, dbKey ? () => getPhotoByDbKey(dbKey) : undefined);
}
type Rating = "VERY_GOOD" | "GOOD" | "FAIR" | "UNUSABLE";
type PF = Rating | "PASS" | "FAIL" | "NA" | "";

const VOLTAGE_FIELDS = ["L1-N", "L2-N", "L3-N", "L1-G", "L2-G", "L3-G", "L1-L2", "L2-L3", "L3-L1", "N-G"] as const;
const LABELS: Record<string, string> = { "L1-N": "L1-N", "L2-N": "L2-N", "L3-N": "L3-N", "L1-G": "L1-G", "L2-G": "L2-G", "L3-G": "L3-G", "L1-L2": "L1-L2", "L2-L3": "L2-L3", "L3-L1": "L3-L1", "N-G": "N-G" };

type QuestionItem = { key: string; label: { th: string; en: string } };
type Question = { no: number; key: string; label: { th: string; en: string }; kind: string; hasPhoto?: boolean; tooltip?: { th: string; en: string }; items?: QuestionItem[] };
const QUESTIONS = QUESTIONS_DATA as unknown as Question[];

// ข้อ 1-3 (no 101-103) เป็นหัวข้อที่เพิ่มไว้หน้าฟอร์ม ป้ายของมันเขียนเลขที่แสดงไว้ตรงแล้ว
// ข้อเดิม no=1..9 ยังใช้คีย์ชุดเดิมใน DB จึงเลื่อนเฉพาะเลขที่แสดงผล
const DISPLAY_SHIFT = 3;

function getQuestionLabel(q: Question, lang: Lang): string {
    if (q.no >= 101 && q.no <= 103) return q.label[lang];
    return q.label[lang].replace(/^(\d+)/, (number) => String(Number(number) + DISPLAY_SHIFT));
}

function getDisplayedQuestionNo(qNo: number): number {
    if (qNo >= 101 && qNo <= 103) return qNo - 100;
    return qNo + DISPLAY_SHIFT;
}

// คีย์รูปของข้อย่อย = no*10 + ลำดับข้อย่อย (103 -> 1031..1034) ข้อธรรมดายังใช้ no ตรง ๆ
function getSubPhotoKey(qNo: number, idx: number): number {
    return qNo * 10 + idx + 1;
}

function isSubPhotoKey(photoKey: number): boolean {
    return photoKey > 1000;
}

// คีย์รูป -> คีย์คำตอบใน rows (1031 -> r103_1)
function rowKeyOfPhotoKey(photoKey: number): string {
    if (!isSubPhotoKey(photoKey)) return `r${photoKey}`;
    return `r${Math.floor(photoKey / 10)}_${photoKey % 10}`;
}

// คีย์รูป -> เลขข้อที่แสดงให้ช่างเห็น (1031 -> "3.1")
function displayedNoOfPhotoKey(photoKey: number): string {
    if (!isSubPhotoKey(photoKey)) return String(getDisplayedQuestionNo(photoKey));
    return `${getDisplayedQuestionNo(Math.floor(photoKey / 10))}.${photoKey % 10}`;
}

// คีย์รูป -> ท้าย id ในหน้าฟอร์ม (1031 -> "103-1")
function idSuffixOfPhotoKey(photoKey: number): string {
    if (!isSubPhotoKey(photoKey)) return String(photoKey);
    return `${Math.floor(photoKey / 10)}-${photoKey % 10}`;
}

// คีย์รูป -> ชื่อกลุ่มที่ backend เก็บ (1031 -> g103_1) ต้องใช้สูตรเดียวกันทั้งตอนอัปและตอนตรวจยอด
function photoGroupKey(photoKey: string | number): string {
    const no = Number(photoKey);
    if (!Number.isFinite(no)) return `g${photoKey}`;
    return isSubPhotoKey(no) ? `g${Math.floor(no / 10)}_${no % 10}` : `g${no}`;
}

// เลขข้อที่แสดง -> ท้าย id ในหน้าฟอร์ม ("3.1" -> "103-1", "4" -> "1")
function idSuffixOfDisplayedNo(item: string): string {
    const [mainStr, subStr] = item.split(".");
    const mainNo = Number(mainStr);
    const storageNo = mainNo <= 3 ? mainNo + 100 : mainNo - DISPLAY_SHIFT;
    return subStr ? `${storageNo}-${subStr}` : String(storageNo);
}

const FIELD_GROUPS: Record<number, { keys: readonly string[] } | undefined> = { 5: { keys: VOLTAGE_FIELDS } };

type UnitVoltage = "V";
type MeasureRow = { value: string; unit: UnitVoltage };
type MeasureState = Record<string, MeasureRow>;

function initMeasureState(keys: readonly string[]): MeasureState {
    return keys.reduce((acc, k) => { acc[k] = { value: "", unit: "V" }; return acc; }, {} as MeasureState);
}

function useMeasure(keys: readonly string[]) {
    const [state, setState] = useState<MeasureState>(() => initMeasureState(keys));
    const patch = (key: string, p: Partial<MeasureRow>) => setState(prev => ({ ...prev, [key]: { ...prev[key], ...p } }));
    return { state, setState, patch };
}


// ชื่อสถานีสำหรับช่อง "สถานที่" — เอกสารที่บันทึกไปแล้วหลายใบเก็บ job.station_name เป็นค่าว่าง
// ต้องดึงจากข้อมูลสถานีเสมอ ไม่งั้นหน้าดูข้อมูลขึ้นช่องว่าง
async function fetchStationName(stationId: string): Promise<string> {
    const res = await fetch(`${API_BASE}/station/info/public?station_id=${encodeURIComponent(stationId)}`, { cache: "no-store", credentials: "include" });
    if (!res.ok) return "";
    const json = await res.json();
    return (json.station ?? json)?.station_name ?? "";
}

function getTodayLocalStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

async function fetchReport(reportId: string, stationId: string) {
    const res = await fetch(`${API_BASE}/cbboxpmreport/get?station_id=${stationId}&report_id=${reportId}`, { credentials: "include" });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

// ==================== UI COMPONENTS ====================

function SectionCard({ title, children, tooltip }: { title?: string; children: React.ReactNode; tooltip?: string }) {
    return (
        <div className="tw-rounded-xl tw-border tw-border-gray-200 tw-overflow-hidden tw-bg-white tw-shadow-sm">
            {title && (
                <div className="tw-bg-gray-800 tw-px-4 tw-py-3 tw-flex tw-items-center tw-justify-between">
                    <Typography className="tw-text-white tw-font-medium tw-text-sm">{title}</Typography>
                    {tooltip && (
                        <Tooltip content={tooltip} placement="bottom">
                            <svg className="tw-w-5 tw-h-5 tw-text-gray-400 tw-cursor-help hover:tw-text-white" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                            </svg>
                        </Tooltip>
                    )}
                </div>
            )}
            <div className="tw-p-4">{children}</div>
        </div>
    );
}

function Section({ title, ok, children, lang }: { title: React.ReactNode; ok: boolean; children?: React.ReactNode; lang: Lang }) {
    return (
        <div className="tw-rounded-lg tw-p-2.5 sm:tw-p-3 tw-bg-gray-100">
            <div className="tw-flex tw-items-center tw-gap-2">
                {ok ? <svg className="tw-w-4 tw-h-4 tw-text-gray-700 tw-flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                    : <svg className="tw-w-4 tw-h-4 tw-text-gray-500 tw-flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>}
                <Typography className="tw-font-medium tw-text-xs sm:tw-text-sm tw-text-gray-800">{title}</Typography>
            </div>
            {ok ? <Typography variant="small" className="!tw-text-green-600 tw-text-xs sm:tw-text-sm tw-ml-6">{t("allComplete", lang)}</Typography> : <div className="tw-ml-6 tw-mt-1">{children}</div>}
        </div>
    );
}

// ==================== PMValidationCard Component ====================
interface ValidationError {
    section: string;
    sectionIcon: string;
    itemName: string;
    message: string;
    scrollId?: string;
}

function groupErrorsBySection(errors: ValidationError[]): Map<string, ValidationError[]> {
    const map = new Map<string, ValidationError[]>();
    errors.forEach((err) => {
        const key = `${err.sectionIcon} ${err.section}`;
        if (!map.has(key)) map.set(key, []);
        map.get(key)!.push(err);
    });
    return map;
}

interface MissingInputItem {
    qNo: number;
    label: string;
    fieldKey: string;
}

interface PMValidationCardProps {
    lang: Lang;
    allPhotosAttached: boolean;
    missingPhotoItems: string[];
    allRequiredInputsFilled: boolean;
    missingInputsDetailed: MissingInputItem[];
    allPFAnsweredPost: boolean;
    missingPFItemsPost: string[];
    isSummaryFilled: boolean;
    isSummaryCheckFilled: boolean;
}

function PMValidationCard({
    lang,
    allPhotosAttached, missingPhotoItems,
    allRequiredInputsFilled, missingInputsDetailed,
    allPFAnsweredPost, missingPFItemsPost,
    isSummaryFilled, isSummaryCheckFilled,
}: PMValidationCardProps) {
    const [isExpanded, setIsExpanded] = useState(true);

    const handleHeaderClick = () => {
        setIsExpanded(!isExpanded);
    };

    const getPhotoScrollId = (item: string): string => `${ID_PREFIX}-photo-${idSuffixOfDisplayedNo(item)}`;

    const getPfButtonsScrollId = (item: string): string => `${ID_PREFIX}-pf-${idSuffixOfDisplayedNo(item)}`;

    const getInputScrollId = (qNo: number, fieldKey: string): string => {
        return `${ID_PREFIX}-input-${qNo}-${fieldKey}`;
    };

    const allErrors: ValidationError[] = useMemo(() => {
        const errors: ValidationError[] = [];

        // 1) Photo errors
        if (!allPhotosAttached) {
            missingPhotoItems.forEach((item) => {
                errors.push({
                    section: lang === "th" ? "รูปภาพ" : "Photos",
                    sectionIcon: "📷",
                    itemName: `${t("itemLabel", lang)} ${item}`,
                    message: lang === "th" ? "ยังไม่ได้แนบรูป" : "Photo not attached",
                    scrollId: getPhotoScrollId(item),
                });
            });
        }

        // 2) Input errors
        if (!allRequiredInputsFilled) {
            missingInputsDetailed.forEach(({ qNo, label, fieldKey }) => {
                const scrollId = getInputScrollId(qNo, fieldKey);
                const message = lang === "th" ? `ยังไม่ได้กรอกค่า ${label}` : `${label} value not filled`;
                errors.push({
                    section: lang === "th" ? "ค่าที่ต้องกรอก" : "Required Inputs",
                    sectionIcon: "📝",
                    itemName: `${t("itemLabel", lang)} ${getDisplayedQuestionNo(qNo)}`,
                    message,
                    scrollId,
                });
            });
        }

        // 3) PF status errors
        if (!allPFAnsweredPost) {
            missingPFItemsPost.forEach((item) => {
                errors.push({
                    section: lang === "th" ? "ระดับผลการตรวจ" : "Inspection rating",
                    sectionIcon: "✅",
                    itemName: `${t("itemLabel", lang)} ${item}`,
                    message: lang === "th" ? "ยังไม่ได้เลือกระดับผลการตรวจ" : "Inspection rating not selected",
                    scrollId: getPfButtonsScrollId(item),
                });
            });
        }

        // 4) Summary errors
        if (!isSummaryFilled) {
            errors.push({
                section: lang === "th" ? "สรุปผล" : "Summary",
                sectionIcon: "📋",
                itemName: "Comment",
                message: lang === "th" ? "ยังไม่ได้กรอก Comment" : "Comment not filled",
                scrollId: `${ID_PREFIX}-summary-section`,
            });
        }
        if (!isSummaryCheckFilled) {
            errors.push({
                section: lang === "th" ? "สรุปผล" : "Summary",
                sectionIcon: "📋",
                itemName: lang === "th" ? "สถานะสรุป" : "Summary Status",
                message: lang === "th" ? "ยังไม่ได้เลือกระดับผลการตรวจหรือ N/A" : "Inspection rating or N/A not selected",
                scrollId: `${ID_PREFIX}-summary-section`,
            });
        }

        return errors;
    }, [
        lang,
        allPhotosAttached, missingPhotoItems,
        allRequiredInputsFilled, missingInputsDetailed,
        allPFAnsweredPost, missingPFItemsPost,
        isSummaryFilled, isSummaryCheckFilled
    ]);

    const groupedErrors = useMemo(() => groupErrorsBySection(allErrors), [allErrors]);
    const isComplete = allErrors.length === 0;

    const scrollToItem = (scrollId?: string) => {
        if (!scrollId) return;
        const element = document.getElementById(scrollId);
        if (element) {
            const rect = element.getBoundingClientRect();
            const elementTop = rect.top + window.scrollY;
            const elementHeight = rect.height;
            const viewportHeight = window.innerHeight;
            let targetScrollY = elementTop - (viewportHeight / 2) + (elementHeight / 2);
            targetScrollY = Math.max(0, targetScrollY);
            const maxScrollY = document.documentElement.scrollHeight - viewportHeight;
            targetScrollY = Math.min(targetScrollY, maxScrollY);
            window.scrollTo({ top: targetScrollY, behavior: "smooth" });
            element.classList.add("tw-ring-2", "tw-ring-amber-400", "tw-bg-amber-50");
            setTimeout(() => {
                element.classList.remove("tw-ring-2", "tw-ring-amber-400", "tw-bg-amber-50");
            }, 2000);
        }
    };

    return (
        <div className={`tw-rounded-xl tw-border tw-shadow-sm tw-overflow-hidden ${isComplete ? "tw-border-green-200 tw-bg-green-50" : "tw-border-amber-200 tw-bg-amber-50"}`}>
            <div className={`tw-px-4 tw-py-3 tw-cursor-pointer tw-flex tw-items-center tw-justify-between ${isComplete ? "tw-bg-green-100" : "tw-bg-amber-100"}`} onClick={handleHeaderClick}>
                <div className="tw-flex tw-items-center tw-gap-3">
                    {isComplete ? (
                        <div className="tw-w-10 tw-h-10 tw-rounded-full tw-bg-green-500 tw-flex tw-items-center tw-justify-center">
                            <svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                    ) : (
                        <div className="tw-w-10 tw-h-10 tw-rounded-full tw-bg-amber-500 tw-flex tw-items-center tw-justify-center">
                            <svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                        </div>
                    )}
                    <div>
                        <Typography className={`tw-font-bold tw-text-base ${isComplete ? "tw-text-green-800" : "tw-text-amber-800"}`}>
                            {t("formStatus", lang)}
                        </Typography>
                        <Typography variant="small" className={isComplete ? "tw-text-green-600" : "tw-text-amber-600"}>
                            {isComplete ? t("allCompleteReady", lang) : t("remaining", lang).replace("{n}", String(allErrors.length))}
                        </Typography>
                    </div>
                </div>
                <div className="tw-flex tw-items-center tw-gap-4">
                    {!isComplete && (
                        <div className="tw-hidden md:tw-flex tw-items-center tw-gap-2">
                            {Array.from(groupedErrors.keys()).map((sectionKey) => (
                                <span key={sectionKey} className="tw-text-xs tw-bg-amber-200 tw-text-amber-800 tw-px-2 tw-py-1 tw-rounded-full tw-font-medium">
                                    {sectionKey.split(" ")[0]} {groupedErrors.get(sectionKey)?.length}
                                </span>
                            ))}
                        </div>
                    )}
                    {!isComplete && (
                        <svg className={`tw-w-6 tw-h-6 tw-text-amber-600 tw-transition-transform ${isExpanded ? "tw-rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                    )}
                </div>
            </div>
            {isExpanded && !isComplete && (
                <div className="tw-px-4 tw-py-3 tw-max-h-80 tw-overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                    <div className="tw-space-y-4">
                        {Array.from(groupedErrors.entries()).map(([sectionKey, sectionErrors]) => (
                            <div key={sectionKey} className="tw-bg-white tw-rounded-lg tw-p-3 tw-border tw-border-amber-200">
                                <div className="tw-flex tw-items-center tw-justify-between tw-mb-2">
                                    <Typography className="tw-font-semibold tw-text-gray-800 tw-text-sm">{sectionKey}</Typography>
                                    <span className="tw-text-xs tw-bg-amber-100 tw-text-amber-700 tw-px-2 tw-py-0.5 tw-rounded-full">
                                        {sectionErrors.length} {t("items", lang)}
                                    </span>
                                </div>
                                <ul className="tw-space-y-1 tw-max-h-40 tw-overflow-y-auto">
                                    {sectionErrors.map((error, idx) => (
                                        <li key={idx} className="tw-flex tw-items-start tw-gap-2 tw-text-sm tw-text-amber-700 tw-cursor-pointer hover:tw-text-amber-900 hover:tw-bg-amber-50 tw-rounded tw-px-1 tw-py-0.5 tw-transition-colors" onClick={(e) => { e.stopPropagation(); scrollToItem(error.scrollId); }}>
                                            <span className="tw-text-amber-500 tw-mt-0.5">→</span>
                                            <span>
                                                <span className="tw-font-medium">{error.itemName}:</span>{" "}
                                                <span className="tw-underline tw-underline-offset-2">{error.message}</span>
                                            </span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

function InputWithUnit({ label, value, unit, onValueChange, readOnly, disabled, required = false, id }: {
    label: string; value: string; unit: string; onValueChange: (v: string) => void; readOnly?: boolean; disabled?: boolean; required?: boolean; id?: string;
}) {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = e.target.value;
        if (newValue === "" || /^-?\d*\.?\d*$/.test(newValue)) onValueChange(newValue);
    };
    return (
        <div id={id} className="tw-flex tw-items-center tw-gap-2">
            <div className="tw-flex-1 tw-relative">
                <input type="text" inputMode="numeric" pattern="-?[0-9]*\.?[0-9]*" value={value} onChange={handleChange} readOnly={readOnly} disabled={disabled} required={required} placeholder=" "
                    className={`tw-peer tw-w-full tw-h-10 tw-px-3 tw-pt-4 tw-pb-1 tw-text-sm tw-border tw-border-gray-300 tw-rounded-lg tw-outline-none focus:tw-border-blue-500 focus:tw-ring-1 focus:tw-ring-blue-500 ${disabled ? "tw-bg-gray-100 tw-text-gray-500" : "tw-bg-white"}`} />
                <label className="tw-absolute tw-left-3 tw-top-1 tw-text-[10px] tw-text-gray-500 tw-pointer-events-none">{label}{required && <span className="tw-text-red-500">*</span>}</label>
            </div>
            <div className="tw-flex-shrink-0 tw-w-10 tw-h-10 tw-flex tw-items-center tw-justify-center tw-text-gray-600 tw-font-medium tw-text-sm tw-bg-gray-100 tw-rounded-lg tw-border tw-border-gray-200">{unit}</div>
        </div>
    );
}

function PassFailRow({ label, value, onChange, remark, onRemarkChange, labels, aboveRemark, beforeRemark, showPfButtons = true, lang, id, remarkId }: {
    label: string; value: PF; onChange: (v: Rating | "NA") => void; remark?: string; onRemarkChange?: (v: string) => void;
    labels?: Partial<Record<Exclude<PF, "">, React.ReactNode>>; aboveRemark?: React.ReactNode; beforeRemark?: React.ReactNode; showPfButtons?: boolean; lang: Lang; id?: string; remarkId?: string;
}) {
    const text = {
        VERY_GOOD: labels?.VERY_GOOD ?? (lang === "th" ? "ดีมาก" : "Excellent"),
        GOOD: labels?.GOOD ?? (lang === "th" ? "ดี" : "Good"),
        FAIR: labels?.FAIR ?? (lang === "th" ? "พอใช้" : "Fair"),
        UNUSABLE: labels?.UNUSABLE ?? (lang === "th" ? "ใช้งานไม่ได้" : "Unusable"),
        NA: labels?.NA ?? t("na", lang),
    };
    // layout เดียวกับทุกฟอร์ม PM: หัวข้อ → รูป → ปุ่มระดับผลชิดขวา → หมายเหตุ
    const buttonGroup = (
        <div id={id} className="tw-flex tw-flex-wrap tw-gap-2 tw-ml-auto tw-transition-all tw-duration-300">
            <Button size="sm" color="green" variant={value === "VERY_GOOD" || value === "PASS" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("VERY_GOOD")}>{text.VERY_GOOD}</Button>
            <Button size="sm" color="light-green" variant={value === "GOOD" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("GOOD")}>{text.GOOD}</Button>
            <Button size="sm" color="amber" variant={value === "FAIR" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("FAIR")}>{text.FAIR}</Button>
            <Button size="sm" color="red" variant={value === "UNUSABLE" || value === "FAIL" ? "filled" : "outlined"} className="sm:tw-min-w-[112px]" onClick={() => onChange("UNUSABLE")}>{text.UNUSABLE}</Button>
            <Button size="sm" color="blue-gray" variant={value === "NA" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("NA")}>{text.NA}</Button>
        </div>
    );
    const buttonsRow = (
        <div className="tw-flex tw-items-center tw-gap-3 tw-w-full">
            {buttonGroup}
        </div>
    );
    return (
        <div className="tw-space-y-3 tw-py-3">
            <Typography className="tw-font-medium">{label}</Typography>
            {onRemarkChange ? (
                <div className="tw-w-full tw-min-w-0 tw-space-y-2">
                    {aboveRemark}
                    {showPfButtons && buttonsRow}
                    {beforeRemark}
                    <div id={remarkId} className="tw-transition-all tw-duration-300">
                        <Textarea label={t("remark", lang)} value={remark || ""} onChange={(e) => onRemarkChange(e.target.value)}
                            containerProps={{ className: "!tw-w-full !tw-min-w-0" }} className="!tw-w-full" />
                    </div>
                </div>
            ) : (
                showPfButtons && <div className="tw-flex tw-flex-col sm:tw-flex-row tw-gap-2 sm:tw-items-center sm:tw-justify-between">{buttonsRow}</div>
            )}
        </div>
    );
}

function PhotoMultiInput({ photos, setPhotos, max = 10, draftKey, qNo, lang, id }: {
    photos: PhotoItem[]; setPhotos: React.Dispatch<React.SetStateAction<PhotoItem[]>>;
    max?: number; draftKey: string; qNo: number; lang: Lang; id?: string;
}) {
    const cameraRef = useRef<HTMLInputElement>(null);
    const fileRef = useRef<HTMLInputElement>(null);
    const isMobile = useMemo(() => isMobileDevice(), []);
    const [landscapeWarning, setLandscapeWarning] = useState(false);

    const processFile = async (rawFile: File): Promise<PhotoItem | null> => {
        try {
            // กันไฟล์ว่าง (size=0) ตั้งแต่ต้นทาง — เป็นต้นเหตุของ error "Empty file (size=0)" ตอนอัปโหลด
            if (!rawFile || rawFile.size === 0) {
                console.warn("processFile: empty source file", rawFile?.name);
                return null;
            }
            // รูป HEIC จาก iPhone: เบราว์เซอร์นอกจาก Safari decode ไม่ได้ ทำให้ทั้งท่อพังเงียบ ๆ
            // — addTimestampToImage ไม่ประทับเวลา/พิกัด, compressImage ไม่บีบ, preview ขึ้นกรอบว่าง
            // แปลงเป็น JPEG ที่ server ก่อน (ล้มเหลวก็คืนไฟล์เดิม backend แปลงให้อีกชั้นตอนอัปโหลด)
            const file = await ensureViewableImage(rawFile);
            const locationText = await getCachedLocation();
            const stamped = await addTimestampToImage(file, locationText);
            // ถ้า encode แล้วได้ไฟล์ว่าง (เช่น canvas ล้มเหลวบางเครื่อง) ให้ fallback ไฟล์เดิม แล้วเช็กซ้ำ
            const fileWithTimestamp = (stamped && stamped.size > 0) ? stamped : file;
            if (fileWithTimestamp.size === 0) {
                console.warn("processFile: empty file after timestamp", file.name);
                return null;
            }
            // บีบรูปก่อนเก็บลง IndexedDB — ลดพื้นที่จัดเก็บ (กัน quota เต็มบนมือถือ) + ได้รูปที่พร้อมอัปโหลดเลย
            const compressed = await compressImage(fileWithTimestamp);
            const finalFile = (compressed && compressed.size > 0) ? compressed : fileWithTimestamp;
            // ⚡ ดักตั้งแต่ตอนแนบ: .size เชื่อไม่ได้ (iOS คืน backing store แต่ยังรายงาน size เดิม)
            if (!(await isFileReadable(finalFile))) {
                console.warn("processFile: ไฟล์อ่านไม่ได้ตั้งแต่ตอนแนบ", file.name);
                return null;
            }
            // หมายเหตุ: เคย return null ตรงนี้ถ้า decode ไม่ผ่าน แต่ทำให้แนบรูปไม่ได้เลย
            // เพราะ CSP img-src ไม่อนุญาต blob: การโหลดรูปเลยล้มเหลวทุกใบ
            // เหลือไว้เป็น log อย่างเดียว ห้ามใช้ block การแนบรูป
            if (!(await isImageDecodable(finalFile))) {
                console.warn("processFile: เบราว์เซอร์แสดงผลรูปนี้ไม่ได้", file.name, file.type);
            }

            const photoId = `${qNo}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${file.name}`;
            // เขียน IndexedDB ไม่ได้ (พื้นที่เต็ม / private mode) → ห้ามทิ้งรูป เก็บใน memory ต่อแล้วเตือน
            let ref: PhotoRef | undefined;
            try { ref = await putPhoto(draftKey, photoId, finalFile); }
            catch (e) { console.error("putPhoto failed:", e); reportPhotoStorageFailure(lang); }
            const now = new Date().toLocaleString("th-TH", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
            return { id: photoId, file: finalFile, preview: URL.createObjectURL(finalFile), remark: "", ref, createdAt: now, location: locationText };
        } catch (err) { console.error("processFile error:", err); return null; }
    };

    const handleFiles = async (list: FileList | null, fromCamera: boolean) => {
        if (!list || list.length === 0) return;
        const remain = Math.max(0, max - photos.length);
        if (remain === 0) { alert(lang === "th" ? `แนบรูปได้สูงสุด ${max} รูปต่อข้อ` : `Maximum ${max} photos per item`); return; }
        const files = Array.from(list).slice(0, remain);
        if (Array.from(list).length > remain) alert(lang === "th" ? `เลือกได้อีก ${remain} รูป (ครบ ${max} รูปแล้ว)` : `Only ${remain} more photo(s) allowed (max ${max})`);
        let hasLandscape = false;
        const validFiles: File[] = [];
        for (const f of files) {
            if (fromCamera) {
                try { const dim = await getImageDimensions(f); if (dim.width > dim.height) { hasLandscape = true; continue; } } catch { }
            }
            validFiles.push(f);
        }
        const results = await Promise.all(validFiles.map(f => processFile(f)));
        const accepted = results.filter(Boolean) as PhotoItem[];
        const rejected = validFiles.length - accepted.length;
        if (accepted.length > 0) setPhotos(prev => [...prev, ...accepted]);
        // แจ้งเตือนถ้ามีรูปว่าง/เสียหายถูกข้าม — กันผู้ใช้เข้าใจผิดว่าแนบครบแล้ว
        if (rejected > 0) {
            alert(lang === "th"
                ? `มีรูปว่าง/เสียหาย ${rejected} รูป ใช้ไม่ได้ กรุณาถ่ายหรือเลือกใหม่อีกครั้ง`
                : `${rejected} photo(s) are empty/corrupted and were skipped. Please retake or reselect.`);
        }
        if (hasLandscape) setLandscapeWarning(true);
        if (cameraRef.current) cameraRef.current.value = "";
        if (fileRef.current) fileRef.current.value = "";
    };

    const handleRemove = async (id: string) => {
        await delPhoto(draftKey, id);
        setPhotos(prev => { const target = prev.find(p => p.id === id); if (target?.preview) URL.revokeObjectURL(target.preview); return prev.filter(p => p.id !== id); });
    };

    return (
        <div id={id} className="tw-space-y-3 tw-transition-all tw-duration-300">
            {landscapeWarning && (
                <div className="tw-fixed tw-inset-0 tw-z-[9999] tw-bg-black/70 tw-flex tw-items-center tw-justify-center tw-p-6" onClick={() => setLandscapeWarning(false)}>
                    <div className="tw-bg-white tw-rounded-2xl tw-p-6 tw-max-w-sm tw-text-center tw-shadow-xl" onClick={e => e.stopPropagation()}>
                        <svg className="tw-w-14 tw-h-14 tw-text-amber-500 tw-mx-auto tw-mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                        <p className="tw-text-lg tw-font-bold tw-text-gray-800 tw-mb-2">{lang === "th" ? "กรุณาถ่ายรูปแนวตั้ง" : "Please take portrait photos"}</p>
                        <p className="tw-text-sm tw-text-gray-600 tw-mb-4">{lang === "th" ? "รูปที่ถ่ายเป็นแนวนอนจะไม่ถูกรับ กรุณาหมุนมือถือเป็นแนวตั้งแล้วถ่ายใหม่" : "Landscape photos are not accepted. Please hold your phone upright and retake."}</p>
                        <Button size="sm" color="amber" variant="filled" onClick={() => setLandscapeWarning(false)} className="tw-w-full">{lang === "th" ? "รับทราบ" : "OK"}</Button>
                    </div>
                </div>
            )}
            <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2">
                {isMobile ? (
                    <Button data-photo-add size="sm" color="blue" variant="outlined" onClick={() => cameraRef.current?.click()} className="tw-shrink-0 tw-flex tw-items-center tw-gap-1">
                        <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                        {lang === "th" ? "ถ่ายรูป" : "Take Photo"}
                    </Button>
                ) : (
                    <Button data-photo-add size="sm" color="blue" variant="outlined" onClick={() => fileRef.current?.click()} className="tw-shrink-0 tw-flex tw-items-center tw-gap-1">
                        <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        {t("attachPhoto", lang)}
                    </Button>
                )}
            </div>
            {isMobile && <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="tw-hidden" onChange={e => { void handleFiles(e.target.files, true); }} />}
            {!isMobile && <input ref={fileRef} type="file" accept="image/*" multiple className="tw-hidden" onChange={e => { void handleFiles(e.target.files, false); }} />}
            <Typography variant="small" className="!tw-text-blue-gray-500">{t("maxPhotos", lang)} {max} {t("photos", lang)}</Typography>
            {photos.length > 0 ? (
                <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-3 md:tw-grid-cols-4 tw-gap-3">
                    {photos.map(p => (
                        <div key={p.id} className="tw-border tw-rounded-lg tw-overflow-hidden tw-bg-gray-100 tw-shadow-xs tw-flex tw-flex-col">
                            <div className="tw-relative tw-aspect-[4/3] tw-bg-gray-100">
                                {p.preview && <img src={p.preview} alt="preview" className="tw-w-full tw-h-full tw-object-contain" />}
                                <button data-photo-remove onClick={() => { void handleRemove(p.id); }} className="tw-absolute tw-top-2 tw-right-2 tw-bg-red-500 tw-text-white tw-w-6 tw-h-6 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-shadow-md hover:tw-bg-red-600 tw-transition-colors">×</button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (<Typography variant="small" className="!tw-text-blue-gray-500">{t("noPhotos", lang)}</Typography>)}
        </div>
    );
}

// ==================== MAIN COMPONENT ====================

export default function CBBOXPMForm() {
    const { lang } = useLanguage();
    const router = useRouter();
    const searchParams = useSearchParams();

    // ปุ่มย้อนกลับ: เปิดมาจากหน้า PM List ให้กลับไปหน้านั้นตรงๆ
    const goBackToList = useCallback(() => {
        // กลับหน้าที่เปิดเข้ามา: หน้ารวมของใบ PM สถานี / PM List — นอกนั้นถอยประวัติ
        const back = pmFormReturnRoute(searchParams);
        if (back) router.push(back);
        else router.back();
    }, [router, searchParams]);
    const editId = searchParams.get("edit_id") ?? "";
    // เปิดจากใบ PM สถานี "ใบเดียว 4 ส่วน" → ผูกใบนี้เป็นส่วนหนึ่งของใบแม่
    const jobId = searchParams.get("job_id") ?? "";
    const action = searchParams.get("action");

    const [submitting, setSubmitting] = useState(false);
    const [docName, setDocName] = useState("");
    const [reportId, setReportId] = useState("");
    const [stationId, setStationId] = useState<string | null>(null);
    // เปิดจากใบ PM สถานี → หัวฟอร์มใช้เลขที่/ชื่อเอกสารของใบแม่ (ส่วนที่ยังไม่บันทึกไม่มีเลขในตัวเอง)
    const jobDocIds = useJobDocIds(jobId, stationId ?? searchParams.get("station_id"));
    const [summary, setSummary] = useState("");
    const [summaryCheck, setSummaryCheck] = useState<PF>("");
    // เวลาทำงานจริงของช่าง (datetime-local) — ส่งเข้า Maximo ทาง IN09 ตอนปิดใบงาน

    const [workStart, setWorkStart] = useState<string>("");
    const [workFinish, setWorkFinish] = useState<string>("");
    // planner เปิดเอกสารที่ช่างส่งมาเพื่อตรวจก่อนอนุมัติ (?approve=1)
    const approveMode = searchParams.get("approve") === "1";
    // ช่างเปิดดูใบที่ตัวเองส่งไปแล้ว (?review=1) — เห็นหน้าเดียวกับ planner
    // แต่แก้อะไรไม่ได้ และไม่มีปุ่ม Reject/Approve
    const reviewMode = approveMode || searchParams.get("review") === "1";
    const reviewAction = usePmReviewAction();
    const cancelEditAction = usePmCancelEdit();

    // laborcode ฝั่ง Maximo ที่ช่างเลือกเอง — username ใน iMPS ใช้แทนกันไม่ได้
    const [laborOptions, setLaborOptions] = useState<{ laborcode: string; name: string; needs_name?: boolean }[]>([]);
    const [maximoLabor, setMaximoLabor] = useState<string[]>([]);
    const [maximoContractor, setMaximoContractor] = useState<string>("");

    useEffect(() => {
        let alive = true;
        (async () => {
            try {
                const res = await fetch(`${API_BASE}/cm-maximo/labor-codes`, { credentials: "include" });
                if (!res.ok) return;
                const data = await res.json();
                if (alive && Array.isArray(data?.items)) setLaborOptions(data.items);
            } catch {
                // ดึงไม่ได้ = ไม่โชว์ตัวเลือก ไม่ต้องบล็อกการกรอกใบงาน
            }
        })();
        return () => { alive = false; };
    }, []);

    const toggleMaximoLabor = (code: string) =>
        setMaximoLabor(prev => prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]);

    // ติ๊กรหัสกลางของผู้รับเหมาไว้ = ต้องมีชื่อจริงกำกับ

    // รหัสที่ช่างเลือกไว้ต้องโชว์ได้เสมอ ถึงรายชื่อจาก Maximo จะโหลดไม่ขึ้น
    // (เน็ตหลุด / สิทธิ์ไม่ถึง) ไม่งั้นหน้าอนุมัติจะกลายเป็นว่าไม่ได้เลือกใครเลย
    const laborList = useMemo(() => {
        const have = new Set(laborOptions.map((o) => o.laborcode));
        const missing = maximoLabor.filter((c) => !have.has(c)).map((c) => ({ laborcode: c, name: c }));
        const all = missing.length ? [...laborOptions, ...missing] : laborOptions;
        // โหมดตรวจไม่ต้องเห็นรายชื่อทั้งกรม เอาเฉพาะคนที่ช่างเลือกลงใบงานนี้
        return reviewMode ? all.filter((o) => maximoLabor.includes(o.laborcode)) : all;
    }, [laborOptions, maximoLabor, reviewMode]);
    const contractorPicked = laborOptions.some((o) => o.needs_name && maximoLabor.includes(o.laborcode));
    const contractorMissing = contractorPicked && !maximoContractor.trim();
    const [inspector, setInspector] = useState("");
    const [postApiLoaded, setPostApiLoaded] = useState(false);
    // ใบใหม่ยังไม่มีวันที่จากเอกสาร — ใช้วันนี้ (backend ก็ใช้วันนี้ตอนสร้างใบ) ให้ตรงกับที่หน้าดูจะแสดง
    const [job, setJob] = useState({ issue_id: "", station_name: "", date: editId ? "" : getTodayLocalStr() });
    const [dropdownQ1, setDropdownQ1] = useState("");
    const [dropdownQ2, setDropdownQ2] = useState("");

    const initialPhotos: Record<number, PhotoItem[]> = Object.fromEntries(
        QUESTIONS.filter(q => q.hasPhoto).flatMap(q => q.items
            ? q.items.map((_, idx) => [getSubPhotoKey(q.no, idx), []] as [number, PhotoItem[]])
            : [[q.no, []] as [number, PhotoItem[]]])
    ) as Record<number, PhotoItem[]>;
    const [photos, setPhotos] = useState<Record<number, PhotoItem[]>>(initialPhotos);
    // รูปเดิมของเอกสารที่โหลดมาใส่ฟอร์ม (หน้าดู / แก้ส่วนที่ส่งแล้ว) — ตอนบันทึกเทียบกับ photos
    // เพื่อรู้ว่าผู้ใช้กดลบรูปเดิมรูปไหนออก แล้วลบออกจากเอกสารจริง
    const serverPhotosRef = useRef<Record<string, ViewPhoto[]>>({});
    const photosRef = useRef(photos);
    useEffect(() => { photosRef.current = photos; }, [photos]);
    useEffect(() => () => {
        Object.values(photosRef.current).flat().forEach((p: any) => {
            if (typeof p?.preview === "string" && p.preview.startsWith("blob:")) URL.revokeObjectURL(p.preview);
        });
    }, []);

    const [rows, setRows] = useState<Record<string, { pf: PF; remark: string }>>(() => {
        const initial: Record<string, { pf: PF; remark: string }> = {};
        QUESTIONS.forEach(q => {
            if (q.items) q.items.forEach(it => { initial[it.key] = { pf: "", remark: "" }; });
            else initial[q.key] = { pf: "", remark: "" };
        });
        return initial;
    });

    const m5 = useMeasure(VOLTAGE_FIELDS);

    // ใบใหม่ (เปิดจาก job_id ยังไม่มี edit_id) ก็ต้องมี key ของตัวเอง ไม่งั้นรีโหลดแล้วข้อมูลหาย
    const postKey = useMemo(
        () => `${draftKey(stationId)}:${editId ? editId : (jobId ? `job-${jobId}` : "new")}:post`,
        [stationId, editId, jobId],
    );
    // key ที่กู้ draft เสร็จแล้ว — autosave ต้องรอให้ตรงกับ postKey ก่อน
    // ไม่งั้น state ว่างตอนเปิดหน้าจะเขียนทับ draft ก่อนได้กู้
    const [restoredKey, setRestoredKey] = useState<string | null>(null);
    // ส่งเสร็จแล้วล้าง draft — autosave ที่ค้างอยู่ (รวมตอนออกจากหน้า) ห้ามเขียนกลับ
    const draftClearedRef = useRef(false);
    // ปุ่ม "ยกเลิกการแก้ไข" ที่หน้ารวมล้าง draft ของฟอร์มนี้ผ่านตัวนี้ (หน้ารวมไม่รู้สูตร key ของแต่ละฟอร์ม)
    useEffect(() => registerDraftDiscard(async () => {
        draftClearedRef.current = true; // กัน autosave ที่ค้างอยู่เขียนกลับมาตอนออกจากหน้า
        await clearDraftLocal(postKey);
    }), [postKey]);
    useEffect(() => { draftClearedRef.current = false; }, [postKey]);
    const restoringKeyRef = useRef<string | null>(null);

    // Load station id
    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const sid = params.get("station_id") || localStorage.getItem("selected_station_id");
        if (sid) setStationId(sid);
    }, []);

    useEffect(() => {
        if (!stationId) return;
        let alive = true;
        fetchStationName(stationId)
            .then(name => { if (alive && name) setJob(prev => ({ ...prev, station_name: prev.station_name || name })); })
            .catch(err => console.error("load station info failed:", err));
        return () => { alive = false; };
    }, [stationId]);

    // Load me — หน้าดูข้อมูลต้องโชว์ผู้ตรวจที่บันทึกในเอกสาร ไม่ใช่คนที่เปิดดู
    useEffect(() => {
        if (reviewMode) return;
        fetch(`${API_BASE}/me`, { credentials: "include" })
            .then(res => res.ok ? res.json() : null)
            .then((data: Me | null) => { if (data) setInspector(prev => prev || data.username || ""); })
            .catch(console.error);
    }, []);

    // Load API data for Post mode
    useEffect(() => {
        if (!editId || !stationId) return;
        setPostApiLoaded(false);
        fetchReport(editId, stationId).then(data => {
            if (data.job) setJob(prev => ({ ...prev, ...data.job, station_name: data.job.station_name || prev.station_name, issue_id: data.issue_id ?? prev.issue_id }));
            if (data.pm_date) setJob(prev => ({ ...prev, date: data.pm_date }));
            if (data.doc_name) setDocName(data.doc_name);
            if (data.inspector) setInspector(data.inspector);
            if (data.dropdownQ1) setDropdownQ1(data.dropdownQ1);
            if (data.dropdownQ2) setDropdownQ2(data.dropdownQ2);
            if (data.summary) setSummary(data.summary);
                // สรุปผล/หมายเหตุเดิมอ่านจาก draft ในเครื่องอย่างเดียว คนที่ไม่ได้เป็นคนกรอก
                // (ผู้อนุมัติ) จึงเปิดมาเจอช่องว่าง ต้องดึงจากตัวเอกสารด้วย
                // ส่วนหนึ่งของใบ PM สถานี: เปิดแก้ส่วนที่ส่งแล้ว (เครื่องนี้ไม่มี draft) ก็ต้องได้ค่าเดิมจากเอกสาร
                if (reviewMode || jobId) {
                    // เวลาทำงาน/laborcode ก็เก็บอยู่ใน draft ของเครื่องช่างเหมือนกัน
                    // ผู้อนุมัติต้องอ่านจากตัวเอกสาร ไม่งั้นเห็นเป็นช่องว่าง
                    if (typeof data.work_start === "string") setWorkStart(data.work_start);
                    if (typeof data.work_finish === "string") setWorkFinish(data.work_finish);
                    if (Array.isArray(data.maximo_labor)) setMaximoLabor(data.maximo_labor);
                    if (typeof data.maximo_contractor === "string") setMaximoContractor(data.maximo_contractor);
                    if (typeof data.summary === "string") setSummary(data.summary);
                    if (data.summaryCheck) setSummaryCheck(data.summaryCheck as PF);
                    // หน้าดูใช้ฟอร์มเดียวกับตอนกรอก — รูป/ค่าที่วัดมาจากเอกสาร ไม่ใช่ draft ในเครื่อง
                    const fromServer = serverPhotosToForm(data.photos,
                        formKeyFromForward(Object.keys(initialPhotos).map(Number), k => photoGroupKey(k)), API_BASE);
                    serverPhotosRef.current = fromServer;
                    setPhotos(prev => ({ ...prev, ...fromServer }) as typeof prev);
                    if (data.measures?.m5) m5.setState(measureAsText(data.measures.m5));
                }
            if (data.rows) setRows(prev => ({ ...prev, ...data.rows }));
            setPostApiLoaded(true);
        }).catch(err => { console.error(err); setPostApiLoaded(true); });
    }, [editId, stationId]);

    const makePhotoSetter = (no: number): React.Dispatch<React.SetStateAction<PhotoItem[]>> => {
        return action => setPhotos(prev => ({ ...prev, [no]: typeof action === "function" ? action(prev[no] ?? []) : action }));
    };

    // Validation
    const photoKeysOfQuestion = (q: Question): number[] => q.items ? q.items.map((_, idx) => getSubPhotoKey(q.no, idx)) : [q.no];
    const REQUIRED_PHOTO_ITEMS_POST = useMemo(() => QUESTIONS.filter(q => q.hasPhoto).flatMap(photoKeysOfQuestion), []);

    // ข้อที่ตอบ N/A ไม่ต้องแนบรูป
    const missingPhotoItemsPost = useMemo(() => REQUIRED_PHOTO_ITEMS_POST.filter(no => { if (rows[rowKeyOfPhotoKey(no)]?.pf === "NA") return false; return (photos[no]?.length ?? 0) < 1; }), [photos, rows]);

    const allPhotosAttachedPost = missingPhotoItemsPost.length === 0;

    // Format missingPhotoItems as string[] for PMValidationCard
    const missingPhotoItemsFormatted = useMemo(() => {
        return missingPhotoItemsPost.map(displayedNoOfPhotoKey);
    }, [missingPhotoItemsPost]);

    const rowKeysOfQuestion = (q: Question): string[] => q.items ? q.items.map(it => it.key) : [q.key];
    // ข้อ 1-2 (pre_r1/pre_r2 = สภาพก่อนบำรุงรักษา) และข้อ 4-5 (dropdown) ไม่มีปุ่มระดับผล
    const PF_KEYS_POST = useMemo(() => QUESTIONS.filter(q => {
        if (q.key.startsWith("pre_")) return false;
        if (q.no === 1 || q.no === 2) return false;
        return true;
    }).flatMap(rowKeysOfQuestion), []);

    const allPFAnsweredPost = useMemo(() => PF_KEYS_POST.every(k => rows[k]?.pf !== ""), [rows, PF_KEYS_POST]);
    const missingPFItemsPost = useMemo(() => PF_KEYS_POST.filter(k => !rows[k]?.pf).map(k => {
        const sub = k.match(/^r(\d+)_(\d+)$/);
        if (sub) return `${getDisplayedQuestionNo(Number(sub[1]))}.${sub[2]}`;
        return String(getDisplayedQuestionNo(Number(k.replace("r", ""))));
    }).sort((a, b) => {
        const [aM, aS] = a.split(".").map(Number);
        const [bM, bS] = b.split(".").map(Number);
        return aM !== bM ? aM - bM : (aS || 0) - (bS || 0);
    }), [rows, PF_KEYS_POST]);

    // ข้อ 5 ตอบ N/A ไม่ต้องกรอกค่าแรงดัน

    // Detailed missing inputs for PMValidationCard
    // ค่าที่วัดได้ (แรงดัน / CP ฯลฯ) ไม่บังคับกรอกแล้ว — ช่างเว้นว่างได้ ส่วนรูป/ผลตรวจ/สรุปยังบังคับเหมือนเดิม
    const missingInputsDetailed: React.ComponentProps<typeof PMValidationCard>["missingInputsDetailed"] = [];

    const allRequiredInputsFilled = true;
    const isSummaryFilled = summary.trim().length > 0;
    const isSummaryCheckFilled = summaryCheck !== "";

    const canFinalSave = allPhotosAttachedPost && allPFAnsweredPost && allRequiredInputsFilled && isSummaryFilled && isSummaryCheckFilled;

    // Auto-save draft
    const photoRefs = useMemo(() => {
        const out: Record<number, (PhotoRef | { isNA: true })[]> = {};
        Object.entries(photos).forEach(([noStr, list]) => {
            out[Number(noStr)] = (list || [])
                .map(p => {
                    if (p.isNA) return { isNA: true } as const;
                    if (!p.ref) return null;
                    return { ...p.ref, uploaded: p.uploaded === true } as PhotoRef & { uploaded: boolean };
                })
                .filter(Boolean) as (PhotoRef | { isNA: true })[];
        });
        return out;
    }, [photos]);

    // Restore draft — ใบเดิมรอข้อมูลจาก API ก่อนแล้วค่อยทับด้วย draft, ใบใหม่กู้ได้ทันทีที่รู้ stationId
    useEffect(() => {
        if (reviewMode || !stationId) return;
        if (editId && !postApiLoaded) return;
        if (restoredKey === postKey || restoringKeyRef.current === postKey) return;
        restoringKeyRef.current = postKey;
        const key = postKey;
        const draft = loadDraftLocal<{
            rows?: typeof rows; m5?: MeasureState; summary?: string; summaryCheck?: PF;
            dropdownQ1?: string; dropdownQ2?: string; workStart?: string; workFinish?: string;
            maximoLabor?: string[]; maximoContractor?: string;
            photoRefs?: Record<string, ((PhotoRef & { uploaded?: boolean }) | { isNA: true })[]>;
        }>(key);
        if (!draft) { setRestoredKey(key); return; }
        if (draft.rows) setRows(prev => ({ ...prev, ...draft.rows }));
        if (draft.m5) m5.setState(prev => ({ ...prev, ...draft.m5 }));
        if (typeof draft.summary === "string" && draft.summary) setSummary(draft.summary);
        if (draft.summaryCheck) setSummaryCheck(draft.summaryCheck);
        if (draft.dropdownQ1) setDropdownQ1(draft.dropdownQ1);
        if (draft.dropdownQ2) setDropdownQ2(draft.dropdownQ2);
        if (draft.workStart) setWorkStart(draft.workStart);
        if (draft.workFinish) setWorkFinish(draft.workFinish);
        if (Array.isArray(draft.maximoLabor)) setMaximoLabor(draft.maximoLabor);
        if (typeof draft.maximoContractor === "string") setMaximoContractor(draft.maximoContractor);
        (async () => {
            try {
                if (!draft.photoRefs) return;
                const next: Record<string, PhotoItem[]> = {};
                let missing = 0;
                for (const [photoKey, refs] of Object.entries(draft.photoRefs)) {
                    const items: PhotoItem[] = [];
                    for (const ref of refs || []) {
                        if ("isNA" in ref && ref.isNA) { items.push({ id: `${photoKey}-NA-restored`, isNA: true }); continue; }
                        const r = ref as PhotoRef & { uploaded?: boolean };
                        if (!r.id || !r.dbKey) continue;
                        const file = await getPhotoByDbKey(r.dbKey);
                        if (!file || file.size === 0) {
                            console.warn("Photo missing/empty in IndexedDB:", r.dbKey);
                            missing++;
                            continue;
                        }
                        items.push({ id: r.id, file, preview: URL.createObjectURL(file), remark: (r as any).remark ?? "", ref: r, uploaded: r.uploaded === true });
                    }
                    if (items.length > 0) next[photoKey] = items;
                }
                if (restoringKeyRef.current !== key) {
                    Object.values(next).flat().forEach(p => { if (p.preview) URL.revokeObjectURL(p.preview); });
                    return;
                }
                for (let i = 0; i < missing; i++) reportMissingDraftPhoto(lang);
                if (Object.keys(next).length > 0) setPhotos(prev => mergeDraftPhotos(prev as any, next as any) as typeof prev);
            } catch (err) {
                console.error("restore draft photos failed:", err);
            } finally {
                if (restoringKeyRef.current === key) setRestoredKey(key);
            }
        })();
    }, [stationId, editId, postKey, postApiLoaded, reviewMode, restoredKey]);

    useDebouncedEffect(() => {
        if (reviewMode || !stationId || restoredKey !== postKey || draftClearedRef.current) return;
        saveDraftLocal(postKey, {
            ...loadDraftLocal<any>(postKey),
            rows, m5: m5.state, summary, summaryCheck, dropdownQ1, dropdownQ2,
            workStart, workFinish, maximoLabor, maximoContractor, photoRefs,
        });
    }, [postKey, stationId, restoredKey, reviewMode, rows, m5.state, summary, summaryCheck, dropdownQ1, dropdownQ2, workStart, workFinish, maximoLabor, maximoContractor, photoRefs]);


    // Render measure grid
    const renderMeasureGrid = (no: number) => {
        const cfg = FIELD_GROUPS[no]; if (!cfg) return null;
        return (
            <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-3 md:tw-grid-cols-5 tw-gap-3">
                {cfg.keys.map(k => (
                    <div key={k}>
                        <InputWithUnit
                            label={LABELS[k] ?? k}
                            value={m5.state[k]?.value || ""}
                            unit="V"
                            onValueChange={v => m5.patch(k, { value: v })}
                            id={getInputIdFromKey(no, k)}
                        />
                    </div>
                ))}
            </div>
        );
    };

    // Render question block
    const renderQuestionBlock = (q: Question) => {
        const hasMeasure = q.kind === "measure" && !!FIELD_GROUPS[q.no];
        const qTooltip = q.tooltip?.[lang];

        // ข้อที่มีข้อย่อย (ข้อ 3 แหล่งจ่ายไฟ MDB) — แต่ละข้อย่อยมีรูป/สถานะ/หมายเหตุของตัวเอง
        if (q.items) {
            const items = q.items;
            return (
                <SectionCard key={q.key} title={getQuestionLabel(q, lang)} tooltip={qTooltip}>
                    <div className="tw-divide-y tw-divide-gray-200">
                        {items.map((item, idx) => {
                            const photoKey = getSubPhotoKey(q.no, idx);
                            const idSuffix = idSuffixOfPhotoKey(photoKey);
                            const itemLabel = item.label[lang];
                            const photoInput = (
                                <PhotoMultiInput photos={photos[photoKey] || []} setPhotos={makePhotoSetter(photoKey)} max={10}
                                    draftKey={postKey} qNo={photoKey} lang={lang} id={`${ID_PREFIX}-photo-${idSuffix}`} />
                            );

                            return (
                                <div key={item.key} className="tw-py-4 first:tw-pt-2">
                                    <PassFailRow
                                        label={itemLabel}
                                        value={rows[item.key]?.pf ?? ""}
                                        lang={lang}
                                        onChange={v => setRows(prev => ({ ...prev, [item.key]: { ...prev[item.key], pf: v } }))}
                                        remark={rows[item.key]?.remark || ""}
                                        onRemarkChange={v => setRows(prev => ({ ...prev, [item.key]: { ...prev[item.key], remark: v } }))}
                                        id={`${ID_PREFIX}-pf-${idSuffix}`}
                                        remarkId={`${ID_PREFIX}-remark-${idSuffix}`}
                                        aboveRemark={<div className="tw-pb-4 tw-border-b tw-mb-4 tw-border-gray-100">{photoInput}</div>}
                                    />
                                </div>
                            );
                        })}
                    </div>
                </SectionCard>
            );
        }

        if (q.no === 1 || q.no === 2) {
            return (
                <SectionCard key={q.key} title={getQuestionLabel(q, lang)} tooltip={qTooltip}>
                    {q.hasPhoto && <div className="tw-mb-3"><PhotoMultiInput photos={photos[q.no] || []} setPhotos={makePhotoSetter(q.no)} max={10} draftKey={postKey} qNo={q.no} lang={lang} id={getPhotoIdFromKey(q.no)} /></div>}
                    {q.no === 1 && <div className="tw-mb-4"><Typography variant="small" className="tw-font-medium tw-text-gray-700 tw-mb-2">{t("powerSource", lang)}</Typography><select value={dropdownQ1} onChange={e => setDropdownQ1(e.target.value)} className="tw-w-full tw-max-w-sm tw-px-3 tw-py-2 tw-rounded-lg tw-border tw-border-gray-300 tw-bg-white tw-text-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-500/30"><option value="">{t("selectPowerSource", lang)}</option>{DROPDOWN_Q1_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt[lang]}</option>)}</select><div id={getRemarkIdFromKey(q.no)}><Textarea label={t("remark", lang)} value={rows[q.key]?.remark || ""} onChange={e => setRows(prev => ({ ...prev, [q.key]: { ...prev[q.key], remark: e.target.value } }))} rows={2} containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full tw-mt-3" /></div></div>}
                    {q.no === 2 && <div className="tw-mb-4"><Typography variant="small" className="tw-font-medium tw-text-gray-700 tw-mb-2">{t("circuitDevice", lang)}</Typography><select value={dropdownQ2} onChange={e => setDropdownQ2(e.target.value)} className="tw-w-full tw-max-w-sm tw-px-3 tw-py-2 tw-rounded-lg tw-border tw-border-gray-300 tw-bg-white tw-text-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-500/30"><option value="">{t("selectDevice", lang)}</option>{DROPDOWN_Q2_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt[lang]}</option>)}</select><div id={getRemarkIdFromKey(q.no)}><Textarea label={t("remark", lang)} value={rows[q.key]?.remark || ""} onChange={e => setRows(prev => ({ ...prev, [q.key]: { ...prev[q.key], remark: e.target.value } }))} rows={2} containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full tw-mt-3" /></div></div>}
                </SectionCard>
            );
        }

        return (
            <SectionCard key={q.key} title={getQuestionLabel(q, lang)} tooltip={qTooltip}>
                <PassFailRow
                    label={t("testResult", lang)}
                    showPfButtons={!q.key.startsWith("pre_")}
                    value={rows[q.key]?.pf ?? ""}
                    lang={lang}
                    onChange={v => setRows(prev => ({ ...prev, [q.key]: { ...prev[q.key], pf: v } }))}
                    remark={rows[q.key]?.remark || ""}
                    onRemarkChange={v => setRows(prev => ({ ...prev, [q.key]: { ...prev[q.key], remark: v } }))}
                    id={getPfIdFromKey(q.no)}
                    remarkId={getRemarkIdFromKey(q.no)}
                    aboveRemark={q.hasPhoto && <div className="tw-pb-4 tw-border-b tw-mb-4 tw-border-gray-100"><PhotoMultiInput photos={photos[q.no] || []} setPhotos={makePhotoSetter(q.no)} max={10} draftKey={postKey} qNo={q.no} lang={lang} id={getPhotoIdFromKey(q.no)} /></div>}
                    beforeRemark={hasMeasure && renderMeasureGrid(q.no)}
                />
            </SectionCard>
        );
    };

    // รับ PhotoItem แทน File[] เพื่อให้รู้ว่ารูปไหนอัปสำเร็จแล้ว — ตอนกดบันทึกซ้ำหลังอัปหลุด
    // จะได้ข้ามรูปเดิม ไม่อัปซ้ำจนรูปโผล่ซ้ำในรายงาน (และไม่ไปชนเพดาน 10 รูป/ข้อ)
    async function uploadGroupPhotos(reportId: string, stationId: string, group: string, items: PhotoItem[], stateKey: string, uploadedIds: Set<string>) {
        // uploadedIds จำเป็นเพราะ setPhotos() ยังไม่ flush เข้า photosRef ภายใน tick เดียวกัน
        // ถ้าไม่มี รอบอัปโหลดรอบสองจะส่งรูปเดิมซ้ำ
        const pending = (items || []).filter(p => !p.isNA && !p.uploaded && !uploadedIds.has(p.id) && (p.file || p.ref));
        if (pending.length === 0) return;
        const url = `${API_BASE}/cbboxpmreport/${reportId}/post/photos`;
        // ส่งทีละรูป (1 request/รูป) เพื่อไม่ให้ body รวมเกิน limit ของ nginx (กัน 413 เมื่อข้อหนึ่งมีหลายรูป)
        for (const p of pending) {
            const compressed = await compressImage(await resolveUploadFile(p));
            const form = new FormData();
            form.append("station_id", stationId);
            form.append("group", group);
            form.append("side", "post");
            form.append("files", compressed);
            const res = await fetch(url, { method: "POST", body: form, credentials: "include" });
            if (!res.ok) throw new Error(await res.text());
            uploadedIds.add(p.id);
            setPhotos(prev => ({ ...prev, [stateKey]: (prev[stateKey as any] || []).map(x => x.id === p.id ? { ...x, uploaded: true } : x) }));
        }
    }

    /** อัปโหลดหลายรอบ + ยืนยันจำนวนกับ server ก่อนให้ caller ไปลบรูปในเครื่อง
     *  คืน true = ปลอดภัยที่จะลบ, false = ยังไม่ครบ (แจ้ง user แล้ว) ห้ามลบ */
    async function syncPhotosAndVerify(reportId: string): Promise<boolean> {
        const sid = stationId;
        if (!sid) throw new Error(t("alertNoStation", lang));
        const uploadedIds = new Set<string>();
        for (let pass = 1; pass <= 3; pass++) {
            if (unrecoverablePhotos(photosRef.current as any, uploadedIds).length > 0) {
                throw new Error(unrecoverableMessage(lang));
            }
            if (collectPending(photosRef.current as any, uploadedIds).length === 0) break;
            // อัปไม่ผ่าน → throw ทะลุขึ้นไป catch ของ handler โดยยังไม่ได้ลบอะไร
            await Promise.all(
                Object.entries(photosRef.current).map(([no, list]) =>
                    uploadGroupPhotos(reportId, sid, photoGroupKey(no), list || [], no, uploadedIds))
            );
        }

        const stillPending = collectPending(photosRef.current as any, uploadedIds);
        if (stillPending.length > 0) {
            alert(pendingMessage(stillPending.length, lang));
            return false;
        }

        const expected = expectedCountByGroup(photosRef.current as any, k => photoGroupKey(k));
        if (Object.keys(expected).length === 0) return true;

        const res = await fetch(`${API_BASE}/cbboxpmreport/get?station_id=${encodeURIComponent(sid)}&report_id=${reportId}`,
            { credentials: "include" });
        if (!res.ok) throw new Error(await res.text());
        const doc = await res.json() as { photos?: Record<string, unknown[]> };
        const shortfall = findShortfall(expected, doc?.photos);
        if (shortfall.length > 0) {
            console.error(`[CB-BOX post verify] shortfall:`, shortfall);
            alert(shortfallMessage(shortfall, lang));
            return false;
        }
        return true;
    }

    const onFinalSave = async () => {
        if (!stationId) { alert(t("alertNoStation", lang)); return; }

        // Validation checks with scroll to error
        if (!allPhotosAttachedPost) { alert(t("alertFillPhoto", lang)); return; }
        if (!allPFAnsweredPost) { alert(lang === "th" ? "กรุณาเลือกระดับผลการตรวจหรือ N/A ทุกข้อ" : "Please select an inspection rating or N/A for all items"); return; }
        if (!allRequiredInputsFilled) { alert(t("alertInputNotComplete", lang)); return; }
        if (!isSummaryFilled || !isSummaryCheckFilled) { alert(t("alertCompleteAll", lang)); return; }

        if (submitting) return;
        setSubmitting(true);
        try {
            // ฟอร์มนี้เหลือแค่ Post-PM แล้ว (ไม่มีด่าน Pre ที่เคยสร้าง report_id ให้)
            // ใบใหม่ให้ backend สร้างรายงานตอนกดบันทึก — ถ้าเคยกดแล้วอัปรูปหลุด ใช้ id เดิมจาก draft กันได้รายงานซ้ำ
            let finalReportId: string = reportId || editId || loadDraftLocal<any>(postKey)?.pendingReportId || "";
            const payload = { station_id: stationId, ...(jobId ? { job_id: jobId } : {}), inspector, job: { station_name: job.station_name, date: job.date }, ...(job.date ? { pm_date: job.date } : {}), rows, measures: { m5: m5.state }, summary, dropdownQ1, dropdownQ2, ...(summaryCheck ? { summaryCheck } : {}), ...(jobId ? {} : { work_start: workStart, work_finish: workFinish, maximo_labor: maximoLabor, maximo_contractor: contractorPicked ? maximoContractor.trim() : "" }), wonum: searchParams.get("wonum") ?? "", side: "post", ...(finalReportId ? { report_id: finalReportId } : {}) };
            const res = await fetch(`${API_BASE}/cbboxpmreport/submit`, { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(payload) });
            if (!res.ok) throw new Error(await res.text());
            const { report_id } = await res.json() as { report_id: string };
            if (!finalReportId) {
                finalReportId = report_id;
                setReportId(report_id);
                saveDraftLocal(postKey, { ...loadDraftLocal<any>(postKey), pendingReportId: report_id });
            }
            // ต้องยืนยันรูปครบก่อน ถึงจะ finalize + ลบรูปในเครื่อง
            // แก้ส่วนที่ส่งแล้ว: รูปเดิมที่กดลบออก ลบออกจากเอกสารจริงก่อน แล้วค่อยอัปรูปใหม่
            if (jobId) {
                await deleteRemovedServerPhotos(apiFetch, {
                    jobId, stationId: stationId ?? "", section: "cbbox", reportId: finalReportId,
                    original: serverPhotosRef.current, current: photosRef.current as any,
                });
                serverPhotosRef.current = {};
            }
            if (!(await syncPhotosAndVerify(finalReportId))) return;
            if (!jobId && (!workStart || !workFinish)) { alert(t("alertWorkTime", lang)); setSubmitting(false); return; }
            if (!jobId && contractorMissing) { alert(t("contractorRequired", lang)); setSubmitting(false); return; }
            if (!jobId && workFinish < workStart) { alert(t("alertWorkTimeOrder", lang)); setSubmitting(false); return; }
            // Maximo ตีกลับ IN09 ด้วย BMXAA2641E ถ้าเวลาทำงานยังมาไม่ถึง
            // ปล่อยผ่านตรงนี้ = ปิดใบงานได้แต่ปิด WO ในระบบเขาไม่ได้ ต้องมาแก้ย้อนหลัง
            const nowLocal = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
                .toISOString().slice(0, 16);
            if (!jobId && (workStart > nowLocal || workFinish > nowLocal)) { alert(t("alertWorkTimeFuture", lang)); setSubmitting(false); return; }

            const finalizeRes = await fetch(`${API_BASE}/cbboxpmreport/${finalReportId}/finalize`, { method: "POST", credentials: "include", body: new URLSearchParams({ station_id: stationId }) });
            if (!finalizeRes.ok) throw new Error(await finalizeRes.text());
            const allPhotos = Object.values(photosRef.current).flat();
            await Promise.all(allPhotos.map(p => delPhoto(postKey, p.id)));
            draftClearedRef.current = true; // กัน autosave ที่ค้างอยู่เขียน draft กลับมาหลังล้าง
            await clearDraftLocal(postKey);
            // กลับหน้าที่เปิดเข้ามา (หน้ารวมของใบ PM สถานี / PM List) — ไม่มีก็ไปตารางใบ PM ของสถานี
            router.replace(pmFormReturnRoute(searchParams) ?? `/dashboard/pm-report?station_id=${encodeURIComponent(stationId)}&tab=cb-box`);
        } catch (err: any) { alert(`${t("alertSaveFailed", lang)} ${err?.message ?? err}`); } finally { setSubmitting(false); }
    };


    useEffect(() => { void prefetchLocation(); }, []);



    // กล่องหมายเหตุ + สรุปผลการตรวจสอบ — ประกาศครั้งเดียว วางได้สองที่
    // ตอนกรอกอยู่ในฟอร์มตามเดิม ตอนตรวจย้ายลงไปล่างสุดใต้ตารางผลการตรวจ
    const summaryBlock = (
                        <div id={`${ID_PREFIX}-summary-section`} className="tw-space-y-3 tw-mt-6">
                            <Typography variant="h6">{t("comment", lang)}</Typography>
                            <Textarea label={t("comment", lang)} value={summary} onChange={e => setSummary(e.target.value)} rows={4} required containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full" />
                            <div className="tw-pt-4 tw-border-t tw-border-gray-100"><PassFailRow label={t("summaryResult", lang)} value={summaryCheck} onChange={v => setSummaryCheck(v)} lang={lang} labels={{ PASS: t("summaryPassLabel", lang), FAIL: t("summaryFailLabel", lang), NA: t("summaryNALabel", lang) }} /></div>
                        </div>
    );

    return (
        <section className="tw-pb-24">
            <div className="tw-mx-auto tw-max-w-6xl tw-flex tw-items-center tw-justify-between tw-mb-4">
                <Button variant="outlined" size="sm" onClick={goBackToList} title={t("backToList", lang)}><ArrowLeftIcon className="tw-w-4 tw-h-4 tw-stroke-gray-900 tw-stroke-2" /></Button>
            </div>
            {/* โหมดตรวจ: ฟอร์มกรอกไม่ต้องโชว์ ดูจากตารางผลการตรวจก่อน/หลังด้านล่างแทน
                แต่ยังต้อง mount ไว้ ค่าที่คำนวณจากฟอร์ม (ความครบถ้วน, สรุป) ใช้ต่อข้างล่าง */}
            <form noValidate onSubmit={e => { e.preventDefault(); return false; }} onKeyDown={e => { if (e.key === "Enter") e.preventDefault(); }}>
                <div className="tw-mx-auto tw-max-w-6xl tw-bg-white tw-border tw-border-gray-200 tw-rounded-xl tw-shadow-sm tw-p-4 sm:tw-p-6 md:tw-p-8">
                {/* ดูอย่างเดียว: fieldset ปิดช่องกรอกทั้งหมด — แถวปุ่มบันทึก/แก้ไขอยู่นอก fieldset ปุ่มแก้ไขจะได้กดได้ */}
                <fieldset disabled={reviewMode} className="pm-readonly tw-m-0 tw-min-w-0 tw-border-0 tw-p-0">
                    <div className="tw-flex tw-flex-col tw-gap-4 md:tw-flex-row md:tw-items-start md:tw-justify-between md:tw-gap-6">
                        <div className="tw-flex tw-items-start tw-gap-3 md:tw-gap-4">
                            <div className="tw-relative tw-overflow-hidden tw-bg-white tw-rounded-md tw-shrink-0 tw-h-14 tw-w-[64px] sm:tw-h-16 sm:tw-w-[76px] md:tw-h-20 md:tw-w-[108px] lg:tw-h-24 lg:tw-w-[152px]"><Image src={LOGO_SRC} alt="Logo" fill priority className="tw-object-contain" sizes="152px" /></div>
                            <div className="tw-min-w-0"><div className="tw-font-semibold tw-text-gray-900 tw-text-sm sm:tw-text-base">{t("pageTitle", lang)}</div><div className="tw-text-xs sm:tw-text-sm tw-text-gray-600">{t("companyAddressShort", lang)}<br />{t("callCenter", lang)}</div></div>
                        </div>
                        <div className="tw-text-left md:tw-text-right tw-text-sm tw-text-gray-700 tw-border-t tw-border-gray-100 tw-pt-3 md:tw-border-t-0 md:tw-pt-0 md:tw-shrink-0"><div className="tw-font-semibold">{t("docName", lang)}</div><div className="tw-break-all">{jobDocIds?.doc_name || docName || "-"}</div></div>
                    </div>
                    <div className="tw-mt-8 tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-6 tw-gap-4">
                        <div className="lg:tw-col-span-1"><Input label={t("issueId", lang)} value={jobDocIds?.issue_id || job.issue_id || "-"} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full !tw-bg-gray-50" /></div>
                        <div className="sm:tw-col-span-2 lg:tw-col-span-2"><Input label={t("location", lang)} value={job.station_name} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-gray-50" /></div>
                        <div className="sm:tw-col-span-2 lg:tw-col-span-2"><Input label={t("inspector", lang)} value={inspector} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-gray-50" /></div>
                        <div className="lg:tw-col-span-1"><Input label={t("pmDate", lang)} type="text" value={job.date} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-gray-50" /></div>
                    </div>
                    <div className="tw-space-y-4 tw-mt-6">{/* หน้าดูใช้ฟอร์มเดียวกับตอนกรอก — fieldset ล็อกไม่ให้แก้ */}
                        <fieldset disabled={reviewMode} className="pm-readonly tw-m-0 tw-min-w-0 tw-border-0 tw-p-0 tw-space-y-4 sm:tw-space-y-6">{QUESTIONS.map((q) => renderQuestionBlock(q))}</fieldset></div>
                    {summaryBlock}
                    <div className="tw-flex tw-flex-col tw-gap-3 tw-mt-8">
                    {/* ใบที่เป็นส่วนหนึ่งของใบ PM สถานี: เวลาทำงาน/ช่างที่ลงเวลา Maximo กรอกครั้งเดียวตอนกด
                        "ปิดใบงาน" ที่หน้ารวมของใบ — ไม่ต้องกรอกซ้ำทุกส่วน (ใบเดี่ยวรุ่นเก่ายังกรอกที่นี่) */}
                    {!jobId && (<>
                    {/* เวลาทำงานจริงของช่าง — ต้องกรอกก่อนส่งปิดใบงาน (ส่งเข้า Maximo IN09) */}
                    {(
                        <div className="tw-mt-6 tw-pt-4 tw-border-t tw-border-gray-200">
                            <div className="tw-mb-2">
                                <Typography variant="h6" className="tw-text-sm sm:tw-text-base">
                                    {t("workTime", lang)} <span className="tw-text-red-500">*</span>
                                </Typography>
                                <Typography variant="small" className="tw-text-xs tw-font-normal tw-text-blue-gray-400">
                                    {t("workTimeHint", lang)}
                                </Typography>
                            </div>
                            <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-3">
                                <div>
                                    <label className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">{t("workStart", lang)}</label>
                                    <input type="datetime-local" value={workStart} disabled={reviewMode} onChange={(e) => setWorkStart(e.target.value)}
                                        className="tw-w-full tw-rounded-lg tw-border tw-border-blue-gray-200 tw-bg-white tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none focus:tw-border-blue-500" />
                                </div>
                                <div>
                                    <label className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">{t("workFinish", lang)}</label>
                                    {/* min กัน picker เลือกย้อนหลัง — ยังต้อง validate เพราะพิมพ์มือเลี่ยงได้ */}
                                    <input type="datetime-local" value={workFinish} disabled={reviewMode} min={workStart || undefined} onChange={(e) => setWorkFinish(e.target.value)}
                                        className={`tw-w-full tw-rounded-lg tw-border tw-bg-white tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none ${workStart && workFinish && workFinish < workStart ? "tw-border-red-400 focus:tw-border-red-500" : "tw-border-blue-gray-200 focus:tw-border-blue-500"}`} />
                                    {workStart && workFinish && workFinish < workStart && (
                                        <p className="tw-mt-1.5 tw-text-xs tw-text-red-600">{t("alertWorkTimeOrder", lang)}</p>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* ช่างที่จะลงเวลาเข้า Maximo — laborcode คนละชุดกับ username ใน iMPS
                        จึงต้องให้เลือกเอง ไม่งั้น IN09 จะ unmapped ทั้งใบ (อยู่ล่างสุดของฟอร์ม) */}
                    <div className="tw-mt-6 tw-pt-4 tw-border-t tw-border-gray-200">
                        <div className="tw-mb-2">
                            <Typography variant="h6" className="tw-text-sm sm:tw-text-base">{t("maximoLabor", lang)}</Typography>
                            <Typography variant="small" className="tw-text-xs tw-font-normal tw-text-blue-gray-400">
                                {t("maximoLaborHint", lang)}
                            </Typography>
                        </div>
                        {laborList.length === 0 ? (
                            <p className="tw-text-xs tw-text-orange-600">
                                            {reviewMode ? t("maximoLaborNone", lang) : t("maximoLaborEmpty", lang)}
                                        </p>
                        ) : (
                            <div className="tw-rounded-lg tw-border tw-border-blue-gray-200 tw-bg-white tw-divide-y tw-divide-blue-gray-50 tw-max-h-56 tw-overflow-y-auto">
                                {laborList.map((o) => (
                                    <label key={o.laborcode} className="tw-flex tw-items-center tw-gap-2.5 tw-px-3 tw-py-2.5 tw-cursor-pointer hover:tw-bg-blue-gray-50/60 tw-transition-colors">
                                        {!reviewMode && (<input type="checkbox" checked={maximoLabor.includes(o.laborcode)}
                                            onChange={() => toggleMaximoLabor(o.laborcode)}
                                            className="tw-h-4 tw-w-4 tw-shrink-0 tw-rounded tw-border-blue-gray-300 tw-text-blue-600 focus:tw-ring-blue-500 tw-cursor-pointer" />)}
                                        <span className="tw-min-w-0 tw-truncate tw-text-sm tw-text-blue-gray-800">{o.name}</span>
                                        <span className="tw-ml-auto tw-font-mono tw-text-xs tw-text-blue-gray-400">{o.laborcode}</span>
                                    </label>
                                ))}
                            </div>
                        )}
                        {(contractorPicked || (reviewMode && !!maximoContractor.trim())) && (
                            <div className="tw-mt-3 tw-space-y-1.5">
                                <label className="tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">
                                    {t("contractorName", lang)} <span className="tw-text-red-500">*</span>
                                </label>
                                <input type="text" value={maximoContractor} onChange={(e) => setMaximoContractor(e.target.value)}
                                    placeholder={t("contractorPlaceholder", lang)}
                                    className={`tw-w-full tw-rounded-lg tw-border tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none ${contractorMissing ? "tw-border-red-400 focus:tw-border-red-500" : "tw-border-blue-gray-200 focus:tw-border-blue-500"}`} />
                                {contractorMissing && <p className="tw-text-xs tw-text-red-600">{t("contractorRequired", lang)}</p>}
                            </div>
                        )}
                    </div>
                    </>)}

                        {/* โหมดตรวจไม่ต้องมี ฟอร์มฝั่งช่างดักความครบถ้วนไว้ตั้งแต่ตอนกรอกแล้ว */}
                        {!reviewMode && (
                            <PMValidationCard
                                lang={lang}
                                allPhotosAttached={allPhotosAttachedPost}
                                missingPhotoItems={missingPhotoItemsFormatted}
                                allRequiredInputsFilled={allRequiredInputsFilled}
                                missingInputsDetailed={missingInputsDetailed}
                                allPFAnsweredPost={allPFAnsweredPost}
                                missingPFItemsPost={missingPFItemsPost}
                                isSummaryFilled={isSummaryFilled}
                                isSummaryCheckFilled={isSummaryCheckFilled}
                            />
                        )}
                    </div>
                </fieldset>
                    {/* หน้าดูข้อมูล: ปุ่มแก้ไข (ถ้ามีสิทธิ์) อยู่ตำแหน่งเดียวกับปุ่มบันทึกของหน้ากรอก */}
                    {(!reviewMode || reviewAction) && (
                        <div className="tw-mt-3 tw-flex tw-flex-col sm:tw-flex-row tw-justify-end tw-gap-2 sm:tw-gap-3">
                            {!reviewMode && cancelEditAction}
                            {reviewMode ? reviewAction : (
                                <Button className="tw-text-sm tw-py-2.5 tw-bg-gray-800 hover:tw-bg-gray-900 tw-w-full sm:tw-w-auto" type="button" onClick={onFinalSave} disabled={!canFinalSave || submitting}>{submitting ? t("saving", lang) : t("save", lang)}</Button>
                            )}
                        </div>
                    )}
                </div>
            </form>
            {/* ตรวจเสร็จแล้วกดต่อได้เลย ไม่ต้องเลื่อนกลับขึ้นไปข้างบน */}
            {approveMode && editId && (
                <div id="pm-approve-bottom" className="tw-mx-auto tw-max-w-6xl tw-mt-6 tw-flex tw-items-center tw-justify-end tw-gap-2 tw-border-t tw-border-blue-gray-100 tw-pt-5">
                    <PmApprovalBar
                        prefix="cbboxpmreport" reportId={editId}
                        scope={{ station_id: stationId }}
                        apiBase={API_BASE}
                        onDone={(msg) => { alert(msg); goBackToList(); }}
                    />
                </div>
            )}
        </section>
    );
}
