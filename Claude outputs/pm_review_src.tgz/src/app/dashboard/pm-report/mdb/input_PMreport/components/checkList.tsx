"use client";

import React, { useMemo, useCallback, useRef, useState, useEffect } from "react";
import {
    Button,
    Input,
    Typography,
    Textarea,
    Tooltip,
} from "@material-tailwind/react";
import Image from "next/image";
import { draftKey, saveDraftLocal, loadDraftLocal, clearDraftLocal } from "../lib/draft";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import PmApprovalBar from "@/app/dashboard/pm-report/components/PmApprovalBar";
import PmResultTable from "@/app/dashboard/pm-report/components/PmResultTable";
import { ArrowLeftIcon } from "@heroicons/react/24/solid";
import { putPhoto, getPhotoByDbKey, delPhoto, type PhotoRef } from "../lib/draftPhotos";
import { isFileReadable, isImageDecodable, resolveUsableFile, reportMissingDraftPhoto, reportPhotoStorageFailure } from "@/utils/upload-safety";
import { ensureViewableImage } from "@/utils/heic";
import { collectPending, unrecoverablePhotos, expectedCountByGroup, findShortfall, shortfallMessage, pendingMessage, unrecoverableMessage } from "@/utils/pm-photo-sync";
import { useLanguage, type Lang } from "@/utils/useLanguage";
import { apiFetch } from "@/utils/api";
import LoadingOverlay from "@/app/dashboard/components/Loadingoverlay";
import { pmFormReturnRoute } from "@/app/dashboard/pm-report/lib/origin";
import { registerDraftDiscard } from "@/app/dashboard/pm-report/lib/discardDraft";
import { serverPhotosToForm, mergeDraftPhotos, deleteRemovedServerPhotos, isServerPhoto, type ViewPhoto } from "@/app/dashboard/pm-report/lib/reviewData";
import { useJobDocIds } from "@/app/dashboard/pm-report/lib/useJobDocIds";
import { useDebouncedEffect } from "@/app/dashboard/pm-report/lib/useDebouncedEffect";
import { usePmCancelEdit, usePmReviewAction } from "@/app/dashboard/pm-report/lib/reviewAction";

// ==================== GPS + ADDRESS CACHE ====================
let _cachedLocation: { text: string; timestamp: number } | null = null;
let _locationFetching = false;
const LOCATION_CACHE_MAX_AGE = 5 * 60 * 1000;

async function prefetchLocation(): Promise<void> {
    if (_locationFetching) return;
    _locationFetching = true;
    try {
        const gps = await getCurrentGPS();
        if (gps) {
            const text = await reverseGeocode(gps.lat, gps.lng);
            _cachedLocation = { text, timestamp: Date.now() };
        }
    } catch { /* silent */ }
    finally { _locationFetching = false; }
}

async function getCachedLocation(): Promise<string> {
    if (_cachedLocation && (Date.now() - _cachedLocation.timestamp) < LOCATION_CACHE_MAX_AGE) {
        void prefetchLocation();
        return _cachedLocation.text;
    }
    await Promise.race([
        prefetchLocation(),
        new Promise<void>(resolve => setTimeout(resolve, 2000))
    ]);
    return _cachedLocation?.text || "ไม่สามารถระบุตำแหน่งได้";
}

// ==================== BACKGROUND UPLOAD QUEUE ====================
type BgUploadTask = {
    reportId: string;
    stationId: string;
    group: string;
    file: File;
};
type BgUploadProgress = {
    total: number;
    completed: number;
    failed: number;
    inProgress: boolean;
    failures: { group: string; error: string }[];
};

let _bgQueue: BgUploadTask[] = [];
let _bgProgress: BgUploadProgress = { total: 0, completed: 0, failed: 0, inProgress: false, failures: [] };
let _bgListeners = new Set<(p: BgUploadProgress) => void>();
function _bgNotify() { _bgListeners.forEach(fn => fn({ ..._bgProgress, failures: [..._bgProgress.failures] })); }

function subscribeBgUpload(fn: (p: BgUploadProgress) => void) {
    _bgListeners.add(fn);
    fn({ ..._bgProgress, failures: [..._bgProgress.failures] });
    return () => { _bgListeners.delete(fn); };
}

function resetBgUpload() {
    _bgProgress = { total: 0, completed: 0, failed: 0, inProgress: false, failures: [] };
    _bgQueue = [];
    _bgNotify();
}

/** ไฟล์ใน state อาจใช้ไม่ได้แล้ว (iOS คืนหน่วยความจำ) → กู้จาก IndexedDB ที่เซฟไว้ตอนแนบ */
function resolveUploadFile(task: { file?: File; ref?: PhotoRef }): Promise<File> {
    const dbKey = task.ref?.dbKey;
    return resolveUsableFile(task.file, dbKey ? () => getPhotoByDbKey(dbKey) : undefined);
}

async function _bgCompressImage(file: File, maxWidth = 1600, quality = 0.8): Promise<File> {
    if (!file.type.startsWith("image/") || file.size < 500 * 1024) return file;
    return new Promise((resolve) => {
        const img = document.createElement("img");
        img.onload = () => {
            URL.revokeObjectURL(img.src);
            let { width, height } = img;
            if (width > maxWidth) { height = (height * maxWidth) / width; width = maxWidth; }
            const canvas = document.createElement("canvas");
            canvas.width = width; canvas.height = height;
            const ctx = canvas.getContext("2d")!;
            ctx.drawImage(img, 0, 0, width, height);
            canvas.toBlob((blob) => {
                if (blob && blob.size < file.size) resolve(new File([blob], ensureJpgFilename(file.name), { type: "image/jpeg" }));
                else resolve(file);
            }, "image/jpeg", quality);
        };
        img.onerror = () => { URL.revokeObjectURL(img.src); resolve(file); };
        img.src = URL.createObjectURL(file);
    });
}

async function _bgUploadSingle(reportId: string, stationId: string, group: string, file: File) {
    if (!reportId || reportId === "undefined" || reportId === "null") {
        throw new Error(`Invalid reportId: ${reportId}`);
    }

    // normalize group เหมือน foreground
    const normalizedGroup = (() => {
        const k = String(group);
        if (/^\d+$/.test(k)) return `g${k}`;
        if (/^r\d+_[a-z0-9]+(?:_[a-z0-9]+)*$/.test(k)) return k;
        if (k.startsWith("g")) return k;
        return `g${k}`;
    })();

    const form = new FormData();
    form.append("station_id", stationId);
    form.append("group", normalizedGroup); // ← normalize แล้ว
    form.append("side", "post");
    form.append("files", file, ensureJpgFilename(file.name));

    const url = `${API_BASE}/mdbpmreport/${reportId}/post/photos`;

    const res = await apiFetch(url, {
        method: "POST",
        body: form,
        credentials: "include"  // ← เพิ่ม
    });
    if (!res.ok) {
        const errText = await res.text().catch(() => "");
        throw new Error(`[${res.status}] ${normalizedGroup}: ${errText || res.statusText}`);
    }
}
async function _bgUploadWithRetry(reportId: string, stationId: string, group: string, file: File, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try { await _bgUploadSingle(reportId, stationId, group, file); return; }
        catch (err: any) {
            if (attempt === maxRetries) throw err;
            await new Promise(r => setTimeout(r, Math.min(1000 * 2 ** (attempt - 1), 8000)));
        }
    }
}

async function _bgProcessQueue() {
    if (_bgProgress.inProgress) return;
    _bgProgress.inProgress = true;
    _bgNotify();
    const CONCURRENCY = 3;
    while (_bgQueue.length > 0) {
        const batch = _bgQueue.splice(0, CONCURRENCY);
        const results = await Promise.allSettled(
            batch.map(async (task) => {
                const compressed = await _bgCompressImage(task.file);
                await _bgUploadWithRetry(task.reportId, task.stationId, task.group, compressed);
            })
        );
        results.forEach((r, idx) => {
            if (r.status === "fulfilled") _bgProgress.completed++;
            else { _bgProgress.failed++; _bgProgress.failures.push({ group: batch[idx].group, error: r.reason?.message || "unknown" }); }
        });
        _bgNotify();
    }
    _bgProgress.inProgress = false;
    _bgNotify();
}

function enqueueBgUploads(tasks: BgUploadTask[]) {
    if (tasks.length === 0) return;
    _bgProgress = { ..._bgProgress, total: _bgProgress.total + tasks.length };
    _bgQueue.push(...tasks);
    _bgNotify();
    void _bgProcessQueue();
}

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";
const LOGO_SRC = "/img/logo_egat.png";

// ==================== TRANSLATIONS ====================
const T = {
    pageTitle: { th: "Preventive Maintenance Checklist - Main Distribution Board (MDB)", en: "Preventive Maintenance Checklist - Main Distribution Board (MDB)" },
    companyName: { th: "Electricity Generating Authority of Thailand (EGAT)", en: "Electricity Generating Authority of Thailand (EGAT)" },
    companyAddress: { th: "53 Moo 2 Charansanitwong Road, Bang Kruai, Nonthaburi 11130, Thailand", en: "53 Moo 2 Charansanitwong Road, Bang Kruai, Nonthaburi 11130, Thailand" },
    callCenter: { th: "Call Center Tel. 02-114-3350", en: "Call Center Tel. 02-114-3350" },
    docName: { th: "Document Name.", en: "Document Name." },
    issueId: { th: "Issue id", en: "Issue ID" },
    location: { th: "Location / สถานที่", en: "Location" },
    inspector: { th: "Inspector / ผู้ตรวจสอบ", en: "Inspector" },
    pmDate: { th: "PM Date / วันที่ตรวจสอบ", en: "PM Date" },
    save: { th: "บันทึก", en: "Save" },
    saving: { th: "กำลังบันทึก...", en: "Saving..." },
    attachPhoto: { th: "แนบรูป / ถ่ายรูป", en: "Attach / Take Photo" },
    takePhoto: { th: "ถ่ายรูป", en: "Take Photo" },
    na: { th: "N/A", en: "N/A" },
    cancelNA: { th: "ยกเลิก N/A", en: "Cancel N/A" },
    pass: { th: "PASS", en: "PASS" },
    fail: { th: "FAIL", en: "FAIL" },
    remark: { th: "หมายเหตุ", en: "Remark" },
    testResult: { th: "ผลการทดสอบ", en: "Test Result" },
    comment: { th: "Comment", en: "Comment" },
    summaryResult: { th: "สรุปผลการตรวจสอบ", en: "Summary Result" },
    summaryPassLabel: { th: "Pass : ผ่าน", en: "Pass" },
    summaryFailLabel: { th: "Fail : ไม่ผ่าน", en: "Fail" },
    summaryNALabel: { th: "N/A : ไม่พบ", en: "N/A" },
    maxPhotos: { th: "สูงสุด", en: "Max" },
    photos: { th: "รูป", en: "photos" },
    noPhotos: { th: "ยังไม่มีรูปแนบ", en: "No photos attached" },
    breakerMainCount: { th: "จำนวน Breaker Main:", en: "Breaker Main count:" },
    unit: { th: "ตัว", en: "units" },
    addBreakerMain: { th: "เพิ่ม", en: "Add" },
    chargerCountLabel: { th: "จำนวนตู้ชาร์จใน Station นี้:", en: "Chargers in this station:" },
    chargerUnit: { th: "ตู้", en: "chargers" },
    breakerCCBCount: { th: "จำนวน Breaker CCB:", en: "Breaker CCB count:" },
    breakerCCBMax: { th: "ตัว (สูงสุด 4 ตัว)", en: "units (max 4)" },
    addBreakerCCB: { th: "เพิ่ม", en: "Add" },
    rcdCount: { th: "จำนวน RCD (ตามจำนวนตู้ชาร์จ):", en: "RCD count (per charger):" },
    breakerChargerCount: { th: "จำนวน Breaker Charger (ตามจำนวนตู้ชาร์จ):", en: "Breaker Charger (per charger):" },
    allComplete: { th: "ครบเรียบร้อย ✅", en: "Complete ✅" },
    alertNoStation: { th: "ยังไม่ทราบ station_id", en: "Station ID not found" },
    alertFillVoltage: { th: "กรุณากรอกค่าแรงดันไฟฟ้าให้ครบก่อนบันทึก", en: "Please fill all voltage values" },
    alertSaveFailed: { th: "บันทึกไม่สำเร็จ:", en: "Save failed:" },
    dustFilterChanged: { th: "เปลี่ยนแผ่นกรองระบายอากาศ", en: "Ventilation filter replaced" },
    photoNotComplete: { th: "กรุณาแนบรูปให้ครบก่อนบันทึก", en: "Please attach all photos" },
    inputNotComplete: { th: "กรุณากรอกค่าข้อ 4-8 ให้ครบก่อนบันทึก", en: "Please fill items 4-8" },
    allNotComplete: { th: "กรุณากรอกข้อมูล / แนบรูป และสรุปผลให้ครบก่อนบันทึก", en: "Please complete all data" },
    remarkLabel: { th: "หมายเหตุ", en: "Remark" },
    itemLabel: { th: "ข้อ", en: "Item" },
    formStatus: { th: "สถานะการกรอกข้อมูล", en: "Form Completion Status" },
    allCompleteReady: { th: "กรอกข้อมูลครบถ้วนแล้ว พร้อมบันทึก ✓", en: "All fields completed. Ready to save ✓" },
    remaining: { th: "ยังขาดอีก {n} รายการ", en: "{n} items remaining" },
    items: { th: "รายการ", en: "items" },
    missingPhoto: { th: "ยังไม่ได้แนบรูปข้อ:", en: "Missing photos:" },
    missingSummaryText: { th: "ยังไม่ได้กรอกข้อความสรุปผลการตรวจสอบ", en: "Summary text not filled" },
    missingSummaryStatus: { th: "ยังไม่ได้เลือกระดับสรุปผล / N/A", en: "Summary rating / N/A not selected" },
    backToList: { th: "กลับไปหน้า List", en: "Back to List" },
    loading: { th: "กำลังโหลดข้อมูล...", en: "Loading..." },
    logoAlt: { th: "โลโก้บริษัท", en: "Company logo" },
    photoPreviewAlt: { th: "ตัวอย่างรูป", en: "Photo preview" },
    uploadFailedItem: { th: "ข้อ", en: "Item" },
    workTime: { th: "เวลาทำงานจริง", en: "Actual work time" },
    workStart: { th: "เวลาเริ่มงาน", en: "Start time" },
    workFinish: { th: "เวลาเสร็จงาน", en: "Finish time" },
    workTimeHint: { th: "ใช้ส่งเวลาทำงานของช่างเข้า Maximo", en: "Sent to Maximo as actual labor time" },
    alertWorkTime: { th: "กรุณากรอกเวลาเริ่มงานและเวลาเสร็จงาน", en: "Please fill in the start and finish time" },
    alertWorkTimeOrder: { th: "เวลาเสร็จงานต้องไม่ก่อนเวลาเริ่มงาน", en: "Finish time must not be before the start time" },
    alertWorkTimeFuture: { th: "เวลาทำงานต้องไม่เป็นเวลาในอนาคต — Maximo ไม่รับเวลาที่ยังมาไม่ถึง", en: "Work time cannot be in the future — Maximo rejects labor times that have not happened yet" },
    maximoLabor: { th: "ช่างที่ลงเวลากับ Maximo", en: "Technicians for Maximo time log" },
    maximoLaborHint: {
        th: "เลือกคนที่จะลงเวลาทำงานเข้า Maximo (IN09) — ไม่เลือกจะใช้ช่างที่ผู้วางแผนมอบหมายแทน",
        en: "Who gets an actual-labor record in Maximo (IN09) — leave empty to fall back to the assigned technicians",
    },
    maximoLaborEmpty: { th: "ยังไม่มีรหัสช่างจาก Maximo", en: "No Maximo labor codes available" },
    maximoLaborNone: { th: "ช่างไม่ได้เลือกใครไว้", en: "No technician selected" },
    contractorName: { th: "ชื่อผู้รับเหมา", en: "Contractor name" },
    contractorPlaceholder: { th: "ระบุชื่อผู้รับเหมาที่มาทำงานจริง", en: "Name of the contractor who did the work" },
    contractorRequired: { th: "เลือกผู้รับเหมาแล้วต้องระบุชื่อด้วย", en: "Enter the contractor name" },
    legacyFormTitle: { th: "ใบงานฟอร์มรุ่นเก่า — เปิดดูได้อย่างเดียว", en: "Older form version — view only" },
    legacyFormHint: {
        th: "ใบนี้บันทึกไว้ก่อนฟอร์มจะเพิ่มข้อ 1-2 (ก่อนบำรุงรักษา) เลขข้อจึงคนละชุดกับฟอร์มปัจจุบัน แก้ไขต่อในฟอร์มใหม่ไม่ได้ ดูรายละเอียดจากตารางด้านล่างหรือออก PDF ได้ตามปกติ",
        en: "This report was saved before items 1-2 (before maintenance) were added, so its item numbering differs from the current form. It cannot be edited here — read it from the table below or open the PDF.",
    },
};

const t = (key: keyof typeof T, lang: Lang): string => T[key][lang];

const ID_PREFIX = "mdb-pm";
const getPhotoIdFromKey = (key: string | number): string => { if (typeof key === "number") return `${ID_PREFIX}-photo-${key}`; const m = String(key).match(/^r(\d+)(?:_(\d+))?$/); return m ? (m[2] ? `${ID_PREFIX}-photo-${m[1]}-${m[2]}` : `${ID_PREFIX}-photo-${m[1]}`) : `${ID_PREFIX}-photo-${key}`; };
const getRemarkIdFromKey = (key: string | number): string => { if (typeof key === "number") return `${ID_PREFIX}-remark-${key}`; const m = String(key).match(/^r(\d+)(?:_(\d+))?$/); return m ? (m[2] ? `${ID_PREFIX}-remark-${m[1]}-${m[2]}` : `${ID_PREFIX}-remark-${m[1]}`) : `${ID_PREFIX}-remark-${key}`; };
const getInputIdFromKey = (key: string | number): string => { if (typeof key === "number") return `${ID_PREFIX}-input-${key}`; const m = String(key).match(/^r(\d+)(?:_(\d+))?$/); return m ? (m[2] ? `${ID_PREFIX}-input-${m[1]}-${m[2]}` : `${ID_PREFIX}-input-${m[1]}`) : `${ID_PREFIX}-input-${key}`; };
const getPfIdFromKey = (key: string | number): string => { if (typeof key === "number") return `${ID_PREFIX}-pf-${key}`; const m = String(key).match(/^r(\d+)(?:_(\d+))?$/); return m ? (m[2] ? `${ID_PREFIX}-pf-${m[1]}-${m[2]}` : `${ID_PREFIX}-pf-${m[1]}`) : `${ID_PREFIX}-pf-${key}`; };

// Questions
// เลขข้อ = คีย์ที่เก็บลง DB (rows.r{n} / photos.g{n}) — ห้ามสลับลำดับโดยไม่ขึ้น
// form_version ใหม่ ไม่งั้นใบเก่าจะถูกอ่านผิดหัวข้อ ดู FORM_VERSION ด้านล่าง
const QUESTIONS_DATA = [
    { no: 1, key: "r1", label: { th: "1) ตรวจสอบสภาพทั่วไป (ก่อนบำรุงรักษา)", en: "1) General condition (before maintenance)" }, kind: "simple", hasPhoto: true, tooltip: { th: "บันทึกสภาพตู้ MDB โดยรวมก่อนลงมือ — ถ่ายรูปสภาพก่อนบำรุงรักษาไว้เป็นหลักฐาน", en: "Record the overall MDB condition before starting work" } },
    { no: 2, key: "r2", label: { th: "2) อุปกรณ์ชำรุดเสียหาย (ก่อนบำรุงรักษา)", en: "2) Damaged equipment (before maintenance)" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจและบันทึกอุปกรณ์ที่ชำรุดเสียหายที่พบก่อนเริ่มบำรุงรักษา", en: "Record any damaged equipment found before maintenance" } },
    { no: 103, key: "r3_power_source", label: { th: "3) ตรวจสอบสภาพแหล่งจ่ายไฟ MDB", en: "3) Inspect MDB power supply condition" }, kind: "power_source", hasPhoto: true, items: [
        { key: "r3_power_main_cb", label: { th: "3.1) Main CB", en: "3.1) Main CB" } },
        { key: "r3_power_cb", label: { th: "3.2) CB", en: "3.2) CB" } },
        { key: "r3_power_meter", label: { th: "3.3) Power Meter (Voltage)", en: "3.3) Power Meter (Voltage)" } },
        { key: "r3_power_transformer", label: { th: "3.4) Transformer", en: "3.4) Transformer" } },
    ], tooltip: { th: "ตรวจสอบสภาพอุปกรณ์แหล่งจ่ายไฟของตู้ MDB", en: "Inspect the MDB power supply equipment" } },
    { no: 3, key: "r3", label: { th: "4) ตรวจสอบสภาพทั่วไป", en: "4) General condition inspection" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบโครงสร้างตู้ ระบบล็อกและบานพับรวมถึงป้ายชื่อวงจร (Labeling)", en: "Check cabinet structure, lock system, hinges and circuit labeling" } },
    { no: 4, key: "r4", label: { th: "5) ตรวจสอบดักซีล, ซิลิโคนกันซึม", en: "5) Check sealant and silicone" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบสภาพดักซีลที่ปิดหรืออุดตามรอยต่อและช่องทางเข้าสาย", en: "Check sealant condition at joints and cable entry points" } },
    { no: 5, key: "r5", label: { th: "6) ตรวจสอบ Power Meter", en: "6) Check Power Meter" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบการแสดงของจอ Power Meter และความถูกต้องของค่าพารามิเตอร์ไฟฟ้า (V, A, Hz, PF)", en: "Check Power Meter display and parameters (V, A, Hz, PF)" } },
    { no: 6, key: "r6", label: { th: "7) ตรวจสอบแรงดันไฟฟ้า Breaker Main", en: "7) Check Breaker Main voltage" }, kind: "dynamic_measure", hasPhoto: true, tooltip: { th: "วัดค่าแรงดันไฟฟ้าด้านเข้าของ Breaker Main", en: "Measure input voltage of Breaker Main" } },
    { no: 7, key: "r7", label: { th: "8) ตรวจสอบแรงดันไฟฟ้า Breaker Charger", en: "8) Check Breaker Charger voltage" }, kind: "charger_measure", hasPhoto: true, tooltip: { th: "วัดค่าแรงดันไฟฟ้าด้านเข้าของ Breaker Charger", en: "Measure input voltage of Breaker Charger" } },
    { no: 8, key: "r8", label: { th: "9) ตรวจสอบแรงดันไฟฟ้า Breaker CCB", en: "9) Check Breaker CCB voltage" }, kind: "ccb_measure", hasPhoto: true, tooltip: { th: "วัดค่าแรงดันไฟฟ้าด้านเข้าของ Breaker CCB", en: "Measure input voltage of Breaker CCB" } },
    { no: 9, key: "r9", label: { th: "10) ตรวจสอบแรงดันไฟฟ้า RCD", en: "10) Check RCD voltage" }, kind: "rcd_measure", hasPhoto: true, tooltip: { th: "วัดค่าแรงดันไฟฟ้าด้าน Load ของอุปกรณ์ป้องกันไฟรั่ว (RCD)", en: "Measure load side voltage of RCD" } },
    { no: 10, key: "r10", label: { th: "11) ทดสอบปุ่ม Trip Test RCD", en: "11) Test RCD Trip button" }, kind: "trip_rcd", hasPhoto: true, tooltip: { th: "กดปุ่ม Test เพื่อทดสอบกลไกการตัดกระแสไฟรั่วของ RCD", en: "Press Test button to test RCD trip mechanism" } },
    { no: 11, key: "r11", label: { th: "12) ทดสอบปุ่ม Trip Test Breaker CCB", en: "12) Test Breaker CCB Trip button" }, kind: "trip_ccb", hasPhoto: true, tooltip: { th: "กดปุ่ม Test เพื่อทดสอบกลไกการตัดวงจรของ Breaker CCB", en: "Press Test button to test Breaker CCB trip mechanism" } },
    { no: 12, key: "r12", label: { th: "13) ทดสอบปุ่ม Trip Test Breaker Charger", en: "13) Test Breaker Charger Trip button" }, kind: "trip_charger", hasPhoto: true, tooltip: { th: "กดปุ่ม Test เพื่อทดสอบกลไกการตัดวงจรของ Breaker Charger", en: "Press Test button to test Breaker Charger Trip mechanism" } },
    { no: 13, key: "r13", label: { th: "14) ทดสอบปุ่ม Trip Test Breaker Main", en: "14) Test Breaker Main Trip button" }, kind: "trip_main", hasPhoto: true, tooltip: { th: "กดปุ่ม Test เพื่อทดสอบกลไกการตัดวงจรของ Breaker Main", en: "Press Test button to test Breaker Main Trip mechanism" } },
    { no: 14, key: "r14", label: { th: "15) ตรวจสอบจุดต่อทางไฟฟ้า", en: "15) Check electrical connections" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบการขันแน่นของน็อตบริเวณจุดต่อสายและตรวจเช็ครอยไหม้ด้วยกล้องถ่ายภาพความร้อน", en: "Check bolt tightness at connection points and inspect for burn marks using thermal camera" } },
    { no: 15, key: "r15", label: { th: "16) ทำความสะอาดตู้ MDB", en: "16) Clean MDB cabinet" }, kind: "simple", hasPhoto: true, tooltip: { th: "ทำความสะอาดโดยการขจัดฝุ่นและสิ่งสกปรกภายในตู้ด้วยเครื่องดูดฝุ่นหรือเป่าลมแห้ง", en: "Clean by removing dust inside cabinet with vacuum or dry air" } },
] as const;

// ใบที่บันทึกด้วยฟอร์มชุดนี้ถูกสตัมป์ form_version ไว้ ใบที่ไม่มี (หรือ < 2)
// คือฟอร์มรุ่นเก่าที่ยังไม่มี 2 ข้อแรก — คีย์ r1..r13 ของใบพวกนั้นคนละหัวข้อกัน
const FORM_VERSION = 2;

// หัวข้อของฟอร์มรุ่นก่อน — ใช้แปลคีย์ของใบเก่าตอนเปิดดูเท่านั้น
const LEGACY_ROW_LABELS: Record<string, { th: string; en: string }> = {
    r1: { th: "1) ตรวจสอบสภาพทั่วไป", en: "1) General condition inspection" },
    r2: { th: "2) ตรวจสอบดักซีล, ซิลิโคนกันซึม", en: "2) Check sealant and silicone" },
    r3: { th: "3) ตรวจสอบ Power Meter", en: "3) Check Power Meter" },
    r4: { th: "4) ตรวจสอบแรงดันไฟฟ้า Breaker Main", en: "4) Check Breaker Main voltage" },
    r5: { th: "5) ตรวจสอบแรงดันไฟฟ้า Breaker Charger", en: "5) Check Breaker Charger voltage" },
    r6: { th: "6) ตรวจสอบแรงดันไฟฟ้า Breaker CCB", en: "6) Check Breaker CCB voltage" },
    r7: { th: "7) ตรวจสอบแรงดันไฟฟ้า RCD", en: "7) Check RCD voltage" },
    r8: { th: "8) ทดสอบปุ่ม Trip Test RCD", en: "8) Test RCD Trip button" },
    r9: { th: "9) ทดสอบปุ่ม Trip Test Breaker CCB", en: "9) Test Breaker CCB Trip button" },
    r10: { th: "10) ทดสอบปุ่ม Trip Test Breaker Charger", en: "10) Test Breaker Charger Trip button" },
    r11: { th: "11) ทดสอบปุ่ม Trip Test Breaker Main", en: "11) Test Breaker Main Trip button" },
    r12: { th: "12) ตรวจสอบจุดต่อทางไฟฟ้า", en: "12) Check electrical connections" },
    r13: { th: "13) ทำความสะอาดตู้ MDB", en: "13) Clean MDB cabinet" },
};

const getDynamicLabel = {
    breakerMain: (idx: number, lang: Lang) => lang === "th" ? `6.${idx}) Breaker Main ตัวที่ ${idx}` : `6.${idx}) Breaker Main #${idx}`,
    breakerCharger: (idx: number, lang: Lang) => lang === "th" ? `7.${idx}) Breaker Charger ตัวที่ ${idx}` : `7.${idx}) Breaker Charger #${idx}`,
    breakerCCB: (idx: number, lang: Lang) => lang === "th" ? `8.${idx}) Breaker CCB ตัวที่ ${idx}` : `8.${idx}) Breaker CCB #${idx}`,
    rcd: (idx: number, lang: Lang) => lang === "th" ? `9.${idx}) RCD ตัวที่ ${idx}` : `9.${idx}) RCD #${idx}`,
    tripRCD: (idx: number, lang: Lang) => lang === "th" ? `10.${idx}) Trip Test RCD ตัวที่ ${idx}` : `10.${idx}) Trip Test RCD #${idx}`,
    tripCCB: (idx: number, lang: Lang) => lang === "th" ? `11.${idx}) Trip Test Breaker CCB ตัวที่ ${idx}` : `11.${idx}) Trip Test Breaker CCB #${idx}`,
    tripCharger: (idx: number, lang: Lang) => lang === "th" ? `12.${idx}) Trip Test Breaker Charger ตัวที่ ${idx}` : `12.${idx}) Trip Test Breaker Charger #${idx}`,
    tripMain: (idx: number, lang: Lang) => lang === "th" ? `13.${idx}) Trip Test Breaker Main ตัวที่ ${idx}` : `13.${idx}) Trip Test Breaker Main #${idx}`,
};

type StationPublic = { station_id: string; station_name: string; status?: boolean; };
type Me = { id: string; username: string; email: string; role: string; company: string; tel: string; };

async function getStationInfoPublic(stationId: string): Promise<StationPublic> {
    const url = `${API_BASE}/station/info/public?station_id=${encodeURIComponent(stationId)}`;
    const res = await fetch(url, { cache: "no-store", credentials: "include" });
    if (res.status === 404) throw new Error("Station not found");
    if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
    const json = await res.json();
    return json.station ?? json;
}

async function getChargerCountByStation(stationId: string): Promise<number> {
    try {
        const url = `${API_BASE}/chargers/${encodeURIComponent(stationId)}`;
        const res = await apiFetch(url, { cache: "no-store", credentials: "include" });
        if (!res.ok) return 1;
        const json = await res.json();
        return Array.isArray(json.chargers) ? json.chargers.length || 1 : 1;
    } catch { return 1; }
}

const UNITS = { voltage: ["V"] as const };
type UnitVoltage = (typeof UNITS.voltage)[number];

type PhotoItem = {
    id: string; file?: File; preview?: string; remark?: string;
    uploading?: boolean; uploaded?: boolean; error?: string; ref?: PhotoRef; isNA?: boolean;
    createdAt?: string; location?: string;
};

type Question = {
    no: number; key: string;
    label: { th: string; en: string };
    kind: string; hasPhoto?: boolean;
    tooltip?: { th: string; en: string };
    items?: { key: string; label: { th: string; en: string } }[];
};

const VOLTAGE_FIELDS = ["L1-N", "L2-N", "L3-N", "L1-G", "L2-G", "L3-G", "L1-L2", "L2-L3", "L3-L1", "N-G"] as const;
const VOLTAGE_FIELDS_CCB = ["L1-N", "L1-G", "N-G"] as const;
const LABELS: Record<string, string> = { "L1-L2": "L1-L2", "L2-L3": "L2-L3", "L3-L1": "L3-L1", "L1-N": "L1-N", "L2-N": "L2-N", "L3-N": "L3-N", "L1-G": "L1-G", "L2-G": "L2-G", "L3-G": "L3-G", "N-G": "N-G" };
const QUESTIONS = QUESTIONS_DATA as unknown as Question[];

type MeasureRow<U extends string> = { value: string; unit: U };
type MeasureState<U extends string> = Record<string, MeasureRow<U>>;
type Rating = "VERY_GOOD" | "GOOD" | "FAIR" | "UNUSABLE";
type PF = Rating | "PASS" | "FAIL" | "NA" | "";

function initMeasureState<U extends string>(keys: readonly string[], defaultUnit: U): MeasureState<U> {
    return keys.reduce((acc, k) => { acc[k] = { value: "", unit: defaultUnit }; return acc; }, {} as MeasureState<U>);
}

function useMeasure<U extends string>(keys: readonly string[], defaultUnit: U) {
    const [state, setState] = useState<MeasureState<U>>(() => initMeasureState(keys, defaultUnit));
    const patch = (key: string, p: Partial<MeasureRow<U>>) => setState(prev => ({ ...prev, [key]: { ...prev[key], ...p } }));
    const syncUnits = (u: U) => setState(prev => { const n = { ...prev }; keys.forEach(k => (n[k] = { ...prev[k], unit: u })); return n; });
    return { state, setState, patch, syncUnits };
}


/** เวลาปัจจุบันในรูปแบบที่ input[type=datetime-local] รับ — เวลาเครื่อง ไม่ใช่ UTC */
function nowLocalDatetime(): string {
    return new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
        .toISOString().slice(0, 16);
}

// ==================== GPS ====================
async function getCurrentGPS(): Promise<{ lat: number; lng: number } | null> {
    if (!navigator.geolocation) return null;
    if (window.isSecureContext === false) return null;
    const fast = await new Promise<{ lat: number; lng: number } | null>((resolve) => {
        const timer = setTimeout(() => resolve(null), 2000);
        navigator.geolocation.getCurrentPosition(
            (pos) => { clearTimeout(timer); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
            () => { clearTimeout(timer); resolve(null); },
            { enableHighAccuracy: false, timeout: 1500, maximumAge: 300000 }
        );
    });
    if (fast) return fast;
    return new Promise((resolve) => {
        const timer = setTimeout(() => resolve(null), 8000);
        navigator.geolocation.getCurrentPosition(
            (pos) => { clearTimeout(timer); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
            () => { clearTimeout(timer); resolve(null); },
            { enableHighAccuracy: true, timeout: 7000, maximumAge: 30000 }
        );
    });
}

const GOOGLE_MAPS_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY ?? "";

async function reverseGeocodeGoogle(lat: number, lng: number): Promise<string | null> {
    if (!GOOGLE_MAPS_KEY) return null;
    try {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 5000);
        const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&language=th&result_type=street_address|route|premise&key=${GOOGLE_MAPS_KEY}`;
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(tid);
        if (!res.ok) return null;
        const data = await res.json();
        if (data.status !== "OK" || !data.results?.length) return null;
        const best = data.results[0];
        const c = best.address_components || [];
        const get = (type: string) => c.find((x: any) => x.types?.includes(type))?.long_name || "";
        const parts: string[] = [];
        const premise = get("premise"); if (premise) parts.push(premise);
        const hn = get("street_number"), road = get("route");
        if (hn && road) parts.push(`${hn} ${road}`); else if (road) parts.push(road);
        const sub2 = get("sublocality_level_2"); if (sub2 && !parts.some(p => p.includes(sub2))) parts.push(sub2);
        const sub1 = get("sublocality_level_1"); if (sub1 && !parts.some(p => p.includes(sub1))) parts.push(sub1);
        const dist = get("locality") || get("administrative_area_level_2"); if (dist && !parts.some(p => p.includes(dist))) parts.push(dist);
        const prov = get("administrative_area_level_1"); if (prov && !parts.some(p => p.includes(prov))) parts.push(prov);
        if (parts.length > 0) { let r = parts.join(" "); return r.length > 80 ? r.substring(0, 77) + "..." : r; }
        if (best.formatted_address) { const a = best.formatted_address.replace(/\s*\d{5}\s*/, " ").replace(/ประเทศไทย/g, "").trim(); return a.length > 80 ? a.substring(0, 77) + "..." : a; }
        return null;
    } catch { return null; }
}

async function reverseGeocodeNominatim(lat: number, lng: number): Promise<string> {
    try {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 5000);
        const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=th&zoom=21&addressdetails=1`;
        const res = await fetch(url, { headers: { "User-Agent": "PM-Checklist-App/1.0" }, signal: controller.signal });
        clearTimeout(tid);
        if (!res.ok) return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
        const data = await res.json();
        const addr = data.address || {};
        const poi = addr.amenity || addr.building || addr.shop || addr.tourism || "";
        let roadPart = "";
        const hn = addr.house_number || "", road = addr.road || addr.pedestrian || "";
        if (hn && road) roadPart = `${hn} ${road}`; else if (road) roadPart = road;
        const village = addr.village || addr.neighbourhood || addr.residential || "";
        const subdistrict = addr.subdistrict || addr.suburb || "";
        const district = addr.district || addr.city_district || "";
        const province = addr.province || addr.state || addr.city || "";
        const rawParts = [poi, roadPart, village, subdistrict, district, province].filter(Boolean);
        const parts: string[] = [];
        for (const p of rawParts) { if (!parts.some(e => e.includes(p) || p.includes(e))) parts.push(p); }
        if (parts.length > 0) { let r = parts.slice(0, 4).join(" "); return r.length > 70 ? r.substring(0, 67) + "..." : r; }
        if (data.display_name) { const s = data.display_name.split(",").slice(0, 4).join(",").trim(); return s.length > 70 ? s.substring(0, 67) + "..." : s; }
        return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
    } catch { return `${lat.toFixed(6)}, ${lng.toFixed(6)}`; }
}

async function reverseGeocode(lat: number, lng: number): Promise<string> {
    const google = await reverseGeocodeGoogle(lat, lng);
    if (google) return google;
    return reverseGeocodeNominatim(lat, lng);
}

// ==================== IMAGE UTILS ====================
// ⚡ FIX 422: ชื่อไฟล์จากกล้อง/แกลเลอรีบางเครื่องมี " หรือ newline ปนมา ทำให้ header
// Content-Disposition ของ multipart เพี้ยน → server parse body ไม่ออก ตอบ 422 โดยที่
// station_id/group/files หายพร้อมกันทั้งหมด จึงเหลือไว้เฉพาะอักขระที่ปลอดภัยเสมอ
function ensureJpgFilename(name: string): string {
    const base = (name || "").replace(/\.[^.]*$/, "");
    const safe = base.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._-]+/, "").slice(0, 80);
    return safe ? `${safe}.jpg` : `image_${Date.now()}.jpg`;
}

async function addTimestampToImage(file: File, locationText: string): Promise<File> {
    return new Promise((resolve) => {
        const img = document.createElement("img");
        img.onload = () => {
            try {
                URL.revokeObjectURL(img.src);
                const canvas = document.createElement("canvas");
                canvas.width = img.width; canvas.height = img.height;
                const ctx = canvas.getContext("2d");
                if (!ctx) { resolve(file); return; }
                ctx.drawImage(img, 0, 0);
                const now = new Date();
                const timestamp = now.toLocaleString("th-TH", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
                const fontSize = Math.max(14, Math.floor(img.width * 0.022));
                const padding = Math.floor(fontSize * 0.5);
                const lineHeight = fontSize * 1.3;
                ctx.font = `bold ${fontSize}px Arial, sans-serif`;
                const tsWidth = ctx.measureText(timestamp).width;
                const locDisplay = `📍 ${locationText}`;
                const locWidth = ctx.measureText(locDisplay).width;
                const totalHeight = lineHeight * 2;
                const boxWidth = Math.max(Math.floor(img.width * 0.6), Math.max(tsWidth, locWidth) + padding * 2);
                const bgX = 10, bgY = Math.max(0, img.height - totalHeight - padding * 2 - 10);
                ctx.fillStyle = "rgba(0,0,0,0.65)";
                ctx.fillRect(bgX, bgY, boxWidth, totalHeight + padding * 2);
                ctx.fillStyle = "#FFFFFF"; ctx.textBaseline = "top";
                ctx.fillText(timestamp, bgX + padding, bgY + padding);
                let locText = locDisplay;
                while (ctx.measureText(locText).width > boxWidth - padding * 2 && locText.length > 10) locText = locText.slice(0, -4) + "...";
                ctx.fillText(locText, bgX + padding, bgY + padding + lineHeight);
                canvas.toBlob((blob) => {
                    if (blob) resolve(new File([blob], ensureJpgFilename(file.name), { type: "image/jpeg" }));
                    else resolve(file);
                }, "image/jpeg", 0.9);
            } catch { resolve(file); }
        };
        img.onerror = () => { URL.revokeObjectURL(img.src); resolve(file); };
        img.src = URL.createObjectURL(file);
    });
}

function getImageDimensions(file: File): Promise<{ width: number; height: number }> {
    return new Promise((resolve, reject) => {
        const img = new window.Image();
        img.onload = () => { resolve({ width: img.naturalWidth, height: img.naturalHeight }); URL.revokeObjectURL(img.src); };
        img.onerror = () => { reject(new Error("Cannot read image")); URL.revokeObjectURL(img.src); };
        img.src = URL.createObjectURL(file);
    });
}

function isMobileDevice(): boolean {
    if (typeof navigator === "undefined") return false;
    return /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
        || ("ontouchstart" in window && navigator.maxTouchPoints > 0);
}

// ==================== UI COMPONENTS ====================
function PassFailRow({ label, value, onChange, remark, onRemarkChange, labels, aboveRemark, beforeRemark, belowRemark, inlineLeft, showPfButtons = true, lang, remarkId, pfButtonsId }: {
    label: string; value: PF; onChange: (v: Rating | "NA") => void;
    remark?: string; onRemarkChange?: (v: string) => void;
    labels?: Partial<Record<Exclude<PF, "">, React.ReactNode>>;
    aboveRemark?: React.ReactNode; beforeRemark?: React.ReactNode; belowRemark?: React.ReactNode; inlineLeft?: React.ReactNode; showPfButtons?: boolean;
    lang: Lang; remarkId?: string; pfButtonsId?: string;
}) {
    const text = {
        VERY_GOOD: labels?.VERY_GOOD ?? (lang === "th" ? "ดีมาก" : "Excellent"),
        GOOD: labels?.GOOD ?? (lang === "th" ? "ดี" : "Good"),
        FAIR: labels?.FAIR ?? (lang === "th" ? "พอใช้" : "Fair"),
        UNUSABLE: labels?.UNUSABLE ?? (lang === "th" ? "ใช้งานไม่ได้" : "Unusable"),
        NA: labels?.NA ?? t("na", lang),
    };
    const buttonGroup = (
        <div id={pfButtonsId} className="tw-flex tw-flex-wrap tw-gap-2 tw-ml-auto tw-transition-all tw-duration-300">
            <Button size="sm" color="green" variant={value === "VERY_GOOD" || value === "PASS" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("VERY_GOOD")}>{text.VERY_GOOD}</Button>
            <Button size="sm" color="light-green" variant={value === "GOOD" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("GOOD")}>{text.GOOD}</Button>
            <Button size="sm" color="amber" variant={value === "FAIR" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("FAIR")}>{text.FAIR}</Button>
            <Button size="sm" color="red" variant={value === "UNUSABLE" || value === "FAIL" ? "filled" : "outlined"} className="sm:tw-min-w-[112px]" onClick={() => onChange("UNUSABLE")}>{text.UNUSABLE}</Button>
            <Button size="sm" color="blue-gray" variant={value === "NA" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("NA")}>{text.NA}</Button>
        </div>
    );
    const buttonsRow = (<div className="tw-flex tw-items-center tw-gap-3 tw-w-full">{inlineLeft && <div className="tw-flex tw-items-center tw-gap-2">{inlineLeft}</div>}{buttonGroup}</div>);
    return (
        <div className="tw-space-y-3 tw-py-3">
            <Typography className="tw-font-medium">{label}</Typography>
            {onRemarkChange ? (
                <div className="tw-w-full tw-min-w-0 tw-space-y-2">
                    {aboveRemark}{showPfButtons && buttonsRow}{beforeRemark}
                    <div id={remarkId} className="tw-transition-all tw-duration-300">
                        <Textarea label={t("remark", lang)} value={remark || ""} onChange={(e) => onRemarkChange(e.target.value)} containerProps={{ className: "!tw-w-full !tw-min-w-0" }} className="!tw-w-full" />
                    </div>
                    {belowRemark}
                </div>
            ) : (
                showPfButtons && <div className="tw-flex tw-flex-col sm:tw-flex-row tw-gap-2 sm:tw-items-center sm:tw-justify-between">{buttonsRow}</div>
            )}
        </div>
    );
}

function SectionCard({ title, subtitle, children, tooltip, id }: { title?: string; subtitle?: string; children: React.ReactNode; tooltip?: string; id?: string; }) {
    const qNumber = title?.match(/^(\d+)\)/)?.[1];
    return (
        <div id={id} className="tw-bg-white tw-rounded-xl tw-border tw-border-gray-200 tw-shadow-sm tw-overflow-hidden tw-transition-all tw-duration-300">
            {title && (
                <div className="tw-bg-gray-800 tw-px-3 sm:tw-px-4 tw-py-2.5 sm:tw-py-3">
                    <div className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-3">
                        {qNumber && (<div className="tw-flex-shrink-0 tw-w-7 tw-h-7 sm:tw-w-8 sm:tw-h-8 tw-rounded-full tw-bg-white tw-text-gray-800 tw-flex tw-items-center tw-justify-center tw-font-bold tw-text-xs sm:tw-text-sm">{qNumber}</div>)}
                        <Typography variant="h6" className="tw-text-white tw-text-sm sm:tw-text-base tw-font-semibold tw-flex-1">{qNumber ? title.replace(/^\d+\)\s*/, '') : title}</Typography>
                        {tooltip && (<Tooltip content={tooltip} placement="bottom"><svg className="tw-w-4 tw-h-4 sm:tw-w-5 sm:tw-h-5 tw-text-gray-400 tw-cursor-help tw-flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" /></svg></Tooltip>)}
                    </div>
                    {subtitle && <Typography variant="small" className="!tw-text-gray-300 tw-text-xs sm:tw-text-sm tw-mt-1 tw-ml-9 sm:tw-ml-11">{subtitle}</Typography>}
                </div>
            )}
            <div className="tw-p-3 sm:tw-p-4 tw-space-y-3 sm:tw-space-y-4">{children}</div>
        </div>
    );
}

// ==================== VALIDATION CARD ====================
interface ValidationError { section: string; sectionIcon: string; itemName: string; message: string; scrollId?: string; }
interface MissingInputItem { qNo: number; subNo?: number; label: string; fieldKey: string; }
interface PMValidationCardProps {
    lang: Lang;
    allPhotosAttached: boolean; missingPhotoItems: string[];
    allRequiredInputsFilled: boolean; missingInputsDetailed: MissingInputItem[];
    allPFAnswered: boolean; missingPFItems: string[];
    isSummaryFilled: boolean; isSummaryCheckFilled: boolean;
}

function PMValidationCard({ lang, allPhotosAttached, missingPhotoItems, allRequiredInputsFilled, missingInputsDetailed, allPFAnswered, missingPFItems, isSummaryFilled, isSummaryCheckFilled }: PMValidationCardProps) {
    const [isExpanded, setIsExpanded] = useState(false);

    const getPhotoScrollId = (item: string) => { const p = item.split('.'); return p.length === 2 ? `${ID_PREFIX}-photo-${p[0]}-${p[1]}` : `${ID_PREFIX}-photo-${p[0]}`; };
    const getPfScrollId = (item: string) => { const p = item.split('.'); return p.length === 2 ? `${ID_PREFIX}-pf-${p[0]}-${p[1]}` : `${ID_PREFIX}-pf-${p[0]}`; };

    const allErrors: ValidationError[] = useMemo(() => {
        const errors: ValidationError[] = [];
        if (!allPhotosAttached) {
            missingPhotoItems.forEach(item => errors.push({ section: lang === "th" ? "รูปภาพ" : "Photos", sectionIcon: "📷", itemName: `${t("itemLabel", lang)} ${item}`, message: t("missingPhoto", lang).replace(":", ""), scrollId: getPhotoScrollId(item) }));
        }
        if (!allRequiredInputsFilled) {
            missingInputsDetailed.forEach(({ qNo, subNo, label }) => {
                errors.push({ section: lang === "th" ? "ค่าที่ต้องกรอก" : "Required Inputs", sectionIcon: "📝", itemName: `${t("itemLabel", lang)} ${subNo ? `${qNo}.${subNo}` : qNo}`, message: lang === "th" ? `ยังไม่ได้กรอกค่า ${label}` : `${label} value not filled`, scrollId: subNo ? `${ID_PREFIX}-input-${qNo}-${subNo}` : `${ID_PREFIX}-question-${qNo}` });
            });
        }
        {
            if (!allPFAnswered) missingPFItems.forEach(item => errors.push({ section: lang === "th" ? "ระดับผลการตรวจ / N/A" : "Inspection rating / N/A", sectionIcon: "✅", itemName: `${t("itemLabel", lang)} ${item}`, message: lang === "th" ? "ยังไม่ได้เลือกสถานะ" : "Status not selected", scrollId: getPfScrollId(item) }));
            if (!isSummaryFilled) errors.push({ section: lang === "th" ? "สรุปผลการตรวจสอบ" : "Inspection Summary", sectionIcon: "📋", itemName: "Comment", message: t("missingSummaryText", lang), scrollId: "mdb-pm-summary-section" });
            if (!isSummaryCheckFilled) errors.push({ section: lang === "th" ? "สรุปผลการตรวจสอบ" : "Inspection Summary", sectionIcon: "📋", itemName: lang === "th" ? "สถานะสรุปผล" : "Summary Status", message: t("missingSummaryStatus", lang), scrollId: "mdb-pm-summary-section" });
        }
        return errors;
    }, [lang, allPhotosAttached, missingPhotoItems, allRequiredInputsFilled, missingInputsDetailed, allPFAnswered, missingPFItems, isSummaryFilled, isSummaryCheckFilled]);

    const groupedErrors = useMemo(() => {
        const m = new Map<string, ValidationError[]>();
        allErrors.forEach(e => { const k = `${e.sectionIcon} ${e.section}`; m.set(k, [...(m.get(k) || []), e]); });
        return m;
    }, [allErrors]);

    const isComplete = allErrors.length === 0;

    const scrollToItem = (scrollId?: string) => {
        if (!scrollId) return;
        const el = document.getElementById(scrollId);
        if (el) {
            el.scrollIntoView({ behavior: "smooth", block: "center" });
            el.classList.add("tw-ring-2", "tw-ring-amber-400", "tw-bg-amber-50");
            setTimeout(() => el.classList.remove("tw-ring-2", "tw-ring-amber-400", "tw-bg-amber-50"), 2000);
        }
    };

    return (
        <div className={`tw-rounded-xl tw-border tw-shadow-sm tw-overflow-hidden ${isComplete ? "tw-border-green-200 tw-bg-green-50" : "tw-border-amber-200 tw-bg-amber-50"}`}>
            <div className={`tw-px-4 tw-py-3 tw-cursor-pointer tw-flex tw-items-center tw-justify-between ${isComplete ? "tw-bg-green-100" : "tw-bg-amber-100"}`} onClick={() => setIsExpanded(!isExpanded)}>
                <div className="tw-flex tw-items-center tw-gap-3">
                    {isComplete ? (
                        <div className="tw-w-10 tw-h-10 tw-rounded-full tw-bg-green-500 tw-flex tw-items-center tw-justify-center"><svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg></div>
                    ) : (
                        <div className="tw-w-10 tw-h-10 tw-rounded-full tw-bg-amber-500 tw-flex tw-items-center tw-justify-center"><svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg></div>
                    )}
                    <div>
                        <Typography className={`tw-font-bold tw-text-base ${isComplete ? "tw-text-green-800" : "tw-text-amber-800"}`}>{t("formStatus", lang)}</Typography>
                        <Typography variant="small" className={isComplete ? "tw-text-green-600" : "tw-text-amber-600"}>{isComplete ? t("allCompleteReady", lang) : t("remaining", lang).replace("{n}", String(allErrors.length))}</Typography>
                    </div>
                </div>
                <div className="tw-flex tw-items-center tw-gap-4">
                    {!isComplete && (<div className="tw-hidden md:tw-flex tw-items-center tw-gap-2">{Array.from(groupedErrors.keys()).map(k => (<span key={k} className="tw-text-xs tw-bg-amber-200 tw-text-amber-800 tw-px-2 tw-py-1 tw-rounded-full tw-font-medium">{k.split(" ")[0]} {groupedErrors.get(k)?.length}</span>))}</div>)}
                    {!isComplete && (<svg className={`tw-w-6 tw-h-6 tw-text-amber-600 tw-transition-transform ${isExpanded ? "tw-rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>)}
                </div>
            </div>
            {isExpanded && !isComplete && (
                <div className="tw-px-4 tw-py-3 tw-max-h-80 tw-overflow-y-auto">
                    <div className="tw-space-y-4">
                        {Array.from(groupedErrors.entries()).map(([sectionKey, sectionErrors]) => (
                            <div key={sectionKey} className="tw-bg-white tw-rounded-lg tw-p-3 tw-border tw-border-amber-200">
                                <div className="tw-flex tw-items-center tw-justify-between tw-mb-2">
                                    <Typography className="tw-font-semibold tw-text-gray-800 tw-text-sm">{sectionKey}</Typography>
                                    <span className="tw-text-xs tw-bg-amber-100 tw-text-amber-700 tw-px-2 tw-py-0.5 tw-rounded-full">{sectionErrors.length} {t("items", lang)}</span>
                                </div>
                                <ul className="tw-space-y-1 tw-max-h-40 tw-overflow-y-auto">
                                    {sectionErrors.map((error, idx) => (
                                        <li key={idx} className="tw-flex tw-items-start tw-gap-2 tw-text-sm tw-text-amber-700 tw-cursor-pointer hover:tw-text-amber-900 hover:tw-bg-amber-50 tw-rounded tw-px-1 tw-py-0.5 tw-transition-colors" onClick={() => scrollToItem(error.scrollId)}>
                                            <span className="tw-text-amber-500 tw-mt-0.5">→</span>
                                            <span><span className="tw-font-medium">{error.itemName}:</span> <span className="tw-underline tw-underline-offset-2">{error.message}</span></span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

function InputWithUnit<U extends string>({ label, value, unit, units, onValueChange, onUnitChange, readOnly, disabled, required = false }: {
    label: string; value: string; unit: U; units: readonly U[];
    onValueChange: (v: string) => void; onUnitChange: (u: U) => void;
    readOnly?: boolean; disabled?: boolean; required?: boolean;
}) {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const v = e.target.value;
        if (v === "" || v === "-" || /^-?\d*\.?\d*$/.test(v)) onValueChange(v);
    };
    return (
        <div className="tw-flex tw-items-center tw-gap-2">
            <div className="tw-flex-1 tw-relative">
                <input type="text" inputMode="text" pattern="-?[0-9]*\.?[0-9]*" value={value} onChange={handleChange} readOnly={readOnly} disabled={disabled} required={required} placeholder=" "
                    className={`tw-peer tw-w-full tw-h-10 tw-px-3 tw-pt-4 tw-pb-1 tw-text-sm tw-border tw-rounded-lg tw-outline-none focus:tw-ring-1 tw-border-gray-300 focus:tw-border-blue-500 focus:tw-ring-blue-500 ${disabled ? "tw-bg-gray-100 tw-text-gray-500" : "tw-bg-white"}`} />
                <label className="tw-absolute tw-left-3 tw-top-1 tw-text-[10px] tw-text-gray-500 tw-pointer-events-none">{label}{required && <span className="tw-text-red-500">*</span>}</label>
            </div>
            <div className="tw-flex-shrink-0 tw-w-10 tw-h-10 tw-flex tw-items-center tw-justify-center tw-text-gray-600 tw-font-medium tw-text-sm tw-bg-gray-100 tw-rounded-lg tw-border tw-border-gray-200">{unit}</div>
        </div>
    );
}

// ==================== PHOTO INPUT (matches Charger) ====================
// บีบรูปก่อนอัปโหลด — การันตีว่าผลลัพธ์เล็กกว่า targetBytes
// แก้คอมเมนต์ 2026-09-23: เพดานจริงของ nginx คือ 30M ไม่ใช่ ~1MB ตามที่เคยเขียนไว้
// (ตรวจแล้วที่ /etc/nginx/conf.d/imps-upload.conf — client_max_body_size 30M)
// targetBytes 900KB ยังคงไว้เพราะจงใจ: ช่างอัปจากมือถือผ่าน 4G ทีละ 10 รูป
// ไฟล์เล็กกว่า = อัปเร็วกว่าและเปลืองพื้นที่เซิร์ฟเวอร์น้อยกว่า ไม่ใช่ข้อจำกัดของ nginx
// ไฟล์ที่เล็กกว่าเป้าอยู่แล้วจะคืนค่าเดิมทันที (nginx จำกัดที่ "ขนาดไฟล์" ไม่ใช่ความละเอียด)
async function compressImage(
    file: File,
    maxWidth = 1600,
    quality = 0.8,
    targetBytes = 900 * 1024,
): Promise<File> {
    if (!file.type.startsWith("image/") || file.size <= targetBytes) return file;

    const img = await new Promise<HTMLImageElement | null>((resolve) => {
        const im = document.createElement("img");
        im.onload = () => resolve(im);
        im.onerror = () => resolve(null);
        im.src = URL.createObjectURL(file);
    });
    if (!img) return file;
    URL.revokeObjectURL(img.src);

    let { width, height } = img;
    if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
    }

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(img, 0, 0, width, height);

    const toBlob = (q: number) =>
        new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", q));

    // วนลดคุณภาพทีละขั้นจนกว่าไฟล์จะเล็กกว่าเป้า (หรือถึงคุณภาพต่ำสุดที่ยอมรับได้)
    let q = quality;
    let blob = await toBlob(q);
    while (blob && blob.size > targetBytes && q > 0.4) {
        q = Math.round((q - 0.1) * 10) / 10;
        blob = await toBlob(q);
    }

    if (!blob || blob.size >= file.size) return file; // toBlob ล้มเหลว หรือไม่เล็กลง → ใช้ไฟล์เดิม
    return new File([blob], ensureJpgFilename(file.name), { type: "image/jpeg" });
}

 function PhotoMultiInput({ photos, setPhotos, max = 10, draftKey, qNo, lang, id }: {
    photos: PhotoItem[]; setPhotos: React.Dispatch<React.SetStateAction<PhotoItem[]>>;
    max?: number; draftKey: string; qNo: number; lang: Lang; id?: string;
}) {
    const cameraRef = useRef<HTMLInputElement>(null);
    const fileRef = useRef<HTMLInputElement>(null);
    const isMobile = useMemo(() => isMobileDevice(), []);
    const [landscapeWarning, setLandscapeWarning] = useState(false);

    const processFile = async (rawFile: File): Promise<PhotoItem | null> => {
        try {
            // กันไฟล์ว่าง (size=0) ตั้งแต่ต้นทาง — เป็นต้นเหตุของ error "Empty file (size=0)" ตอนอัปโหลด
            if (!rawFile || rawFile.size === 0) {
                console.warn("processFile: empty source file", rawFile?.name);
                return null;
            }
            // รูป HEIC จาก iPhone: เบราว์เซอร์นอกจาก Safari decode ไม่ได้ ทำให้ทั้งท่อพังเงียบ ๆ
            // — addTimestampToImage ไม่ประทับเวลา/พิกัด, compressImage ไม่บีบ, preview ขึ้นกรอบว่าง
            // แปลงเป็น JPEG ที่ server ก่อน (ล้มเหลวก็คืนไฟล์เดิม backend แปลงให้อีกชั้นตอนอัปโหลด)
            const file = await ensureViewableImage(rawFile);
            const locationText = await getCachedLocation();
            const stamped = await addTimestampToImage(file, locationText);
            // ถ้า encode แล้วได้ไฟล์ว่าง (เช่น canvas ล้มเหลวบางเครื่อง) ให้ fallback ไฟล์เดิม แล้วเช็กซ้ำ
            const fileWithTimestamp = (stamped && stamped.size > 0) ? stamped : file;
            if (fileWithTimestamp.size === 0) {
                console.warn("processFile: empty file after timestamp", file.name);
                return null;
            }
            // บีบรูปก่อนเก็บลง IndexedDB — ลดพื้นที่จัดเก็บ (กัน quota เต็มบนมือถือ) + ได้รูปที่พร้อมอัปโหลดเลย
            const compressed = await compressImage(fileWithTimestamp);
            const finalFile = (compressed && compressed.size > 0) ? compressed : fileWithTimestamp;
            // ⚡ ดักตั้งแต่ตอนแนบ: .size เชื่อไม่ได้ (iOS คืน backing store แต่ยังรายงาน size เดิม)
            if (!(await isFileReadable(finalFile))) {
                console.warn("processFile: ไฟล์อ่านไม่ได้ตั้งแต่ตอนแนบ", file.name);
                return null;
            }
            // หมายเหตุ: เคย return null ตรงนี้ถ้า decode ไม่ผ่าน แต่ทำให้แนบรูปไม่ได้เลย
            // เพราะ CSP img-src ไม่อนุญาต blob: การโหลดรูปเลยล้มเหลวทุกใบ
            // เหลือไว้เป็น log อย่างเดียว ห้ามใช้ block การแนบรูป
            if (!(await isImageDecodable(finalFile))) {
                console.warn("processFile: เบราว์เซอร์แสดงผลรูปนี้ไม่ได้", file.name, file.type);
            }
            const photoId = `${qNo}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${file.name}`;
            // เขียน IndexedDB ไม่ได้ (พื้นที่เต็ม / private mode) → ห้ามทิ้งรูป เก็บใน memory ต่อแล้วเตือน
            let ref: PhotoRef | undefined;
            try { ref = await putPhoto(draftKey, photoId, finalFile); }
            catch (e) { console.error("putPhoto failed:", e); reportPhotoStorageFailure(lang); }
            const now = new Date().toLocaleString("th-TH", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
            return { id: photoId, file: finalFile, preview: URL.createObjectURL(finalFile), remark: "", ref, createdAt: now, location: locationText };
        } catch (err) { console.error("processFile error:", err); return null; }
    };

    const handleFiles = async (list: FileList | null, fromCamera: boolean) => {
        if (!list || list.length === 0) return;
        const remain = Math.max(0, max - photos.length);
        if (remain === 0) { alert(lang === "th" ? `แนบรูปได้สูงสุด ${max} รูปต่อข้อ` : `Maximum ${max} photos per item`); return; }
        const files = Array.from(list).slice(0, remain);
        if (Array.from(list).length > remain) alert(lang === "th" ? `เลือกได้อีก ${remain} รูป (ครบ ${max} รูปแล้ว)` : `Only ${remain} more photo(s) allowed (max ${max})`);

        let hasLandscape = false;
        const validFiles: File[] = [];
        for (const f of files) {
            if (fromCamera) {
                try { const dim = await getImageDimensions(f); if (dim.width > dim.height) { hasLandscape = true; continue; } } catch { }
            }
            validFiles.push(f);
        }
        const results = await Promise.all(validFiles.map(f => processFile(f)));
        const accepted = results.filter(Boolean) as PhotoItem[];
        const rejected = validFiles.length - accepted.length;
        if (accepted.length > 0) setPhotos(prev => [...prev, ...accepted]);
        // แจ้งเตือนถ้ามีรูปว่าง/เสียหายถูกข้าม — กันผู้ใช้เข้าใจผิดว่าแนบครบแล้ว
        if (rejected > 0) {
            alert(lang === "th"
                ? `มีรูปว่าง/เสียหาย ${rejected} รูป ใช้ไม่ได้ กรุณาถ่ายหรือเลือกใหม่อีกครั้ง`
                : `${rejected} photo(s) are empty/corrupted and were skipped. Please retake or reselect.`);
        }
        if (hasLandscape) setLandscapeWarning(true);
        if (cameraRef.current) cameraRef.current.value = "";
        if (fileRef.current) fileRef.current.value = "";
    };

    const handleRemove = async (id: string) => {
        await delPhoto(draftKey, id);
        setPhotos(prev => { const target = prev.find(p => p.id === id); if (target?.preview) URL.revokeObjectURL(target.preview); return prev.filter(p => p.id !== id); });
    };

    return (
        <div id={id} className="tw-space-y-3 tw-transition-all tw-duration-300">
            {landscapeWarning && (
                <div className="tw-fixed tw-inset-0 tw-z-[9999] tw-bg-black/70 tw-flex tw-items-center tw-justify-center tw-p-6" onClick={() => setLandscapeWarning(false)}>
                    <div className="tw-bg-white tw-rounded-2xl tw-p-6 tw-max-w-sm tw-text-center tw-shadow-xl" onClick={e => e.stopPropagation()}>
                        <svg className="tw-w-14 tw-h-14 tw-text-amber-500 tw-mx-auto tw-mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                        <p className="tw-text-lg tw-font-bold tw-text-gray-800 tw-mb-2">{lang === "th" ? "กรุณาถ่ายรูปแนวตั้ง" : "Please take portrait photos"}</p>
                        <p className="tw-text-sm tw-text-gray-600 tw-mb-4">{lang === "th" ? "รูปที่ถ่ายเป็นแนวนอนจะไม่ถูกรับ กรุณาหมุนมือถือเป็นแนวตั้งแล้วถ่ายใหม่" : "Landscape photos are not accepted. Please hold your phone upright and retake."}</p>
                        <Button size="sm" color="amber" variant="filled" onClick={() => setLandscapeWarning(false)} className="tw-w-full">{lang === "th" ? "รับทราบ" : "OK"}</Button>
                    </div>
                </div>
            )}
            <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2">
                {isMobile ? (
                    <Button data-photo-add size="sm" color="blue" variant="outlined" onClick={() => cameraRef.current?.click()} className="tw-shrink-0 tw-flex tw-items-center tw-gap-1">
                        <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                        {t("takePhoto", lang)}
                    </Button>
                ) : (
                    <Button data-photo-add size="sm" color="blue" variant="outlined" onClick={() => fileRef.current?.click()} className="tw-shrink-0 tw-flex tw-items-center tw-gap-1">
                        <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        {t("attachPhoto", lang)}
                    </Button>
                )}
            </div>
            {isMobile && <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="tw-hidden" onChange={e => { void handleFiles(e.target.files, true); }} />}
            {!isMobile && <input ref={fileRef} type="file" accept="image/*" multiple className="tw-hidden" onChange={e => { void handleFiles(e.target.files, false); }} />}
            <Typography variant="small" className="!tw-text-blue-gray-500">{t("maxPhotos", lang)} {max} {t("photos", lang)}</Typography>
            {photos.length > 0 ? (
                <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-3 md:tw-grid-cols-4 tw-gap-3">
                    {photos.map(p => (
                        <div key={p.id} className="tw-border tw-rounded-lg tw-overflow-hidden tw-bg-gray-100 tw-shadow-xs tw-flex tw-flex-col">
                            <div className="tw-relative tw-aspect-[4/3] tw-bg-gray-100">
                                {p.preview && <img src={p.preview} alt={t("photoPreviewAlt", lang)} className="tw-w-full tw-h-full tw-object-contain" />}
                                <button data-photo-remove onClick={() => { void handleRemove(p.id); }} className="tw-absolute tw-top-2 tw-right-2 tw-bg-red-500 tw-text-white tw-w-6 tw-h-6 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-shadow-md hover:tw-bg-red-600 tw-transition-colors">×</button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (<Typography variant="small" className="!tw-text-blue-gray-500">{t("noPhotos", lang)}</Typography>)}
        </div>
    );
}

// ==================== BACKGROUND UPLOAD BANNER ====================
function BackgroundUploadBanner({ lang }: { lang: Lang }) {
    const [progress, setProgress] = useState<BgUploadProgress>({ total: 0, completed: 0, failed: 0, inProgress: false, failures: [] });
    useEffect(() => subscribeBgUpload(setProgress), []);
    useEffect(() => {
        if (progress.total > 0 && !progress.inProgress && progress.failed === 0 && progress.completed === progress.total) {
            const timer = setTimeout(() => resetBgUpload(), 3000);
            return () => clearTimeout(timer);
        }
    }, [progress]);
    if (progress.total === 0) return null;
    if (!progress.inProgress && progress.failed === 0 && progress.completed === progress.total) {
        return (<div className="tw-fixed tw-bottom-4 tw-left-1/2 tw--translate-x-1/2 tw-z-50 tw-bg-green-600 tw-text-white tw-px-5 tw-py-3 tw-rounded-xl tw-shadow-2xl tw-text-sm tw-flex tw-items-center tw-gap-2"><svg className="tw-w-5 tw-h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>{lang === "th" ? "อัปโหลดข้อมูลสำเร็จ" : "Data uploaded successfully"}</div>);
    }
    if (!progress.inProgress && progress.failed > 0) {
        return (<div className="tw-fixed tw-bottom-4 tw-left-1/2 tw--translate-x-1/2 tw-z-50 tw-bg-red-600 tw-text-white tw-px-5 tw-py-3 tw-rounded-xl tw-shadow-2xl tw-text-sm tw-max-w-md"><div className="tw-flex tw-items-center tw-gap-2"><span>⚠️</span><span>{lang === "th" ? `อัปโหลดรูปไม่สำเร็จ ${progress.failed} รูป (สำเร็จ ${progress.completed}/${progress.total})` : `${progress.failed} photos failed (${progress.completed}/${progress.total} ok)`}</span></div><button onClick={resetBgUpload} className="tw-mt-2 tw-text-xs tw-underline tw-opacity-80 hover:tw-opacity-100">{lang === "th" ? "ปิด" : "Dismiss"}</button></div>);
    }
    const pct = progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0;
    return (
        <div className="tw-fixed tw-bottom-4 tw-left-1/2 tw--translate-x-1/2 tw-z-50 tw-bg-gray-800 tw-text-white tw-px-5 tw-py-3 tw-rounded-xl tw-shadow-2xl tw-text-sm tw-min-w-[260px]">
            <div className="tw-flex tw-items-center tw-gap-3"><svg className="tw-animate-spin tw-h-4 tw-w-4 tw-flex-shrink-0" viewBox="0 0 24 24"><circle className="tw-opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="tw-opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg><span>{lang === "th" ? `กำลังอัปโหลดรูป...` : `Uploading photos...`} {progress.completed}/{progress.total}</span></div>
            <div className="tw-mt-2 tw-h-1.5 tw-bg-gray-600 tw-rounded-full tw-overflow-hidden"><div className="tw-h-full tw-bg-blue-400 tw-rounded-full tw-transition-all tw-duration-300" style={{ width: `${pct}%` }} /></div>
        </div>
    );
}

// ==================== API ====================
const PM_PREFIX = "mdbpmreport";

async function fetchPreviewIssueId(stationId: string, pmDate: string): Promise<string | null> {
    const u = new URL(`${API_BASE}/mdbpmreport/preview-issueid`);
    u.searchParams.set("station_id", stationId); u.searchParams.set("pm_date", pmDate);
    const r = await apiFetch(u.toString(), { credentials: "include" });
    if (!r.ok) return null;
    const j = await r.json();
    return (j && typeof j.issue_id === "string") ? j.issue_id : null;
}

async function fetchPreviewDocName(stationId: string, pmDate: string): Promise<string | null> {
    const u = new URL(`${API_BASE}/mdbpmreport/preview-docname`);
    u.searchParams.set("station_id", stationId); u.searchParams.set("pm_date", pmDate);
    const r = await apiFetch(u.toString(), { credentials: "include" });
    if (!r.ok) return null;
    const j = await r.json();
    return (j && typeof j.doc_name === "string") ? j.doc_name : null;
}

async function fetchReport(reportId: string, stationId: string) {
    const url = `${API_BASE}/mdbpmreport/get?station_id=${stationId}&report_id=${reportId}`;
    const res = await apiFetch(url, { method: "GET", credentials: "include" });
    if (!res.ok) throw new Error(await res.text());
    return await res.json();
}

// ==================== MAIN COMPONENT ====================
export default function MDBPMForm() {
    const { lang } = useLanguage();
    const [me, setMe] = useState<Me | null>(null);
    const router = useRouter();
    const [submitting, setSubmitting] = useState(false);
    const [pageLoading, setPageLoading] = useState(true);
    const [preUploadState, setPreUploadState] = useState({ show: false, total: 0, completed: 0, failed: 0 });
    const [docName, setDocName] = useState<string>("");

    const pathname = usePathname();
    const searchParams = useSearchParams();

    // ปุ่มย้อนกลับ: เปิดมาจากหน้า PM List ให้กลับไปหน้านั้นตรงๆ
    // router.back() ใช้ไม่ได้ เพราะสลับ pmtab ในฟอร์มก็ดันประวัติเพิ่มทุกครั้ง
    // กดกลับเลยแค่ถอยการสลับแท็บ ไม่ได้ออกจากใบงาน
    const goBackToList = useCallback(() => {
        // กลับหน้าที่เปิดเข้ามา: หน้ารวมของใบ PM สถานี / PM List — นอกนั้นถอยประวัติ
        const back = pmFormReturnRoute(searchParams);
        if (back) router.push(back);
        else router.back();
    }, [router, searchParams]);
    // ใบที่เปิดจาก List (แก้ใบที่โดนตีกลับ / ใบเก่าที่ยังเป็น draft) — ใบใหม่เปิดมาไม่มี id
    const editId = searchParams.get("edit_id") ?? "";
    // เปิดจากใบ PM สถานี "ใบเดียว 4 ส่วน" → ผูกใบนี้เป็นส่วนหนึ่งของใบแม่
    const jobId = searchParams.get("job_id") ?? "";

    const [docApiLoaded, setDocApiLoaded] = useState(false);
    const [photos, setPhotos] = useState<Record<string | number, PhotoItem[]>>({});
    // รูปเดิมของเอกสารที่โหลดมาใส่ฟอร์ม (หน้าดู / แก้ส่วนที่ส่งแล้ว) — ตอนบันทึกเทียบกับ photos
    // เพื่อรู้ว่าผู้ใช้กดลบรูปเดิมรูปไหนออก แล้วลบออกจากเอกสารจริง
    const serverPhotosRef = useRef<Record<string, ViewPhoto[]>>({});
    const [summary, setSummary] = useState<string>("");
    const [stationId, setStationId] = useState<string | null>(null);
    // เปิดจากใบ PM สถานี → หัวฟอร์มใช้เลขที่/ชื่อเอกสารของใบแม่ (ส่วนที่ยังไม่บันทึกไม่มีเลขในตัวเอง)
    const jobDocIds = useJobDocIds(jobId, stationId ?? searchParams.get("station_id"));

    // draft ในเครื่อง — สูตรเดียวกับฟอร์มอื่น: ใบเดิมผูกกับ id, ใบใหม่ผูกกับใบ PM สถานี (job_id)
    // เดิมใบใหม่ใช้ key ของสถานีร่วมกันทุกใบ draft ของอีกใบเลยโผล่มาปนได้
    const currentDraftKey = useMemo(
        () => `${draftKey(stationId)}:${editId ? editId : (jobId ? `job-${jobId}` : "new")}:post`,
        [stationId, editId, jobId],
    );
    // key เก่าของใบใหม่ — draft ที่ค้างอยู่ก่อนเปลี่ยนสูตรจะได้ไม่หาย
    const legacyNewDraftKey = useMemo(() => draftKey(stationId), [stationId]);
    // key ที่ restore draft เสร็จแล้ว — autosave ห้ามทำงานก่อน ไม่งั้น state ว่างตอนเปิดหน้า
    // (ยังไม่มีรูป) จะเขียนทับ draft เดิม รูปที่แนบไว้เลยหายตอนกลับเข้าฟอร์ม
    const [restoredKey, setRestoredKey] = useState<string | null>(null);
    // ส่งเสร็จแล้วล้าง draft — autosave ที่ค้างอยู่ (รวมตอนออกจากหน้า) ห้ามเขียนกลับ
    const draftClearedRef = useRef(false);
    // ปุ่ม "ยกเลิกการแก้ไข" ที่หน้ารวมล้าง draft ของฟอร์มนี้ผ่านตัวนี้ (หน้ารวมไม่รู้สูตร key ของแต่ละฟอร์ม)
    useEffect(() => registerDraftDiscard(async () => {
        draftClearedRef.current = true; // กัน autosave ที่ค้างอยู่เขียนกลับมาตอนออกจากหน้า
        await clearDraftLocal(currentDraftKey);
    }), [currentDraftKey]);
    useEffect(() => { draftClearedRef.current = false; }, [currentDraftKey]);

    const reportIdRef = useRef<string | null>(null);

    useEffect(() => { reportIdRef.current = null; }, [editId]);

    const photosRef = useRef(photos);
    useEffect(() => { photosRef.current = photos; }, [photos]);
    useEffect(() => {
        return () => { Object.values(photosRef.current).flat().forEach(p => { if (p.preview?.startsWith("blob:")) URL.revokeObjectURL(p.preview); }); };
    }, []);

    const [summaryCheck, setSummaryCheck] = useState<PF>("");

    // เวลาทำงานจริงของช่าง (datetime-local) — ส่งเข้า Maximo ทาง IN09 ตอนปิดใบงาน

    // ตั้งต้นเป็นเวลาที่ช่างเปิดฟอร์ม — ปกติคือเวลาที่ถึงหน้างานพอดี แก้ทีหลังได้
    // ใบที่เคยบันทึกเวลาไว้แล้วจะถูกทับด้วยค่าจากเอกสารตอนโหลด
    const [workStart, setWorkStart] = useState<string>(() => nowLocalDatetime());

    const [workFinish, setWorkFinish] = useState<string>("");

    // planner เปิดเอกสารที่ช่างส่งมาเพื่อตรวจก่อนอนุมัติ (?approve=1)

    const approveMode = searchParams.get("approve") === "1";
    // ช่างเปิดดูใบที่ตัวเองส่งไปแล้ว (?review=1) — เห็นหน้าเดียวกับ planner
    // แต่แก้อะไรไม่ได้ และไม่มีปุ่ม Reject/Approve
    const reviewMode = approveMode || searchParams.get("review") === "1";
    const reviewAction = usePmReviewAction();
    const cancelEditAction = usePmCancelEdit();

    // laborcode ฝั่ง Maximo ที่ช่างเลือกเอง — username ใน iMPS ใช้แทนกันไม่ได้
    const [laborOptions, setLaborOptions] = useState<{ laborcode: string; name: string; needs_name?: boolean }[]>([]);
    const [maximoLabor, setMaximoLabor] = useState<string[]>([]);
    const [maximoContractor, setMaximoContractor] = useState<string>("");

    useEffect(() => {
        let alive = true;
        (async () => {
            try {
                const res = await apiFetch(`${API_BASE}/cm-maximo/labor-codes`);
                if (!res.ok) return;
                const data = await res.json();
                if (alive && Array.isArray(data?.items)) setLaborOptions(data.items);
            } catch {
                // ดึงไม่ได้ = ไม่โชว์ตัวเลือก ไม่ต้องบล็อกการกรอกใบงาน
            }
        })();
        return () => { alive = false; };
    }, []);

    const toggleMaximoLabor = (code: string) =>
        setMaximoLabor(prev => prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]);

    // ติ๊กรหัสกลางของผู้รับเหมาไว้ = ต้องมีชื่อจริงกำกับ

    // รหัสที่ช่างเลือกไว้ต้องโชว์ได้เสมอ ถึงรายชื่อจาก Maximo จะโหลดไม่ขึ้น
    // (เน็ตหลุด / สิทธิ์ไม่ถึง) ไม่งั้นหน้าอนุมัติจะกลายเป็นว่าไม่ได้เลือกใครเลย
    const laborList = useMemo(() => {
        const have = new Set(laborOptions.map((o) => o.laborcode));
        const missing = maximoLabor.filter((c) => !have.has(c)).map((c) => ({ laborcode: c, name: c }));
        const all = missing.length ? [...laborOptions, ...missing] : laborOptions;
        // โหมดตรวจไม่ต้องเห็นรายชื่อทั้งกรม เอาเฉพาะคนที่ช่างเลือกลงใบงานนี้
        return reviewMode ? all.filter((o) => maximoLabor.includes(o.laborcode)) : all;
    }, [laborOptions, maximoLabor, reviewMode]);
    const contractorPicked = laborOptions.some((o) => o.needs_name && maximoLabor.includes(o.laborcode));
    const contractorMissing = contractorPicked && !maximoContractor.trim();
    const [inspector, setInspector] = useState<string>("");
    const [dustFilterChanged, setDustFilterChanged] = useState<boolean>(false);
    const [job, setJob] = useState({ issue_id: "", station_name: "", date: "" });

    useEffect(() => { void prefetchLocation(); }, []);

    // รูปจากเอกสาร (ใช้ในตารางผลการตรวจตอนตรวจอนุมัติ) — state รูปของฟอร์มเป็นรูปในเครื่อง
    const [cmpPhotos, setCmpPhotos] = useState<any>({});

    // ใบที่ไม่มี form_version (หรือต่ำกว่าปัจจุบัน) ใช้เลขข้อคนละชุด — คีย์ r1..r13
    // ของใบพวกนั้นคือหัวข้อ 1-13 แบบเก่า ถ้าเอามาเปิดในฟอร์มนี้จะจับคู่ผิดหัวข้อทั้งใบ
    // จึงให้เปิดดูผ่านตารางสรุป/PDF อย่างเดียว แก้ไขต่อไม่ได้
    const [docFormVersion, setDocFormVersion] = useState<number>(FORM_VERSION);
    const legacyDoc = !!editId && docFormVersion < FORM_VERSION;
    const [rows, setRows] = useState<Record<string, { pf: PF; remark: string }>>(() => {
        const initial: Record<string, { pf: PF; remark: string }> = {};
        QUESTIONS.forEach(q => { if (q.kind === "simple" || q.kind === "measure") initial[q.key] = { pf: "", remark: "" }; else if ((q.kind === "group" || q.kind === "power_source") && q.items) q.items.forEach(it => { initial[it.key] = { pf: "", remark: "" }; }); });
        return initial;
    });

    const [m4State, setM4State] = useState<Record<string, MeasureState<UnitVoltage>>>({});
    const [m5State, setM5State] = useState<Record<string, MeasureState<UnitVoltage>>>({});
    const [m6State, setM6State] = useState<Record<string, MeasureState<UnitVoltage>>>({});
    const [m7State, setM7State] = useState<Record<string, MeasureState<UnitVoltage>>>({});

    const [q6Items, setQ6Items] = useState<{ key: string; label: string }[]>([{ key: "r6_1", label: getDynamicLabel.breakerMain(1, lang) }]);
    const [q8Items, setQ8Items] = useState<{ key: string; label: string }[]>([{ key: "r8_1", label: getDynamicLabel.breakerCCB(1, lang) }]);
    const [chargerCount, setChargerCount] = useState<number>(1);

    useEffect(() => {
        setQ6Items(prev => prev.map((item, i) => ({ ...item, label: getDynamicLabel.breakerMain(i + 1, lang) })));
        setQ8Items(prev => prev.map((item, i) => ({ ...item, label: getDynamicLabel.breakerCCB(i + 1, lang) })));
    }, [lang]);

    const q7Items = useMemo(() => Array.from({ length: chargerCount }, (_, i) => ({ key: `r7_${i + 1}`, label: getDynamicLabel.breakerCharger(i + 1, lang) })), [chargerCount, lang]);
    const q9Items = useMemo(() => Array.from({ length: chargerCount }, (_, i) => ({ key: `r9_${i + 1}`, label: getDynamicLabel.rcd(i + 1, lang) })), [chargerCount, lang]);
    const q10Items = useMemo(() => Array.from({ length: chargerCount }, (_, i) => ({ key: `r10_${i + 1}`, label: getDynamicLabel.tripRCD(i + 1, lang) })), [chargerCount, lang]);
    const q11Items = useMemo(() => q8Items.map((_, i) => ({ key: `r11_${i + 1}`, label: getDynamicLabel.tripCCB(i + 1, lang) })), [q8Items, lang]);
    const q12Items = useMemo(() => Array.from({ length: chargerCount }, (_, i) => ({ key: `r12_${i + 1}`, label: getDynamicLabel.tripCharger(i + 1, lang) })), [chargerCount, lang]);
    const q13Items = useMemo(() => q6Items.map((_, i) => ({ key: `r13_${i + 1}`, label: getDynamicLabel.tripMain(i + 1, lang) })), [q6Items, lang]);

    useEffect(() => { setM4State(prev => { const n = { ...prev }; q6Items.forEach(item => { if (!n[item.key]) n[item.key] = initMeasureState(VOLTAGE_FIELDS, "V"); }); return n; }); }, [q6Items]);
    useEffect(() => { setM5State(prev => { const n = { ...prev }; q7Items.forEach(item => { if (!n[item.key]) n[item.key] = initMeasureState(VOLTAGE_FIELDS, "V"); }); return n; }); }, [q7Items]);
    useEffect(() => { setM6State(prev => { const n = { ...prev }; q8Items.forEach(item => { if (!n[item.key]) n[item.key] = initMeasureState(VOLTAGE_FIELDS_CCB, "V"); }); return n; }); }, [q8Items]);
    useEffect(() => { setM7State(prev => { const n = { ...prev }; q9Items.forEach(item => { if (!n[item.key]) n[item.key] = initMeasureState(VOLTAGE_FIELDS_CCB, "V"); }); return n; }); }, [q9Items]);

    useEffect(() => {
        setRows(prev => {
            const next = { ...prev }; let changed = false;
            [q6Items, q7Items, q8Items, q9Items, q10Items, q11Items, q12Items, q13Items].forEach(items => {
                items.forEach(item => { if (!next[item.key]) { next[item.key] = { pf: "", remark: "" }; changed = true; } });
            });
            return changed ? next : prev;
        });
    }, [q6Items, q7Items, q8Items, q9Items, q10Items, q11Items, q12Items, q13Items]);

    const addQ6Item = () => { const i = q6Items.length + 1; setQ6Items(prev => [...prev, { key: `r6_${i}`, label: getDynamicLabel.breakerMain(i, lang) }]); };
    const removeQ6Item = (idx: number) => {
        if (q6Items.length <= 1) return;
        const oldKeys = q6Items.map(it => it.key);
        const remainingOldKeys = oldKeys.filter((_, i) => i !== idx);
        const newItems = remainingOldKeys.map((_, i) => ({ key: `r6_${i + 1}`, label: getDynamicLabel.breakerMain(i + 1, lang) }));
        setQ6Items(newItems);
        setRows(prev => { const n = { ...prev }; oldKeys.forEach(k => delete n[k]); remainingOldKeys.forEach((oldKey, i) => { if (prev[oldKey] !== undefined) n[`r6_${i + 1}`] = prev[oldKey]; }); return n; });
        setM4State(prev => { const n = { ...prev }; oldKeys.forEach(k => delete n[k]); remainingOldKeys.forEach((oldKey, i) => { if (prev[oldKey] !== undefined) n[`r6_${i + 1}`] = prev[oldKey]; }); return n; });
        setPhotos(prev => { const n = { ...prev }; oldKeys.forEach(k => delete n[k]); remainingOldKeys.forEach((oldKey, i) => { if (prev[oldKey] !== undefined) n[`r6_${i + 1}`] = prev[oldKey]; }); return n; });
    };

    const addQ8Item = () => { if (q8Items.length >= 4) return; const i = q8Items.length + 1; setQ8Items(prev => [...prev, { key: `r8_${i}`, label: getDynamicLabel.breakerCCB(i, lang) }]); };
    const removeQ8Item = (idx: number) => {
        if (q8Items.length <= 1) return;
        const oldKeys = q8Items.map(it => it.key);
        const remainingOldKeys = oldKeys.filter((_, i) => i !== idx);
        const newItems = remainingOldKeys.map((_, i) => ({ key: `r8_${i + 1}`, label: getDynamicLabel.breakerCCB(i + 1, lang) }));
        setQ8Items(newItems);
        setRows(prev => { const n = { ...prev }; oldKeys.forEach(k => delete n[k]); remainingOldKeys.forEach((oldKey, i) => { if (prev[oldKey] !== undefined) n[`r8_${i + 1}`] = prev[oldKey]; }); return n; });
        setM6State(prev => { const n = { ...prev }; oldKeys.forEach(k => delete n[k]); remainingOldKeys.forEach((oldKey, i) => { if (prev[oldKey] !== undefined) n[`r8_${i + 1}`] = prev[oldKey]; }); return n; });
        setPhotos(prev => { const n = { ...prev }; oldKeys.forEach(k => delete n[k]); remainingOldKeys.forEach((oldKey, i) => { if (prev[oldKey] !== undefined) n[`r8_${i + 1}`] = prev[oldKey]; }); return n; });
    };

    // ==================== EFFECTS ====================
    useEffect(() => {
        if (!editId || !stationId) return;
        setDocApiLoaded(false);
        setM4State({}); setM5State({}); setM6State({}); setM7State({});
        setRows(() => { const init: Record<string, { pf: PF; remark: string }> = {}; QUESTIONS.forEach(q => { init[q.key] = { pf: "", remark: "" }; }); return init; });
        (async () => {
            try {
                const data = await fetchReport(editId, stationId);
                setDocFormVersion(Number(data.form_version) || 1);
                if (data.job) setJob(prev => ({ ...prev, ...data.job, station_name: data.job.station_name || prev.station_name, issue_id: data.issue_id ?? prev.issue_id }));
                if (data.pm_date) setJob(prev => ({ ...prev, date: data.pm_date }));
                if (data.charger_count) setChargerCount(data.charger_count);
                if (data.q4_items) setQ6Items(data.q4_items.map((it: any, i: number) => ({ ...it, label: getDynamicLabel.breakerMain(i + 1, lang) })));
                if (data.q6_items) setQ8Items(data.q6_items.map((it: any, i: number) => ({ ...it, label: getDynamicLabel.breakerCCB(i + 1, lang) })));
                if (data.doc_name) setDocName(data.doc_name);
                if (data.inspector) setInspector(data.inspector);
                setCmpPhotos(data.photos ?? {});
                // หน้าดูใช้ฟอร์มเดียวกับตอนกรอก — รูปมาจากเอกสาร ไม่ใช่ draft ในเครื่อง
                // กลุ่ม g{n} คือข้อ n, ข้อย่อย r6_1 ใช้ชื่อเดียวกับ photo key (normalizePhotoGroup)
                // ส่วนหนึ่งของใบ PM สถานี: เปิดแก้ส่วนที่ส่งแล้วก็ต้องเห็นรูปเดิม (ลบ/เพิ่มได้)
                if (reviewMode || jobId) {
                    const fromServer = serverPhotosToForm(data.photos,
                        g => (/^g\d+$/.test(g) ? g.slice(1) : g), API_BASE);
                    serverPhotosRef.current = fromServer;
                    setPhotos(prev => ({ ...prev, ...fromServer }) as typeof prev);
                }
                // ค่าที่ช่างกรอกไว้เก็บอยู่ใน draft ของเครื่องช่างด้วย แต่คนอื่นที่เปิดใบเดียวกัน
                // (ผู้อนุมัติ / ช่างที่มาแก้ใบโดนตีกลับจากอีกเครื่อง) ไม่มี draft นั้น
                // ต้องอ่านจากตัวเอกสารเสมอ ไม่งั้นเปิดมาเจอช่องว่าง
                if (data.work_start) setWorkStart(String(data.work_start));
                if (data.work_finish) setWorkFinish(String(data.work_finish));
                if (Array.isArray(data.maximo_labor)) setMaximoLabor(data.maximo_labor);
                if (typeof data.maximo_contractor === "string") setMaximoContractor(data.maximo_contractor);
                if (typeof data.summary === "string") setSummary(data.summary);
                if (data.summaryCheck) setSummaryCheck(data.summaryCheck as PF);
                if (typeof data.dust_filter?.changed === "boolean") setDustFilterChanged(data.dust_filter.changed);
                if (data?.measures?.m4) setM4State(data.measures.m4);
                if (data?.measures?.m5) setM5State(data.measures.m5);
                if (data?.measures?.m6) setM6State(data.measures.m6);
                if (data?.measures?.m7) setM7State(data.measures.m7);
                if (data.rows) setRows(prev => { const n = { ...prev }; Object.entries(data.rows).forEach(([k, v]) => { n[k] = v as { pf: PF; remark: string }; }); return n; });
                setDocApiLoaded(true);
            } catch (err) { console.error("load report failed:", err); setDocApiLoaded(true); }
        })();
    }, [editId, stationId, lang]);

    useEffect(() => { if (editId && docApiLoaded) setPageLoading(false); }, [editId, docApiLoaded]);

    useEffect(() => {
        (async () => {
            try {
                const res = await apiFetch(`${API_BASE}/me`);
                if (!res.ok) return;
                const data: Me = await res.json();
                setMe(data);
                // หน้าดูข้อมูลต้องโชว์ผู้ตรวจที่บันทึกในเอกสาร ไม่ใช่คนที่เปิดดู
                if (!reviewMode) setInspector(prev => prev || data.username || "");
            } catch (err) { console.error("fetch /me error:", err); }
        })();
    }, []);

    // ใบที่เปิดจาก edit_id (หน้าดู/แก้ใบเดิม) — เอกสารหลายใบเก็บ job.station_name เป็นค่าว่าง
    // ต้องเติมชื่อสถานีจากข้อมูลสถานี ไม่งั้นช่อง "สถานที่" ว่าง
    useEffect(() => {
        if (!editId || !stationId) return;
        let alive = true;
        getStationInfoPublic(stationId)
            .then(st => { if (alive && st.station_name) setJob(prev => ({ ...prev, station_name: prev.station_name || st.station_name })); })
            .catch(err => console.error("load station info failed:", err));
        return () => { alive = false; };
    }, [editId, stationId]);

    useEffect(() => {
        if (editId || jobId || !stationId || !job.date) return;
        let canceled = false;
        (async () => { try { const p = await fetchPreviewIssueId(stationId, job.date); if (!canceled && p) setJob(prev => ({ ...prev, issue_id: p })); } catch { } })();
        return () => { canceled = true; };
    }, [stationId, job.date, editId, jobId]);

    useEffect(() => {
        if (editId || jobId || !stationId || !job.date) return;
        let canceled = false;
        (async () => { try { const p = await fetchPreviewDocName(stationId, job.date); if (!canceled && p) setDocName(p); } catch { } })();
        return () => { canceled = true; };
    }, [stationId, job.date, editId, jobId]);

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const sid = params.get("station_id") || localStorage.getItem("selected_station_id");
        if (sid) setStationId(sid);
        if (!sid || editId) { setPageLoading(false); return; }
        setJob(prev => { if (prev.date) return prev; return { ...prev, date: new Date().toISOString().slice(0, 10) }; });
        getStationInfoPublic(sid)
            .then(st => setJob(prev => ({ ...prev, station_name: st.station_name ?? prev.station_name })))
            .catch(err => console.error("load station info failed:", err))
            .finally(() => setPageLoading(false));
        getChargerCountByStation(sid).then(count => setChargerCount(count)).catch(err => console.error(err));
    }, [editId]);

    useEffect(() => {
        if (typeof window === "undefined") return;
        const params = new URLSearchParams(window.location.search);
        if (params.has("draft_id")) { params.delete("draft_id"); window.history.replaceState({}, "", `${window.location.pathname}?${params.toString()}`); }
    }, []);

    // โหลด draft ในเครื่อง — ใบใหม่ใช้ draft ของสถานี ใบที่เปิดจาก List ใช้ draft ของใบนั้น
    // ใบที่เปิดจาก List ต้องรอโหลดเอกสารเสร็จก่อน draft ถึงจะทับค่าจาก server ได้ถูกลำดับ
    useEffect(() => {
        if (!stationId) return;
        if (editId && !docApiLoaded) return;
        // โหมดตรวจ/อนุมัติอ่านจากตัวเอกสารอย่างเดียว ไม่เอา draft ในเครื่องมาทับ และไม่ autosave
        if (reviewMode) { setRestoredKey(currentDraftKey); return; }
        let draft = loadDraftLocal<any>(currentDraftKey);
        if (!draft && !editId) {
            draft = loadDraftLocal<any>(legacyNewDraftKey);
            // ย้ายมาอยู่ key ใหม่แล้ว (autosave รอบแรกจะเขียนให้) — ลบแค่ตัว draft ไม่ลบรูปใน IndexedDB
            if (draft) { try { localStorage.removeItem(legacyNewDraftKey); } catch { } }
        }
        if (!draft) { setRestoredKey(currentDraftKey); return; }
        if (typeof draft.workStart === "string" && draft.workStart) setWorkStart(draft.workStart);
        if (typeof draft.workFinish === "string" && draft.workFinish) setWorkFinish(draft.workFinish);
        if (Array.isArray(draft.maximoLabor)) setMaximoLabor(draft.maximoLabor);
        if (typeof draft.maximoContractor === "string") setMaximoContractor(draft.maximoContractor);
        if (draft.rows) setRows(prev => ({ ...prev, ...draft.rows }));
        if (draft.m4) setM4State(prev => ({ ...prev, ...draft.m4 }));
        if (draft.m5) setM5State(prev => ({ ...prev, ...draft.m5 }));
        if (draft.m6) setM6State(prev => ({ ...prev, ...draft.m6 }));
        if (draft.m7) setM7State(prev => ({ ...prev, ...draft.m7 }));
        if (draft.summary) setSummary(draft.summary);
        if (draft.summaryCheck) setSummaryCheck(draft.summaryCheck);
        if (typeof draft.dustFilterChanged === "boolean") setDustFilterChanged(draft.dustFilterChanged);
        if (draft.q4_items) setQ6Items(draft.q4_items.map((it: any, i: number) => ({ ...it, label: getDynamicLabel.breakerMain(i + 1, lang) })));
        if (draft.q6_items) setQ8Items(draft.q6_items.map((it: any, i: number) => ({ ...it, label: getDynamicLabel.breakerCCB(i + 1, lang) })));
        if (draft.charger_count) setChargerCount(draft.charger_count);
        if (draft.photoRefs) {
            let canceled = false;
            const cleanup = () => { canceled = true; };
            (async () => {
                const loadedPhotos: Record<string | number, PhotoItem[]> = {};
                for (const [photoKey, refs] of Object.entries(draft.photoRefs as Record<string, (PhotoRef | { isNA: true })[]>)) {
                    if (canceled) return;
                    if (!refs || refs.length === 0) continue;
                    const items: PhotoItem[] = [];
                    for (const ref of refs) {
                        if (canceled) return;
                        if ('isNA' in ref && ref.isNA) { items.push({ id: `na-${photoKey}`, isNA: true }); }
                        else if ('dbKey' in ref) {
                            const file = await getPhotoByDbKey((ref as PhotoRef).dbKey);
                            if (!file || file.size === 0) {
                                console.warn("Photo missing/empty in IndexedDB:", (ref as PhotoRef).dbKey);
                                reportMissingDraftPhoto(lang);
                                continue;
                            }
                            if (file && !canceled) items.push({
                                id: (ref as PhotoRef).id,
                                file,
                                preview: URL.createObjectURL(file),
                                remark: (ref as PhotoRef).remark,
                                ref: ref as PhotoRef,
                                uploaded: (ref as any).uploaded === true,
                            });
                        }
                    }
                    if (items.length > 0) loadedPhotos[photoKey] = items;
                }
                if (!canceled) setPhotos(prev => mergeDraftPhotos(prev, loadedPhotos) as typeof prev);
            })().finally(() => {
                // เปิด autosave หลังรูปโหลดเสร็จ ไม่งั้น photoRefs ว่างจะไปทับ refs ใน draft
                if (!canceled) setRestoredKey(currentDraftKey);
            });
            return cleanup;
        }
        setRestoredKey(currentDraftKey);
    }, [stationId, currentDraftKey, legacyNewDraftKey, editId, docApiLoaded, reviewMode, lang]);

    // ==================== VALIDATIONS ====================
    // ตอบ N/A แล้วไม่ต้องแนบรูป — เดิมดูจากคำตอบด่าน Pre ตอนนี้ดูจากคำตอบในใบเดียวกัน
    const validPhotoKeys = useMemo(() => {
        const keys: { key: string | number; label: string }[] = [];
        const na = (k: string) => rows[k]?.pf === "NA";
        QUESTIONS.filter(q => q.hasPhoto).forEach(q => {
            if (q.kind === "simple" || q.kind === "measure") { if (na(q.key)) return; keys.push({ key: q.no, label: `${q.no}` }); }
            else if (q.kind === "dynamic_measure") q6Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `6.${idx + 1}` }); });
            else if (q.kind === "charger_measure") q7Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `7.${idx + 1}` }); });
            else if (q.kind === "ccb_measure") q8Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `8.${idx + 1}` }); });
            else if (q.kind === "rcd_measure") q9Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `9.${idx + 1}` }); });
            else if (q.kind === "trip_rcd") q10Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `10.${idx + 1}` }); });
            else if (q.kind === "trip_ccb") q11Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `11.${idx + 1}` }); });
            else if (q.kind === "trip_charger") q12Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `12.${idx + 1}` }); });
            else if (q.kind === "trip_main") q13Items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `13.${idx + 1}` }); });
            else if (q.kind === "power_source" && q.items) q.items.forEach((item, idx) => { if (na(item.key)) return; keys.push({ key: item.key, label: `3.${idx + 1}` }); });
        });
        return keys;
    }, [rows, q6Items, q7Items, q8Items, q9Items, q10Items, q11Items, q12Items, q13Items]);

    const sortLabels = (arr: string[]) => arr.sort((a, b) => { const [aM, aS] = a.split('.').map(Number); const [bM, bS] = b.split('.').map(Number); return aM !== bM ? aM - bM : (aS || 0) - (bS || 0); });

    const missingPhotoItems = useMemo(() => sortLabels(validPhotoKeys.filter(({ key }) => (photos[key]?.length ?? 0) < 1).map(({ label }) => label)), [photos, validPhotoKeys]);
    const allPhotosAttached = missingPhotoItems.length === 0;

    const PF_KEYS_ALL = useMemo(() => {
        const keys: string[] = [];
        QUESTIONS.forEach(q => {
            if (q.kind === "simple" || q.kind === "measure") { if (q.key !== "r1" && q.key !== "r2") keys.push(q.key); }
            else if (q.kind === "dynamic_measure") q6Items.forEach(it => keys.push(it.key));
            else if (q.kind === "charger_measure") q7Items.forEach(it => keys.push(it.key));
            else if (q.kind === "ccb_measure") q8Items.forEach(it => keys.push(it.key));
            else if (q.kind === "rcd_measure") q9Items.forEach(it => keys.push(it.key));
            else if (q.kind === "trip_rcd") q10Items.forEach(it => keys.push(it.key));
            else if (q.kind === "trip_ccb") q11Items.forEach(it => keys.push(it.key));
            else if (q.kind === "trip_charger") q12Items.forEach(it => keys.push(it.key));
            else if (q.kind === "trip_main") q13Items.forEach(it => keys.push(it.key));
            else if (q.kind === "group" && q.items) q.items.forEach(it => keys.push(it.key));
            else if (q.kind === "power_source" && q.items) q.items.forEach(it => keys.push(it.key));
        });
        return keys;
    }, [q6Items, q7Items, q8Items, q9Items, q10Items, q11Items, q12Items, q13Items]);

    const allPFAnswered = useMemo(() => PF_KEYS_ALL.every(k => rows[k]?.pf !== ""), [rows, PF_KEYS_ALL]);
    const missingPFItems = useMemo(() => sortLabels(PF_KEYS_ALL.filter(k => !rows[k]?.pf).map(k => { const m = k.match(/^r(\d+)(?:_(\d+))?$/); return m ? (m[2] ? `${m[1]}.${m[2]}` : m[1]) : k; })), [rows, PF_KEYS_ALL]);


    const allRequiredInputsFilled = true;

    // ค่าที่วัดได้ (แรงดัน / CP ฯลฯ) ไม่บังคับกรอกแล้ว — ช่างเว้นว่างได้ ส่วนรูป/ผลตรวจ/สรุปยังบังคับเหมือนเดิม
    const missingInputsDetailed: React.ComponentProps<typeof PMValidationCard>["missingInputsDetailed"] = [];

    const isSummaryFilled = summary.trim().length > 0;
    const isSummaryCheckFilled = summaryCheck !== "";
    const canFinalSave = allPhotosAttached && allPFAnswered && allRequiredInputsFilled && isSummaryFilled && isSummaryCheckFilled;

    // ==================== DRAFT SAVE ====================
    const photoRefs = useMemo(() => {
        const out: Record<string | number, (PhotoRef | { isNA: true })[]> = {};
        Object.entries(photos).forEach(([k, list]) => {
            out[k] = (list || [])
                .map(p => {
                    if (p.isNA) return { isNA: true } as const;
                    if (!p.ref) return null;
                    return { ...p.ref, uploaded: p.uploaded === true } as PhotoRef & { uploaded: boolean };
                })
                .filter(Boolean) as (PhotoRef | { isNA: true })[];
        });
        return out;
    }, [photos]);

    useDebouncedEffect(() => {
        // ห้ามบันทึกก่อน restore เสร็จ (จะเขียนทับ draft เดิมด้วยฟอร์มว่าง) และไม่บันทึกในโหมดตรวจ
        if (!stationId || reviewMode || restoredKey !== currentDraftKey || draftClearedRef.current) return;
        saveDraftLocal(currentDraftKey, {
            ...(loadDraftLocal<any>(currentDraftKey) ?? {}),
            // เอกสารถูกสร้างไปแล้วแต่ยังอัปรูปไม่จบ — id ต้องอยู่ใน draft ตลอด
            // ไม่งั้น debounce ตัวนี้เขียนทับแล้วกดบันทึกใหม่จะได้ใบใหม่แทนที่จะลงใบเดิม
            ...(reportIdRef.current ? { pendingReportId: reportIdRef.current } : {}),
            rows, m4: m4State, m5: m5State, m6: m6State, m7: m7State,
            summary, summaryCheck, dustFilterChanged, photoRefs,
            q4_items: q6Items, q6_items: q8Items, charger_count: chargerCount,
            workStart, workFinish, maximoLabor, maximoContractor,
        });
    }, [currentDraftKey, stationId, reviewMode, restoredKey, rows, m4State, m5State, m6State, m7State, summary, summaryCheck,
        dustFilterChanged, photoRefs, q6Items, q8Items, chargerCount, workStart, workFinish, maximoLabor, maximoContractor]);

    // ==================== UPLOAD HELPERS ====================
    // key ที่ backend ใช้เก็บใน photos — ต้องใช้สูตรเดียวกันทั้งตอน upload และตอน verify
    const normalizePhotoGroup = (group: string | number) => {
        const k = String(group);
        if (/^\d+$/.test(k)) return `g${k}`;       // "1" -> "g1"
        if (/^r\d+_[a-z0-9]+(?:_[a-z0-9]+)*$/.test(k)) return k; // "r6_1", "r3_power_cb" -> ไม่เติม g (backend รับ r{n}_xxx)
        if (k.startsWith("g")) return k;             // "g1" -> "g1"
        return `g${k}`;
    };

    async function uploadSinglePhoto(reportId: string, stationId: string, group: string, file: File) {
        if (!file || file.size === 0) throw new Error(`Empty file: ${file?.name ?? "unknown"}`);
        const normalizedGroup = normalizePhotoGroup(group);

        const url = `${API_BASE}/mdbpmreport/${reportId}/post/photos`;
        console.log("[upload] reportId:", reportId, "| group:", normalizedGroup);
        const form = new FormData();
        form.append("station_id", stationId);
        form.append("group", normalizedGroup);
        form.append("side", "post");
        form.append("files", file, ensureJpgFilename(file.name));
        const res = await apiFetch(url, { method: "POST", body: form, credentials: "include" });
        if (!res.ok) { const e = await res.text().catch(() => ""); throw new Error(`[${res.status}] ${normalizedGroup}: ${e || res.statusText}`); }
        const resJson = await res.json().catch(() => null);
        if (!resJson) throw new Error(`[upload empty] group ${normalizedGroup}: no response`);
        // group_full = ข้อนี้มีรูปครบ 10 รูปฝั่ง server แล้ว → ถือว่าสำเร็จ ไม่ใช่ error (กัน retry วน + ขึ้น "อัปโหลดไม่สำเร็จ" ทั้งที่รูปครบ)
        if (resJson?.skipped === "group_full") return;
        if (resJson.count === 0 && resJson.skipped === "group_full") return; // เต็มแล้ว = ok
        if (resJson.count === 0) throw new Error(`[upload empty] group ${normalizedGroup}: backend saved 0 files`);
    }

    async function uploadSinglePhotoWithRetry(reportId: string, stationId: string, group: string, file: File, maxRetries = 3): Promise<void> {
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try { await uploadSinglePhoto(reportId, stationId, group, file); return; }
            catch (err: any) {
                if (attempt === maxRetries) throw err;
                await new Promise(r => setTimeout(r, Math.min(1000 * 2 ** (attempt - 1), 8000)));
            }
        }
    }

    // ==================== FLAT ROWS HELPER ====================
    const flattenRows = () => {
        const result: Record<string, { pf: PF; remark: string }> = {};
        const simpleKeys = QUESTIONS.filter(q => q.kind === "simple" || q.kind === "measure").map(q => q.key);
        const dynamicKeys = [...q6Items, ...q7Items, ...q8Items, ...q9Items, ...q10Items, ...q11Items, ...q12Items, ...q13Items].map(i => i.key);
        const validKeys = [...simpleKeys, ...dynamicKeys];
        for (const k of validKeys) {
            result[k] = rows[k] ? { pf: rows[k].pf ?? "", remark: rows[k].remark ?? "" } : { pf: "", remark: "" };
        }
        return result;
    };

    // ==================== SAVE HANDLERS ====================
    const makePhotoSetter = (k: string | number): React.Dispatch<React.SetStateAction<PhotoItem[]>> => (action) => {
        setPhotos(prev => {
            const current = prev[k] ?? [];
            const next = typeof action === "function" ? (action as (x: PhotoItem[]) => PhotoItem[])(current) : action;
            return { ...prev, [k]: next };
        });
    };

    const onFinalSave = async () => {
        if (!stationId) { alert(t("alertNoStation", lang)); return; }
        if (!allPhotosAttached) { alert(t("photoNotComplete", lang)); return; }
        if (!allRequiredInputsFilled) { alert(t("alertFillVoltage", lang)); return; }
        if (!isSummaryFilled || !isSummaryCheckFilled) { alert(t("allNotComplete", lang)); return; }
        if (submitting) return;
        setSubmitting(true);
        try {
            let report_id = reportIdRef.current;
            if (!report_id) {
                const draft = loadDraftLocal<any>(currentDraftKey);
                if (draft?.pendingReportId) { report_id = draft.pendingReportId; reportIdRef.current = report_id; }
            }
            if (!report_id) {
                // ใบใหม่: /submit เป็นตัวสร้างเอกสาร + ออก issue_id/doc_name ให้เอง
                // (เดิมงานนี้อยู่ที่ /pre/submit ซึ่งตัดออกไปพร้อมด่านก่อน PM)
                const { issue_id: issueIdFromJob, ...jobWithoutIssueId } = job;
                const payload = {
                    station_id: stationId, ...(jobId ? { job_id: jobId } : {}), rows: flattenRows(),
                    measures: { m4: m4State, m5: m5State, m6: m6State, m7: m7State },
                    summary, ...(summaryCheck ? { summaryCheck } : {}),
                    dust_filter: dustFilterChanged ? { changed: true } : null,
                    // ส่วนหนึ่งของใบ PM สถานี: ค่าพวกนี้มาจากตอนกด "ปิดใบงาน" ไม่ส่งไปทับ
                    ...(jobId ? {} : {
                        work_start: workStart, work_finish: workFinish, maximo_labor: maximoLabor,
                        maximo_contractor: contractorPicked ? maximoContractor.trim() : "",
                    }),
                    wonum: searchParams.get("wonum") ?? "", side: "post" as const, report_id: editId,
                    job: jobWithoutIssueId, issue_id: issueIdFromJob, doc_name: docName,
                    pm_date: job.date?.trim() || "", inspector,
                    q4_items: q6Items, q6_items: q8Items, charger_count: chargerCount,
                };
                const res = await apiFetch(`${API_BASE}/${PM_PREFIX}/submit`, {
                    method: "POST", headers: { "Content-Type": "application/json" },
                    credentials: "include", body: JSON.stringify(payload)
                });
                if (!res.ok) throw new Error(await res.text());
                const jsonRes = await res.json() as { report_id: string; doc_name?: string; issue_id?: string };
                if (!jsonRes?.report_id) throw new Error(`submit did not return report_id. Response: ${JSON.stringify(jsonRes)}`);
                report_id = jsonRes.report_id;
                if (jsonRes.doc_name) setDocName(jsonRes.doc_name);
                if (jsonRes.issue_id) setJob(prev => ({ ...prev, issue_id: jsonRes.issue_id! }));
                reportIdRef.current = report_id;
                saveDraftLocal(currentDraftKey, {
                    ...loadDraftLocal(currentDraftKey), pendingReportId: report_id,
                    rows, m4: m4State, m5: m5State, m6: m6State, m7: m7State,
                    summary, summaryCheck, dustFilterChanged, photoRefs
                });
            }

            const uploadedIdsPost = new Set<string>();

            const flushPostDraft = () => {
                const latestPhotoRefs: Record<string, any> = {};
                Object.entries(photosRef.current).forEach(([k, list]) => {
                    latestPhotoRefs[k] = (list || []).map(p => {
                        if (p.isNA) return { isNA: true };
                        if (!p.ref) return null;
                        return { ...p.ref, uploaded: p.uploaded === true || uploadedIdsPost.has(p.id) };
                    }).filter(Boolean);
                });
                saveDraftLocal(currentDraftKey, {
                    ...loadDraftLocal(currentDraftKey), pendingReportId: report_id,
                    rows, m4: m4State, m5: m5State, m6: m6State, m7: m7State,
                    summary, summaryCheck, dustFilterChanged, photoRefs: latestPhotoRefs
                });
            };

            // แก้ส่วนที่ส่งแล้ว: รูปเดิมที่กดลบออก ลบออกจากเอกสารจริงก่อน แล้วค่อยอัปรูปใหม่
            if (jobId) {
                await deleteRemovedServerPhotos(apiFetch, {
                    jobId, stationId: stationId ?? "", section: "mdb", reportId: report_id,
                    original: serverPhotosRef.current, current: photosRef.current as any,
                });
                serverPhotosRef.current = {};
            }
            // ⚡ อัปโหลดหลายรอบ — รูปที่มาถึงหลังกดบันทึกต้องถูกจับเข้ารอบถัดไป ไม่ใช่ถูกข้ามแล้วโดนลบ
            const MAX_UPLOAD_PASSES = 3;
            for (let pass = 1; pass <= MAX_UPLOAD_PASSES; pass++) {
                if (unrecoverablePhotos(photosRef.current, uploadedIdsPost).length > 0) {
                    throw new Error(unrecoverableMessage(lang));
                }

                const allPostTasks = collectPending(photosRef.current, uploadedIdsPost);
                if (allPostTasks.length === 0) break;

                const totalPhotos = allPostTasks.length;
                setPreUploadState({ show: true, total: totalPhotos, completed: 0, failed: 0 });
                let completedCount = 0, failedCount = 0;
                const failures: { group: string; error: string }[] = [];
                const CONCURRENCY = 3;
                const finalReportId = report_id!;
                const finalStationId = stationId;

                const tasksByGroup = new Map<string, typeof allPostTasks>();
                for (const task of allPostTasks) {
                    if (!tasksByGroup.has(task.group)) tasksByGroup.set(task.group, []);
                    tasksByGroup.get(task.group)!.push(task);
                }
                const groupEntries = Array.from(tasksByGroup.entries());
                let groupIdx = 0;

                const runNextGroup = async (): Promise<void> => {
                    while (groupIdx < groupEntries.length) {
                        const myIdx = groupIdx++;
                        const [group, tasks] = groupEntries[myIdx];
                        for (const task of tasks) {
                            try {
                                const usable = await resolveUploadFile(task);
                                const compressed = await compressImage(usable);
                                await uploadSinglePhotoWithRetry(finalReportId, finalStationId, task.group, compressed);
                                uploadedIdsPost.add(task.photoId);
                                setPhotos(prev => ({
                                    ...prev,
                                    [group]: (prev[group] || []).map(p =>
                                        p.id === task.photoId ? { ...p, uploaded: true } : p
                                    ),
                                }));
                            } catch (err: any) {
                                failedCount++;
                                failures.push({ group, error: err?.message || "unknown" });
                            }
                            completedCount++;
                            setPreUploadState({ show: true, total: totalPhotos, completed: completedCount, failed: failedCount });
                        }
                    }
                };

                await Promise.all(Array.from({ length: CONCURRENCY }, () => runNextGroup()));
                setPreUploadState({ show: false, total: 0, completed: 0, failed: 0 });

                if (failures.length > 0) {
                    flushPostDraft();
                    const details = failures.map(f => `${t("uploadFailedItem", lang)} ${f.group}: ${f.error}`).join("\n");
                    alert(
                        `${lang === "th" ? "อัปโหลดรูปไม่สำเร็จ" : "Photo upload failed"} ${failures.length}\n\n`
                        + `${lang === "th" ? "รูปในเครื่องยังอยู่ครบ กดบันทึกอีกครั้งเพื่ออัปเฉพาะรูปที่ค้าง" : "Your photos are still saved on this device. Click save again to retry only the failed photos"}\n\n${details}`
                    );
                    return;
                }
            }

            // ยังมีรูปค้างหลังครบทุกรอบ → หยุดไว้ ห้ามลบ ห้าม finalize
            const stillPendingPost = collectPending(photosRef.current, uploadedIdsPost);
            if (stillPendingPost.length > 0) {
                flushPostDraft();
                alert(pendingMessage(stillPendingPost.length, lang));
                return;
            }

            // ⚡ ยืนยันจำนวนรูป Post-PM กับ server ก่อน finalize + ล้าง draft
            const expectedPost = expectedCountByGroup(photosRef.current, normalizePhotoGroup);
            if (Object.keys(expectedPost).length > 0) {
                const verifyRes = await apiFetch(`${API_BASE}/${PM_PREFIX}/get?station_id=${encodeURIComponent(stationId)}&report_id=${report_id}`, { credentials: "include" });
                if (!verifyRes.ok) throw new Error(await verifyRes.text());
                const verifyDoc = await verifyRes.json() as { photos?: Record<string, unknown[]> };
                const shortfall = findShortfall(expectedPost, verifyDoc?.photos);
                if (shortfall.length > 0) {
                    console.error("[Post-PM verify] shortfall:", shortfall);
                    flushPostDraft();
                    alert(shortfallMessage(shortfall, lang));
                    return;
                }
            }

            if (!jobId && (!workStart || !workFinish)) { alert(t("alertWorkTime", lang)); setSubmitting(false); return; }
            if (!jobId && contractorMissing) { alert(t("contractorRequired", lang)); setSubmitting(false); return; }
            if (!jobId && workFinish < workStart) { alert(t("alertWorkTimeOrder", lang)); setSubmitting(false); return; }
            // Maximo ตีกลับ IN09 ด้วย BMXAA2641E ถ้าเวลาทำงานยังมาไม่ถึง
            // ปล่อยผ่านตรงนี้ = ปิดใบงานได้แต่ปิด WO ในระบบเขาไม่ได้ ต้องมาแก้ย้อนหลัง
            const nowLocal = nowLocalDatetime();
            if (!jobId && (workStart > nowLocal || workFinish > nowLocal)) { alert(t("alertWorkTimeFuture", lang)); setSubmitting(false); return; }

            const finalizeRes = await apiFetch(`${API_BASE}/${PM_PREFIX}/${report_id}/finalize`, {
                method: "POST", credentials: "include",
                body: new URLSearchParams({ station_id: stationId })
            });
            if (!finalizeRes.ok) throw new Error(await finalizeRes.text());
            reportIdRef.current = null;
            // ใช้ photosRef เพื่ออ่านสถานะล่าสุด — closure ของ handler ถือ photos ค่าเก่าไว้
            // ทำให้รูปที่เพิ่ม/อัปเดตหลัง render ล่าสุด ไม่ถูกลบ กลายเป็นขยะค้างใน IndexedDB
            const allPhotos = Object.values(photosRef.current).flat();
            Promise.all(allPhotos.map(p => delPhoto(currentDraftKey, p.id))).catch(() => { });
            draftClearedRef.current = true; // กัน autosave ที่ค้างอยู่เขียน draft กลับมาหลังล้าง
            clearDraftLocal(currentDraftKey);
            // กลับหน้าที่เปิดเข้ามา (หน้ารวมของใบ PM สถานี / PM List) — ไม่มีก็ไปตารางใบ PM ของสถานี
            const returnTo = pmFormReturnRoute(searchParams);
            if (returnTo) { router.replace(returnTo); return; }
            const listParams = new URLSearchParams();
            listParams.set("station_id", stationId);
            const viewParam = searchParams.get("view");
            if (viewParam) listParams.set("view", viewParam);
            router.replace(`${pathname}?${listParams.toString()}`);
        } catch (err: any) { alert(`${t("alertSaveFailed", lang)} ${err?.message ?? err}`); }
        finally { setSubmitting(false); }
    };

    // ==================== RENDER HELPERS ====================
    const patchM4 = (itemKey: string, fieldKey: string, value: Partial<MeasureRow<UnitVoltage>>) => setM4State(prev => ({ ...prev, [itemKey]: { ...(prev[itemKey] || initMeasureState(VOLTAGE_FIELDS, "V")), [fieldKey]: { ...(prev[itemKey]?.[fieldKey] || { value: "", unit: "V" }), ...value } } }));
    const patchM5 = (itemKey: string, fieldKey: string, value: Partial<MeasureRow<UnitVoltage>>) => setM5State(prev => ({ ...prev, [itemKey]: { ...(prev[itemKey] || initMeasureState(VOLTAGE_FIELDS, "V")), [fieldKey]: { ...(prev[itemKey]?.[fieldKey] || { value: "", unit: "V" }), ...value } } }));
    const patchM6 = (itemKey: string, fieldKey: string, value: Partial<MeasureRow<UnitVoltage>>) => setM6State(prev => ({ ...prev, [itemKey]: { ...(prev[itemKey] || initMeasureState(VOLTAGE_FIELDS_CCB, "V")), [fieldKey]: { ...(prev[itemKey]?.[fieldKey] || { value: "", unit: "V" }), ...value } } }));
    const patchM7 = (itemKey: string, fieldKey: string, value: Partial<MeasureRow<UnitVoltage>>) => setM7State(prev => ({ ...prev, [itemKey]: { ...(prev[itemKey] || initMeasureState(VOLTAGE_FIELDS_CCB, "V")), [fieldKey]: { ...(prev[itemKey]?.[fieldKey] || { value: "", unit: "V" }), ...value } } }));

    const renderDynamicMeasureGrid = (qNo: number, itemKey: string) => {
        type PF_State = Record<string, MeasureState<UnitVoltage>>;
        type PF_Patch = (itemKey: string, fieldKey: string, value: Partial<MeasureRow<UnitVoltage>>) => void;
        // m4..m7 = ชื่อ bucket ใน measures ของ DB (ไม่ผูกกับเลขข้อ) — ข้อ 6-9 ของฟอร์ม
        const configs: Record<number, { state: PF_State; patchFn: PF_Patch; fields: readonly string[] }> = {
            6: { state: m4State, patchFn: patchM4, fields: VOLTAGE_FIELDS },
            7: { state: m5State, patchFn: patchM5, fields: VOLTAGE_FIELDS },
            8: { state: m6State, patchFn: patchM6, fields: VOLTAGE_FIELDS_CCB },
            9: { state: m7State, patchFn: patchM7, fields: VOLTAGE_FIELDS_CCB },
        };
        const cfg = configs[qNo];
        if (!cfg) return null;
        return (
            <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-2 md:tw-grid-cols-5 tw-gap-3">
                {cfg.fields.map(k => (<InputWithUnit<UnitVoltage> key={`${qNo}-${itemKey}-${k}`} label={LABELS[k] ?? k} value={cfg.state[itemKey]?.[k]?.value || ""} unit={(cfg.state[itemKey]?.[k]?.unit as UnitVoltage) || "V"} units={UNITS.voltage} onValueChange={v => cfg.patchFn(itemKey, k, { value: v })} onUnitChange={u => cfg.patchFn(itemKey, k, { unit: u })} />))}
            </div>
        );
    };

    const renderQuestionBlock = (q: Question) => {
        const qTooltip = q.tooltip?.[lang];
        const sectionId = `${ID_PREFIX}-question-${q.no}`;

        const checkboxElement = q.no === 15 ? (
            <label className="tw-flex tw-items-center tw-gap-2 tw-text-xs sm:tw-text-sm tw-text-blue-gray-700 tw-py-2">
                <input type="checkbox" className="tw-h-4 tw-w-4 tw-rounded tw-border-blue-gray-300" checked={dustFilterChanged} onChange={e => setDustFilterChanged(e.target.checked)} />
                <span>{t("dustFilterChanged", lang)}</span>
            </label>
        ) : null;

        const measureMap: Record<string, { items: typeof q6Items; qNo: number; countLabel: string; count: number; countUnit: string }> = {
            dynamic_measure: { items: q6Items, qNo: 6, countLabel: t("breakerMainCount", lang), count: q6Items.length, countUnit: t("unit", lang) },
            charger_measure: { items: q7Items, qNo: 7, countLabel: t("chargerCountLabel", lang), count: chargerCount, countUnit: t("chargerUnit", lang) },
            ccb_measure: { items: q8Items, qNo: 8, countLabel: t("breakerCCBCount", lang), count: q8Items.length, countUnit: t("breakerCCBMax", lang) },
            rcd_measure: { items: q9Items, qNo: 9, countLabel: t("rcdCount", lang), count: chargerCount, countUnit: t("unit", lang) },
        };

        if (q.kind === "power_source" && q.items) {
            return (
                <SectionCard key={q.key} id={sectionId} title={q.label[lang]} tooltip={qTooltip}>
                    <div className="tw-divide-y tw-divide-gray-200">
                        {q.items.map((item, idx) => (
                            <div key={item.key} className="tw-py-4 first:tw-pt-2">
                                <PassFailRow label={item.label[lang]} value={rows[item.key]?.pf ?? ""} lang={lang}
                                    onChange={v => setRows({ ...rows, [item.key]: { ...(rows[item.key] ?? { remark: "" }), pf: v } })}
                                    remark={rows[item.key]?.remark ?? ""}
                                    onRemarkChange={v => setRows({ ...rows, [item.key]: { ...(rows[item.key] ?? { pf: "" }), remark: v } })}
                                    pfButtonsId={getPfIdFromKey(item.key)} remarkId={getRemarkIdFromKey(item.key)}
                                    aboveRemark={<div className="tw-pb-4 tw-border-b tw-border-gray-100"><PhotoMultiInput photos={photos[item.key] || []} setPhotos={makePhotoSetter(item.key)} max={10} draftKey={currentDraftKey} qNo={q.no} lang={lang} id={getPhotoIdFromKey(item.key)} /></div>}
                                />
                            </div>
                        ))}
                    </div>
                </SectionCard>
            );
        }

        if (measureMap[q.kind]) {
            const cfg = measureMap[q.kind];
            // จำนวน Breaker Main / Breaker CCB ช่างปรับเองได้ตามตู้จริง (เดิมอยู่ในด่านก่อน PM)
            const onAdd = q.kind === "dynamic_measure" ? addQ6Item : q.kind === "ccb_measure" ? addQ8Item : null;
            const addDisabled = q.kind === "ccb_measure" && q8Items.length >= 4;
            const addLabel = q.kind === "dynamic_measure" ? t("addBreakerMain", lang) : t("addBreakerCCB", lang);
            const onRemove = q.kind === "dynamic_measure" ? removeQ6Item : q.kind === "ccb_measure" ? removeQ8Item : null;
            return (
                <SectionCard key={q.key} id={sectionId} title={q.label[lang]} tooltip={qTooltip}>
                    <div className="tw-space-y-0">
                        <div className="tw-flex tw-items-center tw-justify-between tw-pb-3 tw-border-b tw-border-gray-200">
                            <div className="tw-flex tw-items-center tw-gap-2">
                                <Typography variant="small" className="tw-text-blue-gray-600">{cfg.countLabel}</Typography>
                                <Typography variant="small" className="tw-font-bold tw-text-blue-600">{cfg.count} {cfg.countUnit}</Typography>
                            </div>
                            {onAdd && (
                                <Button size="sm" color="gray" variant="outlined" onClick={onAdd} disabled={addDisabled} className="tw-flex tw-items-center tw-gap-1">
                                    <span className="tw-text-lg tw-leading-none">+</span><span className="tw-text-xs">{addLabel}</span>
                                </Button>
                            )}
                        </div>
                        <div className="tw-divide-y tw-divide-gray-200">
                            {cfg.items.map((item, idx) => (
                                <div key={item.key} className="tw-py-4 first:tw-pt-2">
                                    <PassFailRow label={item.label} value={rows[item.key]?.pf ?? ""} lang={lang}
                                        onChange={v => setRows({ ...rows, [item.key]: { ...(rows[item.key] ?? { remark: "" }), pf: v } })}
                                        remark={rows[item.key]?.remark ?? ""}
                                        onRemarkChange={v => setRows({ ...rows, [item.key]: { ...(rows[item.key] ?? { pf: "" }), remark: v } })}
                                        pfButtonsId={getPfIdFromKey(item.key)} remarkId={getRemarkIdFromKey(item.key)}
                                        inlineLeft={onRemove && cfg.items.length > 1 ? (
                                            <button type="button" onClick={() => onRemove(idx)} className="tw-h-6 tw-w-6 tw-flex tw-items-center tw-justify-center tw-rounded tw-bg-red-50 tw-text-red-600 hover:tw-bg-red-100">
                                                <svg className="tw-w-3.5 tw-h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
                                            </button>
                                        ) : undefined}
                                        aboveRemark={<div className="tw-pb-4 tw-border-b tw-border-gray-100"><PhotoMultiInput photos={photos[item.key] || []} setPhotos={makePhotoSetter(item.key)} max={10} draftKey={currentDraftKey} qNo={q.no} lang={lang} id={getPhotoIdFromKey(item.key)} /></div>}
                                        beforeRemark={<div id={getInputIdFromKey(item.key)} className={`tw-mb-3 tw-transition-all tw-duration-300 ${rows[item.key]?.pf === "NA" ? "tw-opacity-50 tw-pointer-events-none" : ""}`}>{renderDynamicMeasureGrid(cfg.qNo, item.key)}</div>}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                </SectionCard>
            );
        }

        const tripMap: Record<string, { items: typeof q10Items; countLabel: string; count: number; countUnit: string }> = {
            trip_rcd: { items: q10Items, countLabel: t("rcdCount", lang), count: chargerCount, countUnit: t("unit", lang) },
            trip_ccb: { items: q11Items, countLabel: t("breakerCCBCount", lang), count: q8Items.length, countUnit: t("unit", lang) },
            trip_charger: { items: q12Items, countLabel: t("breakerChargerCount", lang), count: chargerCount, countUnit: t("unit", lang) },
            trip_main: { items: q13Items, countLabel: t("breakerMainCount", lang), count: q6Items.length, countUnit: t("unit", lang) },
        };
        if (tripMap[q.kind]) {
            const cfg = tripMap[q.kind];
            return (
                <SectionCard key={q.key} id={sectionId} title={q.label[lang]} tooltip={qTooltip}>
                    <div className="tw-space-y-0">
                        <div className="tw-flex tw-items-center tw-pb-3 tw-border-b tw-border-gray-200">
                            <div className="tw-flex tw-items-center tw-gap-2">
                                <Typography variant="small" className="tw-text-blue-gray-600">{cfg.countLabel}</Typography>
                                <Typography variant="small" className="tw-font-bold tw-text-blue-600">{cfg.count} {cfg.countUnit}</Typography>
                            </div>
                        </div>
                        <div className="tw-divide-y tw-divide-gray-200">
                            {cfg.items.map((it) => (
                                <div key={it.key} className="tw-py-4 first:tw-pt-2">
                                    <PassFailRow label={it.label} value={rows[it.key]?.pf ?? ""} lang={lang}
                                        onChange={v => setRows({ ...rows, [it.key]: { ...(rows[it.key] ?? { remark: "" }), pf: v } })}
                                        remark={rows[it.key]?.remark ?? ""}
                                        onRemarkChange={v => setRows({ ...rows, [it.key]: { ...(rows[it.key] ?? { pf: "" }), remark: v } })}
                                        pfButtonsId={getPfIdFromKey(it.key)} remarkId={getRemarkIdFromKey(it.key)}
                                        aboveRemark={<div className="tw-pb-4 tw-border-b tw-border-gray-100"><PhotoMultiInput photos={photos[it.key] || []} setPhotos={makePhotoSetter(it.key)} max={10} draftKey={currentDraftKey} qNo={q.no} lang={lang} id={getPhotoIdFromKey(it.key)} /></div>}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                </SectionCard>
            );
        }

        // ข้อธรรมดา (มีรูป + ระดับผลการตรวจ/N-A + หมายเหตุ)
        return (
            <SectionCard key={q.key} id={sectionId} title={q.label[lang]} tooltip={qTooltip}>
                <div className="tw-py-2">
                    <PassFailRow label={t("testResult", lang)} value={rows[q.key]?.pf ?? ""} lang={lang}
                        onChange={v => setRows({ ...rows, [q.key]: { ...(rows[q.key] ?? { remark: "" }), pf: v } })}
                        remark={rows[q.key]?.remark ?? ""}
                        onRemarkChange={v => setRows({ ...rows, [q.key]: { ...(rows[q.key] ?? { pf: "" }), remark: v } })}
                        showPfButtons={q.key !== "r1" && q.key !== "r2"} pfButtonsId={getPfIdFromKey(q.key)} remarkId={getRemarkIdFromKey(q.key)}
                        aboveRemark={<>{q.hasPhoto && <div className="tw-pt-2 tw-pb-4 tw-border-b tw-mb-4 tw-border-gray-100"><PhotoMultiInput photos={photos[q.no] || []} setPhotos={makePhotoSetter(q.no)} max={10} draftKey={currentDraftKey} qNo={q.no} lang={lang} id={getPhotoIdFromKey(q.no)} /></div>}{checkboxElement && <div className="sm:tw-hidden tw-mb-3">{checkboxElement}</div>}</>}
                        inlineLeft={checkboxElement && <div className="tw-hidden sm:tw-flex">{checkboxElement}</div>}
                    />
                </div>
            </SectionCard>
        );
    };

    // ==================== RENDER ====================

    // ── ตารางผลการตรวจ PM (โหมดตรวจอนุมัติ) ──
    // ใช้ state ที่โหลดเอกสารมาแล้ว (rows = ผลการตรวจ)
    // คีย์ที่ไม่ได้อยู่ใน QUESTIONS (ข้อย่อยแบบ r5_1) เอามาต่อท้ายด้วย จะได้ไม่ตกหล่น
    // คีย์รูปของ mdb: ข้อหลักแปลงเป็น g{n} ส่วนข้อย่อยเก็บด้วยคีย์คำตอบตรงๆ
    // (normalizeGroup ปล่อย r{n}_{i} ผ่านโดยไม่เติม g)
    const photoKeysOf = useCallback((row: { key: string }) => {
        if (/^r\d+_[a-z0-9]+(?:_[a-z0-9]+)*$/.test(row.key)) return [row.key, row.key.replace(/^r/, "g")];
        return [`g${row.key.replace(/^r/, "")}`];
    }, []);

    const compareRows = useMemo(() => {
        // ป้ายหัวข้อต้องตรงกับที่ช่างเห็นตอนกรอก — ข้อย่อยอย่าง r3_1 ฟอร์มสร้างขึ้นมาเอง
        // ตอนรันไทม์ (ตามจำนวนหัวชาร์จ/ช่องของสถานีนั้น) ไม่ได้อยู่ใน QUESTIONS
        // ถ้าไม่ไล่เก็บจากแหล่งเดียวกับที่ฟอร์มใช้ ตารางจะโชว์เป็นคีย์ดิบ
        const textOf = (l: any): string =>
            typeof l === "string" ? l
                : l && typeof l === "object" ? (l[lang] ?? l.th ?? l.en ?? "") : "";
        const labels = new Map<string, string>();
        const put = (k: any, v: any) => {
            const text = textOf(v);
            if (typeof k === "string" && text.trim() && !labels.has(k)) labels.set(k, text.trim());
        };
        const labelOfItem = (it: any) =>
            it?.label !== undefined ? it.label : it?.labelKey ? (t as any)(it.labelKey, lang) : "";
        (QUESTIONS as any[]).forEach((q: any) => {
            put(q?.key, labelOfItem(q));
            (q?.items ?? []).forEach((it: any) => put(it?.key, labelOfItem(it)));
        });
        ([q6Items, q7Items, q8Items, q9Items, q10Items, q11Items, q12Items, q13Items] as any[]).forEach((arr: any) =>
            (arr ?? []).forEach((it: any) => put(it?.key, labelOfItem(it))));
        // ใบรุ่นเก่า: คีย์ r1..r13 คือหัวข้อชุดเดิม ห้ามหยิบป้ายจาก QUESTIONS ปัจจุบัน
        const labelOf = (key: string) =>
            (legacyDoc ? LEGACY_ROW_LABELS[key]?.[lang] : undefined) ?? labels.get(key) ?? key;
        // เรียงตามลำดับข้อในฟอร์มกรอก ข้อย่อยที่ช่างเพิ่มเอง (r5_1, r5_2)
        // ต้องต่อท้ายข้อแม่ของมัน ไม่ใช่ไปกองรวมกันท้ายตาราง
        const answered = Object.keys(rows ?? {});
        const subNo = (k: string) => Number(k.split("_")[1] ?? 0) || 0;
        const mk = (k: string, section: string, label: string, qNo?: number) => ({
            key: k,
            section,
            qNo,
            label,
            pf: (rows as any)?.[k]?.pf,
            remark: (rows as any)?.[k]?.remark,
        });
        // วางโครงเดียวกับฟอร์มกรอก: หัวข้อใหญ่เป็นแถบคั่น แล้วข้อย่อยเรียงอยู่ใต้มัน
        // ข้อธรรมดาที่ไม่มีข้อย่อย ตัวมันเองคือเนื้อในของแถบ ช่องหัวข้อจึงเว้นว่าง
        const out: ReturnType<typeof mk>[] = [];
        (QUESTIONS as any[]).forEach((q: any) => {
            if (!q?.key) return;
            const section = labelOf(q.key);
            // เลขข้อ — ใช้รวมรูปของทั้งข้อในตารางผลการตรวจ แบบเดียวกับที่ PDF ทำ
            const qNo: number | undefined = typeof q?.no === "number" ? q.no
                : Number(String(q?.key ?? "").replace(/^r/, "")) || undefined;
            out.push(mk(q.key, section, "", qNo));
            answered
                .filter((k) => k !== q.key && k.split("_")[0] === q.key)
                .sort((a, b) => subNo(a) - subNo(b))
                .forEach((k) => out.push(mk(k, section, labelOf(k), qNo)));
        });
        answered.forEach((k) => {
            if (out.some((r) => r.key === k)) return;
            out.push(mk(k, "", labelOf(k), Number(k.replace(/^r/, "").split("_")[0]) || undefined));
        });
        return out;
    }, [rows, lang, legacyDoc, q6Items, q7Items, q8Items, q9Items, q10Items, q11Items, q12Items, q13Items]);


    // กล่องหมายเหตุ + สรุปผลการตรวจสอบ — ประกาศครั้งเดียว วางได้สองที่
    // ตอนกรอกอยู่ในฟอร์มตามเดิม ตอนตรวจย้ายลงไปล่างสุดใต้ตารางผลการตรวจ
    const summaryBlock = (
                        <div id="mdb-pm-summary-section" className="tw-mt-6 sm:tw-mt-8 tw-space-y-3 tw-transition-all tw-duration-300">
                            <Typography variant="h6" className="tw-mb-1 tw-text-sm sm:tw-text-base">{t("comment", lang)}</Typography>

                            <Textarea
                                label={t("comment", lang)}
                                value={summary}
                                onChange={e => setSummary(e.target.value)}
                                rows={3}
                                required
                                autoComplete="off"
                                containerProps={{ className: "!tw-min-w-0" }}
                                className="!tw-w-full !tw-text-sm resize-none"
                            />
                            <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-200">
                                <PassFailRow
                                    label={t("summaryResult", lang)}
                                    value={summaryCheck}
                                    onChange={v => setSummaryCheck(v)}
                                    lang={lang}
                                    labels={{
                                        PASS: t("summaryPassLabel", lang),
                                        FAIL: t("summaryFailLabel", lang),
                                        NA: t("summaryNALabel", lang)
                                    }}
                                />
                            </div>
                        </div>
    );

    return (
        <section className="tw-pb-24">
            <LoadingOverlay show={pageLoading} text={t("loading", lang)} />
            <LoadingOverlay
                show={preUploadState.show}
                text={lang === "th"
                    ? `กำลังอัปโหลดรูป... ${preUploadState.completed}/${preUploadState.total} รูป`
                    : `Uploading photos... ${preUploadState.completed}/${preUploadState.total}`}
            />
            <div className="tw-mx-auto tw-max-w-6xl tw-flex tw-items-center tw-justify-between tw-mb-4">
                <Button variant="outlined" size="sm" onClick={goBackToList} title={t("backToList", lang)}>
                    <ArrowLeftIcon className="tw-w-4 tw-h-4 tw-stroke-blue-gray-900 tw-stroke-2" />
                </Button>
            </div>

            
            <form action="#" noValidate onSubmit={e => { e.preventDefault(); return false; }} onKeyDown={e => { if (e.key === "Enter") e.preventDefault(); }}>
                <div className="tw-mx-auto tw-max-w-6xl tw-bg-white tw-border tw-border-blue-gray-100 tw-rounded-xl tw-shadow-sm tw-p-6 md:tw-p-8 tw-print:tw-shadow-none tw-print:tw-border-0">
                {/* ดูอย่างเดียว: fieldset ปิดช่องกรอกทั้งหมด — แถวปุ่มบันทึก/แก้ไขอยู่นอก fieldset ปุ่มแก้ไขจะได้กดได้ */}
                <fieldset disabled={reviewMode || legacyDoc} className="pm-readonly tw-m-0 tw-min-w-0 tw-border-0 tw-p-0">
                    <div className="tw-flex tw-flex-col tw-gap-4 md:tw-flex-row md:tw-items-start md:tw-justify-between md:tw-gap-6">
                        <div className="tw-flex tw-items-start tw-gap-3 md:tw-gap-4">
                            <div className="tw-relative tw-overflow-hidden tw-bg-white tw-rounded-md tw-shrink-0 tw-h-14 tw-w-[64px] sm:tw-h-16 sm:tw-w-[76px] md:tw-h-20 md:tw-w-[108px] lg:tw-h-24 lg:tw-w-[152px]">
                                <Image src={LOGO_SRC} alt={t("logoAlt", lang)} fill priority className="tw-object-contain tw-p-0" sizes="(min-width:1024px) 152px, (min-width:768px) 108px, (min-width:640px) 76px, 64px" />
                            </div>
                            <div className="tw-min-w-0">
                                <div className="tw-font-semibold tw-text-blue-gray-900 tw-text-sm sm:tw-text-base">{t("pageTitle", lang)}</div>
                                <div className="tw-text-xs sm:tw-text-sm tw-text-blue-gray-600">
                                    {t("companyName", lang)}<br />
                                    {t("companyAddress", lang)}<br />
                                    {t("callCenter", lang)}
                                </div>
                            </div>
                        </div>
                        <div className="tw-text-left md:tw-text-right tw-text-sm tw-text-blue-gray-700 tw-border-t tw-border-blue-gray-100 tw-pt-3 md:tw-border-t-0 md:tw-pt-0 md:tw-shrink-0">
                            <div className="tw-font-semibold">{t("docName", lang)}</div>
                            <div className="tw-break-all">{jobDocIds?.doc_name || docName || "-"}</div>
                        </div>
                    </div>

                    <div className="tw-mt-6 tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-4 tw-gap-3 sm:tw-gap-4">
                        <Input label={t("issueId", lang)} value={jobDocIds?.issue_id || job.issue_id || "-"} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full !tw-bg-blue-gray-50 !tw-text-sm" />
                        <Input label={t("location", lang)} value={job.station_name} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50 !tw-text-sm" />
                        <Input label={t("pmDate", lang)} type="text" value={job.date} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50 !tw-text-sm" />
                        <Input label={t("inspector", lang)} value={inspector} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50 !tw-text-sm" />
                    </div>

                    <div className="tw-mt-6 sm:tw-mt-8 tw-space-y-4 sm:tw-space-y-6">
                        {/* ใบรุ่นเก่าเลขข้อไม่ตรงกับ QUESTIONS ชุดนี้ ต้องอ่านจากตารางด้านล่างแทน
                            ใบรุ่นปัจจุบันแสดงรายการข้อตรงนี้เสมอ โหมดตรวจก็อ่านจากตรงนี้ (fieldset ปิดการแก้ไว้) */}
                        {legacyDoc ? (
                            <div className="tw-rounded-xl tw-border tw-border-amber-200 tw-bg-amber-50 tw-px-5 tw-py-4">
                                <Typography className="tw-font-semibold tw-text-amber-800 tw-text-sm">{t("legacyFormTitle", lang)}</Typography>
                                <Typography variant="small" className="tw-text-amber-700 tw-mt-1">{t("legacyFormHint", lang)}</Typography>
                            </div>
                        ) : QUESTIONS.map(q => renderQuestionBlock(q))}
                    </div>

                    {/* ใบรุ่นเก่า: ย้ายไปไว้ล่างสุด ให้อ่านหลังดูตารางสรุปเสร็จ */}
                    {!legacyDoc && summaryBlock}

                    <div className="tw-mt-6 sm:tw-mt-8 tw-flex tw-flex-col tw-gap-3">
                    {/* ใบที่เป็นส่วนหนึ่งของใบ PM สถานี: เวลาทำงาน/ช่างที่ลงเวลา Maximo กรอกครั้งเดียวตอนกด
                        "ปิดใบงาน" ที่หน้ารวมของใบ — ไม่ต้องกรอกซ้ำทุกส่วน (ใบเดี่ยวรุ่นเก่ายังกรอกที่นี่) */}
                    {!jobId && (<>
                    {/* เวลาทำงานจริงของช่าง — ต้องกรอกก่อนส่งปิดใบงาน (ส่งเข้า Maximo IN09) */}
                    <div className="tw-mt-6 tw-pt-4 tw-border-t tw-border-gray-200">
                        <div className="tw-mb-2">
                            <Typography variant="h6" className="tw-text-sm sm:tw-text-base">
                                {t("workTime", lang)} <span className="tw-text-red-500">*</span>
                            </Typography>
                            <Typography variant="small" className="tw-text-xs tw-font-normal tw-text-blue-gray-400">
                                {t("workTimeHint", lang)}
                            </Typography>
                        </div>
                        <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-3">
                            <div>
                                <label className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">{t("workStart", lang)}</label>
                                <input type="datetime-local" value={workStart} disabled={reviewMode} onChange={(e) => setWorkStart(e.target.value)}
                                    className="tw-w-full tw-rounded-lg tw-border tw-border-blue-gray-200 tw-bg-white tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none focus:tw-border-blue-500" />
                            </div>
                            <div>
                                <label className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">{t("workFinish", lang)}</label>
                                {/* min กัน picker เลือกย้อนหลัง — ยังต้อง validate เพราะพิมพ์มือเลี่ยงได้ */}
                                <input type="datetime-local" value={workFinish} disabled={reviewMode} min={workStart || undefined} onChange={(e) => setWorkFinish(e.target.value)}
                                    className={`tw-w-full tw-rounded-lg tw-border tw-bg-white tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none ${workStart && workFinish && workFinish < workStart ? "tw-border-red-400 focus:tw-border-red-500" : "tw-border-blue-gray-200 focus:tw-border-blue-500"}`} />
                                {workStart && workFinish && workFinish < workStart && (
                                    <p className="tw-mt-1.5 tw-text-xs tw-text-red-600">{t("alertWorkTimeOrder", lang)}</p>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* ช่างที่จะลงเวลาเข้า Maximo — laborcode คนละชุดกับ username ใน iMPS
                        จึงต้องให้เลือกเอง ไม่งั้น IN09 จะ unmapped ทั้งใบ (อยู่ล่างสุดของฟอร์ม) */}
                    <div className="tw-mt-6 tw-pt-4 tw-border-t tw-border-gray-200">
                        <div className="tw-mb-2">
                            <Typography variant="h6" className="tw-text-sm sm:tw-text-base">{t("maximoLabor", lang)}</Typography>
                            <Typography variant="small" className="tw-text-xs tw-font-normal tw-text-blue-gray-400">
                                {t("maximoLaborHint", lang)}
                            </Typography>
                        </div>
                        {laborList.length === 0 ? (
                            <p className="tw-text-xs tw-text-orange-600">
                                            {reviewMode ? t("maximoLaborNone", lang) : t("maximoLaborEmpty", lang)}
                                        </p>
                        ) : (
                            <div className="tw-rounded-lg tw-border tw-border-blue-gray-200 tw-bg-white tw-divide-y tw-divide-blue-gray-50 tw-max-h-56 tw-overflow-y-auto">
                                {laborList.map((o) => (
                                    <label key={o.laborcode} className="tw-flex tw-items-center tw-gap-2.5 tw-px-3 tw-py-2.5 tw-cursor-pointer hover:tw-bg-blue-gray-50/60 tw-transition-colors">
                                        {!reviewMode && (<input type="checkbox" checked={maximoLabor.includes(o.laborcode)}
                                            onChange={() => toggleMaximoLabor(o.laborcode)}
                                            className="tw-h-4 tw-w-4 tw-shrink-0 tw-rounded tw-border-blue-gray-300 tw-text-blue-600 focus:tw-ring-blue-500 tw-cursor-pointer" />)}
                                        <span className="tw-min-w-0 tw-truncate tw-text-sm tw-text-blue-gray-800">{o.name}</span>
                                        <span className="tw-ml-auto tw-font-mono tw-text-xs tw-text-blue-gray-400">{o.laborcode}</span>
                                    </label>
                                ))}
                            </div>
                        )}
                        {(contractorPicked || (reviewMode && !!maximoContractor.trim())) && (
                            <div className="tw-mt-3 tw-space-y-1.5">
                                <label className="tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">
                                    {t("contractorName", lang)} <span className="tw-text-red-500">*</span>
                                </label>
                                <input type="text" value={maximoContractor} onChange={(e) => setMaximoContractor(e.target.value)}
                                    placeholder={t("contractorPlaceholder", lang)}
                                    className={`tw-w-full tw-rounded-lg tw-border tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none ${contractorMissing ? "tw-border-red-400 focus:tw-border-red-500" : "tw-border-blue-gray-200 focus:tw-border-blue-500"}`} />
                                {contractorMissing && <p className="tw-text-xs tw-text-red-600">{t("contractorRequired", lang)}</p>}
                            </div>
                        )}
                    </div>
                    </>)}

                        {/* โหมดตรวจไม่ต้องมี ฟอร์มฝั่งช่างดักความครบถ้วนไว้ตั้งแต่ตอนกรอกแล้ว */}
                        {!reviewMode && !legacyDoc && (
                            <PMValidationCard
                                lang={lang}
                                allPhotosAttached={allPhotosAttached} missingPhotoItems={missingPhotoItems}
                                allRequiredInputsFilled={allRequiredInputsFilled} missingInputsDetailed={missingInputsDetailed}
                                allPFAnswered={allPFAnswered} missingPFItems={missingPFItems}
                                isSummaryFilled={isSummaryFilled} isSummaryCheckFilled={isSummaryCheckFilled}
                            />
                        )}
                    </div>
                </fieldset>
                    {/* หน้าดูข้อมูล: ปุ่มแก้ไข (ถ้ามีสิทธิ์) อยู่ตำแหน่งเดียวกับปุ่มบันทึกของหน้ากรอก */}
                    {((!reviewMode && !legacyDoc) || (reviewMode && reviewAction)) && (
                        <div className="tw-mt-3 tw-flex tw-flex-col sm:tw-flex-row tw-justify-end tw-gap-2 sm:tw-gap-3">
                            {!reviewMode && cancelEditAction}
                            {reviewMode ? reviewAction : (
                                <Button type="button" onClick={onFinalSave} disabled={!canFinalSave || submitting}
                                    className="tw-text-sm tw-py-2.5 tw-bg-gray-800 hover:tw-bg-gray-900"
                                    title={!canFinalSave ? t("allNotComplete", lang) : undefined}>
                                    {submitting ? t("saving", lang) : t("save", lang)}
                                </Button>
                            )}
                        </div>
                    )}
                </div>
            </form>
            <BackgroundUploadBanner lang={lang} />
            {/* ใบรุ่นเก่า — อ่านคำตอบ/รูปจากตารางผลการตรวจ */}
            {legacyDoc && (
                <PmResultTable
                    rows={compareRows}
                    lang={lang}
                    photos={cmpPhotos}
                    apiBase={API_BASE}
                    photoKeysOf={photoKeysOf}
                />
            )}
            {legacyDoc && (
                <div className="tw-mx-auto tw-max-w-6xl tw-mt-6 tw-rounded-xl tw-border tw-border-blue-gray-100 tw-bg-white tw-p-5 tw-shadow-sm sm:tw-p-6">
                    <fieldset disabled className="pm-readonly tw-m-0 tw-min-w-0 tw-border-0 tw-p-0">
                        {summaryBlock}
                    </fieldset>
                </div>
            )}
            {/* ตรวจเสร็จแล้วกดต่อได้เลย ไม่ต้องเลื่อนกลับขึ้นไปข้างบน */}
            {approveMode && editId && (
                <div id="pm-approve-bottom" className="tw-mx-auto tw-max-w-6xl tw-mt-6 tw-flex tw-items-center tw-justify-end tw-gap-2 tw-border-t tw-border-blue-gray-100 tw-pt-5">
                    <PmApprovalBar
                        prefix="mdbpmreport" reportId={editId}
                        scope={{ station_id: stationId }}
                        apiBase={API_BASE}
                        onDone={(msg) => { alert(msg); goBackToList(); }}
                    />
                </div>
            )}
        </section>
    );
}
