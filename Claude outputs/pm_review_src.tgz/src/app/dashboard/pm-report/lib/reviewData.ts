/**
 * ข้อมูลของเอกสารที่ส่งแล้ว → state ของฟอร์ม — ใช้ตอนเปิดดูอย่างเดียว (?review=1 / ?approve=1)
 * หน้าดูใช้ฟอร์มตัวเดียวกับตอนกรอก (ล็อกด้วย fieldset) จึงต้องเติมรูปและค่าที่วัดจากตัวเอกสาร
 *
 * รูป:
 * ปกติ state รูปของฟอร์มมาจาก draft ในเครื่องที่กรอกอยู่เท่านั้น เปิดดูเอกสารที่ส่งแล้ว
 * (หรือเปิดจากเครื่องอื่น) ช่องรูปจึงว่าง ตัวนี้เอารูปจาก server มาวางลงช่องของข้อนั้นแทน
 *
 * backend เก็บรูปตาม "กลุ่ม" (g16, g10_1, r7 …) ส่วนฟอร์มเก็บตาม photo key ของตัวเอง
 * แต่ละฟอร์มตั้งสูตรคนละแบบ จึงให้ฟอร์มส่งตัวแปลง กลุ่ม → photo key เข้ามา
 */

export type ServerPhoto = { url?: string; remark?: string; item?: string };

/**
 * รูปที่อยู่บน server แล้ว — ไม่มีไฟล์ในเครื่อง มีแค่ลิงก์ (uploaded = ไม่ต้องอัปซ้ำ)
 * group/url ใช้อ้างตอนลบรูปเดิมออกจากเอกสาร (โหมดแก้ไขส่วนที่ส่งแล้ว)
 */
export type ViewPhoto = { id: string; preview: string; remark: string; uploaded: true; group: string; url: string };

const SERVER_ID = "server-";

export function isServerPhoto(p: { id?: string } | null | undefined): boolean {
  return !!p?.id && p.id.startsWith(SERVER_ID);
}

export function serverPhotosToForm(
  server: Record<string, ServerPhoto[] | undefined> | undefined | null,
  formKeyOf: (group: string) => string | number | null | undefined,
  apiBase: string,
  /** รูปที่ server จำไว้ว่าเป็นของข้อย่อยไหน → key ของข้อย่อยนั้น (null = ใช้ key ของกลุ่มตามเดิม) */
  photoKeyOf?: (photo: ServerPhoto, group: string) => string | number | null | undefined,
): Record<string, ViewPhoto[]> {
  const out: Record<string, ViewPhoto[]> = {};
  for (const [group, list] of Object.entries(server ?? {})) {
    const groupKey = formKeyOf(group);
    (list ?? []).forEach((p, i) => {
      if (!p?.url) return;
      const own = photoKeyOf?.(p, group);
      const key = own === null || own === undefined || own === "" ? groupKey : own;
      if (key === null || key === undefined || key === "") return;
      const url = p.url.startsWith("http") ? p.url : `${apiBase}${p.url}`;
      (out[String(key)] ??= []).push({
        id: `${SERVER_ID}${group}-${i}`, preview: url, remark: p.remark ?? "", uploaded: true, group, url: p.url,
      });
    });
  }
  return out;
}

/**
 * ตัวแปลง กลุ่ม → photo key จากสูตรขาไปของฟอร์ม (photo key → กลุ่ม)
 * หลาย photo key ลงกลุ่มเดียวกันได้ (เช่น Station ข้อ 7.1/7.2 → r7) — วางไว้ที่ key แรกของกลุ่ม
 * เพราะ server ไม่ได้จำว่ารูปไหนเป็นของข้อย่อยไหน
 */
export function formKeyFromForward(
  formKeys: (string | number)[],
  toGroup: (formKey: string | number) => string | null | undefined,
): (group: string) => string | number | null {
  const map = new Map<string, string | number>();
  for (const k of formKeys) {
    const g = toGroup(k);
    if (g && !map.has(g)) map.set(g, k);
  }
  return (group) => map.get(group) ?? null;
}

/**
 * ค่าที่วัดของเอกสาร → state ช่องกรอกค่า
 * ตอนบันทึกบางฟอร์มแปลงค่าเป็นตัวเลข (CCB) แต่ช่องกรอกรับข้อความ ต้องแปลงกลับ
 */
export function measureAsText<T>(saved: Record<string, { value?: unknown; unit?: string } | undefined> | undefined | null): T {
  return Object.fromEntries(
    Object.entries(saved ?? {}).map(([k, v]) => [
      k,
      { ...(v ?? {}), value: v?.value === null || v?.value === undefined ? "" : String(v.value) },
    ]),
  ) as T;
}

/**
 * รวมรูปจาก draft ในเครื่องเข้ากับรูปเดิมบน server ที่โหลดไว้แล้ว
 * draft เก็บแค่รูปที่แนบในเครื่อง (รูปบน server ไม่มี ref จึงไม่ลง draft) ถ้าเอามาทับตรง ๆ
 * รูปเดิมของข้อนั้นจะหายจากหน้าจอ
 */
export function mergeDraftPhotos<T extends { id: string }>(
  prev: Record<string | number, T[] | undefined>,
  next: Record<string | number, T[] | undefined>,
): Record<string, T[]> {
  const out: Record<string, T[]> = { ...(prev as Record<string, T[]>) };
  for (const [k, list] of Object.entries(next)) {
    const server = (prev[k] ?? []).filter(isServerPhoto);
    out[k] = [...server, ...(list ?? []).filter((p) => !isServerPhoto(p))];
  }
  return out;
}

/** รูปเดิมบน server ที่ผู้ใช้กดลบออกจากฟอร์มไประหว่างแก้ไข */
export function removedServerPhotos(
  original: Record<string, ViewPhoto[]>,
  current: Record<string | number, { id: string }[] | undefined>,
): ViewPhoto[] {
  const still = new Set(Object.values(current).flat().filter(Boolean).map((p) => p!.id));
  return Object.values(original).flat().filter((p) => !still.has(p.id));
}

/**
 * ลบรูปเดิมที่ผู้ใช้เอาออกจากเอกสารจริง — เรียกตอนกดบันทึก ก่อนอัปรูปใหม่
 * (ต้องเป็นส่วนหนึ่งของใบ PM สถานี: backend ตรวจว่าใบยังไม่ได้กดปิดใบงาน)
 */
export async function deleteRemovedServerPhotos(
  apiFetch: (url: string, init?: RequestInit) => Promise<Response>,
  opts: {
    jobId: string; stationId: string; section: string; sn?: string; reportId: string;
    original: Record<string, ViewPhoto[]>;
    current: Record<string | number, { id: string }[] | undefined>;
  },
): Promise<void> {
  const removed = removedServerPhotos(opts.original, opts.current);
  for (const p of removed) {
    const res = await apiFetch(
      `/stationpmjob/${encodeURIComponent(opts.jobId)}/section-photo/delete?station_id=${encodeURIComponent(opts.stationId)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          section: opts.section, sn: opts.sn ?? "", report_id: opts.reportId, group: p.group, url: p.url,
        }),
      },
    );
    if (!res.ok) {
      const j = await res.json().catch(() => ({} as { detail?: string }));
      throw new Error(j?.detail || `ลบรูปเดิมไม่สำเร็จ (${res.status})`);
    }
  }
}
