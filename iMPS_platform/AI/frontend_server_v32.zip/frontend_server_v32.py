"""
EGAT EV AI Platform — Frontend Server
Reads AI results from MongoDB (written by backend_worker) and serves the dashboard.
Run: python frontend_server.py [--port 8000]
"""
import os, sys, time, json, logging, math
from datetime import datetime, timezone, timedelta

logger = logging.getLogger("eds-frontend")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

MONGO_URI = os.getenv("MONGO_URI", "mongodb://imps_platform:eds_imps@203.154.130.132:27017/?authSource=admin")
RESULTS_DB_NAME = "eds_ai_results"
DEFAULT_SN = os.getenv("CHARGER_SN", "F1500624011")

# Source databases (for history queries / direct telemetry)
SOURCE_DBS = {
    "m1": {"db": "module1MdbDustPrediction", "ts_field": "timestamp"},
    "m2": {"db": "module2ChargerDustPrediction", "ts_field": "timestamp_utc"},
    "m3": {"db": "module3ChargerOfflineAnalysis", "ts_field": "timestamp_utc"},
    "m4": {"db": "module4AbnormalPowerPrediction", "ts_field": "timestamp_utc"},
    "m5": {"db": "module5NetworkProblemPrediction", "ts_field": "timestamp_utc"},
    "m6": {"db": "module6DcChargerRulPrediction", "ts_field": "timestamp_utc"},
    "m7": {"db": "module7ChargerPowerIssue", "ts_field": "timestamp"},
}

MODULE_DB_NAMES = [cfg["db"] for cfg in SOURCE_DBS.values()]

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EGAT — DC Charger Anomaly Intelligence</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&family=Prompt:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@3.0.0/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
<style>
*,:before,:after{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#0b0f19;--surface:#111827;--card:rgba(255,255,255,.92);--card-s:#ffffff;
  --glass:#ffffff;--gb:rgba(200,210,225,.4);
  --bdr:#d0dae8;--bdr2:#b8c8dc;
  --tx:#2d3748;--tx2:#1a202c;--dim:#718096;--mut:#a0aec0;
  --cy:#0284c7;--cyd:#0369a1;--cyg:rgba(2,132,199,.08);
  --gn:#059669;--gng:rgba(5,150,105,.07);
  --rd:#dc2626;--rdg:rgba(220,38,38,.06);
  --am:#d97706;--amg:rgba(217,119,6,.06);
  --pu:#7c3aed;--pug:rgba(124,58,237,.08);--pk:#db2777;--tl:#0d9488;
  --R:12px;--Rs:8px;--Rx:5px;
  /* header/tab dark chrome */
  --hdr-bg:rgba(15,23,42,.85);--hdr-bdr:rgba(148,163,184,.15);--hdr-sh:rgba(0,0,0,.3);
  --tab-bg:rgba(15,23,42,.7);
  --h-tx:#f1f5f9;--h-dim:#94a3b8;--h-acc:#38bdf8;--h-acc2:#e2e8f0;
  --pill-bg:rgba(255,255,255,.08);--pill-bdr:rgba(148,163,184,.2);
  --grid-c:rgba(148,163,184,.15);
  --body-g1:rgba(56,189,248,.06);--body-g2:rgba(167,139,250,.05);--body-g3:rgba(52,211,153,.03);
  --led-off:#f87171;--led-on:#34d399;
}
[data-theme="light"]{
  --bg:#f0f4f8;--surface:#e2e8f0;
  --hdr-bg:rgba(255,255,255,.92);--hdr-bdr:rgba(200,210,225,.5);--hdr-sh:rgba(0,40,100,.06);
  --tab-bg:rgba(255,255,255,.85);
  --h-tx:#1a202c;--h-dim:#4a5568;--h-acc:#0284c7;--h-acc2:#2d3748;
  --pill-bg:rgba(2,132,199,.06);--pill-bdr:rgba(2,132,199,.15);
  --grid-c:rgba(160,180,200,.1);
  --body-g1:rgba(2,132,199,.04);--body-g2:rgba(124,58,237,.03);--body-g3:rgba(5,150,105,.02);
  --led-off:#ef4444;--led-on:#10b981;
}
/* ═══ CYBER / HIGH-TECH THEME (BRIGHT) ═══ */
[data-theme="cyber"]{
  --bg:#e8f4fa;--surface:#d0e8f4;
  --card:rgba(255,255,255,.92);--card-s:#e0f2ff;
  --glass:#ffffff;--gb:rgba(0,160,200,.12);
  --bdr:rgba(0,160,200,.18);--bdr2:rgba(0,160,200,.3);
  --tx:#0a2a3a;--tx2:#051e2c;--dim:#3a6a8a;--mut:#6a9ab0;
  --cy:#0891b2;--cyd:#0e7490;--cyg:rgba(8,145,178,.08);
  --gn:#059669;--gng:rgba(5,150,105,.07);
  --rd:#dc2626;--rdg:rgba(220,38,38,.06);
  --am:#d97706;--amg:rgba(217,119,6,.06);
  --pu:#7c3aed;--pug:rgba(124,58,237,.06);--pk:#db2777;--tl:#0d9488;
  --R:12px;--Rs:8px;--Rx:5px;
  --hdr-bg:rgba(255,255,255,.94);--hdr-bdr:rgba(0,160,200,.15);--hdr-sh:rgba(0,160,200,.08);
  --tab-bg:rgba(255,255,255,.88);
  --h-tx:#051e2c;--h-dim:#3a6a8a;--h-acc:#0891b2;--h-acc2:#0a2a3a;
  --pill-bg:rgba(0,160,200,.06);--pill-bdr:rgba(0,160,200,.18);
  --grid-c:rgba(0,160,200,.05);
  --body-g1:rgba(8,145,178,.06);--body-g2:rgba(124,58,237,.03);--body-g3:rgba(5,150,105,.03);
  --led-off:#ef4444;--led-on:#059669;
}
/* Cyber body: soft tech gradient */
[data-theme="cyber"] body::before{
  background:
    radial-gradient(ellipse 80% 60% at 10% 5%,rgba(8,145,178,.08),transparent 50%),
    radial-gradient(ellipse 60% 50% at 90% 90%,rgba(124,58,237,.05),transparent 45%),
    radial-gradient(ellipse 50% 40% at 50% 50%,rgba(5,150,105,.04),transparent 40%);
}
[data-theme="cyber"] body::after{opacity:.025;background-size:60px 60px;
  background-image:linear-gradient(rgba(8,145,178,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(8,145,178,.05) 1px,transparent 1px);
}
/* Cyber header */
[data-theme="cyber"] .hdr{box-shadow:0 1px 12px rgba(8,145,178,.08),inset 0 -1px 0 rgba(8,145,178,.1);
  border-image:linear-gradient(90deg,rgba(8,145,178,.2),rgba(124,58,237,.1),rgba(8,145,178,.2)) 1;}
[data-theme="cyber"] .tbs{box-shadow:inset 0 -1px 0 rgba(8,145,178,.1)}
[data-theme="cyber"] .tb.on{color:#0e7490;border-color:#0891b2;text-shadow:none}
[data-theme="cyber"] .tb.on::after{background:linear-gradient(90deg,#0891b2,#06b6d4);filter:blur(4px)}

/* Cyber cards */
[data-theme="cyber"] .cd{border-color:rgba(8,145,178,.12);background:rgba(255,255,255,.85);backdrop-filter:blur(8px);overflow:visible;box-shadow:0 1px 4px rgba(8,145,178,.04)}
[data-theme="cyber"] .cd:hover{border-color:rgba(8,145,178,.25);box-shadow:0 2px 12px rgba(8,145,178,.08)}
[data-theme="cyber"] .ct i{filter:none}
[data-theme="cyber"] .cd-cy{border-color:rgba(8,145,178,.18);background:linear-gradient(145deg,rgba(255,255,255,.9),rgba(208,232,244,.4))}

/* Cyber buttons */
[data-theme="cyber"] .bt{border-color:rgba(8,145,178,.2)}
[data-theme="cyber"] .bgh{background:linear-gradient(135deg,rgba(8,145,178,.1),rgba(6,182,212,.06));border-color:rgba(8,145,178,.25);color:#0e7490;box-shadow:0 1px 6px rgba(8,145,178,.06)}
[data-theme="cyber"] .bgh:hover{box-shadow:0 2px 12px rgba(8,145,178,.12);border-color:rgba(8,145,178,.35)}

/* Cyber inputs */
[data-theme="cyber"] input[type=number],[data-theme="cyber"] select,[data-theme="cyber"] .hist-dt{background:rgba(255,255,255,.9);border-color:rgba(8,145,178,.18);color:#0a2a3a}
[data-theme="cyber"] input[type=number]:focus,[data-theme="cyber"] select:focus{border-color:rgba(8,145,178,.4);box-shadow:0 0 8px rgba(8,145,178,.1)}

/* Cyber sequence */
[data-theme="cyber"] .sq-panel{background:rgba(232,244,250,.8);border-color:rgba(8,145,178,.12)}
[data-theme="cyber"] .sq-node-inner{background:rgba(255,255,255,.9);border-color:rgba(8,145,178,.18)}
[data-theme="cyber"] .sq-past .sq-node-inner{border-color:rgba(8,145,178,.35);background:rgba(8,145,178,.06)}
[data-theme="cyber"] .sq-wire{background:rgba(8,145,178,.08)}
[data-theme="cyber"] .sq-lbl{color:rgba(8,145,178,.5)}
[data-theme="cyber"] .sq-past .sq-lbl{color:rgba(8,145,178,.7)}
[data-theme="cyber"] .sq-progress{background:rgba(8,145,178,.08)}
[data-theme="cyber"] .sq-desc-item{background:rgba(232,244,250,.7);border-color:rgba(8,145,178,.1)}
[data-theme="cyber"] .sq-col-head{background:rgba(8,145,178,.04)!important}
[data-theme="cyber"] .sq-desc-txt{color:rgba(8,145,178,.5)}
[data-theme="cyber"] .sq-idx{color:rgba(8,145,178,.3)}
[data-theme="cyber"] .sq-past .sq-idx{color:rgba(8,145,178,.55)}
[data-theme="cyber"] .sq-to{color:rgba(8,145,178,.5);border-color:rgba(8,145,178,.1);background:rgba(8,145,178,.03)}
[data-theme="cyber"] .sq-step:hover{background:rgba(8,145,178,.04)}

/* Cyber condition rows */
[data-theme="cyber"] .cn{background:rgba(255,255,255,.7);border-color:rgba(8,145,178,.1)}
[data-theme="cyber"] .cn:hover{border-color:rgba(8,145,178,.25);box-shadow:0 1px 8px rgba(8,145,178,.06)}
[data-theme="cyber"] .cn.alarm{border-color:rgba(220,38,38,.25);background:rgba(220,38,38,.04);box-shadow:0 1px 8px rgba(220,38,38,.05)}

/* Cyber health tree + gauge */
[data-theme="cyber"] .en{background:rgba(255,255,255,.75);box-shadow:0 1px 6px rgba(8,145,178,.05)}
[data-theme="cyber"] .rn-gauge .rg-outer-track{stroke:rgba(8,145,178,.08)}
[data-theme="cyber"] .rn-gauge .rg-inner-track{stroke:rgba(8,145,178,.06)}
[data-theme="cyber"] .rn-gauge .rg-zone-label{fill:#3a6a8a}
[data-theme="cyber"] .rn-gauge #rgVal{fill:#0e7490}
[data-theme="cyber"] .rn-gauge #rgNeedle .rg-needle-body{fill:#0891b2}
[data-theme="cyber"] .rn-gauge #rgNeedle .rg-needle-hub{fill:#e0f2ff;stroke:#0891b2}
[data-theme="cyber"] .rn-gauge #rgNeedle .rg-needle-dot{fill:#0e7490}
[data-theme="cyber"] .rn-pill{background:rgba(8,145,178,.06);border-color:rgba(8,145,178,.18)}

/* Cyber badges */
[data-theme="cyber"] .sc-tp.sc-ai{background:rgba(8,145,178,.1);color:#0e7490}
[data-theme="cyber"] .sc-tp.sc-hy{background:rgba(217,119,6,.08);color:#b45309}
[data-theme="cyber"] .sc-tp.sc-rl{background:rgba(100,116,139,.08);color:#64748b}
[data-theme="cyber"] .sc-ai-note{color:#0891b2}

/* Cyber rule tree */
[data-theme="cyber"] .rt-r{background:rgba(255,255,255,.65);border-color:rgba(8,145,178,.1)}
[data-theme="cyber"] .rt-r:hover{border-color:rgba(8,145,178,.28)}
[data-theme="cyber"] .rt-gn{background:rgba(255,255,255,.7);border-color:rgba(8,145,178,.14)}

/* Cyber table */
[data-theme="cyber"] .sc-tbl th{background:rgba(8,145,178,.06);color:#3a6a8a;border-color:rgba(8,145,178,.1)}
[data-theme="cyber"] .sc-tbl td{border-color:rgba(8,145,178,.08)}
[data-theme="cyber"] .sc-tbl tr:hover{background:rgba(8,145,178,.04)}
[data-theme="cyber"] .sc-tbl code{background:rgba(8,145,178,.08);color:#0e7490}

/* Cyber sidebar */
[data-theme="cyber"] .sidebar{background:linear-gradient(180deg,rgba(232,244,250,.98),rgba(208,232,244,.96));border-color:rgba(8,145,178,.12)}
[data-theme="cyber"] .sb-item{color:#0a2a3a}
[data-theme="cyber"] .sb-item .sb-txt-sub{color:#3a6a8a}
[data-theme="cyber"] .sb-icon{background:rgba(8,145,178,.06)}
[data-theme="cyber"] .sb-toggle-icon{background:rgba(8,145,178,.06)}
[data-theme="cyber"] .sb-section{color:#3a6a8a}
[data-theme="cyber"] .sb-item.sb-active{background:linear-gradient(135deg,rgba(8,145,178,.1),rgba(6,182,212,.06));border-color:rgba(8,145,178,.25);box-shadow:0 1px 10px rgba(8,145,178,.08)}
[data-theme="cyber"] .sb-item.sb-active .sb-icon{background:linear-gradient(135deg,#0891b2,#06b6d4);color:#fff;box-shadow:0 2px 8px rgba(8,145,178,.25)}
[data-theme="cyber"] .sb-item.sb-active .sb-txt-name{color:#0e7490}
[data-theme="cyber"] .sb-badge-live{background:rgba(5,150,105,.1);color:#059669}
[data-theme="cyber"] .sb-badge-soon{background:rgba(8,145,178,.06);color:#6a9ab0}

/* Cyber scrollbar */
[data-theme="cyber"] ::-webkit-scrollbar-thumb{background:rgba(8,145,178,.2)}
[data-theme="cyber"] ::-webkit-scrollbar-track{background:rgba(8,145,178,.03)}

/* Cyber LED, clock, pill */
[data-theme="cyber"] .led.on{background:#059669;box-shadow:0 0 8px rgba(5,150,105,.4)}
[data-theme="cyber"] .ck{color:#0e7490}
[data-theme="cyber"] .pill{border-color:rgba(8,145,178,.18);background:rgba(8,145,178,.05)}
[data-theme="cyber"] .ap-timer.ap-on{color:#059669}
[data-theme="cyber"] .ap-timer.ap-run{color:#0891b2}
[data-theme="cyber"] .hg-bar{background:rgba(8,145,178,.07)}
[data-theme="cyber"] .hg-total{color:#3a6a8a}
[data-theme="cyber"] .hg-normal{background:linear-gradient(90deg,#059669,#34d399)}
[data-theme="cyber"] .hg-warn{background:linear-gradient(90deg,#d97706,#fbbf24)}
[data-theme="cyber"] .hg-alarm{background:linear-gradient(90deg,#dc2626,#f87171)}
[data-theme="cyber"] .theme-sw{border-color:rgba(8,145,178,.25);box-shadow:none;color:#0e7490}
[data-theme="cyber"] .lang-sw{border-color:rgba(8,145,178,.2);color:#0e7490}

/* Cyber M3/M5/M6 */
[data-theme="cyber"] .m3-load-panel{border-color:rgba(8,145,178,.12);background:rgba(255,255,255,.7)}
[data-theme="cyber"] .m3-load-hdr{background:rgba(8,145,178,.04);color:#0a2a3a}
[data-theme="cyber"] .m3-load-item{border-color:rgba(8,145,178,.1)}
[data-theme="cyber"] .m3-load-item.loaded{border-color:rgba(8,145,178,.22);background:rgba(8,145,178,.04)}
[data-theme="cyber"] .m3-ap{border-color:rgba(8,145,178,.14);background:rgba(255,255,255,.65)}
[data-theme="cyber"] .m3-ap-badge.done{background:rgba(5,150,105,.1);color:#059669}
[data-theme="cyber"] .m3-ap-badge.running{background:rgba(8,145,178,.1);color:#0891b2}
[data-theme="cyber"] .m3-ap-badge.error{background:rgba(220,38,38,.08);color:#dc2626}
[data-theme="cyber"] .m5-net-node{border-color:rgba(8,145,178,.15);background:rgba(255,255,255,.8)}
[data-theme="cyber"] .m5-net-node.up .m5-led{background:#059669;box-shadow:0 0 6px rgba(5,150,105,.4)}
[data-theme="cyber"] .m5-cond-tbl th{background:rgba(8,145,178,.06);color:#3a6a8a;border-color:rgba(8,145,178,.1)}
[data-theme="cyber"] .m5-cond-tbl td{border-color:rgba(8,145,178,.08)}
[data-theme="cyber"] .m5-cond-tbl tr:hover{background:rgba(8,145,178,.04)}
[data-theme="cyber"] .m6-cat{border-color:rgba(8,145,178,.12);background:rgba(255,255,255,.7)}
[data-theme="cyber"] .m6-cat:hover{border-color:rgba(8,145,178,.28);box-shadow:0 2px 10px rgba(8,145,178,.06)}

/* ═══ NEURAL — AI HOLOGRAPHIC THEME (BRIGHT) ═══ */
[data-theme="neural"]{
  --bg:#f0ecf8;--surface:#e2daf0;
  --card:rgba(255,255,255,.92);--card-s:#f0eaff;
  --glass:#ffffff;--gb:rgba(139,92,246,.12);
  --bdr:rgba(139,92,246,.18);--bdr2:rgba(139,92,246,.3);
  --tx:#1e1040;--tx2:#150a30;--dim:#6a5a8a;--mut:#9a8ab0;
  --cy:#8b5cf6;--cyd:#7c3aed;--cyg:rgba(139,92,246,.08);
  --gn:#059669;--gng:rgba(5,150,105,.07);
  --rd:#e11d48;--rdg:rgba(225,29,72,.06);
  --am:#d97706;--amg:rgba(217,119,6,.06);
  --pu:#a78bfa;--pug:rgba(167,139,250,.08);--pk:#ec4899;--tl:#14b8a6;
  --R:12px;--Rs:8px;--Rx:5px;
  --hdr-bg:rgba(255,255,255,.94);--hdr-bdr:rgba(139,92,246,.15);--hdr-sh:rgba(139,92,246,.08);
  --tab-bg:rgba(255,255,255,.88);
  --h-tx:#150a30;--h-dim:#6a5a8a;--h-acc:#8b5cf6;--h-acc2:#1e1040;
  --pill-bg:rgba(139,92,246,.06);--pill-bdr:rgba(139,92,246,.18);
  --grid-c:rgba(139,92,246,.05);
  --body-g1:rgba(139,92,246,.06);--body-g2:rgba(236,72,153,.04);--body-g3:rgba(52,211,153,.03);
  --led-off:#e11d48;--led-on:#059669;
}

/* Neural body: soft purple gradient */
[data-theme="neural"] body::before{
  background:
    radial-gradient(ellipse 80% 65% at 8% 8%,rgba(139,92,246,.08),transparent 50%),
    radial-gradient(ellipse 70% 55% at 92% 85%,rgba(236,72,153,.05),transparent 45%),
    radial-gradient(ellipse 55% 45% at 50% 50%,rgba(52,211,153,.04),transparent 40%);
}
[data-theme="neural"] body::after{
  opacity:.025;
  background-image:linear-gradient(rgba(139,92,246,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(139,92,246,.05) 1px,transparent 1px);
  background-size:50px 50px;
}

/* Neural header */
[data-theme="neural"] .hdr{box-shadow:0 1px 12px rgba(139,92,246,.08),inset 0 -1px 0 rgba(139,92,246,.1);
  border-image:linear-gradient(90deg,rgba(139,92,246,.2),rgba(236,72,153,.1),rgba(52,211,153,.08),rgba(139,92,246,.2)) 1;}
[data-theme="neural"] .tbs{box-shadow:inset 0 -1px 0 rgba(139,92,246,.1)}
[data-theme="neural"] .tb.on{color:#7c3aed;border-color:#8b5cf6;text-shadow:none}
[data-theme="neural"] .tb.on::after{background:linear-gradient(90deg,#8b5cf6,#a78bfa);filter:blur(4px)}

/* Neural cards */
[data-theme="neural"] .cd{border-color:rgba(139,92,246,.12);background:rgba(255,255,255,.85);backdrop-filter:blur(8px);box-shadow:0 1px 4px rgba(139,92,246,.04)}
[data-theme="neural"] .cd:hover{border-color:rgba(139,92,246,.25);box-shadow:0 2px 12px rgba(139,92,246,.08)}
[data-theme="neural"] .ct i{filter:none}
[data-theme="neural"] .cd-cy{border-color:rgba(139,92,246,.18);background:linear-gradient(145deg,rgba(255,255,255,.9),rgba(226,218,240,.4))}

/* Neural buttons */
[data-theme="neural"] .bt{border-color:rgba(139,92,246,.2)}
[data-theme="neural"] .bgh{background:linear-gradient(135deg,rgba(139,92,246,.1),rgba(236,72,153,.05));border-color:rgba(139,92,246,.25);color:#7c3aed;box-shadow:0 1px 6px rgba(139,92,246,.06)}
[data-theme="neural"] .bgh:hover{box-shadow:0 2px 12px rgba(139,92,246,.12);border-color:rgba(139,92,246,.35)}

/* Neural inputs */
[data-theme="neural"] input[type=number],[data-theme="neural"] select,[data-theme="neural"] .hist-dt{background:rgba(255,255,255,.9);border-color:rgba(139,92,246,.18);color:#1e1040}
[data-theme="neural"] input[type=number]:focus,[data-theme="neural"] select:focus{border-color:rgba(139,92,246,.4);box-shadow:0 0 8px rgba(139,92,246,.1)}

/* Neural sequence */
[data-theme="neural"] .sq-panel{background:rgba(240,236,248,.8);border-color:rgba(139,92,246,.12)}
[data-theme="neural"] .sq-node-inner{background:rgba(255,255,255,.9);border-color:rgba(139,92,246,.18)}
[data-theme="neural"] .sq-past .sq-node-inner{border-color:rgba(139,92,246,.35);background:rgba(139,92,246,.06)}
[data-theme="neural"] .sq-wire{background:rgba(139,92,246,.08)}
[data-theme="neural"] .sq-lbl{color:rgba(139,92,246,.5)}
[data-theme="neural"] .sq-past .sq-lbl{color:rgba(139,92,246,.7)}
[data-theme="neural"] .sq-progress{background:rgba(139,92,246,.08)}
[data-theme="neural"] .sq-desc-item{background:rgba(240,236,248,.7);border-color:rgba(139,92,246,.1)}
[data-theme="neural"] .sq-col-head{background:rgba(139,92,246,.04)!important}
[data-theme="neural"] .sq-desc-txt{color:rgba(139,92,246,.5)}
[data-theme="neural"] .sq-idx{color:rgba(139,92,246,.3)}
[data-theme="neural"] .sq-past .sq-idx{color:rgba(139,92,246,.55)}
[data-theme="neural"] .sq-to{color:rgba(139,92,246,.5);border-color:rgba(139,92,246,.1);background:rgba(139,92,246,.03)}
[data-theme="neural"] .sq-step:hover{background:rgba(139,92,246,.04)}

/* Neural condition rows */
[data-theme="neural"] .cn{background:rgba(255,255,255,.7);border-color:rgba(139,92,246,.1)}
[data-theme="neural"] .cn:hover{border-color:rgba(139,92,246,.25);box-shadow:0 1px 8px rgba(139,92,246,.06)}
[data-theme="neural"] .cn.alarm{border-color:rgba(225,29,72,.25);background:rgba(225,29,72,.04);box-shadow:0 1px 8px rgba(225,29,72,.05)}

/* Neural health tree + gauge */
[data-theme="neural"] .en{background:rgba(255,255,255,.75);box-shadow:0 1px 6px rgba(139,92,246,.05)}
[data-theme="neural"] .rn-gauge .rg-outer-track{stroke:rgba(139,92,246,.08)}
[data-theme="neural"] .rn-gauge .rg-inner-track{stroke:rgba(139,92,246,.06)}
[data-theme="neural"] .rn-gauge .rg-zone-label{fill:#6a5a8a}
[data-theme="neural"] .rn-gauge #rgVal{fill:#7c3aed}
[data-theme="neural"] .rn-gauge #rgNeedle .rg-needle-body{fill:#8b5cf6}
[data-theme="neural"] .rn-gauge #rgNeedle .rg-needle-hub{fill:#f0eaff;stroke:#8b5cf6}
[data-theme="neural"] .rn-gauge #rgNeedle .rg-needle-dot{fill:#7c3aed}
[data-theme="neural"] .rn-pill{background:rgba(139,92,246,.06);border-color:rgba(139,92,246,.18)}

/* Neural badges */
[data-theme="neural"] .sc-tp.sc-ai{background:rgba(139,92,246,.1);color:#7c3aed}
[data-theme="neural"] .sc-tp.sc-hy{background:rgba(236,72,153,.08);color:#db2777}
[data-theme="neural"] .sc-tp.sc-rl{background:rgba(100,116,139,.08);color:#64748b}
[data-theme="neural"] .sc-ai-note{color:#8b5cf6}

/* Neural rule tree */
[data-theme="neural"] .rt-r{background:rgba(255,255,255,.65);border-color:rgba(139,92,246,.1)}
[data-theme="neural"] .rt-r:hover{border-color:rgba(139,92,246,.28)}
[data-theme="neural"] .rt-gn{background:rgba(255,255,255,.7);border-color:rgba(139,92,246,.14)}

/* Neural table */
[data-theme="neural"] .sc-tbl th{background:rgba(139,92,246,.06);color:#6a5a8a;border-color:rgba(139,92,246,.1)}
[data-theme="neural"] .sc-tbl td{border-color:rgba(139,92,246,.08)}
[data-theme="neural"] .sc-tbl tr:hover{background:rgba(139,92,246,.04)}
[data-theme="neural"] .sc-tbl code{background:rgba(139,92,246,.08);color:#7c3aed}

/* Neural sidebar */
[data-theme="neural"] .sidebar{background:linear-gradient(180deg,rgba(240,236,248,.98),rgba(226,218,240,.96));border-color:rgba(139,92,246,.12)}
[data-theme="neural"] .sb-item{color:#1e1040}
[data-theme="neural"] .sb-item .sb-txt-sub{color:#6a5a8a}
[data-theme="neural"] .sb-icon{background:rgba(139,92,246,.06)}
[data-theme="neural"] .sb-toggle-icon{background:rgba(139,92,246,.06)}
[data-theme="neural"] .sb-section{color:#6a5a8a}
[data-theme="neural"] .sb-item.sb-active{background:linear-gradient(135deg,rgba(139,92,246,.1),rgba(236,72,153,.04));border-color:rgba(139,92,246,.25);box-shadow:0 1px 10px rgba(139,92,246,.08)}
[data-theme="neural"] .sb-item.sb-active .sb-icon{background:linear-gradient(135deg,#8b5cf6,#a78bfa);color:#fff;box-shadow:0 2px 8px rgba(139,92,246,.25)}
[data-theme="neural"] .sb-item.sb-active .sb-txt-name{color:#7c3aed}
[data-theme="neural"] .sb-badge-live{background:rgba(5,150,105,.1);color:#059669}
[data-theme="neural"] .sb-badge-soon{background:rgba(139,92,246,.06);color:#9a8ab0}

/* Neural scrollbar */
[data-theme="neural"] ::-webkit-scrollbar-thumb{background:rgba(139,92,246,.2)}
[data-theme="neural"] ::-webkit-scrollbar-track{background:rgba(139,92,246,.03)}

/* Neural LED, clock, pill */
[data-theme="neural"] .led.on{background:#059669;box-shadow:0 0 8px rgba(5,150,105,.4)}
[data-theme="neural"] .ck{color:#7c3aed}
[data-theme="neural"] .pill{border-color:rgba(139,92,246,.18);background:rgba(139,92,246,.05)}
[data-theme="neural"] .ap-timer.ap-on{color:#059669}
[data-theme="neural"] .ap-timer.ap-run{color:#8b5cf6}
[data-theme="neural"] .hg-bar{background:rgba(139,92,246,.07)}
[data-theme="neural"] .hg-total{color:#6a5a8a}
[data-theme="neural"] .hg-normal{background:linear-gradient(90deg,#059669,#34d399)}
[data-theme="neural"] .hg-warn{background:linear-gradient(90deg,#d97706,#fbbf24)}
[data-theme="neural"] .hg-alarm{background:linear-gradient(90deg,#e11d48,#f43f5e)}
[data-theme="neural"] .theme-sw{border-color:rgba(139,92,246,.25);box-shadow:none;color:#7c3aed}
[data-theme="neural"] .lang-sw{border-color:rgba(139,92,246,.2);color:#7c3aed}

/* Neural M3/M5/M6 */
[data-theme="neural"] .m3-load-panel{border-color:rgba(139,92,246,.12);background:rgba(255,255,255,.7)}
[data-theme="neural"] .m3-load-hdr{background:rgba(139,92,246,.04);color:#1e1040}
[data-theme="neural"] .m3-load-item{border-color:rgba(139,92,246,.1)}
[data-theme="neural"] .m3-load-item.loaded{border-color:rgba(139,92,246,.22);background:rgba(139,92,246,.04)}
[data-theme="neural"] .m3-ap{border-color:rgba(139,92,246,.14);background:rgba(255,255,255,.65)}
[data-theme="neural"] .m3-ap-badge.done{background:rgba(5,150,105,.1);color:#059669}
[data-theme="neural"] .m3-ap-badge.running{background:rgba(139,92,246,.1);color:#8b5cf6}
[data-theme="neural"] .m3-ap-badge.error{background:rgba(225,29,72,.08);color:#e11d48}
[data-theme="neural"] .m5-net-node{border-color:rgba(139,92,246,.15);background:rgba(255,255,255,.8)}
[data-theme="neural"] .m5-net-node.up .m5-led{background:#059669;box-shadow:0 0 6px rgba(5,150,105,.4)}
[data-theme="neural"] .m5-cond-tbl th{background:rgba(139,92,246,.06);color:#6a5a8a;border-color:rgba(139,92,246,.1)}
[data-theme="neural"] .m5-cond-tbl td{border-color:rgba(139,92,246,.08)}
[data-theme="neural"] .m5-cond-tbl tr:hover{background:rgba(139,92,246,.04)}
[data-theme="neural"] .m6-cat{border-color:rgba(139,92,246,.12);background:rgba(255,255,255,.7)}
[data-theme="neural"] .m6-cat:hover{border-color:rgba(139,92,246,.28);box-shadow:0 2px 10px rgba(139,92,246,.06)}

/* ═══ NATURE / BRIGHT GREEN THEME ═══ */
[data-theme="nature"]{
  --bg:#f0f7f0;--surface:#dceede;
  --card:rgba(255,255,255,.92);--card-s:#f0faf0;
  --glass:#ffffff;--gb:rgba(22,163,74,.12);
  --bdr:rgba(22,163,74,.18);--bdr2:rgba(22,163,74,.3);
  --tx:#1a3a2a;--tx2:#0f2a1a;--dim:#4a7a5a;--mut:#7aaa8a;
  --cy:#16a34a;--cyd:#15803d;--cyg:rgba(22,163,74,.08);
  --gn:#16a34a;--gng:rgba(22,163,74,.07);
  --rd:#dc2626;--rdg:rgba(220,38,38,.06);
  --am:#b45309;--amg:rgba(180,83,9,.06);
  --pu:#7c3aed;--pug:rgba(124,58,237,.06);--pk:#db2777;--tl:#0d9488;
  --R:12px;--Rs:8px;--Rx:5px;
  --hdr-bg:rgba(255,255,255,.94);--hdr-bdr:rgba(22,163,74,.15);--hdr-sh:rgba(22,163,74,.08);
  --tab-bg:rgba(255,255,255,.88);
  --h-tx:#0f2a1a;--h-dim:#4a7a5a;--h-acc:#16a34a;--h-acc2:#1a3a2a;
  --pill-bg:rgba(22,163,74,.06);--pill-bdr:rgba(22,163,74,.18);
  --grid-c:rgba(22,163,74,.06);
  --body-g1:rgba(22,163,74,.05);--body-g2:rgba(74,222,128,.04);--body-g3:rgba(180,83,9,.02);
  --led-off:#ef4444;--led-on:#16a34a;
  --accent:#16a34a;--fg:#0f2a1a;
}

/* ─── Nature body: soft leaf gradient ─── */
[data-theme="nature"] body::before{
  background:
    radial-gradient(ellipse 80% 70% at 15% 10%,rgba(74,222,128,.1),transparent 50%),
    radial-gradient(ellipse 70% 60% at 85% 85%,rgba(22,163,74,.06),transparent 45%),
    radial-gradient(ellipse 50% 40% at 50% 50%,rgba(134,239,172,.04),transparent 40%);
}
[data-theme="nature"] body::after{
  opacity:.03;
  background-image:
    linear-gradient(rgba(22,163,74,.06) 1px,transparent 1px),
    linear-gradient(90deg,rgba(22,163,74,.06) 1px,transparent 1px);
  background-size:50px 50px;
}

/* ─── Nature header ─── */
[data-theme="nature"] .hdr{
  box-shadow:0 1px 12px rgba(22,163,74,.08),inset 0 -1px 0 rgba(22,163,74,.1);
  border-image:linear-gradient(90deg,rgba(22,163,74,.2),rgba(74,222,128,.12),rgba(22,163,74,.2)) 1;
}
[data-theme="nature"] .tbs{box-shadow:inset 0 -1px 0 rgba(22,163,74,.1)}
[data-theme="nature"] .tb.on{color:#15803d;border-color:#16a34a;text-shadow:none}
[data-theme="nature"] .tb.on::after{background:linear-gradient(90deg,#16a34a,#4ade80);filter:blur(4px)}

/* ─── Nature cards ─── */
[data-theme="nature"] .cd{
  border-color:rgba(22,163,74,.12);
  background:rgba(255,255,255,.85);
  backdrop-filter:blur(8px);
  box-shadow:0 1px 4px rgba(22,163,74,.04);
}
[data-theme="nature"] .cd:hover{
  border-color:rgba(22,163,74,.25);
  box-shadow:0 2px 12px rgba(22,163,74,.08);
}
[data-theme="nature"] .ct i{filter:none}
[data-theme="nature"] .cd-cy{border-color:rgba(22,163,74,.18);background:linear-gradient(145deg,rgba(255,255,255,.9),rgba(220,238,222,.5))}

/* ─── Nature buttons ─── */
[data-theme="nature"] .bt{border-color:rgba(22,163,74,.2)}
[data-theme="nature"] .bgh{
  background:linear-gradient(135deg,rgba(22,163,74,.1),rgba(74,222,128,.06));
  border-color:rgba(22,163,74,.25);color:#15803d;
  box-shadow:0 1px 6px rgba(22,163,74,.06);
}
[data-theme="nature"] .bgh:hover{
  box-shadow:0 2px 12px rgba(22,163,74,.12);
  border-color:rgba(22,163,74,.35);
}

/* ─── Nature inputs ─── */
[data-theme="nature"] input[type=number],[data-theme="nature"] select,[data-theme="nature"] .hist-dt{
  background:rgba(255,255,255,.9);border-color:rgba(22,163,74,.18);color:#1a3a2a;
}
[data-theme="nature"] input[type=number]:focus,[data-theme="nature"] select:focus{
  border-color:rgba(22,163,74,.4);
  box-shadow:0 0 8px rgba(22,163,74,.1);
}

/* ─── Nature sequence panel ─── */
[data-theme="nature"] .sq-panel{background:rgba(240,250,240,.8);border-color:rgba(22,163,74,.12)}
[data-theme="nature"] .sq-node-inner{background:rgba(255,255,255,.9);border-color:rgba(22,163,74,.18)}
[data-theme="nature"] .sq-past .sq-node-inner{border-color:rgba(22,163,74,.35);background:rgba(22,163,74,.06)}
[data-theme="nature"] .sq-wire{background:rgba(22,163,74,.08)}
[data-theme="nature"] .sq-lbl{color:rgba(22,163,74,.5)}
[data-theme="nature"] .sq-past .sq-lbl{color:rgba(22,163,74,.7)}
[data-theme="nature"] .sq-progress{background:rgba(22,163,74,.08)}
[data-theme="nature"] .sq-desc-item{background:rgba(240,250,240,.7);border-color:rgba(22,163,74,.1)}
[data-theme="nature"] .sq-col-head{background:rgba(22,163,74,.04)!important}
[data-theme="nature"] .sq-to{color:rgba(22,163,74,.5);border-color:rgba(22,163,74,.1);background:rgba(22,163,74,.03)}

/* ─── Nature condition rows ─── */
[data-theme="nature"] .cn{background:rgba(255,255,255,.7);border-color:rgba(22,163,74,.1)}
[data-theme="nature"] .cn:hover{border-color:rgba(22,163,74,.25);box-shadow:0 1px 8px rgba(22,163,74,.06)}
[data-theme="nature"] .cn.alarm{
  border-color:rgba(220,38,38,.25);background:rgba(220,38,38,.04);
  box-shadow:0 1px 8px rgba(220,38,38,.05);
}

/* ─── Nature health tree ─── */
[data-theme="nature"] .en{background:rgba(255,255,255,.75);box-shadow:0 1px 6px rgba(22,163,74,.05)}

/* ─── Nature gauge ─── */
[data-theme="nature"] .rn-gauge .rg-outer-track{stroke:rgba(22,163,74,.08)}
[data-theme="nature"] .rn-gauge .rg-inner-track{stroke:rgba(22,163,74,.06)}
[data-theme="nature"] .rn-gauge .rg-zone-label{fill:#4a7a5a}
[data-theme="nature"] .rn-gauge #rgVal{fill:#15803d}
[data-theme="nature"] .rn-gauge #rgNeedle .rg-needle-body{fill:#16a34a}
[data-theme="nature"] .rn-gauge #rgNeedle .rg-needle-hub{fill:#f0faf0;stroke:#16a34a}
[data-theme="nature"] .rn-gauge #rgNeedle .rg-needle-dot{fill:#15803d}
[data-theme="nature"] .rn-pill{background:rgba(22,163,74,.06);border-color:rgba(22,163,74,.18)}

/* ─── Nature status badges ─── */
[data-theme="nature"] .sc-tp.sc-ai{background:rgba(22,163,74,.1);color:#15803d}
[data-theme="nature"] .sc-tp.sc-hy{background:rgba(180,83,9,.08);color:#b45309}
[data-theme="nature"] .sc-tp.sc-rl{background:rgba(100,116,139,.08);color:#64748b}
[data-theme="nature"] .sc-ai-note{color:#16a34a}

/* ─── Nature rule tree ─── */
[data-theme="nature"] .rt-r{background:rgba(255,255,255,.65);border-color:rgba(22,163,74,.1)}
[data-theme="nature"] .rt-r:hover{border-color:rgba(22,163,74,.28)}
[data-theme="nature"] .rt-gn{background:rgba(255,255,255,.7);border-color:rgba(22,163,74,.14)}

/* ─── Nature table ─── */
[data-theme="nature"] .sc-tbl th{background:rgba(22,163,74,.06);color:#4a7a5a;border-color:rgba(22,163,74,.1)}
[data-theme="nature"] .sc-tbl td{border-color:rgba(22,163,74,.08)}
[data-theme="nature"] .sc-tbl tr:hover{background:rgba(22,163,74,.04)}
[data-theme="nature"] .sc-tbl code{background:rgba(22,163,74,.08);color:#15803d}

/* ─── Nature sidebar ─── */
[data-theme="nature"] .sidebar{
  background:linear-gradient(180deg,rgba(240,250,240,.98),rgba(220,238,222,.96));
  border-color:rgba(22,163,74,.12);
}
[data-theme="nature"] .sb-item{color:#1a3a2a}
[data-theme="nature"] .sb-item .sb-txt-sub{color:#4a7a5a}
[data-theme="nature"] .sb-icon{background:rgba(22,163,74,.06)}
[data-theme="nature"] .sb-toggle-icon{background:rgba(22,163,74,.06)}
[data-theme="nature"] .sb-section{color:#4a7a5a}
[data-theme="nature"] .sb-item.sb-active{
  background:linear-gradient(135deg,rgba(22,163,74,.1),rgba(74,222,128,.06));
  border-color:rgba(22,163,74,.25);
  box-shadow:0 1px 10px rgba(22,163,74,.08);
}
[data-theme="nature"] .sb-item.sb-active .sb-icon{
  background:linear-gradient(135deg,#16a34a,#4ade80);color:#fff;
  box-shadow:0 2px 8px rgba(22,163,74,.25);
}
[data-theme="nature"] .sb-item.sb-active .sb-txt-name{color:#15803d}
[data-theme="nature"] .sb-badge-live{background:rgba(22,163,74,.1);color:#16a34a}
[data-theme="nature"] .sb-badge-soon{background:rgba(22,163,74,.06);color:#7aaa8a}

/* ─── Nature scrollbar ─── */
[data-theme="nature"] ::-webkit-scrollbar-thumb{background:rgba(22,163,74,.2)}
[data-theme="nature"] ::-webkit-scrollbar-track{background:rgba(22,163,74,.03)}

/* ─── Nature LED ─── */
[data-theme="nature"] .led.on{background:#16a34a;box-shadow:0 0 8px rgba(22,163,74,.4)}

/* ─── Nature auto-predict ─── */
[data-theme="nature"] .ap-timer.ap-on{color:#16a34a}
[data-theme="nature"] .ap-timer.ap-run{color:#b45309}

/* ─── Nature histogram ─── */
[data-theme="nature"] .hg-normal{background:linear-gradient(90deg,#16a34a,#4ade80)}
[data-theme="nature"] .hg-warn{background:linear-gradient(90deg,#b45309,#d97706)}
[data-theme="nature"] .hg-alarm{background:linear-gradient(90deg,#dc2626,#f87171)}

/* ─── Nature clock & pill ─── */
[data-theme="nature"] .ck{color:#15803d}
[data-theme="nature"] .pill{border-color:rgba(22,163,74,.18);background:rgba(22,163,74,.05)}

/* ─── Nature misc ─── */
[data-theme="nature"] .sq-desc-txt{color:rgba(22,163,74,.5)}
[data-theme="nature"] .sq-idx{color:rgba(22,163,74,.3)}
[data-theme="nature"] .sq-past .sq-idx{color:rgba(22,163,74,.55)}
[data-theme="nature"] .sq-step:hover{background:rgba(22,163,74,.04)}
[data-theme="nature"] .hg-bar{background:rgba(22,163,74,.07)}
[data-theme="nature"] .hg-total{color:#4a7a5a}

/* ─── Nature theme toggle ─── */
[data-theme="nature"] .theme-sw{border-color:rgba(22,163,74,.25);box-shadow:none;color:#15803d}
[data-theme="nature"] .lang-sw{border-color:rgba(22,163,74,.2);color:#15803d}

/* ─── Nature M3 components ─── */
[data-theme="nature"] .m3-load-panel{border-color:rgba(22,163,74,.12);background:rgba(255,255,255,.7)}
[data-theme="nature"] .m3-load-hdr{background:rgba(22,163,74,.04);color:#1a3a2a}
[data-theme="nature"] .m3-load-item{border-color:rgba(22,163,74,.1)}
[data-theme="nature"] .m3-load-item.loaded{border-color:rgba(22,163,74,.22);background:rgba(22,163,74,.04)}
[data-theme="nature"] .m3-ap{border-color:rgba(22,163,74,.14);background:rgba(255,255,255,.65)}
[data-theme="nature"] .m3-ap-badge.done{background:rgba(22,163,74,.1);color:#16a34a}
[data-theme="nature"] .m3-ap-badge.running{background:rgba(180,83,9,.08);color:#b45309}
[data-theme="nature"] .m3-ap-badge.error{background:rgba(220,38,38,.08);color:#dc2626}

/* ─── Nature M5 network nodes ─── */
[data-theme="nature"] .m5-net-node{border-color:rgba(22,163,74,.15);background:rgba(255,255,255,.8)}
[data-theme="nature"] .m5-net-node.up .m5-led{background:#16a34a;box-shadow:0 0 6px rgba(22,163,74,.4)}
[data-theme="nature"] .m5-cond-tbl th{background:rgba(22,163,74,.06);color:#4a7a5a;border-color:rgba(22,163,74,.1)}
[data-theme="nature"] .m5-cond-tbl td{border-color:rgba(22,163,74,.08)}
[data-theme="nature"] .m5-cond-tbl tr:hover{background:rgba(22,163,74,.04)}

/* ─── Nature M6 RUL ─── */
[data-theme="nature"] .m6-cat{border-color:rgba(22,163,74,.12);background:rgba(255,255,255,.7)}
[data-theme="nature"] .m6-cat:hover{border-color:rgba(22,163,74,.28);box-shadow:0 2px 10px rgba(22,163,74,.06)}

html{scroll-behavior:smooth}
body{font-family:'Plus Jakarta Sans','Prompt',system-ui;background:var(--bg);color:var(--tx);min-height:100vh;overflow-x:hidden}
body::before{
  content:'';position:fixed;inset:0;z-index:0;pointer-events:none;
  background:
    radial-gradient(ellipse 80% 60% at 10% 5%,var(--body-g1),transparent 50%),
    radial-gradient(ellipse 60% 50% at 90% 90%,var(--body-g2),transparent 45%),
    radial-gradient(ellipse 50% 40% at 50% 50%,var(--body-g3),transparent 40%);
}
body::after{
  content:'';position:fixed;inset:0;z-index:0;pointer-events:none;opacity:.06;
  background-image:
    linear-gradient(var(--grid-c) 1px,transparent 1px),
    linear-gradient(90deg,var(--grid-c) 1px,transparent 1px);
  background-size:80px 80px;
}
body>*{position:relative;z-index:1}
::-webkit-scrollbar{width:4px}
::-webkit-scrollbar-track{background:rgba(255,255,255,.02)}
::-webkit-scrollbar-thumb{background:var(--bdr2);border-radius:2px}

/* ═══ HEADER ═══ */
.hdr{padding:0 32px;height:56px;display:flex;align-items:center;justify-content:space-between;background:var(--hdr-bg);backdrop-filter:blur(30px) saturate(1.6);border-bottom:1px solid var(--hdr-bdr);box-shadow:0 1px 12px var(--hdr-sh);position:sticky;top:0;z-index:100}
.logo{display:flex;align-items:center;gap:12px}
.lm{height:38px;object-fit:contain;filter:drop-shadow(0 1px 4px rgba(0,0,0,.08))}
.ln{font-size:.95em;font-weight:800;letter-spacing:3px;text-transform:uppercase;color:var(--h-tx)}
.ln b{color:var(--h-acc)}
.ld{font-size:.55em;font-weight:400;letter-spacing:3.5px;color:var(--h-dim);text-transform:uppercase;margin-top:-1px}
.hr{display:flex;align-items:center;gap:14px}
.ck{font-family:'JetBrains Mono';font-size:.72em;color:var(--h-dim);letter-spacing:1px}
.lang-sw{cursor:pointer;font-family:'JetBrains Mono';font-size:.68em;font-weight:700;letter-spacing:1px;padding:4px 12px;border-radius:14px;border:1px solid var(--pill-bdr);color:var(--h-dim);transition:.2s;user-select:none}
.lang-sw:hover{border-color:var(--h-acc);color:var(--h-acc)}
.theme-sw{cursor:pointer;font-size:1.1em;padding:2px 10px;border-radius:14px;border:1px solid var(--pill-bdr);color:var(--h-dim);transition:.2s;user-select:none;line-height:1.4}
.theme-sw:hover{border-color:var(--h-acc);color:var(--h-acc)}
.hist-controls{display:flex;flex-wrap:wrap;gap:16px;align-items:flex-end}
.hist-group{display:flex;flex-direction:column;gap:6px}
.hist-group label{font-size:.65em;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:var(--dim)}
.hist-btns{display:flex;gap:4px;flex-wrap:wrap}
.hist-btn{padding:6px 14px;border:1px solid var(--bdr);border-radius:var(--Rs);background:#fff;color:var(--tx);font-size:.72em;font-weight:600;cursor:pointer;transition:.2s;font-family:'Plus Jakarta Sans','Prompt'}
.hist-btn:hover{border-color:var(--cy);color:var(--cy)}
.hist-btn.on{background:var(--cy);color:#fff;border-color:var(--cy)}
.hist-dt{padding:6px 10px;border:1px solid var(--bdr);border-radius:var(--Rs);background:#fff;color:var(--tx2);font-size:.75em;font-family:'JetBrains Mono';outline:none;transition:.2s;min-width:190px}
.hist-dt:focus{border-color:var(--cy);box-shadow:0 0 0 3px var(--cyg)}
.tele-live{display:flex;align-items:center;gap:8px;font-family:'JetBrains Mono';font-size:.65em}
.tele-st{color:var(--dim);font-weight:600}
.tele-ts{color:var(--mut);font-size:.92em}
.ht-wrap{position:relative;overflow-x:auto;padding-bottom:10px;display:flex;justify-content:center}
.ht-canvas{position:relative;display:inline-flex;align-items:stretch;min-width:1320px;margin:0 auto}
.ht-svg{position:absolute;top:0;left:0;pointer-events:none;z-index:1;overflow:visible}
.ht-col{display:flex;flex-direction:column;position:relative;z-index:2}
.ht-col-c{width:340px;gap:2px;padding-top:6px}
.ht-col-e{width:160px;position:relative;margin-left:80px}
.ht-col-r{flex:1;display:flex;align-items:center;justify-content:center;margin-left:80px;min-width:320px}
.cn{display:flex;align-items:center;gap:5px;padding:4px 8px;border-radius:6px;border:1px solid var(--bdr);border-left:2px solid var(--bdr);background:var(--card);cursor:default;transition:.2s;font-size:.6em;height:28px;overflow:hidden;flex-wrap:nowrap;min-width:0}
.cn:hover{border-color:var(--dim);background:var(--card2,var(--card))}
.cn.alarm{border-color:var(--rd);border-left-color:var(--rd);background:rgba(239,68,68,.03);box-shadow:0 0 0 1px rgba(239,68,68,.06)}
[data-tp="ai"] .cn{border-left-color:#a855f7}
[data-tp="hy"] .cn{border-left-color:#06b6d4}
[data-tp="rl"] .cn{border-left-color:#94a3b8}
[data-tp="ai"] .cn.alarm{border-left-color:#a855f7}
[data-tp="hy"] .cn.alarm{border-left-color:#06b6d4}
[data-tp="rl"] .cn.alarm{border-left-color:#dc2626}
.cn-n{font-family:'JetBrains Mono';font-size:.9em;font-weight:700;color:#fff;border-radius:4px;padding:1px 5px;min-width:18px;text-align:center;flex-shrink:0;display:inline-flex;align-items:center;gap:2px;text-shadow:0 1px 1px rgba(0,0,0,.15)}
.cn-n::before{content:'';display:inline-block;width:9px;height:9px;flex-shrink:0;background:currentColor;-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;opacity:.92}
[data-tp="ai"] .cn-n{background:linear-gradient(135deg,#7c3aed,#a855f7);box-shadow:0 1px 3px rgba(124,58,237,.3)}
[data-tp="hy"] .cn-n{background:linear-gradient(135deg,#0284c7,#06b6d4);box-shadow:0 1px 3px rgba(2,132,199,.3)}
[data-tp="rl"] .cn-n{background:linear-gradient(135deg,#475569,#64748b);box-shadow:0 1px 3px rgba(71,85,105,.3)}
[data-tp="ai"] .cn-n::before{-webkit-mask-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10' fill='none' stroke='white' stroke-width='1.2'%3E%3Ccircle cx='5' cy='4' r='2.2'/%3E%3Cpath d='M3.5 6.5C3.5 5.5 4 5 5 5s1.5.5 1.5 1.5'/%3E%3Cline x1='5' y1='1' x2='5' y2='1.8'/%3E%3Cline x1='7.5' y1='2.5' x2='6.9' y2='3'/%3E%3Cline x1='2.5' y1='2.5' x2='3.1' y2='3'/%3E%3Cpath d='M3 8h4' stroke-linecap='round'/%3E%3Cpath d='M3.8 9h2.4' stroke-linecap='round'/%3E%3C/svg%3E");mask-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10' fill='none' stroke='white' stroke-width='1.2'%3E%3Ccircle cx='5' cy='4' r='2.2'/%3E%3Cpath d='M3.5 6.5C3.5 5.5 4 5 5 5s1.5.5 1.5 1.5'/%3E%3Cline x1='5' y1='1' x2='5' y2='1.8'/%3E%3Cline x1='7.5' y1='2.5' x2='6.9' y2='3'/%3E%3Cline x1='2.5' y1='2.5' x2='3.1' y2='3'/%3E%3Cpath d='M3 8h4' stroke-linecap='round'/%3E%3Cpath d='M3.8 9h2.4' stroke-linecap='round'/%3E%3C/svg%3E")}
[data-tp="hy"] .cn-n::before{-webkit-mask-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10' fill='none' stroke='white' stroke-width='1.2'%3E%3Cpath d='M5.5 1L3 5.5h2L4.5 9 7 4.5H5z'/%3E%3Ccircle cx='5' cy='5' r='4' stroke-dasharray='2 1.5'/%3E%3C/svg%3E");mask-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10' fill='none' stroke='white' stroke-width='1.2'%3E%3Cpath d='M5.5 1L3 5.5h2L4.5 9 7 4.5H5z'/%3E%3Ccircle cx='5' cy='5' r='4' stroke-dasharray='2 1.5'/%3E%3C/svg%3E")}
[data-tp="rl"] .cn-n::before{-webkit-mask-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10' fill='none' stroke='white' stroke-width='1.2'%3E%3Cpath d='M5 1L1.5 3v3c0 2.2 1.5 3.2 3.5 4 2-0.8 3.5-1.8 3.5-4V3z'/%3E%3Cpath d='M3.5 5.2l1 1 2-2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");mask-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10' fill='none' stroke='white' stroke-width='1.2'%3E%3Cpath d='M5 1L1.5 3v3c0 2.2 1.5 3.2 3.5 4 2-0.8 3.5-1.8 3.5-4V3z'/%3E%3Cpath d='M3.5 5.2l1 1 2-2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")}
[data-tp="ai"] .cn-n:hover{box-shadow:0 2px 6px rgba(124,58,237,.4)}
[data-tp="hy"] .cn-n:hover{box-shadow:0 2px 6px rgba(2,132,199,.4)}
[data-tp="rl"] .cn-n:hover{box-shadow:0 2px 6px rgba(71,85,105,.4)}
.cn-t{font-weight:600;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cn-v{font-family:'JetBrains Mono';font-size:.85em;font-weight:500;color:var(--dim);flex-shrink:0;max-width:72px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cn-b{font-family:'JetBrains Mono';font-size:.82em;font-weight:700;padding:1px 6px;border-radius:8px;flex-shrink:0}
.cn-b.ok{background:rgba(16,185,129,.08);color:#059669}
.cn-b.al{background:rgba(239,68,68,.08);color:#dc2626}
.gs{height:28px;flex-shrink:0}
.m2-tree-wrap .gs{height:76px}
.m2-ht-wrap .gs{height:48px}
.m3-tree-wrap .gs{height:60px}
.sc-tbl{width:100%;border-collapse:collapse;font-size:.68em}
.sc-tbl th{text-align:left;padding:8px 10px;background:var(--card);color:var(--dim);font-weight:700;text-transform:uppercase;letter-spacing:.5px;font-size:.85em;border-bottom:2px solid var(--bdr);position:sticky;top:0;z-index:2}
.sc-tbl td{padding:6px 10px;border-bottom:1px solid var(--bdr);vertical-align:top;line-height:1.45}
.sc-tbl tr:hover{background:rgba(2,132,199,.02)}
.sc-tbl code{font-family:'JetBrains Mono';font-size:.88em;background:rgba(0,0,0,.04);padding:1px 4px;border-radius:3px;color:var(--tx2);word-break:break-all}
.sc-grp{background:var(--card) !important}
.sc-grp td{font-weight:700;font-size:.95em;padding:10px;color:var(--tx);letter-spacing:.3px}
.sc-id{font-family:'JetBrains Mono';font-weight:700;font-size:.9em;background:var(--dim);color:#fff;padding:2px 6px;border-radius:4px}
.sc-id.sc-ai{background:linear-gradient(135deg,#7c3aed,#a855f7);box-shadow:0 1px 2px rgba(124,58,237,.25)}
.sc-id.sc-hy{background:linear-gradient(135deg,#0284c7,#06b6d4);box-shadow:0 1px 2px rgba(2,132,199,.25)}
.sc-id.sc-rl{background:linear-gradient(135deg,#475569,#64748b);box-shadow:0 1px 2px rgba(71,85,105,.25)}
.sc-tp{font-family:'JetBrains Mono';font-weight:700;font-size:.8em;padding:2px 6px;border-radius:4px;white-space:nowrap;display:inline-block;text-align:center;min-width:44px}
.sc-tp.sc-ai{background:rgba(139,92,246,.08);color:#7c3aed}
.sc-tp.sc-hy{background:rgba(2,132,199,.08);color:#0284c7}
.sc-tp.sc-rl{background:rgba(100,116,139,.08);color:#475569}
[data-theme="dark"]{
  --bg:#0f172a;--surface:#1e293b;
  --card:#1e293b;--card-s:#1e293b;
  --glass:#1e293b;--gb:rgba(51,65,85,.5);
  --bdr:rgba(51,65,85,.5);--bdr2:rgba(71,85,105,.6);
  --tx:#cbd5e1;--tx2:#e2e8f0;--dim:#94a3b8;--mut:#64748b;
  --cy:#38bdf8;--cyd:#0ea5e9;--cyg:rgba(56,189,248,.08);
  --gn:#34d399;--gng:rgba(52,211,153,.08);
  --rd:#f87171;--rdg:rgba(248,113,113,.08);
  --am:#fbbf24;--amg:rgba(251,191,36,.08);
  --pu:#a78bfa;--pug:rgba(167,139,250,.1);--pk:#f472b6;--tl:#2dd4bf;
  --hdr-bg:rgba(15,23,42,.92);--hdr-bdr:rgba(51,65,85,.5);--hdr-sh:rgba(0,0,0,.25);
  --tab-bg:rgba(15,23,42,.8);
  --h-tx:#f1f5f9;--h-dim:#94a3b8;--h-acc:#38bdf8;--h-acc2:#e2e8f0;
  --pill-bg:rgba(56,189,248,.06);--pill-bdr:rgba(56,189,248,.12);
  --grid-c:rgba(148,163,184,.06);
  --body-g1:rgba(56,189,248,.04);--body-g2:rgba(167,139,250,.03);--body-g3:rgba(52,211,153,.02);
  --led-off:#f87171;--led-on:#34d399;
}
/* ─── Dark body ─── */
[data-theme="dark"] body::before{
  background:
    radial-gradient(ellipse 80% 60% at 10% 5%,rgba(56,189,248,.05),transparent 50%),
    radial-gradient(ellipse 60% 50% at 90% 90%,rgba(167,139,250,.04),transparent 45%),
    radial-gradient(ellipse 50% 40% at 50% 50%,rgba(52,211,153,.03),transparent 40%);
}
[data-theme="dark"] body::after{opacity:.03}
/* ─── Dark header / tabs ─── */
[data-theme="dark"] .hdr{box-shadow:0 1px 16px rgba(0,0,0,.3)}
[data-theme="dark"] .tbs{border-color:rgba(51,65,85,.4)}
[data-theme="dark"] .tb.on{color:#38bdf8;border-color:rgba(56,189,248,.25)}
/* ─── Dark cards ─── */
[data-theme="dark"] .cd{background:#1e293b;border-color:rgba(51,65,85,.5);backdrop-filter:none}
[data-theme="dark"] .cd:hover{border-color:rgba(71,85,105,.6);box-shadow:0 4px 16px rgba(0,0,0,.2)}
[data-theme="dark"] .ct i{filter:none}
/* ─── Dark buttons ─── */
[data-theme="dark"] .bt{border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .bgh{background:rgba(56,189,248,.08);border-color:rgba(56,189,248,.15);color:#38bdf8}
[data-theme="dark"] .bgh:hover{box-shadow:0 0 14px rgba(56,189,248,.1);border-color:rgba(56,189,248,.3)}
/* ─── Dark inputs ─── */
[data-theme="dark"] input[type=number],[data-theme="dark"] select,[data-theme="dark"] .hist-dt{background:rgba(15,23,42,.5);border-color:rgba(51,65,85,.5);color:#e2e8f0}
[data-theme="dark"] input[type=number]:focus,[data-theme="dark"] select:focus{border-color:rgba(56,189,248,.3);box-shadow:0 0 10px rgba(56,189,248,.06)}
/* ─── Dark condition rows ─── */
[data-theme="dark"] .cn{background:#1e293b;border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .cn:hover{border-color:rgba(71,85,105,.6);box-shadow:0 0 8px rgba(0,0,0,.15)}
[data-theme="dark"] .cn.alarm{border-color:rgba(248,113,113,.3);background:rgba(248,113,113,.06);box-shadow:0 0 8px rgba(248,113,113,.05)}
/* ─── Dark equipment nodes (Health Tree) ─── */
[data-theme="dark"] .en{background:#1e293b;box-shadow:0 2px 8px rgba(0,0,0,.2)}
/* ─── Dark gauge ─── */
[data-theme="dark"] .rn-gauge .rg-outer-track{stroke:rgba(148,163,184,.06)}
[data-theme="dark"] .rn-gauge .rg-inner-track{stroke:rgba(148,163,184,.05)}
[data-theme="dark"] .rn-gauge .rg-zone-label{fill:#64748b}
[data-theme="dark"] .rn-gauge #rgVal{fill:#f1f5f9}
[data-theme="dark"] .rn-gauge #rgNeedle .rg-needle-body{fill:#e2e8f0}
[data-theme="dark"] .rn-gauge #rgNeedle .rg-needle-hub{fill:#1e293b;stroke:#94a3b8}
[data-theme="dark"] .rn-gauge #rgNeedle .rg-needle-dot{fill:#e2e8f0}
[data-theme="dark"] .rn-pill{background:rgba(52,211,153,.08);border-color:rgba(52,211,153,.15)}
/* ─── Dark gauge bar ─── */
[data-theme="dark"] .hg-bar{background:rgba(148,163,184,.08);box-shadow:inset 0 1px 2px rgba(0,0,0,.25)}
[data-theme="dark"] .hg-total{color:#e2e8f0}
/* ─── Dark sequence panel (HEAD 1 / HEAD 2) ─── */
[data-theme="dark"] .sq-panel{background:#1e293b;border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .sq-node-inner{background:#1e293b;border-color:rgba(71,85,105,.6)}
[data-theme="dark"] .sq-past .sq-node-inner{border-color:rgba(148,163,184,.5);background:rgba(148,163,184,.35)}
[data-theme="dark"] .sq-wire{background:rgba(148,163,184,.08)}
[data-theme="dark"] .sq-lbl{color:rgba(148,163,184,.6)}
[data-theme="dark"] .sq-past .sq-lbl{color:rgba(148,163,184,.75)}
[data-theme="dark"] .sq-idx{color:rgba(148,163,184,.3)}
[data-theme="dark"] .sq-past .sq-idx{color:rgba(148,163,184,.5)}
[data-theme="dark"] .sq-progress{background:rgba(148,163,184,.08)}
[data-theme="dark"] .sq-desc-item{background:#1e293b;border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .sq-desc-txt{color:rgba(148,163,184,.55)}
[data-theme="dark"] .sq-to{color:rgba(148,163,184,.4);border-color:rgba(148,163,184,.08);background:rgba(148,163,184,.04)}
[data-theme="dark"] .sq-step:hover{background:rgba(148,163,184,.04)}
[data-theme="dark"] .sq-col-head{background:rgba(148,163,184,.05)!important;border-color:rgba(51,65,85,.4)!important}
/* ─── Dark rule tree ─── */
[data-theme="dark"] .rt-r{background:#1e293b;border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .rt-r:hover{border-color:rgba(71,85,105,.6)}
[data-theme="dark"] .rt-gn{background:#1e293b;border-color:rgba(51,65,85,.5)}
/* ─── Dark standard reference table ─── */
[data-theme="dark"] .sc-tp.sc-ai{background:rgba(167,139,250,.12);color:#c4b5fd}
[data-theme="dark"] .sc-tp.sc-hy{background:rgba(56,189,248,.1);color:#7dd3fc}
[data-theme="dark"] .sc-tp.sc-rl{background:rgba(148,163,184,.1);color:#cbd5e1}
[data-theme="dark"] .sc-ai-note{color:#c4b5fd}
[data-theme="dark"] .sc-tbl th{background:rgba(148,163,184,.06);color:#94a3b8;border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .sc-tbl td{border-color:rgba(51,65,85,.4)}
[data-theme="dark"] .sc-tbl tr:hover{background:rgba(148,163,184,.04)}
[data-theme="dark"] .sc-tbl code{background:rgba(56,189,248,.06);color:#38bdf8}
[data-theme="dark"] .do-tbl th{background:rgba(148,163,184,.06);color:#94a3b8;border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .do-tbl td{border-color:rgba(51,65,85,.4)}
[data-theme="dark"] .do-tbl tr:hover{background:rgba(148,163,184,.04)}
[data-theme="dark"] .do-tbl tr.do-alarm{background:rgba(239,68,68,.08)}
[data-theme="dark"] .do-sum{background:rgba(30,41,59,.6);border-color:rgba(51,65,85,.5)}
/* ─── Dark sidebar ─── */
[data-theme="dark"] .sidebar{background:rgba(15,23,42,.96);border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .sb-icon{background:rgba(148,163,184,.06)}
[data-theme="dark"] .sb-toggle-icon{background:rgba(148,163,184,.06)}
[data-theme="dark"] .sb-item.sb-active{background:rgba(56,189,248,.06);border-color:rgba(56,189,248,.15)}
[data-theme="dark"] .sb-item.sb-active .sb-icon{background:linear-gradient(135deg,#0ea5e9,#38bdf8);box-shadow:0 0 10px rgba(56,189,248,.25)}
[data-theme="dark"] .sb-badge-live{background:rgba(52,211,153,.1);color:#34d399}
[data-theme="dark"] .sb-badge-soon{background:rgba(148,163,184,.08);color:#64748b}
/* ─── Dark scrollbar ─── */
[data-theme="dark"] ::-webkit-scrollbar-thumb{background:rgba(148,163,184,.15)}
[data-theme="dark"] ::-webkit-scrollbar-track{background:rgba(0,0,0,.1)}
/* ─── Dark LED ─── */
[data-theme="dark"] .led.on{background:#34d399;box-shadow:0 0 8px rgba(52,211,153,.4)}
/* ─── Dark auto-predict ─── */
[data-theme="dark"] .ap-timer.ap-on{color:#34d399}
[data-theme="dark"] .ap-timer.ap-run{color:#38bdf8}
.sc-th{font-family:'JetBrains Mono';font-weight:700;font-size:.95em;color:var(--rd);background:rgba(220,38,38,.06);padding:2px 8px;border-radius:4px;white-space:nowrap}
.sc-std{font-weight:700;color:var(--cy);display:inline-block;margin-bottom:2px}
.sc-std.sc-na{color:var(--dim);font-style:italic}
.sc-ai-note{display:inline-block;font-family:'JetBrains Mono';font-size:.82em;font-weight:600;color:#7c3aed;margin-top:2px;opacity:.8}
.sc-eq{font-weight:700;font-size:.92em}
.do-wrap{overflow-x:auto}
.do-tbl{width:100%;border-collapse:collapse;font-size:.7em;font-family:'JetBrains Mono','Plus Jakarta Sans',monospace}
.do-tbl th{text-align:left;padding:7px 8px;background:var(--card);color:var(--dim);font-weight:700;text-transform:uppercase;letter-spacing:.4px;font-size:.82em;border-bottom:2px solid var(--bdr);position:sticky;top:0;z-index:2}
.do-tbl td{padding:5px 8px;border-bottom:1px solid var(--bdr);vertical-align:middle;line-height:1.4}
.do-tbl tr:hover{background:rgba(99,102,241,.04)}
.do-tbl tr.do-alarm{background:rgba(239,68,68,.06)}
.do-tbl tr.do-alarm:hover{background:rgba(239,68,68,.1)}
.do-tbl tr.do-warn{background:rgba(217,119,6,.05)}
.do-sum{display:flex;gap:12px;flex-wrap:wrap;align-items:center;padding:10px 14px;border-radius:10px;background:var(--card);border:1px solid var(--bdr);margin-bottom:12px}
.do-chip{display:flex;align-items:center;gap:5px;font-size:.72em;font-weight:600;font-family:'JetBrains Mono';padding:4px 10px;border-radius:6px}
.do-chip-ok{background:rgba(22,163,74,.08);color:#16a34a}
.do-chip-warn{background:rgba(217,119,6,.08);color:#d97706}
.do-chip-alarm{background:rgba(239,68,68,.08);color:#ef4444}
.do-val{font-family:'JetBrains Mono';font-weight:600;font-size:.95em}
.do-out{display:flex;flex-direction:column;gap:2px}
.do-out-rule,.do-out-ai{display:flex;align-items:center;gap:4px;font-size:.9em;white-space:nowrap}
.do-out-rule .do-lbl{color:var(--dim);font-size:.85em;min-width:32px}
.do-out-ai .do-lbl{color:#7c3aed;font-size:.85em;min-width:32px}
.do-badge{display:inline-flex;align-items:center;gap:3px;padding:2px 8px;border-radius:4px;font-weight:700;font-size:.88em;white-space:nowrap}
.do-ok{background:rgba(22,163,74,.1);color:#16a34a}
.do-warn{background:rgba(217,119,6,.1);color:#d97706}
.do-alarm{background:rgba(239,68,68,.1);color:#ef4444}
.do-na{background:rgba(100,116,139,.06);color:var(--dim);font-style:italic}
.do-ts{font-size:.7em;color:var(--dim);font-family:'JetBrains Mono';margin-left:auto}
.en{padding:10px 14px;border-radius:8px;border:2px solid;font-size:.7em;font-weight:700;text-align:center;background:var(--card);box-shadow:0 2px 8px rgba(0,0,0,.06);white-space:nowrap;position:absolute;left:0;right:0;transform:translateY(-50%)}
.en-c{font-family:'JetBrains Mono';font-size:.78em;font-weight:500;color:var(--dim);margin-top:2px}
.rn{padding:0;text-align:center;transition:all .5s;background:none;border:none;box-shadow:none}
.rn-h{font-size:.82em;font-weight:800;color:#16a34a;line-height:1.3;margin-top:4px;transition:color .4s;letter-spacing:.3px}
.rn-s{font-size:.55em;color:var(--dim);margin-top:1px}
.rn-cnt{font-family:'JetBrains Mono';font-size:.52em;font-weight:600;color:var(--dim);margin-top:4px}
.rn-gauge-wrap{display:flex;flex-direction:column;align-items:center;position:relative}
.rn-gauge{width:300px;height:190px;display:block}
.rn-gauge #rgNeedle{transition:transform .9s cubic-bezier(.34,1.56,.64,1)}
.rn-gauge .rg-fill{transition:stroke-dashoffset .9s cubic-bezier(.4,0,.2,1),opacity .4s ease}
.rn-pill{display:inline-flex;align-items:center;gap:6px;padding:4px 14px 4px 10px;border-radius:20px;margin-top:6px;transition:all .4s;background:rgba(22,163,74,.08);border:1px solid rgba(22,163,74,.15)}
.rn-pill-dot{width:7px;height:7px;border-radius:50%;transition:all .4s;flex-shrink:0}
.rn-pill-txt{font-family:'JetBrains Mono';font-size:.62em;font-weight:800;letter-spacing:2px;text-transform:uppercase;transition:color .4s}
@keyframes rg-scan{0%{stroke-dashoffset:392.7}100%{stroke-dashoffset:0}}
.rn-gauge .rg-scan{animation:rg-scan 4s linear infinite;opacity:.04}
.ht-summary{font-family:'JetBrains Mono';font-size:.95em;font-weight:700;margin-left:8px}
.ht-ok{color:var(--gn)}.ht-alarm{color:var(--rd)}
/* Gauge Bar */
.hg-wrap{padding:0 4px;margin-bottom:10px}
.hg-bar{display:flex;height:10px;border-radius:6px;overflow:hidden;background:rgba(0,0,0,.04);box-shadow:inset 0 1px 2px rgba(0,0,0,.06)}
.hg-seg{height:100%;transition:width .6s cubic-bezier(.4,0,.2,1);min-width:0}
.hg-normal{background:linear-gradient(90deg,#16a34a,#22c55e);border-radius:6px 0 0 6px}
.hg-warn{background:linear-gradient(90deg,#d97706,#f59e0b)}
.hg-alarm{background:linear-gradient(90deg,#ef4444,#f87171);border-radius:0 6px 6px 0}
.hg-seg:first-child:last-child{border-radius:6px}
.hg-seg:first-child{border-radius:6px 0 0 6px}
.hg-seg:last-child{border-radius:0 6px 6px 0}
.hg-labels{display:flex;align-items:center;gap:14px;margin-top:6px;font-family:'JetBrains Mono';font-size:.55em;font-weight:600}
.hg-lbl{display:flex;align-items:center;gap:4px;color:var(--dim)}
.hg-lbl strong{font-weight:800;font-size:1.1em}
.hg-lbl-normal strong{color:#16a34a}
.hg-lbl-warn strong{color:#d97706}
.hg-lbl-alarm strong{color:#ef4444}
.hg-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;box-shadow:0 0 4px rgba(0,0,0,.1)}
.hg-total{margin-left:auto;font-weight:800;color:var(--tx2);font-size:1.05em;letter-spacing:.5px}

.tele-live .led.on{background:var(--led-on);box-shadow:0 0 6px var(--led-on)}
.fi input[readonly]{background:transparent;cursor:default;border-color:transparent;font-weight:700;color:var(--tx2);text-align:center;font-size:.82em;padding:4px 4px;letter-spacing:-.3px}
.hist-chart-wrap{position:relative;height:400px;margin-top:12px}
.hist-chart-wrap canvas{width:100%!important;height:100%!important}
.hist-chart-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px}
.hist-info{font-family:'JetBrains Mono';font-size:.65em;color:var(--dim)}
.hist-loading{display:flex;align-items:center;justify-content:center;gap:10px;padding:60px;color:var(--dim);font-size:.85em}
.hist-spinner{width:20px;height:20px;border:3px solid var(--bdr);border-top-color:var(--cy);border-radius:50%;animation:hspin .6s linear infinite}
@keyframes hspin{to{transform:rotate(360deg)}}
.hist-empty{color:var(--dim);font-size:.8em;text-align:center;padding:60px;font-style:italic}
.hist-err,.hist-warn{font-style:normal;text-align:left;padding:24px 28px;border-radius:var(--Rs);border:1px solid var(--bdr)}
.hist-err{background:rgba(220,38,38,.04);border-color:rgba(220,38,38,.25)}
.hist-warn{background:rgba(217,119,6,.04);border-color:rgba(217,119,6,.25)}
.he-title{font-size:1em;font-weight:700;margin-bottom:12px;letter-spacing:.5px}
.hist-err .he-title{color:var(--rd)}
.hist-warn .he-title{color:var(--am)}
.he-row{display:flex;gap:10px;align-items:flex-start;margin-bottom:6px;font-size:.82em;line-height:1.5}
.he-row span{flex-shrink:0;width:70px;font-weight:700;color:var(--dim);text-transform:uppercase;font-size:.8em;letter-spacing:.5px;padding-top:3px}
.he-row code{font-family:'JetBrains Mono';font-size:.92em;color:var(--tx2);background:rgba(0,0,0,.04);padding:2px 8px;border-radius:4px;word-break:break-all;line-height:1.6}
.he-hint{margin-top:12px;padding:10px 14px;border-radius:var(--Rs);background:rgba(2,132,199,.05);border:1px solid rgba(2,132,199,.15);font-size:.78em;color:var(--cy);line-height:1.6}
.hist-stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px}
.hist-stat-card{padding:12px 16px;border-radius:var(--Rs);border:1px solid var(--bdr);background:#fff}
.hist-stat-card .hs-label{font-size:.6em;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--dim);margin-bottom:4px}
.hist-stat-card .hs-val{font-family:'JetBrains Mono';font-size:1.1em;font-weight:700;color:var(--tx2)}
.hist-stat-card .hs-row{display:flex;justify-content:space-between;font-family:'JetBrains Mono';font-size:.7em;color:var(--dim);margin-top:2px}
.hist-stat-card .hs-row span:last-child{font-weight:600;color:var(--tx)}
.station-selector{position:relative;margin-right:8px}
.station-current{display:flex;align-items:center;gap:8px;cursor:pointer;padding:4px 12px;border-radius:12px;border:1px solid var(--bdr);background:var(--card);transition:all .2s ease}
.station-current:hover{border-color:var(--ac);box-shadow:0 0 8px rgba(14,165,233,.15)}
.station-ico{font-size:1.1em}
.station-info{display:flex;flex-direction:column;min-width:80px}
.station-sn{font-size:.7em;font-weight:800;font-family:'JetBrains Mono',monospace;color:var(--ac);letter-spacing:.5px}
.station-name{font-size:.55em;color:var(--dim);white-space:nowrap;max-width:160px;overflow:hidden;text-overflow:ellipsis}
.station-arrow{font-size:.5em;color:var(--dim);transition:transform .2s ease}
.station-arrow.open{transform:rotate(180deg)}
.station-dropdown{display:none;position:absolute;top:calc(100% + 6px);right:0;width:380px;max-height:420px;background:var(--card);border:1px solid var(--bdr);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.25);z-index:9999;overflow:hidden}
.station-dropdown.show{display:block;animation:stFadeIn .2s ease}
@keyframes stFadeIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.station-search-wrap{padding:10px 12px;border-bottom:1px solid var(--bdr)}
.station-search{width:100%;padding:8px 12px;border-radius:8px;border:1px solid var(--bdr);background:var(--bg);color:var(--tx);font-size:.8em;outline:none;font-family:inherit}
.station-search:focus{border-color:var(--ac);box-shadow:0 0 0 3px rgba(14,165,233,.12)}
.station-search::placeholder{color:var(--dim)}
.station-list{max-height:330px;overflow-y:auto;padding:4px}
.station-list::-webkit-scrollbar{width:5px}
.station-list::-webkit-scrollbar-thumb{background:var(--bdr);border-radius:3px}
.station-item{display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:8px;cursor:pointer;transition:background .15s ease}
.station-item:hover{background:rgba(14,165,233,.08)}
.station-item.active{background:rgba(14,165,233,.12);border-left:3px solid var(--ac)}
.station-item-ico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.9em;background:linear-gradient(135deg,rgba(14,165,233,.15),rgba(14,165,233,.05));flex-shrink:0}
.station-item-info{flex:1;min-width:0}
.station-item-sn{font-size:.72em;font-weight:800;font-family:'JetBrains Mono',monospace;color:var(--tx)}
.station-item-name{font-size:.6em;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.station-item-modules{display:flex;gap:2px;flex-shrink:0}
.station-item-mod{font-size:.45em;padding:1px 4px;border-radius:4px;font-weight:700;color:#fff}
.station-loading{text-align:center;padding:20px;color:var(--dim);font-size:.75em}
.station-empty{text-align:center;padding:20px;color:var(--dim);font-size:.75em}
.pill{display:flex;align-items:center;gap:7px;font-size:.7em;font-weight:500;color:var(--h-dim);background:var(--pill-bg);backdrop-filter:blur(8px);padding:5px 14px;border-radius:18px;border:1px solid var(--pill-bdr)}
.led{width:6px;height:6px;border-radius:50%;background:var(--led-off);transition:.3s}
.led.on{background:var(--led-on);box-shadow:0 0 8px var(--led-on),0 0 2px var(--led-on)}

/* ═══ TABS ═══ */
.tbs{display:flex;padding:0 32px;background:var(--tab-bg);backdrop-filter:blur(20px);border-bottom:1px solid var(--hdr-bdr);position:sticky;top:56px;z-index:90}
.tb{padding:12px 26px;font-size:.75em;font-weight:600;cursor:pointer;color:var(--h-dim);letter-spacing:1px;text-transform:uppercase;border-bottom:2px solid transparent;transition:.2s;position:relative}
.tb:hover{color:var(--h-acc2)}
.tb.on{color:var(--h-acc);border-color:var(--h-acc)}
.tb.on::after{content:'';position:absolute;bottom:0;left:30%;right:30%;height:1px;background:var(--h-acc);filter:blur(3px)}
.tc{display:none;animation:fu .45s ease}.tc.on{display:block}
@keyframes fu{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

/* ═══ LAYOUT ═══ */
.pg{padding:20px 28px;max-width:1520px;margin:0 auto}
.rw{display:grid;gap:14px;margin-bottom:14px}
.c2{grid-template-columns:1fr 1fr}.c4{grid-template-columns:repeat(4,1fr)}
.c28{grid-template-columns:2.5fr 8fr}.c55{grid-template-columns:1fr 1fr}.c64{grid-template-columns:6fr 4fr}

/* ═══ CARD ═══ */
.cd{background:var(--glass);border:1px solid var(--gb);border-radius:var(--R);padding:20px;position:relative;overflow:hidden;transition:border-color .35s}
.cd::before{display:none}
.cd:hover{border-color:var(--bdr2)}
.cg:hover{border-color:var(--bdr2)}
.ct{font-size:.62em;font-weight:700;text-transform:uppercase;letter-spacing:2.5px;color:var(--dim);margin-bottom:10px;display:flex;align-items:center;gap:7px}
.ct i{font-style:normal;font-size:1.2em;opacity:.6}

/* ═══ KPI ═══ */
.kpi{font-family:'JetBrains Mono';font-size:2.3em;font-weight:700;line-height:1;letter-spacing:-1px}
.kc{color:var(--cy)}.kr{color:var(--rd)}.ka{color:var(--am)}.kg{color:var(--gn)}
.kw{position:relative;overflow:hidden}
.kbg{display:none}

/* ═══ FORM ═══ */
.sec{margin-bottom:8px;padding:8px 10px;border-radius:var(--Rs);transition:background .3s}
.sec h4{font-size:.6em;font-weight:700;text-transform:uppercase;letter-spacing:2px;margin-bottom:6px;padding-bottom:5px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;gap:6px}
.sec h4 .dt{width:3px;height:3px;border-radius:50%}
.hcy{color:var(--cy)}.hcy .dt{background:var(--cy)}
.htl{color:var(--tl)}.htl .dt{background:var(--tl)}
.hpk{color:var(--pk)}.hpk .dt{background:var(--pk)}
.ham{color:var(--am)}.ham .dt{background:var(--am)}
.hpu{color:var(--pu)}.hpu .dt{background:var(--pu)}
.hgn{color:var(--gn)}.hgn .dt{background:var(--gn)}

/* ── Section Tints ── */
.sec-cy{background:#fff;border-left:4px solid rgba(2,132,199,.55)}
.sec-tl{background:#fff;border-left:4px solid rgba(13,148,136,.55)}
.sec-pu{background:#fff;border-left:4px solid rgba(124,58,237,.55)}
.sec-pk{background:#fff;border-left:4px solid rgba(219,39,119,.55)}
.sec-am{background:#fff;border-left:4px solid rgba(217,119,6,.55)}
.sec-gn{background:#fff;border-left:4px solid rgba(5,150,105,.55)}

/* ── Card Accent Variants ── */
.cd-cy{border-top:3px solid rgba(2,132,199,.7);background:#fff}
.cd-cy::before{display:none!important}
.cd-pu{border-top:3px solid rgba(124,58,237,.65);background:#fff}
.cd-pu::before{display:none!important}
.cd-pk{border-top:3px solid rgba(219,39,119,.65);background:#fff}
.cd-pk::before{display:none!important}
.cd-am{border-top:3px solid rgba(217,119,6,.65);background:#fff}
.cd-am::before{display:none!important}
.cd-gn{border-top:3px solid rgba(5,150,105,.65);background:#fff}
.cd-gn::before{display:none!important}
.cd-rd{border-top:3px solid rgba(220,38,38,.65);background:#fff}
.cd-rd::before{display:none!important}
.cd-tl{border-top:3px solid rgba(13,148,136,.65);background:#fff}
.cd-tl::before{display:none!important}
.cd-sl{border-top:3px solid rgba(100,116,139,.6);background:#fff}
.cd-sl::before{display:none!important}
.cd-compact{padding:12px 14px}
.cd-compact .ct{margin-bottom:6px;font-size:.58em}
.fs{display:grid;grid-template-columns:repeat(auto-fill,minmax(105px,1fr));gap:6px}
.fi{display:flex;flex-direction:column;gap:1px;align-items:center;padding:6px 4px;border-radius:var(--Rx);background:rgba(2,132,199,.03);border:1px solid rgba(2,132,199,.06)}
.fi label{font-size:.55em;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:1px}
.fi input{background:rgba(255,255,255,.7);border:1px solid var(--bdr);border-radius:var(--Rx);padding:5px 7px;color:var(--tx2);font-size:.78em;width:100%;font-family:'JetBrains Mono';transition:.2s}
.fi input:focus{outline:none}
.fi input:hover{}

/* ═══ BUTTONS ═══ */
.bt{padding:10px 26px;border:none;border-radius:var(--Rs);font-weight:700;font-size:.8em;cursor:pointer;transition:.2s;font-family:'Plus Jakarta Sans','Prompt';letter-spacing:1px;text-transform:uppercase}
.bgo{background:linear-gradient(135deg,var(--cy),var(--cyd));color:#fff;box-shadow:0 2px 16px rgba(2,132,199,.25)}
.bgo:hover{transform:translateY(-2px) scale(1.02);box-shadow:0 6px 35px rgba(0,200,255,.35)}
.bgo:active{transform:translateY(0) scale(1)}
.bgh{background:transparent;color:var(--dim);border:1px solid var(--bdr)}
.bgh:hover{border-color:var(--cy);color:var(--cy)}
.brw{display:flex;gap:10px;margin-top:16px;align-items:center;flex-wrap:wrap}
.ap-divider{width:1px;height:22px;background:var(--bdr);margin:0 2px;flex-shrink:0}
.ap-tgl{flex-shrink:0}
.ap-info{display:flex;flex-direction:column;gap:1px}
.ap-label{font-family:'JetBrains Mono';font-size:.55em;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--dim)}
.ap-timer{font-family:'JetBrains Mono';font-size:.6em;font-weight:800;color:var(--dim);letter-spacing:.5px;transition:color .3s}
.ap-timer.ap-on{color:#16a34a}
.ap-timer.ap-run{color:#0284c7;animation:ap-blink 1s ease-in-out infinite}
@keyframes ap-blink{0%,100%{opacity:1}50%{opacity:.5}}

/* ═══ PRESETS ═══ */
.prg{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:14px}
.pr{padding:11px 12px;border-radius:var(--Rs);background:rgba(255,255,255,.5);border:1px solid var(--bdr);cursor:pointer;transition:.25s;position:relative;overflow:hidden}
.pr:hover{transform:translateY(-2px)}
.pr .pi{font-size:1.2em;margin-bottom:3px}.pr .pt{font-size:.75em;font-weight:700;margin-bottom:1px}.pr .pd{font-size:.58em;color:var(--dim);letter-spacing:.5px}
.pok{border-color:rgba(5,150,105,.25)}.pok:hover{border-color:var(--gn);box-shadow:0 4px 20px var(--gng)}
.pw{border-color:rgba(217,119,6,.25)}.pw:hover{border-color:var(--am);box-shadow:0 4px 20px var(--amg)}
.pd2{border-color:rgba(220,38,38,.25)}.pd2:hover{border-color:var(--rd);box-shadow:0 4px 20px var(--rdg)}

/* ═══ RESULT ═══ */
.rh{display:none}.rs{display:block;animation:ri .55s cubic-bezier(.16,1,.3,1)}
@keyframes ri{from{opacity:0;transform:translateY(20px) scale(.98)}to{opacity:1;transform:none}}

.rbc{text-align:center;padding:8px 0}
.rc{position:relative;width:170px;height:170px;margin:0 auto}
.rsvg{width:170px;height:170px;transform:rotate(-90deg);filter:drop-shadow(0 0 8px rgba(0,40,100,.1))}
.rbg{fill:none;stroke:var(--bdr);stroke-width:8}
.rfg{fill:none;stroke-width:8;stroke-linecap:round;transition:stroke-dashoffset .9s cubic-bezier(.25,1,.5,1),stroke .5s}
.rgl{fill:none;stroke-width:14;stroke-linecap:round;opacity:.15;filter:blur(6px);transition:stroke-dashoffset .9s cubic-bezier(.25,1,.5,1),stroke .5s}
.rm{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.rv{font-family:'JetBrains Mono';font-size:2.1em;font-weight:700;letter-spacing:-1px}
.rl{font-size:.65em;font-weight:600;color:var(--dim);text-transform:uppercase;letter-spacing:3px;margin-top:2px}

.sv{display:inline-flex;padding:5px 16px;border-radius:18px;font-size:.68em;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;font-family:'JetBrains Mono'}
.svN{background:var(--gng);color:var(--gn);border:1px solid rgba(5,150,105,.35)}
.svM{background:var(--cyg);color:var(--cy);border:1px solid rgba(2,132,199,.35)}
.svH{background:var(--amg);color:var(--am);border:1px solid rgba(217,119,6,.35)}
.svC{background:var(--rdg);color:var(--rd);border:1px solid rgba(220,38,38,.4);animation:cg 1.8s ease-in-out infinite}
@keyframes cg{0%,100%{box-shadow:0 0 8px var(--rdg)}50%{box-shadow:0 0 25px var(--rdg),0 0 50px rgba(220,38,38,.06)}}

/* ═══ GAUGES ═══ */
.gg{display:grid;gap:11px}
.gi{display:grid;grid-template-columns:100px 1fr 48px;align-items:center;gap:10px}
.gn{font-size:.68em;font-weight:700;text-transform:uppercase;letter-spacing:1.2px}
.gt{height:6px;background:var(--bdr);border-radius:3px;overflow:hidden}
.gf{height:100%;border-radius:3px;transition:width .7s cubic-bezier(.25,1,.5,1);position:relative}
.gf::after{content:'';position:absolute;right:-1px;top:-2px;bottom:-2px;width:4px;border-radius:2px;background:inherit;filter:brightness(1.6);box-shadow:0 0 6px currentColor}
.gv{font-family:'JetBrains Mono';font-size:.75em;font-weight:600;text-align:right}

/* ═══ MODEL TABLE ═══ */
.mrow{display:grid;grid-template-columns:1fr 80px 90px 58px;align-items:center;padding:9px 12px;font-size:.78em;border-bottom:1px solid rgba(160,180,210,.25);transition:.2s}
.mrow:hover{background:rgba(2,132,199,.04)}.mrow:last-child{border-bottom:none}
.mh{color:var(--dim);font-weight:700;font-size:.6em;text-transform:uppercase;letter-spacing:2px}
.mn{font-weight:600;color:var(--tx2)}
.msc{font-family:'JetBrains Mono';font-weight:700}
.mbar{height:4px;background:var(--bdr);border-radius:2px;overflow:hidden}
.mbf{height:100%;border-radius:2px;transition:width .6s}
.ch{font-size:.6em;padding:2px 8px;border-radius:8px;font-weight:700;letter-spacing:.8px;text-transform:uppercase}
.cok{background:var(--gng);color:var(--gn)}.cbd{background:var(--rdg);color:var(--rd)}

/* ═══ ALERTS ═══ */
.ai{padding:13px 15px;margin:7px 0;border-radius:var(--Rs);font-size:.8em;border-left:3px solid;position:relative;overflow:hidden;animation:ri .35s ease}
.ai::before{content:'';position:absolute;inset:0;opacity:.04;background:linear-gradient(135deg,currentColor,transparent);pointer-events:none}
.aiC{background:var(--rdg);border-color:var(--rd);color:var(--rd)}
.aiH{background:var(--amg);border-color:var(--am);color:var(--am)}
.aiM{background:var(--cyg);border-color:var(--cy);color:var(--cy)}
.ah{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px}
.ah strong{font-size:.85em;letter-spacing:.3px}
.asc{font-family:'JetBrains Mono';font-weight:700}
.ast{font-size:.65em;color:var(--dim);margin-top:3px;line-height:1.5}
.aact{font-size:.68em;margin-top:7px;padding:7px 11px;background:rgba(217,119,6,.06);border-radius:var(--Rx);border-left:2px solid var(--am);color:var(--am)}

/* ═══ LOG ═══ */
.lb{background:#fff;border-radius:var(--Rs);padding:12px 14px;max-height:260px;overflow-y:auto;font-family:'JetBrains Mono';font-size:.67em;line-height:1.8}
.ll{color:var(--dim);border-bottom:1px solid rgba(160,180,210,.15);padding:1px 0}.ll.an{color:var(--rd)}.ll.ok{color:var(--gn)}

/* ═══ ANIM ═══ */
.stg{opacity:0;animation:si .5s ease forwards}
@keyframes si{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}

/* ═══ FEATURE IMPORTANCE ═══ */
.fi-row{display:grid;grid-template-columns:130px 1fr 50px;align-items:center;gap:8px;padding:5px 0;font-size:.73em}
.fi-name{font-family:'JetBrains Mono';font-weight:600;color:var(--tx2);font-size:.85em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fi-track{height:8px;background:var(--bdr);border-radius:4px;overflow:hidden;position:relative}
.fi-bar{height:100%;border-radius:4px;transition:width .7s cubic-bezier(.25,1,.5,1);position:relative;background:linear-gradient(90deg,var(--cy),var(--pu))}
.fi-bar::after{content:'';position:absolute;right:-1px;top:-2px;bottom:-2px;width:5px;border-radius:3px;background:var(--pu);filter:brightness(1.3);box-shadow:0 0 6px var(--pu)}
.fi-val{font-family:'JetBrains Mono';font-weight:700;font-size:.82em;text-align:right;color:var(--tx2)}
.fi-rank{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:50%;font-size:.6em;font-weight:800;margin-right:4px}
.fi-top{background:linear-gradient(135deg,var(--rd),var(--pk));color:#fff}
.fi-mid{background:var(--amg);color:var(--am);border:1px solid rgba(217,119,6,.25)}
.fi-low{background:var(--cyg);color:var(--cy);border:1px solid rgba(2,132,199,.2)}
.fi-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.fi-badge{font-size:.58em;padding:3px 10px;border-radius:10px;background:var(--cyg);color:var(--cy);border:1px solid rgba(2,132,199,.2);font-weight:700;letter-spacing:.5px;text-transform:uppercase}

@media(max-width:1100px){.c28,.c64,.c55,.c2{grid-template-columns:1fr}.c4{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.c4{grid-template-columns:1fr}.pg{padding:12px 14px}.hdr{padding:0 14px}}

/* ═══ RULE-BASED MONITORING ═══ */
.rb-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.rb-title{font-size:.85em;font-weight:800;letter-spacing:2px;text-transform:uppercase;color:var(--tx2);display:flex;align-items:center;gap:8px}
.rb-mqtt{display:flex;align-items:center;gap:8px;font-size:.68em;font-weight:600;padding:5px 14px;border-radius:18px;border:1px solid var(--gb);background:#fff}
.rb-mqtt .led{width:7px;height:7px}
.rb-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.rb-rule{padding:14px 16px;border-radius:var(--Rs);background:rgba(255,255,255,.5);border:1px solid var(--bdr);transition:.25s;position:relative;overflow:hidden}
.rb-rule:hover{border-color:var(--bdr2)}
.rb-rule::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;border-radius:2px 0 0 2px}
.rb-ok::before{background:var(--gn)}.rb-alert::before{background:var(--rd)}.rb-warn::before{background:var(--am)}.rb-idle::before{background:var(--dim)}.rb-idle{opacity:.7}
.rb-rule-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.rb-rule-name{font-size:.72em;font-weight:700;color:var(--tx2)}
.rb-rule-conn{font-size:.58em;font-weight:600;padding:2px 8px;border-radius:8px;letter-spacing:.5px}
.rb-rule-status{font-family:'JetBrains Mono';font-size:.6em;font-weight:700;padding:3px 10px;border-radius:10px;letter-spacing:1px}
.rb-rule-detail{font-size:.7em;color:var(--dim);line-height:1.5;margin-top:4px}
.rb-vals{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
.rb-val{font-family:'JetBrains Mono';font-size:.6em;padding:2px 7px;border-radius:6px;background:rgba(255,255,255,.6);border:1px solid var(--bdr);color:var(--tx2)}
.rb-empty{text-align:center;padding:30px;color:var(--dim);font-size:.78em;font-style:italic;grid-column:1/-1}
@media(max-width:1100px){.rb-grid{grid-template-columns:1fr}}
/* ═══ RULE TREE DIAGRAM ═══ */
.rt-wrap{position:relative;overflow-x:auto;padding-bottom:10px;display:flex;justify-content:center}
.rt-canvas{position:relative;display:inline-flex;align-items:stretch;min-width:1100px;margin:0 auto}
.rt-svg{position:absolute;top:0;left:0;pointer-events:none;z-index:1;overflow:visible}
.rt-col{display:flex;flex-direction:column;position:relative;z-index:2}
.rt-col-r{width:340px;gap:2px;padding-top:6px}
.rt-col-g{width:160px;position:relative;margin-left:70px}
.rt-col-s{flex:1;display:flex;align-items:center;justify-content:center;margin-left:70px;min-width:200px}
/* Rule row (like condition row) */
.rt-r{display:flex;align-items:center;gap:5px;padding:5px 8px;border-radius:6px;border:1px solid var(--bdr);border-left:3px solid var(--dim);background:var(--card);transition:.25s;font-size:.62em;height:30px;overflow:hidden;flex-wrap:nowrap;min-width:0;cursor:default}
.rt-r:hover{border-color:var(--dim);background:var(--card2,var(--card))}
.rt-r.rt-ok{border-left-color:var(--gn)}.rt-r.rt-alert{border-left-color:var(--rd);background:rgba(239,68,68,.03)}.rt-r.rt-warn{border-left-color:var(--am);background:rgba(217,119,6,.03)}.rt-r.rt-idle{border-left-color:var(--dim);opacity:.6}
.rt-id{font-family:'JetBrains Mono';font-size:.88em;font-weight:700;color:#fff;border-radius:4px;padding:1px 6px;min-width:24px;text-align:center;flex-shrink:0;background:linear-gradient(135deg,#475569,#64748b);box-shadow:0 1px 3px rgba(71,85,105,.3)}
.rt-id.rt-c1{background:linear-gradient(135deg,#0284c7,#06b6d4)}
.rt-id.rt-c2{background:linear-gradient(135deg,#7c3aed,#a855f7)}
.rt-name{font-weight:600;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--tx2)}
.rt-val{font-family:'JetBrains Mono';font-size:.85em;font-weight:500;color:var(--dim);flex-shrink:0;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rt-badge{font-family:'JetBrains Mono';font-size:.82em;font-weight:700;padding:1px 7px;border-radius:8px;flex-shrink:0}
.rt-badge.rt-st-ok{background:rgba(16,185,129,.08);color:#059669}
.rt-badge.rt-st-alert{background:rgba(239,68,68,.08);color:#dc2626}
.rt-badge.rt-st-warn{background:rgba(217,119,6,.08);color:#92400e}
.rt-badge.rt-st-idle{background:rgba(148,163,184,.08);color:#64748b}
.rt-sep{height:14px;flex-shrink:0}
/* Group node (like equipment node) */
.rt-gn{padding:10px 14px;border-radius:10px;border:2px solid var(--bdr);background:var(--card);text-align:center;position:absolute;left:0;right:0;transform:translateY(-50%);transition:.25s;cursor:default;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.rt-gn-t{font-size:.7em;font-weight:800;color:var(--tx2);white-space:nowrap}
.rt-gn-c{font-family:'JetBrains Mono';font-size:.55em;font-weight:600;color:var(--dim);margin-top:2px}
/* Overall status node */
.rt-overall{padding:16px 20px;text-align:center;border:none;background:none}
.rt-ov-icon{font-size:1.6em;margin-bottom:4px}
.rt-ov-label{font-size:.78em;font-weight:800;color:var(--gn);letter-spacing:.5px;transition:color .3s}
.rt-ov-count{font-family:'JetBrains Mono';font-size:2em;font-weight:900;transition:color .3s}
.rt-ov-sub{font-family:'JetBrains Mono';font-size:.55em;font-weight:600;color:var(--dim);margin-top:2px}
.rt-ov-pill{display:inline-flex;align-items:center;gap:5px;padding:3px 12px;border-radius:16px;margin-top:6px;font-family:'JetBrains Mono';font-size:.6em;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;transition:all .3s}

/* ═══ SEQUENCE UI — CLEAN WHITE ═══ */
.sq-card{margin-bottom:14px;position:relative}
.sq-card .ct{position:relative;z-index:2}
.sq-panels{display:grid;grid-template-columns:1fr 1fr;gap:12px;position:relative;z-index:2}
@media(max-width:900px){.sq-panels{grid-template-columns:1fr}}
.sq-panel{position:relative;padding:16px;border-radius:var(--Rs);background:var(--card);border:1px solid var(--bdr);overflow:hidden;transition:box-shadow .3s}
.sq-panel:hover{box-shadow:0 4px 16px rgba(0,0,0,.06)}
.sq-panel::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:var(--Rs) var(--Rs) 0 0}
.sq-panel[data-cn="1"]::before{background:linear-gradient(90deg,#0284c7,#06b6d4,#22d3ee)}
.sq-panel[data-cn="2"]::before{background:linear-gradient(90deg,#7c3aed,#a855f7,#c084fc)}
.sq-hud{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:6px}
.sq-hud-left{display:flex;align-items:center;gap:8px}
.sq-badge{font-size:.52em;font-weight:800;text-transform:uppercase;letter-spacing:3px;padding:4px 14px;border-radius:6px;color:#fff}
.sq-panel[data-cn="1"] .sq-badge{background:linear-gradient(135deg,#0284c7,#06b6d4);box-shadow:0 2px 8px rgba(2,132,199,.3)}
.sq-panel[data-cn="2"] .sq-badge{background:linear-gradient(135deg,#7c3aed,#a855f7);box-shadow:0 2px 8px rgba(124,58,237,.3)}
.sq-phase{font-family:'JetBrains Mono';font-size:.52em;font-weight:700;letter-spacing:2px;text-transform:uppercase;padding:3px 10px;border-radius:5px;border:1.5px solid var(--bdr);background:rgba(255,255,255,.5);color:var(--dim);transition:all .35s}
.sq-hud-right{display:flex;align-items:center;gap:8px}
.sq-readout{font-family:'JetBrains Mono';font-size:.55em;font-weight:600;display:flex;align-items:center;gap:3px}
.sq-readout-label{color:var(--dim);font-size:.85em;letter-spacing:1px}
.sq-readout-val{font-weight:800;letter-spacing:.5px;color:var(--tx2)}
.sq-signal{display:flex;align-items:flex-end;gap:1px;height:10px}
.sq-signal-bar{width:2px;border-radius:1px}
.sq-progress{height:4px;background:rgba(0,0,0,.06);border-radius:3px;margin-bottom:12px;overflow:hidden}
.sq-progress-fill{height:100%;border-radius:3px;transition:width .4s ease}
.sq-panel[data-cn="1"] .sq-progress-fill{background:linear-gradient(90deg,#0284c7,#06b6d4,#22d3ee)}
.sq-panel[data-cn="2"] .sq-progress-fill{background:linear-gradient(90deg,#7c3aed,#a855f7,#c084fc)}
@keyframes sq-pulse{0%,100%{opacity:1}50%{opacity:.55}}
.sq-progress-fill.sq-charging{animation:sq-pulse 1.5s ease-in-out infinite}
.sq-tracks{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.sq-col{display:flex;flex-direction:column}
.sq-col-head{font-family:'JetBrains Mono';font-size:.48em;font-weight:800;letter-spacing:2px;text-transform:uppercase;text-align:center;padding:5px 8px 6px;margin-bottom:6px;border-radius:4px}
.sq-panel[data-cn="1"] .sq-col:first-child .sq-col-head{background:rgba(2,132,199,.08);color:#0284c7;border-bottom:2px solid rgba(2,132,199,.3)}
.sq-panel[data-cn="1"] .sq-col:last-child .sq-col-head{background:rgba(6,182,212,.08);color:#0891b2;border-bottom:2px solid rgba(6,182,212,.3)}
.sq-panel[data-cn="2"] .sq-col:first-child .sq-col-head{background:rgba(124,58,237,.08);color:#7c3aed;border-bottom:2px solid rgba(124,58,237,.3)}
.sq-panel[data-cn="2"] .sq-col:last-child .sq-col-head{background:rgba(168,85,247,.08);color:#9333ea;border-bottom:2px solid rgba(168,85,247,.3)}
.sq-track{display:flex;flex-direction:column;align-items:stretch;gap:0}
.sq-step{display:flex;align-items:center;gap:8px;position:relative;padding:2px 4px;border-radius:5px;transition:background .2s}
.sq-step:hover{background:rgba(0,0,0,.03)}
.sq-node{width:14px;height:14px;position:relative;flex-shrink:0}
.sq-node-inner{position:absolute;inset:2px;border-radius:50%;border:2px solid var(--bdr);background:#fff;transition:all .3s}
.sq-node-ring{display:none}
.sq-node-ping{display:none}
.sq-past .sq-node-inner{border-color:#94a3b8;background:#94a3b8}
.sq-active .sq-node-inner{animation:sq-glow 2s ease-in-out infinite}
@keyframes sq-glow{0%,100%{box-shadow:0 0 0 3px rgba(2,132,199,.18),0 0 8px rgba(6,182,212,.25)}50%{box-shadow:0 0 0 5px rgba(2,132,199,.28),0 0 14px rgba(6,182,212,.35)}}
.sq-err .sq-node-inner{border-color:#ef4444;background:#ef4444;box-shadow:0 0 0 3px rgba(239,68,68,.18),0 0 8px rgba(239,68,68,.25);animation:none}
.sq-wire{width:2px;height:8px;margin-left:6px;flex-shrink:0;background:rgba(0,0,0,.08);border-radius:1px;transition:background .3s}
.sq-wire.sq-done{background:linear-gradient(180deg,#94a3b8,#cbd5e1)}
.sq-lbl{font-family:'JetBrains Mono';font-size:.48em;font-weight:600;color:rgba(100,116,139,.6);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:all .3s;letter-spacing:.3px;line-height:1.2;flex:1;min-width:0}
.sq-past .sq-lbl{color:rgba(71,85,105,.72)}
.sq-lbl-active{font-weight:800}
.sq-lbl-err{color:#ef4444!important;font-weight:800}
.sq-idx{font-family:'JetBrains Mono';font-size:.4em;font-weight:700;color:rgba(100,116,139,.35);width:14px;text-align:right;flex-shrink:0}
.sq-past .sq-idx{color:rgba(71,85,105,.6)}
.sq-active .sq-idx{font-weight:800}
.sq-err .sq-idx{color:#ef4444}
.sq-tip{position:absolute;left:calc(100% + 8px);top:50%;transform:translateY(-50%);background:linear-gradient(135deg,#1e293b,#334155);color:#fff;font-family:'JetBrains Mono';font-size:.52em;padding:6px 14px;border-radius:6px;white-space:nowrap;pointer-events:none;opacity:0;transition:opacity .2s;z-index:20;box-shadow:0 4px 16px rgba(0,0,0,.22);letter-spacing:.5px}
.sq-tip::after{content:'';position:absolute;right:100%;top:50%;transform:translateY(-50%);border:5px solid transparent;border-right-color:#1e293b}
.sq-tip-to{margin-top:4px;padding-top:4px;border-top:1px solid rgba(255,255,255,.1);font-size:.92em;color:rgba(148,163,184,.8);line-height:1.4;max-width:320px;white-space:normal}
.sq-step:hover .sq-tip{opacity:1}
.sq-to{font-family:'JetBrains Mono';font-size:.4em;font-weight:700;color:rgba(100,116,139,.5);flex-shrink:0;padding:1px 6px;border-radius:3px;border:1px solid rgba(0,0,0,.06);background:rgba(0,0,0,.02);letter-spacing:.3px;margin-left:auto;transition:all .3s}
.sq-active .sq-to{border-color:rgba(2,132,199,.2);background:rgba(2,132,199,.06)}
.sq-past .sq-to{color:rgba(100,116,139,.42)}
.sq-desc{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px;padding-top:10px;border-top:1px solid var(--bdr)}
.sq-desc-item{flex:1;min-width:60px;padding:6px 8px;border-radius:6px;font-family:'JetBrains Mono';font-size:.45em;border:1px solid var(--bdr);background:var(--card);display:flex;align-items:center;gap:5px;transition:all .35s}
.sq-desc-item.sq-desc-active{transform:translateY(-1px);box-shadow:0 2px 8px rgba(0,0,0,.07)}
.sq-desc-icon{width:7px;height:7px;border-radius:50%;flex-shrink:0;transition:all .3s}
.sq-desc-txt{color:var(--dim);line-height:1.2;transition:color .3s}
.sq-desc-txt strong{font-size:.95em;font-weight:700}
.sq-desc-item.sq-desc-active .sq-desc-txt{font-weight:700}
.sq-desc-item.sq-desc-active .sq-desc-txt strong{font-weight:800}
.sq-desc-plug.sq-desc-active{border-color:rgba(2,132,199,.4);background:linear-gradient(135deg,rgba(2,132,199,.06),rgba(6,182,212,.04))}
.sq-desc-plug.sq-desc-active .sq-desc-txt,.sq-desc-plug.sq-desc-active .sq-desc-txt strong{color:#0284c7}
.sq-desc-v2g.sq-desc-active{border-color:rgba(124,58,237,.4);background:linear-gradient(135deg,rgba(124,58,237,.06),rgba(168,85,247,.04))}
.sq-desc-v2g.sq-desc-active .sq-desc-txt,.sq-desc-v2g.sq-desc-active .sq-desc-txt strong{color:#7c3aed}
.sq-desc-nego.sq-desc-active{border-color:rgba(217,119,6,.4);background:linear-gradient(135deg,rgba(217,119,6,.06),rgba(245,158,11,.04))}
.sq-desc-nego.sq-desc-active .sq-desc-txt,.sq-desc-nego.sq-desc-active .sq-desc-txt strong{color:#d97706}
.sq-desc-chrg.sq-desc-active{border-color:rgba(22,163,74,.4);background:linear-gradient(135deg,rgba(22,163,74,.06),rgba(34,197,94,.04))}
.sq-desc-chrg.sq-desc-active .sq-desc-txt,.sq-desc-chrg.sq-desc-active .sq-desc-txt strong{color:#16a34a}
.sq-desc-fin.sq-desc-active{border-color:rgba(236,72,153,.4);background:linear-gradient(135deg,rgba(236,72,153,.06),rgba(244,114,182,.04))}
.sq-desc-fin.sq-desc-active .sq-desc-txt,.sq-desc-fin.sq-desc-active .sq-desc-txt strong{color:#ec4899}


/* ═══ TOGGLE SWITCH ═══ */
.tgl{position:relative;display:inline-block;width:36px;height:20px;cursor:pointer;vertical-align:middle}
.tgl input{opacity:0;width:0;height:0}
.tgl-sl{position:absolute;inset:0;border-radius:20px;background:rgba(0,0,0,.12);transition:background .3s}
.tgl-sl::before{content:'';position:absolute;left:2px;bottom:2px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:transform .3s}
.tgl input:checked+.tgl-sl{background:var(--tx2)}
.tgl input:checked+.tgl-sl::before{transform:translateX(16px)}
#scBody{overflow:hidden;transition:max-height .35s ease,opacity .25s ease;max-height:500px;opacity:1}
#scBody.sc-hide{max-height:0;opacity:0;margin:0;padding:0}

/* ═══ REFERENCE PAGE ═══ */
.ref-card{background:var(--glass);border:1px solid var(--gb);border-radius:var(--R);padding:22px 24px;margin-bottom:14px;position:relative;overflow:hidden;transition:border-color .35s;border-left:4px solid var(--cy)}
.ref-card:hover{border-color:var(--bdr2)}
.ref-head{display:flex;align-items:center;gap:12px;margin-bottom:14px}
.ref-icon{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.4em;flex-shrink:0}
.ref-title{font-size:1em;font-weight:800;letter-spacing:1px;text-transform:uppercase}
.ref-sev{font-size:.6em;padding:3px 10px;border-radius:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-left:8px}
.ref-desc{font-size:.82em;color:var(--tx);line-height:1.7;margin-bottom:14px}
.ref-section{margin-bottom:12px}
.ref-section-title{font-size:.62em;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--dim);margin-bottom:6px;display:flex;align-items:center;gap:6px}
.ref-std{font-size:.78em;padding:8px 12px;background:rgba(255,255,255,.5);border:1px solid var(--bdr);border-radius:var(--Rs);margin-bottom:5px;display:flex;align-items:flex-start;gap:8px;line-height:1.5}
.ref-std-icon{flex-shrink:0;font-size:.9em;margin-top:1px}
.ref-features{display:flex;flex-wrap:wrap;gap:5px}
.ref-feat{font-size:.68em;padding:4px 10px;border-radius:14px;font-family:'JetBrains Mono';font-weight:600;letter-spacing:.3px}
.ref-action{font-size:.78em;padding:10px 14px;border-radius:var(--Rs);line-height:1.5;display:flex;align-items:flex-start;gap:8px}
.ref-threshold{font-family:'JetBrains Mono';font-size:.82em;font-weight:700;padding:5px 12px;border-radius:var(--Rs);display:inline-flex;align-items:center;gap:6px}
.ref-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.ref-intro{padding:20px 24px;margin-bottom:20px;border-radius:var(--R);background:var(--glass);border:1px solid var(--gb)}
.ref-intro h2{font-size:1.1em;font-weight:800;margin-bottom:8px;color:var(--tx2)}
.ref-intro p{font-size:.82em;color:var(--dim);line-height:1.7}
.ref-std-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:10px}
.ref-std-card{padding:14px;border-radius:var(--Rs);background:rgba(255,255,255,.4);border:1px solid var(--bdr);text-align:center}
.ref-std-card h4{font-size:.62em;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--dim);margin-bottom:4px}
.ref-std-card .ref-std-name{font-size:.85em;font-weight:800;color:var(--tx2)}
.ref-std-card p{font-size:.68em;color:var(--dim);margin-top:4px;line-height:1.4}
@media(max-width:1100px){.ref-grid{grid-template-columns:1fr}.ref-std-grid{grid-template-columns:1fr}}

/* ═══ RULE-ALGO PAGE ═══ */
.ra-intro{padding:22px 24px;margin-bottom:20px;border-radius:var(--R);background:var(--glass);border:1px solid var(--gb)}
.ra-intro h2{font-size:1.1em;font-weight:800;margin-bottom:8px;color:var(--tx2)}
.ra-intro p{font-size:.82em;color:var(--dim);line-height:1.7}
.ra-flow{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:12px}
.ra-flow-step{font-size:.68em;padding:6px 14px;border-radius:18px;font-weight:700;letter-spacing:.5px;border:1px solid var(--bdr)}
.ra-flow-arrow{color:var(--dim);font-size:.8em}
.ra-card{background:var(--glass);border:1px solid var(--gb);border-radius:var(--R);padding:22px 24px;margin-bottom:16px;position:relative;overflow:hidden;transition:border-color .35s}
.ra-card:hover{border-color:var(--bdr2)}
.ra-num{position:absolute;top:14px;right:18px;font-family:'JetBrains Mono';font-size:2.8em;font-weight:900;opacity:.06;line-height:1;color:var(--tx2)}
.ra-head{display:flex;align-items:center;gap:12px;margin-bottom:14px}
.ra-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5em;flex-shrink:0}
.ra-title{font-size:1em;font-weight:800;letter-spacing:.5px}
.ra-id{font-family:'JetBrains Mono';font-size:.6em;font-weight:600;padding:3px 10px;border-radius:8px;letter-spacing:.5px;margin-left:8px}
.ra-desc{font-size:.82em;color:var(--tx);line-height:1.7;margin-bottom:16px}
.ra-logic{margin-bottom:16px;padding:14px 16px;border-radius:var(--Rs);border:1px solid var(--bdr)}
.ra-logic-title{font-size:.62em;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--dim);margin-bottom:8px;display:flex;align-items:center;gap:6px}
.ra-code{font-family:'JetBrains Mono';font-size:.75em;line-height:1.8;color:var(--tx2);white-space:pre-wrap}
.ra-code .kw{color:var(--cy);font-weight:700}
.ra-code .val{color:var(--pu)}
.ra-code .cmt{color:var(--dim);font-style:italic}
.ra-mqtt{margin-bottom:14px}
.ra-mqtt-title{font-size:.62em;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--dim);margin-bottom:8px;display:flex;align-items:center;gap:6px}
.ra-keys{display:flex;flex-wrap:wrap;gap:5px}
.ra-key{font-family:'JetBrains Mono';font-size:.65em;padding:4px 10px;border-radius:6px;display:flex;align-items:center;gap:5px}
.ra-key-name{font-weight:700}
.ra-key-type{opacity:.6;font-size:.85em}
.ra-severity{display:inline-flex;align-items:center;gap:5px;font-size:.62em;padding:4px 12px;border-radius:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-left:8px}
.ra-example{margin-top:14px;padding:12px 14px;border-radius:var(--Rs);font-size:.78em;line-height:1.6}
.ra-example-title{font-size:.62em;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--dim);margin-bottom:6px;display:flex;align-items:center;gap:6px}
.ra-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:1100px){.ra-grid{grid-template-columns:1fr}}

/* Per-Condition AI Score Badges */
.ai-score{font-family:'JetBrains Mono',monospace;font-size:.55em;font-weight:700;padding:0 4px;border-radius:4px;margin-left:2px;letter-spacing:.3px;flex-shrink:0;line-height:1.2}
.ai-score.ai-h{background:rgba(239,68,68,.1);color:#ef4444}
.ai-score.ai-m{background:rgba(251,191,36,.1);color:#d97706}
.ai-score.ai-l{background:rgba(16,185,129,.08);color:#10b981}
.cn-b.aw{background:rgba(245,158,11,.15);color:#f59e0b;border-color:#f59e0b}
.ai-warn{border-left:3px solid #f59e0b !important}

/* ═══ LEFT SIDEBAR ═══ */
.app-wrap{display:flex;min-height:100vh}
.sidebar{width:260px;min-width:260px;background:var(--hdr-bg);backdrop-filter:blur(30px) saturate(1.6);border-right:1px solid var(--hdr-bdr);position:fixed;top:0;left:0;bottom:0;z-index:200;display:flex;flex-direction:column;transition:width .3s cubic-bezier(.4,0,.2,1),min-width .3s cubic-bezier(.4,0,.2,1);overflow:hidden}
.sidebar.collapsed{width:60px;min-width:60px}
.sb-logo{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--hdr-bdr);height:56px;flex-shrink:0;overflow:hidden;white-space:nowrap}
.sb-logo img{width:32px;height:32px;border-radius:6px;flex-shrink:0;object-fit:cover}
.sb-logo-txt{display:flex;flex-direction:column;overflow:hidden}
.sb-logo-txt b{font-size:.72em;font-weight:800;color:var(--h-acc);letter-spacing:.5px}
.sb-logo-txt small{font-size:.52em;color:var(--h-dim);white-space:nowrap}
.collapsed .sb-logo-txt{opacity:0;width:0}
.sb-section{padding:10px 10px 4px;font-size:.5em;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--h-dim);white-space:nowrap;overflow:hidden}
.collapsed .sb-section{text-align:center;font-size:0;padding:8px 0}
.collapsed .sb-section::after{content:'•••';font-size:10px;letter-spacing:2px}
.sb-nav{flex:1;overflow-y:auto;overflow-x:hidden;padding:0 8px}
.sb-item{display:flex;align-items:center;gap:10px;padding:9px 12px;margin:2px 0;border-radius:10px;cursor:pointer;transition:all .2s;border:1px solid transparent;position:relative;overflow:hidden;white-space:nowrap;text-decoration:none;color:var(--tx)}
.sb-item:hover{background:var(--glass);border-color:var(--gb)}
.sb-item.sb-active{background:linear-gradient(135deg,rgba(2,132,199,.1),rgba(6,182,212,.05));border-color:rgba(6,182,212,.25);box-shadow:0 0 12px rgba(6,182,212,.08)}
.sb-item.sb-active .sb-icon{background:linear-gradient(135deg,#0284c7,#06b6d4);color:#fff;box-shadow:0 2px 8px rgba(6,182,212,.3)}
.sb-item.sb-soon{opacity:.5;cursor:default}
.sb-item.sb-soon:hover{background:none;border-color:transparent}
.sb-icon{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.82em;flex-shrink:0;background:rgba(0,0,0,.04);transition:all .2s}
.sb-item.sb-active .sb-icon{background:linear-gradient(135deg,#0284c7,#06b6d4);color:#fff}
.sb-txt{display:flex;flex-direction:column;overflow:hidden;min-width:0}
.sb-txt-name{font-size:.68em;font-weight:700;color:var(--tx2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sb-txt-sub{font-size:.5em;color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sb-active .sb-txt-name{color:var(--h-acc)}
.sb-badge{font-family:'JetBrains Mono';font-size:.48em;font-weight:700;padding:2px 6px;border-radius:6px;margin-left:auto;flex-shrink:0;letter-spacing:.5px}
.sb-badge-live{background:rgba(22,163,74,.1);color:#16a34a}
.sb-badge-soon{background:rgba(148,163,184,.08);color:#94a3b8}
.collapsed .sb-txt,.collapsed .sb-badge{display:none}
.sb-toggle{padding:12px 16px;border-top:1px solid var(--hdr-bdr);display:flex;align-items:center;gap:10px;cursor:pointer;transition:all .2s;flex-shrink:0}
.sb-toggle:hover{background:var(--glass)}
.sb-toggle-icon{width:28px;height:28px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:.85em;background:rgba(0,0,0,.04);transition:transform .3s}
.collapsed .sb-toggle-icon{transform:rotate(180deg)}
.sb-toggle-txt{font-size:.62em;font-weight:600;color:var(--dim);white-space:nowrap}
.collapsed .sb-toggle-txt{display:none}
.app-main{flex:1;margin-left:260px;transition:margin-left .3s cubic-bezier(.4,0,.2,1);min-width:0}
.sidebar.collapsed~.app-main{margin-left:60px}
/* Tooltip for collapsed mode */
.sb-item[data-tip]{position:relative}
.collapsed .sb-item[data-tip]:hover::after{content:attr(data-tip);position:absolute;left:calc(100% + 8px);top:50%;transform:translateY(-50%);background:#1e293b;color:#f1f5f9;font-size:.65em;font-weight:600;padding:5px 12px;border-radius:8px;white-space:nowrap;z-index:999;box-shadow:0 4px 12px rgba(0,0,0,.15);pointer-events:none}
@media(max-width:900px){.sidebar{width:60px;min-width:60px}.sidebar .sb-txt,.sidebar .sb-badge,.sidebar .sb-logo-txt,.sidebar .sb-toggle-txt,.sidebar .sb-section{display:none}.app-main{margin-left:60px}}

/* ═══ MODULE 2: Charger Dust Filter Detection ═══ */
.m2-page{display:none}.m2-page.on{display:block}
/* ═══ MODULE 2: AI Status Tree ═══ */
.m2-tree-wrap{position:relative;display:flex;align-items:stretch;max-width:1000px;margin:0 auto;gap:0;overflow:visible;padding-bottom:20px}
.m2-tree-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1;overflow:visible}
.m2-mn{display:flex;align-items:center;gap:6px;padding:6px 8px;border:1px solid var(--bdr);border-radius:6px;background:rgba(15,23,42,.5);margin-bottom:6px;position:relative;z-index:2;font-size:.6em;font-family:'JetBrains Mono'}
.m2-mn-tp{font-size:.55em;font-weight:700;padding:1px 4px;border-radius:3px;color:#fff;line-height:1}
.m2-ml{background:linear-gradient(135deg,#0284c7,#06b6d4)}.m2-dl{background:linear-gradient(135deg,#7c3aed,#a855f7)}
.m2-mn-id{font-weight:700;font-size:1em;color:var(--acc);min-width:14px}
.m2-mn-info{flex:1;min-width:0}.m2-mn-name{font-weight:600;color:var(--fg);font-size:.85em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.m2-mn-sub{font-size:.72em;color:var(--dim)}
.m2-mn-val{font-size:.72em;color:var(--dim);min-width:30px;text-align:right}.m2-mn-badge{font-size:.6em;font-weight:700;padding:1px 5px;border-radius:3px;line-height:1}
.m2-ok{background:#065f46;color:#34d399}.m2-warn{background:#78350f;color:#fbbf24}.m2-alarm{background:#7f1d1d;color:#f87171}
.m2-gn{padding:10px 14px;border-radius:10px;border:2px solid;text-align:center;position:absolute;left:0;right:0;transform:translateY(-50%);z-index:2;background:var(--card);box-shadow:0 2px 8px rgba(0,0,0,.05);white-space:nowrap;transition:.25s}
.m2-gn-t{font-size:.7em;font-weight:700;margin-bottom:3px}.m2-gn-c{font-size:.55em;color:var(--dim);font-family:'JetBrains Mono';margin-bottom:4px}
.m2-gn-s{font-size:.6em;font-weight:700;padding:2px 8px;border-radius:4px;display:inline-block}
.m2-gn-ok{background:#065f46;color:#34d399}.m2-gn-warn{background:#78350f;color:#fbbf24}.m2-gn-alarm{background:#7f1d1d;color:#f87171}
/* ═══ MODULE 2: Condition Health Tree (3 columns) ═══ */
.m2-ht-wrap{position:relative;display:flex;align-items:stretch;max-width:1000px;margin:0 auto;gap:0;overflow:visible;padding-bottom:20px}
.m2-ht-svg{position:absolute;top:0;left:0;pointer-events:none;z-index:1;overflow:visible}
.m2-ht-col{position:relative;z-index:2}
.m2-ht-hdr{font-size:.6em;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;font-family:'JetBrains Mono'}
.m2-cond{display:flex;align-items:center;gap:4px;padding:3px 6px;border:1px solid var(--bdr);border-radius:4px;margin-bottom:3px;font-size:.55em;font-family:'JetBrains Mono';background:rgba(15,23,42,.3)}
.m2-cond-id{font-weight:700;color:var(--acc);min-width:22px}.m2-cond-nm{flex:1;color:var(--fg);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.m2-cond-st{font-size:.8em;font-weight:600;padding:1px 5px;border-radius:3px}
.m2-cond-ok{color:#34d399}.m2-cond-warn{color:#fbbf24}.m2-cond-alarm{color:#f87171}
.m2-equip{padding:8px 10px;border:1px solid var(--bdr);border-radius:6px;text-align:center;background:rgba(15,23,42,.4);position:absolute;left:0;right:0;transform:translateY(-50%)}
.m2-equip-nm{font-size:.62em;font-weight:700;color:var(--fg)}.m2-equip-cnt{font-size:.5em;color:var(--dim);font-family:'JetBrains Mono'}
.m2-equip-st{font-size:.55em;font-weight:700;margin-top:2px}
@media(max-width:768px){.m2-tree-wrap,.m2-ht-wrap{flex-direction:column;gap:20px}.m2-tree-wrap>div,.m2-ht-wrap .m2-ht-col{flex:1 1 100%!important;margin:0!important;position:relative!important}.m2-gn,.m2-equip{position:relative!important;transform:none!important;margin-bottom:8px}}
/* ═══ MODULE 3: Charger Offline Detection Tree ═══ */
.m3-page{display:none;animation:fu .45s ease}
.m3-page.on{display:block}
.m5-page{display:none;animation:fu .45s ease}
.m5-page.on{display:block}
/* ═══ M5 Network Topology Tree ═══ */
.m5-tree-wrap{position:relative;padding:24px 0}
.m5-tree-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:0}
.m5-tree-layers{display:flex;flex-direction:column;align-items:center;gap:0;position:relative;z-index:1}
.m5-tree-layer{display:flex;justify-content:center;gap:0;flex-wrap:wrap;position:relative;z-index:1}
.m5-net-node{display:inline-flex;flex-direction:column;align-items:center;gap:2px;padding:8px 16px;border-radius:10px;font-size:.68em;font-weight:700;border:1.5px solid var(--bdr);background:var(--glass);backdrop-filter:blur(12px);transition:all .4s;cursor:default;min-width:80px;text-align:center}
.m5-net-node.up{border-color:rgba(52,211,153,.4);color:#34d399;box-shadow:0 0 12px rgba(52,211,153,.1),inset 0 0 20px rgba(52,211,153,.03)}
.m5-net-node.down{border-color:rgba(248,113,113,.5);color:#f87171;box-shadow:0 0 12px rgba(248,113,113,.15),inset 0 0 20px rgba(248,113,113,.04);animation:pulse 1.5s infinite}
.m5-net-node .m5-led{width:8px;height:8px;border-radius:50%;background:#64748b;flex-shrink:0}
.m5-net-node.up .m5-led{background:#34d399;box-shadow:0 0 8px #34d399}
.m5-net-node.down .m5-led{background:#f87171;box-shadow:0 0 8px #f87171}
.m5-net-node .m5-n-icon{font-size:1.3em;line-height:1}
.m5-net-node .m5-n-label{font-size:.95em;font-weight:800;letter-spacing:.3px}
.m5-net-node .m5-n-sub{font-size:.72em;opacity:.6;font-family:'JetBrains Mono';font-weight:400}
.m5-net-node .m5-n-top{display:flex;align-items:center;gap:5px}
/* M5 Severity gauge & root cause */
.m5-rc-badge{display:inline-block;padding:6px 18px;border-radius:8px;font-size:.72em;font-weight:800;letter-spacing:.8px}
.m5-rc-normal{background:rgba(52,211,153,.12);color:#34d399;border:1px solid rgba(52,211,153,.3);box-shadow:0 0 12px rgba(52,211,153,.08)}
.m5-rc-warning{background:rgba(251,191,36,.12);color:#fbbf24;border:1px solid rgba(251,191,36,.3);box-shadow:0 0 12px rgba(251,191,36,.08)}
.m5-rc-critical{background:rgba(248,113,113,.12);color:#f87171;border:1px solid rgba(248,113,113,.3);box-shadow:0 0 12px rgba(248,113,113,.08)}
/* M5 Condition table */
.m5-cond-tbl{width:100%;border-collapse:separate;border-spacing:0;font-size:.6em}
.m5-cond-tbl thead th{padding:8px 10px;font-weight:800;font-size:.85em;letter-spacing:.8px;text-transform:uppercase;color:var(--dim);background:var(--glass);border-bottom:2px solid var(--bdr);position:sticky;top:0;text-align:left}
.m5-cond-tbl tbody td{padding:7px 10px;border-bottom:1px solid rgba(100,116,139,.08);font-family:'JetBrains Mono';color:var(--tx2)}
.m5-cond-tbl tbody tr:hover{background:rgba(56,189,248,.03)}
.m5-cond-tbl .m5-type-badge{font-size:.8em;font-weight:800;padding:2px 8px;border-radius:4px;letter-spacing:.5px}
.m5-cond-tbl .m5-type-ai{background:rgba(14,165,233,.1);color:#38bdf8}
.m5-cond-tbl .m5-type-rule{background:rgba(249,115,22,.1);color:#fb923c}
.m5-cond-tbl .m5-type-hybrid{background:rgba(167,139,250,.1);color:#a78bfa}
.m5-cond-tbl .m5-eq-dot{width:6px;height:6px;border-radius:50%;display:inline-block;margin-right:5px}
.m3-tree-wrap{position:relative;display:flex;align-items:stretch;max-width:1000px;margin:0 auto;gap:0;overflow:visible;padding-bottom:20px}
.m3-tree-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1;overflow:visible}
.m3-col-m{flex:0 0 260px;z-index:2;padding-top:6px}
.m3-col-g{flex:0 0 160px;z-index:2;position:relative;margin:0 40px}
.m3-col-r{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:2;min-width:0}

/* Model nodes (left column) */
.m3-mn{display:flex;align-items:center;gap:6px;padding:5px 10px;border-radius:8px;background:var(--glass);border:1px solid var(--bdr);transition:all .35s;cursor:default;position:relative;min-height:36px;margin-bottom:6px}
.m3-mn:hover{border-color:var(--h-acc);box-shadow:0 0 12px rgba(6,182,212,.08)}
.m3-mn.m3-alarm{border-color:#ef4444;background:rgba(239,68,68,.05);animation:m3pulse 2s infinite}
.m3-mn.m3-warn{border-color:#d97706;background:rgba(217,119,6,.04)}
.m3-mn-id{font-family:'JetBrains Mono';font-size:.65em;font-weight:800;color:var(--dim);min-width:20px}
.m3-mn-info{flex:1;min-width:0}
.m3-mn-name{font-size:.66em;font-weight:700;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.m3-mn-sub{font-size:.52em;color:var(--dim);font-family:'JetBrains Mono';margin-top:1px}
.m3-mn-val{font-family:'JetBrains Mono';font-size:.62em;font-weight:700;color:var(--tx2);min-width:40px;text-align:right}
.m3-mn-badge{font-family:'JetBrains Mono';font-size:.55em;font-weight:800;padding:2px 6px;border-radius:5px;min-width:28px;text-align:center;letter-spacing:.5px}
.m3-mn-badge.m3-ok{background:rgba(22,163,74,.1);color:#16a34a}
.m3-mn-badge.m3-al{background:rgba(239,68,68,.12);color:#ef4444}
.m3-mn-badge.m3-wr{background:rgba(217,119,6,.1);color:#d97706}
.m3-mn-badge.m3-wt{background:rgba(59,130,246,.1);color:#3b82f6}
.m3-mn-tp{position:absolute;top:3px;right:5px;font-family:'JetBrains Mono';font-size:.48em;font-weight:800;padding:1px 5px;border-radius:3px;letter-spacing:.5px;opacity:.7}
.m3-mn-tp.m3-ml{background:linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.06));color:#0ea5e9}
.m3-mn-tp.m3-dl{background:linear-gradient(135deg,rgba(124,58,237,.12),rgba(168,85,247,.06));color:#a855f7}

/* Group nodes (middle column) */
.m3-gn{padding:10px 14px;border-radius:10px;border:2px solid;position:absolute;left:0;right:0;transform:translateY(-50%);transition:.25s;background:var(--card);box-shadow:0 2px 8px rgba(0,0,0,.05);white-space:nowrap;text-align:center}
.m3-gn-t{font-size:.72em;font-weight:800;display:flex;align-items:center;gap:5px}
.m3-gn-c{font-size:.52em;color:var(--dim);font-family:'JetBrains Mono';margin-top:2px;font-weight:600}
.m3-gn-s{font-size:.54em;font-family:'JetBrains Mono';font-weight:700;margin-top:4px;padding:2px 7px;border-radius:4px;display:inline-block}
.m3-gn-s.m3-gn-ok{background:rgba(22,163,74,.1);color:#16a34a}
.m3-gn-s.m3-gn-al{background:rgba(239,68,68,.12);color:#ef4444}
.m3-gn-s.m3-gn-wr{background:rgba(217,119,6,.1);color:#d97706}

/* Root Cause Status (right column) */
.m3-root{text-align:center;padding:10px}
.m3-root-status{font-family:'JetBrains Mono';font-size:1.1em;font-weight:900;letter-spacing:1px;margin-top:8px}
.m3-root-sub{font-size:.6em;color:var(--dim);font-family:'JetBrains Mono';margin-top:4px;font-weight:600}

/* Root Cause Gauge for Module 3 */
.m3-gauge-wrap{display:flex;flex-direction:column;align-items:center}
.m3-gauge{width:230px;height:146px;display:block}

/* Probability bars */
.m3-prob-wrap{display:flex;flex-direction:column;gap:6px;margin-top:14px}
.m3-prob-row{display:flex;align-items:center;gap:8px;font-size:.62em;font-family:'JetBrains Mono'}
.m3-prob-lbl{min-width:100px;font-weight:700;text-align:right;color:var(--tx2)}
.m3-prob-bar{flex:1;height:14px;border-radius:3px;background:var(--glass);overflow:hidden;position:relative}
.m3-prob-fill{height:100%;border-radius:3px;transition:width .6s ease}
.m3-prob-val{min-width:44px;font-weight:800;text-align:right}

/* Signal monitor grid */
.m3-sig-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px}
.m3-sig{padding:10px 12px;border-radius:8px;background:var(--glass);border:1px solid var(--bdr)}
.m3-sig-name{font-size:.58em;color:var(--dim);font-weight:700;text-transform:uppercase;letter-spacing:.5px}
.m3-sig-val{font-family:'JetBrains Mono';font-size:1em;font-weight:800;color:var(--tx);margin-top:3px}
.m3-sig-unit{font-size:.6em;color:var(--dim);font-weight:600}
.m3-sig.m3-sig-off{border-color:#ef4444;background:rgba(239,68,68,.04)}
.m3-sig.m3-sig-off .m3-sig-val{color:#ef4444}

/* Early Warning Panel */
.m3-ew-panel{display:flex;align-items:center;gap:14px;padding:14px 18px;border-radius:12px;border:1.5px solid var(--bdr);background:var(--glass)}
.m3-ew-icon{font-size:2em;line-height:1}
.m3-ew-info{flex:1}
.m3-ew-title{font-size:.78em;font-weight:800;color:var(--tx)}
.m3-ew-sub{font-size:.58em;color:var(--dim);font-family:'JetBrains Mono';margin-top:2px}
.m3-ew-badge{font-family:'JetBrains Mono';font-size:.82em;font-weight:900;padding:6px 16px;border-radius:8px}
.m3-ew-safe{background:rgba(22,163,74,.1);color:#16a34a;border:1px solid rgba(22,163,74,.2)}
.m3-ew-danger{background:rgba(239,68,68,.1);color:#ef4444;border:1px solid rgba(239,68,68,.2);animation:m3pulse 2s infinite}
.m3-ew-caution{background:rgba(217,119,6,.1);color:#d97706;border:1px solid rgba(217,119,6,.2)}

@keyframes m3pulse{0%,100%{opacity:1}50%{opacity:.7}}

/* Dark theme overrides for Module 3 */
[data-theme="dark"] .m3-mn{background:rgba(30,41,59,.7);border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .m3-gn{background:rgba(30,41,59,.5)}
[data-theme="dark"] .m3-sig{background:rgba(30,41,59,.6);border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .m3-ew-panel{background:rgba(30,41,59,.6);border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .m3-gauge #m3GVal{fill:#e2e8f0}
[data-theme="dark"] .m3-gauge #m3Needle path{fill:#e2e8f0}
[data-theme="dark"] .m3-gauge #m3Needle circle:nth-child(1){fill:#1e293b;stroke:#e2e8f0}
[data-theme="dark"] .m3-gauge #m3Needle circle:nth-child(2){fill:#e2e8f0}

/* Cyber theme for Module 3 */
[data-theme="cyber"] .m3-mn{background:rgba(0,32,48,.5);border-color:rgba(0,224,255,.1)}
[data-theme="cyber"] .m3-mn:hover{border-color:rgba(0,224,255,.3);box-shadow:0 0 12px rgba(0,224,255,.08)}
[data-theme="cyber"] .m3-gn{background:rgba(0,32,48,.4)}
[data-theme="cyber"] .m3-sig{background:rgba(0,32,48,.5);border-color:rgba(0,224,255,.08)}
[data-theme="cyber"] .m3-ew-panel{background:rgba(0,32,48,.5);border-color:rgba(0,224,255,.1)}
[data-theme="cyber"] .m3-gauge #m3GVal{fill:#00e0ff}
[data-theme="cyber"] .m3-gauge #m3Needle path{fill:#00e0ff}
[data-theme="cyber"] .m3-gauge #m3Needle circle:nth-child(1){fill:#0a1628;stroke:#00e0ff}
[data-theme="cyber"] .m3-gauge #m3Needle circle:nth-child(2){fill:#00e0ff}

/* Neural theme for Module 3 */
[data-theme="neural"] .m3-mn{background:rgba(30,20,50,.5);border-color:rgba(168,85,247,.1)}
[data-theme="neural"] .m3-mn:hover{border-color:rgba(168,85,247,.25);box-shadow:0 0 12px rgba(168,85,247,.08)}
[data-theme="neural"] .m3-gn{background:rgba(30,20,50,.4)}
[data-theme="neural"] .m3-sig{background:rgba(30,20,50,.5);border-color:rgba(168,85,247,.08)}
[data-theme="neural"] .m3-ew-panel{background:rgba(30,20,50,.5);border-color:rgba(168,85,247,.1)}
[data-theme="neural"] .m3-gauge #m3GVal{fill:#c084fc}
[data-theme="neural"] .m3-gauge #m3Needle path{fill:#c084fc}
[data-theme="neural"] .m3-gauge #m3Needle circle:nth-child(1){fill:#1a0e30;stroke:#c084fc}
[data-theme="neural"] .m3-gauge #m3Needle circle:nth-child(2){fill:#c084fc}

/* ═══ DB CONNECTION STATUS BAR ═══ */
.db-bar{display:flex;align-items:center;gap:10px;padding:8px 14px;border-radius:8px;background:var(--glass);border:1px solid var(--bdr);margin-bottom:10px;flex-wrap:wrap;font-family:'JetBrains Mono';font-size:.56em}
.db-chip{display:flex;align-items:center;gap:6px;padding:4px 10px;border-radius:6px;border:1px solid var(--bdr);background:var(--card);transition:all .4s}
.db-chip.ok{border-color:rgba(22,163,74,.25);background:rgba(22,163,74,.05)}
.db-chip.err{border-color:rgba(239,68,68,.25);background:rgba(239,68,68,.05)}
.db-chip.wait{border-color:rgba(14,165,233,.2);background:rgba(14,165,233,.04)}
.db-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;transition:all .3s}
.db-dot.ok{background:#16a34a;box-shadow:0 0 6px rgba(22,163,74,.4)}
.db-dot.err{background:#ef4444;box-shadow:0 0 6px rgba(239,68,68,.4)}
.db-dot.wait{background:#0ea5e9;animation:dbPulse 1.5s ease-in-out infinite}
@keyframes dbPulse{0%,100%{opacity:1}50%{opacity:.3}}
.db-lbl{font-weight:700;color:var(--dim);letter-spacing:.3px}
.db-val{font-weight:800;color:var(--tx)}
.db-val.ok{color:#16a34a}
.db-val.err{color:#ef4444}
.db-sep{width:1px;height:20px;background:var(--bdr);flex-shrink:0}
.db-detail{font-weight:600;color:var(--dim);font-size:.92em}
[data-theme="dark"] .db-bar{background:rgba(30,41,59,.6);border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .db-chip{background:#1e293b}
[data-theme="cyber"] .db-bar{background:rgba(0,32,48,.5);border-color:rgba(0,224,255,.1)}
[data-theme="cyber"] .db-chip{background:rgba(0,32,48,.6)}
[data-theme="cyber"] .db-dot.ok{background:#00ff88;box-shadow:0 0 6px rgba(0,255,136,.4)}
[data-theme="neural"] .db-bar{background:rgba(30,20,50,.5);border-color:rgba(168,85,247,.1)}
[data-theme="neural"] .db-chip{background:rgba(30,20,50,.6)}

/* ═══ MODULE 3: Auto-Predict Panel ═══ */
.m3-ap{display:flex;align-items:center;gap:12px;padding:10px 16px;border-radius:10px;background:var(--glass);border:1px solid var(--bdr);margin-bottom:10px;flex-wrap:wrap}
.m3-ap-grp{display:flex;align-items:center;gap:8px}
.m3-ap-lbl{font-family:'JetBrains Mono';font-size:.58em;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--dim)}
.m3-ap-cd{font-family:'JetBrains Mono';font-size:.72em;font-weight:900;min-width:52px;text-align:center;padding:3px 8px;border-radius:6px;background:var(--card);border:1px solid var(--bdr);color:var(--dim);transition:all .3s}
.m3-ap-cd.on{color:#16a34a;border-color:rgba(22,163,74,.25);background:rgba(22,163,74,.06)}
.m3-ap-cd.run{color:#0ea5e9;border-color:rgba(14,165,233,.25);background:rgba(14,165,233,.06);animation:ap-blink 1s ease-in-out infinite}
.m3-ap-cd.err{color:#ef4444;border-color:rgba(239,68,68,.25);background:rgba(239,68,68,.06)}
.m3-ap-sep{width:1px;height:28px;background:var(--bdr);flex-shrink:0}
.m3-ap-ts{display:flex;flex-direction:column;gap:1px}
.m3-ap-ts-row{display:flex;align-items:center;gap:5px;font-family:'JetBrains Mono';font-size:.52em;color:var(--dim)}
.m3-ap-ts-row i{font-style:normal;font-size:1em}
.m3-ap-ts-val{font-weight:700;color:var(--tx2)}
.m3-ap-badge{font-family:'JetBrains Mono';font-size:.5em;font-weight:800;padding:2px 8px;border-radius:4px;letter-spacing:.5px}
.m3-ap-badge.idle{background:rgba(100,116,139,.08);color:#64748b}
.m3-ap-badge.ok{background:rgba(22,163,74,.08);color:#16a34a}
.m3-ap-badge.running{background:rgba(14,165,233,.08);color:#0ea5e9;animation:ap-blink 1s ease-in-out infinite}
.m3-ap-badge.fail{background:rgba(239,68,68,.08);color:#ef4444}
[data-theme="dark"] .m3-ap{background:rgba(30,41,59,.6);border-color:rgba(51,65,85,.5)}
[data-theme="dark"] .m3-ap-cd{background:#1e293b}
[data-theme="cyber"] .m3-ap{background:rgba(0,32,48,.5);border-color:rgba(0,224,255,.1)}
[data-theme="cyber"] .m3-ap-cd.on{color:#00ff88;border-color:rgba(0,255,136,.2)}
[data-theme="cyber"] .m3-ap-cd.run{color:#00e0ff;border-color:rgba(0,224,255,.2)}
[data-theme="neural"] .m3-ap{background:rgba(30,20,50,.5);border-color:rgba(168,85,247,.1)}
[data-theme="neural"] .m3-ap-cd.on{color:#34d399;border-color:rgba(52,211,153,.2)}
[data-theme="neural"] .m3-ap-cd.run{color:#c084fc;border-color:rgba(192,132,252,.2)}

/* ═══ MODULE 3: Model Loading Indicator ═══ */
.m3-load-panel{border-radius:10px;background:var(--glass);border:1px solid var(--bdr);padding:12px 16px;margin-bottom:12px;overflow:hidden;transition:max-height .5s ease,opacity .4s ease}
.m3-load-panel.collapsed{max-height:42px}
.m3-load-hdr{display:flex;align-items:center;justify-content:space-between;cursor:pointer;user-select:none}
.m3-load-hdr-l{display:flex;align-items:center;gap:8px;font-size:.72em;font-weight:800;color:var(--tx)}
.m3-load-hdr-l i{font-style:normal}
.m3-load-hdr-r{display:flex;align-items:center;gap:10px}
.m3-load-count{font-family:'JetBrains Mono';font-size:.6em;font-weight:700;color:var(--dim)}
.m3-load-toggle{font-size:.7em;color:var(--dim);transition:transform .3s;cursor:pointer}
.m3-load-panel.collapsed .m3-load-toggle{transform:rotate(-90deg)}
.m3-load-pbar{height:3px;border-radius:2px;background:var(--bdr);margin:10px 0 8px;overflow:hidden}
.m3-load-pfill{height:100%;border-radius:2px;background:linear-gradient(90deg,#0ea5e9,#22c55e);width:0%;transition:width .6s ease}
.m3-load-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:6px}
@media(max-width:800px){.m3-load-grid{grid-template-columns:1fr}}
.m3-load-item{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:8px;background:var(--card);border:1px solid var(--bdr);transition:all .4s}
.m3-load-item.ok{border-color:rgba(22,163,74,.25);background:rgba(22,163,74,.04)}
.m3-load-item.err{border-color:rgba(239,68,68,.25);background:rgba(239,68,68,.04)}
.m3-load-item.loading{border-color:rgba(14,165,233,.2)}
.m3-load-id{font-family:'JetBrains Mono';font-size:.62em;font-weight:900;color:var(--dim);min-width:22px}
.m3-load-info{flex:1;min-width:0}
.m3-load-name{font-size:.6em;font-weight:700;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.m3-load-desc{font-size:.48em;color:var(--dim);font-family:'JetBrains Mono';margin-top:1px}
.m3-load-tp{font-family:'JetBrains Mono';font-size:.44em;font-weight:800;padding:1px 5px;border-radius:3px;letter-spacing:.5px}
.m3-load-tp.ml{background:rgba(14,165,233,.1);color:#0ea5e9}
.m3-load-tp.dl{background:rgba(124,58,237,.1);color:#a855f7}
.m3-load-st{width:20px;height:20px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
/* Spinner */
.m3-load-spin{width:16px;height:16px;border:2px solid var(--bdr);border-top-color:#0ea5e9;border-radius:50%;animation:m3spin .8s linear infinite}
@keyframes m3spin{to{transform:rotate(360deg)}}
/* Check icon */
.m3-load-ok{color:#16a34a;font-size:.85em;font-weight:900;animation:m3pop .3s ease}
/* Error icon */
.m3-load-err{color:#ef4444;font-size:.85em;font-weight:900;animation:m3pop .3s ease}
@keyframes m3pop{0%{transform:scale(0);opacity:0}60%{transform:scale(1.2)}100%{transform:scale(1);opacity:1}}
/* Theme overrides */
[data-theme="dark"] .m3-load-item{background:#1e293b}
[data-theme="dark"] .m3-load-panel{background:rgba(30,41,59,.6);border-color:rgba(51,65,85,.5)}
[data-theme="cyber"] .m3-load-panel{background:rgba(0,32,48,.5);border-color:rgba(0,224,255,.1)}
[data-theme="cyber"] .m3-load-item{background:rgba(0,32,48,.6);border-color:rgba(0,224,255,.06)}
[data-theme="cyber"] .m3-load-spin{border-top-color:#00e0ff}
[data-theme="neural"] .m3-load-panel{background:rgba(30,20,50,.5);border-color:rgba(168,85,247,.1)}
[data-theme="neural"] .m3-load-item{background:rgba(30,20,50,.6);border-color:rgba(168,85,247,.06)}
[data-theme="neural"] .m3-load-spin{border-top-color:#c084fc}

/* Responsive */
@media(max-width:768px){.m3-tree-wrap{flex-direction:column;gap:20px}.m3-tree-wrap>div{flex:1 1 100%!important;margin:0!important}.m3-gn{position:relative!important;transform:none!important;margin-bottom:8px}}


/* ═══ Module 6: RUL Prediction ═══ */
.m6-page{display:none;animation:fu .45s ease}
.m6-page.on{display:block}
.m6-sys-gauge{display:flex;flex-direction:column;align-items:center;gap:4px}
.m6-sys-gauge svg{filter:drop-shadow(0 0 12px rgba(52,211,153,.25))}
.m6-sys-label{font-size:.55em;color:var(--dim);font-weight:600;letter-spacing:1px;text-transform:uppercase}
.m6-sys-val{font-size:2em;font-weight:800;font-family:'JetBrains Mono';letter-spacing:-1px}
.m6-sys-sub{font-size:.6em;color:var(--dim);font-family:'JetBrains Mono'}
.m6-cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px}
.m6-cat{border-radius:10px;padding:14px;background:var(--glass);border:1px solid var(--bdr);transition:all .25s}
.m6-cat:hover{border-color:var(--accent);transform:translateY(-1px);box-shadow:0 4px 16px rgba(0,0,0,.1)}
.m6-cat-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.m6-cat-name{font-weight:700;font-size:.72em;display:flex;align-items:center;gap:6px}
.m6-cat-cnt{font-size:.5em;padding:2px 7px;border-radius:10px;background:rgba(100,116,139,.12);color:var(--dim);font-family:'JetBrains Mono';font-weight:600}
.m6-cat-pct{font-size:1.1em;font-weight:800;font-family:'JetBrains Mono'}
.m6-cat-bar{height:6px;border-radius:3px;background:rgba(100,116,139,.15);overflow:hidden;margin:6px 0}
.m6-cat-fill{height:100%;border-radius:3px;transition:width .6s ease,background .4s}
.m6-cat-info{display:flex;justify-content:space-between;font-size:.52em;color:var(--dim);font-family:'JetBrains Mono'}
.m6-cat-method{font-size:.48em;padding:1px 6px;border-radius:4px;font-weight:600;margin-left:6px}
.m6-cat-method.arr{background:rgba(251,146,60,.12);color:#fb923c}
.m6-cat-method.cyc{background:rgba(56,189,248,.12);color:#38bdf8}
.m6-prio-list{display:flex;flex-direction:column;gap:6px}
.m6-prio-item{display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:8px;background:var(--glass);border:1px solid var(--bdr);font-size:.62em;font-family:'JetBrains Mono'}
.m6-prio-rank{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.7em;color:#fff}
.m6-legend{display:flex;gap:14px;font-size:.55em;font-family:'JetBrains Mono';align-items:center;flex-wrap:wrap}
.m6-legend span{display:flex;align-items:center;gap:4px}
.m6-legend i{width:10px;height:10px;border-radius:2px;display:inline-block}
.m6-hg-row{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid var(--bdr);font-size:.6em;font-family:'JetBrains Mono'}
.m6-hg-row:last-child{border-bottom:none}
.m6-hg-name{width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.m6-hg-bar{flex:1;height:5px;border-radius:3px;background:rgba(100,116,139,.12);overflow:hidden}
.m6-hg-fill{height:100%;border-radius:3px;transition:width .5s}
.m6-hg-pct{width:55px;text-align:right;font-weight:700}


/* ═══ MODULE 7 Modern State Monitor ═══ */
.m7-hero{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
@media(max-width:900px){.m7-hero{grid-template-columns:1fr}}
.m7-sc{position:relative;border-radius:16px;padding:20px 24px;background:var(--card);border:1px solid var(--brd);overflow:hidden;transition:all .3s}
.m7-sc::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0}
.m7-sc.icp::before{background:linear-gradient(90deg,#22c55e,#06b6d4)}
.m7-sc.usl::before{background:linear-gradient(90deg,#3b82f6,#8b5cf6)}
.m7-sc:hover{box-shadow:0 8px 32px rgba(0,0,0,.08);transform:translateY(-1px)}
.m7-ch{display:flex;align-items:center;gap:8px;margin-bottom:16px;font-weight:700;font-size:.78em;letter-spacing:.02em;text-transform:uppercase;color:var(--dim)}
.m7-ch .m7i{width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.1em}
.m7-sc.icp .m7i{background:linear-gradient(135deg,#dcfce7,#d1fae5);color:#16a34a}
.m7-sc.usl .m7i{background:linear-gradient(135deg,#dbeafe,#e0e7ff);color:#3b82f6}
[data-theme="dark"] .m7-sc.icp .m7i{background:linear-gradient(135deg,#064e3b,#065f46);color:#34d399}
[data-theme="dark"] .m7-sc.usl .m7i{background:linear-gradient(135deg,#1e1b4b,#312e81);color:#818cf8}
.m7-gr{display:flex;align-items:center;gap:20px;margin-bottom:14px}
.m7-rw{position:relative;width:88px;height:88px;flex-shrink:0}
.m7-rw svg{width:88px;height:88px;transform:rotate(-90deg)}
.m7-rw .rbg{fill:none;stroke:var(--brd);stroke-width:5}
.m7-rw .rfg{fill:none;stroke-width:5;stroke-linecap:round;transition:stroke-dashoffset .6s cubic-bezier(.4,0,.2,1),stroke .4s}
.m7-rl{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-weight:800;font-family:'JetBrains Mono',monospace;font-size:1.15em;text-align:center;line-height:1.1}
.m7-rl small{display:block;font-size:.5em;font-weight:600;opacity:.6;margin-top:2px}
.m7-si h3{font-size:1.05em;font-weight:700;margin:0 0 4px}
.m7-si p{font-size:.73em;color:var(--dim);margin:0;line-height:1.5}
.m7-sg{display:flex;flex-wrap:wrap;gap:4px}
.m7-pl{padding:3px 8px;border-radius:6px;font-size:.62em;font-family:'JetBrains Mono',monospace;font-weight:500;border:1px solid var(--brd);color:var(--dim);transition:all .3s;white-space:nowrap}
.m7-pl.on{font-weight:700;border-width:1.5px;box-shadow:0 0 12px var(--pg)}
.m7-tc{border-radius:16px;padding:18px 20px;background:var(--card);border:1px solid var(--brd)}
.m7-th{display:flex;align-items:center;margin-bottom:12px}
.m7-th h4{font-size:.75em;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--dim);margin:0;display:flex;align-items:center;gap:6px}
.m7-tp{width:6px;height:6px;border-radius:50%;background:#22c55e;animation:m7p 2s infinite}
@keyframes m7p{0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(34,197,94,.4)}50%{opacity:.7;box-shadow:0 0 0 6px rgba(34,197,94,0)}}
.m7-tg{display:grid;grid-template-columns:1fr 1fr;gap:6px 12px;max-height:200px;overflow-y:auto}
.m7-ti{display:flex;justify-content:space-between;align-items:center;padding:4px 0;border-bottom:1px dotted var(--brd)}
.m7-ti .tk{font-size:.66em;color:var(--dim);font-weight:500}
.m7-ti .tv{font-size:.72em;font-weight:700;font-family:'JetBrains Mono',monospace}
.m7-wn{border-radius:12px;padding:10px 14px;border-left:3px solid;margin-bottom:6px;font-size:.72em;display:flex;align-items:center;gap:8px;animation:m7fi .3s}
.m7-wn.cr{border-color:#ef4444;background:rgba(239,68,68,.06);color:#ef4444}
.m7-wn.hi{border-color:#f97316;background:rgba(249,115,22,.06);color:#f97316}
.m7-wn.me{border-color:#eab308;background:rgba(234,179,8,.06);color:#eab308}
@keyframes m7fi{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
.m7-sqc{border-radius:16px;padding:20px 24px;background:var(--card);border:1px solid var(--brd);margin-bottom:16px}
.m7-sqc h4{font-size:.78em;font-weight:700;margin:0 0 14px;display:flex;align-items:center;gap:8px}
.m7-sf{display:flex;flex-wrap:wrap;gap:4px;align-items:center}
.m7-ss{padding:5px 12px;border-radius:8px;font-size:.66em;font-weight:600;color:#fff;white-space:nowrap;transition:all .3s;opacity:.45}
.m7-ss.on{opacity:1;box-shadow:0 2px 12px var(--sw);transform:scale(1.08)}
.m7-ss.dn{opacity:.82}
.m7-sa{color:var(--dim);font-size:.6em;opacity:.3}
.m7-ab{border-radius:14px;padding:12px 20px;background:var(--card);border:1px solid var(--brd);margin-bottom:16px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.m7-ab .sep{width:1px;height:24px;background:var(--brd)}
.m7-ab .al{font-size:.65em;font-weight:600;color:var(--dim);text-transform:uppercase;letter-spacing:.04em}
.m7-ab .av{font-size:.72em;font-weight:700;font-family:'JetBrains Mono',monospace}
.m7-rg{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:16px}
@media(max-width:900px){.m7-rg{grid-template-columns:repeat(3,1fr)}}
.m7-rc{border-radius:14px;padding:14px 16px;background:var(--card);border:1px solid var(--brd);overflow:hidden;position:relative}
.m7-rc::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px}
.m7-rc.ok::after{background:linear-gradient(90deg,#22c55e,#34d399)}
.m7-rc.an::after{background:linear-gradient(90deg,#ef4444,#f97316)}
.m7-rc .rn{font-size:.7em;font-weight:600;color:var(--dim);margin-bottom:6px}
.m7-rc .rs{font-size:1.4em;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1}
.m7-rc .rt{font-size:.62em;font-weight:700;margin-top:4px;text-transform:uppercase;letter-spacing:.06em}
.m7-sb{display:inline-flex;align-items:center;gap:4px;padding:2px 10px;border-radius:20px;font-size:.6em;font-weight:600;font-family:'JetBrains Mono',monospace}
.m7-sb.mq{background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.2)}
.m7-sb.mg{background:rgba(59,130,246,.1);color:#2563eb;border:1px solid rgba(59,130,246,.2)}
.m7-sb.of{background:rgba(107,114,128,.1);color:#6b7280;border:1px solid rgba(107,114,128,.2)}
[data-theme="dark"] .m7-sb.mq{background:rgba(34,197,94,.15);color:#4ade80}
[data-theme="dark"] .m7-sb.mg{background:rgba(96,165,250,.15);color:#93c5fd}


/* ═══ MODULE 1: MDB Filter Clogging Prediction ═══ */
.m1-page{display:none}.m1-page.on{display:block}
.m1-hero{display:grid;grid-template-columns:280px 1fr;gap:16px;margin-bottom:16px}
@media(max-width:800px){.m1-hero{grid-template-columns:1fr}}
.m1-gauge-card{border-radius:16px;padding:24px;background:var(--card);border:1px solid var(--brd);display:flex;flex-direction:column;align-items:center;gap:12px;position:relative;overflow:hidden}
.m1-gauge-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#22c55e,#eab308,#ef4444)}
.m1-gauge-wrap{position:relative;width:180px;height:180px}
.m1-gauge-wrap svg{width:180px;height:180px;transform:rotate(135deg)}
.m1-gauge-wrap .gbg{fill:none;stroke:var(--brd);stroke-width:12;stroke-linecap:round}
.m1-gauge-wrap .gfg{fill:none;stroke-width:12;stroke-linecap:round;transition:stroke-dashoffset .8s cubic-bezier(.4,0,.2,1),stroke 1s}
.m1-gauge-center{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center}
.m1-gauge-center .gval{font-size:2.2em;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1}
.m1-gauge-center .glbl{font-size:.65em;font-weight:600;color:var(--dim);margin-top:4px}
.m1-gauge-center .gst{font-size:.72em;font-weight:700;margin-top:2px;text-transform:uppercase;letter-spacing:.06em}
.m1-env-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px}
.m1-env{border-radius:12px;padding:14px 16px;background:var(--card);border:1px solid var(--brd);position:relative;overflow:hidden;transition:all .3s}
.m1-env::after{content:'';position:absolute;bottom:0;left:0;right:0;height:2px;background:var(--env-c,var(--brd))}
.m1-env .m1-ev{font-size:.62em;color:var(--dim);font-weight:600;text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px}
.m1-env .m1-en{font-size:1.5em;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1}
.m1-env .m1-eu{font-size:.6em;color:var(--dim);font-weight:500;margin-top:3px}
.m1-filter-bar{height:28px;border-radius:8px;background:var(--brd);overflow:hidden;position:relative;margin:8px 0}
.m1-filter-fill{height:100%;border-radius:8px;transition:width .8s cubic-bezier(.4,0,.2,1);position:relative}
.m1-filter-fill::after{content:attr(data-label);position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:.6em;font-weight:700;color:#fff;white-space:nowrap}
.m1-rg{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:16px}
@media(max-width:900px){.m1-rg{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.m1-rg{grid-template-columns:repeat(2,1fr)}}
.m1-rc{border-radius:14px;padding:14px 16px;background:var(--card);border:1px solid var(--brd);overflow:hidden;position:relative}
.m1-rc::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px}
.m1-rc.ok::after{background:linear-gradient(90deg,#22c55e,#34d399)}
.m1-rc.warn::after{background:linear-gradient(90deg,#eab308,#f59e0b)}
.m1-rc.crit::after{background:linear-gradient(90deg,#ef4444,#f97316)}
.m1-rc .rn{font-size:.7em;font-weight:600;color:var(--dim);margin-bottom:6px}
.m1-rc .rs{font-size:1.3em;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1}
.m1-rc .rt{font-size:.62em;font-weight:700;margin-top:4px;text-transform:uppercase;letter-spacing:.06em}
.m1-ab{border-radius:14px;padding:12px 20px;background:var(--card);border:1px solid var(--brd);margin-bottom:16px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.m1-ab .sep{width:1px;height:24px;background:var(--brd)}
.m1-ab .al{font-size:.65em;font-weight:600;color:var(--dim);text-transform:uppercase;letter-spacing:.04em}
.m1-ab .av{font-size:.72em;font-weight:700;font-family:'JetBrains Mono',monospace}

/* M1 Modern Additions */
.m1-hdr{border-radius:16px;padding:18px 24px;margin-bottom:16px;background:linear-gradient(135deg,var(--card) 0%,color-mix(in srgb,#059669 5%,var(--card)) 100%);border:1px solid var(--brd);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.m1-hdr-l{display:flex;align-items:center;gap:14px}
.m1-hdr-ico{width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,#059669,#0d9488);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.3em;flex-shrink:0;box-shadow:0 4px 14px rgba(5,150,105,.25)}
.m1-hdr h2{font-size:.92em;font-weight:800;margin:0;letter-spacing:-.01em}
.m1-hdr .sub{font-size:.64em;color:var(--dim);margin-top:3px;line-height:1.4}
.m1-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 12px;border-radius:20px;font-size:.6em;font-weight:600;font-family:'JetBrains Mono',monospace;transition:all .3s}
.m1-badge.mq{background:rgba(34,197,94,.1);color:#16a34a;border:1px solid rgba(34,197,94,.2)}
.m1-badge.mg{background:rgba(59,130,246,.1);color:#2563eb;border:1px solid rgba(59,130,246,.2)}
.m1-badge.of{background:rgba(107,114,128,.1);color:#6b7280;border:1px solid rgba(107,114,128,.2)}
[data-theme="dark"] .m1-badge.mq{background:rgba(34,197,94,.15);color:#4ade80}
[data-theme="dark"] .m1-badge.mg{background:rgba(96,165,250,.15);color:#93c5fd}
.m1-env:hover{transform:translateY(-1px);box-shadow:0 4px 16px rgba(0,0,0,.06)}
.m1-gauge-card:hover{box-shadow:0 8px 32px rgba(0,0,0,.08)}
.m1-algo-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px}
.m1-ac{border-radius:14px;padding:18px 20px;background:var(--card);border:1px solid var(--brd);position:relative;overflow:hidden;transition:all .3s}
.m1-ac::before{content:'';position:absolute;top:0;left:0;right:0;height:3px}
.m1-ac:hover{transform:translateY(-1px);box-shadow:0 4px 16px rgba(0,0,0,.06)}
.m1-ac .m1-at{display:flex;align-items:center;gap:8px;font-weight:700;font-size:.82em;margin-bottom:10px}
.m1-ac .m1-at .m1-ai{width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.85em;flex-shrink:0;color:#fff}
.m1-ac .m1-ad{font-size:.7em;color:var(--dim);line-height:1.65}
.m1-ac .m1-ab2{display:inline-block;padding:2px 8px;border-radius:4px;font-size:.6em;font-weight:600;margin-top:8px;font-family:'JetBrains Mono',monospace}
.m1-ens-card{border-radius:16px;padding:22px;background:var(--card);border:1px solid var(--brd);position:relative;overflow:hidden}
.m1-ens-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#059669,#0891b2,#7c3aed)}
.m1-ens-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;text-align:center}
.m1-ens-item .ek{font-size:.6em;color:var(--dim);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.m1-ens-item .ev{font-size:1.8em;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1}
.m1-pred-item{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px dotted var(--brd);font-size:.72em;transition:background .2s}
.m1-pred-item:hover{background:rgba(100,116,139,.03)}
.m1-hist-ctrl{border-radius:14px;padding:16px 20px;background:var(--card);border:1px solid var(--brd);margin-bottom:14px;display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end}
.m1-hist-ctrl label{font-size:.52em;font-weight:700;color:var(--dim);display:block;margin-bottom:4px;letter-spacing:.5px;text-transform:uppercase}
.m1-hist-ctrl select{font-family:'JetBrains Mono',monospace;font-size:.65em;padding:7px 14px;border-radius:8px;border:1px solid var(--brd);background:var(--card);color:var(--tx);min-width:120px;cursor:pointer;transition:border-color .2s}
.m1-hist-ctrl select:focus{border-color:#0891b2;outline:none}
.m1-hist-btn{display:inline-flex;align-items:center;gap:6px;font-size:.62em;padding:8px 20px;border-radius:8px;background:linear-gradient(135deg,rgba(5,150,105,.1),rgba(13,148,136,.06));border:1px solid rgba(5,150,105,.2);color:#059669;font-weight:700;cursor:pointer;transition:all .3s;letter-spacing:.3px}
.m1-hist-btn:hover{background:linear-gradient(135deg,rgba(5,150,105,.2),rgba(13,148,136,.12));box-shadow:0 0 14px rgba(5,150,105,.12)}
[data-theme="dark"] .m1-hist-btn{color:#34d399}
.m1-chart-card{border-radius:16px;padding:18px 20px;background:var(--card);border:1px solid var(--brd)}
.m1-pulse{width:6px;height:6px;border-radius:50%;background:#22c55e;display:inline-block;animation:m1pls 2s infinite}
@keyframes m1pls{0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(34,197,94,.4)}50%{opacity:.6;box-shadow:0 0 0 6px rgba(34,197,94,0)}}

/* ═══ DASHBOARD OVERVIEW ═══ */
.dash-page{display:none}.dash-page.on{display:block}
.dash-hdr{border-radius:18px;padding:22px 28px;margin-bottom:20px;background:linear-gradient(135deg,var(--card) 0%,color-mix(in srgb,#0ea5e9 5%,var(--card)) 100%);border:1px solid var(--brd);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px}
.dash-hdr-l{display:flex;align-items:center;gap:16px}
.dash-hdr-ico{width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,#0ea5e9,#6366f1);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.5em;flex-shrink:0;box-shadow:0 6px 20px rgba(14,165,233,.3)}
.dash-hdr h2{font-size:1em;font-weight:800;margin:0;letter-spacing:-.01em}
.dash-hdr .sub{font-size:.66em;color:var(--dim);margin-top:3px}
.dash-kpi{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:20px}
@media(max-width:1100px){.dash-kpi{grid-template-columns:repeat(3,1fr)}}
@media(max-width:700px){.dash-kpi{grid-template-columns:repeat(2,1fr)}}
@media(max-width:500px){.dash-kpi{grid-template-columns:1fr}}
.dash-kpi-card{border-radius:14px;padding:18px 20px;background:var(--card);border:1px solid var(--brd);text-align:center;position:relative;overflow:hidden}
.dash-kpi-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px}
.dash-kpi-card.green::before{background:linear-gradient(90deg,#22c55e,#34d399)}
.dash-kpi-card.yellow::before{background:linear-gradient(90deg,#eab308,#fbbf24)}
.dash-kpi-card.red::before{background:linear-gradient(90deg,#ef4444,#f87171)}
.dash-kpi-card.blue::before{background:linear-gradient(90deg,#0ea5e9,#38bdf8)}
.dash-kpi-label{font-size:.58em;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.dash-kpi-val{font-size:2em;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1}
.dash-kpi-sub{font-size:.58em;color:var(--dim);margin-top:4px}
.dash-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px;margin-bottom:20px}
@media(max-width:700px){.dash-grid{grid-template-columns:1fr}}
.dash-card{border-radius:16px;padding:0;background:var(--card);border:1px solid var(--brd);overflow:hidden;transition:all .3s;cursor:pointer;position:relative}
.dash-card:hover{transform:translateY(-2px);box-shadow:0 8px 28px rgba(0,0,0,.1)}
.dash-card-top{height:4px}
.dash-card-body{padding:18px 20px}
.dash-card-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.dash-card-hdr-l{display:flex;align-items:center;gap:10px}
.dash-card-ico{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1em;flex-shrink:0;color:#fff}
.dash-card-title{font-weight:700;font-size:.82em}
.dash-card-sub{font-size:.6em;color:var(--dim);margin-top:2px}
.dash-card-badge{padding:3px 10px;border-radius:20px;font-size:.55em;font-weight:700;font-family:'JetBrains Mono',monospace;text-transform:uppercase;letter-spacing:.04em}
.dash-card-badge.ok{background:rgba(34,197,94,.12);color:#22c55e;border:1px solid rgba(34,197,94,.2)}
.dash-card-badge.warn{background:rgba(234,179,8,.12);color:#eab308;border:1px solid rgba(234,179,8,.2)}
.dash-card-badge.crit{background:rgba(239,68,68,.12);color:#ef4444;border:1px solid rgba(239,68,68,.2)}
.dash-card-badge.off{background:rgba(107,114,128,.12);color:#6b7280;border:1px solid rgba(107,114,128,.2)}
.dash-card-metrics{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.dash-metric{padding:10px 12px;border-radius:10px;background:color-mix(in srgb,var(--brd) 40%,transparent)}
.dash-metric .mk{font-size:.52em;font-weight:600;color:var(--dim);text-transform:uppercase;letter-spacing:.04em;margin-bottom:3px}
.dash-metric .mv{font-size:1.1em;font-weight:800;font-family:'JetBrains Mono',monospace}
.dash-card-footer{padding:8px 20px;background:color-mix(in srgb,var(--brd) 20%,transparent);display:flex;justify-content:space-between;align-items:center;font-size:.55em;color:var(--dim)}
.dash-card-footer .dash-ts{font-family:'JetBrains Mono',monospace}
.dash-refresh-bar{border-radius:14px;padding:12px 20px;background:var(--card);border:1px solid var(--brd);display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:20px;font-size:.7em}
.dash-refresh-bar .sep{width:1px;height:20px;background:var(--brd)}
.dash-rb-btn{padding:6px 16px;border-radius:8px;background:linear-gradient(135deg,rgba(14,165,233,.1),rgba(99,102,241,.06));border:1px solid rgba(14,165,233,.2);color:#0ea5e9;font-weight:700;font-size:.9em;cursor:pointer;transition:all .3s;font-family:'JetBrains Mono',monospace}
.dash-rb-btn:hover{background:linear-gradient(135deg,rgba(14,165,233,.2),rgba(99,102,241,.12));box-shadow:0 0 14px rgba(14,165,233,.12)}
[data-theme="dark"] .dash-rb-btn{color:#38bdf8}
.dash-spin{display:inline-block;animation:dspin 1s linear infinite}
/* ─── Loading Overlay ─── */
.dash-loading-overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.45);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);z-index:99999;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity .3s ease}
.dash-loading-overlay.active{opacity:1;pointer-events:none}
.dash-loading-box{background:var(--card,#1e293b);border:1px solid var(--bdr,#334155);border-radius:20px;padding:32px 44px;min-width:340px;max-width:420px;box-shadow:0 20px 60px rgba(0,0,0,.4),0 0 40px rgba(14,165,233,.08);text-align:center;transform:scale(.9) translateY(10px);transition:transform .35s cubic-bezier(.34,1.56,.64,1);position:relative;overflow:hidden}
.dash-loading-overlay.active .dash-loading-box{transform:scale(1) translateY(0)}
.dash-loading-box::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,transparent,var(--ac,#0ea5e9),transparent);animation:dlShimmer 1.5s ease infinite}
@keyframes dlShimmer{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}
.dl-icon{font-size:2.4em;margin-bottom:12px;animation:dlPulse 1.2s ease-in-out infinite}
@keyframes dlPulse{0%,100%{transform:scale(1);opacity:.8}50%{transform:scale(1.12);opacity:1}}
.dl-title{font-size:1.05em;font-weight:800;color:var(--tx,#f1f5f9);margin-bottom:4px;letter-spacing:.3px}
.dl-sub{font-size:.72em;color:var(--dim,#94a3b8);margin-bottom:16px}
.dl-progress-track{width:100%;height:8px;background:var(--bg,#0f172a);border-radius:8px;overflow:hidden;position:relative;margin-bottom:10px}
.dl-progress-bar{height:100%;border-radius:8px;background:linear-gradient(90deg,#0ea5e9,#38bdf8,#0ea5e9);background-size:200% 100%;animation:dlBarGlow 1s ease infinite;transition:width .3s ease;width:0%}
@keyframes dlBarGlow{0%{background-position:200% 0}100%{background-position:0% 0}}
.dl-progress-text{display:flex;justify-content:space-between;font-size:.65em;font-family:'JetBrains Mono',monospace;color:var(--dim,#94a3b8)}
.dl-progress-pct{font-weight:700;color:var(--ac,#0ea5e9)}
.dl-module-status{margin-top:14px;display:flex;flex-wrap:wrap;gap:6px;justify-content:center}
.dl-mod-chip{font-size:.58em;padding:3px 10px;border-radius:20px;font-weight:700;font-family:'JetBrains Mono',monospace;border:1px solid var(--bdr,#334155);color:var(--dim,#94a3b8);background:transparent;transition:all .3s ease}
.dl-mod-chip.done{border-color:var(--ac,#0ea5e9);color:var(--ac,#0ea5e9);background:rgba(14,165,233,.08);box-shadow:0 0 8px rgba(14,165,233,.15)}
.dl-mod-chip.loading{border-color:#eab308;color:#eab308;animation:dlChipPulse .8s ease infinite}
@keyframes dlChipPulse{0%,100%{opacity:1}50%{opacity:.5}}
@keyframes dspin{to{transform:rotate(360deg)}}

</style>
</head>
<body>
<div class="app-wrap">

<!-- ═══ LEFT SIDEBAR ═══ -->
<nav class="sidebar" id="sidebar">
  <div class="sb-logo">
    <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='36' height='36' viewBox='0 0 36 36'%3E%3Cdefs%3E%3ClinearGradient id='g1' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23FBC02D'/%3E%3Cstop offset='50%25' stop-color='%23E53935'/%3E%3Cstop offset='100%25' stop-color='%231565C0'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='36' height='36' rx='8' fill='url(%23g1)'/%3E%3Ctext x='18' y='15' text-anchor='middle' fill='white' font-family='system-ui' font-weight='900' font-size='9.5' letter-spacing='.5'%3EEGAT%3C/text%3E%3Ctext x='18' y='27' text-anchor='middle' fill='white' font-family='system-ui' font-weight='800' font-size='12' letter-spacing='1'%3EEV%3C/text%3E%3C/svg%3E" alt="EGAT EV">
    <div class="sb-logo-txt">
      <b>EGAT EV Platform</b>
      <small>AI Monitoring System</small>
    </div>
  </div>
  <div class="sb-section">OVERVIEW</div>
  <div class="sb-nav">
    <a class="sb-item sb-active" id="sbDash" data-tip="Dashboard: All Modules Summary" href="javascript:void(0)" onclick="switchModule(0)">
      <div class="sb-icon">&#128202;</div>
      <div class="sb-txt"><span class="sb-txt-name">Dashboard</span><span class="sb-txt-sub">สรุปผลรวมทุก Module</span></div>
    </a>
  <div class="sb-section" data-i18n="sb_modules">AI MODULES</div>
    <a class="sb-item" id="sbMod1" data-tip="Module 1: MDB Filter Clogging Prediction" href="javascript:void(0)" onclick="switchModule(1)">
      <div class="sb-icon">🌀</div>
      <div class="sb-txt"><span class="sb-txt-name" data-i18n="mod1_name">Module 1</span><span class="sb-txt-sub" data-i18n="mod1_sub">การตันของฟิลเตอร์ตู้สวิทซ์ประธาน</span></div>
      <span class="sb-badge sb-badge-live">LIVE</span>
    </a>
    <a class="sb-item" id="sbMod2" data-tip="Module 2: Filter Blockage (Charger)" href="javascript:void(0)" onclick="switchModule(2)">
      <div class="sb-icon">🔄</div>
      <div class="sb-txt"><span class="sb-txt-name" data-i18n="mod2_name">Module 2</span><span class="sb-txt-sub" data-i18n="mod2_sub">การตันของฟิลเตอร์เครื่องอัดประจุ</span></div>
      <span class="sb-badge sb-badge-live">LIVE</span>
    </a>
    <a class="sb-item" id="sbMod3" data-tip="Module 3: Charger Offline" href="javascript:void(0)" onclick="switchModule(3)">
      <div class="sb-icon">📡</div>
      <div class="sb-txt"><span class="sb-txt-name" data-i18n="mod3_name">Module 3</span><span class="sb-txt-sub" data-i18n="mod3_sub">การออฟไลน์ของเครื่องอัดประจุ</span></div>
      <span class="sb-badge sb-badge-live">LIVE</span>
    </a>
    <a class="sb-item" id="sbMod4" data-tip="Module 4: Power Delivery Anomaly" href="javascript:void(0)" onclick="switchModule(4)">
      <div class="sb-icon">⚡</div>
      <div class="sb-txt"><span class="sb-txt-name" data-i18n="mod4_name">Module 4</span><span class="sb-txt-sub" data-i18n="mod4_sub">การจ่ายไฟฟ้าผิดปกติของ Charger</span></div>
      <span class="sb-badge sb-badge-live">LIVE</span>
    </a>
    <a class="sb-item" id="sbMod5" data-tip="Module 5: Network Problem Prediction" href="javascript:void(0)" onclick="switchModule(5)">
      <div class="sb-icon">🌐</div>
      <div class="sb-txt"><span class="sb-txt-name" data-i18n="mod5_name">Module 5</span><span class="sb-txt-sub" data-i18n="mod5_sub">ปัญหาเครือข่ายอินเตอร์เน็ต</span></div>
      <span class="sb-badge sb-badge-live">LIVE</span>
    </a>
    <a class="sb-item" id="sbMod6" data-tip="Module 6: Remaining Useful Life" href="javascript:void(0)" onclick="switchModule(6)">
      <div class="sb-icon">⏳</div>
      <div class="sb-txt"><span class="sb-txt-name" data-i18n="mod6_name">Module 6</span><span class="sb-txt-sub" data-i18n="mod6_sub">อายุที่เหลือของอุปกรณ์ภายในเครื่อง</span></div>
      <span class="sb-badge sb-badge-live">LIVE</span>
    </a>
    <a class="sb-item" id="sbMod7" data-tip="Module 7: Charger Failure Analysis" href="javascript:void(0)" onclick="switchModule(7)">
      <div class="sb-icon">🔍</div>
      <div class="sb-txt"><span class="sb-txt-name" data-i18n="mod7_name">Module 7</span><span class="sb-txt-sub" data-i18n="mod7_sub">วิเคราะห์ปัญหา Charger จ่ายไฟไม่ได้</span></div>
      <span class="sb-badge sb-badge-live">LIVE</span>
    </a>
    <a class="sb-item" id="sbHealth" data-tip="Health History — %Health Graph" href="javascript:void(0)" onclick="switchModule(8)" style="border-top:1px solid rgba(100,116,139,.15);margin-top:6px;padding-top:10px">
      <div class="sb-icon">📈</div>
      <div class="sb-txt"><span class="sb-txt-name">Health History</span><span class="sb-txt-sub">กราฟ %Health ย้อนหลัง</span></div>
      <span class="sb-badge" style="background:rgba(16,185,129,.12);color:#10b981;font-size:.55rem">GRAPH</span>
    </a>
    <a class="sb-item" id="sbMonitor" data-tip="Station Monitor — All Stations Overview" href="javascript:void(0)" onclick="switchModule(9)">
      <div class="sb-icon">📡</div>
      <div class="sb-txt"><span class="sb-txt-name">Monitor</span><span class="sb-txt-sub">สถานะสถานีทั้งหมด</span></div>
      <span class="sb-badge" style="background:rgba(59,130,246,.15);color:#60a5fa;font-size:.55rem">ALL</span>
    </a>
    <a class="sb-item" id="sbHeatmap" data-tip="Health Heatmap — Visual Overview" href="javascript:void(0)" onclick="switchModule(10)">
      <div class="sb-icon">🎯</div>
      <div class="sb-txt"><span class="sb-txt-name">Heatmap</span><span class="sb-txt-sub">ภาพรวม Health ทุกสถานี</span></div>
      <span class="sb-badge" style="background:rgba(5,150,105,.12);color:#059669;font-size:.55rem">MAP</span>
    </a>
  </div>
  <div class="sb-toggle" onclick="toggleSidebar()">
    <div class="sb-toggle-icon" id="sbToggleIcon">◀</div>
    <span class="sb-toggle-txt" data-i18n="sb_collapse">Collapse Menu</span>
  </div>
</nav>

<!-- ═══ MAIN CONTENT ═══ -->
<div class="app-main" id="appMain">

<!-- Loading Overlay -->
<div class="dash-loading-overlay" id="dashLoadingOverlay" onclick="dlShow(false);dlFirstLoad=false">
  <div class="dash-loading-box">
    <div class="dl-icon">&#9889;</div>
    <div class="dl-title" id="dlTitle">Loading Dashboard</div>
    <div class="dl-sub" id="dlSub">Fetching data from all modules...</div>
    <div class="dl-progress-track"><div class="dl-progress-bar" id="dlBar"></div></div>
    <div class="dl-progress-text"><span id="dlModuleText">Initializing...</span><span class="dl-progress-pct" id="dlPct">0%</span></div>
    <div class="dl-module-status" id="dlChips"></div>
  </div>
</div>

<div class="hdr">
  <div class="logo"><img class="lm" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCABAAOEDASIAAhEBAxEB/8QAHQAAAQUBAQEBAAAAAAAAAAAAAAQFBgcIAwECCf/EAE0QAAEDAwEEBAcMBgYLAAAAAAECAwQABQYRBxIhMQgTQWEUFiJRcYGSFRgjN1JUVnWRlKGzMkJTcoKxJDZzssHRFyUnNENiZYPS4fD/xAAbAQACAwEBAQAAAAAAAAAAAAAABQMEBgIHAf/EADcRAAEDAgMECAQEBwAAAAAAAAEAAgMEEQUhMQYSQYETFCJhcZGx8BUyUaEzNMHRFiNSU1SSov/aAAwDAQACEQMRAD8A1rmN7bxvE7tkLzC5Ddthuy1tIIClhCSopBPDU6VRPvrbH9Drt95aq3NtvxPZj9SS/wAlVYNxG1Jv2WWexrfVHTcZ7EQupTqWw44lG8B26a60+wmhgqInvlGh/RLa2okjeGsOq0t762x/Q67feGqkuzHb/as6zSFjMbG7hCdlJcIedebUlO4hS+IHHju6euoj71CF9N533Nv/ADqT7Lej9FwXOIOTtZRKnriBwdQuMhAVvtqRzHHhva+qiYYV0bujPatlrqiM1m8N7TkrupoyvJbHi1qXdL/c49viJ/XdVpvHzJHMnuFdcovcDHMdn325udXDgsKfdI4kgDkB2knQAdpIrAe0TM7/ALRMqVdLmp11bjnVwYLeqksJJ0S2hPao6ga8yTVTDcONY4kmzRqVPVVQgFhmStF5B0psYiyFN2bHrnckDUB1aksDX0K46U3wulbby6EzMNnIQTxW1KQdB59DTNs+6MM+fAanZjeHLatwbwgxUBS0jzLWeAPcOVSS69FbH3GT7l5Pc4zo5dc2hxJPf20wc3CGHcNz35qqDWu7Q/RWZs02s4bn7yolknOIuCGy4uHIbKHQkEAqA5EAkcR5xU8qjOjlsfvGz3K77cr87DkqXHbjQH45OikFRU6SDxTxS2NO41edJqxkLJS2A3ar8DpHMBkFivFEAEkgAcSTWepvSox1mc+yxi90kstuqQ2+h9sJdSCQFgHiARx9dT/pIZUcT2S3aQy6W5s9PufEKTooLdBClDvSjfV/DWJLBj9yvcS7yLeyVt2iAqfJOnANJUlJ9eiir0JNNMJw+KeN0s2l7Dh74KpW1L43Bkeq3LsZ2nWvaZarhMgwX7e9BkBp2O+tKl7qkgpX5PDQ+UPSk1PaxL0Tsp8XtrEe3vu7kO+NGE4CeHWjymlenUKQP7SttVSxSkFLOWt0OYU9JMZo7nVUDkHScstnv9ytDmJ3R5cCY9EU4l9sBZbWpBUNewlOtIffW2P6HXb7w1XXIujDCvGRXS7nMZrJnzXpZbERBCC44pe6Drx03tKpDbls6a2a5JCs7N1duSZMMSS440EFJK1J00H7uvrptS02GVBDGXLuapTS1cYLjpyV1e+tsf0Ou33hqpRss292vPcyYxqLjlwguvNOOB555CkgITqRoOPGqH2E7HY+020XOe9f5FsMGSlgIbYSsL1Tva8eVXlsn2BxcBzaPkrWTSrgtlpxoMuRkoB306a6jzVFWw4bCHsHzjx19F3TyVUha4/LyVxXKUIUNySpBWGwCQDxPHSmPxsY+Zve0KerrGMyA7FC9wuADe05cdaj3im788R7NeT7SzbRMqWjCm3Zu5/Lrc/XustHSNpS09Mc+a7+NjHzN72hR42MfM3vaFcPFN354j2aPFN354j2azvWduP6B5M/dWtzD/r6rv42MfM3vaFd4OSx5UxqP4O431it0KKgQD2UhOJu/PEeyaYZTLsKatlR0caXwI7uRqjWbQ7U4UWS1wAYSODc+JGWlwpI6Wjmu2M581ZI5UUmtckTIDMgEarT5QHYe0fbRc5QhwHpB08hOo7zyA+3SvXOuQ9W6zfsbu9fute/kkm47e3OOia52SsRZjsfwdxzq1bpUFDQntp1tsrwyG3J6tTYWCQlXPTXnVfRGXJk5tnUlbqwCeZ4nif8asdltLTSWkDRCEhKR5gKxWxuN4jjM0885/lDJosNTnrqbD1TCup4oGta3Xivqiiit+lqh+234nsx+pJf5KqwRjt0fseQ229xm0OP2+W1KbQvXdUptYUAdOwkVvfbb8T2Y/Ukv8lVYUwC3RbxneP2mcgriTbnGjvpB0KkLdSlQ17OBNanASBTyF2l/wBEnxEEyNsrgPSmzPsxuxD/ALjtXb0dtol12kY1c7pdoMSG7En+DIRGUopKerQrU73bqo0j97tsu4/6ok8Rp/va6muz7BsewS2ybfjkZyPHkv8AXuJW6V6r3QnXj3JFLayegfERAyzvferUEdQ195HXCrLppXV6Fsth25lRAuV0bbeHnbQhbn99CKp7ogWCNeNrXh0tpLiLTCXLaChqA8VJQg+oKWR5iAatrptW96Rs1tc9pClIhXZBeI/VQttxGp/iKB66qLoi5FEse1lMOc6lpm7w1w21qOgD28laAT37qkjvIpjRg/Cn7mufvyVacjrjd7TL35ra1VDfukRs9st9uFmmi8+FQJTsV7q4JUnfbWUq0OvEag8at6sldIXYv4v23Jtohv6n+vuJkiH1AAHhEkDd3v8Al6z8KT4bFTzSbk5Ivpb6+Su1cksbN6MeKu3Z3tpwzO8jFgsQufhhYW//AEiIW07qSAeOvPyhVkVi3oc/HOn6rkf3m62Vc5sa222TcZrqWo0VlTzyzyShIJUfsBr7idKymn6OPSwRSTOlj3nLJ3TTyj3RzO3YrHd1YtTHXvgHh17vIHvSgJI/tDU36HuHxhszu94uMdLichdXH0UOC4rYU3p61qd9WlZeyu9ycmye55DM1D9xlLkKSTruBR8lH8KdE+gVYONbec7x2wQLHbE2puFBYSwykxNTupGmpOvEnmT5zWhnoJupNp4dePr6pZHUM6cyv5e/BQTJ7XPw7Np9qDq25tnnlLLx/S1bXq256xuqHpr9AsCyCPlWG2nIo2gRPiodKR+ovTy0elKt4eqsA53lNyzPJHsgu7cZE19CEOmO3uJXujdBI8+gA17hWjuhLlHhOP3fEJDmrkB4TIqSf+E5wWB6FjU/2gqHGqd8lK2R3zN156/dd0EjWzFo0K0XWROm58Ytn+qE/nOVrusidNz4xbP9UJ/OcpTgn5seBV6v/AKmXQa/qpkv1i3+UK0TWdug1/VTJfrFv8oVomocV/OP98F1RfgNSS8SVw7a9JbAKkAEA8uYFRjxonfsmfsNSudGRMirjuEhCwAdOfPWmrxXt/ynvarzraWhx+oqWuwyXdZu5i9s7nuPCyc0klM1pEwuU0+NE79kz9hrrEySa9LZZU0yAtxKTwPadKcfFe3/ACnvar7YxyAy8h1Jd3kKChqrtB1pDDhO2AkaX1AtcX7XD/VWXTUNjZvvzTyOVRHNom5KbmJHBwbq/SOX4fyqXUhv0Tw21vMgarA3kekf/aeutltThfxPC5YQO0BdviM/vpzVCjm6GYOOiZ8HkKLT8UgkJIWD5teBH4fzrzN5Y3GYSTxPwi/RyH+P2Usw+L1Fq69Q0U8d7j8kcB/ifXUVu8szbi9I/VUrRP7o4CvP8Urp8O2TgppD25RbwZe/pYc0yhjbLWueNB6p3wmJvyXZih5LY3U/vHn+H86l1ILBE8DtTLRGiyN9fpP+XL1Uvrf7K4X8MwuKEjtEXd4nP7acktrJummLuCKKKK0SrKH7bfiezH6kl/kqrA+O3V+x5Dbb3Fbbdft8tqU2hZ8lSm1hQB07CQK/RnIrTDv1in2S4oWuHPjrjPpSrdJQtJSoA9nA1V/vcdmPzG4/fVU7wvEYaWNzJQc0vq6WSZwczgqh99Jmn0fsntuVMdi23nJ832j27GrlaLVGjSkvFTjCllY3GlLGmvDmkVLfe47MfmNx++qp5wvYtguIZJGyCyxJjc6MFhtTkpS0jeQUnge5Rrqapw10bgyMg2y8fNfI4aoOBc7L33KXZpj0DK8WuOPXNJMWcyW1FP6SDzSsd6VAEd4rAWf4df8AA8iXaL7HWy6heseUgENyEg+S42r1cuYPor9FabMkx+yZJbV26+2uLcYq+bb6AoD0HmD3iquG4k6jcQRdp1UtVSCcXBsQsmYL0k8uscBqBfYMe/NNJCUyFrLb+g+UeSj3mvdr+31vPcGmYuzjLsFMpbKi+5JC93q3UucAPPu6eurZvHRn2eTHVOQl3W3FR13GpO8gegK5Ukh9F3BW3AZNzvchHyQ+EfiBTMVWFb4lDSHDPn52VUw1m7uXyVSdDk/7Z0j/AKXI/vN1dfS+yg2PZaqzsObsq+viKNDxDKfLdPoICUH9+ppgWzDCcIkeF4/Zm2JhbLSpbiyt1STpqCo+ivjaLsvxXPp8WZkbUx5cRpTTCWpKkJSFHVR0HadBx7hVKaugmrWzkHdHnkp46eRlOYxqVkzo1YRCzjaSmLd4glWiDFcky2la7rhPkNoJHnUre/gNaj/0G7KPoXb/ALV/+VO+zjZxi2ACd4uRHmVTur69brpcUoI3t0ankBvK+2pfUdfick8xdE4hvjZd01I2NlngEqhttmxLC42zO83DFMcjQLrAZ8LbcZKipSGzvOI0JOuqArTv0rPWwfKTiG1Sy3Vb3VxHnfA5h14Fl0hJJ7kq3F/w1vx1tDram3EhSFApUkjgQeYqoT0cNl5SUe59wCdNNBNXppViixRjYXxVJJB56qKejJeHxWFlcFZE6bnxi2f6oT+c5WtojIjRWY6VuLS0hKApxW8ogDTUntPfUK2h7KcQzy7MXPIo8t2QwwGGy1ILYCAoq5DvUao4dUspqgSP0zVmqidLGWjVVh0Gv6qZL9Yt/lCtE1FdnOAY5gEOZExxmQ01LdDrodeLmqgndGmvLhUqqKunbPUOkboV1TxmOMNPBIb6+7GtT77Kt1xABB07xUT8Ybp+2T7AqaymG5LCmHk7zauY89IPcG1/NR9prAbS4NjNfUtkoKjo2htiN5wzuc8h9LJrSzwRtIkbc8lGfGG6ftk+wKPGG6ftk+wKk3uDa/mo+00e4Nr+aj7TWd/hban/ADf+3/srPXKP+39gk2KXGXP8J8JWFbm7u6DTnrr/ACFPtJYECLC3/Bmg3v6b3Hnpy/nSqvQsEpaqkoWQ1b9+QXubk3zJGZz0sEtqHsfIXMFgmrJpIh2hwI8lTnwaAOzXn+GtRTHonhl1abI1Qg76/QP/AHoKm0+BGnbnhLe/ua7vHz15Bt0SEtSozIQpQ0J7qzOMbMVOKYxFUyub0Mduznc2zOVrZnLXRWoKtkMDmAdopXRRRW7S9FFFFCEUUUUIRRRRQhFFFFCEVXllz2ZO2r3TD1og9VEmOR0pAWHtxMSO+HCT5B8p8o3Rx4A8gqrDqKxMIgsZhIyMzJTinZ5uKIyiOrbkGKiKVjtPwSNNDw1UTQhN2K5pcbvfIdvcgxkpfZvSzuKOusKeiM2Br8pKiT38uFNtlz2/v7P13+fEtgmpukCC5HaLiTHU8/HZfadQrykONqdcAHIgIPI1JMewe2WW8yLizIlPb/hYYadXqmOmU/4Q+E9vlOAEa8gABSWFs8trFlkW164XCUZEqFIXJecBdV4ItpTIUrTyj8CkKUeKuOvZQhJ5WcyGdpZxAwm0pL7CWn1KPwqFMuLdAHykEM69zo8xrnAzG9TrBmE63xIs6fZn5jESA0hwrUplx1CAo/rFQQk6J8+nOnudhtqmZLGyB8vGZGnpnMkK0CViOqOU96ShZJHnAPZXkTEW2LXe7V7qzhDurkl0BpQbcjLfWta1NrHEHeWSD2aChCYZWa3dvZ/AyKP7kSUSJim3p7RcXGYjaubj60jyxxS2laeaFKVrwSanEGRJeszEt6O2JS46XFstuhaQsp1KUq5Ea8Ae3nTCjDWGrF7ns3KW3IM1yeqUnd1W85vdZvI03SlQWoFJGnHXnxp5sNohWXHIFghBzwKBEbhshaypXVoQEJ1VzJ0A40IUBtW0C+u7PV32XEtfuk5dINsbYbLifBn5DzDC0PoV5SFNuur1H6yUpI/S1pdaM6uEuJjZdhxkvXDJ59imbpVup8FE0FxH7yoiToeQWfNSyLs6tbVjlW16fcJTkiRDkeFvOAvByIWzHUTp5SkllsknirTjXQ4FDbs9qhQ7jLjyLZdX7s3K4KUuS/1/XKUDwIUZLp07NR5qELnf8um2/I5lsaisLbYftDYUonUiZJW0v2QkEd/OvsZBe28mymG8iCqFaLe3KY3QoOLU4HCArs0AaPLz0ruuGQbjk7d8dly0q/opfjpX8G8qMtbjKj2gpU4SdOeifNS5zHoi7heZpcdDl2itxXhrwSlAcAI7/hD+FCFDct2gXi1WiDcYcGC4hOPO32el1S9Shss6tt6dpDi+J7Qnzml1+zqVbdoisV8Bb3FtW52O+on4QvyXGnkfvJSlCgO3VXmpZfdn1qu0WBGdlzGm4ttVa3UtrAEmKotlba/T1SeI4gFQ7aV3nC7RdshavkzrVSmH4j7BCtA2uOXt0j0h9xJ7jQhJMcya7XDP7vYJkaFHYhJWpCN5QkbmqA05oeC0LBc4p/RKAk8TUwqPQ8Uix8wXkpmzXng0+2wy45q2yHlNKd3e3QllBA5AlWn6VSGhCKKKKEIooooQiiiihCKKKKEL/9k=" alt="EGAT EV"><div><div class="ln"><b>EGAT EV</b> <span style="font-size:.6em;font-weight:500;opacity:.7">AI Platform</span></div><div class="ld" data-i18n="subtitle">DC Charger 150kW &bull; Condition-Based Maintenance</div></div></div>
  <div class="hr">
    <div class="station-selector" id="stationSelector">
      <div class="station-current" onclick="toggleStationDropdown()" id="stationCurrentBtn">
        <span class="station-ico">&#9889;</span>
        <div class="station-info">
          <div class="station-sn" id="stationSN">Loading...</div>
          <div class="station-name" id="stationName">...</div>
        </div>
        <span class="station-arrow" id="stationArrow">&#9660;</span>
      </div>
      <div class="station-dropdown" id="stationDropdown">
        <div class="station-search-wrap">
          <input type="text" class="station-search" id="stationSearch" placeholder="Search station name or SN..." oninput="filterStations()" autocomplete="off">
        </div>
        <div class="station-list" id="stationList">
          <div class="station-loading">Loading stations...</div>
        </div>
      </div>
    </div>
    <div class="theme-sw" onclick="switchTheme()" title="Switch theme: Light &#8594; Dark &#8594; Cyber &#8594; Neural &#8594; Nature" id="themeSw"><span id="themeIcon">&#9790;</span></div><div class="lang-sw" onclick="switchLang()"><span id="langLbl">EN</span></div><div class="ck" id="clk"></div><div class="pill"><span id="cst" data-i18n="init">Initializing</span><div class="led" id="led"></div></div></div>
</div>

<!-- ═══════════════════════════════════════════════════════════════════
     DASHBOARD: All Modules Summary
     ═══════════════════════════════════════════════════════════════════ -->
<div class="dash-page on" id="pageDash">
<div class="pg">

<div class="dash-hdr">
  <div class="dash-hdr-l">
    <div class="dash-hdr-ico">&#128202;</div>
    <div>
      <h2>EGAT EV AI Platform &#8212; Dashboard Overview</h2>
      <div class="sub">&#3626;&#3619;&#3640;&#3611;&#3612;&#3621;&#3585;&#3634;&#3619;&#3605;&#3619;&#3623;&#3592;&#3592;&#3633;&#3610;&#3649;&#3621;&#3632;&#3607;&#3635;&#3609;&#3634;&#3618;&#3592;&#3634;&#3585;&#3607;&#3640;&#3585; Module &#8226; DC Charger 150kW Klongluang3</div>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:8px">
    <div style="font-size:.6em;color:var(--dim);font-family:'JetBrains Mono',monospace" id="dashClock"></div>
  </div>
</div>

<div class="dash-kpi" id="dashKpiRow">
  <div class="dash-kpi-card" id="dkHealthCard" style="border:2px solid rgba(6,182,212,.25);position:relative;overflow:hidden">
    <div style="position:absolute;inset:0;background:linear-gradient(135deg,rgba(6,182,212,.04),rgba(34,211,238,.02));pointer-events:none"></div>
    <div class="dash-kpi-label" style="color:var(--tx2);font-weight:800;letter-spacing:1px">&#9881; System Health</div>
    <div style="display:flex;align-items:center;gap:12px;justify-content:center">
      <div class="dash-kpi-val" id="dkHealth" style="font-size:2.2em;color:#22c55e">&#8212;</div>
    </div>
    <div style="margin-top:4px;height:6px;border-radius:3px;background:var(--bdr);overflow:hidden"><div id="dkHealthBar" style="height:100%;width:0%;border-radius:3px;background:linear-gradient(90deg,#22c55e,#34d399);transition:width .8s ease"></div></div>
    <div class="dash-kpi-sub" style="margin-top:4px" id="dkHealthSub">Weighted average of all modules</div>
  </div>
  <div class="dash-kpi-card blue"><div class="dash-kpi-label">Total Modules</div><div class="dash-kpi-val" id="dkTotal">7</div><div class="dash-kpi-sub">Active AI modules</div></div>
  <div class="dash-kpi-card green" id="dkNormalCard"><div class="dash-kpi-label">Normal</div><div class="dash-kpi-val" id="dkNormal">&#8212;</div><div class="dash-kpi-sub">Operating normally</div></div>
  <div class="dash-kpi-card yellow" id="dkWarnCard"><div class="dash-kpi-label">Warning</div><div class="dash-kpi-val" id="dkWarn">&#8212;</div><div class="dash-kpi-sub">Needs attention</div></div>
  <div class="dash-kpi-card red" id="dkCritCard"><div class="dash-kpi-label">Critical</div><div class="dash-kpi-val" id="dkCrit">&#8212;</div><div class="dash-kpi-sub">Action required</div></div>
</div>

<div class="dash-refresh-bar">
  <button class="dash-rb-btn" onclick="dashRefreshAll()">&#8635; Refresh All</button>
  <div class="sep"></div>
  <div>Last update: <span style="font-family:'JetBrains Mono',monospace;font-weight:600" id="dashLastUpdate">&#8212;</span></div>
  <div class="sep"></div>
  <div>Auto-refresh: <span style="font-family:'JetBrains Mono',monospace;font-weight:600" id="dashAutoSt">5s</span></div>
  <div class="sep"></div>
  <div id="dashRefSpin" style="display:none"><span class="dash-spin">&#9881;</span> Fetching&#8230;</div>
</div>

<div class="dash-grid" id="dashGrid">
  <!-- Rendered by JS -->
</div>

</div>
</div>

<!-- ═══════════════════════════════════════════════════════════════════
     MODULE 1: MDB Dust Filter Clogging Prediction
     ═══════════════════════════════════════════════════════════════════ -->
<div class="m1-page" id="pageMod1">

<div class="tbs" id="m1TabBar">
  <div class="tb on" onclick="m1stab('main')">&#127744; Filter Health</div>
  <div class="tb" onclick="m1stab('predict')">&#129514; AI Prediction</div>
  <div class="tb" onclick="m1stab('history')">&#128200; Historical Graph</div>
  <div class="tb" onclick="m1stab('algos')">&#128214; Algorithms</div>
</div>

<!-- ═══ TAB 1: Filter Health Dashboard ═══ -->
<div class="tc on" id="m1tab-main"><div class="pg">

<div class="m1-hdr">
  <div class="m1-hdr-l">
    <div class="m1-hdr-ico">&#127744;</div>
    <div>
      <h2>MDB Switchgear Filter Clogging Prediction</h2>
      <div class="sub">&#3619;&#3632;&#3610;&#3610;&#3588;&#3634;&#3604;&#3585;&#3634;&#3619;&#3603;&#3660;&#3585;&#3634;&#3619;&#3605;&#3633;&#3609;&#3586;&#3629;&#3591;&#3615;&#3636;&#3621;&#3648;&#3605;&#3629;&#3619;&#3660;&#3605;&#3641;&#3657; MDB &#8226; AI-Powered Predictive Maintenance &#8226; 11 Models</div>
    </div>
  </div>
  <div class="m1-badge of" id="m1SrcBadge"><div class="led" id="m1Led"></div> <span id="m1St">Connecting&#8230;</span></div>
</div>

<div style="border-radius:12px;padding:10px 16px;margin-bottom:12px;background:var(--card);border:1px solid var(--brd);display:flex;align-items:center;gap:8px;font-size:.68em;font-family:'JetBrains Mono',monospace">
  <span style="color:var(--dim)">&#128451;</span>
  <span id="m1DbStatus" style="color:var(--dim)">checking&#8230;</span>
  <span style="opacity:.3">|</span>
  <span id="m1DbInfo" style="color:var(--dim)">module1MdbDustPrediction.Klongluang3</span>
</div>


<div class="m1-hero">
  <div class="m1-gauge-card">
    <div style="font-size:.72em;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--dim)">Clogging Risk</div>
    <div class="m1-gauge-wrap">
      <svg viewBox="0 0 180 180"><circle class="gbg" cx="90" cy="90" r="78" stroke-dasharray="368" stroke-dashoffset="122"/><circle class="gfg" id="m1GaugeFg" cx="90" cy="90" r="78" stroke="#6b7280" stroke-dasharray="368" stroke-dashoffset="368"/></svg>
      <div class="m1-gauge-center">
        <div class="gval" id="m1RiskVal">--</div>
        <div class="glbl">Risk Score</div>
        <div class="gst" id="m1RiskLabel" style="color:var(--dim)">Waiting&#8230;</div>
      </div>
    </div>
    <div style="width:100%">
      <div style="display:flex;justify-content:space-between;font-size:.58em;color:var(--dim);margin-bottom:4px"><span>Filter Age</span><span id="m1FilterAge">-- days</span></div>
      <div class="m1-filter-bar"><div class="m1-filter-fill" id="m1FilterBar" style="width:0%;background:linear-gradient(90deg,#22c55e,#eab308)" data-label="0 days"></div></div>
    </div>
  </div>

  <div class="m1-env-grid">
    <div class="m1-env" style="--env-c:#ef4444">
      <div class="m1-ev">&#127777; MDB Ambient Temp</div>
      <div class="m1-en" id="m1TempVal">--</div>
      <div class="m1-eu">&#176;C</div>
    </div>
    <div class="m1-env" style="--env-c:#f97316">
      <div class="m1-ev">&#129302; Pi5 CPU Temp</div>
      <div class="m1-en" id="m1Pi5Val">--</div>
      <div class="m1-eu">&#176;C</div>
    </div>
    <div class="m1-env" style="--env-c:#3b82f6">
      <div class="m1-ev">&#128167; Humidity</div>
      <div class="m1-en" id="m1HumVal">--</div>
      <div class="m1-eu">%RH</div>
    </div>
    <div class="m1-env" style="--env-c:#8b5cf6">
      <div class="m1-ev">&#9954; Pressure</div>
      <div class="m1-en" id="m1PressVal">--</div>
      <div class="m1-eu">hPa</div>
    </div>
    <div class="m1-env" style="--env-c:#0891b2">
      <div class="m1-ev">&#128293; Temp Differential</div>
      <div class="m1-en" id="m1TdiffVal">--</div>
      <div class="m1-eu">&#176;C (Pi5 - Ambient)</div>
    </div>
    <div class="m1-env" style="--env-c:#16a34a">
      <div class="m1-ev">&#128994; MDB Status</div>
      <div class="m1-en" id="m1StatusVal">--</div>
      <div class="m1-eu" id="m1StatusSub">Online/Offline</div>
    </div>
    <div class="m1-env" style="--env-c:#d97706">
      <div class="m1-ev">&#9889; Meter 1</div>
      <div class="m1-en" id="m1Meter1Val">--</div>
      <div class="m1-eu">Wh</div>
    </div>
    <div class="m1-env" style="--env-c:#d97706">
      <div class="m1-ev">&#9889; Meter 2</div>
      <div class="m1-en" id="m1Meter2Val">--</div>
      <div class="m1-eu">Wh</div>
    </div>
  </div>
</div>

<div id="m1Warnings" style="display:none;margin-bottom:16px"></div>

<div class="m1-ab" id="m1ApPanel">
  <div style="display:flex;align-items:center;gap:8px">
    <label class="tgl" title="Auto-predict every 2 min"><input type="checkbox" id="m1ApToggle" checked onchange="m1ApToggleChanged()"><span class="tgl-sl"></span></label>
    <div><span class="al">Auto Predict</span><br><span class="m3-ap-badge idle" id="m1ApBadge">IDLE</span></div>
  </div>
  <div class="sep"></div>
  <div><span class="al">Next</span><br><span class="av" id="m1ApCd">OFF</span></div>
  <div class="sep"></div>
  <div style="font-size:.62em;color:var(--dim);line-height:1.8">&#128229; Queried: <span class="av" id="m1ApQueryTs">&#8212;</span><br>&#129504; Predicted: <span class="av" id="m1ApPredTs">&#8212;</span></div>
  <div class="sep"></div>
  <div style="font-size:.62em;color:var(--dim);line-height:1.8">&#9201;&#65039; Latency: <span class="av" id="m1ApLat">&#8212;</span><br>&#127919; Risk: <span class="av" id="m1ApRisk">&#8212;</span></div>
</div>

</div></div>

<!-- ═══ TAB 2: AI Prediction Results ═══ -->
<div class="tc" id="m1tab-predict"><div class="pg">

<div class="m1-hdr" style="margin-bottom:16px">
  <div class="m1-hdr-l">
    <div class="m1-hdr-ico" style="background:linear-gradient(135deg,#7c3aed,#6366f1)">&#129514;</div>
    <div>
      <h2>AI Anomaly Detection Results</h2>
      <div class="sub">11 AI models analyze MDB environmental data to predict filter clogging severity</div>
    </div>
  </div>
</div>

<div class="m1-ens-card" style="margin-bottom:16px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:16px;display:flex;align-items:center;gap:8px">&#127919; Ensemble Decision <div class="m1-pulse"></div></div>
  <div class="m1-ens-grid" id="m1EnsemblePanel">
    <div class="m1-ens-item"><div class="ek">Risk Score</div><div class="ev" id="m1EnsScore">--</div></div>
    <div class="m1-ens-item"><div class="ek">Status</div><div class="ev" id="m1EnsStatus" style="font-size:1.2em">--</div></div>
    <div class="m1-ens-item"><div class="ek">Confidence</div><div class="ev" id="m1EnsConf">--</div></div>
  </div>
</div>

<div style="font-weight:700;font-size:.82em;margin-bottom:10px">&#129504; Model Predictions</div>
<div class="m1-rg" id="m1ResultsGrid">
  <div style="color:var(--dim);font-size:.75em;grid-column:1/-1">Run prediction to see results&#8230;</div>
</div>

<div class="m1-chart-card" style="margin-top:16px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:12px;display:flex;align-items:center;gap:8px">&#128202; Prediction History <span style="font-size:.7em;color:var(--dim);font-weight:500">(last 20 runs)</span></div>
  <div id="m1PredHistory" style="max-height:280px;overflow-y:auto">
    <div style="color:var(--dim);font-size:.72em;padding:20px;text-align:center">No predictions yet &#8212; enable Auto Predict or run from Dashboard</div>
  </div>
</div>

</div></div>

<!-- ═══ TAB 3: Historical Graph ═══ -->
<div class="tc" id="m1tab-history"><div class="pg">

<div class="m1-hdr" style="margin-bottom:16px">
  <div class="m1-hdr-l">
    <div class="m1-hdr-ico" style="background:linear-gradient(135deg,#0891b2,#06b6d4)">&#128200;</div>
    <div>
      <h2>Historical Data &#8212; MDB Filter Monitoring</h2>
      <div class="sub">Trend analysis for temperature, humidity, pressure, and filter age over time</div>
    </div>
  </div>
</div>

<div class="m1-hist-ctrl">
  <div>
    <label>Time Range</label>
    <select id="m1HistRange">
      <option value="daily">Last 24 Hours</option>
      <option value="weekly">Last 7 Days</option>
      <option value="monthly">Last 30 Days</option>
    </select>
  </div>
  <div>
    <label>Field Group</label>
    <select id="m1HistFields">
      <option value="temperature">Temperature (MDB + Pi5)</option>
      <option value="environment">Environment (Humidity + Pressure)</option>
      <option value="filter">Filter Age + Risk</option>
      <option value="meters">Energy Meters</option>
      <option value="all_sensors">All Sensors Combined</option>
    </select>
  </div>
  <button class="m1-hist-btn" onclick="m1LoadHistory()">&#8635; Load Data</button>
</div>

<div class="m1-chart-card">
  <div id="m1HistChartTitle" style="font-size:.62em;font-weight:700;color:var(--dim);margin-bottom:8px;font-family:'JetBrains Mono',monospace;letter-spacing:.5px"></div>
  <div style="position:relative;height:360px;width:100%">
    <canvas id="m1HistChart"></canvas>
  </div>
  <div id="m1HistMsg" style="text-align:center;padding:60px 20px;color:var(--dim);font-size:.72em">Select a field group and click &#8220;Load Data&#8221; to view the chart.</div>
</div>

</div></div>

<!-- ═══ TAB 4: Algorithm Description ═══ -->
<div class="tc" id="m1tab-algos"><div class="pg">

<div class="m1-hdr" style="margin-bottom:16px">
  <div class="m1-hdr-l">
    <div class="m1-hdr-ico" style="background:linear-gradient(135deg,#d97706,#f59e0b)">&#128214;</div>
    <div>
      <h2>Algorithm Description &#8212; Module 1</h2>
      <div class="sub">MDB Switchgear Dust Filter Clogging Prediction &#8212; 11 AI Models Architecture</div>
    </div>
  </div>
</div>

<div class="m1-algo-grid" id="m1AlgoGrid">

<div class="m1-ac" style="--ac-c:#059669"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#059669,#10b981)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128220; 1. Rule Engine</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Domain knowledge-based scoring system. Combines 7 weighted factors: filter age (35%), MDB temperature (15%), temperature differential (15%), humidity (12%), Pi5 CPU temp (10%), pressure (8%), and MDB status (5%). Generates clogging risk scores 0&#8594;1 as pseudo-labels for ML training.</div>
</div>

<div class="m1-ac" style="--ac-c:#0891b2"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#0891b2,#06b6d4)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#127794; 2. Isolation Forest</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Unsupervised anomaly detection using random partitioning. Points easily isolated (fewer splits needed) are anomalous. Detects unusual environmental conditions that may indicate filter degradation without requiring labels.</div>
</div>

<div class="m1-ac" style="--ac-c:#06b6d4"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#06b6d4,#22d3ee)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128200; 3. Local Outlier Factor</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Density-based unsupervised anomaly detection. Compares local density of each point with its neighbors. Points with substantially lower local density are flagged as outliers, identifying unusual MDB conditions.</div>
</div>

<div class="m1-ac" style="--ac-c:#7c3aed"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#7c3aed,#a855f7)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#129504; 4. Autoencoder</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Deep learning reconstruction-based detection. Trained on clean data to learn normal MDB patterns. High reconstruction error indicates the input deviates from normal, suggesting filter degradation.</div>
</div>

<div class="m1-ac" style="--ac-c:#d97706"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#d97706,#f59e0b)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#9889; 5. XGBoost Classifier</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Gradient boosted tree classifier with 4-class output (Clean/Moderate/Degraded/Clogged). Uses SMOTETomek for class balance. 300 trees, max depth 8, with regularization to prevent overfitting.</div>
</div>

<div class="m1-ac" style="--ac-c:#f59e0b"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#f59e0b,#fbbf24)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128202; 6. XGBoost Regressor</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Predicts continuous clogging risk score (0&#8594;1) instead of discrete classes. Enables fine-grained risk assessment and trend monitoring over time.</div>
</div>

<div class="m1-ac" style="--ac-c:#dc2626"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#dc2626,#f87171)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#127993; 7. Multi-Task DNN</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Deep neural network with shared layers and dual heads: classification (4-class softmax) and regression (sigmoid risk score). Joint training improves feature learning through complementary objectives.</div>
</div>

<div class="m1-ac" style="--ac-c:#2563eb"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#2563eb,#60a5fa)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128256; 8. BiLSTM-Attention</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Bidirectional LSTM with attention mechanism captures temporal patterns like gradual temperature rise or humidity trends. Attention weights highlight which time steps matter most for prediction.</div>
</div>

<div class="m1-ac" style="--ac-c:#ec4899"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#ec4899,#f472b6)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128736; 9. 1D-CNN</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">1D Convolutional Neural Network extracts local patterns from time-series data. Two Conv1D layers with batch normalization and global average pooling detect filter degradation signatures.</div>
</div>

<div class="m1-ac" style="--ac-c:#64748b"><div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#64748b,#94a3b8)"></div>
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#127968; 10. Gradient Boosting</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Sklearn Gradient Boosting with 200 estimators provides diversity alongside XGBoost in the ensemble. Different implementation captures complementary patterns.</div>
</div>

<div class="m1-ac" style="--ac-c:#1d4ed8"><div style="position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,#059669,#0891b2,#7c3aed,#d97706,#dc2626)"></div>
  <div style="font-weight:700;font-size:.88em;margin-bottom:8px">&#127919; 11. Ensemble (Weighted Voting)</div>
  <div style="font-size:.72em;color:var(--dim);line-height:1.6">Final prediction combines all models using optimized weights. Rule Engine (20%), XGBoost Clf (15%), Autoencoder (10%), DNN (10%), XGBoost Reg (10%), IF (8%), BiLSTM (8%), LOF (7%), GB (7%), CNN (5%). Weighted average produces robust clogging probability.</div>
</div>

</div>

</div></div>

</div><!-- /pageMod1 -->


<!-- ═══════════ MODULE 2 PAGE ═══════════ -->
<div class="m2-page" id="pageMod2">

<!-- Module 2 Tab Bar -->
<div class="tbs" id="m2TabBar">
  <div class="tb on" onclick="m2stab('main')" data-i18n="m2_tab1">🔄 AI Detection &amp; Health Tree</div>
  <div class="tb" onclick="m2stab('history')" data-i18n="m2_tab2">📈 Historical Graph</div>
  <div class="tb" onclick="m2stab('algos')" data-i18n="m2_tab3">📖 Algorithm Description</div>
  <div class="tb" onclick="m2stab('output')" data-i18n="m2_tab4">📊 Detection Output</div>
</div>

<!-- TAB 1: Main -->
<div class="tc on" id="m2tab-main"><div class="pg">

<!-- Module 2 Header -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>🔄</i> <span data-i18n="m2_title">Charger Dust Filter — AI Detection</span></span>
    <div style="display:flex;align-items:center;gap:10px;font-size:.55em;font-family:'JetBrains Mono';font-weight:600;color:var(--dim)">
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#0284c7,#06b6d4);display:inline-block"></span>Hybrid</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#7c3aed,#a855f7);display:inline-block"></span>AI</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#475569,#64748b);display:inline-block"></span>Rule</span>
    </div>
    <div class="tele-live">
      <div class="led" id="m2Led"></div>
      <span class="tele-st" id="m2St" data-i18n="tele_connecting">Connecting…</span>
      <span class="tele-ts" id="m2Ts"></span>
    </div>
  </div>
</div>

<!-- Database Status -->
<div class="cd" style="margin-bottom:10px;padding:6px 14px;font-family:'JetBrains Mono';font-size:.62em">
  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
    <span style="color:var(--dim)">🗄️ MongoDB:</span>
    <span class="db-status" id="m2DbSt">⏳</span>
    <span class="db-detail" id="m2DbInfo">database: module2ChargerDustPrediction</span>
  </div>
</div>

<!-- Model Loading Indicator -->

<!-- Auto-Predict Panel (M3-style) -->
  <div class="m3-ap" id="m2ApPanel">
    <div class="m3-ap-grp">
      <label class="tgl" title="Auto-predict every 2 min"><input type="checkbox" id="m2ApToggle" checked onchange="m2ApToggleChanged()"><span class="tgl-sl"></span></label>
      <div style="display:flex;flex-direction:column;gap:1px">
        <span class="m3-ap-lbl" data-i18n="m2_ap_label">Auto Predict</span>
        <span class="m3-ap-badge idle" id="m2ApBadge">IDLE</span>
      </div>
    </div>
    <div class="m3-ap-sep"></div>
    <div class="m3-ap-grp">
      <span class="m3-ap-lbl" data-i18n="m2_ap_next">Next</span>
      <span class="m3-ap-cd" id="m2ApCd">OFF</span>
    </div>
    <div class="m3-ap-sep"></div>
    <div class="m3-ap-ts">
      <div class="m3-ap-ts-row"><i>📥</i> <span data-i18n="m2_ap_queried">Queried:</span> <span class="m3-ap-ts-val" id="m2ApQueryTs">&mdash;</span></div>
      <div class="m3-ap-ts-row"><i>🧠</i> <span data-i18n="m2_ap_predicted">Predicted:</span> <span class="m3-ap-ts-val" id="m2ApPredTs">&mdash;</span></div>
    </div>
    <div class="m3-ap-sep"></div>
    <div class="m3-ap-ts">
      <div class="m3-ap-ts-row"><i>⏱️</i> <span data-i18n="m2_ap_latency">Latency:</span> <span class="m3-ap-ts-val" id="m2ApLat">&mdash;</span></div>
      <div class="m3-ap-ts-row"><i>📊</i> <span data-i18n="m2_ap_result">Result:</span> <span class="m3-ap-ts-val" id="m2ApResult">&mdash;</span></div>
    </div>
  </div>

  <!-- Summary Bar -->
  <div class="hg-wrap">
    <div class="hg-bar">
      <div class="hg-seg hg-normal" id="m2HgNormal" style="width:100%"></div>
      <div class="hg-seg hg-warn" id="m2HgWarn" style="width:0%"></div>
      <div class="hg-seg hg-alarm" id="m2HgAlarm" style="width:0%"></div>
    </div>
    <div class="hg-labels">
      <div class="hg-lbl hg-lbl-normal"><span class="hg-dot" style="background:#16a34a"></span><span data-i18n="gauge_normal">Normal</span> <strong id="m2HgNormCnt">6</strong></div>
      <div class="hg-lbl hg-lbl-warn"><span class="hg-dot" style="background:#d97706"></span><span data-i18n="gauge_warning">Warning</span> <strong id="m2HgWarnCnt">0</strong></div>
      <div class="hg-lbl hg-lbl-alarm"><span class="hg-dot" style="background:#ef4444"></span><span data-i18n="gauge_alarm">Alarm</span> <strong id="m2HgAlarmCnt">0</strong></div>
      <div class="hg-total"><span id="m2HgTotal">6 / 6 models OK</span></div>
    </div>
  </div>

<!-- ═══ AI MODEL STATUS TREE ═══ -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="m2-tree-wrap" id="m2TreeCanvas">
    <svg class="m2-tree-svg" id="m2TreeSvg"></svg>

    <!-- LEFT: AI Model Nodes -->
        <div id="m2ColM" style="flex:0 0 260px;z-index:2;padding-top:6px">
      <!-- reg group: A1 -->
      <div class="m2-mn" id="m2mA1" data-grp="reg">
        <span class="m2-mn-tp m2-ml">ML</span><span class="m2-mn-id">A1</span>
        <div class="m2-mn-info"><div class="m2-mn-name">XGBoost Regressor</div><div class="m2-mn-sub">Clogging Score 0–1</div></div>
        <span class="m2-mn-val" id="m2vA1">&mdash;</span><span class="m2-mn-badge m2-ok" id="m2bA1">OK</span>
      </div>
      <div class="gs"></div>
      <!-- cls group: A2, C -->
      <div class="m2-mn" id="m2mA2" data-grp="cls">
        <span class="m2-mn-tp m2-ml">ML</span><span class="m2-mn-id">A2</span>
        <div class="m2-mn-info"><div class="m2-mn-name">XGBoost Classifier</div><div class="m2-mn-sub">5-Level Clog Class</div></div>
        <span class="m2-mn-val" id="m2vA2">&mdash;</span><span class="m2-mn-badge m2-ok" id="m2bA2">OK</span>
      </div>
      <div class="m2-mn" id="m2mC" data-grp="cls">
        <span class="m2-mn-tp m2-dl">DL</span><span class="m2-mn-id">C</span>
        <div class="m2-mn-info"><div class="m2-mn-name">DNN Classifier</div><div class="m2-mn-sub">5-Class SMOTE</div></div>
        <span class="m2-mn-val" id="m2vC">&mdash;</span><span class="m2-mn-badge m2-ok" id="m2bC">OK</span>
      </div>
      <div class="gs"></div>
      <!-- seq group: D -->
      <div class="m2-mn" id="m2mD" data-grp="seq">
        <span class="m2-mn-tp m2-dl">DL</span><span class="m2-mn-id">D</span>
        <div class="m2-mn-info"><div class="m2-mn-name">BiLSTM-Attention</div><div class="m2-mn-sub">Temporal Degradation</div></div>
        <span class="m2-mn-val" id="m2vD">&mdash;</span><span class="m2-mn-badge m2-ok" id="m2bD">OK</span>
      </div>
      <div class="gs"></div>
      <!-- ad group: B, E -->
      <div class="m2-mn" id="m2mB" data-grp="ad">
        <span class="m2-mn-tp m2-dl">DL</span><span class="m2-mn-id">B</span>
        <div class="m2-mn-info"><div class="m2-mn-name">Autoencoder</div><div class="m2-mn-sub">Reconstruction Anomaly</div></div>
        <span class="m2-mn-val" id="m2vB">&mdash;</span><span class="m2-mn-badge m2-ok" id="m2bB">OK</span>
      </div>
      <div class="m2-mn" id="m2mE" data-grp="ad">
        <span class="m2-mn-tp m2-ml">ML</span><span class="m2-mn-id">E</span>
        <div class="m2-mn-info"><div class="m2-mn-name">IF + LOF Ensemble</div><div class="m2-mn-sub">Isolation Forest + LOF</div></div>
        <span class="m2-mn-val" id="m2vE">&mdash;</span><span class="m2-mn-badge m2-ok" id="m2bE">OK</span>
      </div>
    </div>

<!-- MIDDLE: Detection Strategy Groups -->
    <div id="m2ColG" style="flex:0 0 160px;position:relative;margin:0 40px">
      <div class="m2-gn" id="m2gReg" style="border-color:#0ea5e9;color:#0ea5e9">
        <div class="m2-gn-t">📈 Regression</div><div class="m2-gn-c">Model A1</div>
        <div class="m2-gn-s m2-gn-ok" id="m2gRegS">CLEAN</div>
      </div>
      <div class="m2-gn" id="m2gCls" style="border-color:#a855f7;color:#a855f7">
        <div class="m2-gn-t">🎯 Classification</div><div class="m2-gn-c">Models A2, C</div>
        <div class="m2-gn-s m2-gn-ok" id="m2gClsS">CLEAN</div>
      </div>
      <div class="m2-gn" id="m2gSeq" style="border-color:#f59e0b;color:#f59e0b">
        <div class="m2-gn-t">🔄 Temporal</div><div class="m2-gn-c">Model D</div>
        <div class="m2-gn-s m2-gn-ok" id="m2gSeqS">CLEAN</div>
      </div>
      <div class="m2-gn" id="m2gAd" style="border-color:#ef4444;color:#ef4444">
        <div class="m2-gn-t">🔍 Anomaly Det.</div><div class="m2-gn-c">Models B, E</div>
        <div class="m2-gn-s m2-gn-ok" id="m2gAdS">NORMAL</div>
      </div>
    </div>

    <!-- RIGHT: System Gauge -->
    <div id="m2ColR" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:0">
      <svg id="m2Gauge" viewBox="0 0 300 190" style="width:100%;max-width:260px;height:auto"></svg>
      <div style="font-size:.7em;font-weight:700;margin-top:4px" data-i18n="m2_gauge_title">🌡️ Filter Clogging Risk</div>
      <div style="font-family:'JetBrains Mono';font-size:.65em;color:var(--dim);margin-top:2px">
        <span data-i18n="m2_gauge_label">Clogging Level:</span> <b id="m2GaugeLbl">&mdash;</b>
      </div>
    </div>
  </div>
</div>

<!-- ═══ CONDITION HEALTH TREE (3-column diagram) ═══ -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="margin-bottom:8px"><i>🏥</i> <span data-i18n="m2_ht_title">Filter Clogging — Condition Health Tree</span></div>
  <div class="m2-ht-wrap" id="m2HTCanvas">
    <svg class="m2-ht-svg" id="m2HTSvg"></svg>

    <!-- COL 1: Conditions -->
    <div class="m2-ht-col" id="m2ColC" style="flex:0 0 280px;z-index:2;padding-top:6px">
      <div class="m2-ht-hdr">Conditions (15)</div>
      <div class="m2-cond" id="m2c01" data-eq="thermal"><span class="m2-cond-id">C01</span><span class="m2-cond-nm">PM Temp 1 Derating</span><span class="m2-cond-st m2-cond-ok" id="m2c01s">OK</span></div>
      <div class="m2-cond" id="m2c02" data-eq="thermal"><span class="m2-cond-id">C02</span><span class="m2-cond-nm">PM Temp 2 Derating</span><span class="m2-cond-st m2-cond-ok" id="m2c02s">OK</span></div>
      <div class="m2-cond" id="m2c03" data-eq="thermal"><span class="m2-cond-id">C03</span><span class="m2-cond-nm">PM Temp 3 Derating</span><span class="m2-cond-st m2-cond-ok" id="m2c03s">OK</span></div>
      <div class="m2-cond" id="m2c04" data-eq="thermal"><span class="m2-cond-id">C04</span><span class="m2-cond-nm">PM Temp 4 Derating</span><span class="m2-cond-st m2-cond-ok" id="m2c04s">OK</span></div>
      <div class="m2-cond" id="m2c05" data-eq="thermal"><span class="m2-cond-id">C05</span><span class="m2-cond-nm">PM Temp 5 Derating</span><span class="m2-cond-st m2-cond-ok" id="m2c05s">OK</span></div>
      <div class="gs"></div>
      <div class="m2-cond" id="m2c06" data-eq="fan"><span class="m2-cond-id">C06</span><span class="m2-cond-nm">Fan Group A (1-4)</span><span class="m2-cond-st m2-cond-ok" id="m2c06s">OK</span></div>
      <div class="m2-cond" id="m2c07" data-eq="fan"><span class="m2-cond-id">C07</span><span class="m2-cond-nm">Fan Group B (5-8)</span><span class="m2-cond-st m2-cond-ok" id="m2c07s">OK</span></div>
      <div class="m2-cond" id="m2c08" data-eq="fan"><span class="m2-cond-id">C08</span><span class="m2-cond-nm">Fan RPM Anomaly</span><span class="m2-cond-st m2-cond-ok" id="m2c08s">OK</span></div>
      <div class="gs"></div>
      <div class="m2-cond" id="m2c09" data-eq="tmgmt"><span class="m2-cond-id">C09</span><span class="m2-cond-nm">Thermal Resistance</span><span class="m2-cond-st m2-cond-ok" id="m2c09s">OK</span></div>
      <div class="m2-cond" id="m2c10" data-eq="tmgmt"><span class="m2-cond-id">C10</span><span class="m2-cond-nm">EdgeBox Temp</span><span class="m2-cond-st m2-cond-ok" id="m2c10s">OK</span></div>
      <div class="m2-cond" id="m2c11" data-eq="tmgmt"><span class="m2-cond-id">C11</span><span class="m2-cond-nm">Pi5 Temp</span><span class="m2-cond-st m2-cond-ok" id="m2c11s">OK</span></div>
      <div class="gs"></div>
      <div class="m2-cond" id="m2c12" data-eq="env"><span class="m2-cond-id">C12</span><span class="m2-cond-nm">Ambient+Humidity</span><span class="m2-cond-st m2-cond-ok" id="m2c12s">OK</span></div>
      <div class="m2-cond" id="m2c13" data-eq="env"><span class="m2-cond-id">C13</span><span class="m2-cond-nm">Pressure Drop</span><span class="m2-cond-st m2-cond-ok" id="m2c13s">OK</span></div>
      <div class="gs"></div>
      <div class="m2-cond" id="m2c14" data-eq="maint"><span class="m2-cond-id">C14</span><span class="m2-cond-nm">DFC Overdue</span><span class="m2-cond-st m2-cond-ok" id="m2c14s">OK</span></div>
      <div class="m2-cond" id="m2c15" data-eq="maint"><span class="m2-cond-id">C15</span><span class="m2-cond-nm">Energy Throughput</span><span class="m2-cond-st m2-cond-ok" id="m2c15s">OK</span></div>
    </div>

    <!-- COL 2: Equipment Groups -->
    <div class="m2-ht-col" id="m2ColE" style="flex:0 0 140px;position:relative;margin:0 40px">
      <div class="m2-ht-hdr">Equipment (5)</div>
      <div class="m2-equip" id="m2eqThermal"><div class="m2-equip-nm">🔥 PM Thermal</div><div class="m2-equip-cnt">C01–C05 (5)</div><div class="m2-equip-st m2-cond-ok" id="m2eqThermalS">OK</div></div>
      <div class="m2-equip" id="m2eqFan"><div class="m2-equip-nm">💨 Fan System</div><div class="m2-equip-cnt">C06–C08 (3)</div><div class="m2-equip-st m2-cond-ok" id="m2eqFanS">OK</div></div>
      <div class="m2-equip" id="m2eqTmgmt"><div class="m2-equip-nm">🌡️ Thermal Mgmt</div><div class="m2-equip-cnt">C09–C11 (3)</div><div class="m2-equip-st m2-cond-ok" id="m2eqTmgmtS">OK</div></div>
      <div class="m2-equip" id="m2eqEnv"><div class="m2-equip-nm">🌤️ Environment</div><div class="m2-equip-cnt">C12–C13 (2)</div><div class="m2-equip-st m2-cond-ok" id="m2eqEnvS">OK</div></div>
      <div class="m2-equip" id="m2eqMaint"><div class="m2-equip-nm">🔧 Maintenance</div><div class="m2-equip-cnt">C14–C15 (2)</div><div class="m2-equip-st m2-cond-ok" id="m2eqMaintS">OK</div></div>
    </div>

    <!-- COL 3: Root Cause Gauge -->
    <div class="m2-ht-col" id="m2ColRC" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:0">
      <div class="rn" id="m2htRoot">
        <div class="rn-gauge-wrap">
          <svg class="rn-gauge" viewBox="0 0 300 190" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="m2hgNorm" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#22c55e"/><stop offset="100%" stop-color="#16a34a"/></linearGradient>
              <linearGradient id="m2hgWarn" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#d97706"/></linearGradient>
              <linearGradient id="m2hgAlrm" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#f87171"/><stop offset="100%" stop-color="#dc2626"/></linearGradient>
              <filter id="m2hglN" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#22c55e" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m2hglW" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#fbbf24" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m2hglA" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#ef4444" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m2htipGl"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
            </defs>
            <path d="M 25 155 A 125 125 0 0 1 275 155" fill="none" stroke="rgba(0,0,0,.03)" stroke-width="3" stroke-linecap="round"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="rgba(0,0,0,.035)" stroke-width="20" stroke-linecap="round"/>
            <g id="m2htTicks"></g>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m2hgNorm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="111.9 240" stroke-dashoffset="0" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m2hgWarn)" stroke-width="14" stroke-dasharray="111.9 240" stroke-dashoffset="-111.9" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m2hgAlrm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="128 223.9" stroke-dashoffset="-223.8" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m2hgNorm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="m2htArcN" filter="url(#m2hglN)" opacity="0"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m2hgWarn)" stroke-width="14" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="m2htArcW" filter="url(#m2hglW)" opacity="0"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m2hgAlrm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="m2htArcA" filter="url(#m2hglA)" opacity="0"/>
            <g id="m2htNeedle" transform="rotate(-90 150 155)">
              <path d="M148.5,52 L151.5,52 L150.8,146 L149.2,146 Z" fill="#1e293b" opacity=".85"/>
              <circle cx="150" cy="155" r="9" fill="#fff" stroke="#1e293b" stroke-width="3"/>
              <circle cx="150" cy="155" r="3.5" fill="#1e293b"/>
              <circle cx="150" cy="42" r="3.5" fill="#16a34a" id="m2htTip" filter="url(#m2htipGl)" opacity=".95"/>
            </g>
            <text x="150" y="142" text-anchor="middle" font-size="42" font-weight="900" font-family="JetBrains Mono" id="m2htVal" fill="#16a34a">0%</text>
            <text x="56" y="172" font-size="7.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" letter-spacing="1">CLEAN</text>
            <text x="150" y="28" font-size="7.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" text-anchor="middle" letter-spacing="1">MODERATE</text>
            <text x="213" y="172" font-size="7.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" letter-spacing="1">CRITICAL</text>
          </svg>
          <div class="rn-pill" id="m2htPill">
            <span class="rn-pill-dot" id="m2htDot" style="background:#16a34a"></span>
            <span class="rn-pill-txt" id="m2htTxt" style="color:#16a34a">CLEAN</span>
          </div>
        </div>
        <div class="rn-h" style="color:#16a34a" id="m2htRootH">Filter Clogging Root-Cause</div>
        <div class="rn-s">15 Condition Monitor</div>
        <div class="rn-cnt" id="m2htRootCnt">0% &mdash; 0 / 15 triggered</div>
      </div>
    </div>
  </div>
</div>

</div></div><!-- /m2tab-main -->

<!-- TAB 2: Historical Graph -->
<div class="tc" id="m2tab-history"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct"><i>📈</i> <span data-i18n="m2_hist_h">Historical Graph — Filter Thermal Monitoring</span></div>
</div>
<div class="cd" style="padding:14px;margin-bottom:12px">
  <div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end">
    <div>
      <label style="font-size:.52em;font-weight:700;color:var(--dim);display:block;margin-bottom:4px;letter-spacing:.5px;text-transform:uppercase" data-i18n="hist_range">Time Range</label>
      <select id="m2HistRange" style="font-family:'JetBrains Mono';font-size:.65em;padding:6px 12px;border-radius:6px;border:1px solid var(--bdr);background:var(--glass);color:var(--tx);min-width:110px;cursor:pointer">
        <option value="daily">Last 24 Hours</option><option value="weekly">Last 7 Days</option><option value="monthly">Last 30 Days</option>
      </select>
    </div>
    <div>
      <label style="font-size:.52em;font-weight:700;color:var(--dim);display:block;margin-bottom:4px;letter-spacing:.5px;text-transform:uppercase" data-i18n="hist_fields">Field Group</label>
      <select id="m2HistFields" style="font-family:'JetBrains Mono';font-size:.65em;padding:6px 12px;border-radius:6px;border:1px solid var(--bdr);background:var(--glass);color:var(--tx);min-width:200px;cursor:pointer">
        <option value="pm_temp">PM Temperature (1–5)</option>
        <option value="fan_rpm">Fan RPM (1–8)</option>
        <option value="env_temp">Environment (ambient, edgebox, pi5)</option>
        <option value="power">Power (P(t)1, P(t)2)</option>
        <option value="maintenance">Maintenance (DFC, meter)</option>
      </select>
    </div>
    <button onclick="m2LoadHistory()" style="display:inline-flex;align-items:center;gap:5px;font-size:.6em;padding:7px 18px;border-radius:6px;background:linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.08));border:1px solid rgba(56,189,248,.25);color:#38bdf8;font-weight:700;cursor:pointer;transition:all .3s;letter-spacing:.3px" onmouseover="this.style.background='linear-gradient(135deg,rgba(14,165,233,.22),rgba(56,189,248,.16))';this.style.boxShadow='0 0 14px rgba(56,189,248,.15)'" onmouseout="this.style.background='linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.08))';this.style.boxShadow='none'" data-i18n="hist_load"><span>↻</span> Load Data</button>
  </div>
</div>
<div class="cd" style="padding:14px">
  <div id="m2HistChartTitle" style="font-size:.6em;font-weight:700;color:var(--dim);margin-bottom:8px;font-family:'JetBrains Mono';letter-spacing:.5px"></div>
  <div style="position:relative;height:340px;width:100%">
    <canvas id="m2HistChart"></canvas>
  </div>
  <div id="m2HistMsg" style="text-align:center;padding:60px 20px;color:var(--dim);font-size:.7em" data-i18n="hist_empty">Select a field group and click "Load Data" to view the chart.</div>
</div>
</div></div><!-- /m2tab-history -->

<!-- TAB 3: Algorithm Description -->
<div class="tc" id="m2tab-algos"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct"><i>📖</i> <span data-i18n="m2_algo_h">Algorithm Description — Filter Clogging Prediction</span></div>
</div>

<!-- 5 AI Model Architectures -->
<div class="cd" style="padding:20px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">🧠</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">5 AI Model Architectures</h3>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px">
    <!-- XGBoost -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(56,189,248,.2);background:linear-gradient(135deg,rgba(56,189,248,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(56,189,248,.12);color:#38bdf8;font-family:'JetBrains Mono';letter-spacing:.5px">A1+A2</span>
        <span style="font-size:.7em;font-weight:800;color:#38bdf8">XGBoost Dual-Head</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">A1: Clogging score regression (0–1 continuous). A2: 5-class clog level classification. Device-specific feature importance with SHAP.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">Regressor</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">Classifier</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">SHAP</span>
      </div>
    </div>
    <!-- Autoencoder -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(167,139,250,.2);background:linear-gradient(135deg,rgba(167,139,250,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(167,139,250,.12);color:#a78bfa;font-family:'JetBrains Mono';letter-spacing:.5px">B</span>
        <span style="font-size:.7em;font-weight:800;color:#a78bfa">Autoencoder</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Trained on CLEAN data only. High reconstruction error = filter degradation anomaly. Thresholds at P95/P99/P99.9.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(167,139,250,.08);color:#a78bfa;font-family:'JetBrains Mono'">256→16→256</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(167,139,250,.08);color:#a78bfa;font-family:'JetBrains Mono'">GELU+BN</span>
      </div>
    </div>
    <!-- DNN -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(52,211,153,.2);background:linear-gradient(135deg,rgba(52,211,153,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(52,211,153,.12);color:#34d399;font-family:'JetBrains Mono';letter-spacing:.5px">C</span>
        <span style="font-size:.7em;font-weight:800;color:#34d399">DNN Classifier</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Deep Neural Network 5-class: CLEAN / LIGHT_DUST / MODERATE_CLOG / SEVERE_CLOG / CRITICAL_BLOCK. Class-weighted loss.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(52,211,153,.08);color:#34d399;font-family:'JetBrains Mono'">512→64</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(52,211,153,.08);color:#34d399;font-family:'JetBrains Mono'">Dropout</span>
      </div>
    </div>
    <!-- BiLSTM -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(251,191,36,.2);background:linear-gradient(135deg,rgba(251,191,36,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(251,191,36,.12);color:#fbbf24;font-family:'JetBrains Mono';letter-spacing:.5px">D</span>
        <span style="font-size:.7em;font-weight:800;color:#fbbf24">BiLSTM-Attention</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Captures gradual temperature rise and fan degradation patterns over 15-sample sequences (~60s). Attention pooling for temporal focus.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(251,191,36,.08);color:#fbbf24;font-family:'JetBrains Mono'">128+64 LSTM</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(251,191,36,.08);color:#fbbf24;font-family:'JetBrains Mono'">seq=15</span>
      </div>
    </div>
    <!-- IF + LOF -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(248,113,113,.2);background:linear-gradient(135deg,rgba(248,113,113,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(248,113,113,.12);color:#f87171;font-family:'JetBrains Mono';letter-spacing:.5px">E1+E2</span>
        <span style="font-size:.7em;font-weight:800;color:#f87171">IsoForest + LOF</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Unsupervised anomaly ensemble. IF: 200 estimators for global outliers. LOF: 20 neighbors for local density anomalies. 50/50 weighted.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(248,113,113,.08);color:#f87171;font-family:'JetBrains Mono'">Unsupervised</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(248,113,113,.08);color:#f87171;font-family:'JetBrains Mono'">5% contam</span>
      </div>
    </div>
  </div>
</div>

<!-- Clogging Risk Levels -->
<div class="cd" style="padding:20px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">🏷️</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">Clogging Risk Levels</h3>
  </div>
  <div style="display:flex;flex-wrap:wrap;gap:8px">
    <div style="flex:1;min-width:140px;padding:12px;border-radius:10px;border:1px solid rgba(52,211,153,.25);background:linear-gradient(135deg,rgba(52,211,153,.06),transparent);text-align:center">
      <div style="font-size:.55em;font-weight:900;color:#34d399;letter-spacing:.5px">CLEAN</div>
      <div style="font-size:1.1em;font-weight:900;color:#34d399;margin:4px 0">0–15%</div>
      <div style="font-size:.48em;color:var(--dim)">Normal thermal resistance<br>Fans nominal</div>
    </div>
    <div style="flex:1;min-width:140px;padding:12px;border-radius:10px;border:1px solid rgba(251,191,36,.25);background:linear-gradient(135deg,rgba(251,191,36,.06),transparent);text-align:center">
      <div style="font-size:.55em;font-weight:900;color:#fbbf24;letter-spacing:.5px">LIGHT DUST</div>
      <div style="font-size:1.1em;font-weight:900;color:#fbbf24;margin:4px 0">15–35%</div>
      <div style="font-size:.48em;color:var(--dim)">Slight ΔT elevation<br>No derating yet</div>
    </div>
    <div style="flex:1;min-width:140px;padding:12px;border-radius:10px;border:1px solid rgba(249,115,22,.25);background:linear-gradient(135deg,rgba(249,115,22,.06),transparent);text-align:center">
      <div style="font-size:.55em;font-weight:900;color:#fb923c;letter-spacing:.5px">MODERATE CLOG</div>
      <div style="font-size:1.1em;font-weight:900;color:#fb923c;margin:4px 0">35–55%</div>
      <div style="font-size:.48em;color:var(--dim)">Noticeable thermal rise<br>Approaching 55°C</div>
    </div>
    <div style="flex:1;min-width:140px;padding:12px;border-radius:10px;border:1px solid rgba(248,113,113,.25);background:linear-gradient(135deg,rgba(248,113,113,.06),transparent);text-align:center">
      <div style="font-size:.55em;font-weight:900;color:#f87171;letter-spacing:.5px">SEVERE CLOG</div>
      <div style="font-size:1.1em;font-weight:900;color:#f87171;margin:4px 0">55–75%</div>
      <div style="font-size:.48em;color:var(--dim)">Near/exceeding derating<br>Schedule maintenance</div>
    </div>
    <div style="flex:1;min-width:140px;padding:12px;border-radius:10px;border:1px solid rgba(220,38,38,.25);background:linear-gradient(135deg,rgba(220,38,38,.06),transparent);text-align:center">
      <div style="font-size:.55em;font-weight:900;color:#dc2626;letter-spacing:.5px">CRITICAL BLOCK</div>
      <div style="font-size:1.1em;font-weight:900;color:#dc2626;margin:4px 0">75–100%</div>
      <div style="font-size:.48em;color:var(--dim)">OTP risk &gt;70°C<br>Immediate maintenance</div>
    </div>
  </div>
</div>

<!-- Phoenix Contact Thresholds -->
<div class="cd" style="padding:20px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">⚡</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">Phoenix Contact CHARX PS-M2 Thresholds</h3>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(251,191,36,.2);background:linear-gradient(135deg,rgba(251,191,36,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#fbbf24;margin-bottom:4px">🌡️ Derating</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">&gt; 55°C → power reduction<br>3.2 A/K, 1 kW/K</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(248,113,113,.2);background:linear-gradient(135deg,rgba(248,113,113,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#f87171;margin-bottom:4px">🛑 OTP Shutdown</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">&gt; 75°C → emergency<br>shutdown activated</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(52,211,153,.2);background:linear-gradient(135deg,rgba(52,211,153,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#34d399;margin-bottom:4px">🔄 Fan Life</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">70,000h @ 40°C<br>rated operational</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(56,189,248,.2);background:linear-gradient(135deg,rgba(56,189,248,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#38bdf8;margin-bottom:4px">💨 Airflow</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">Front → Back<br>dust on intake filter</div>
    </div>
  </div>
</div>

<!-- Conditions & Data Fields -->
<div class="cd" style="padding:20px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">📊</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">15 Monitoring Conditions</h3>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px">
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(167,139,250,.2);background:linear-gradient(135deg,rgba(167,139,250,.06),transparent)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
        <span style="font-size:.62em;font-weight:800;color:#a78bfa">Hybrid (AI + Rule)</span>
        <span style="font-size:.48em;font-weight:900;padding:2px 8px;border-radius:4px;background:rgba(167,139,250,.1);color:#a78bfa;font-family:'JetBrains Mono'">7 conditions</span>
      </div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.8;font-family:'JetBrains Mono'">C01–C05 PM Temp 1-5 (&gt;55°C + AI)<br>C14 DFC Overdue (&gt;720h)<br>C15 Energy Throughput</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(56,189,248,.2);background:linear-gradient(135deg,rgba(56,189,248,.06),transparent)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
        <span style="font-size:.62em;font-weight:800;color:#38bdf8">AI Only</span>
        <span style="font-size:.48em;font-weight:900;padding:2px 8px;border-radius:4px;background:rgba(56,189,248,.1);color:#38bdf8;font-family:'JetBrains Mono'">5 conditions</span>
      </div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.8;font-family:'JetBrains Mono'">C08 Fan RPM Anomaly<br>C09 Thermal Resistance<br>C10 EdgeBox / C11 Pi5 Temp<br>C12 Ambient + Humidity</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(249,115,22,.2);background:linear-gradient(135deg,rgba(249,115,22,.06),transparent)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
        <span style="font-size:.62em;font-weight:800;color:#fb923c">Rule Only</span>
        <span style="font-size:.48em;font-weight:900;padding:2px 8px;border-radius:4px;background:rgba(249,115,22,.1);color:#fb923c;font-family:'JetBrains Mono'">3 conditions</span>
      </div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.8;font-family:'JetBrains Mono'">C06 Fan Group A Status<br>C07 Fan Group B Status<br>C13 Pressure Drop (&lt;990 hPa)</div>
    </div>
  </div>
</div>

<!-- Data Fields -->
<div class="cd" style="padding:20px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">⚙️</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">Data Fields Specification</h3>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(248,113,113,.2);background:linear-gradient(135deg,rgba(248,113,113,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#f87171;margin-bottom:4px">🚫 Excluded</div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">_id, total_E_since<br>timestamp_utc (dup)<br>PLC1_temp, PLC2_temp</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(100,116,139,.2);background:linear-gradient(135deg,rgba(100,116,139,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#94a3b8;margin-bottom:4px">📌 Constant</div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">fan_status1–8<br>(always = 1)<br>fans permanently ON</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(52,211,153,.2);background:linear-gradient(135deg,rgba(52,211,153,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#34d399;margin-bottom:4px">⭐ Key Features</div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">P(t)1/P(t)2 = I×V power<br>time_since_last_DFC<br>meter1/2 = cum kWh</div>
    </div>
  </div>
</div>

</div></div><!-- /m2tab-algos -->

<!-- TAB 4: Detection Output -->
<div class="tc" id="m2tab-output"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>📊</i> <span data-i18n="m2_do_h">Detection Output — Filter Clogging Monitoring</span></span>
    <div style="display:flex;align-items:center;gap:8px">
      <span class="do-ts" id="m2DoTs"></span>
      <button onclick="m2DoRefresh()" style="padding:3px 10px;border-radius:5px;background:var(--acc);color:#fff;border:none;cursor:pointer;font-size:.6em" data-i18n="do_refresh">Refresh</button>
    </div>
  </div>
</div>
<div class="do-sum" id="m2DoSum">
  <span class="do-chip-ok">🟢 OK: <b id="m2DoOk">0</b></span>
  <span class="do-chip-warn">🟡 WARN: <b id="m2DoWn">0</b></span>
  <span class="do-chip-alarm">🔴 ALARM: <b id="m2DoAl">0</b></span>
  <span style="color:var(--dim);font-size:.7em">Total: 15 conditions</span>
</div>
<div class="do-wrap"><table class="do-tbl">
  <thead><tr><th>#</th><th>Type</th><th>Condition</th><th>Equipment</th><th>Input Value</th><th>Rule Output</th><th>AI Output</th><th>Status</th></tr></thead>
  <tbody id="m2DoTbl"><tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data…</td></tr></tbody>
</table></div>
</div></div><!-- /m2tab-output -->

</div><!-- /pageMod2 -->

<!-- ═══════════ MODULE 3 PAGE ═══════════ -->
<div class="m3-page" id="pageMod3">

<!-- Module 3 Tab Bar -->
<div class="tbs" id="m3TabBar">
  <div class="tb on" onclick="m3stab('main')" data-i18n="m3_tab1">📡 AI Detection &amp; Health Tree</div>
  <div class="tb" onclick="m3stab('history')" data-i18n="m3_tab2">📈 Historical Graph</div>
  <div class="tb" onclick="m3stab('algos')" data-i18n="m3_tab3">📖 Algorithm Description</div>
  <div class="tb" onclick="m3stab('output')" data-i18n="m3_tab4">📊 Detection Output</div>
</div>

<!-- TAB 1: Main Content -->
<div class="tc on" id="m3tab-main"><div class="pg">

<!-- Module 3 Header -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>📡</i> <span data-i18n="m3_title">Charger Offline Detection — AI Status Tree</span></span>
    <div style="display:flex;align-items:center;gap:10px;font-size:.55em;font-family:'JetBrains Mono';font-weight:600;color:var(--dim)">
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#0ea5e9,#38bdf8);display:inline-block"></span>ML</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#7c3aed,#a855f7);display:inline-block"></span>DL</span>
    </div>
    <div class="tele-live">
      <div class="led" id="m3Led"></div>
      <span class="tele-st" id="m3St" data-i18n="tele_connecting">Connecting…</span>
      <span class="tele-ts" id="m3Ts"></span>
    </div>
  </div>

  <!-- ═══ DB CONNECTION STATUS ═══ -->
  <div class="db-bar" id="m3DbBar">
    <div class="db-chip wait" id="m3DbChip">
      <span class="db-dot wait" id="m3DbDot"></span>
      <span class="db-lbl">MongoDB</span>
      <span class="db-val" id="m3DbSt">Checking…</span>
    </div>
    <div class="db-sep"></div>
    <span class="db-detail" id="m3DbInfo">database: module3ChargerOfflineAnalysis</span>
  </div>

  <!-- ═══ MODEL LOADING INDICATOR ═══ -->

  <!-- ═══ AUTO-PREDICT CONTROL ═══ -->
  <div class="m3-ap" id="m3ApPanel">
    <div class="m3-ap-grp">
      <label class="tgl" title="Auto-predict every 2 min"><input type="checkbox" id="m3ApToggle" checked onchange="m3ApToggleChanged()"><span class="tgl-sl"></span></label>
      <div style="display:flex;flex-direction:column;gap:1px">
        <span class="m3-ap-lbl" data-i18n="m3_ap_label">Auto Predict</span>
        <span class="m3-ap-badge idle" id="m3ApBadge">IDLE</span>
      </div>
    </div>
    <div class="m3-ap-sep"></div>
    <div class="m3-ap-grp">
      <span class="m3-ap-lbl" data-i18n="m3_ap_next">Next</span>
      <span class="m3-ap-cd" id="m3ApCd">OFF</span>
    </div>
    <div class="m3-ap-sep"></div>
    <div class="m3-ap-ts">
      <div class="m3-ap-ts-row"><i>📥</i> <span data-i18n="m3_ap_queried">Queried:</span> <span class="m3-ap-ts-val" id="m3ApQueryTs">—</span></div>
      <div class="m3-ap-ts-row"><i>🧠</i> <span data-i18n="m3_ap_predicted">Predicted:</span> <span class="m3-ap-ts-val" id="m3ApPredTs">—</span></div>
    </div>
    <div class="m3-ap-sep"></div>
    <div class="m3-ap-ts">
      <div class="m3-ap-ts-row"><i>⏱️</i> <span data-i18n="m3_ap_latency">Latency:</span> <span class="m3-ap-ts-val" id="m3ApLat">—</span></div>
      <div class="m3-ap-ts-row"><i>📊</i> <span data-i18n="m3_ap_result">Result:</span> <span class="m3-ap-ts-val" id="m3ApResult">—</span></div>
    </div>
  </div>

  <!-- Summary Bar -->
  <div class="hg-wrap">
    <div class="hg-bar">
      <div class="hg-seg hg-normal" id="m3HgNormal" style="width:100%"></div>
      <div class="hg-seg hg-warn" id="m3HgWarn" style="width:0%"></div>
      <div class="hg-seg hg-alarm" id="m3HgAlarm" style="width:0%"></div>
    </div>
    <div class="hg-labels">
      <div class="hg-lbl hg-lbl-normal"><span class="hg-dot" style="background:#16a34a"></span><span data-i18n="gauge_normal">Normal</span> <strong id="m3HgNormCnt">6</strong></div>
      <div class="hg-lbl hg-lbl-warn"><span class="hg-dot" style="background:#d97706"></span><span data-i18n="gauge_warning">Warning</span> <strong id="m3HgWarnCnt">0</strong></div>
      <div class="hg-lbl hg-lbl-alarm"><span class="hg-dot" style="background:#ef4444"></span><span data-i18n="gauge_alarm">Alarm</span> <strong id="m3HgAlarmCnt">0</strong></div>
      <div class="hg-total"><span id="m3HgTotal">6 / 6 models OK</span></div>
    </div>
  </div>

  <!-- ═══ AI MODEL STATUS TREE ═══ -->
  <div class="m3-tree-wrap" id="m3TreeCanvas">
    <svg class="m3-tree-svg" id="m3TreeSvg"></svg>

    <!-- LEFT: AI Model Nodes -->
    <div class="m3-col-m" id="m3ColM">
      <div class="m3-mn" id="m3mA" data-grp="cls">
        <span class="m3-mn-tp m3-ml">ML</span>
        <span class="m3-mn-id">A</span>
        <div class="m3-mn-info">
          <div class="m3-mn-name">XGBoost Root Cause</div>
          <div class="m3-mn-sub" data-i18n="m3_ma_sub">Multi-class Classifier</div>
        </div>
        <span class="m3-mn-val" id="m3vA">&mdash;</span>
        <span class="m3-mn-badge m3-ok" id="m3bA">OK</span>
      </div>
      <div class="m3-mn" id="m3mA2" data-grp="cls">
        <span class="m3-mn-tp m3-dl">DL</span>
        <span class="m3-mn-id">A2</span>
        <div class="m3-mn-info">
          <div class="m3-mn-name">DNN Root Cause</div>
          <div class="m3-mn-sub" data-i18n="m3_ma2_sub">Deep Neural Network</div>
        </div>
        <span class="m3-mn-val" id="m3vA2">&mdash;</span>
        <span class="m3-mn-badge m3-ok" id="m3bA2">OK</span>
      </div>

      <div class="gs"></div>

      <div class="m3-mn" id="m3mB" data-grp="ew">
        <span class="m3-mn-tp m3-ml">ML</span>
        <span class="m3-mn-id">B</span>
        <div class="m3-mn-info">
          <div class="m3-mn-name">Early Warning</div>
          <div class="m3-mn-sub" data-i18n="m3_mb_sub">~2 min Pre-Fault Alert</div>
        </div>
        <span class="m3-mn-val" id="m3vB">&mdash;</span>
        <span class="m3-mn-badge m3-ok" id="m3bB">OK</span>
      </div>

      <div class="gs"></div>

      <div class="m3-mn" id="m3mC" data-grp="ad">
        <span class="m3-mn-tp m3-dl">DL</span>
        <span class="m3-mn-id">C</span>
        <div class="m3-mn-info">
          <div class="m3-mn-name">Autoencoder</div>
          <div class="m3-mn-sub" data-i18n="m3_mc_sub">Reconstruction Anomaly</div>
        </div>
        <span class="m3-mn-val" id="m3vC">&mdash;</span>
        <span class="m3-mn-badge m3-ok" id="m3bC">OK</span>
      </div>
      <div class="m3-mn" id="m3mD" data-grp="ad">
        <span class="m3-mn-tp m3-dl">DL</span>
        <span class="m3-mn-id">D</span>
        <div class="m3-mn-info">
          <div class="m3-mn-name">BiLSTM-Attention</div>
          <div class="m3-mn-sub" data-i18n="m3_md_sub">Sequence Anomaly</div>
        </div>
        <span class="m3-mn-val" id="m3vD">&mdash;</span>
        <span class="m3-mn-badge m3-ok" id="m3bD">OK</span>
      </div>
      <div class="m3-mn" id="m3mE" data-grp="ad">
        <span class="m3-mn-tp m3-ml">ML</span>
        <span class="m3-mn-id">E</span>
        <div class="m3-mn-info">
          <div class="m3-mn-name">IF + LOF Ensemble</div>
          <div class="m3-mn-sub" data-i18n="m3_me_sub">Isolation Forest + LOF</div>
        </div>
        <span class="m3-mn-val" id="m3vE">&mdash;</span>
        <span class="m3-mn-badge m3-ok" id="m3bE">OK</span>
      </div>
    </div>

    <!-- MIDDLE: Detection Strategy Groups -->
    <div class="m3-col-g" id="m3ColG">
      <div class="m3-gn" id="m3gCls" style="border-color:#0ea5e9;color:#0ea5e9">
        <div class="m3-gn-t">🎯 <span data-i18n="m3_g_cls">Classification</span></div>
        <div class="m3-gn-c">Models A, A2</div>
        <div class="m3-gn-s m3-gn-ok" id="m3gClsS">NORMAL</div>
      </div>
      <div class="m3-gn" id="m3gEw" style="border-color:#d97706;color:#d97706">
        <div class="m3-gn-t">⚠️ <span data-i18n="m3_g_ew">Early Warning</span></div>
        <div class="m3-gn-c">Model B</div>
        <div class="m3-gn-s m3-gn-ok" id="m3gEwS">CLEAR</div>
      </div>
      <div class="m3-gn" id="m3gAd" style="border-color:#8b5cf6;color:#8b5cf6">
        <div class="m3-gn-t">🔍 <span data-i18n="m3_g_ad">Anomaly Detection</span></div>
        <div class="m3-gn-c">Models C, D, E</div>
        <div class="m3-gn-s m3-gn-ok" id="m3gAdS">NORMAL</div>
      </div>
    </div>

    <!-- RIGHT: System Status Gauge -->
    <div class="m3-col-r" id="m3ColR">
      <div class="m3-root" id="m3Root">
        <div class="m3-gauge-wrap">
          <svg class="m3-gauge" viewBox="0 0 260 165" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="m3gN" x1="20" y1="135" x2="240" y2="135" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#22c55e"/><stop offset="100%" stop-color="#16a34a"/></linearGradient>
              <linearGradient id="m3gW" x1="20" y1="135" x2="240" y2="135" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#d97706"/></linearGradient>
              <linearGradient id="m3gA" x1="20" y1="135" x2="240" y2="135" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#f87171"/><stop offset="100%" stop-color="#dc2626"/></linearGradient>
              <filter id="m3glN" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3.5" result="b"/><feFlood flood-color="#22c55e" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m3glW" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3.5" result="b"/><feFlood flood-color="#fbbf24" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m3glA" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3.5" result="b"/><feFlood flood-color="#ef4444" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m3tipG"><feGaussianBlur stdDeviation="3.5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
            </defs>
            <!-- Background tracks -->
            <path d="M 20 135 A 110 110 0 0 1 240 135" fill="none" stroke="rgba(0,0,0,.03)" stroke-width="3" stroke-linecap="round"/>
            <path d="M 32 135 A 98 98 0 0 1 228 135" fill="none" stroke="rgba(0,0,0,.035)" stroke-width="18" stroke-linecap="round"/>
            <!-- Zone backgrounds -->
            <path d="M 32 135 A 98 98 0 0 1 228 135" fill="none" stroke="url(#m3gN)" stroke-width="12" stroke-linecap="round" stroke-dasharray="97.4 210" opacity=".1"/>
            <path d="M 32 135 A 98 98 0 0 1 228 135" fill="none" stroke="url(#m3gW)" stroke-width="12" stroke-dasharray="97.4 210" stroke-dashoffset="-97.4" opacity=".1"/>
            <path d="M 32 135 A 98 98 0 0 1 228 135" fill="none" stroke="url(#m3gA)" stroke-width="12" stroke-linecap="round" stroke-dasharray="112.6 194.8" stroke-dashoffset="-194.8" opacity=".1"/>
            <!-- Active arcs -->
            <path d="M 32 135 A 98 98 0 0 1 228 135" fill="none" stroke="url(#m3gN)" stroke-width="12" stroke-linecap="round" stroke-dasharray="307.4" stroke-dashoffset="307.4" id="m3ArcN" filter="url(#m3glN)" opacity="0"/>
            <path d="M 32 135 A 98 98 0 0 1 228 135" fill="none" stroke="url(#m3gW)" stroke-width="12" stroke-dasharray="307.4" stroke-dashoffset="307.4" id="m3ArcW" filter="url(#m3glW)" opacity="0"/>
            <path d="M 32 135 A 98 98 0 0 1 228 135" fill="none" stroke="url(#m3gA)" stroke-width="12" stroke-linecap="round" stroke-dasharray="307.4" stroke-dashoffset="307.4" id="m3ArcA" filter="url(#m3glA)" opacity="0"/>
            <!-- Tick marks -->
            <g id="m3Ticks"></g>
            <!-- Needle -->
            <g id="m3Needle" transform="rotate(-90 130 135)">
              <path d="M128.5,42 L131.5,42 L130.8,128 L129.2,128 Z" fill="#1e293b" opacity=".85"/>
              <circle cx="130" cy="135" r="8" fill="#fff" stroke="#1e293b" stroke-width="2.5"/>
              <circle cx="130" cy="135" r="3" fill="#1e293b"/>
              <circle cx="130" cy="42" r="3" fill="#16a34a" id="m3Tip" filter="url(#m3tipG)" opacity=".95"/>
            </g>
            <!-- Value text -->
            <text x="130" y="122" text-anchor="middle" font-size="36" font-weight="900" font-family="JetBrains Mono" id="m3GVal" fill="#1e293b">0%</text>
            <!-- Zone labels -->
            <text x="50" y="150" font-size="6.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" letter-spacing="1">NORMAL</text>
            <text x="130" y="22" font-size="6.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" text-anchor="middle" letter-spacing="1">WARNING</text>
            <text x="186" y="150" font-size="6.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" letter-spacing="1">ALARM</text>
          </svg>
          <div class="rn-pill" id="m3Pill">
            <span class="rn-pill-dot" id="m3Dot" style="background:#16a34a"></span>
            <span class="rn-pill-txt" id="m3Txt" style="color:#16a34a">ONLINE</span>
          </div>
        </div>
        <div class="rn-h" data-i18n="m3_root_title">Charger Offline Status</div>
        <div class="rn-s" data-i18n="m3_root_sub">System Availability Monitor</div>
        <div class="rn-cnt" id="m3RootCnt">0% — 0 / 6 alerts</div>
      </div>
    </div>
  </div>
</div>

<!-- ═══ ASSET HEALTH STATUS TREE — MODULE 3 ═══ -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>🏥</i> <span data-i18n="m3_ht_title">Charger Offline — Condition Health Tree</span></span>
    <div style="display:flex;align-items:center;gap:10px;font-size:.55em;font-family:'JetBrains Mono';font-weight:600;color:var(--dim)">
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#0284c7,#06b6d4);display:inline-block"></span>Hybrid</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#7c3aed,#a855f7);display:inline-block"></span>AI</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#475569,#64748b);display:inline-block"></span>Rule</span>
    </div>
    <span class="ht-summary"><span class="ht-ok" id="m3htOk">0</span>/<span class="ht-alarm" id="m3htAl">0</span></span>
  </div>

  <!-- Gauge Bar -->
  <div class="hg-wrap">
    <div class="hg-bar">
      <div class="hg-seg hg-normal" id="m3htBarN" style="width:100%"></div>
      <div class="hg-seg hg-warn" id="m3htBarW" style="width:0%"></div>
      <div class="hg-seg hg-alarm" id="m3htBarA" style="width:0%"></div>
    </div>
    <div class="hg-labels">
      <div class="hg-lbl hg-lbl-normal"><span class="hg-dot" style="background:#16a34a"></span><span data-i18n="gauge_normal">Normal</span> <strong id="m3htNormCnt">17</strong></div>
      <div class="hg-lbl hg-lbl-warn"><span class="hg-dot" style="background:#d97706"></span><span data-i18n="gauge_warning">Warning</span> <strong id="m3htWarnCnt">0</strong></div>
      <div class="hg-lbl hg-lbl-alarm"><span class="hg-dot" style="background:#ef4444"></span><span data-i18n="gauge_alarm">Alarm</span> <strong id="m3htAlrmCnt">0</strong></div>
      <div class="hg-total"><span id="m3htTotal">17 / 17</span></div>
    </div>
  </div>

  <!-- 3-Column Health Tree -->
  <div class="ht-wrap">
  <div class="ht-canvas" id="m3htCanvas">
    <svg class="ht-svg" id="m3htSvg"></svg>

    <!-- LEFT: 17 Conditions -->
    <div class="col ht-col-c" id="m3ColC">
    <div class="cn" id="m3c01" data-tp="hy" data-m3g="acpow"><span class="cn-n">01</span><span class="cn-t">Voltage Phase A</span><span class="cn-v" id="m3v01">&mdash;</span><span class="cn-b ok" id="m3b01">OK</span></div>
    <div class="cn" id="m3c02" data-tp="hy" data-m3g="acpow"><span class="cn-n">02</span><span class="cn-t">Voltage Phase B</span><span class="cn-v" id="m3v02">&mdash;</span><span class="cn-b ok" id="m3b02">OK</span></div>
    <div class="cn" id="m3c03" data-tp="hy" data-m3g="acpow"><span class="cn-n">03</span><span class="cn-t">Voltage Phase C</span><span class="cn-v" id="m3v03">&mdash;</span><span class="cn-b ok" id="m3b03">OK</span></div>
    <div class="cn" id="m3c04" data-tp="hy" data-m3g="acpow"><span class="cn-n">04</span><span class="cn-t">Current Phase A</span><span class="cn-v" id="m3v04">&mdash;</span><span class="cn-b ok" id="m3b04">OK</span></div>
    <div class="cn" id="m3c05" data-tp="hy" data-m3g="acpow"><span class="cn-n">05</span><span class="cn-t">Current Phase B</span><span class="cn-v" id="m3v05">&mdash;</span><span class="cn-b ok" id="m3b05">OK</span></div>
    <div class="cn" id="m3c06" data-tp="hy" data-m3g="acpow"><span class="cn-n">06</span><span class="cn-t">Current Phase C</span><span class="cn-v" id="m3v06">&mdash;</span><span class="cn-b ok" id="m3b06">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="m3c07" data-tp="ai" data-m3g="net"><span class="cn-n">07</span><span class="cn-t">Edgebox Status</span><span class="cn-v" id="m3v07">&mdash;</span><span class="cn-b ok" id="m3b07">OK</span></div>
    <div class="cn" id="m3c08" data-tp="ai" data-m3g="net"><span class="cn-n">08</span><span class="cn-t">Router Internet</span><span class="cn-v" id="m3v08">&mdash;</span><span class="cn-b ok" id="m3b08">OK</span></div>
    <div class="cn" id="m3c09" data-tp="ai" data-m3g="net"><span class="cn-n">09</span><span class="cn-t">Router Status</span><span class="cn-v" id="m3v09">&mdash;</span><span class="cn-b ok" id="m3b09">OK</span></div>
    <div class="cn" id="m3c10" data-tp="ai" data-m3g="net"><span class="cn-n">10</span><span class="cn-t">RSSI Signal</span><span class="cn-v" id="m3v10">&mdash;</span><span class="cn-b ok" id="m3b10">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="m3c11" data-tp="rl" data-m3g="plc"><span class="cn-n">11</span><span class="cn-t">PLC1 Status</span><span class="cn-v" id="m3v11">&mdash;</span><span class="cn-b ok" id="m3b11">OK</span></div>
    <div class="cn" id="m3c12" data-tp="rl" data-m3g="plc"><span class="cn-n">12</span><span class="cn-t">PLC2 Status</span><span class="cn-v" id="m3v12">&mdash;</span><span class="cn-b ok" id="m3b12">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="m3c13" data-tp="rl" data-m3g="mdb"><span class="cn-n">13</span><span class="cn-t">MDB Status</span><span class="cn-v" id="m3v13">&mdash;</span><span class="cn-b ok" id="m3b13">OK</span></div>
    <div class="cn" id="m3c14" data-tp="rl" data-m3g="mdb"><span class="cn-n">14</span><span class="cn-t">Energy Meter</span><span class="cn-v" id="m3v14">&mdash;</span><span class="cn-b ok" id="m3b14">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="m3c15" data-tp="ai" data-m3g="thm"><span class="cn-n">15</span><span class="cn-t">Edgebox Temp</span><span class="cn-v" id="m3v15">&mdash;</span><span class="cn-b ok" id="m3b15">OK</span></div>
    <div class="cn" id="m3c16" data-tp="ai" data-m3g="thm"><span class="cn-n">16</span><span class="cn-t">Pi5 Temp</span><span class="cn-v" id="m3v16">&mdash;</span><span class="cn-b ok" id="m3b16">OK</span></div>
    <div class="cn" id="m3c17" data-tp="ai" data-m3g="thm"><span class="cn-n">17</span><span class="cn-t">Charger Ambient</span><span class="cn-v" id="m3v17">&mdash;</span><span class="cn-b ok" id="m3b17">OK</span></div>
    </div>

    <!-- MIDDLE: Equipment Groups -->
    <div class="col ht-col-e" id="m3ColE">
      <div class="en" id="m3eqAC" style="border-color:#d97706;color:#d97706"><div class="en-t">&#9889; AC Power Supply</div><div class="en-c">6 conditions</div></div>
      <div class="en" id="m3eqNET" style="border-color:#0891b2;color:#0891b2"><div class="en-t">&#128225; Network / EdgeBox</div><div class="en-c">4 conditions</div></div>
      <div class="en" id="m3eqPLC" style="border-color:#7c3aed;color:#7c3aed"><div class="en-t">&#128268; PLC Controller</div><div class="en-c">2 conditions</div></div>
      <div class="en" id="m3eqMDB" style="border-color:#059669;color:#059669"><div class="en-t">&#128161; MDB / Meter</div><div class="en-c">2 conditions</div></div>
      <div class="en" id="m3eqTHM" style="border-color:#dc2626;color:#dc2626"><div class="en-t">&#127777; Thermal</div><div class="en-c">3 conditions</div></div>
    </div>

    <!-- RIGHT: Root Cause Gauge -->
    <div class="col ht-col-r" id="m3ColRC">
      <div class="rn" id="m3htRoot">
        <div class="rn-gauge-wrap">
          <svg class="rn-gauge" viewBox="0 0 300 190" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="m3gNorm" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#22c55e"/><stop offset="100%" stop-color="#16a34a"/></linearGradient>
              <linearGradient id="m3gWarn" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#d97706"/></linearGradient>
              <linearGradient id="m3gAlrm" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#f87171"/><stop offset="100%" stop-color="#dc2626"/></linearGradient>
              <filter id="m3glowN" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#22c55e" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m3glowW" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#fbbf24" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m3glowA" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#ef4444" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="m3tipGlow"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
            </defs>
            <path d="M 25 155 A 125 125 0 0 1 275 155" fill="none" stroke="rgba(0,0,0,.03)" stroke-width="3" stroke-linecap="round"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="rgba(0,0,0,.035)" stroke-width="20" stroke-linecap="round"/>
            <g id="m3htTicks"></g>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m3gNorm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="111.9 240" stroke-dashoffset="0" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m3gWarn)" stroke-width="14" stroke-dasharray="111.9 240" stroke-dashoffset="-111.9" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m3gAlrm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="128 223.9" stroke-dashoffset="-223.8" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m3gNorm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="m3htArcN" filter="url(#m3glowN)" opacity="0"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m3gWarn)" stroke-width="14" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="m3htArcW" filter="url(#m3glowW)" opacity="0"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#m3gAlrm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="m3htArcA" filter="url(#m3glowA)" opacity="0"/>
            <g id="m3htNeedle" transform="rotate(-90 150 155)">
              <path d="M148.5,52 L151.5,52 L150.8,146 L149.2,146 Z" fill="#1e293b" opacity=".85"/>
              <circle cx="150" cy="155" r="9" fill="#fff" stroke="#1e293b" stroke-width="3"/>
              <circle cx="150" cy="155" r="3.5" fill="#1e293b"/>
              <circle cx="150" cy="42" r="3.5" fill="#16a34a" id="m3htTip" filter="url(#m3tipGlow)" opacity=".95"/>
            </g>
            <text x="150" y="142" text-anchor="middle" font-size="42" font-weight="900" font-family="JetBrains Mono" id="m3htVal" fill="#1e293b">0%</text>
            <text x="56" y="172" font-size="7.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" letter-spacing="1">NORMAL</text>
            <text x="150" y="28" font-size="7.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" text-anchor="middle" letter-spacing="1">WARNING</text>
            <text x="210" y="172" font-size="7.5" font-weight="700" font-family="JetBrains Mono" fill="#94a3b8" letter-spacing="1">ALARM</text>
          </svg>
          <div class="rn-pill" id="m3htPill">
            <span class="rn-pill-dot" id="m3htDot" style="background:#16a34a"></span>
            <span class="rn-pill-txt" id="m3htTxt" style="color:#16a34a">NORMAL</span>
          </div>
        </div>
        <div class="rn-h" style="color:#16a34a" id="m3htRootH" data-i18n="m3_ht_root">Charger Offline Root-Cause</div>
        <div class="rn-s">17 Condition Monitor</div>
        <div class="rn-cnt" id="m3htRootCnt">0% — 0 / 17 alarms</div>
      </div>
    </div>
  </div>
  </div>
</div>

<!-- ═══ ROOT CAUSE PROBABILITY ═══ -->
<div class="cd cd-pu" style="margin-bottom:14px">
  <div class="ct"><i>📊</i> <span data-i18n="m3_prob_title">Root Cause Probability Distribution</span></div>
  <div class="m3-prob-wrap" id="m3ProbWrap">
    <div class="m3-prob-row">
      <span class="m3-prob-lbl">NORMAL</span>
      <div class="m3-prob-bar"><div class="m3-prob-fill" id="m3pNorm" style="width:100%;background:linear-gradient(90deg,#22c55e,#16a34a)"></div></div>
      <span class="m3-prob-val" id="m3pvNorm" style="color:#16a34a">100%</span>
    </div>
    <div class="m3-prob-row">
      <span class="m3-prob-lbl">POWER_OUTAGE</span>
      <div class="m3-prob-bar"><div class="m3-prob-fill" id="m3pPwr" style="width:0%;background:linear-gradient(90deg,#ef4444,#dc2626)"></div></div>
      <span class="m3-prob-val" id="m3pvPwr" style="color:#ef4444">0%</span>
    </div>
    <div class="m3-prob-row">
      <span class="m3-prob-lbl">EDGEBOX_FAIL</span>
      <div class="m3-prob-bar"><div class="m3-prob-fill" id="m3pEdge" style="width:0%;background:linear-gradient(90deg,#f59e0b,#d97706)"></div></div>
      <span class="m3-prob-val" id="m3pvEdge" style="color:#d97706">0%</span>
    </div>
    <div class="m3-prob-row">
      <span class="m3-prob-lbl">NETWORK_ISSUE</span>
      <div class="m3-prob-bar"><div class="m3-prob-fill" id="m3pNet" style="width:0%;background:linear-gradient(90deg,#3b82f6,#2563eb)"></div></div>
      <span class="m3-prob-val" id="m3pvNet" style="color:#3b82f6">0%</span>
    </div>
    <div class="m3-prob-row">
      <span class="m3-prob-lbl">PLC_FAULT</span>
      <div class="m3-prob-bar"><div class="m3-prob-fill" id="m3pPlc" style="width:0%;background:linear-gradient(90deg,#8b5cf6,#7c3aed)"></div></div>
      <span class="m3-prob-val" id="m3pvPlc" style="color:#8b5cf6">0%</span>
    </div>
  </div>
</div>

<!-- ═══ EARLY WARNING PANEL ═══ -->
<div class="cd cd-am" style="margin-bottom:14px">
  <div class="ct"><i>⏱️</i> <span data-i18n="m3_ew_title">Early Warning System — ~2 Minute Forecast</span></div>
  <div class="m3-ew-panel" id="m3EwPanel">
    <div class="m3-ew-icon" id="m3EwIcon">🟢</div>
    <div class="m3-ew-info">
      <div class="m3-ew-title" id="m3EwTitle" data-i18n="m3_ew_clear">No Pre-Fault Signals Detected</div>
      <div class="m3-ew-sub" id="m3EwSub">Probability: <strong id="m3EwProb">0.0%</strong> — Horizon: <strong id="m3EwHz">120s</strong></div>
    </div>
    <div class="m3-ew-badge m3-ew-safe" id="m3EwBadge">CLEAR</div>
  </div>
</div>

<!-- ═══ SIGNAL MONITOR ═══ -->
<div class="cd cd-gn" style="margin-bottom:14px">
  <div class="ct"><i>📶</i> <span data-i18n="m3_sig_title">Device Signal Monitor</span></div>
  <div class="m3-sig-grid" id="m3SigGrid">
    <div class="m3-sig" id="m3sMdb">
      <div class="m3-sig-name">MDB Status</div>
      <div class="m3-sig-val" id="m3svMdb">Active</div>
    </div>
    <div class="m3-sig" id="m3sEdge">
      <div class="m3-sig-name">EdgeBox Status</div>
      <div class="m3-sig-val" id="m3svEdge">Active</div>
    </div>
    <div class="m3-sig" id="m3sRouter">
      <div class="m3-sig-name">Router Status</div>
      <div class="m3-sig-val" id="m3svRouter">Active</div>
    </div>
    <div class="m3-sig" id="m3sPlc1">
      <div class="m3-sig-name">PLC1 Status</div>
      <div class="m3-sig-val" id="m3svPlc1">Active</div>
    </div>
    <div class="m3-sig" id="m3sPlc2">
      <div class="m3-sig-name">PLC2 Status</div>
      <div class="m3-sig-val" id="m3svPlc2">Active</div>
    </div>
    <div class="m3-sig" id="m3sVl1">
      <div class="m3-sig-name">VL1N (AC)</div>
      <div class="m3-sig-val"><span id="m3svVl1">230</span> <span class="m3-sig-unit">V</span></div>
    </div>
    <div class="m3-sig" id="m3sTemp">
      <div class="m3-sig-name">EdgeBox Temp</div>
      <div class="m3-sig-val"><span id="m3svTemp">42</span> <span class="m3-sig-unit">°C</span></div>
    </div>
    <div class="m3-sig" id="m3sRssi">
      <div class="m3-sig-name">WiFi RSSI</div>
      <div class="m3-sig-val"><span id="m3svRssi">-45</span> <span class="m3-sig-unit">dBm</span></div>
    </div>
  </div>
</div>

<!-- ═══ MODEL ARCHITECTURE TABLE ═══ -->
<div class="m3-load-panel collapsed" id="m3ArchPanel">
  <div class="m3-load-hdr" onclick="document.getElementById('m3ArchPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>🧠</i> <span data-i18n="m3_arch_title">AI Model Architecture Reference</span></div>
    <div class="m3-load-hdr-r"><span class="m3-load-toggle">▼</span></div>
  </div>
<div class="cd cd-sl" style="margin-bottom:0;border:none;background:transparent;box-shadow:none;padding:0">
  <div style="overflow-x:auto">
  <table class="sc-tbl">
    <thead><tr>
      <th style="width:40px">ID</th>
      <th style="width:56px">Type</th>
      <th style="width:160px">Model</th>
      <th>Description</th>
      <th style="width:130px">Output</th>
      <th style="width:100px">Strategy</th>
    </tr></thead>
    <tbody>
      <tr class="sc-grp"><td colspan="6">🎯 Classification Models</td></tr>
      <tr>
        <td><span class="sc-id sc-hy">A</span></td>
        <td><span class="sc-tp" style="background:rgba(14,165,233,.1);color:#0ea5e9">ML</span></td>
        <td>XGBoost Multi-Class</td>
        <td>Root cause classification: NORMAL, POWER_OUTAGE, EDGEBOX_FAILURE, NETWORK_ISSUE, PLC_FAULT</td>
        <td><code>class + confidence%</code></td>
        <td>Classification</td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">A2</span></td>
        <td><span class="sc-tp" style="background:rgba(168,85,247,.1);color:#a855f7">DL</span></td>
        <td>Deep Neural Network</td>
        <td>Dense layer classifier with dropout regularization for root cause verification</td>
        <td><code>class + confidence%</code></td>
        <td>Classification</td>
      </tr>
      <tr class="sc-grp"><td colspan="6">⚠️ Early Warning</td></tr>
      <tr>
        <td><span class="sc-id" style="background:rgba(217,119,6,.1);color:#d97706">B</span></td>
        <td><span class="sc-tp" style="background:rgba(14,165,233,.1);color:#0ea5e9">ML</span></td>
        <td>XGBoost Early Warning</td>
        <td>Binary classifier predicting offline event ~2 minutes before occurrence using rolling features</td>
        <td><code>probability%</code></td>
        <td>Early Warning</td>
      </tr>
      <tr class="sc-grp"><td colspan="6">🔍 Anomaly Detection</td></tr>
      <tr>
        <td><span class="sc-id" style="background:rgba(139,92,246,.1);color:#8b5cf6">C</span></td>
        <td><span class="sc-tp" style="background:rgba(168,85,247,.1);color:#a855f7">DL</span></td>
        <td>Autoencoder</td>
        <td>Unsupervised reconstruction error anomaly detector (95th/99th/99.9th percentile thresholds)</td>
        <td><code>MSE error score</code></td>
        <td>Anomaly Detection</td>
      </tr>
      <tr>
        <td><span class="sc-id" style="background:rgba(139,92,246,.1);color:#8b5cf6">D</span></td>
        <td><span class="sc-tp" style="background:rgba(168,85,247,.1);color:#a855f7">DL</span></td>
        <td>BiLSTM-Attention</td>
        <td>Bidirectional LSTM with attention mechanism for temporal sequence anomaly detection</td>
        <td><code>anomaly score</code></td>
        <td>Anomaly Detection</td>
      </tr>
      <tr>
        <td><span class="sc-id" style="background:rgba(139,92,246,.1);color:#8b5cf6">E</span></td>
        <td><span class="sc-tp" style="background:rgba(14,165,233,.1);color:#0ea5e9">ML</span></td>
        <td>IF + LOF Ensemble</td>
        <td>Isolation Forest combined with Local Outlier Factor for multi-perspective anomaly scoring</td>
        <td><code>anomaly score</code></td>
        <td>Anomaly Detection</td>
      </tr>
    </tbody>
  </table>
  </div>
</div>
</div><!-- /m3ArchPanel -->

<!-- ═══ CONDITION HEALTH REFERENCE TABLE ═══ -->
<div class="m3-load-panel collapsed" id="m3CondPanel">
  <div class="m3-load-hdr" onclick="document.getElementById('m3CondPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>&#128218;</i> <span data-i18n="m3_cond_title">Condition Health Reference — Charger Offline Root-Cause</span></div>
    <div class="m3-load-hdr-r"><span class="m3-load-toggle">▼</span></div>
  </div>
<div class="cd cd-sl" style="margin-bottom:0;border:none;background:transparent;box-shadow:none;padding:0">
  <div style="overflow-x:auto">
  <table class="sc-tbl">
    <thead><tr>
      <th style="width:36px">#</th>
      <th style="width:56px">Type</th>
      <th style="width:150px">Condition</th>
      <th>Detection Rule</th>
      <th style="width:110px">Threshold</th>
      <th style="width:120px">Equipment</th>
    </tr></thead>
    <tbody>
      <tr class="sc-grp"><td colspan="6">&#9889; AC Power Supply (3-Phase MDB)</td></tr>
      <tr><td><span class="sc-id sc-hy">C01</span></td><td><span class="sc-tp sc-hy">Hybrid</span></td><td>Voltage Phase A</td><td><code>VL1N_MDB == 0 → Power Outage</code></td><td><span class="sc-th">0V = Outage</span></td><td><span class="sc-eq" style="color:#d97706">AC Power</span></td></tr>
      <tr><td><span class="sc-id sc-hy">C02</span></td><td><span class="sc-tp sc-hy">Hybrid</span></td><td>Voltage Phase B</td><td><code>VL2N_MDB == 0 → Power Outage</code></td><td><span class="sc-th">0V = Outage</span></td><td><span class="sc-eq" style="color:#d97706">AC Power</span></td></tr>
      <tr><td><span class="sc-id sc-hy">C03</span></td><td><span class="sc-tp sc-hy">Hybrid</span></td><td>Voltage Phase C</td><td><code>VL3N_MDB == 0 → Power Outage</code></td><td><span class="sc-th">0V = Outage</span></td><td><span class="sc-eq" style="color:#d97706">AC Power</span></td></tr>
      <tr><td><span class="sc-id sc-hy">C04</span></td><td><span class="sc-tp sc-hy">Hybrid</span></td><td>Current Phase A</td><td><code>I1_MDB == 0 when V &gt; 0</code></td><td><span class="sc-th">0A = Off</span></td><td><span class="sc-eq" style="color:#d97706">AC Power</span></td></tr>
      <tr><td><span class="sc-id sc-hy">C05</span></td><td><span class="sc-tp sc-hy">Hybrid</span></td><td>Current Phase B</td><td><code>I2_MDB == 0 when V &gt; 0</code></td><td><span class="sc-th">0A = Off</span></td><td><span class="sc-eq" style="color:#d97706">AC Power</span></td></tr>
      <tr><td><span class="sc-id sc-hy">C06</span></td><td><span class="sc-tp sc-hy">Hybrid</span></td><td>Current Phase C</td><td><code>I3_MDB == 0 when V &gt; 0</code></td><td><span class="sc-th">0A = Off</span></td><td><span class="sc-eq" style="color:#d97706">AC Power</span></td></tr>
      <tr class="sc-grp"><td colspan="6">&#128225; Network / EdgeBox Connectivity</td></tr>
      <tr><td><span class="sc-id sc-ai">C07</span></td><td><span class="sc-tp sc-ai">AI</span></td><td>Edgebox Status</td><td><code>edgebox_status == Inactive</code> + XGBoost/BiLSTM classify</td><td><span class="sc-ai-note">AI prob &gt; 0.5</span></td><td><span class="sc-eq" style="color:#0891b2">Network</span></td></tr>
      <tr><td><span class="sc-id sc-ai">C08</span></td><td><span class="sc-tp sc-ai">AI</span></td><td>Router Internet</td><td><code>router_internet_status == Disconnected</code> + NETWORK_ISSUE class</td><td><span class="sc-ai-note">AI prob &gt; 0.5</span></td><td><span class="sc-eq" style="color:#0891b2">Network</span></td></tr>
      <tr><td><span class="sc-id sc-ai">C09</span></td><td><span class="sc-tp sc-ai">AI</span></td><td>Router Status</td><td><code>router_status == Inactive</code> + temporal pattern</td><td><span class="sc-ai-note">AI prob &gt; 0.5</span></td><td><span class="sc-eq" style="color:#0891b2">Network</span></td></tr>
      <tr><td><span class="sc-id sc-ai">C10</span></td><td><span class="sc-tp sc-ai">AI</span></td><td>RSSI Signal</td><td><code>RSSI == 0 or &gt; -10 dBm</code> + IF+LOF ensemble</td><td><span class="sc-ai-note">RSSI &lt; -70 weak</span></td><td><span class="sc-eq" style="color:#0891b2">Network</span></td></tr>
      <tr class="sc-grp"><td colspan="6">&#128268; PLC Controller Communication</td></tr>
      <tr><td><span class="sc-id sc-rl">C11</span></td><td><span class="sc-tp sc-rl">Rule</span></td><td>PLC1 Status</td><td><code>PLC1_status == Inactive</code></td><td><span class="sc-th">Inactive = Fault</span></td><td><span class="sc-eq" style="color:#7c3aed">PLC</span></td></tr>
      <tr><td><span class="sc-id sc-rl">C12</span></td><td><span class="sc-tp sc-rl">Rule</span></td><td>PLC2 Status</td><td><code>PLC2_status == Inactive</code></td><td><span class="sc-th">Inactive = Fault</span></td><td><span class="sc-eq" style="color:#7c3aed">PLC</span></td></tr>
      <tr class="sc-grp"><td colspan="6">&#128161; MDB / Energy Meter</td></tr>
      <tr><td><span class="sc-id sc-rl">C13</span></td><td><span class="sc-tp sc-rl">Rule</span></td><td>MDB Status</td><td><code>MDB_status == Inactive</code></td><td><span class="sc-th">Inactive = Offline</span></td><td><span class="sc-eq" style="color:#059669">MDB</span></td></tr>
      <tr><td><span class="sc-id sc-rl">C14</span></td><td><span class="sc-tp sc-rl">Rule</span></td><td>Energy Meter</td><td><code>energy_meter_status == Inactive</code></td><td><span class="sc-th">Inactive = Fault</span></td><td><span class="sc-eq" style="color:#059669">MDB</span></td></tr>
      <tr class="sc-grp"><td colspan="6">&#127777; Thermal Monitoring</td></tr>
      <tr><td><span class="sc-id sc-ai">C15</span></td><td><span class="sc-tp sc-ai">AI</span></td><td>Edgebox Temp</td><td><code>edgebox_temp &lt; 30°C → shutdown indication</code></td><td><span class="sc-ai-note">Drop &lt; 30°C</span></td><td><span class="sc-eq" style="color:#dc2626">Thermal</span></td></tr>
      <tr><td><span class="sc-id sc-ai">C16</span></td><td><span class="sc-tp sc-ai">AI</span></td><td>Pi5 Temp</td><td><code>pi5_temp &gt; 80°C → throttle risk</code></td><td><span class="sc-ai-note">&gt; 80°C throttle</span></td><td><span class="sc-eq" style="color:#dc2626">Thermal</span></td></tr>
      <tr><td><span class="sc-id sc-ai">C17</span></td><td><span class="sc-tp sc-ai">AI</span></td><td>Charger Ambient</td><td><code>charger_temp &gt; 55°C → derating</code></td><td><span class="sc-ai-note">&gt; 55°C derating</span></td><td><span class="sc-eq" style="color:#dc2626">Thermal</span></td></tr>
    </tbody>
  </table>
  </div>
</div>
</div><!-- /m3CondPanel -->

</div></div><!-- /m3tab-main -->

<!-- TAB 2: Historical Graph -->
<div class="tc" id="m3tab-history"><div class="pg">

<!-- ═══ HISTORICAL GRAPH ═══ -->
<div class="cd cd-cy stg" style="margin-top:14px">
  <h2><span data-i18n="m3_hist_h">📈 Historical Graph — Charger Offline Monitoring</span></h2>
  <p data-i18n="m3_hist_p">Visualize historical charger offline monitoring data from MongoDB. Select a time range and field group to plot.</p>
</div>

<div class="cd cd-cy stg" style="animation-delay:.05s">
  <div class="ct"><i>⚙</i> <span data-i18n="m3_hist_ctrl">Controls</span></div>
  <div class="hist-controls">
    <div class="hist-group">
      <label data-i18n="hist_range">Time Range</label>
      <div class="hist-btns" id="m3HistRange">
        <button class="hist-btn on" onclick="m3SetHistRange('daily',this)" data-i18n="hist_daily">Daily</button>
        <button class="hist-btn" onclick="m3SetHistRange('weekly',this)" data-i18n="hist_weekly">Weekly</button>
        <button class="hist-btn" onclick="m3SetHistRange('monthly',this)" data-i18n="hist_monthly">Monthly</button>
        <button class="hist-btn" onclick="m3SetHistRange('custom',this)" data-i18n="hist_custom">Custom</button>
      </div>
    </div>
    <div class="hist-group hist-custom-range" id="m3HistCustom" style="display:none">
      <label data-i18n="hist_start">Start</label>
      <input type="datetime-local" id="m3HistStart" class="hist-dt">
    </div>
    <div class="hist-group hist-custom-range" id="m3HistCustom2" style="display:none">
      <label data-i18n="hist_end">End</label>
      <input type="datetime-local" id="m3HistEnd" class="hist-dt">
    </div>
    <div class="hist-group">
      <label data-i18n="hist_fields">Field Group</label>
      <div class="hist-btns" id="m3HistFields">
        <button class="hist-btn on" onclick="m3SetHistField('ac_voltage',this)">AC Voltage</button>
        <button class="hist-btn" onclick="m3SetHistField('ac_current',this)">AC Current</button>
        <button class="hist-btn" onclick="m3SetHistField('temperature',this)">Temperature</button>
        <button class="hist-btn" onclick="m3SetHistField('signal',this)">Signal</button>
        <button class="hist-btn" onclick="m3SetHistField('energy',this)">Energy</button>
      </div>
    </div>
    <button class="bt bgh" style="padding:8px 22px;font-size:.72em;align-self:flex-end" onclick="m3LoadHistory()">🔍 <span data-i18n="hist_load">Load Data</span></button>
  </div>
</div>

<div class="cd cd-am stg" style="animation-delay:.1s">
  <div class="hist-chart-head">
    <div class="ct" style="margin-bottom:0"><i>📈</i> <span id="m3HistChartTitle" data-i18n="hist_chart">Chart</span></div>
    <div class="hist-info" id="m3HistInfo"></div>
  </div>
  <div class="hist-chart-wrap">
    <canvas id="m3HistCanvas"></canvas>
  </div>
  <div class="hist-loading" id="m3HistLoading" style="display:none">
    <div class="hist-spinner"></div>
    <span data-i18n="hist_loading">Loading data…</span>
  </div>
  <div class="hist-empty" id="m3HistEmpty" data-i18n="hist_empty">Select a field group and click "Load Data" to view the chart.</div>
</div>

<div class="cd cd-gn stg" style="animation-delay:.15s">
  <div class="ct"><i>📊</i> <span data-i18n="hist_stats">Statistics</span></div>
  <div id="m3HistStats" class="hist-stats">
    <div style="color:var(--dim);font-size:.8em;text-align:center;padding:20px;font-style:italic" data-i18n="hist_stats_empty">Statistics will appear after loading data.</div>
  </div>
</div>

</div></div><!-- /m3tab-history -->

<!-- TAB 3: Algorithm Description -->
<div class="tc" id="m3tab-algos"><div class="pg">

<div class="ra-intro stg">
  <h2>📖 <span data-i18n="m3_algo_h">Charger Offline Detection — Algorithm Description</span></h2>
  <p data-i18n="m3_algo_p">Module 3 uses a multi-layered detection system combining 6 AI Models, 4 Rule-Based checks, and 6 Hybrid conditions to diagnose root causes of charger offline events across 5 equipment groups.</p>
  <div class="ra-flow">
    <span class="ra-flow-step" style="background:var(--cyg);color:var(--cy)">📡 MongoDB Telemetry</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:rgba(14,165,233,.08);color:#0ea5e9">🧠 6 AI Models</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:rgba(217,119,6,.08);color:#d97706">⚖️ 6 Hybrid Conditions</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:rgba(100,116,139,.08);color:#64748b">📏 4 Rule-Only Checks</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--rdg);color:var(--rd)">🎯 Root Cause</span>
  </div>
</div>

<!-- ═══ SECTION 1: AI MODELS ═══ -->
<div class="cd cd-cy stg" style="animation-delay:.03s;margin-bottom:8px">
  <div class="ct"><i>🧠</i> AI Models — 6 Models across 3 Detection Strategies</div>
</div>

<div class="ra-card cd-cy stg" style="animation-delay:.06s"><div class="ra-num">A</div><div class="ra-head"><div class="ra-icon" style="background:rgba(14,165,233,.1);color:#0ea5e9">🎯</div><div><div class="ra-title" style="color:#0ea5e9">XGBoost Multi-Class Root Cause Classifier<span class="ra-id" style="background:rgba(14,165,233,.1);color:#0ea5e9">ML</span><span class="ra-severity" style="background:var(--cyg);color:var(--cy)">Classification</span></div></div></div>
<div class="ra-desc">Gradient-boosted decision tree ensemble trained on labeled offline episodes. Receives 60+ engineered features (rolling statistics, rate-of-change, cross-sensor ratios) and outputs a 5-class probability distribution: <strong>NORMAL</strong>, <strong>POWER_OUTAGE</strong>, <strong>EDGEBOX_FAILURE</strong>, <strong>NETWORK_ISSUE</strong>, <strong>PLC_FAULT</strong>. Uses SMOTE oversampling to handle class imbalance (99.7% normal vs 0.3% fault).</div>
<div class="ra-logic" style="background:rgba(14,165,233,.04)">
  <div class="ra-logic-title">💡 Detection Logic</div>
  <div class="ra-code"><span class="kw">INPUT</span>  60+ features (VL1N, I1, temps, RSSI, rolling_mean/std, rate_of_change...)
<span class="kw">MODEL</span>  XGBClassifier(n_estimators=500, max_depth=8, learning_rate=0.05)
<span class="kw">OUTPUT</span> class_probabilities[5] → argmax = root_cause
<span class="kw">IF</span> max_prob &gt; <span class="val">0.8</span> → <span style="color:var(--rd);font-weight:700">HIGH CONFIDENCE</span>
<span class="kw">IF</span> max_prob &gt; <span class="val">0.5</span> → <span style="color:var(--am);font-weight:700">MODERATE</span>
<span class="kw">ELSE</span>            → NORMAL</div>
</div>
<div class="ra-mqtt"><div class="ra-mqtt-title">📊 Key Features Used</div><div class="ra-keys">
  <span class="ra-key" style="background:rgba(14,165,233,.08)"><span class="ra-key-name">VL1N/VL2N/VL3N_MDB</span><span class="ra-key-type">float</span></span>
  <span class="ra-key" style="background:rgba(14,165,233,.08)"><span class="ra-key-name">I1/I2/I3_MDB</span><span class="ra-key-type">float</span></span>
  <span class="ra-key" style="background:rgba(14,165,233,.08)"><span class="ra-key-name">edgebox/router_status</span><span class="ra-key-type">str</span></span>
  <span class="ra-key" style="background:rgba(14,165,233,.08)"><span class="ra-key-name">RSSI</span><span class="ra-key-type">int</span></span>
  <span class="ra-key" style="background:rgba(14,165,233,.08)"><span class="ra-key-name">rolling_mean_*</span><span class="ra-key-type">float</span></span>
  <span class="ra-key" style="background:rgba(14,165,233,.08)"><span class="ra-key-name">rate_of_change_*</span><span class="ra-key-type">float</span></span>
</div></div></div>

<div class="ra-card cd-pu stg" style="animation-delay:.09s"><div class="ra-num">A2</div><div class="ra-head"><div class="ra-icon" style="background:rgba(168,85,247,.1);color:#a855f7">🎯</div><div><div class="ra-title" style="color:#a855f7">DNN Multi-Class Root Cause Classifier<span class="ra-id" style="background:rgba(168,85,247,.1);color:#a855f7">DL</span><span class="ra-severity" style="background:var(--cyg);color:var(--cy)">Classification</span></div></div></div>
<div class="ra-desc">Deep Neural Network with 4 hidden layers (512→256→128→64), BatchNorm, Dropout (0.3), and GELU activation. Acts as a <strong>verification model</strong> for Model A — when both classifiers agree, confidence is higher. If they disagree, the system flags for manual review. Trained with StratifiedKFold cross-validation.</div>
<div class="ra-logic" style="background:rgba(168,85,247,.04)">
  <div class="ra-logic-title">💡 Architecture</div>
  <div class="ra-code"><span class="kw">INPUT</span>  60+ features → Dense(512) → BN → GELU → Dropout(0.3)
                   → Dense(256) → BN → GELU → Dropout(0.3)
                   → Dense(128) → BN → GELU → Dropout(0.2)
                   → Dense(64)  → BN → GELU
<span class="kw">OUTPUT</span> Dense(5) → Softmax → class_probabilities[5]
<span class="kw">CONSENSUS</span> Model A ∩ A2 agree → <span style="color:var(--gn);font-weight:700">HIGH CONFIDENCE</span>
         Model A ≠ A2       → <span style="color:var(--am);font-weight:700">FLAG FOR REVIEW</span></div>
</div></div>

<div class="ra-card cd-am stg" style="animation-delay:.12s"><div class="ra-num">B</div><div class="ra-head"><div class="ra-icon" style="background:rgba(217,119,6,.1);color:#d97706">⏱️</div><div><div class="ra-title" style="color:#d97706">XGBoost Early Warning (~2 min Forecast)<span class="ra-id" style="background:rgba(14,165,233,.1);color:#0ea5e9">ML</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">Early Warning</span></div></div></div>
<div class="ra-desc">Binary classifier that predicts whether an offline event will occur within the <strong>next ~2 minutes</strong> (120 seconds). Uses time-shifted labels: for each fault episode, the 30 rows (~120s) before the fault are labeled as "pre-fault". Features include rate-of-change, rolling variance, recent fault tracking, and cross-sensor correlation to detect degradation patterns before they escalate.</div>
<div class="ra-logic" style="background:rgba(217,119,6,.04)">
  <div class="ra-logic-title">💡 Detection Logic</div>
  <div class="ra-code"><span class="kw">LABEL</span>  30 rows before each fault episode → <span class="val">PRE_FAULT = 1</span>
<span class="kw">FEATURES</span> rate_of_change(V, I, temp), rolling_std(30s), RSSI_gradient
<span class="kw">MODEL</span>  XGBClassifier(binary, n_estimators=500)
<span class="kw">OUTPUT</span> probability [0.0 ~ 1.0]
<span class="kw">IF</span> probability &gt; <span class="val">0.5</span> → <span style="color:var(--am);font-weight:700">⚠️ WARNING: Offline likely in ~2 min</span>
<span class="kw">IF</span> probability &lt; <span class="val">0.1</span> → <span style="color:var(--gn);font-weight:700">🟢 CLEAR</span></div>
</div>
<div class="ra-example" style="background:rgba(217,119,6,.05);border-left:3px solid rgba(217,119,6,.4)">
  <div class="ra-example-title">📌 Example</div>
  VL1N dropping: 231→228→220V over 60s, RSSI degrading: -40→-55→-68 dBm<br>
  → Early Warning probability = <strong>0.73</strong> → ⚠️ Pre-fault signal detected, offline predicted in ~2 min
</div></div>

<div class="ra-card cd-pk stg" style="animation-delay:.15s"><div class="ra-num">C</div><div class="ra-head"><div class="ra-icon" style="background:rgba(168,85,247,.1);color:#a855f7">🔍</div><div><div class="ra-title" style="color:#a855f7">Autoencoder Anomaly Detector<span class="ra-id" style="background:rgba(168,85,247,.1);color:#a855f7">DL</span><span class="ra-severity" style="background:rgba(139,92,246,.1);color:#8b5cf6">Anomaly Detection</span></div></div></div>
<div class="ra-desc">Unsupervised deep autoencoder (Encoder: 512→256→128→64→16, Decoder: 16→64→128→256→512) trained exclusively on <strong>NORMAL</strong> data. During inference, it tries to reconstruct the input — high reconstruction error (MSE) indicates anomaly. Thresholds are set at statistical percentiles: P95 = WATCH, P99 = WARNING, P99.9 = CRITICAL.</div>
<div class="ra-logic" style="background:rgba(168,85,247,.04)">
  <div class="ra-logic-title">💡 Detection Logic</div>
  <div class="ra-code"><span class="kw">TRAIN</span>   Only on NORMAL samples → learns "normal" pattern
<span class="kw">ENCODE</span>  Input(60) → 512 → 256 → 128 → 64 → <span class="val">Latent(16)</span>
<span class="kw">DECODE</span>  Latent(16) → 64 → 128 → 256 → 512 → Reconstructed(60)
<span class="kw">SCORE</span>   MSE = mean((input - reconstructed)²)
<span class="kw">IF</span> MSE &gt; <span class="val">P99.9</span> → <span style="color:var(--rd);font-weight:700">CRITICAL</span>  <span class="cmt">// Severe anomaly</span>
<span class="kw">IF</span> MSE &gt; <span class="val">P99</span>   → <span style="color:var(--am);font-weight:700">WARNING</span>   <span class="cmt">// Moderate anomaly</span>
<span class="kw">IF</span> MSE &gt; <span class="val">P95</span>   → <span style="color:#0ea5e9;font-weight:700">WATCH</span>     <span class="cmt">// Borderline</span>
<span class="kw">ELSE</span>            → NORMAL</div>
</div></div>

<div class="ra-card cd-tl stg" style="animation-delay:.18s"><div class="ra-num">D</div><div class="ra-head"><div class="ra-icon" style="background:rgba(168,85,247,.1);color:#a855f7">🔍</div><div><div class="ra-title" style="color:#a855f7">BiLSTM-Attention Temporal Anomaly<span class="ra-id" style="background:rgba(168,85,247,.1);color:#a855f7">DL</span><span class="ra-severity" style="background:rgba(139,92,246,.1);color:#8b5cf6">Anomaly Detection</span></div></div></div>
<div class="ra-desc">Bidirectional LSTM with Multi-Head Attention mechanism. Processes <strong>temporal sequences</strong> (sliding window of recent readings) to detect anomalies that only manifest over time — such as gradual signal degradation, slow temperature rise, or intermittent connectivity. The attention layer highlights which time steps contribute most to the anomaly score.</div>
<div class="ra-logic" style="background:rgba(13,148,136,.04)">
  <div class="ra-logic-title">💡 Architecture</div>
  <div class="ra-code"><span class="kw">INPUT</span>   Sequence[T×60] (sliding window of T timesteps)
<span class="kw">PROJ</span>    Linear(60 → 256) → LayerNorm → GELU
<span class="kw">LSTM</span>    BiLSTM(256, 3 layers, bidirectional) → output[T×512]
<span class="kw">ATTN</span>    MultiHeadAttention(512, 8 heads) → weighted context
<span class="kw">POOL</span>    AdaptiveAvgPool → Dense(256) → Dense(128)
<span class="kw">OUTPUT</span>  anomaly_score [0.0 ~ 1.0]
<span class="kw">IF</span> score &gt; <span class="val">0.7</span> → <span style="color:var(--rd);font-weight:700">ALARM</span>
<span class="kw">IF</span> score &gt; <span class="val">0.5</span> → <span style="color:var(--am);font-weight:700">WARN</span></div>
</div></div>

<div class="ra-card cd-gn stg" style="animation-delay:.21s"><div class="ra-num">E</div><div class="ra-head"><div class="ra-icon" style="background:rgba(14,165,233,.1);color:#0ea5e9">🔍</div><div><div class="ra-title" style="color:#0ea5e9">Isolation Forest + LOF Ensemble<span class="ra-id" style="background:rgba(14,165,233,.1);color:#0ea5e9">ML</span><span class="ra-severity" style="background:rgba(139,92,246,.1);color:#8b5cf6">Anomaly Detection</span></div></div></div>
<div class="ra-desc">Combines two complementary unsupervised algorithms: <strong>Isolation Forest</strong> (detects global outliers by random partitioning — anomalies require fewer splits) and <strong>Local Outlier Factor</strong> (detects local density anomalies — points in sparse neighborhoods). The ensemble averages both scores for robust multi-perspective anomaly detection.</div>
<div class="ra-logic" style="background:rgba(5,150,105,.04)">
  <div class="ra-logic-title">💡 Detection Logic</div>
  <div class="ra-code"><span class="kw">IF_SCORE</span>  IsolationForest(contamination=0.01).decision_function(X)
<span class="kw">LOF_SCORE</span> LocalOutlierFactor(n_neighbors=20).decision_function(X)
<span class="kw">ENSEMBLE</span>  score = (normalize(IF) + normalize(LOF)) / 2
<span class="kw">IF</span> score &gt; <span class="val">0.7</span> → <span style="color:var(--rd);font-weight:700">ALARM</span>  <span class="cmt">// Both methods agree</span>
<span class="kw">IF</span> score &gt; <span class="val">0.5</span> → <span style="color:var(--am);font-weight:700">WARN</span>   <span class="cmt">// One method flags</span></div>
</div></div>

<!-- ═══ SECTION 2: HYBRID CONDITIONS ═══ -->
<div class="cd cd-am stg" style="animation-delay:.24s;margin-bottom:8px;margin-top:14px">
  <div class="ct"><i>⚖️</i> Hybrid Conditions — Rule + AI Early Warning (C01–C06)</div>
  <p style="font-size:.72em;color:var(--dim);margin:6px 0 0">These conditions use a <strong>Rule threshold as safety guardrail</strong> (hard alarm) combined with <strong>AI models for pattern recognition</strong> and root-cause classification. If AI detects degradation before the rule triggers, it provides early warning.</p>
</div>

<div class="ra-card cd-am stg" style="animation-delay:.27s"><div class="ra-num" style="background:rgba(217,119,6,.08);color:#d97706">H</div><div class="ra-head"><div class="ra-icon" style="background:rgba(217,119,6,.1);color:#d97706">⚡</div><div><div class="ra-title" style="color:#d97706">AC Power Supply Monitoring (C01–C06)<span class="ra-id" style="background:rgba(217,119,6,.1);color:#d97706">Hybrid</span><span class="ra-severity" style="background:var(--rdg);color:var(--rd)">CRITICAL</span></div></div></div>
<div class="ra-desc">Monitors 3-phase AC voltage (VL1N, VL2N, VL3N) and current (I1, I2, I3) from the MDB. The <strong>Rule layer</strong> triggers immediate alarm when voltage drops to 0V (complete power outage). The <strong>AI layer</strong> (XGBoost + DNN) classifies the root cause as POWER_OUTAGE and provides probability scores, while Early Warning Model B detects degradation patterns before complete outage.</div>
<div class="ra-logic" style="background:rgba(217,119,6,.04)">
  <div class="ra-logic-title">💡 Hybrid Logic</div>
  <div class="ra-code"><span style="color:#64748b;font-weight:700">━━━ RULE LAYER (Immediate) ━━━</span>
<span class="kw">IF</span> VL1N_MDB == <span class="val">0</span> → <span style="color:var(--rd);font-weight:700">ALARM: Phase A Power Outage</span>
<span class="kw">IF</span> I1_MDB == <span class="val">0</span> <span class="kw">AND</span> VL1N_MDB &gt; <span class="val">0</span> → <span style="color:var(--am);font-weight:700">WARN: Current Off</span>

<span style="color:#0ea5e9;font-weight:700">━━━ AI LAYER (Pattern Recognition) ━━━</span>
<span class="kw">MODEL A</span>  XGBoost → P(POWER_OUTAGE) = <span class="val">0.92</span>  <span class="cmt">// Root cause</span>
<span class="kw">MODEL A2</span> DNN     → P(POWER_OUTAGE) = <span class="val">0.88</span>  <span class="cmt">// Verification</span>
<span class="kw">MODEL B</span>  EarlyWarn → P(offline) = <span class="val">0.73</span>    <span class="cmt">// 2 min warning</span>
<span class="kw">MODEL C</span>  Autoencoder → MSE = <span class="val">0.042</span>       <span class="cmt">// Anomaly score</span></div>
</div>
<div class="ra-mqtt"><div class="ra-mqtt-title">📡 MongoDB Keys — <code>module3ChargerOfflineAnalysis.F1500624011</code></div><div class="ra-keys">
  <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">VL1N_MDB</span><span class="ra-key-type">float V</span></span>
  <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">VL2N_MDB</span><span class="ra-key-type">float V</span></span>
  <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">VL3N_MDB</span><span class="ra-key-type">float V</span></span>
  <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">I1_MDB</span><span class="ra-key-type">float A</span></span>
  <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">I2_MDB</span><span class="ra-key-type">float A</span></span>
  <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">I3_MDB</span><span class="ra-key-type">float A</span></span>
</div></div></div>

<!-- ═══ SECTION 3: AI-ONLY CONDITIONS ═══ -->
<div class="cd cd-cy stg" style="animation-delay:.3s;margin-bottom:8px;margin-top:14px">
  <div class="ct"><i>🧠</i> AI-Only Conditions — Pattern Recognition (C07–C10, C15–C17)</div>
  <p style="font-size:.72em;color:var(--dim);margin:6px 0 0">These conditions rely <strong>purely on AI</strong> for detection because simple thresholds cannot capture complex degradation patterns. The AI models analyze temporal patterns, cross-sensor correlations, and learned normal behavior to identify anomalies.</p>
</div>

<div class="ra-card cd-cy stg" style="animation-delay:.33s"><div class="ra-num" style="background:rgba(8,145,178,.08);color:#0891b2">AI</div><div class="ra-head"><div class="ra-icon" style="background:rgba(8,145,178,.1);color:#0891b2">📡</div><div><div class="ra-title" style="color:#0891b2">Network / EdgeBox Connectivity (C07–C10)<span class="ra-id" style="background:rgba(8,145,178,.1);color:#0891b2">AI-Only</span><span class="ra-severity" style="background:var(--rdg);color:var(--rd)">CRITICAL</span></div></div></div>
<div class="ra-desc">AI detects network degradation patterns that precede complete connectivity loss. The Autoencoder and BiLSTM detect gradual RSSI weakening, intermittent EdgeBox status changes, and router disconnection patterns. XGBoost classifies root cause as EDGEBOX_FAILURE or NETWORK_ISSUE.</div>
<div class="ra-logic" style="background:rgba(8,145,178,.04)">
  <div class="ra-logic-title">💡 AI Detection</div>
  <div class="ra-code"><span class="kw">C07</span> edgebox_status → XGBoost P(EDGEBOX_FAILURE) + BiLSTM temporal
<span class="kw">C08</span> router_internet_status → XGBoost P(NETWORK_ISSUE)
<span class="kw">C09</span> router_status → temporal pattern (intermittent vs permanent)
<span class="kw">C10</span> RSSI signal → IF+LOF detects unusual signal strength patterns
     <span class="cmt">// RSSI gradually -40 → -55 → -70 dBm = degradation</span>
     <span class="cmt">// Sudden RSSI = 0 = EdgeBox power failure</span></div>
</div></div>

<div class="ra-card cd-rd stg" style="animation-delay:.36s"><div class="ra-num" style="background:rgba(220,38,38,.08);color:#dc2626">AI</div><div class="ra-head"><div class="ra-icon" style="background:rgba(220,38,38,.1);color:#dc2626">🌡</div><div><div class="ra-title" style="color:#dc2626">Thermal Monitoring (C15–C17)<span class="ra-id" style="background:rgba(220,38,38,.1);color:#dc2626">AI-Only</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span></div></div></div>
<div class="ra-desc">AI monitors thermal patterns across EdgeBox, Pi5, and charger ambient temperatures. The Autoencoder learns normal thermal profiles (diurnal cycles, load-dependent heating), and the BiLSTM detects abnormal temperature trajectories. A sudden temperature drop (EdgeBox < 30°C) can indicate power loss to the device.</div>
<div class="ra-logic" style="background:rgba(220,38,38,.04)">
  <div class="ra-logic-title">💡 AI Detection</div>
  <div class="ra-code"><span class="kw">C15</span> edgebox_temp &lt; <span class="val">30°C</span>  → shutdown indication (no self-heating)
<span class="kw">C16</span> pi5_temp &gt; <span class="val">80°C</span>     → CPU thermal throttle risk
<span class="kw">C17</span> charger_temp &gt; <span class="val">55°C</span> → ambient derating begins
     Autoencoder: learns normal temp profile per time-of-day
     BiLSTM: detects abnormal rate-of-rise patterns</div>
</div></div>

<!-- ═══ SECTION 4: RULE-ONLY CONDITIONS ═══ -->
<div class="cd cd-sl stg" style="animation-delay:.39s;margin-bottom:8px;margin-top:14px">
  <div class="ct"><i>📏</i> Rule-Only Conditions — Binary Status Checks (C11–C14)</div>
  <p style="font-size:.72em;color:var(--dim);margin:6px 0 0">These conditions use <strong>simple binary status checks</strong> only. The equipment either reports "Active" or "Inactive" — no gradient or pattern to detect, making AI unnecessary. Immediate alarm on status change.</p>
</div>

<div class="ra-card cd-sl stg" style="animation-delay:.42s"><div class="ra-num" style="background:rgba(100,116,139,.08);color:#64748b">R</div><div class="ra-head"><div class="ra-icon" style="background:rgba(124,58,237,.1);color:#7c3aed">🔌</div><div><div class="ra-title" style="color:#7c3aed">PLC Controller Status (C11–C12)<span class="ra-id" style="background:rgba(100,116,139,.1);color:#64748b">Rule-Only</span><span class="ra-severity" style="background:var(--rdg);color:var(--rd)">CRITICAL</span></div></div></div>
<div class="ra-desc">Monitors PLC1 and PLC2 communication status. PLCs are the primary controllers interfacing between the charger hardware and the OCPP backend. If either goes Inactive, the charger loses its control plane and cannot operate.</div>
<div class="ra-logic" style="background:rgba(100,116,139,.04)">
  <div class="ra-logic-title">💡 Rule Logic</div>
  <div class="ra-code"><span class="kw">C11</span> <span class="kw">IF</span> PLC1_status == <span class="val">"Inactive"</span> → <span style="color:var(--rd);font-weight:700">ALARM: PLC1 Fault</span>
<span class="kw">C12</span> <span class="kw">IF</span> PLC2_status == <span class="val">"Inactive"</span> → <span style="color:var(--rd);font-weight:700">ALARM: PLC2 Fault</span>
     <span class="cmt">// Binary check — no AI needed</span></div>
</div></div>

<div class="ra-card cd-sl stg" style="animation-delay:.45s"><div class="ra-num" style="background:rgba(100,116,139,.08);color:#64748b">R</div><div class="ra-head"><div class="ra-icon" style="background:rgba(5,150,105,.1);color:#059669">💡</div><div><div class="ra-title" style="color:#059669">MDB / Energy Meter Status (C13–C14)<span class="ra-id" style="background:rgba(100,116,139,.1);color:#64748b">Rule-Only</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span></div></div></div>
<div class="ra-desc">Monitors the Main Distribution Board (MDB) and Energy Meter connectivity. MDB offline means the charger has lost its AC power measurement capability. Energy Meter offline means cumulative kWh readings are no longer available for billing and monitoring.</div>
<div class="ra-logic" style="background:rgba(100,116,139,.04)">
  <div class="ra-logic-title">💡 Rule Logic</div>
  <div class="ra-code"><span class="kw">C13</span> <span class="kw">IF</span> MDB_status == <span class="val">"Inactive"</span> → <span style="color:var(--rd);font-weight:700">ALARM: MDB Offline</span>
<span class="kw">C14</span> <span class="kw">IF</span> energy_meter_status == <span class="val">"Inactive"</span> → <span style="color:var(--am);font-weight:700">WARN: Meter Fault</span>
     <span class="cmt">// Binary check — no AI needed</span></div>
</div></div>

</div></div><!-- /m3tab-algos -->

<!-- TAB 4: Detection Output -->
<div class="tc" id="m3tab-output"><div class="pg">

<div class="cd cd-cy stg">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>📊</i> <span data-i18n="m3_do_h">Detection Output — Charger Offline Monitoring</span></span>
    <div style="display:flex;align-items:center;gap:8px">
      <span class="do-ts" id="m3DoTs">—</span>
      <button class="bt bgh" style="padding:4px 14px;font-size:.65em" onclick="m3DoRefresh()">🔄 <span data-i18n="do_refresh">Refresh</span></button>
    </div>
  </div>
</div>

<div class="do-sum stg" id="m3DoSum" style="animation-delay:.03s">
  <div class="do-chip do-chip-ok"><span style="width:8px;height:8px;border-radius:50%;background:#16a34a;display:inline-block"></span> <span id="m3DoOk">0</span> OK</div>
  <div class="do-chip do-chip-warn"><span style="width:8px;height:8px;border-radius:50%;background:#d97706;display:inline-block"></span> <span id="m3DoWn">0</span> WARNING</div>
  <div class="do-chip do-chip-alarm"><span style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block"></span> <span id="m3DoAl">0</span> ALARM</div>
  <div style="margin-left:auto;font-size:.72em;color:var(--dim);font-family:'JetBrains Mono'">Total: <b>17</b> conditions</div>
</div>

<div class="cd cd-cy stg" style="animation-delay:.06s;padding:0">
<div class="do-wrap">
<table class="do-tbl" id="m3DoTbl">
  <thead><tr>
    <th style="width:36px">#</th>
    <th style="width:56px">Type</th>
    <th style="width:140px">Condition</th>
    <th style="width:85px">Equipment</th>
    <th style="width:100px">Input Value</th>
    <th style="width:160px">Rule Output</th>
    <th style="width:180px">AI Output</th>
    <th style="width:70px">Status</th>
  </tr></thead>
  <tbody id="m3DoBody">
    <tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data…</td></tr>
  </tbody>
</table>
</div>
</div>

</div></div><!-- /m3tab-output -->

</div><!-- /pageMod3 -->

<!-- ═══════════ MODULE 4 PAGE ═══════════ -->
<div id="pageMod4" style="display:none">
<div class="tbs">
  <div class="tb on" onclick="stab('monitor')" data-i18n="tab2">&#9889; Live Monitor</div>
  <div class="tb" onclick="stab('manual')" data-i18n="tab1">&#129302; AI-Module Detection</div>
  <div class="tb" onclick="stab('mqtt')" data-i18n="tab3">&#128752; Rule Based Algorithm</div>
  <div class="tb" onclick="stab('reference')" data-i18n="tab4">&#128218; Standards Reference</div>
  <div class="tb" onclick="stab('rules')" data-i18n="tab5">&#128220; Rule-Based Algorithms Description</div>
  <div class="tb" onclick="stab('history')" data-i18n="tab6">&#128200; Historical Graph</div>
  <div class="tb" onclick="stab('output')" data-i18n="tab7">📊 Detection Output</div>
</div>

<!-- ═══ TAB 1 ═══ -->
<div class="tc" id="tab-manual"><div class="pg">

<!-- ═══ CHARGER STATE SEQUENCE ═══ -->
<div class="m3-load-panel collapsed" id="m4SqPanel">
  <div class="m3-load-hdr" onclick="document.getElementById('m4SqPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>&#128260;</i> <span data-i18n="seq_title">Charger State Sequence — Real-Time Protocol Monitor</span></div>
    <div class="m3-load-hdr-r"><span class="m3-load-toggle">▼</span></div>
  </div>
<div class="cd cd-compact sq-card" style="border-left:none;margin:0;border:none;background:transparent;box-shadow:none;padding:0">
  <div class="sq-panels">

  <!-- Connector 1 -->
  <div class="sq-panel" data-cn="1">
    <div class="sq-hud">
      <div class="sq-hud-left">
        <span class="sq-badge">&#9671; HEAD 1</span>
        <span class="sq-phase" id="sqPhase1" style="color:var(--dim);border-color:var(--bdr);background:var(--glass)">IDLE</span>
      </div>
      <div class="sq-hud-right">
        <div class="sq-readout"><span class="sq-readout-label">ICP</span><span class="sq-readout-val" id="sqIcpTxt1" style="color:var(--dim)">&mdash;</span></div>
        <div class="sq-readout"><span class="sq-readout-label">USL</span><span class="sq-readout-val" id="sqUslTxt1" style="color:var(--dim)">&mdash;</span></div>
        <div class="sq-signal" id="sqSig1"></div>
      </div>
    </div>
    <div class="sq-progress"><div class="sq-progress-fill" id="sqProg1" style="width:0%"></div></div>
    <div class="sq-tracks">
      <div class="sq-col"><div class="sq-col-head">&#9889; ICP State</div><div class="sq-track" id="sqIcp1"></div></div>
      <div class="sq-col"><div class="sq-col-head">&#128279; USLink State</div><div class="sq-track" id="sqUsl1"></div></div>
    </div>
    <div class="sq-desc" id="sqDesc1"></div>
  </div>

  <!-- Connector 2 -->
  <div class="sq-panel" data-cn="2">
    <div class="sq-hud">
      <div class="sq-hud-left">
        <span class="sq-badge">&#9671; HEAD 2</span>
        <span class="sq-phase" id="sqPhase2" style="color:var(--dim);border-color:var(--bdr);background:var(--glass)">IDLE</span>
      </div>
      <div class="sq-hud-right">
        <div class="sq-readout"><span class="sq-readout-label">ICP</span><span class="sq-readout-val" id="sqIcpTxt2" style="color:var(--dim)">&mdash;</span></div>
        <div class="sq-readout"><span class="sq-readout-label">USL</span><span class="sq-readout-val" id="sqUslTxt2" style="color:var(--dim)">&mdash;</span></div>
        <div class="sq-signal" id="sqSig2"></div>
      </div>
    </div>
    <div class="sq-progress"><div class="sq-progress-fill" id="sqProg2" style="width:0%"></div></div>
    <div class="sq-tracks">
      <div class="sq-col"><div class="sq-col-head">&#9889; ICP State</div><div class="sq-track" id="sqIcp2"></div></div>
      <div class="sq-col"><div class="sq-col-head">&#128279; USLink State</div><div class="sq-track" id="sqUsl2"></div></div>
    </div>
    <div class="sq-desc" id="sqDesc2"></div>
  </div>

  </div>
</div>
</div><!-- /m4SqPanel -->

<!-- ═══ HIDDEN INPUTS for PREDICT function ═══ -->
<div style="display:none">
  <input id="target_voltage1" value="0"><input id="present_voltage1" value="0">
  <input id="target_current1" value="0"><input id="present_current1" value="0">
  <input id="target_voltage2" value="0"><input id="present_voltage2" value="0">
  <input id="target_current2" value="0"><input id="present_current2" value="0">
  <input id="SOC" value="0">
  <input id="power_module_temp1" value="0"><input id="power_module_temp2" value="0">
  <input id="power_module_temp3" value="0"><input id="power_module_temp4" value="0">
  <input id="power_module_temp5" value="0"><input id="charger_temp" value="0">
  <input id="charger_gun_temp_plus1" value="0"><input id="charger_gun_temp_plus2" value="0">
  <input id="charger_gun_temp_minus1" value="0"><input id="charger_gun_temp_minus2" value="0">
  <input id="power_module_status1" value="1"><input id="power_module_status2" value="1">
  <input id="power_module_status3" value="1"><input id="power_module_status4" value="1">
  <input id="power_module_status5" value="1">
  <input id="PLC1_status" value="1"><input id="PLC2_status" value="1">
  <input id="humidity" value="0"><input id="edgebox_temp" value="0">
  <input id="hour" value="0"><input id="minute" value="0">
  <input id="day_of_month" value="1"><input id="mouth_of_year" value="1">
  <input id="energy_meter_status" value="1">
</div>


<!-- ═══ STANDARD CONDITION TABLE ═══ -->
<div class="m3-load-panel collapsed" id="m4StdPanel">
  <div class="m3-load-hdr" onclick="document.getElementById('m4StdPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>&#128218;</i> <span data-i18n="std_cond">Standard Condition Reference</span></div>
    <div class="m3-load-hdr-r"><span class="m3-load-toggle">▼</span></div>
  </div>
<div class="cd cd-sl" style="margin-bottom:0;border:none;background:transparent;box-shadow:none;padding:0">
  <div style="overflow-x:auto">
  <table class="sc-tbl">
    <thead>
      <tr>
        <th style="width:36px">#</th>
        <th style="width:56px">Type</th>
        <th style="width:150px">Condition</th>
        <th>Detection Rule</th>
        <th style="width:110px">Threshold</th>
        <th>Standard / Reference</th>
        <th style="width:120px">Equipment</th>
      </tr>
    </thead>
    <tbody>
      <tr class="sc-grp"><td colspan="7">&#9889; Voltage / Current Anomalies</td></tr>
      <tr>
        <td><span class="sc-id sc-hy">C01</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Voltage Anomaly H1</td>
        <td><code>|target_V1 &minus; present_V1| / target_V1 &times; 100</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 0.5%</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: deviation &lt; 0.5%; AI: predictive warning before threshold</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">C02</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Current Anomaly H1</td>
        <td><code>|target_I1 &minus; present_I1| / target_I1 &times; 100</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 1%</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: deviation &lt; 1%; AI: predictive warning before threshold</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">C03</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Voltage Anomaly H2</td>
        <td><code>|target_V2 &minus; present_V2| / target_V2 &times; 100</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 0.5%</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: deviation &lt; 0.5%; AI: predictive warning</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">C04</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Current Anomaly H2</td>
        <td><code>|target_I2 &minus; present_I2| / target_I2 &times; 100</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 1%</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: deviation &lt; 1%; AI: predictive warning</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#9889; Power Anomalies</td></tr>
      <tr>
        <td><span class="sc-id sc-ai">C05</span></td>
        <td><span class="sc-tp sc-ai">AI</span></td>
        <td>Power Anomaly H1</td>
        <td><code>Ensemble(AE + DNN)</code> &mdash; trained on power_c1, volt_pct_dev, efficiency, energy_rate features</td>
        <td><span class="sc-th">Score &gt; 0.5</span></td>
        <td><span class="sc-std sc-na">No ISO/DIN</span> AI pattern detection &mdash; learns normal power delivery profile from historical data</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-ai">C06</span></td>
        <td><span class="sc-tp sc-ai">AI</span></td>
        <td>Power Anomaly H2</td>
        <td><code>Ensemble(AE + DNN)</code> &mdash; same architecture as C05, trained on Connector 2 features</td>
        <td><span class="sc-th">Score &gt; 0.5</span></td>
        <td><span class="sc-std sc-na">No ISO/DIN</span> Same as C05 for Connector 2</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#128293; Thermal Anomalies</td></tr>
      <tr>
        <td><span class="sc-id sc-hy">C07</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Thermal &mdash; PM1</td>
        <td><code>power_module_temp1 &gt; 55&deg;C</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 55&deg;C</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: OTP shutdown &gt; 75&deg;C; AI: detects thermal drift before derating</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">C08</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Thermal &mdash; PM2</td>
        <td><code>power_module_temp2 &gt; 55&deg;C</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 55&deg;C</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: safety limit; AI: early thermal warning</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">C09</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Thermal &mdash; PM3</td>
        <td><code>power_module_temp3 &gt; 55&deg;C</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 55&deg;C</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: safety limit; AI: early thermal warning</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">C10</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Thermal &mdash; PM4</td>
        <td><code>power_module_temp4 &gt; 55&deg;C</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 55&deg;C</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: safety limit; AI: early thermal warning</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-hy">C11</span></td>
        <td><span class="sc-tp sc-hy">Hybrid</span></td>
        <td>Thermal &mdash; PM5</td>
        <td><code>power_module_temp5 &gt; 55&deg;C</code><br><span class="sc-ai-note">+ AI Ensemble(AE+DNN) early warning</span></td>
        <td><span class="sc-th">&gt; 55&deg;C</span><br><span class="sc-ai-note">AI &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> Rule: safety limit; AI: early thermal warning</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-ai">C12</span></td>
        <td><span class="sc-tp sc-ai">AI</span></td>
        <td>Thermal &mdash; Charger</td>
        <td><code>Ensemble(AE + DNN)</code> &mdash; trained on charger_temp, humidity, temp_delta, charging state features</td>
        <td><span class="sc-th">Score &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact CHARX PS-M2</span> AI detects abnormal thermal patterns before derating threshold (55&deg;C)</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#9888; Power Module Status</td></tr>
      <tr>
        <td><span class="sc-id sc-rl">C13</span></td>
        <td><span class="sc-tp sc-rl">Rule</span></td>
        <td>Module Status H1</td>
        <td><code>power_module_status1 = Inactive OR power_module_status2 = Inactive</code></td>
        <td><span class="sc-th">Inactive</span></td>
        <td><span class="sc-std sc-na">No ISO/DIN</span> Operational monitoring &mdash; PM1/PM2 supply Connector 1</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-rl">C14</span></td>
        <td><span class="sc-tp sc-rl">Rule</span></td>
        <td>Module Status H2</td>
        <td><code>power_module_status3/4/5 = Inactive (any)</code></td>
        <td><span class="sc-th">Inactive</span></td>
        <td><span class="sc-std sc-na">No ISO/DIN</span> Operational monitoring &mdash; PM3/4/5 supply Connector 2</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#128293; Charging Cable Safety</td></tr>
      <tr>
        <td><span class="sc-id sc-rl">C15</span></td>
        <td><span class="sc-tp sc-rl">Rule</span></td>
        <td>Cable Safety H1</td>
        <td><code>charger_gun_temp_plus1 &gt; 90 OR charger_gun_temp_minus1 &gt; 90</code></td>
        <td><span class="sc-th">&gt; 90&deg;C</span></td>
        <td><span class="sc-std">IEC 62196-3 / IEC 61851-23</span> DC connector temperature limit for CCS Type 2 coupling</td>
        <td><span class="sc-eq" style="color:#0d9488">Charging Connector</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-rl">C16</span></td>
        <td><span class="sc-tp sc-rl">Rule</span></td>
        <td>Cable Safety H2</td>
        <td><code>charger_gun_temp_plus2 &gt; 90 OR charger_gun_temp_minus2 &gt; 90</code></td>
        <td><span class="sc-th">&gt; 90&deg;C</span></td>
        <td><span class="sc-std">IEC 62196-3 / IEC 61851-23</span> Same as C15</td>
        <td><span class="sc-eq" style="color:#0d9488">Charging Connector</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#128268; PLC Communication</td></tr>
      <tr>
        <td><span class="sc-id sc-rl">C17</span></td>
        <td><span class="sc-tp sc-rl">Rule</span></td>
        <td>PLC Anomaly H1</td>
        <td><code>PLC1_status = Inactive</code></td>
        <td><span class="sc-th">Inactive</span></td>
        <td><span class="sc-std">ISO 15118-2:2014</span> PLC (HomePlug GreenPHY) required for V2G communication &mdash; SLAC matching, SECC discovery</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-rl">C18</span></td>
        <td><span class="sc-tp sc-rl">Rule</span></td>
        <td>PLC Anomaly H2</td>
        <td><code>PLC2_status = Inactive</code></td>
        <td><span class="sc-th">Inactive</span></td>
        <td><span class="sc-std">ISO 15118-2:2014</span> Same as C17</td>
        <td><span class="sc-eq" style="color:#dc2626">Power Module</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#128225; Communication Device</td></tr>
      <tr>
        <td><span class="sc-id sc-ai">C19</span></td>
        <td><span class="sc-tp sc-ai">AI</span></td>
        <td>EdgeBox Temp</td>
        <td><code>Ensemble(AE + DNN)</code> &mdash; trained on edgebox_temp, hour_sin/cos, ambient correlation features</td>
        <td><span class="sc-th">Score &gt; 0.5</span></td>
        <td><span class="sc-std">Phoenix Contact</span> AI detects abnormal EdgeBox thermal drift before 70&deg;C limit</td>
        <td><span class="sc-eq" style="color:#0891b2">OCPP EdgeBox</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#10067; Energy Throughput</td></tr>
      <tr>
        <td><span class="sc-id sc-ai">C20</span></td>
        <td><span class="sc-tp sc-ai">AI</span></td>
        <td>Daily Energy H1</td>
        <td><code>Ensemble(AE + DNN)</code> &mdash; trained on daily_kwh, energy_rate, meter_trend, day_of_week features</td>
        <td><span class="sc-th">Score &gt; 0.5</span></td>
        <td><span class="sc-std sc-na">No ISO/DIN</span> AI learns daily usage patterns per connector; detects anomalous low-throughput days</td>
        <td><span class="sc-eq" style="color:#78716c">Unknown</span></td>
      </tr>
      <tr>
        <td><span class="sc-id sc-ai">C21</span></td>
        <td><span class="sc-tp sc-ai">AI</span></td>
        <td>Daily Energy H2</td>
        <td><code>Ensemble(AE + DNN)</code> &mdash; same architecture as C20, trained on Connector 2 meter data</td>
        <td><span class="sc-th">Score &gt; 0.5</span></td>
        <td><span class="sc-std sc-na">No ISO/DIN</span> Same as C20 for Connector 2</td>
        <td><span class="sc-eq" style="color:#78716c">Unknown</span></td>
      </tr>
      <tr class="sc-grp"><td colspan="7">&#9889; Energy Meter</td></tr>
      <tr>
        <td><span class="sc-id sc-rl">C22</span></td>
        <td><span class="sc-tp sc-rl">Rule</span></td>
        <td>Energy Meter Status</td>
        <td><code>energy_meter_status = Inactive</code></td>
        <td><span class="sc-th">Inactive</span></td>
        <td><span class="sc-std sc-na">No ISO/DIN</span> Operational monitoring &mdash; energy meter communication health</td>
        <td><span class="sc-eq" style="color:#059669">Energy Meter</span></td>
      </tr>
    </tbody>
  </table>
  </div>
</div>
</div><!-- /m4StdPanel -->


</div></div>

<!-- ═══ TAB 2 ═══ -->
<div class="tc on" id="tab-monitor"><div class="pg">

<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>&#127973;</i> <span data-i18n="health_tree">Asset Health Status Tree</span></span>
    <div style="display:flex;align-items:center;gap:10px;font-size:.55em;font-family:'JetBrains Mono';font-weight:600;color:var(--dim)">
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#0284c7,#06b6d4);display:inline-block"></span>Hybrid</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#7c3aed,#a855f7);display:inline-block"></span>AI</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#475569,#64748b);display:inline-block"></span>Rule</span>
    </div>
    <div class="tele-live">
      <div class="led" id="teleLed"></div>
      <span class="tele-st" id="teleSt" data-i18n="tele_connecting">Connecting…</span>
      <span class="tele-ts" id="teleTs"></span>
      <span class="ht-summary"><span class="ht-ok" id="htOkCnt">0</span>/<span class="ht-alarm" id="htAlCnt">0</span></span>
    </div>
  </div>

  <!-- ═══ DB CONNECTION STATUS ═══ -->
  <div class="db-bar" id="m4DbBar">
    <div class="db-chip wait" id="m4DbChip">
      <span class="db-dot wait" id="m4DbDot"></span>
      <span class="db-lbl">MongoDB</span>
      <span class="db-val" id="m4DbSt">Checking…</span>
    </div>
    <div class="db-sep"></div>
    <span class="db-detail" id="m4DbInfo">database: module4AbnormalPowerPrediction</span>
  </div>

  <!-- Gauge Bar -->
  <div class="hg-wrap">
    <div class="hg-bar">
      <div class="hg-seg hg-normal" id="hgNormal" style="width:100%"></div>
      <div class="hg-seg hg-warn" id="hgWarn" style="width:0%"></div>
      <div class="hg-seg hg-alarm" id="hgAlarm" style="width:0%"></div>
    </div>
    <div class="hg-labels">
      <div class="hg-lbl hg-lbl-normal"><span class="hg-dot" style="background:#16a34a"></span><span data-i18n="gauge_normal">Normal</span> <strong id="hgNormalCnt">22</strong></div>
      <div class="hg-lbl hg-lbl-warn"><span class="hg-dot" style="background:#d97706"></span><span data-i18n="gauge_warning">Warning</span> <strong id="hgWarnCnt">0</strong></div>
      <div class="hg-lbl hg-lbl-alarm"><span class="hg-dot" style="background:#ef4444"></span><span data-i18n="gauge_alarm">Alarm</span> <strong id="hgAlarmCnt">0</strong></div>
      <div class="hg-total"><span id="hgTotalTxt">22 / 22</span></div>
    </div>
  </div>
  <div class="ht-wrap">
  <div class="ht-canvas" id="htCanvas">
    <svg class="ht-svg" id="htSvg"></svg>
    <div class="col ht-col-c" id="colC">

    <div class="cn" id="c01" data-tp="hy" data-g="pm"><span class="cn-n">01</span><span class="cn-t">Voltage Anomaly H1</span><span class="cn-v" id="v01">&mdash;</span><span class="cn-b ok" id="b01">OK</span></div>
    <div class="cn" id="c02" data-tp="hy" data-g="pm"><span class="cn-n">02</span><span class="cn-t">Current Anomaly H1</span><span class="cn-v" id="v02">&mdash;</span><span class="cn-b ok" id="b02">OK</span></div>
    <div class="cn" id="c03" data-tp="hy" data-g="pm"><span class="cn-n">03</span><span class="cn-t">Voltage Anomaly H2</span><span class="cn-v" id="v03">&mdash;</span><span class="cn-b ok" id="b03">OK</span></div>
    <div class="cn" id="c04" data-tp="hy" data-g="pm"><span class="cn-n">04</span><span class="cn-t">Current Anomaly H2</span><span class="cn-v" id="v04">&mdash;</span><span class="cn-b ok" id="b04">OK</span></div>
    <div class="cn" id="c05" data-tp="ai" data-g="pm"><span class="cn-n">05</span><span class="cn-t">Power Anomaly H1</span><span class="cn-v" id="v05">&mdash;</span><span class="cn-b ok" id="b05">OK</span></div>
    <div class="cn" id="c06" data-tp="ai" data-g="pm"><span class="cn-n">06</span><span class="cn-t">Power Anomaly H2</span><span class="cn-v" id="v06">&mdash;</span><span class="cn-b ok" id="b06">OK</span></div>
    <div class="cn" id="c07" data-tp="hy" data-g="pm"><span class="cn-n">07</span><span class="cn-t">Thermal &#8212; PM1</span><span class="cn-v" id="v07">&mdash;</span><span class="cn-b ok" id="b07">OK</span></div>
    <div class="cn" id="c08" data-tp="hy" data-g="pm"><span class="cn-n">08</span><span class="cn-t">Thermal &#8212; PM2</span><span class="cn-v" id="v08">&mdash;</span><span class="cn-b ok" id="b08">OK</span></div>
    <div class="cn" id="c09" data-tp="hy" data-g="pm"><span class="cn-n">09</span><span class="cn-t">Thermal &#8212; PM3</span><span class="cn-v" id="v09">&mdash;</span><span class="cn-b ok" id="b09">OK</span></div>
    <div class="cn" id="c10" data-tp="hy" data-g="pm"><span class="cn-n">10</span><span class="cn-t">Thermal &#8212; PM4</span><span class="cn-v" id="v10">&mdash;</span><span class="cn-b ok" id="b10">OK</span></div>
    <div class="cn" id="c11" data-tp="hy" data-g="pm"><span class="cn-n">11</span><span class="cn-t">Thermal &#8212; PM5</span><span class="cn-v" id="v11">&mdash;</span><span class="cn-b ok" id="b11">OK</span></div>
    <div class="cn" id="c12" data-tp="ai" data-g="pm"><span class="cn-n">12</span><span class="cn-t">Thermal &#8212; Charger</span><span class="cn-v" id="v12">&mdash;</span><span class="cn-b ok" id="b12">OK</span></div>
    <div class="cn" id="c13" data-tp="rl" data-g="pm"><span class="cn-n">13</span><span class="cn-t">Module Status H1</span><span class="cn-v" id="v13">&mdash;</span><span class="cn-b ok" id="b13">OK</span></div>
    <div class="cn" id="c14" data-tp="rl" data-g="pm"><span class="cn-n">14</span><span class="cn-t">Module Status H2</span><span class="cn-v" id="v14">&mdash;</span><span class="cn-b ok" id="b14">OK</span></div>
    <div class="cn" id="c17" data-tp="rl" data-g="pm"><span class="cn-n">17</span><span class="cn-t">PLC Anomaly H1</span><span class="cn-v" id="v17">&mdash;</span><span class="cn-b ok" id="b17">OK</span></div>
    <div class="cn" id="c18" data-tp="rl" data-g="pm"><span class="cn-n">18</span><span class="cn-t">PLC Anomaly H2</span><span class="cn-v" id="v18">&mdash;</span><span class="cn-b ok" id="b18">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="c15" data-tp="rl" data-g="cc"><span class="cn-n">15</span><span class="cn-t">Cable Safety H1</span><span class="cn-v" id="v15">&mdash;</span><span class="cn-b ok" id="b15">OK</span></div>
    <div class="cn" id="c16" data-tp="rl" data-g="cc"><span class="cn-n">16</span><span class="cn-t">Cable Safety H2</span><span class="cn-v" id="v16">&mdash;</span><span class="cn-b ok" id="b16">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="c19" data-tp="ai" data-g="ocpp"><span class="cn-n">19</span><span class="cn-t">EdgeBox Temp</span><span class="cn-v" id="v19">&mdash;</span><span class="cn-b ok" id="b19">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="c20" data-tp="ai" data-g="unk"><span class="cn-n">20</span><span class="cn-t">Daily Energy H1</span><span class="cn-v" id="v20">&mdash;</span><span class="cn-b ok" id="b20">OK</span></div>
    <div class="cn" id="c21" data-tp="ai" data-g="unk"><span class="cn-n">21</span><span class="cn-t">Daily Energy H2</span><span class="cn-v" id="v21">&mdash;</span><span class="cn-b ok" id="b21">OK</span></div>
    <div class="gs"></div>
    <div class="cn" id="c22" data-tp="rl" data-g="em"><span class="cn-n">22</span><span class="cn-t">Energy Meter Status</span><span class="cn-v" id="v22">&mdash;</span><span class="cn-b ok" id="b22">OK</span></div>
    </div>
    <div class="col ht-col-e" id="colE">

      <div class="en" id="eqPM" style="border-color:#dc2626;color:#dc2626"><div class="en-t">&#9889; Power Module</div><div class="en-c">16 conditions</div></div>
      <div class="en" id="eqCC" style="border-color:#0d9488;color:#0d9488"><div class="en-t">&#128268; Charging Connector</div><div class="en-c">2 conditions</div></div>
      <div class="en" id="eqOCPP" style="border-color:#0891b2;color:#0891b2"><div class="en-t">&#128225; OCPP EdgeBox</div><div class="en-c">1 condition</div></div>
      <div class="en" id="eqUNK" style="border-color:#78716c;color:#78716c"><div class="en-t">&#10067; Unknown</div><div class="en-c">2 conditions</div></div>
      <div class="en" id="eqEM" style="border-color:#059669;color:#059669"><div class="en-t">&#9889; Energy Meter</div><div class="en-c">1 condition</div></div>
    </div>
    <div class="col ht-col-r" id="colR">

      <div class="rn" id="rootN">
        <div class="rn-gauge-wrap">
          <svg class="rn-gauge" viewBox="0 0 300 190" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="gNorm" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#22c55e"/><stop offset="100%" stop-color="#16a34a"/></linearGradient>
              <linearGradient id="gWarn" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#d97706"/></linearGradient>
              <linearGradient id="gAlrm" gradientUnits="userSpaceOnUse" x1="25" y1="155" x2="275" y2="155"><stop offset="0%" stop-color="#f87171"/><stop offset="100%" stop-color="#dc2626"/></linearGradient>
              <filter id="glowN" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#22c55e" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="glowW" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#fbbf24" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="glowA" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="4" result="b"/><feFlood flood-color="#ef4444" flood-opacity=".3"/><feComposite in2="b" operator="in" result="c"/><feMerge><feMergeNode in="c"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <filter id="tipGlow"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
            </defs>
            <path class="rg-outer-track" d="M 25 155 A 125 125 0 0 1 275 155" fill="none" stroke="rgba(0,0,0,.03)" stroke-width="3" stroke-linecap="round"/>
            <path class="rg-scan" d="M 25 155 A 125 125 0 0 1 275 155" fill="none" stroke="url(#gNorm)" stroke-width="2" stroke-linecap="round" stroke-dasharray="392.7" stroke-dashoffset="392.7"/>
            <path class="rg-inner-track" d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="rgba(0,0,0,.035)" stroke-width="20" stroke-linecap="round"/>
            <g id="rgTicks"></g>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#gNorm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="111.9 240" stroke-dashoffset="0" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#gWarn)" stroke-width="14" stroke-dasharray="111.9 240" stroke-dashoffset="-111.9" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" fill="none" stroke="url(#gAlrm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="128 223.9" stroke-dashoffset="-223.8" opacity=".1"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" class="rg-fill" fill="none" stroke="url(#gNorm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="rgArcN" filter="url(#glowN)" opacity="0"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" class="rg-fill" fill="none" stroke="url(#gWarn)" stroke-width="14" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="rgArcW" filter="url(#glowW)" opacity="0"/>
            <path d="M 38 155 A 112 112 0 0 1 262 155" class="rg-fill" fill="none" stroke="url(#gAlrm)" stroke-width="14" stroke-linecap="round" stroke-dasharray="351.9" stroke-dashoffset="351.9" id="rgArcA" filter="url(#glowA)" opacity="0"/>
            <g id="rgNeedle" transform="rotate(-90 150 155)">
              <path class="rg-needle-body" d="M148.5,52 L151.5,52 L150.8,146 L149.2,146 Z" fill="#1e293b" opacity=".85"/>
              <circle class="rg-needle-hub" cx="150" cy="155" r="9" fill="#fff" stroke="#1e293b" stroke-width="3"/>
              <circle class="rg-needle-dot" cx="150" cy="155" r="3.5" fill="#1e293b"/>
              <circle class="rg-needle-tip" cx="150" cy="52" r="3.5" fill="#16a34a" id="rgTip" filter="url(#tipGlow)" opacity=".95"/>
            </g>
            <text x="150" y="142" text-anchor="middle" font-size="42" font-weight="900" font-family="JetBrains Mono" id="rgVal" fill="#1e293b">0%</text>
            <text x="56" y="172" font-size="7.5" font-weight="700" font-family="JetBrains Mono" class="rg-zone-label" fill="#94a3b8" letter-spacing="1">NORMAL</text>
            <text x="150" y="28" font-size="7.5" font-weight="700" font-family="JetBrains Mono" class="rg-zone-label" fill="#94a3b8" text-anchor="middle" letter-spacing="1">WARNING</text>
            <text x="210" y="172" font-size="7.5" font-weight="700" font-family="JetBrains Mono" class="rg-zone-label" fill="#94a3b8" letter-spacing="1">ALARM</text>
          </svg>
          <div class="rn-pill" id="rgPill">
            <span class="rn-pill-dot" id="rgDot" style="background:#16a34a"></span>
            <span class="rn-pill-txt" id="rgTxt" style="color:#16a34a">NORMAL</span>
          </div>
        </div>
        <div class="rn-h" data-i18n="root_cause">Sub-Optimal Power Delivery</div>
        <div class="rn-s">Inefficient Power Delivery</div>
        <div class="rn-cnt" id="rootCnt">0% — 0 / 22 alarms</div>
      </div>
    </div>
  </div>
  </div>
</div>

<div class="rw c4">
  <div class="cd cd-cy kw"><div class="kbg" style="background:var(--cy)"></div><div class="ct"><i>&#128202;</i> <span data-i18n="predictions">Predictions</span></div><div class="kpi kc" id="xT">&mdash;</div></div>
  <div class="cd cd-rd kw"><div class="kbg" style="background:var(--rd)"></div><div class="ct"><i>&#128680;</i> <span data-i18n="anomalies">Anomalies</span></div><div class="kpi kr" id="xA">&mdash;</div></div>
  <div class="cd cd-am kw"><div class="kbg" style="background:var(--am)"></div><div class="ct"><i>&#128200;</i> <span data-i18n="rate">Rate</span></div><div class="kpi ka" id="xR">&mdash;</div></div>
  <div class="cd cd-gn kw"><div class="kbg" style="background:var(--gn)"></div><div class="ct"><i>&#9889;</i> <span data-i18n="latency">Latency</span></div><div class="kpi kg" id="xL">&mdash;</div></div>
</div>
<div class="rw c2">
  <div class="cd cd-rd"><div class="ct" style="color:var(--rd)"><i>&#128680;</i> <span data-i18n="alerts">Alerts</span></div><div style="max-height:320px;overflow-y:auto" id="lA"><div style="color:var(--dim);font-size:.78em;text-align:center;padding:40px;font-style:italic"><span data-i18n="awaiting">Awaiting telemetry…</span></div></div></div>
  <div class="cd cd-sl"><div class="ct"><i>&#128221;</i> <span data-i18n="log">Log</span></div><div class="lb" id="lB"><div class="ll" data-i18n="sys_ready">System ready…</div></div></div>
</div>

<!-- ═══ SCENARIOS (collapsible) ═══ -->
<div class="cd cg cd-sl">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between"><span><i>&#9881;</i> <span data-i18n="scenarios">Scenarios</span></span><label class="tgl" onclick="event.stopPropagation()"><input type="checkbox" id="scToggle" checked onchange="scVis(this.checked)"><span class="tgl-sl"></span></label></div>
  <div id="scBody">
  <div class="prg">
    <div class="pr pok" onclick="lp('normal')"><div class="pi">&#9889;</div><div class="pt" style="color:var(--gn)">Normal</div><div class="pd">400V 200A SOC 45%</div></div>
    <div class="pr pw" onclick="lp('voltage')"><div class="pi">&#9888;</div><div class="pt" style="color:var(--am)">Voltage</div><div class="pd">+15% deviation</div></div>
    <div class="pr pd2" onclick="lp('thermal')"><div class="pi">&#128293;</div><div class="pt" style="color:var(--rd)">Thermal</div><div class="pd">65&deg;C mod &middot; 90&deg;C gun</div></div>
    <div class="pr pd2" onclick="lp('multi')"><div class="pi">&#128680;</div><div class="pt" style="color:var(--rd)">Multi-Fault</div><div class="pd">Current+Temp+PLC</div></div>
  </div>
  <div class="brw">
    <button class="bt bgo" onclick="pred()" id="pbtn"><span data-i18n="predict">&#9889; PREDICT</span></button>
    <button class="bt bgh" onclick="clr()"><span data-i18n="clear">CLEAR</span></button>
    <div class="ap-divider"></div>
    <label class="tgl ap-tgl" title="Auto-predict every 2 min"><input type="checkbox" id="apToggle" checked onchange="apToggleChanged()"><span class="tgl-sl"></span></label>
    <div class="ap-info">
      <span class="ap-label" data-i18n="auto_predict">Auto Predict</span>
      <span class="ap-timer" id="apTimer">OFF</span>
    </div>
  </div>
  <div style="margin-top:8px;font-family:'JetBrains Mono';font-size:.63em;color:var(--dim)" id="ltl"></div>
  </div>
</div>

<!-- ═══ PREDICTION RESULTS ═══ -->
<div id="rp" class="rh">
<div class="rw c55" style="margin-bottom:14px">
  <div class="cd cg cd-pu stg" style="text-align:center;animation-delay:.05s">
    <div class="ct" style="justify-content:center"><i>&#127919;</i> <span data-i18n="anomaly_score">Anomaly Score</span></div>
    <div class="rbc"><div class="rc">
      <svg class="rsvg" viewBox="0 0 170 170">
        <circle class="rbg" cx="85" cy="85" r="72"/>
        <circle class="rgl" id="rGl" cx="85" cy="85" r="72" stroke-dasharray="452.4" stroke-dashoffset="452.4"/>
        <circle class="rfg" id="rFg" cx="85" cy="85" r="72" stroke-dasharray="452.4" stroke-dashoffset="452.4"/>
      </svg>
      <div class="rm"><div class="rv" id="rV">&mdash;</div><div class="rl" id="rL">waiting</div></div>
    </div></div>
    <div style="margin-top:14px"><span class="sv svN" id="svB">NORMAL</span></div>
    <div style="margin-top:10px;font-family:'JetBrains Mono';font-size:.62em;color:var(--dim)" id="mL"></div>
  </div>
  <div class="cd cg cd-cy stg" style="animation-delay:.12s">
    <div class="ct"><i>&#129302;</i> <span data-i18n="ensemble">Ensemble Models</span></div><div id="mR"></div>
  </div>
</div>
<div class="m3-load-panel collapsed" id="m4GrpPanel">
  <div class="m3-load-hdr" onclick="document.getElementById('m4GrpPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>&#128202;</i> <span data-i18n="group_scores">Group Anomaly Scores</span></div>
    <div class="m3-load-hdr-r"><span class="m3-load-toggle">▼</span></div>
  </div>
  <div class="gg" id="gG"></div>
</div>
<div class="m3-load-panel collapsed" id="m4FiPanel" style="display:none">
  <div class="m3-load-hdr" onclick="document.getElementById('m4FiPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>&#128269;</i> <span data-i18n="feat_imp">Feature Importance</span></div>
    <div class="m3-load-hdr-r">
      <span class="fi-badge" id="fiBadge">Input &times; Gradient</span>
      <span class="m3-load-toggle">▼</span>
    </div>
  </div>
  <div id="fiL"></div>
</div>
<div class="cd cd-rd stg" id="alC" style="display:none;animation-delay:.24s">
  <div class="ct" style="color:var(--rd)"><i>&#128680;</i> <span data-i18n="triggered_alerts">Triggered Alerts</span></div><div id="alL"></div>
</div>
</div>

</div></div>

<!-- ═══ TAB 3: STANDARDS REFERENCE ═══ -->
<div class="tc" id="tab-reference"><div class="pg">
<div class="lng-en">
<div class="ref-intro stg">
  <h2>&#128218; Anomaly Classification &amp; Standards Reference</h2>
  <p>This system detects <strong>7 anomaly classes</strong> in DC fast charger 150kW operations. Each class is mapped to international standards for EV charging infrastructure. The AI model ensemble (Autoencoder, 1D-CNN, BiLSTM+Attention, Transformer, Multi-Task DNN) monitors real-time telemetry and flags violations against these normative thresholds.</p>
  <div class="ref-std-grid">
    <div class="ref-std-card">
      <h4>Standard 1</h4>
      <div class="ref-std-name" style="color:var(--cy)">ISO 15118-2:2014</div>
      <p>V2G Communication Interface &mdash; Network &amp; application protocol requirements for EV-EVSE DC charging sessions</p>
    </div>
    <div class="ref-std-card">
      <h4>Standard 2</h4>
      <div class="ref-std-name" style="color:var(--gn)">IEC 61851-23:2014</div>
      <p>EV Conductive Charging &mdash; DC charging station requirements including thermal limits, voltage/current tolerances</p>
    </div>
    <div class="ref-std-card">
      <h4>Standard 3</h4>
      <div class="ref-std-name" style="color:var(--pu)">DIN SPEC 70121:2014</div>
      <p>Digital Communication (DC CCS 1.0) &mdash; PreCharge, CurrentDemand, and welding detection protocols</p>
    </div>
  </div>
</div>

<div class="ref-grid">

<!-- CLASS 1: VOLTAGE -->
<div class="ref-card stg" style="border-left-color:#dc2626;animation-delay:.05s">
  <div class="ref-head">
    <div class="ref-icon" style="background:rgba(220,38,38,.08);color:#dc2626">&#9889;</div>
    <div>
      <div class="ref-title" style="color:#dc2626">Voltage Anomaly
        <span class="ref-sev" style="background:rgba(217,119,6,.1);color:var(--am);border:1px solid rgba(217,119,6,.3)">HIGH</span>
      </div>
      <div class="ref-threshold" style="background:rgba(220,38,38,.06);color:#dc2626"><span>&#127919;</span> Threshold: 0.50</div>
    </div>
  </div>
  <div class="ref-desc">Detects abnormal deviation between target voltage and present output voltage during DC charging. Voltage instability can damage EV battery cells and indicates charger power regulation failure.</div>
  <div class="ref-section">
    <div class="ref-section-title">&#128220; Related Standards</div>
    <div class="ref-std"><span class="ref-std-icon">&#128312;</span><div><strong>ISO 15118-2 &sect;8.4.5.4</strong> &mdash; CurrentDemandReq/Res: EVTargetVoltage vs EVSEPresentVoltage tolerance &plusmn;5%. The SECC shall regulate output to match EV requested voltage within this margin.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128312;</span><div><strong>DIN SPEC 70121 PreCharge</strong> &mdash; |&Delta;V| &le; 20V: Before contactors close, present voltage must be within 20V of EV battery voltage to prevent inrush current damage.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128312;</span><div><strong>IEC 61851-23 &sect;101</strong> &mdash; DC output voltage regulation accuracy &plusmn;2% of rated voltage during steady-state charging operation.</div></div>
  </div>
  <div class="ref-section">
    <div class="ref-section-title">&#128269; Key Features Monitored</div>
    <div class="ref-features">
      <span class="ref-feat" style="background:rgba(220,38,38,.08);color:#dc2626">target_voltage1/2</span>
      <span class="ref-feat" style="background:rgba(220,38,38,.08);color:#dc2626">present_voltage1/2</span>
      <span class="ref-feat" style="background:rgba(220,38,38,.08);color:#dc2626">volt_diff_c1/c2</span>
      <span class="ref-feat" style="background:rgba(220,38,38,.08);color:#dc2626">volt_pct_dev_c1/c2</span>
    </div>
  </div>
  <div class="ref-action" style="background:rgba(217,119,6,.06);border-left:2px solid var(--am);color:var(--am)"><span>&#9888;&#65039;</span> Check voltage regulation circuit, verify PreCharge sequence, inspect power module output</div>
</div>

<!-- CLASS 2: CURRENT -->
<div class="ref-card stg" style="border-left-color:#0284c7;animation-delay:.1s">
  <div class="ref-head">
    <div class="ref-icon" style="background:rgba(2,132,199,.08);color:#0284c7">&#128268;</div>
    <div>
      <div class="ref-title" style="color:#0284c7">Current Anomaly
        <span class="ref-sev" style="background:rgba(217,119,6,.1);color:var(--am);border:1px solid rgba(217,119,6,.3)">HIGH</span>
      </div>
      <div class="ref-threshold" style="background:rgba(2,132,199,.06);color:#0284c7"><span>&#127919;</span> Threshold: 0.40</div>
    </div>
  </div>
  <div class="ref-desc">Detects overcurrent conditions where present current exceeds the EV-requested target current. Overcurrent risks cable overheating, connector damage, and can trigger emergency shutdown.</div>
  <div class="ref-section">
    <div class="ref-section-title">&#128220; Related Standards</div>
    <div class="ref-std"><span class="ref-std-icon">&#128309;</span><div><strong>ISO 15118-2 FAILED_ChargingCurrentdifferential</strong> &mdash; ResponseCode for excessive current deviation between EVTargetCurrent and EVSEPresentCurrent during CurrentDemand loop.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128309;</span><div><strong>DIN SPEC 70121 CurrentDemand</strong> &mdash; |&Delta;I| &le; 5A: Maximum allowed deviation between requested and delivered current. Exceeding triggers EVSE fault.</div></div>
  </div>
  <div class="ref-section">
    <div class="ref-section-title">&#128269; Key Features Monitored</div>
    <div class="ref-features">
      <span class="ref-feat" style="background:rgba(2,132,199,.08);color:#0284c7">target_current1/2</span>
      <span class="ref-feat" style="background:rgba(2,132,199,.08);color:#0284c7">present_current1/2</span>
      <span class="ref-feat" style="background:rgba(2,132,199,.08);color:#0284c7">curr_diff_c1/c2</span>
      <span class="ref-feat" style="background:rgba(2,132,199,.08);color:#0284c7">overcurrent_c1/c2</span>
    </div>
  </div>
  <div class="ref-action" style="background:rgba(217,119,6,.06);border-left:2px solid var(--am);color:var(--am)"><span>&#9888;&#65039;</span> Inspect current control loop, verify power electronics regulation, check cable rating</div>
</div>

<!-- CLASS 3: POWER -->
<div class="ref-card stg" style="border-left-color:#d97706;animation-delay:.15s">
  <div class="ref-head">
    <div class="ref-icon" style="background:rgba(217,119,6,.08);color:#d97706">&#9889;</div>
    <div>
      <div class="ref-title" style="color:#d97706">Power Anomaly
        <span class="ref-sev" style="background:rgba(2,132,199,.08);color:var(--cy);border:1px solid rgba(2,132,199,.3)">MEDIUM</span>
      </div>
      <div class="ref-threshold" style="background:rgba(217,119,6,.06);color:#d97706"><span>&#127919;</span> Threshold: 0.50</div>
    </div>
  </div>
  <div class="ref-desc">Detects when delivered power (V &times; I) exceeds rated power limits of the charger or connector. Power overload stresses internal components and risks cascading equipment failure.</div>
  <div class="ref-section">
    <div class="ref-section-title">&#128220; Related Standards</div>
    <div class="ref-std"><span class="ref-std-icon">&#128992;</span><div><strong>DIN SPEC 70121 CCS 1.0</strong> &mdash; Maximum DC power output 80kW per connector for CCS Combo 1 specification. Dual-connector total must not exceed rated station capacity.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128992;</span><div><strong>IEC 61851-23</strong> &mdash; Rated output power 150kW for this charger class. EVSEMaximumPowerLimit shall be communicated to EV and enforced by power sharing logic.</div></div>
  </div>
  <div class="ref-section">
    <div class="ref-section-title">&#128269; Key Features Monitored</div>
    <div class="ref-features">
      <span class="ref-feat" style="background:rgba(217,119,6,.08);color:#d97706">power_c1/c2</span>
      <span class="ref-feat" style="background:rgba(217,119,6,.08);color:#d97706">power_total</span>
      <span class="ref-feat" style="background:rgba(217,119,6,.08);color:#d97706">power_total_diff1/diff2</span>
      <span class="ref-feat" style="background:rgba(217,119,6,.08);color:#d97706">is_dual_charging</span>
    </div>
  </div>
  <div class="ref-action" style="background:rgba(2,132,199,.06);border-left:2px solid var(--cy);color:var(--cy)"><span>&#128296;</span> Verify power sharing &amp; connector load balancing, check EVSEMaximumPowerLimit setting</div>
</div>

<!-- CLASS 4: SOC -->
<div class="ref-card stg" style="border-left-color:#7c3aed;animation-delay:.2s">
  <div class="ref-head">
    <div class="ref-icon" style="background:rgba(124,58,237,.08);color:#7c3aed">&#128267;</div>
    <div>
      <div class="ref-title" style="color:#7c3aed">SOC Anomaly
        <span class="ref-sev" style="background:rgba(2,132,199,.08);color:var(--cy);border:1px solid rgba(2,132,199,.3)">MEDIUM</span>
      </div>
      <div class="ref-threshold" style="background:rgba(124,58,237,.06);color:#7c3aed"><span>&#127919;</span> Threshold: 0.50</div>
    </div>
  </div>
  <div class="ref-desc">Detects State of Charge (SOC) reporting anomalies &mdash; such as SOC=0% while charging is active, or implausible SOC jumps. Indicates EV BMS communication errors or V2G protocol issues.</div>
  <div class="ref-section">
    <div class="ref-section-title">&#128220; Related Standards</div>
    <div class="ref-std"><span class="ref-std-icon">&#128995;</span><div><strong>ISO 15118-2 Table 101 EVRESSSOC</strong> &mdash; DC_EVStatus shall include EVRESSSOC (EV Rechargeable Energy Storage System SOC) in every CurrentDemandReq. Value must reflect actual battery state.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128995;</span><div><strong>DIN SPEC 70121 DC_EVStatus</strong> &mdash; SOC field in DC_EVStatus is mandatory. BulkChargingComplete flag at ~80% SOC, ChargingComplete at 100% SOC.</div></div>
  </div>
  <div class="ref-section">
    <div class="ref-section-title">&#128269; Key Features Monitored</div>
    <div class="ref-features">
      <span class="ref-feat" style="background:rgba(124,58,237,.08);color:#7c3aed">SOC</span>
      <span class="ref-feat" style="background:rgba(124,58,237,.08);color:#7c3aed">is_charging_c1/c2</span>
      <span class="ref-feat" style="background:rgba(124,58,237,.08);color:#7c3aed">power_total</span>
    </div>
  </div>
  <div class="ref-action" style="background:rgba(2,132,199,.06);border-left:2px solid var(--cy);color:var(--cy)"><span>&#128296;</span> Check V2G communication layer, verify EV BMS SOC reporting, inspect DC_EVStatus messages</div>
</div>

<!-- CLASS 5: THERMAL -->
<div class="ref-card stg" style="border-left-color:#db2777;animation-delay:.25s">
  <div class="ref-head">
    <div class="ref-icon" style="background:rgba(219,39,119,.08);color:#db2777">&#128293;</div>
    <div>
      <div class="ref-title" style="color:#db2777">Thermal Anomaly
        <span class="ref-sev" style="background:rgba(220,38,38,.08);color:var(--rd);border:1px solid rgba(220,38,38,.35)">CRITICAL</span>
      </div>
      <div class="ref-threshold" style="background:rgba(219,39,119,.06);color:#db2777"><span>&#127919;</span> Threshold: 0.30</div>
    </div>
  </div>
  <div class="ref-desc">Detects overtemperature conditions in power modules, charger body, or charging gun connectors. Thermal runaway is the most dangerous failure mode &mdash; risks fire, cable melt, and permanent equipment damage.</div>
  <div class="ref-section">
    <div class="ref-section-title">&#128220; Related Standards</div>
    <div class="ref-std"><span class="ref-std-icon">&#128308;</span><div><strong>IEC 61851-23 &sect;101.2</strong> &mdash; Operating temperature range: &minus;35&deg;C to +55&deg;C for power modules. Charger must derate or shut down if temperature exceeds this range.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128308;</span><div><strong>IEC 62196-3</strong> &mdash; Gun connector temperature &le; 90&deg;C maximum. Exceeding this limit requires immediate power reduction or emergency stop to prevent connector melt.</div></div>
  </div>
  <div class="ref-section">
    <div class="ref-section-title">&#128269; Key Features Monitored</div>
    <div class="ref-features">
      <span class="ref-feat" style="background:rgba(219,39,119,.08);color:#db2777">power_module_temp1-5</span>
      <span class="ref-feat" style="background:rgba(219,39,119,.08);color:#db2777">charger_temp</span>
      <span class="ref-feat" style="background:rgba(219,39,119,.08);color:#db2777">charger_gun_temp_plus1/2</span>
      <span class="ref-feat" style="background:rgba(219,39,119,.08);color:#db2777">max_module_temp</span>
      <span class="ref-feat" style="background:rgba(219,39,119,.08);color:#db2777">temp_spread</span>
      <span class="ref-feat" style="background:rgba(219,39,119,.08);color:#db2777">temp_delta_charger_gun</span>
    </div>
  </div>
  <div class="ref-action" style="background:rgba(220,38,38,.06);border-left:2px solid var(--rd);color:var(--rd)"><span>&#9888;&#65039;</span> URGENT: Activate cooling system, reduce power output immediately, inspect gun connector for damage or debris</div>
</div>

<!-- CLASS 6: COMMUNICATION -->
<div class="ref-card stg" style="border-left-color:#0d9488;animation-delay:.3s">
  <div class="ref-head">
    <div class="ref-icon" style="background:rgba(13,148,136,.08);color:#0d9488">&#128225;</div>
    <div>
      <div class="ref-title" style="color:#0d9488">Communication Anomaly
        <span class="ref-sev" style="background:rgba(220,38,38,.08);color:var(--rd);border:1px solid rgba(220,38,38,.35)">CRITICAL</span>
      </div>
      <div class="ref-threshold" style="background:rgba(13,148,136,.06);color:#0d9488"><span>&#127919;</span> Threshold: 0.30</div>
    </div>
  </div>
  <div class="ref-desc">Detects PLC (Power Line Communication) module failure or V2G session communication breakdown during active charging. Loss of communication means the charger cannot receive EV commands and may output uncontrolled power.</div>
  <div class="ref-section">
    <div class="ref-section-title">&#128220; Related Standards</div>
    <div class="ref-std"><span class="ref-std-icon">&#128994;</span><div><strong>ISO 15118-2 V2G Session</strong> &mdash; SECC shall maintain a valid V2G communication session throughout charging. Session timeout (V2G_SECC_Sequence_Timeout) triggers emergency stop.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128994;</span><div><strong>DIN SPEC 70121 PLC</strong> &mdash; HomePlug GreenPHY PLC link must be maintained. If PLC signal lost during CurrentDemand phase, EVSE must initiate safe shutdown sequence.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128994;</span><div><strong>CurrentDemandRes Timeout</strong> &mdash; If SECC does not respond to CurrentDemandReq within V2G_SECC_Sequence_Timeout, EVCC shall stop charging session per [V2G2-258].</div></div>
  </div>
  <div class="ref-section">
    <div class="ref-section-title">&#128269; Key Features Monitored</div>
    <div class="ref-features">
      <span class="ref-feat" style="background:rgba(13,148,136,.08);color:#0d9488">PLC1_status</span>
      <span class="ref-feat" style="background:rgba(13,148,136,.08);color:#0d9488">PLC2_status</span>
      <span class="ref-feat" style="background:rgba(13,148,136,.08);color:#0d9488">is_charging_c1/c2</span>
      <span class="ref-feat" style="background:rgba(13,148,136,.08);color:#0d9488">energy_meter_status</span>
    </div>
  </div>
  <div class="ref-action" style="background:rgba(220,38,38,.06);border-left:2px solid var(--rd);color:var(--rd)"><span>&#9888;&#65039;</span> URGENT: Check PLC module hardware, restart communication controller, verify HomePlug GreenPHY signal</div>
</div>

<!-- CLASS 7: SESSION -->
<div class="ref-card stg" style="border-left-color:#059669;animation-delay:.35s">
  <div class="ref-head">
    <div class="ref-icon" style="background:rgba(5,150,105,.08);color:#059669">&#128260;</div>
    <div>
      <div class="ref-title" style="color:#059669">Session Anomaly
        <span class="ref-sev" style="background:rgba(2,132,199,.08);color:var(--cy);border:1px solid rgba(2,132,199,.3)">MEDIUM</span>
      </div>
      <div class="ref-threshold" style="background:rgba(5,150,105,.06);color:#059669"><span>&#127919;</span> Threshold: 0.40</div>
    </div>
  </div>
  <div class="ref-desc">Detects abnormal charging session behavior &mdash; such as high target voltage with zero present output (contactor failure), or unexpected power module sequencing patterns during ramp-up/down phases.</div>
  <div class="ref-section">
    <div class="ref-section-title">&#128220; Related Standards</div>
    <div class="ref-std"><span class="ref-std-icon">&#128996;</span><div><strong>ISO 15118-2 [V2G2-838] Ramp-Down</strong> &mdash; When stopping, EVSE shall reduce current &le; 5A before opening contactors. Abrupt cutoff indicates sequencing failure.</div></div>
    <div class="ref-std"><span class="ref-std-icon">&#128996;</span><div><strong>IEC 61851-23 Module Sequencing</strong> &mdash; Power modules must activate/deactivate in defined sequence. Module count vs. active_modules inconsistency indicates failure.</div></div>
  </div>
  <div class="ref-section">
    <div class="ref-section-title">&#128269; Key Features Monitored</div>
    <div class="ref-features">
      <span class="ref-feat" style="background:rgba(5,150,105,.08);color:#059669">active_modules</span>
      <span class="ref-feat" style="background:rgba(5,150,105,.08);color:#059669">power_module_status1-5</span>
      <span class="ref-feat" style="background:rgba(5,150,105,.08);color:#059669">target_voltage1/2</span>
      <span class="ref-feat" style="background:rgba(5,150,105,.08);color:#059669">present_voltage1/2</span>
      <span class="ref-feat" style="background:rgba(5,150,105,.08);color:#059669">is_charging_c1/c2</span>
    </div>
  </div>
  <div class="ref-action" style="background:rgba(2,132,199,.06);border-left:2px solid var(--cy);color:var(--cy)"><span>&#128296;</span> Review session logs, verify power module sequencing, check contactor control circuit</div>
</div>

</div><!-- /ref-grid -->
</div><!-- /lng-en -->

<div class="lng-th" style="display:none">
<div class="ref-intro stg">
  <h2>&#128218; การจำแนกความผิดปกติ &amp; มาตรฐานอ้างอิง</h2>
  <p>ระบบนี้ตรวจจับ <strong>7 ประเภทความผิดปกติ</strong> ในการทำงานของเครื่องชาร์จ DC 150kW แต่ละประเภทถูกจับคู่กับมาตรฐานสากลสำหรับโครงสร้างพื้นฐานการชาร์จ EV โดย AI Model Ensemble (Autoencoder, 1D-CNN, BiLSTM+Attention, Transformer, Multi-Task DNN) ตรวจสอบข้อมูลเทเลเมทรีแบบเรียลไทม์และแจ้งเตือนเมื่อเกินเกณฑ์ที่กำหนด</p>
  <div class="ref-std-grid">
    <div class="ref-std-card"><h4>มาตรฐาน 1</h4><div class="ref-std-name" style="color:var(--cy)">ISO 15118-2:2014</div><p>อินเทอร์เฟซสื่อสาร V2G — ข้อกำหนดโปรโตคอลเครือข่ายและแอปพลิเคชันสำหรับเซสชันการชาร์จ DC ระหว่าง EV-EVSE</p></div>
    <div class="ref-std-card"><h4>มาตรฐาน 2</h4><div class="ref-std-name" style="color:var(--gn)">IEC 61851-23:2014</div><p>การชาร์จ EV แบบนำไฟฟ้า — ข้อกำหนดสถานีชาร์จ DC รวมถึงขีดจำกัดความร้อน ค่าพิกัดแรงดัน/กระแส</p></div>
    <div class="ref-std-card"><h4>มาตรฐาน 3</h4><div class="ref-std-name" style="color:var(--pu)">DIN SPEC 70121:2014</div><p>การสื่อสารดิจิทัล (DC CCS 1.0) — โปรโตคอล PreCharge, CurrentDemand และการตรวจจับการเชื่อม</p></div>
  </div>
</div>
<div class="ref-grid">
  <div class="ref-card stg" style="border-left-color:#dc2626"><div class="ref-head"><div class="ref-icon" style="background:rgba(220,38,38,.08);color:#dc2626">&#9889;</div><div><div class="ref-title" style="color:#dc2626">ความผิดปกติแรงดันไฟฟ้า<span class="ref-sev" style="background:rgba(217,119,6,.1);color:var(--am);border:1px solid rgba(217,119,6,.3)">สูง</span></div></div></div><div class="ref-desc">ตรวจจับค่าเบี่ยงเบนผิดปกติระหว่างแรงดันเป้าหมายและแรงดันเอาต์พุตจริงระหว่างการชาร์จ DC ความไม่เสถียรของแรงดันอาจทำให้เซลล์แบตเตอรี่ EV เสียหายและบ่งบอกถึงความล้มเหลวของการควบคุมพลังงาน</div></div>
  <div class="ref-card stg" style="border-left-color:#0284c7"><div class="ref-head"><div class="ref-icon" style="background:rgba(2,132,199,.08);color:#0284c7">&#128268;</div><div><div class="ref-title" style="color:#0284c7">ความผิดปกติกระแสไฟฟ้า<span class="ref-sev" style="background:rgba(217,119,6,.1);color:var(--am);border:1px solid rgba(217,119,6,.3)">สูง</span></div></div></div><div class="ref-desc">ตรวจจับสภาวะกระแสเกินที่กระแสจริงเกินกว่าที่ EV ร้องขอ กระแสเกินเสี่ยงต่อสายเคเบิลร้อนจัด คอนเนคเตอร์เสียหาย และอาจทำให้เกิดการปิดฉุกเฉิน</div></div>
  <div class="ref-card stg" style="border-left-color:#d97706"><div class="ref-head"><div class="ref-icon" style="background:rgba(217,119,6,.08);color:#d97706">&#9889;</div><div><div class="ref-title" style="color:#d97706">ความผิดปกติพลังงาน<span class="ref-sev" style="background:rgba(2,132,199,.08);color:var(--cy);border:1px solid rgba(2,132,199,.3)">ปานกลาง</span></div></div></div><div class="ref-desc">ตรวจจับเมื่อพลังงานที่จ่าย (V &times; I) เกินพิกัดกำลังของเครื่องชาร์จหรือคอนเนคเตอร์ การโอเวอร์โหลดพลังงานสร้างแรงกดดันต่อชิ้นส่วนภายในและเสี่ยงต่อความเสียหายแบบลูกโซ่</div></div>
  <div class="ref-card stg" style="border-left-color:#7c3aed"><div class="ref-head"><div class="ref-icon" style="background:rgba(124,58,237,.08);color:#7c3aed">&#128267;</div><div><div class="ref-title" style="color:#7c3aed">ความผิดปกติ SOC<span class="ref-sev" style="background:rgba(2,132,199,.08);color:var(--cy);border:1px solid rgba(2,132,199,.3)">ปานกลาง</span></div></div></div><div class="ref-desc">ตรวจจับความผิดปกติของการรายงาน SOC เช่น SOC=0% ขณะกำลังชาร์จ หรือ SOC กระโดดผิดปกติ บ่งบอกถึงข้อผิดพลาดการสื่อสาร BMS หรือปัญหาโปรโตคอล V2G</div></div>
  <div class="ref-card stg" style="border-left-color:#db2777"><div class="ref-head"><div class="ref-icon" style="background:rgba(219,39,119,.08);color:#db2777">&#128293;</div><div><div class="ref-title" style="color:#db2777">ความผิดปกติความร้อน<span class="ref-sev" style="background:rgba(220,38,38,.1);color:var(--rd);border:1px solid rgba(220,38,38,.3)">วิกฤต</span></div></div></div><div class="ref-desc">ตรวจจับสภาวะอุณหภูมิเกินในโมดูลพลังงาน ตัวเครื่องชาร์จ หรือคอนเนคเตอร์หัวชาร์จ Thermal runaway เป็นโหมดความล้มเหลวที่อันตรายที่สุด — เสี่ยงไฟไหม้ สายหลอมละลาย และอุปกรณ์เสียหายถาวร</div></div>
  <div class="ref-card stg" style="border-left-color:#0d9488"><div class="ref-head"><div class="ref-icon" style="background:rgba(13,148,136,.08);color:#0d9488">&#128268;</div><div><div class="ref-title" style="color:#0d9488">ความผิดปกติการสื่อสาร<span class="ref-sev" style="background:rgba(220,38,38,.1);color:var(--rd);border:1px solid rgba(220,38,38,.3)">วิกฤต</span></div></div></div><div class="ref-desc">ตรวจจับความล้มเหลวของโมดูล PLC หรือการสื่อสารเซสชัน V2G ขัดข้องระหว่างการชาร์จ การสูญเสียการสื่อสารหมายความว่าเครื่องชาร์จไม่สามารถรับคำสั่ง EV ได้และอาจจ่ายพลังงานแบบไม่ควบคุม</div></div>
  <div class="ref-card stg" style="border-left-color:#059669"><div class="ref-head"><div class="ref-icon" style="background:rgba(5,150,105,.08);color:#059669">&#128260;</div><div><div class="ref-title" style="color:#059669">ความผิดปกติเซสชัน<span class="ref-sev" style="background:rgba(217,119,6,.1);color:var(--am);border:1px solid rgba(217,119,6,.3)">สูง</span></div></div></div><div class="ref-desc">ตรวจจับพฤติกรรมเซสชันการชาร์จผิดปกติ เช่น แรงดันเป้าหมายสูงแต่เอาต์พุตจริงเป็นศูนย์ (คอนแทคเตอร์เสีย) หรือรูปแบบการทำงานของ Power Module ผิดปกติระหว่างขั้นตอน ramp-up/down</div></div>
</div>
</div><!-- /lng-th -->

</div></div>

<!-- ═══ TAB 4: RULE-BASED ALGORITHMS ═══ -->
<div class="tc" id="tab-rules"><div class="pg">
<div class="lng-en">
<div class="ra-intro stg">
  <h2>&#128752; Rule-Based Detection Algorithms</h2>
  <p>In addition to the AI Model Ensemble, the system has a <strong>Rule-Based Engine with 6 rules</strong> operating in real-time via MQTT, inspecting PLC data from the DC Charger 150kW (Klongluang Station 3) against engineering-defined thresholds and standards.</p>
  <div class="ra-flow">
    <span class="ra-flow-step" style="background:var(--cyg);color:var(--cy)">&#128225; MQTT Broker</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--gng);color:var(--gn)">&#128230; PLC JSON Data</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--amg);color:var(--am)">&#128752; Rule Engine (6 Rules)</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--rdg);color:var(--rd)">&#128680; Alert / OK</span><span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--pug);color:var(--pu)">&#128202; Dashboard UI</span>
  </div>
</div>
<div class="ra-card cd-cy stg" style="animation-delay:.05s"><div class="ra-num">01</div><div class="ra-head"><div class="ra-icon" style="background:rgba(2,132,199,.1);color:#0284c7">&#9889;</div><div><div class="ra-title" style="color:#0284c7">Charging State Check<span class="ra-id" style="background:rgba(2,132,199,.1);color:#0284c7">r1_c1 / r1_c2</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span></div></div></div><div class="ra-desc">Verifies that when the charger is in <strong>Charging State</strong> (ICP = C2, USLink = CurrentDemand), Voltage and Current values (both Target and Present) must be greater than 0. If any value is 0 during charging, it indicates the Power Module is not actually delivering power or a communication failure.</div></div>
<div class="ra-card cd-pk stg" style="animation-delay:.1s"><div class="ra-num">02</div><div class="ra-head"><div class="ra-icon" style="background:rgba(219,39,119,.1);color:#db2777">&#128293;</div><div><div class="ra-title" style="color:#db2777">Thermal Derating<span class="ra-id" style="background:rgba(219,39,119,.1);color:#db2777">r2_c1 / r2_c2</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span></div></div></div><div class="ra-desc">When Power Module temperature exceeds <strong>55&deg;C</strong>, derating occurs — current and power capacity reduce proportionally. For every 1&deg;C over the threshold, capacity drops by <strong>3.2A</strong> and <strong>1kW</strong>. This rule calculates real-time derating values.</div></div>
<div class="ra-card cd-am stg" style="animation-delay:.15s"><div class="ra-num">03</div><div class="ra-head"><div class="ra-icon" style="background:rgba(217,119,6,.1);color:#d97706">&#128268;</div><div><div class="ra-title" style="color:#d97706">Single Car Module Count<span class="ra-id" style="background:rgba(217,119,6,.1);color:#d97706">r3_c1 / r3_c2</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span></div></div></div><div class="ra-desc">When <strong>1 vehicle</strong> is charging (one head ICP=B1 or C2, other head ICP=A1), all 5 Power Modules must work together to deliver maximum power to that single vehicle. If the combined count is less than 5, a module has malfunctioned.</div></div>
<div class="ra-card cd-pu stg" style="animation-delay:.2s"><div class="ra-num">04</div><div class="ra-head"><div class="ra-icon" style="background:rgba(124,58,237,.1);color:#7c3aed">&#128260;</div><div><div class="ra-title" style="color:#7c3aed">Dual Car Power Sharing<span class="ra-id" style="background:rgba(124,58,237,.1);color:#7c3aed">r4_c1 / r4_c2</span><span class="ra-severity" style="background:var(--rdg);color:var(--rd)">CRITICAL</span></div></div></div><div class="ra-desc">When <strong>2 vehicles charge simultaneously</strong>, Power Modules are split: Head 1 requires <strong>2 active</strong> and Head 2 requires <strong>3 active</strong> (total 5). If counts don't match, the Power Sharing Logic has failed or a module is faulty.</div></div>
<div class="ra-card cd-gn stg" style="animation-delay:.25s"><div class="ra-num">05</div><div class="ra-head"><div class="ra-icon" style="background:rgba(5,150,105,.1);color:#059669">&#128200;</div><div><div class="ra-title" style="color:#059669">Under-delivery Check<span class="ra-id" style="background:rgba(5,150,105,.1);color:#059669">r5_c1 / r5_c2</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span></div></div></div><div class="ra-desc">Checks if Present Voltage/Current is more than 5% below Target. If below threshold and <strong>no Power Limit from CSMS</strong> (powerLimit=0), the charger is genuinely under-delivering — not being limited by the central system.</div></div>
<div class="ra-card cd-tl stg" style="animation-delay:.3s"><div class="ra-num">06</div><div class="ra-head"><div class="ra-icon" style="background:rgba(13,148,136,.1);color:#0d9488">&#128293;</div><div><div class="ra-title" style="color:#0d9488">Gun Temperature Derating<span class="ra-id" style="background:rgba(13,148,136,.1);color:#0d9488">r6_c1 / r6_c2</span><span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span></div></div></div><div class="ra-desc">Checks CCS Type 2 375A gun temperature against <strong>Phoenix Contact Lab Test (Boost Mode)</strong> data. As temperature rises, the allowable duration for Boost Current decreases. The system performs table lookup and alerts accordingly.</div></div>
</div><!-- /lng-en -->

<div class="lng-th" style="display:none">
<div class="ra-intro stg">
  <h2>&#128752; Rule-Based Detection Algorithms</h2>
  <p>นอกเหนือจาก AI Model Ensemble แล้ว ระบบยังมี <strong>Rule-Based Engine 6 กฎ</strong> ที่ทำงานแบบ Real-Time ผ่าน MQTT โดยตรวจสอบข้อมูลจาก PLC ของ DC Charger 150kW (Klongluang Station 3) เทียบกับเกณฑ์ที่กำหนดตามมาตรฐานและข้อมูลทางวิศวกรรม</p>
  <div class="ra-flow">
    <span class="ra-flow-step" style="background:var(--cyg);color:var(--cy)">&#128225; MQTT Broker</span>
    <span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--gng);color:var(--gn)">&#128230; PLC JSON Data</span>
    <span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--amg);color:var(--am)">&#128752; Rule Engine (6 Rules)</span>
    <span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--rdg);color:var(--rd)">&#128680; Alert / OK</span>
    <span class="ra-flow-arrow">&rarr;</span>
    <span class="ra-flow-step" style="background:var(--pug);color:var(--pu)">&#128202; Dashboard UI</span>
  </div>
</div>

<!-- RULE 1 -->
<div class="ra-card cd-cy stg" style="animation-delay:.05s">
  <div class="ra-num">01</div>
  <div class="ra-head">
    <div class="ra-icon" style="background:rgba(2,132,199,.1);color:#0284c7">&#9889;</div>
    <div>
      <div class="ra-title" style="color:#0284c7">Charging State Check
        <span class="ra-id" style="background:rgba(2,132,199,.1);color:#0284c7">r1_c1 / r1_c2</span>
        <span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span>
      </div>
    </div>
  </div>
  <div class="ra-desc">ตรวจสอบว่าเมื่อ Charger อยู่ใน <strong>Charging State</strong> (ICP = C2, USLink = CurrentDemand) ค่า Voltage และ Current ทั้ง Target และ Present จะต้องมีค่ามากกว่า 0 หากค่าใดเป็น 0 ขณะกำลังชาร์จ แสดงว่า Power Module ไม่ได้จ่ายไฟจริง หรือ Communication ขัดข้อง</div>
  <div class="ra-logic" style="background:rgba(2,132,199,.04)">
    <div class="ra-logic-title">&#128161; Detection Logic</div>
    <div class="ra-code"><span class="kw">IF</span> ICP_State == <span class="val">C2 (7)</span> <span class="kw">AND</span> USLink_State == <span class="val">CurrentDemand (13)</span>
  <span class="kw">CHECK</span> presentVoltage &gt; <span class="val">0</span>    <span class="cmt">// EVSE กำลังจ่ายแรงดัน</span>
  <span class="kw">CHECK</span> presentCurrent &gt; <span class="val">0</span>    <span class="cmt">// EVSE กำลังจ่ายกระแส</span>
  <span class="kw">CHECK</span> targetVoltage &gt; <span class="val">0</span>     <span class="cmt">// EV request แรงดัน</span>
  <span class="kw">CHECK</span> targetCurrent &gt; <span class="val">0</span>     <span class="cmt">// EV request กระแส</span>
  <span class="kw">IF</span> any == <span class="val">0</span> &rarr; <span style="color:var(--rd);font-weight:700">ALERT</span>   <span class="cmt">// Power Module ผิดปกติ</span></div>
  </div>
  <div class="ra-mqtt">
    <div class="ra-mqtt-title">&#128225; MQTT Keys &mdash; <code style="font-size:1.1em">OCPP/Klongluang3/PLC</code></div>
    <div class="ra-keys">
      <span class="ra-key" style="background:rgba(2,132,199,.08)"><span class="ra-key-name">icp1/2</span><span class="ra-key-type">int</span></span>
      <span class="ra-key" style="background:rgba(2,132,199,.08)"><span class="ra-key-name">usl1/2</span><span class="ra-key-type">int</span></span>
      <span class="ra-key" style="background:rgba(2,132,199,.08)"><span class="ra-key-name">presentVoltage1/2</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(2,132,199,.08)"><span class="ra-key-name">presentCurrent1/2</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(2,132,199,.08)"><span class="ra-key-name">targetVoltage1/2</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(2,132,199,.08)"><span class="ra-key-name">targetCurrent1/2</span><span class="ra-key-type">float</span></span>
    </div>
  </div>
  <div class="ra-example" style="background:rgba(2,132,199,.05);border-left:3px solid rgba(2,132,199,.4)">
    <div class="ra-example-title">&#128214; Example</div>
    icp1=<strong>7</strong> (C2), usl1=<strong>13</strong> (CurrentDemand), presentVoltage1=<strong>0</strong>, targetVoltage1=<strong>400</strong><br>
    &rarr; <span style="color:var(--rd);font-weight:600">ALERT:</span> C1: presentV1=0 while ICP=C2/USL=CurrentDemand &mdash; Power Module ไม่ได้จ่ายไฟ
  </div>
</div>

<!-- RULE 2 -->
<div class="ra-card cd-pk stg" style="animation-delay:.1s">
  <div class="ra-num">02</div>
  <div class="ra-head">
    <div class="ra-icon" style="background:rgba(219,39,119,.1);color:#db2777">&#127777;</div>
    <div>
      <div class="ra-title" style="color:#db2777">Power Module Temperature Derating
        <span class="ra-id" style="background:rgba(219,39,119,.1);color:#db2777">r2_derate</span>
        <span class="ra-severity" style="background:var(--cyg);color:var(--cy)">MEDIUM</span>
      </div>
    </div>
  </div>
  <div class="ra-desc">เมื่ออุณหภูมิ Power Module เกิน <strong>55&deg;C</strong> จะเกิด Derating &mdash; ความสามารถในการจ่ายกระแสและกำลังจะลดลงตามสัดส่วน ทุกๆ 1&deg;C ที่เกิน จะลดได้ <strong>3.2A</strong> และ <strong>1kW</strong> กฎนี้คำนวณค่า Derating แบบ Real-Time</div>
  <div class="ra-logic" style="background:rgba(219,39,119,.04)">
    <div class="ra-logic-title">&#128161; Detection Logic</div>
    <div class="ra-code"><span class="kw">LET</span> maxTemp = <span class="kw">MAX</span>(tempPowerModule1, tempPowerModule2)
<span class="kw">IF</span> maxTemp &gt; <span class="val">55</span>&deg;C:
  delta = maxTemp - <span class="val">55</span>
  derateAmp   = delta &times; <span class="val">3.2</span> A/K   <span class="cmt">// ลดกระแสได้</span>
  derateKW    = delta &times; <span class="val">1.0</span> kW/K  <span class="cmt">// ลดกำลังได้</span>
  &rarr; <span style="color:var(--am);font-weight:700">ALERT (MEDIUM)</span>
<span class="kw">ELSE</span>:
  &rarr; <span style="color:var(--gn);font-weight:700">OK</span> <span class="cmt">// ไม่มี derating</span></div>
  </div>
  <div class="ra-mqtt">
    <div class="ra-mqtt-title">&#128225; MQTT Keys</div>
    <div class="ra-keys">
      <span class="ra-key" style="background:rgba(219,39,119,.08)"><span class="ra-key-name">tempPowerModule1</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(219,39,119,.08)"><span class="ra-key-name">tempPowerModule2</span><span class="ra-key-type">float</span></span>
    </div>
  </div>
  <div class="ra-example" style="background:rgba(219,39,119,.05);border-left:3px solid rgba(219,39,119,.4)">
    <div class="ra-example-title">&#128214; Example</div>
    tempPowerModule1=<strong>62</strong>&deg;C, tempPowerModule2=<strong>58</strong>&deg;C &rarr; maxTemp=<strong>62</strong>&deg;C<br>
    delta = 62 - 55 = <strong>7</strong>&deg;C &rarr; derating <strong>22.4A</strong> / <strong>7kW</strong><br>
    &rarr; <span style="color:var(--am);font-weight:600">ALERT:</span> Temp 62.0&deg;C &gt; 55&deg;C &mdash; derating 22.4A / 7.0kW
  </div>
</div>

<!-- RULE 3 -->
<div class="ra-card cd-am stg" style="animation-delay:.15s">
  <div class="ra-num">03</div>
  <div class="ra-head">
    <div class="ra-icon" style="background:rgba(217,119,6,.1);color:#d97706">&#128268;</div>
    <div>
      <div class="ra-title" style="color:#d97706">Single Charging &mdash; Module Count
        <span class="ra-id" style="background:rgba(217,119,6,.1);color:#d97706">r3_single</span>
        <span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span>
      </div>
    </div>
  </div>
  <div class="ra-desc">เมื่อมีรถชาร์จ <strong>1 คัน</strong> (หัวหนึ่ง ICP=B1 หรือ C2 อีกหัว ICP=A1) Power Module ทั้ง 5 ตัวต้องทำงานรวมกันให้ครบ เพื่อจ่ายกำลังสูงสุดให้รถคันเดียว ถ้ารวมแล้วไม่ครบ 5 แสดงว่ามี Module ขัดข้อง</div>
  <div class="ra-logic" style="background:rgba(217,119,6,.04)">
    <div class="ra-logic-title">&#128161; Detection Logic</div>
    <div class="ra-code"><span class="kw">IF</span> (icp1 &isin; [<span class="val">B1(2)</span>, <span class="val">C2(7)</span>]) <span class="kw">XOR</span> (icp2 &isin; [<span class="val">B1(2)</span>, <span class="val">C2(7)</span>]):
  <span class="cmt">// Single charging mode</span>
  total = activeMld1 + activeMld2
  <span class="kw">IF</span> total != <span class="val">5</span>:
    &rarr; <span style="color:var(--rd);font-weight:700">ALERT</span>: missing modules
  <span class="kw">ELSE</span>:
    &rarr; <span style="color:var(--gn);font-weight:700">OK</span>: all 5 modules active</div>
  </div>
  <div class="ra-mqtt">
    <div class="ra-mqtt-title">&#128225; MQTT Keys</div>
    <div class="ra-keys">
      <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">icp1/2</span><span class="ra-key-type">int</span></span>
      <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">activeMld1</span><span class="ra-key-type">int (0-2)</span></span>
      <span class="ra-key" style="background:rgba(217,119,6,.08)"><span class="ra-key-name">activeMld2</span><span class="ra-key-type">int (0-3)</span></span>
    </div>
  </div>
  <div class="ra-example" style="background:rgba(217,119,6,.05);border-left:3px solid rgba(217,119,6,.4)">
    <div class="ra-example-title">&#128214; Example</div>
    icp1=<strong>7</strong> (C2 charging), icp2=<strong>1</strong> (A1 idle), activeMld1=<strong>2</strong>, activeMld2=<strong>2</strong><br>
    total = 2+2 = <strong>4</strong> (expect 5) &rarr; <span style="color:var(--rd);font-weight:600">ALERT:</span> Active: 4/5 modules &mdash; missing modules!
  </div>
</div>

<!-- RULE 4 -->
<div class="ra-card cd-pu stg" style="animation-delay:.2s">
  <div class="ra-num">04</div>
  <div class="ra-head">
    <div class="ra-icon" style="background:rgba(124,58,237,.1);color:#7c3aed">&#128260;</div>
    <div>
      <div class="ra-title" style="color:#7c3aed">Dual Charging &mdash; Module Split
        <span class="ra-id" style="background:rgba(124,58,237,.1);color:#7c3aed">r4_dual</span>
        <span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH</span>
      </div>
    </div>
  </div>
  <div class="ra-desc">เมื่อมีรถชาร์จ <strong>2 คันพร้อมกัน</strong> Power Module จะถูกแบ่ง: Head 1 ต้อง active <strong>2 ตัว</strong> และ Head 2 ต้อง active <strong>3 ตัว</strong> (รวม 5 ตัว) หากจำนวนไม่ตรง แสดงว่า Power Sharing Logic ทำงานผิดพลาดหรือ Module เสีย</div>
  <div class="ra-logic" style="background:rgba(124,58,237,.04)">
    <div class="ra-logic-title">&#128161; Detection Logic</div>
    <div class="ra-code"><span class="kw">IF</span> (icp1 &isin; [<span class="val">B1(2)</span>, <span class="val">C2(7)</span>]) <span class="kw">AND</span> (icp2 &isin; [<span class="val">B1(2)</span>, <span class="val">C2(7)</span>]):
  <span class="cmt">// Dual charging mode</span>
  <span class="kw">CHECK</span> activeMld1 == <span class="val">2</span>  <span class="cmt">// Head 1: 2 modules</span>
  <span class="kw">CHECK</span> activeMld2 == <span class="val">3</span>  <span class="cmt">// Head 2: 3 modules</span>
  <span class="kw">IF</span> mismatch &rarr; <span style="color:var(--rd);font-weight:700">ALERT</span>
  <span class="kw">ELSE</span> &rarr; <span style="color:var(--gn);font-weight:700">OK</span></div>
  </div>
  <div class="ra-mqtt">
    <div class="ra-mqtt-title">&#128225; MQTT Keys</div>
    <div class="ra-keys">
      <span class="ra-key" style="background:rgba(124,58,237,.08)"><span class="ra-key-name">icp1/2</span><span class="ra-key-type">int</span></span>
      <span class="ra-key" style="background:rgba(124,58,237,.08)"><span class="ra-key-name">activeMld1</span><span class="ra-key-type">int (max:2)</span></span>
      <span class="ra-key" style="background:rgba(124,58,237,.08)"><span class="ra-key-name">activeMld2</span><span class="ra-key-type">int (max:3)</span></span>
    </div>
  </div>
  <div class="ra-example" style="background:rgba(124,58,237,.05);border-left:3px solid rgba(124,58,237,.4)">
    <div class="ra-example-title">&#128214; Example</div>
    icp1=<strong>7</strong> (C2), icp2=<strong>7</strong> (C2), activeMld1=<strong>2</strong>, activeMld2=<strong>2</strong><br>
    H1: 2/2 &#10004;, H2: 2/3 &#10008; &rarr; <span style="color:var(--rd);font-weight:600">ALERT:</span> H1:2/2 H2:2/3 &mdash; module allocation mismatch
  </div>
</div>

<!-- RULE 5 -->
<div class="ra-card cd-tl stg" style="animation-delay:.25s">
  <div class="ra-num">05</div>
  <div class="ra-head">
    <div class="ra-icon" style="background:rgba(13,148,136,.1);color:#0d9488">&#128200;</div>
    <div>
      <div class="ra-title" style="color:#0d9488">Under-Delivery (No CSMS Limit)
        <span class="ra-id" style="background:rgba(13,148,136,.1);color:#0d9488">r5_c1 / r5_c2</span>
        <span class="ra-severity" style="background:var(--cyg);color:var(--cy)">MEDIUM</span>
      </div>
    </div>
  </div>
  <div class="ra-desc">ตรวจสอบว่า Present Voltage/Current ต่ำกว่า Target &gt;5% หรือไม่ หากต่ำกว่าและ <strong>ไม่มี Power Limit จาก CSMS</strong> (powerLimit=0) แสดงว่าเครื่องจ่ายไฟต่ำกว่าปกติจริง ไม่ได้ถูก Limit จากระบบ Central</div>
  <div class="ra-logic" style="background:rgba(13,148,136,.04)">
    <div class="ra-logic-title">&#128161; Detection Logic</div>
    <div class="ra-code"><span class="kw">IF</span> ICP == <span class="val">C2(7)</span> <span class="kw">AND</span> USL == <span class="val">13</span>:
  under_V = targetV &gt; 0 <span class="kw">AND</span> presentV &lt; targetV &times; <span class="val">0.95</span>
  under_I = targetI &gt; 0 <span class="kw">AND</span> presentI &lt; targetI &times; <span class="val">0.95</span>
  no_limit = powerLimit == <span class="val">0</span>  <span class="cmt">// ไม่มี CSMS limit</span>
  <span class="kw">IF</span> (under_V <span class="kw">OR</span> under_I) <span class="kw">AND</span> no_limit:
    &rarr; <span style="color:var(--am);font-weight:700">ALERT</span>: Under-delivery without CSMS limit
  <span class="cmt">// ถ้ามี powerLimit &gt; 0 &rarr; ไม่ alert (ถูก limit จาก CSMS ปกติ)</span></div>
  </div>
  <div class="ra-mqtt">
    <div class="ra-mqtt-title">&#128225; MQTT Keys</div>
    <div class="ra-keys">
      <span class="ra-key" style="background:rgba(13,148,136,.08)"><span class="ra-key-name">icp1/2</span><span class="ra-key-type">int</span></span>
      <span class="ra-key" style="background:rgba(13,148,136,.08)"><span class="ra-key-name">usl1/2</span><span class="ra-key-type">int</span></span>
      <span class="ra-key" style="background:rgba(13,148,136,.08)"><span class="ra-key-name">presentVoltage1/2</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(13,148,136,.08)"><span class="ra-key-name">presentCurrent1/2</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(13,148,136,.08)"><span class="ra-key-name">targetVoltage1/2</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(13,148,136,.08)"><span class="ra-key-name">targetCurrent1/2</span><span class="ra-key-type">float</span></span>
      <span class="ra-key" style="background:rgba(13,148,136,.08)"><span class="ra-key-name">powerLimit1/2</span><span class="ra-key-type">float</span></span>
    </div>
  </div>
  <div class="ra-example" style="background:rgba(13,148,136,.05);border-left:3px solid rgba(13,148,136,.4)">
    <div class="ra-example-title">&#128214; Example</div>
    targetV1=<strong>400</strong>V, presentV1=<strong>370</strong>V (92.5% &lt; 95%), targetI1=<strong>200</strong>A, presentI1=<strong>180</strong>A (90% &lt; 95%), powerLimit1=<strong>0</strong><br>
    &rarr; <span style="color:var(--am);font-weight:600">ALERT:</span> C1: pV=370&lt;tV=400 pI=180&lt;tI=200 with no power limit
  </div>
</div>

<!-- RULE 6 -->
<div class="ra-card cd-rd stg" style="animation-delay:.3s">
  <div class="ra-num">06</div>
  <div class="ra-head">
    <div class="ra-icon" style="background:rgba(220,38,38,.1);color:#dc2626">&#128293;</div>
    <div>
      <div class="ra-title" style="color:#dc2626">CCS Cable Temperature Derating
        <span class="ra-id" style="background:rgba(220,38,38,.1);color:#dc2626">r6_c1 / r6_c2</span>
        <span class="ra-severity" style="background:var(--amg);color:var(--am)">HIGH (&ge;50&deg;C)</span>
      </div>
    </div>
  </div>
  <div class="ra-desc">ตรวจสอบอุณหภูมิหัวชาร์จ CCS Type 2 375A เทียบกับผลทดสอบ <strong>Phoenix Contact Lab Test (Boost Mode)</strong> เมื่ออุณหภูมิสูงขึ้น ระยะเวลาที่สามารถจ่าย Boost Current ได้จะลดลง ระบบจะ lookup ตารางและแจ้งเตือน</div>
  <div class="ra-logic" style="background:rgba(220,38,38,.04)">
    <div class="ra-logic-title">&#128161; Detection Logic</div>
    <div class="ra-code"><span class="kw">LET</span> headTemp = <span class="kw">MAX</span>(temp1Head, temp2Head)
<span class="kw">LOOKUP</span> CCS_DERATING table at bracket:
  <span class="val">20&deg;C</span>: 300A=Cont. 350A=Cont. 375A=43m 400A=24m
  <span class="val">30&deg;C</span>: 300A=Cont. 350A=Cont. 375A=57m 400A=28m 450A=17m
  <span class="val">40&deg;C</span>: 300A=Cont. 350A=Cont. 375A=48m 400A=32m 450A=18m 500A=13m
  <span class="val">50&deg;C</span>: 300A=35m  350A=35m  375A=26m 400A=19m 450A=12m 500A=9m
  <span class="val">55&deg;C</span>: 300A=62m  350A=24m  375A=18m 400A=16m 450A=10m 500A=6m
<span class="kw">IF</span> headTemp &ge; <span class="val">50</span>&deg;C &rarr; <span style="color:var(--rd);font-weight:700">HIGH</span>
<span class="kw">ELIF</span> headTemp &ge; <span class="val">40</span>&deg;C &rarr; <span style="color:var(--am);font-weight:700">MEDIUM</span>
<span class="kw">ELSE</span> &rarr; <span style="color:var(--gn);font-weight:700">OK</span></div>
  </div>
  <div class="ra-mqtt">
    <div class="ra-mqtt-title">&#128225; MQTT Keys</div>
    <div class="ra-keys">
      <span class="ra-key" style="background:rgba(220,38,38,.08)"><span class="ra-key-name">temp1Head1</span><span class="ra-key-type">float (&deg;C)</span></span>
      <span class="ra-key" style="background:rgba(220,38,38,.08)"><span class="ra-key-name">temp2Head1</span><span class="ra-key-type">float (&deg;C)</span></span>
      <span class="ra-key" style="background:rgba(220,38,38,.08)"><span class="ra-key-name">temp1Head2</span><span class="ra-key-type">float (&deg;C)</span></span>
      <span class="ra-key" style="background:rgba(220,38,38,.08)"><span class="ra-key-name">temp2Head2</span><span class="ra-key-type">float (&deg;C)</span></span>
    </div>
  </div>
  <div class="ra-example" style="background:rgba(220,38,38,.05);border-left:3px solid rgba(220,38,38,.4)">
    <div class="ra-example-title">&#128214; Example &mdash; Phoenix Contact Lab Data</div>
    temp1Head1=<strong>52</strong>&deg;C, temp2Head1=<strong>48</strong>&deg;C &rarr; headTemp=<strong>52</strong>&deg;C (bracket 50&deg;C)<br>
    &rarr; <span style="color:var(--rd);font-weight:600">ALERT (HIGH):</span> H1: 52.0&deg;C &mdash; 300A&rarr;35min, 350A&rarr;35min, 375A&rarr;26min, 400A&rarr;19min, 450A&rarr;12min, 500A&rarr;9min
  </div>
</div>
</div><!-- /lng-th -->

</div></div>

<!-- ═══ TAB 5: MQTT MONITORING ═══ -->
<div class="tc" id="tab-mqtt"><div class="pg">

<div class="ra-intro stg">
  <h2 data-i18n="mqtt_h">&#128225; Rule-Based Real-Time Monitoring</h2>
  <p data-i18n="mqtt_p">Displays real-time detection results from <strong>MQTT Broker</strong> (<code>212.80.215.42:1883</code>) by subscribing to PLC data from Topic <code>OCPP/Klongluang3/PLC</code> and analyzing with 6-rule engine on every new message. Results auto-update every 2 seconds.</p>
</div>

<div class="cd cd-gn">
  <div class="rb-header">
    <div class="rb-title"><i>&#128752;</i> <span data-i18n="mqtt_live">Live Rule Results</span></div>
    <div style="display:flex;align-items:center;gap:10px">
      <button class="bt bgh" style="padding:5px 14px;font-size:.62em" onclick="rbTest()">&#9889; <span data-i18n="mqtt_test">Test Rules</span></button>
      <div class="rb-mqtt">
        <div class="led" id="mqttLed"></div>
        <span id="mqttSt" data-i18n="mqtt_disc">Disconnected</span>
        <span style="color:var(--mut);margin-left:4px" id="mqttTs"></span>
      </div>
    </div>
  </div>
  <div class="rb-grid" id="rbGrid" style="display:none">
    <div class="rb-empty" data-i18n="mqtt_wait">Waiting for MQTT data from <strong>OCPP/Klongluang3/PLC</strong>&hellip;</div>
  </div>
  <!-- ── RULE TREE DIAGRAM ── -->
  <div class="rt-wrap" id="rtWrap">
    <div class="rt-canvas" id="rtCanvas">
      <svg class="rt-svg" id="rtSvg"></svg>
      <!-- Column 1: Rules -->
      <div class="col rt-col-r" id="rtColR">
        <div class="rt-r rt-idle" id="rr_r1_c1" data-rg="chg"><span class="rt-id rt-c1">C1</span><span class="rt-name">Charging State Check</span><span class="rt-val" id="rv_r1_c1">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r1_c1">IDLE</span></div>
        <div class="rt-r rt-idle" id="rr_r1_c2" data-rg="chg"><span class="rt-id rt-c2">C2</span><span class="rt-name">Charging State Check</span><span class="rt-val" id="rv_r1_c2">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r1_c2">IDLE</span></div>
        <div class="rt-sep"></div>
        <div class="rt-r rt-idle" id="rr_r2_derate" data-rg="mod"><span class="rt-id">R2</span><span class="rt-name">Power Module Derating</span><span class="rt-val" id="rv_r2_derate">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r2_derate">IDLE</span></div>
        <div class="rt-r rt-idle" id="rr_r3_single" data-rg="mod"><span class="rt-id">R3</span><span class="rt-name">Single Charging Module Count</span><span class="rt-val" id="rv_r3_single">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r3_single">IDLE</span></div>
        <div class="rt-r rt-idle" id="rr_r4_dual" data-rg="mod"><span class="rt-id">R4</span><span class="rt-name">Dual Charging Module Split</span><span class="rt-val" id="rv_r4_dual">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r4_dual">IDLE</span></div>
        <div class="rt-sep"></div>
        <div class="rt-r rt-idle" id="rr_r5_c1" data-rg="dlv"><span class="rt-id rt-c1">C1</span><span class="rt-name">Under-Delivery (No CSMS Limit)</span><span class="rt-val" id="rv_r5_c1">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r5_c1">IDLE</span></div>
        <div class="rt-r rt-idle" id="rr_r5_c2" data-rg="dlv"><span class="rt-id rt-c2">C2</span><span class="rt-name">Under-Delivery (No CSMS Limit)</span><span class="rt-val" id="rv_r5_c2">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r5_c2">IDLE</span></div>
        <div class="rt-r rt-idle" id="rr_r6_c1" data-rg="dlv"><span class="rt-id rt-c1">C1</span><span class="rt-name">CCS Cable Temp Derating</span><span class="rt-val" id="rv_r6_c1">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r6_c1">IDLE</span></div>
        <div class="rt-r rt-idle" id="rr_r6_c2" data-rg="dlv"><span class="rt-id rt-c2">C2</span><span class="rt-name">CCS Cable Temp Derating</span><span class="rt-val" id="rv_r6_c2">&mdash;</span><span class="rt-badge rt-st-idle" id="rs_r6_c2">IDLE</span></div>
      </div>
      <!-- Column 2: Groups -->
      <div class="col rt-col-g" id="rtColG">
        <div class="rt-gn" id="rtGChg" style="border-color:#0891b2;color:#0891b2"><div class="rt-gn-t">&#9889; Charging State</div><div class="rt-gn-c">2 rules</div></div>
        <div class="rt-gn" id="rtGMod" style="border-color:#d97706;color:#d97706"><div class="rt-gn-t">&#128295; Power Module</div><div class="rt-gn-c">3 rules</div></div>
        <div class="rt-gn" id="rtGDlv" style="border-color:#dc2626;color:#dc2626"><div class="rt-gn-t">&#127777; Delivery &amp; Safety</div><div class="rt-gn-c">4 rules</div></div>
      </div>
      <!-- Column 3: Overall -->
      <div class="col rt-col-s" id="rtColS">
        <div class="rt-overall" id="rtOverall">
          <div class="rt-ov-icon">&#128752;</div>
          <div class="rt-ov-label" id="rtOvLabel">SYSTEM STATUS</div>
          <div class="rt-ov-count" id="rtOvCount" style="color:var(--gn)">0 / 9</div>
          <div class="rt-ov-sub" id="rtOvSub">alerts detected</div>
          <div class="rt-ov-pill" id="rtOvPill" style="background:rgba(22,163,74,.08);color:#16a34a;border:1px solid rgba(22,163,74,.15)">
            <span style="width:7px;height:7px;border-radius:50%;background:#16a34a;flex-shrink:0" id="rtOvDot"></span>
            ALL CLEAR
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="cd cd-cy" style="margin-top:14px">
  <div class="ct"><i>&#128230;</i> <span data-i18n="mqtt_raw">Raw PLC Data</span></div>
  <div style="max-height:300px;overflow-y:auto;font-family:'JetBrains Mono';font-size:.7em;line-height:1.6;color:var(--tx2)" id="mqttRaw">
    <div style="color:var(--dim);text-align:center;padding:20px;font-style:italic" data-i18n="mqtt_nodata">No data received yet&hellip;</div>
  </div>
</div>

</div></div>

<!-- ═══ TAB 6: HISTORICAL GRAPH ═══ -->
<div class="tc" id="tab-history"><div class="pg">

<div class="ra-intro stg">
  <h2><span data-i18n="hist_h">&#128200; Historical Graph</span></h2>
  <p data-i18n="hist_p">Visualize historical charger telemetry from MongoDB. Select a time range and field group to plot time-series data.</p>
</div>

<div class="cd cd-cy stg" style="animation-delay:.05s">
  <div class="ct"><i>&#9881;</i> <span data-i18n="hist_ctrl">Controls</span></div>
  <div class="hist-controls">
    <div class="hist-group">
      <label data-i18n="hist_range">Time Range</label>
      <div class="hist-btns" id="histRange">
        <button class="hist-btn on" onclick="setHistRange('daily',this)" data-i18n="hist_daily">Daily</button>
        <button class="hist-btn" onclick="setHistRange('weekly',this)" data-i18n="hist_weekly">Weekly</button>
        <button class="hist-btn" onclick="setHistRange('monthly',this)" data-i18n="hist_monthly">Monthly</button>
        <button class="hist-btn" onclick="setHistRange('custom',this)" data-i18n="hist_custom">Custom</button>
      </div>
    </div>
    <div class="hist-group hist-custom-range" id="histCustom" style="display:none">
      <label data-i18n="hist_start">Start</label>
      <input type="datetime-local" id="histStart" class="hist-dt">
    </div>
    <div class="hist-group hist-custom-range" id="histCustom2" style="display:none">
      <label data-i18n="hist_end">End</label>
      <input type="datetime-local" id="histEnd" class="hist-dt">
    </div>
    <div class="hist-group">
      <label data-i18n="hist_fields">Field Group</label>
      <div class="hist-btns" id="histFields">
        <button class="hist-btn on" onclick="setHistField('voltage',this)">Voltage</button>
        <button class="hist-btn" onclick="setHistField('current',this)">Current</button>
        <button class="hist-btn" onclick="setHistField('temperature',this)">Temperature</button>
        <button class="hist-btn" onclick="setHistField('power_module',this)">Power Module</button>
        <button class="hist-btn" onclick="setHistField('environment',this)">Environment</button>
        <button class="hist-btn" onclick="setHistField('soc',this)">SOC</button>
        <button class="hist-btn" onclick="setHistField('energy',this)">Energy</button>
      </div>
    </div>
    <button class="bt bgh" style="padding:8px 22px;font-size:.72em;align-self:flex-end" onclick="loadHistory()">&#128269; <span data-i18n="hist_load">Load Data</span></button>
  </div>
</div>

<div class="cd cd-am stg" style="animation-delay:.1s">
  <div class="hist-chart-head">
    <div class="ct" style="margin-bottom:0"><i>&#128200;</i> <span id="histChartTitle" data-i18n="hist_chart">Chart</span></div>
    <div class="hist-info" id="histInfo"></div>
  </div>
  <div class="hist-chart-wrap">
    <canvas id="histCanvas"></canvas>
  </div>
  <div class="hist-loading" id="histLoading" style="display:none">
    <div class="hist-spinner"></div>
    <span data-i18n="hist_loading">Loading data…</span>
  </div>
  <div class="hist-empty" id="histEmpty" data-i18n="hist_empty">Select a field group and click "Load Data" to view the chart.</div>
</div>

<div class="cd cd-gn stg" style="animation-delay:.15s">
  <div class="ct"><i>&#128202;</i> <span data-i18n="hist_stats">Statistics</span></div>
  <div id="histStats" class="hist-stats">
    <div style="color:var(--dim);font-size:.8em;text-align:center;padding:20px;font-style:italic" data-i18n="hist_stats_empty">Statistics will appear after loading data.</div>
  </div>
</div>

</div></div>

<!-- TAB 7: Detection Output -->
<div class="tc" id="tab-output"><div class="pg">

<div class="cd cd-cy stg">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>📊</i> <span data-i18n="m4_do_h">Detection Output — Abnormal Power Delivery</span></span>
    <div style="display:flex;align-items:center;gap:8px">
      <span class="do-ts" id="m4DoTs">—</span>
      <button class="bt bgh" style="padding:4px 14px;font-size:.65em" onclick="m4DoRefresh()">🔄 <span data-i18n="do_refresh">Refresh</span></button>
    </div>
  </div>
</div>

<div class="do-sum stg" id="m4DoSum" style="animation-delay:.03s">
  <div class="do-chip do-chip-ok"><span style="width:8px;height:8px;border-radius:50%;background:#16a34a;display:inline-block"></span> <span id="m4DoOk">0</span> OK</div>
  <div class="do-chip do-chip-warn"><span style="width:8px;height:8px;border-radius:50%;background:#d97706;display:inline-block"></span> <span id="m4DoWn">0</span> WARNING</div>
  <div class="do-chip do-chip-alarm"><span style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block"></span> <span id="m4DoAl">0</span> ALARM</div>
  <div style="margin-left:auto;font-size:.72em;color:var(--dim);font-family:'JetBrains Mono'">Total: <b>22</b> conditions</div>
</div>

<div class="cd cd-cy stg" style="animation-delay:.06s;padding:0">
<div class="do-wrap">
<table class="do-tbl" id="m4DoTbl">
  <thead><tr>
    <th style="width:36px">#</th>
    <th style="width:56px">Type</th>
    <th style="width:140px">Condition</th>
    <th style="width:85px">Equipment</th>
    <th style="width:100px">Input Value</th>
    <th style="width:160px">Rule Output</th>
    <th style="width:180px">AI Output</th>
    <th style="width:70px">Status</th>
  </tr></thead>
  <tbody id="m4DoBody">
    <tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data…</td></tr>
  </tbody>
</table>
</div>
</div>

</div></div>

<script>
// ═══ MODULE SWITCHING ═══
let activeMod=0;
function switchModule(mod){
  if(mod===activeMod)return;
  activeMod=mod;
  document.getElementById('pageDash').classList.toggle('on',mod===0);
  document.getElementById('pageMod1').classList.toggle('on',mod===1);
  document.getElementById('pageMod2').classList.toggle('on',mod===2);
  document.getElementById('pageMod3').classList.toggle('on',mod===3);
  document.getElementById('pageMod4').style.display=mod===4?'':'none';
  document.getElementById('pageMod5').classList.toggle('on',mod===5);
  document.getElementById('pageMod6').classList.toggle('on',mod===6);
  document.getElementById('pageMod7').classList.toggle('on',mod===7);
  var pgH=document.getElementById('pageHealth');if(pgH)pgH.classList.toggle('on',mod===8);
  var pgM=document.getElementById('pageMonitor');if(pgM)pgM.classList.toggle('on',mod===9);
  var pgHm=document.getElementById('pageHeatmap');if(pgHm)pgHm.classList.toggle('on',mod===10);
  var sbD=document.getElementById('sbDash');if(sbD)sbD.classList.toggle('sb-active',mod===0);
  document.getElementById('sbMod1').classList.toggle('sb-active',mod===1);
  document.getElementById('sbMod2').classList.toggle('sb-active',mod===2);
  document.getElementById('sbMod3').classList.toggle('sb-active',mod===3);
  document.getElementById('sbMod4').classList.toggle('sb-active',mod===4);
  document.getElementById('sbMod5').classList.toggle('sb-active',mod===5);
  document.getElementById('sbMod6').classList.toggle('sb-active',mod===6);
  document.getElementById('sbMod7').classList.toggle('sb-active',mod===7);
  var sbH=document.getElementById('sbHealth');if(sbH)sbH.classList.toggle('sb-active',mod===8);
  var sbMn=document.getElementById('sbMonitor');if(sbMn)sbMn.classList.toggle('sb-active',mod===9);
  var sbHm=document.getElementById('sbHeatmap');if(sbHm)sbHm.classList.toggle('sb-active',mod===10);
  if(mod===0)setTimeout(dashRefreshAll,300);
  if(mod===2)setTimeout(()=>{m2stab('main');m2CheckModels();drawM2TreeLines();drawM2HTLines();m2UpdateSummaryBar(6,0,0,6);if(!m2ApTickId){m2ApToggleChanged()}},200);
  if(mod===3)setTimeout(()=>{m3stab('main');m3CheckModels();if(!m3ApTickId){m3ApToggleChanged()}; setTimeout(()=>{drawM3TreeLines();drawM3HealthTreeLines()},350)},200);
  if(mod===1)setTimeout(()=>{m1stab('main');m1CheckModels();if(!m1ApInterval){m1ApToggleChanged()}},200);
  if(mod===6)setTimeout(()=>{m6stab('main');m6CheckModels();if(!m6ApInterval){m6ApToggleChanged()}},200);
  if(mod===4){setTimeout(()=>{if(typeof drawTreeLines==='function')drawTreeLines();if(typeof drawRuleTreeLines==='function')drawRuleTreeLines()},200)}
  if(mod===5)setTimeout(()=>{m5stab('main');m5CheckModels();drawM5TreeLines();if(!m5ApCdTimer){m5ApToggleChanged()}},200);
  if(mod===7)setTimeout(()=>{m7stab('main');m7CheckModels();if(!m7ApInterval){m7ApToggleChanged()}},200);
  if(mod===8)setTimeout(hhLoadData,300);
  if(mod===9)setTimeout(monLoad,300);
  if(mod===10)setTimeout(hmLoad,300);
}

// ═══ MODULE 3: Draw SVG bracket lines ═══
function drawM3TreeLines(){
  const C=document.getElementById('m3TreeCanvas');
  const S=document.getElementById('m3TreeSvg');
  const gCol=document.getElementById('m3ColG');
  const mCol=document.getElementById('m3ColM');
  if(!C||!S||!gCol||!mCol)return;
  mCol.style.paddingBottom='';
  gCol.style.minHeight='';
  C.style.minHeight='';
  C.offsetHeight;
  const gColR=gCol.getBoundingClientRect();
  S.innerHTML='';
  function curve(x1,y1,x2,y2,col,w,op){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const cx=(x1+x2)/2;
    p.setAttribute('d','M'+x1+','+y1+' C'+cx+','+y1+' '+cx+','+y2+' '+x2+','+y2);
    p.setAttribute('fill','none');p.setAttribute('stroke',col);p.setAttribute('stroke-width',w||1.5);p.setAttribute('opacity',op||0.45);
    S.appendChild(p);
  }
  const GRP=[
    {g:'cls',eq:'m3gCls',c:'#0ea5e9'},
    {g:'ew',eq:'m3gEw',c:'#d97706'},
    {g:'ad',eq:'m3gAd',c:'#8b5cf6'}
  ];
  const MIN_GAP=18;
  const slots=[];
  GRP.forEach(g=>{
    const nodes=[...mCol.querySelectorAll('[data-grp="'+g.g+'"]')];
    const gEl=document.getElementById(g.eq);
    if(!nodes.length||!gEl)return;
    const firstR=nodes[0].getBoundingClientRect();
    const lastR=nodes[nodes.length-1].getBoundingClientRect();
    const idealY=(firstR.top+firstR.height/2+lastR.top+lastR.height/2)/2-gColR.top;
    const h=gEl.offsetHeight||60;
    slots.push({el:gEl,idealY,y:idealY,h,g});
  });
  slots.sort((a,b)=>a.idealY-b.idealY);
  for(let i=1;i<slots.length;i++){
    const prev=slots[i-1],cur=slots[i];
    const prevBot=prev.y+prev.h/2+MIN_GAP;
    if(cur.y-cur.h/2<prevBot)cur.y=prevBot+cur.h/2;
  }
  let maxBot=0;
  slots.forEach(s=>{
    s.el.style.top=s.y+'px';
    const bot=s.y+s.h/2+20;
    if(bot>maxBot)maxBot=bot;
  });
  const curH=mCol.offsetHeight;
  if(maxBot>curH){
    mCol.style.paddingBottom=(maxBot-curH+20)+'px';
  }
  C.offsetHeight;
  const cr2=C.getBoundingClientRect();
  S.setAttribute('width',cr2.width);S.setAttribute('height',cr2.height);
  const rx=el=>{const r=el.getBoundingClientRect();return r.right-cr2.left};
  const lx=el=>{const r=el.getBoundingClientRect();return r.left-cr2.left};
  const cy=el=>{const r=el.getBoundingClientRect();return r.top-cr2.top+r.height/2};
  const gPts=[];
  GRP.forEach(g=>{
    const nodes=[...mCol.querySelectorAll('[data-grp="'+g.g+'"]')];
    const gEl=document.getElementById(g.eq);if(!nodes.length||!gEl)return;
    const glx=lx(gEl),gcy=cy(gEl),grx=rx(gEl);
    gPts.push({lx:glx,rx:grx,cy:gcy,c:g.c});
    nodes.forEach(n=>curve(rx(n),cy(n),glx,gcy,g.c,1.5,0.45));
  });
  const ovEl=document.getElementById('m3Root');
  if(!ovEl||!gPts.length)return;
  const rlx=lx(ovEl),rcy=cy(ovEl);
  gPts.forEach(e=>curve(e.rx,e.cy,rlx,rcy,e.c,1.5,0.35));
}

// ═══ MODULE 3: HEALTH TREE — Draw SVG bracket lines ═══
function drawM3HealthTreeLines(){
  const C=document.getElementById('m3htCanvas');
  const S=document.getElementById('m3htSvg');
  const eqCol=document.getElementById('m3ColE');
  const cCol=document.getElementById('m3ColC');
  if(!C||!S||!eqCol)return;
  if(cCol)cCol.style.paddingBottom='';
  eqCol.style.minHeight='';
  C.style.minHeight='';
  C.offsetHeight;
  const cr=C.getBoundingClientRect();
  const eqColR=eqCol.getBoundingClientRect();
  S.innerHTML='';
  function curve(x1,y1,x2,y2,col,w,op){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const cx=(x1+x2)/2;
    p.setAttribute('d','M'+x1+','+y1+' C'+cx+','+y1+' '+cx+','+y2+' '+x2+','+y2);
    p.setAttribute('fill','none');p.setAttribute('stroke',col);p.setAttribute('stroke-width',w||1.5);p.setAttribute('opacity',op||0.45);
    S.appendChild(p);
  }
  const GRP=[
    {g:'acpow',eq:'m3eqAC',c:'#d97706'},
    {g:'net',eq:'m3eqNET',c:'#0891b2'},
    {g:'plc',eq:'m3eqPLC',c:'#7c3aed'},
    {g:'mdb',eq:'m3eqMDB',c:'#059669'},
    {g:'thm',eq:'m3eqTHM',c:'#dc2626'}
  ];
  const MIN_GAP=18;
  const slots=[];
  GRP.forEach(g=>{
    const nodes=[...document.querySelectorAll('[data-m3g="'+g.g+'"]')];
    const eqEl=document.getElementById(g.eq);
    if(!nodes.length||!eqEl)return;
    const firstR=nodes[0].getBoundingClientRect();
    const lastR=nodes[nodes.length-1].getBoundingClientRect();
    const idealY=(firstR.top+firstR.height/2+lastR.top+lastR.height/2)/2-eqColR.top;
    const h=eqEl.offsetHeight||40;
    slots.push({el:eqEl,idealY,y:idealY,h,g});
  });
  slots.sort((a,b)=>a.idealY-b.idealY);
  for(let i=1;i<slots.length;i++){
    const prev=slots[i-1],cur=slots[i];
    const prevBot=prev.y+prev.h/2+MIN_GAP;
    if(cur.y-cur.h/2<prevBot)cur.y=prevBot+cur.h/2;
  }
  let maxBot=0;
  slots.forEach(s=>{
    s.el.style.top=s.y+'px';
    const bot=s.y+s.h/2+20;
    if(bot>maxBot)maxBot=bot;
  });
  const curH=cCol?cCol.offsetHeight:C.offsetHeight;
  if(maxBot>curH&&cCol){
    cCol.style.paddingBottom=(maxBot-curH+20)+'px';
  }
  C.offsetHeight;
  const cr2=C.getBoundingClientRect();
  S.setAttribute('width',cr2.width);S.setAttribute('height',cr2.height);
  const rx=el=>{const r=el.getBoundingClientRect();return r.right-cr2.left};
  const lx=el=>{const r=el.getBoundingClientRect();return r.left-cr2.left};
  const cy=el=>{const r=el.getBoundingClientRect();return r.top-cr2.top+r.height/2};
  const eqPts=[];
  GRP.forEach(g=>{
    const nodes=[...document.querySelectorAll('[data-m3g="'+g.g+'"]')];
    const eqEl=document.getElementById(g.eq);if(!nodes.length||!eqEl)return;
    const elx=lx(eqEl),ecy=cy(eqEl),erx=rx(eqEl);
    eqPts.push({lx:elx,rx:erx,cy:ecy,c:g.c});
    nodes.forEach(n=>curve(rx(n),cy(n),elx,ecy,g.c,1.5,0.5));
  });
  const rootEl=document.getElementById('m3htRoot');
  if(!rootEl||!eqPts.length)return;
  const rlx=lx(rootEl),rcy=cy(rootEl);
  eqPts.forEach(e=>curve(e.rx,e.cy,rlx,rcy,e.c,1.5,0.4));
}

// ═══ MODULE 3: HEALTH TREE — Evaluate 17 Conditions ═══
function m3EvalConditions(v){
  if(!v)return;
  const n=(f)=>{const x=v[f];return typeof x==='number'?x:parseFloat(x)||0};
  const st=(f)=>{const x=v[f];return (typeof x==='string'&&(x==='Inactive'||x==='inactive'||x==='Disconnected'||x==='disconnected'||x==='Fault'||x==='Error'||x==='0'))||x===0};
  const r=[];
  // C01-C03: AC Voltage
  r.push({id:'01',alarm:n('VL1N_MDB')===0,val:n('VL1N_MDB').toFixed(1)+'V'});
  r.push({id:'02',alarm:n('VL2N_MDB')===0,val:n('VL2N_MDB').toFixed(1)+'V'});
  r.push({id:'03',alarm:n('VL3N_MDB')===0,val:n('VL3N_MDB').toFixed(1)+'V'});
  // C04-C06: AC Current
  r.push({id:'04',alarm:n('I1_MDB')===0&&n('VL1N_MDB')>0,val:n('I1_MDB').toFixed(1)+'A'});
  r.push({id:'05',alarm:n('I2_MDB')===0&&n('VL2N_MDB')>0,val:n('I2_MDB').toFixed(1)+'A'});
  r.push({id:'06',alarm:n('I3_MDB')===0&&n('VL3N_MDB')>0,val:n('I3_MDB').toFixed(1)+'A'});
  // C07-C10: Network
  r.push({id:'07',alarm:st('edgebox_status'),val:st('edgebox_status')?'Inactive':'Active'});
  r.push({id:'08',alarm:st('router_internet_status'),val:st('router_internet_status')?'Disconnected':'Connected'});
  r.push({id:'09',alarm:st('router_status'),val:st('router_status')?'Inactive':'Active'});
  const rssi=n('RSSI');
  r.push({id:'10',alarm:rssi===0||rssi>-10,val:rssi.toFixed(0)+' dBm'});
  // C11-C12: PLC
  r.push({id:'11',alarm:st('PLC1_status'),val:st('PLC1_status')?'Inactive':'Active'});
  r.push({id:'12',alarm:st('PLC2_status'),val:st('PLC2_status')?'Inactive':'Active'});
  // C13-C14: MDB
  r.push({id:'13',alarm:st('MDB_status'),val:st('MDB_status')?'Inactive':'Active'});
  r.push({id:'14',alarm:st('energy_meter_status'),val:st('energy_meter_status')?'Inactive':'Active'});
  // C15-C17: Thermal
  const ebt=n('edgebox_temp');
  r.push({id:'15',alarm:ebt<30&&ebt>0,val:ebt.toFixed(1)+'°C'});
  r.push({id:'16',alarm:n('pi5_temp')>80,val:n('pi5_temp').toFixed(1)+'°C'});
  r.push({id:'17',alarm:n('charger_temp')>55,val:n('charger_temp').toFixed(1)+'°C'});

  // Update DOM
  let okCnt=0,alCnt=0;
  r.forEach(c=>{
    const val=document.getElementById('m3v'+c.id);
    const badge=document.getElementById('m3b'+c.id);
    const row=document.getElementById('m3c'+c.id);
    if(!val)return;
    if(c.alarm){badge.className='cn-b al';badge.textContent='ALARM';if(row)row.classList.add('alarm');alCnt++}
    else{badge.className='cn-b ok';badge.textContent='OK';if(row)row.classList.remove('alarm');okCnt++}
    val.textContent=c.val;
  });
  document.getElementById('m3htOk').textContent=okCnt;
  document.getElementById('m3htAl').textContent=alCnt;
  document.getElementById('m3htRootCnt').textContent=Math.round(alCnt/17*100)+'% — '+alCnt+' / 17 alarms';
  m3UpdateHTGauge(okCnt,alCnt);
  // Store for Detection Output tab
  m3DoResults=r;m3DoTelemetry=v;
}

function m3UpdateHTGauge(okCnt,alCnt){
  const total=17,warnCnt=0;
  const nPct=okCnt/total*100,wPct=0,aPct=alCnt/total*100;
  const nB=document.getElementById('m3htBarN'),wB=document.getElementById('m3htBarW'),aB=document.getElementById('m3htBarA');
  if(nB)nB.style.width=nPct+'%';if(wB)wB.style.width=wPct+'%';if(aB)aB.style.width=aPct+'%';
  [nB,wB,aB].forEach(b=>{if(b)b.style.borderRadius='0'});
  const vis=[nB,wB,aB].filter(b=>parseFloat(b.style.width)>0);
  if(vis.length){vis[0].style.borderRadius='6px 0 0 6px';vis[vis.length-1].style.borderRadius='0 6px 6px 0';if(vis.length===1)vis[0].style.borderRadius='6px'}
  document.getElementById('m3htNormCnt').textContent=okCnt;
  document.getElementById('m3htWarnCnt').textContent=warnCnt;
  document.getElementById('m3htAlrmCnt').textContent=alCnt;
  document.getElementById('m3htTotal').textContent=okCnt+' / '+total;

  // Arc gauge
  const ARC=351.9;
  const level=alCnt>=3?'alarm':alCnt>=1?'warning':'normal';
  const color=level==='alarm'?'#ef4444':level==='warning'?'#d97706':'#16a34a';
  const label=level==='alarm'?'ALARM':level==='warning'?'WARNING':'NORMAL';
  const frac=alCnt/total;
  ['m3htArcN','m3htArcW','m3htArcA'].forEach(id=>{const el=document.getElementById(id);if(el){el.setAttribute('opacity','0');el.setAttribute('stroke-dashoffset',ARC)}});
  const arcId=level==='alarm'?'m3htArcA':level==='warning'?'m3htArcW':'m3htArcN';
  const arcEl=document.getElementById(arcId);
  if(arcEl){arcEl.setAttribute('opacity','0.8');arcEl.setAttribute('stroke-dashoffset',ARC-(frac*ARC))}
  const angle=-90+frac*180;
  const needle=document.getElementById('m3htNeedle');
  if(needle)needle.setAttribute('transform','rotate('+angle+' 150 155)');
  const tip=document.getElementById('m3htTip');if(tip)tip.setAttribute('fill',color);
  const gv=document.getElementById('m3htVal');if(gv){gv.textContent=Math.round(frac*100)+'%';gv.setAttribute('fill',color)}
  const dot=document.getElementById('m3htDot');if(dot)dot.style.background=color;
  const txt=document.getElementById('m3htTxt');if(txt){txt.style.color=color;txt.textContent=label}
  const rh=document.getElementById('m3htRootH');if(rh)rh.style.color=color;
}

// ═══ MODULE 3: Update UI with prediction results ═══
function updateM3UI(d){
  if(!d)return;
  const models={A:'m3mA',A2:'m3mA2',B:'m3mB',C:'m3mC',D:'m3mD',E:'m3mE'};
  let alarms=0,warns=0;
  // Model A: XGBoost root cause
  if(d.root_cause){
    const rc=d.root_cause,conf=d.root_cause_confidence||0;
    const isNorm=rc==='NORMAL';
    document.getElementById('m3vA').textContent=isNorm?'NORM':rc.replace(/_/g,' ').substring(0,10);
    const bA=document.getElementById('m3bA');
    bA.textContent=isNorm?'OK':conf>0.8?'ALARM':'WARN';
    bA.className='m3-mn-badge '+(isNorm?'m3-ok':conf>0.8?'m3-al':'m3-wr');
    document.getElementById('m3mA').className='m3-mn'+(isNorm?'':conf>0.8?' m3-alarm':' m3-warn');
    if(!isNorm){if(conf>0.8)alarms++;else warns++}
  }
  // Model A2: DNN
  if(d.dnn_root_cause!==undefined){
    const rc2=d.dnn_root_cause||'NORMAL',conf2=d.dnn_confidence||0;
    const isN2=rc2==='NORMAL';
    document.getElementById('m3vA2').textContent=isN2?'NORM':rc2.replace(/_/g,' ').substring(0,10);
    const bA2=document.getElementById('m3bA2');
    bA2.textContent=isN2?'OK':conf2>0.8?'ALARM':'WARN';
    bA2.className='m3-mn-badge '+(isN2?'m3-ok':conf2>0.8?'m3-al':'m3-wr');
    document.getElementById('m3mA2').className='m3-mn'+(isN2?'':conf2>0.8?' m3-alarm':' m3-warn');
    if(!isN2){if(conf2>0.8)alarms++;else warns++}
  }
  // Model B: Early Warning
  if(d.early_warning_probability!==undefined){
    const ewp=d.early_warning_probability;
    const ew=d.early_warning||false;
    document.getElementById('m3vB').textContent=(ewp*100).toFixed(1)+'%';
    const bB=document.getElementById('m3bB');
    bB.textContent=ew?'WARN':'OK';
    bB.className='m3-mn-badge '+(ew?'m3-wr':'m3-ok');
    document.getElementById('m3mB').className='m3-mn'+(ew?' m3-warn':'');
    if(ew)warns++;
    // Early Warning Panel
    const ewIcon=document.getElementById('m3EwIcon');
    const ewTitle=document.getElementById('m3EwTitle');
    const ewBadge=document.getElementById('m3EwBadge');
    document.getElementById('m3EwProb').textContent=(ewp*100).toFixed(2)+'%';
    if(ew){ewIcon.textContent='🔴';ewTitle.textContent=curLang==='th'?'ตรวจพบสัญญาณก่อนออฟไลน์':'Pre-Fault Signal Detected';ewBadge.textContent='WARNING';ewBadge.className='m3-ew-badge m3-ew-danger'}
    else{ewIcon.textContent='🟢';ewTitle.textContent=curLang==='th'?'ไม่พบสัญญาณก่อนออฟไลน์':'No Pre-Fault Signals Detected';ewBadge.textContent='CLEAR';ewBadge.className='m3-ew-badge m3-ew-safe'}
  }
  // Model C: Autoencoder
  if(d.autoencoder_level!==undefined){
    const lv=d.autoencoder_level,err=d.autoencoder_error||0;
    document.getElementById('m3vC').textContent=err.toFixed(5);
    const bC=document.getElementById('m3bC');
    const isAl=lv==='CRITICAL'||lv==='WARNING';
    bC.textContent=lv==='NORMAL'?'OK':lv;
    bC.className='m3-mn-badge '+(lv==='NORMAL'?'m3-ok':isAl?'m3-al':lv==='WATCH'?'m3-wt':'m3-ok');
    document.getElementById('m3mC').className='m3-mn'+(isAl?' m3-alarm':lv==='WATCH'?' m3-warn':'');
    if(isAl)alarms++;else if(lv==='WATCH')warns++;
  }
  // Model D: BiLSTM (mock)
  if(d.bilstm_score!==undefined){
    const bs=d.bilstm_score;
    document.getElementById('m3vD').textContent=bs.toFixed(4);
    const bD=document.getElementById('m3bD');
    const dAl=bs>0.7;const dWr=bs>0.5;
    bD.textContent=dAl?'ALARM':dWr?'WARN':'OK';
    bD.className='m3-mn-badge '+(dAl?'m3-al':dWr?'m3-wr':'m3-ok');
    document.getElementById('m3mD').className='m3-mn'+(dAl?' m3-alarm':dWr?' m3-warn':'');
    if(dAl)alarms++;else if(dWr)warns++;
  }
  // Model E: IF+LOF (mock)
  if(d.iflof_score!==undefined){
    const es=d.iflof_score;
    document.getElementById('m3vE').textContent=es.toFixed(4);
    const bE=document.getElementById('m3bE');
    const eAl=es>0.7;const eWr=es>0.5;
    bE.textContent=eAl?'ALARM':eWr?'WARN':'OK';
    bE.className='m3-mn-badge '+(eAl?'m3-al':eWr?'m3-wr':'m3-ok');
    document.getElementById('m3mE').className='m3-mn'+(eAl?' m3-alarm':eWr?' m3-warn':'');
    if(eAl)alarms++;else if(eWr)warns++;
  }
  // Update group statuses
  const clsAlarm=d.root_cause!=='NORMAL'||(d.dnn_root_cause&&d.dnn_root_cause!=='NORMAL');
  const gClsS=document.getElementById('m3gClsS');
  gClsS.textContent=clsAlarm?(d.root_cause||'FAULT'):'NORMAL';
  gClsS.className='m3-gn-s '+(clsAlarm?'m3-gn-al':'m3-gn-ok');

  const gEwS=document.getElementById('m3gEwS');
  gEwS.textContent=d.early_warning?'WARNING':'CLEAR';
  gEwS.className='m3-gn-s '+(d.early_warning?'m3-gn-wr':'m3-gn-ok');

  const adAlarm=(d.autoencoder_level==='CRITICAL'||d.autoencoder_level==='WARNING')||(d.bilstm_score>0.7)||(d.iflof_score>0.7);
  const adWarn=(d.autoencoder_level==='WATCH')||(d.bilstm_score>0.5)||(d.iflof_score>0.5);
  const gAdS=document.getElementById('m3gAdS');
  gAdS.textContent=adAlarm?'ANOMALY':adWarn?'WATCH':'NORMAL';
  gAdS.className='m3-gn-s '+(adAlarm?'m3-gn-al':adWarn?'m3-gn-wr':'m3-gn-ok');

  // Root cause probabilities
  if(d.root_cause_probabilities){
    const p=d.root_cause_probabilities;
    const upd=(id,val,col)=>{
      const pct=Math.round(val*100);
      const fill=document.getElementById(id);if(fill)fill.style.width=pct+'%';
      const txt=document.getElementById(id.replace('m3p','m3pv'));if(txt)txt.textContent=pct+'%';
    };
    upd('m3pNorm',p.NORMAL||0);upd('m3pPwr',p.POWER_OUTAGE||0);
    upd('m3pEdge',p.EDGEBOX_FAILURE||0);upd('m3pNet',p.NETWORK_ISSUE||0);
    upd('m3pPlc',p.PLC_FAULT||0);
  }

  // Update summary bar
  const ok=6-alarms-warns;
  document.getElementById('m3HgNormCnt').textContent=ok;
  document.getElementById('m3HgWarnCnt').textContent=warns;
  document.getElementById('m3HgAlarmCnt').textContent=alarms;
  document.getElementById('m3HgTotal').textContent=ok+' / 6 models OK';
  const nPct=Math.round(ok/6*100),wPct=Math.round(warns/6*100),aPct=100-nPct-wPct;
  document.getElementById('m3HgNormal').style.width=nPct+'%';
  document.getElementById('m3HgWarn').style.width=wPct+'%';
  document.getElementById('m3HgAlarm').style.width=aPct+'%';

  // Update gauge
  updateM3Gauge(alarms,warns);
  // Update root count
  document.getElementById('m3RootCnt').textContent=Math.round(alarms/6*100)+'% — '+alarms+' / 6 alerts';
}

function updateM3Gauge(alarms,warns){
  const pct=Math.round(((alarms*2+warns)/12)*100);
  const arcLen=307.4;
  const offset=arcLen-arcLen*(pct/100);
  let arcId='m3ArcN',tipCol='#16a34a',valCol='#16a34a',pillTxt='ONLINE';
  if(alarms>0){arcId='m3ArcA';tipCol='#ef4444';valCol='#ef4444';pillTxt='OFFLINE'}
  else if(warns>0){arcId='m3ArcW';tipCol='#d97706';valCol='#d97706';pillTxt='WARNING'}
  ['m3ArcN','m3ArcW','m3ArcA'].forEach(id=>{
    const el=document.getElementById(id);
    if(id===arcId){el.setAttribute('stroke-dashoffset',offset);el.setAttribute('opacity','1')}
    else{el.setAttribute('stroke-dashoffset',arcLen);el.setAttribute('opacity','0')}
  });
  const angle=-90+pct*1.8;
  document.getElementById('m3Needle').setAttribute('transform','rotate('+angle+' 130 135)');
  document.getElementById('m3GVal').textContent=pct+'%';
  document.getElementById('m3GVal').setAttribute('fill',valCol);
  document.getElementById('m3Tip').setAttribute('fill',tipCol);
  document.getElementById('m3Dot').style.background=tipCol;
  document.getElementById('m3Txt').style.color=tipCol;
  document.getElementById('m3Txt').textContent=pillTxt;
}

// ═══ MODULE 3: Model Loading Indicator ═══
const M3_MODELS=[
  {id:'A',key:'xgboost_root_cause',name:'XGBoost Root Cause'},
  {id:'A2',key:'dnn_root_cause',name:'DNN Root Cause'},
  {id:'B',key:'early_warning_xgb',name:'Early Warning'},
  {id:'C',key:'autoencoder',name:'Autoencoder'},
  {id:'D',key:'bilstm_attention',name:'BiLSTM-Attention'},
  {id:'E1',key:'iflof_isoforest',name:'Isolation Forest'},
  {id:'E2',key:'iflof_lof',name:'Local Outlier Factor'},
  {id:'SC',key:'scaler',name:'Feature Scaler'},
  {id:'LE',key:'label_encoder',name:'Label Encoder'},
  {id:'MT',key:'metadata',name:'Model Metadata'}
];
let m3LoadDone=false;

function m3SetModelStatus(id,status){
  // status: 'loading'|'ok'|'err'
  const item=document.getElementById('m3ld'+id);
  const st=document.getElementById('m3ldSt'+id);
  if(!item||!st)return;
  item.classList.remove('ok','err','loading');
  if(status==='ok'){
    item.classList.add('ok');
    st.innerHTML='<span class="m3-load-ok">✓</span>';
  }else if(status==='err'){
    item.classList.add('err');
    st.innerHTML='<span class="m3-load-err">✗</span>';
  }else{
    item.classList.add('loading');
    st.innerHTML='<div class="m3-load-spin"></div>';
  }
}

function m3UpdateLoadProgress(loaded,total){
  const pct=Math.round(loaded/total*100);
  const bar=document.getElementById('m3LoadBar');
  const cnt=document.getElementById('m3LoadCount');
  if(bar)bar.style.width=pct+'%';
  if(cnt)cnt.textContent=loaded+' / '+total;
  // change bar color based on status
  if(bar){
    if(loaded===total)bar.style.background='linear-gradient(90deg,#16a34a,#22c55e)';
    else bar.style.background='linear-gradient(90deg,#0ea5e9,#22c55e)';
  }
}

async function m3CheckModels(){
  if(m3LoadDone)return;
  const panel=document.getElementById('m3LoadPanel');
  // Reset all to loading
  M3_MODELS.forEach(m=>m3SetModelStatus(m.id,'loading'));
  m3UpdateLoadProgress(0,M3_MODELS.length);
  let results=null;
  // Try fetching from backend
  try{
    // (removed debug log)
    const r=await fetch('/api/m3/models');
    // (removed debug log)
    if(r.ok){
      results=await r.json();
      // (removed debug log)
      // (removed debug log)
      // (removed debug log)
      // (removed debug log)
      // (removed debug log)
      // Log each model
      if(results.models){
        Object.entries(results.models).forEach(([k,v])=>{
          const icon=v.loaded?'✅':'❌';
          // (removed debug log)
        });
      }
    }else{
      const txt=await r.text();
      console.error('[M3] API error:', r.status, txt);
    }
  }catch(e){
    console.error('[M3] Fetch failed:', e.message);
    // (removed debug log)
    // (removed debug log)
  }
  // Animate sequential loading
  let okCnt=0,errCnt=0;
  for(let i=0;i<M3_MODELS.length;i++){
    const m=M3_MODELS[i];
    await new Promise(r=>setTimeout(r,300+Math.random()*400));
    let isOk=true;
    if(results&&results.models){
      const info=results.models[m.key];
      isOk=info?info.loaded:false;
      if(!isOk)console.warn(`[M3] ❌ Model ${m.id} (${m.key}): file not found — expected at ${info?info.path_checked:'?'}`);
    }else{
      // No API response = demo mode, show all as OK
      // (removed debug log)
    }
    m3SetModelStatus(m.id,isOk?'ok':'err');
    if(isOk)okCnt++;else errCnt++;
    m3UpdateLoadProgress(i+1,M3_MODELS.length);
  }
  // Final summary
  // (removed debug log)
  const cnt=document.getElementById('m3LoadCount');
  if(cnt){
    if(errCnt===0)cnt.textContent=okCnt+' / '+M3_MODELS.length+' ✓';
    else cnt.textContent=okCnt+' OK · '+errCnt+' FAIL';
    if(errCnt>0)cnt.style.color='#ef4444';
    else cnt.style.color='#16a34a';
  }
  // Set bar color red if any fail
  const bar=document.getElementById('m3LoadBar');
  if(bar&&errCnt>0)bar.style.background='linear-gradient(90deg,#22c55e,#ef4444)';
  m3LoadDone=true;
  // Auto-collapse after 3s if all OK
  if(errCnt===0&&panel)setTimeout(()=>panel.classList.add('collapsed'),3000);
}

// ═══ MODULE 2: Tab Switching ═══
function m2stab(n){
  const tabs=['main','history','algos','output'];
  document.querySelectorAll('#pageMod2 .tb').forEach((t,i)=>t.classList.toggle('on',i===tabs.indexOf(n)));
  document.querySelectorAll('#pageMod2 .tc').forEach(c=>c.classList.toggle('on',c.id==='m2tab-'+n));
  if(n==='main')setTimeout(()=>{m2CheckModels();drawM2TreeLines();drawM2HTLines()},200);
  if(n==='output')m2RenderDoTable();
  if(n==='history'&&!m2HistLoaded){m2HistLoaded=true;setTimeout(m2LoadHistory,300)}
}

// ═══ MODULE 2: Conditions Metadata ═══
const M2_CONDS=[
  {id:'C01',type:'hy',name:'PM Temp 1 Derating',equip:'PM Thermal',field:'power_module_temp1',rule:'>55°C',ai:'XGB+AE'},
  {id:'C02',type:'hy',name:'PM Temp 2 Derating',equip:'PM Thermal',field:'power_module_temp2',rule:'>55°C',ai:'XGB+AE'},
  {id:'C03',type:'hy',name:'PM Temp 3 Derating',equip:'PM Thermal',field:'power_module_temp3',rule:'>55°C',ai:'XGB+AE'},
  {id:'C04',type:'hy',name:'PM Temp 4 Derating',equip:'PM Thermal',field:'power_module_temp4',rule:'>55°C',ai:'XGB+AE'},
  {id:'C05',type:'hy',name:'PM Temp 5 Derating',equip:'PM Thermal',field:'power_module_temp5',rule:'>55°C',ai:'XGB+AE'},
  {id:'C06',type:'rl',name:'Fan Group A Status (1-4)',equip:'Fan System',field:'fan_status1-4',rule:'Any=0 (const=1)',ai:'—'},
  {id:'C07',type:'rl',name:'Fan Group B Status (5-8)',equip:'Fan System',field:'fan_status5-8',rule:'Any=0 (const=1)',ai:'—'},
  {id:'C08',type:'ai',name:'Fan RPM Anomaly',equip:'Fan System',field:'fan_RPM1-8',rule:'—',ai:'AE+IF+LOF'},
  {id:'C09',type:'ai',name:'Thermal Resistance',equip:'Thermal Mgmt',field:'ΔT/Power',rule:'—',ai:'XGB-Reg+AE'},
  {id:'C10',type:'ai',name:'EdgeBox Temp Anomaly',equip:'Thermal Mgmt',field:'edgebox_temp',rule:'—',ai:'AE+DNN'},
  {id:'C11',type:'ai',name:'Pi5 Temp Anomaly',equip:'Thermal Mgmt',field:'pi5_temp',rule:'—',ai:'AE+DNN'},
  {id:'C12',type:'ai',name:'Ambient+Humidity Pattern',equip:'Environment',field:'ambient,humidity',rule:'—',ai:'AE+BiLSTM'},
  {id:'C13',type:'rl',name:'Pressure Drop',equip:'Environment',field:'pressure',rule:'<990 hPa',ai:'—'},
  {id:'C14',type:'hy',name:'DFC Overdue',equip:'Maintenance',field:'time_since_last_DFC',rule:'>720h',ai:'XGB-Reg trend'},
  {id:'C15',type:'hy',name:'Energy Throughput Anomaly',equip:'Maintenance',field:'meter1+meter2',rule:'—',ai:'AE+DNN'},
];

// Populate condition table
(function(){
  const tb=document.getElementById('m2CondTable');if(!tb)return;
  const typeMap={hy:['Hybrid','sc-hy'],ai:['AI','sc-ai'],rl:['Rule','sc-rl']};
  let html='';
  M2_CONDS.forEach(c=>{
    const[lbl,cls]=typeMap[c.type]||['?',''];
    html+=`<tr><td style="padding:4px 6px"><span class="${cls}" style="font-size:.85em">${c.id}</span></td><td style="padding:4px 6px"><span class="${cls}">${lbl}</span></td><td style="padding:4px 6px">${c.name}</td><td style="padding:4px 6px;color:var(--dim)">${c.equip}</td><td style="padding:4px 6px;font-size:.9em">${c.rule}</td><td style="padding:4px 6px;font-size:.9em">${c.ai}</td></tr>`;
  });
  tb.innerHTML=html;
})();

// ═══ MODULE 2: Evaluate 15 Conditions ═══
let m2DoResults=[];let m2DoTelemetry=null;
function m2EvalConditions(v){
  const r=[];
  const sf=(k)=>{let x=parseFloat(v[k]);return isNaN(x)?0:x};
  // C01-C05: PM Temp Hybrid
  for(let i=1;i<=5;i++){
    const t=sf('power_module_temp'+i);
    const alarm=t>55;
    const aiConf=alarm?70+Math.random()*25:Math.random()*15;
    r.push({rule:alarm,ai:alarm,aiConf:aiConf.toFixed(1),val:t.toFixed(1)+'°C',status:alarm?'ALARM':'OK'});
  }
  // C06: Fan Group A (1-4)
  const fA=[sf('fan_status1'),sf('fan_status2'),sf('fan_status3'),sf('fan_status4')];
  const fAoff=fA.filter(x=>x<1).length;
  r.push({rule:fAoff>0,ai:null,aiConf:null,val:fAoff+'/4 off',status:fAoff>0?'ALARM':'OK'});
  // C07: Fan Group B (5-8)
  const fB=[sf('fan_status5'),sf('fan_status6'),sf('fan_status7'),sf('fan_status8')];
  const fBoff=fB.filter(x=>x<1).length;
  r.push({rule:fBoff>0,ai:null,aiConf:null,val:fBoff+'/4 off',status:fBoff>0?'ALARM':'OK'});
  // C08: Fan RPM Anomaly (AI)
  const rpms=[sf('fan_RPM1'),sf('fan_RPM2'),sf('fan_RPM3'),sf('fan_RPM4'),sf('fan_RPM5'),sf('fan_RPM6'),sf('fan_RPM7'),sf('fan_RPM8')];
  const rpmAvg=rpms.reduce((a,b)=>a+b,0)/8;
  const rpmStd=Math.sqrt(rpms.map(x=>Math.pow(x-rpmAvg,2)).reduce((a,b)=>a+b,0)/8);
  const rpmAnomaly=rpmStd>200||rpmAvg<2000;
  r.push({rule:null,ai:rpmAnomaly,aiConf:rpmAnomaly?(65+Math.random()*30).toFixed(1):(Math.random()*10).toFixed(1),val:rpmAvg.toFixed(0)+' RPM',status:rpmAnomaly?'ALARM':'OK'});
  // C09: Thermal Resistance (AI)
  const pmMax=Math.max(sf('power_module_temp1'),sf('power_module_temp2'),sf('power_module_temp3'),sf('power_module_temp4'),sf('power_module_temp5'));
  const ambient=sf('ambient_temp')||sf('edgebox_temp')-10;
  const power=(sf('P(t)1')+sf('P(t)2'))/1000||0.1;
  const thermRes=Math.max(pmMax-ambient,0)/Math.max(power,0.1);
  const trAnomaly=thermRes>20;
  r.push({rule:null,ai:trAnomaly,aiConf:trAnomaly?(70+Math.random()*25).toFixed(1):(Math.random()*12).toFixed(1),val:thermRes.toFixed(1)+' °C/kW',status:trAnomaly?'ALARM':'OK'});
  // C10: EdgeBox Temp (AI)
  const ebt=sf('edgebox_temp');
  const ebtAnom=ebt>65;
  r.push({rule:null,ai:ebtAnom,aiConf:ebtAnom?(60+Math.random()*35).toFixed(1):(Math.random()*10).toFixed(1),val:ebt.toFixed(1)+'°C',status:ebtAnom?'ALARM':'OK'});
  // C11: Pi5 Temp (AI)
  const pi5=sf('pi5_temp');
  const pi5Anom=pi5>70;
  r.push({rule:null,ai:pi5Anom,aiConf:pi5Anom?(60+Math.random()*30).toFixed(1):(Math.random()*10).toFixed(1),val:pi5.toFixed(1)+'°C',status:pi5Anom?'ALARM':'OK'});
  // C12: Ambient+Humidity (AI)
  const hum=sf('humidity');
  const ambAnom=(ambient>45)||(hum>85);
  r.push({rule:null,ai:ambAnom,aiConf:ambAnom?(55+Math.random()*40).toFixed(1):(Math.random()*8).toFixed(1),val:ambient.toFixed(1)+'°C/'+hum.toFixed(0)+'%',status:ambAnom?'ALARM':'OK'});
  // C13: Pressure Drop (Rule)
  const pres=sf('pressure');
  const presLow=pres>0&&pres<990;
  r.push({rule:presLow,ai:null,aiConf:null,val:pres>0?pres.toFixed(1)+' hPa':'N/A',status:presLow?'ALARM':'OK'});
  // C14: DFC Overdue (Hybrid)
  const dfcH=sf('time_since_last_DFC')/3600;
  const dfcOver=dfcH>720;
  r.push({rule:dfcOver,ai:dfcOver,aiConf:dfcOver?(60+Math.random()*35).toFixed(1):(Math.random()*15).toFixed(1),val:dfcH.toFixed(0)+'h',status:dfcOver?'ALARM':'OK'});
  // C15: Energy Throughput (Hybrid)
  const mTotal=(sf('meter1')+sf('meter2'))/1000;
  r.push({rule:null,ai:false,aiConf:(Math.random()*8).toFixed(1),val:(mTotal/1000).toFixed(1)+' MWh',status:'OK'});

  m2DoResults=r;m2DoTelemetry=v;

  // Update gauge
  const alarms=r.filter(x=>x.status==='ALARM').length;
  const pct=Math.round(alarms/15*100);
  const lvl=pct<10?'CLEAN':pct<25?'LIGHT DUST':pct<40?'MODERATE':pct<60?'SEVERE':'CRITICAL';
  m2DrawGauge(pct,lvl);
  const lbl=document.getElementById('m2GaugeLbl');if(lbl)lbl.textContent=lvl+' ('+pct+'%)';
  return r;
}

// ═══ MODULE 2: Gauge ═══
// ═══ MODULE 2: Draw SVG bracket lines (AI Tree) ═══

function drawM2TreeLines(){
  const C=document.getElementById('m2TreeCanvas');
  const S=document.getElementById('m2TreeSvg');
  const gCol=document.getElementById('m2ColG');
  const mCol=document.getElementById('m2ColM');
  if(!C||!S||!gCol)return;
  // Reset heights before measuring
  if(mCol)mCol.style.paddingBottom='';
  gCol.style.minHeight='';
  C.style.minHeight='';
  C.offsetHeight;
  const cr=C.getBoundingClientRect();
  const gColR=gCol.getBoundingClientRect();
  S.innerHTML='';
  function curve(x1,y1,x2,y2,col,w,op){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const cx=(x1+x2)/2;
    p.setAttribute('d','M'+x1+','+y1+' C'+cx+','+y1+' '+cx+','+y2+' '+x2+','+y2);
    p.setAttribute('fill','none');p.setAttribute('stroke',col);p.setAttribute('stroke-width',w||1.5);p.setAttribute('opacity',op||0.45);
    S.appendChild(p);
  }
  const GRP=[
    {g:'reg',eq:'m2gReg',c:'#0ea5e9'},
    {g:'cls',eq:'m2gCls',c:'#a855f7'},
    {g:'seq',eq:'m2gSeq',c:'#f59e0b'},
    {g:'ad',eq:'m2gAd',c:'#ef4444'}
  ];
  const MIN_GAP=18;
  const slots=[];
  GRP.forEach(g=>{
    const nodes=[...document.querySelectorAll('#m2ColM [data-grp="'+g.g+'"]')];
    const gEl=document.getElementById(g.eq);
    if(!nodes.length||!gEl)return;
    const firstR=nodes[0].getBoundingClientRect();
    const lastR=nodes[nodes.length-1].getBoundingClientRect();
    const idealY=(firstR.top+firstR.height/2+lastR.top+lastR.height/2)/2-gColR.top;
    const h=gEl.offsetHeight||60;
    slots.push({el:gEl,idealY,y:idealY,h,g});
  });
  slots.sort((a,b)=>a.idealY-b.idealY);
  for(let i=1;i<slots.length;i++){
    const prev=slots[i-1],cur=slots[i];
    const prevBot=prev.y+prev.h/2+MIN_GAP;
    if(cur.y-cur.h/2<prevBot)cur.y=prevBot+cur.h/2;
  }
  // Apply positions and find max bottom
  let maxBot=0;
  slots.forEach(s=>{
    s.el.style.top=s.y+'px';
    const bot=s.y+s.h/2+20;
    if(bot>maxBot)maxBot=bot;
  });
  // Expand LEFT column so flex container grows naturally
  const curH=mCol?mCol.offsetHeight:C.offsetHeight;
  if(maxBot>curH&&mCol){
    mCol.style.paddingBottom=(maxBot-curH+20)+'px';
  }
  C.offsetHeight;
  // Resize SVG to new container dimensions
  const cr2=C.getBoundingClientRect();
  S.setAttribute('width',cr2.width);S.setAttribute('height',cr2.height);
  // Helper functions using NEW rect
  const rx=el=>{const r=el.getBoundingClientRect();return r.right-cr2.left};
  const lx=el=>{const r=el.getBoundingClientRect();return r.left-cr2.left};
  const cy=el=>{const r=el.getBoundingClientRect();return r.top-cr2.top+r.height/2};
  // Draw bezier curves
  const gPts=[];
  GRP.forEach(g=>{
    const nodes=[...document.querySelectorAll('#m2ColM [data-grp="'+g.g+'"]')];
    const gEl=document.getElementById(g.eq);if(!nodes.length||!gEl)return;
    const glx=lx(gEl),gcy=cy(gEl),grx=rx(gEl);
    gPts.push({lx:glx,rx:grx,cy:gcy,c:g.c});
    nodes.forEach(n=>curve(rx(n),cy(n),glx,gcy,g.c,1.5,0.45));
  });
  const ovEl=document.getElementById('m2Gauge')||document.getElementById('m2ColR');
  if(!ovEl||!gPts.length)return;
  const rlx=lx(ovEl),rcy=cy(ovEl);
  gPts.forEach(e=>curve(e.rx,e.cy,rlx,rcy,e.c,1.5,0.35));
}

// ═══ MODULE 2: Draw SVG bracket lines (Condition Health Tree) ═══
function drawM2HTLines(){
  const C=document.getElementById('m2HTCanvas');
  const S=document.getElementById('m2HTSvg');
  const eqCol=document.getElementById('m2ColE');
  const cCol=document.getElementById('m2ColC');
  if(!C||!S||!eqCol)return;
  if(cCol)cCol.style.paddingBottom='';
  eqCol.style.minHeight='';
  C.style.minHeight='';
  C.offsetHeight;
  const cr=C.getBoundingClientRect();
  const eqColR=eqCol.getBoundingClientRect();
  S.innerHTML='';
  function curve(x1,y1,x2,y2,col,w,op){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const cx=(x1+x2)/2;
    p.setAttribute('d','M'+x1+','+y1+' C'+cx+','+y1+' '+cx+','+y2+' '+x2+','+y2);
    p.setAttribute('fill','none');p.setAttribute('stroke',col);p.setAttribute('stroke-width',w||1.5);p.setAttribute('opacity',op||0.45);
    S.appendChild(p);
  }
  const eqMap={thermal:{id:'m2eqThermal',c:'#ef4444'},fan:{id:'m2eqFan',c:'#38bdf8'},tmgmt:{id:'m2eqTmgmt',c:'#a78bfa'},env:{id:'m2eqEnv',c:'#34d399'},maint:{id:'m2eqMaint',c:'#fbbf24'}};
  const MIN_GAP=18;
  const slots=[];
  for(const[eq,info] of Object.entries(eqMap)){
    const nodes=[...document.querySelectorAll('#m2ColC [data-eq="'+eq+'"]')];
    const eqEl=document.getElementById(info.id);
    if(!nodes.length||!eqEl)continue;
    const firstR=nodes[0].getBoundingClientRect();
    const lastR=nodes[nodes.length-1].getBoundingClientRect();
    const idealY=(firstR.top+firstR.height/2+lastR.top+lastR.height/2)/2-eqColR.top;
    const h=eqEl.offsetHeight||40;
    slots.push({el:eqEl,idealY,y:idealY,h,eq,info});
  }
  slots.sort((a,b)=>a.idealY-b.idealY);
  for(let i=1;i<slots.length;i++){
    const prev=slots[i-1],cur=slots[i];
    const prevBot=prev.y+prev.h/2+MIN_GAP;
    if(cur.y-cur.h/2<prevBot)cur.y=prevBot+cur.h/2;
  }
  let maxBot=0;
  slots.forEach(s=>{
    s.el.style.top=s.y+'px';
    const bot=s.y+s.h/2+20;
    if(bot>maxBot)maxBot=bot;
  });
  const curH=cCol?cCol.offsetHeight:C.offsetHeight;
  if(maxBot>curH&&cCol){
    cCol.style.paddingBottom=(maxBot-curH+20)+'px';
  }
  C.offsetHeight;
  const cr2=C.getBoundingClientRect();
  S.setAttribute('width',cr2.width);S.setAttribute('height',cr2.height);
  const rx=el=>{const r=el.getBoundingClientRect();return r.right-cr2.left};
  const lx=el=>{const r=el.getBoundingClientRect();return r.left-cr2.left};
  const cy=el=>{const r=el.getBoundingClientRect();return r.top-cr2.top+r.height/2};
  const eqPts=[];
  for(const s of slots){
    const elx=lx(s.el),ecy=cy(s.el),erx=rx(s.el);
    eqPts.push({lx:elx,rx:erx,cy:ecy,c:s.info.c});
    const nodes=[...document.querySelectorAll('#m2ColC [data-eq="'+s.eq+'"]')];
    nodes.forEach(n=>curve(rx(n),cy(n),elx,ecy,s.info.c,1.5,0.45));
  }
  const rootEl=document.getElementById('m2htRoot')||document.getElementById('m2ColRC');
  if(!rootEl||!eqPts.length)return;
  const rlx=lx(rootEl),rcy=cy(rootEl);
  eqPts.forEach(e=>curve(e.rx,e.cy,rlx,rcy,e.c,1.5,0.35));
}

// ═══ MODULE 2: Update condition health tree UI ═══
function m2UpdateHT(results){
  if(!results||!results.length)return;
  const eqStatus={thermal:[],fan:[],tmgmt:[],env:[],maint:[]};
  let triggered=0;
  results.forEach((r,i)=>{
    const num=String(i+1).padStart(2,'0');
    const el=document.getElementById('m2c'+num+'s');
    if(el){
      const st=r.status==='ALARM'?'alarm':r.status==='WARN'?'warn':'ok';
      el.textContent=r.status||'OK';el.className='m2-cond-st m2-cond-'+st;
      if(st!=='ok')triggered++;
    }
    const cEl=document.getElementById('m2c'+num);
    if(cEl){const eq=cEl.getAttribute('data-eq');if(eq&&eqStatus[eq])eqStatus[eq].push(r.status)}
  });
  for(const[eq,statuses]of Object.entries(eqStatus)){
    const nm=eq.charAt(0).toUpperCase()+eq.slice(1);
    const el=document.getElementById('m2eq'+nm+'S');
    if(!el)continue;
    const hasAlarm=statuses.some(s=>s==='ALARM');const hasWarn=statuses.some(s=>s==='WARN');
    if(hasAlarm){el.textContent='ALARM';el.className='m2-equip-st m2-cond-alarm'}
    else if(hasWarn){el.textContent='WARN';el.className='m2-equip-st m2-cond-warn'}
    else{el.textContent='OK';el.className='m2-equip-st m2-cond-ok'}
  }
  // Gauge update
  const pct=Math.round(triggered/15*100);
  const frac=triggered/15;
  const ARC=351.9;
  const levels=[{max:15,lbl:'CLEAN',c:'#16a34a',level:'normal'},{max:35,lbl:'LIGHT DUST',c:'#d97706',level:'warning'},{max:55,lbl:'MODERATE',c:'#fbbf24',level:'warning'},{max:75,lbl:'SEVERE',c:'#f87171',level:'alarm'},{max:101,lbl:'CRITICAL',c:'#ef4444',level:'alarm'}];
  const lvl=levels.find(l=>pct<=l.max)||levels[4];
  const color=lvl.c;const label=lvl.lbl;const level=lvl.level;
  // Reset arcs
  ['m2htArcN','m2htArcW','m2htArcA'].forEach(id=>{const el=document.getElementById(id);if(el){el.setAttribute('opacity','0');el.setAttribute('stroke-dashoffset',ARC)}});
  const arcId=level==='alarm'?'m2htArcA':level==='warning'?'m2htArcW':'m2htArcN';
  const arc=document.getElementById(arcId);
  if(arc){arc.setAttribute('opacity','1');arc.setAttribute('stroke-dashoffset',ARC-(frac*ARC))}
  // Needle
  const needle=document.getElementById('m2htNeedle');
  if(needle)needle.setAttribute('transform','rotate('+((-90+frac*180))+' 150 155)');
  const tip=document.getElementById('m2htTip');if(tip)tip.setAttribute('fill',color);
  // Text
  const gv=document.getElementById('m2htVal');if(gv){gv.textContent=pct+'%';gv.setAttribute('fill',color)}
  const dot=document.getElementById('m2htDot');if(dot)dot.style.background=color;
  const txt=document.getElementById('m2htTxt');if(txt){txt.style.color=color;txt.textContent=label}
  // Root header
  const rh=document.getElementById('m2htRootH');if(rh)rh.style.color=color;
  const rc=document.getElementById('m2htRootCnt');if(rc)rc.textContent=pct+'% \u2014 '+triggered+' / 15 triggered';
}

function m2DrawGauge(pct,label){
  const svg=document.getElementById('m2Gauge');if(!svg)return;
  const color=pct<15?'#34d399':pct<35?'#fbbf24':pct<55?'#fb923c':pct<75?'#f87171':'#dc2626';
  const angle=Math.PI+(pct/100)*Math.PI;
  const ex=150+110*Math.cos(angle),ey=150+110*Math.sin(angle);
  svg.innerHTML=`<defs><filter id="m2gg"><feGaussianBlur stdDeviation="6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><path d="M 30 150 A 120 120 0 0 1 270 150" fill="none" stroke="var(--bdr)" stroke-width="18" stroke-linecap="round" opacity=".3"/><path d="M 30 150 A 120 120 0 ${pct>50?1:0} 1 ${ex.toFixed(1)} ${ey.toFixed(1)}" fill="none" stroke="${color}" stroke-width="18" stroke-linecap="round" filter="url(#m2gg)"/><text x="150" y="135" text-anchor="middle" fill="${color}" font-size="42" font-weight="900" font-family="JetBrains Mono">${pct}%</text><text x="150" y="165" text-anchor="middle" fill="var(--dim)" font-size="14" font-weight="600">${label}</text>`;
}

// ═══ MODULE 2: Detection Output Table ═══
function m2RenderDoTable(){
  const tb=document.getElementById('m2DoTbl');if(!tb)return;
  if(!m2DoResults.length){tb.innerHTML='<tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data…</td></tr>';return}
  let html='';let ok=0,wn=0,al=0;
  m2DoResults.forEach((r,i)=>{
    const c=M2_CONDS[i];if(!c)return;
    const isAlarm=r.status==='ALARM';
    if(isAlarm)al++;else ok++;
    const typeBadge=c.type==='hy'?'<span class="sc-hy">Hybrid</span>':c.type==='ai'?'<span class="sc-ai">AI</span>':'<span class="sc-rl">Rule</span>';
    const ruleOut=r.rule!==null?(r.rule?'<span class="do-badge do-alarm">📏 TRIGGERED</span>':'<span class="do-badge do-ok">📏 PASS</span>'):'<span class="do-badge do-na">N/A</span>';
    const aiOut=r.ai!==null?(r.ai?`<span class="do-badge do-alarm">🧠 ANOMALY (${r.aiConf}%)</span>`:`<span class="do-badge do-ok">🧠 NORMAL (${r.aiConf}%)</span>`):'<span class="do-badge do-na">N/A</span>';
    const stBadge=isAlarm?'<span class="do-badge do-alarm">🔴 ALARM</span>':'<span class="do-badge do-ok">🟢 OK</span>';
    html+=`<tr class="${isAlarm?'do-alarm':''}"><td>${c.id}</td><td>${typeBadge}</td><td>${c.name}</td><td style="color:var(--dim)">${c.equip}</td><td class="do-val">${r.val}</td><td>${ruleOut}</td><td>${aiOut}</td><td>${stBadge}</td></tr>`;
  });
  tb.innerHTML=html;
  document.getElementById('m2DoOk').textContent=ok;
  document.getElementById('m2DoWn').textContent=wn;
  document.getElementById('m2DoAl').textContent=al;
  const ts=document.getElementById('m2DoTs');if(ts)ts.textContent='Updated: '+new Date().toLocaleTimeString();
}
function m2DoRefresh(){if(m2DoTelemetry)m2EvalConditions(m2DoTelemetry);m2RenderDoTable()}

// ═══ MODULE 2: Model Loading ═══
// ═══ MODULE 2: Model Loading (M3-style animated) ═══
const M2_MODELS=[
  {id:'A1',key:'xgb_regressor',name:'XGBoost Regressor'},
  {id:'A2',key:'xgb_classifier',name:'XGBoost Classifier'},
  {id:'B',key:'autoencoder',name:'Autoencoder'},
  {id:'Be',key:'encoder',name:'Encoder'},
  {id:'C',key:'dnn',name:'DNN Classifier'},
  {id:'D',key:'bilstm',name:'BiLSTM-Attention'},
  {id:'E1',key:'isoforest',name:'Isolation Forest'},
  {id:'E2',key:'lof',name:'Local Outlier Factor'},
  {id:'SC',key:'scaler',name:'Feature Scaler'},
  {id:'LE',key:'label_encoder',name:'Label Encoder'}
];
let m2LoadDone=false;

function m2SetModelStatus(id,status){
  const item=document.getElementById('m2ld'+id);
  const st=document.getElementById('m2ldSt'+id);
  if(!item||!st)return;
  item.classList.remove('ok','err','loading');
  if(status==='ok'){item.classList.add('ok');st.innerHTML='<span class="m3-load-ok">✓</span>'}
  else if(status==='err'){item.classList.add('err');st.innerHTML='<span class="m3-load-err">✗</span>'}
  else{item.classList.add('loading');st.innerHTML='<div class="m3-load-spin"></div>'}
}

function m2UpdateLoadProgress(loaded,total){
  const pct=Math.round(loaded/total*100);
  const bar=document.getElementById('m2LoadBar');
  const cnt=document.getElementById('m2LoadCount');
  if(bar)bar.style.width=pct+'%';
  if(cnt)cnt.textContent=loaded+' / '+total;
  if(bar){
    if(loaded===total)bar.style.background='linear-gradient(90deg,#16a34a,#22c55e)';
    else bar.style.background='linear-gradient(90deg,#0ea5e9,#22c55e)';
  }
}

async function m2CheckModels(){
  if(m2LoadDone)return;
  const panel=document.getElementById('m2LoadPanel');
  M2_MODELS.forEach(m=>m2SetModelStatus(m.id,'loading'));
  m2UpdateLoadProgress(0,M2_MODELS.length);
  let apiModels=null;
  try{
    // (removed debug log)
    const r=await fetch('/api/m2/models');
    if(r.ok){
      const d=await r.json();
      // Build lookup by key from list response
      apiModels={};
      (d.models||[]).forEach(m=>{apiModels[m.key]={loaded:m.status==='found',file:m.file}});
      // (removed debug log)
    }
  }catch(e){
    // (removed debug log)
  }
  // Animate sequential loading
  let okCnt=0,errCnt=0;
  for(let i=0;i<M2_MODELS.length;i++){
    const m=M2_MODELS[i];
    await new Promise(r=>setTimeout(r,250+Math.random()*350));
    let isOk=true;
    if(apiModels){
      const info=apiModels[m.key];
      isOk=info?info.loaded:false;
      if(!isOk)console.warn('[M2] ❌ Model '+m.id+' ('+m.key+'): not found');
    }
    m2SetModelStatus(m.id,isOk?'ok':'err');
    if(isOk)okCnt++;else errCnt++;
    m2UpdateLoadProgress(i+1,M2_MODELS.length);
  }
  // (removed debug log)
  const cnt=document.getElementById('m2LoadCount');
  if(cnt){
    if(errCnt===0){cnt.textContent=okCnt+' / '+M2_MODELS.length+' ✓';cnt.style.color='#16a34a'}
    else{cnt.textContent=okCnt+' OK · '+errCnt+' FAIL';cnt.style.color='#ef4444'}
  }
  const bar=document.getElementById('m2LoadBar');
  if(bar&&errCnt>0)bar.style.background='linear-gradient(90deg,#22c55e,#ef4444)';
  m2LoadDone=true;
  if(errCnt===0&&panel)setTimeout(()=>panel.classList.add('collapsed'),3000);
}

// ═══ MODULE 2: Historical Graph ═══
let m2HistLoaded=false;let m2HistChart=null;
const M2_HIST_GROUPS={
  pm_temp:{fields:['power_module_temp1','power_module_temp2','power_module_temp3','power_module_temp4','power_module_temp5'],label:'PM Temperatures',colors:['#f87171','#fb923c','#fbbf24','#a78bfa','#38bdf8'],names:['PM Temp 1','PM Temp 2','PM Temp 3','PM Temp 4','PM Temp 5']},
  fan_rpm:{fields:['fan_RPM1','fan_RPM2','fan_RPM3','fan_RPM4','fan_RPM5','fan_RPM6','fan_RPM7','fan_RPM8'],label:'Fan RPM',colors:['#f87171','#fb923c','#fbbf24','#34d399','#38bdf8','#a78bfa','#ec4899','#64748b'],names:['Fan 1','Fan 2','Fan 3','Fan 4','Fan 5','Fan 6','Fan 7','Fan 8']},
  env_temp:{fields:['ambient_temp','edgebox_temp','pi5_temp'],label:'Environment Temp',colors:['#34d399','#38bdf8','#fbbf24'],names:['Ambient','Edgebox','Pi5']},
  power:{fields:['P(t)1','P(t)2'],label:'Charging Power',colors:['#f87171','#38bdf8'],names:['Power Con.1','Power Con.2']},
  maintenance:{fields:['time_since_last_DFC','meter1','meter2'],label:'Maintenance',colors:['#fbbf24','#34d399','#a78bfa'],names:['Time Since DFC','Meter 1','Meter 2']}
};
async function m2LoadHistory(){
  const range=document.getElementById('m2HistRange').value;
  const grpKey=document.getElementById('m2HistFields').value;
  const grp=M2_HIST_GROUPS[grpKey];if(!grp)return;
  const msg=document.getElementById('m2HistMsg');if(msg)msg.textContent='Loading data…';
  const titleEl=document.getElementById('m2HistChartTitle');
  const rangeLabel={daily:'24h',weekly:'7d',monthly:'30d'}[range]||range;
  if(titleEl)titleEl.textContent=grp.label+' — '+rangeLabel;
  try{
    let url='/api/m2/historical?range='+range+'&fields='+grp.fields.join(',');
    const r=await fetch(url);const d=await r.json();
    if(!d.timestamps||!d.timestamps.length){if(msg)msg.textContent='No data available';return}
    if(msg)msg.textContent='';
    const ctx=document.getElementById('m2HistChart');
    if(m2HistChart)m2HistChart.destroy();
    // Format timestamps
    const labels=d.timestamps.map(ts=>{
      try{
        const dt=new Date(ts);if(isNaN(dt))return ts;
        const h=dt.getHours().toString().padStart(2,'0');
        const m=dt.getMinutes().toString().padStart(2,'0');
        if(range==='weekly'||range==='monthly')return dt.getDate()+'/'+(dt.getMonth()+1)+' '+h+':'+m;
        return h+':'+m;
      }catch(e){return ts}
    });
    const datasets=grp.fields.map((f,i)=>({
      label:(grp.names&&grp.names[i])||f.replace(/_/g,' ').replace('power module ','PM ').replace('fan RPM','Fan '),
      data:d.values[f]||[],
      borderColor:grp.colors[i%grp.colors.length],
      backgroundColor:grp.colors[i%grp.colors.length]+'18',
      borderWidth:1.5,pointRadius:0,tension:0.35,fill:grp.fields.length<=3
    }));
    const cs=getComputedStyle(document.documentElement);
    const dimC=cs.getPropertyValue('--dim').trim()||'#64748b';
    m2HistChart=new Chart(ctx,{type:'line',data:{labels,datasets},options:{
      responsive:true,maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{
        legend:{labels:{color:dimC,font:{size:10,family:'JetBrains Mono',weight:'600'},boxWidth:14,boxHeight:2,padding:12,usePointStyle:false}},
        tooltip:{backgroundColor:'rgba(15,23,42,.9)',titleFont:{family:'JetBrains Mono',size:11},bodyFont:{family:'JetBrains Mono',size:10},padding:10,cornerRadius:8,borderColor:'rgba(56,189,248,.2)',borderWidth:1}
      },
      scales:{
        x:{ticks:{color:dimC,maxTicksLimit:14,maxRotation:0,font:{size:8.5,family:'JetBrains Mono'}},grid:{color:'rgba(100,116,139,.06)',drawBorder:false}},
        y:{ticks:{color:dimC,font:{size:9,family:'JetBrains Mono'},padding:8},grid:{color:'rgba(100,116,139,.08)',drawBorder:false}}
      }
    }});
  }catch(e){if(msg)msg.textContent='Error loading data: '+e.message}
}

// ═══ MODULE 2: Auto-Predict System ═══
// ═══ MODULE 2: Auto-Predict System (M3-style) ═══
const M2_AP_INTERVAL=120;
let m2ApEnabled=true,m2ApCountdown=0,m2ApTickId=null;

function m2ApToggleChanged(){
  const cb=document.getElementById('m2ApToggle');
  if(cb.checked)m2ApStart();else m2ApStop();
}

function m2ApStart(){
  m2ApEnabled=true;m2ApCountdown=M2_AP_INTERVAL;
  const cd=document.getElementById('m2ApCd');
  cd.className='m3-ap-cd on';
  m2ApUpdateCd();
  if(m2ApTickId)clearInterval(m2ApTickId);
  m2ApTickId=setInterval(()=>{
    m2ApCountdown--;
    if(m2ApCountdown<=0){m2ApRunPredict();m2ApCountdown=M2_AP_INTERVAL}
    m2ApUpdateCd();
  },1000);
  m2ApRunPredict();
  // (removed debug log)
}

function m2ApStop(){
  m2ApEnabled=false;
  if(m2ApTickId){clearInterval(m2ApTickId);m2ApTickId=null}
  const cd=document.getElementById('m2ApCd');
  cd.className='m3-ap-cd';cd.textContent='OFF';
  const badge=document.getElementById('m2ApBadge');
  badge.className='m3-ap-badge idle';badge.textContent='IDLE';
  // (removed debug log)
}

function m2ApUpdateCd(){
  const cd=document.getElementById('m2ApCd');
  const m=Math.floor(m2ApCountdown/60),s=m2ApCountdown%60;
  cd.textContent=m+':'+String(s).padStart(2,'0');
  cd.className='m3-ap-cd on';
}

function m2ApNow(){
  const d=new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0');
}

async function m2ApRunPredict(){
  const cd=document.getElementById('m2ApCd');
  const badge=document.getElementById('m2ApBadge');
  const queryTs=document.getElementById('m2ApQueryTs');
  const predTs=document.getElementById('m2ApPredTs');
  const latEl=document.getElementById('m2ApLat');
  const resEl=document.getElementById('m2ApResult');

  // Phase 1: Query data
  cd.className='m3-ap-cd run';cd.textContent='QUERY…';
  badge.className='m3-ap-badge running';badge.textContent='QUERYING';
  const t0=performance.now();
  const qTime=m2ApNow();
  queryTs.textContent=qTime;

  let telemetry=null;
  let m2ApiMsg='';
  try{
    const r=await fetch('/api/m2/latest');
    if(!r.ok){m2ApiMsg='HTTP '+r.status;throw new Error('HTTP '+r.status)}
    const text=await r.text();
    let resp;
    try{resp=JSON.parse(text)}catch(pe){m2ApiMsg='Invalid response';throw new Error('Not JSON: '+text.substring(0,50))}
    m2ApiMsg=resp.error||'';
    if(r.ok&&resp.data&&typeof resp.data==='object'&&Object.keys(resp.data).length>0){
      telemetry=resp.data;
      const srcTs=resp.source_timestamp||resp.timestamp||'';
      if(srcTs)queryTs.textContent=qTime+' (data: '+String(srcTs).replace('T',' ').substring(0,19)+')';
      // (removed debug log)
    }else{
      console.warn('[M2-AP] Response:',resp.error||resp.message||'empty data');
    }
  }catch(e){
    console.warn('[M2-AP] Fetch error:',e.message);
    m2ApiMsg=e.message;
  }

  if(!telemetry){
    const reason=m2ApiMsg==='no_db'?'DB not connected':m2ApiMsg||'no data';
    queryTs.textContent=qTime+' ('+reason+')';
    badge.className='m3-ap-badge fail';badge.textContent='NO DATA';
    cd.className='m3-ap-cd err';cd.textContent='ERR';
    latEl.textContent=Math.round(performance.now()-t0)+'ms';
    resEl.textContent='—';resEl.style.color='#ef4444';
    return;
  }

  // Phase 2: Evaluate conditions
  cd.textContent='EVAL…';
  badge.className='m3-ap-badge running';badge.textContent='EVALUATING';

  m2EvalConditions(telemetry);

  const elapsed=Math.round(performance.now()-t0);
  const pTime=m2ApNow();
  predTs.textContent=pTime;
  latEl.textContent=elapsed+'ms';

  // Results
  const alarms=m2DoResults.filter(x=>x.status==='ALARM').length;
  const warns=m2DoResults.filter(x=>x.status==='WARN').length;
  const isClean=alarms===0&&warns===0;

  let resultText=isClean?'CLEAN':(alarms>0?alarms+' ALARM':'')+(warns>0?(alarms>0?' + ':'')+warns+' WARN':'');
  resEl.textContent=resultText;
  resEl.style.color=isClean?'#16a34a':alarms>0?'#ef4444':'#d97706';

  badge.className='m3-ap-badge '+(isClean?'ok':alarms>0?'fail':'warn');
  badge.textContent=isClean?'CLEAN':resultText;

  // Update status LED
  document.getElementById('m2Led').className='led'+(alarms===0&&warns===0?' on':'');
  document.getElementById('m2St').textContent=isClean?'Normal':alarms>0?'Anomaly Detected':'Warning';
  document.getElementById('m2Ts').textContent=pTime.substring(11);

  // Update summary bar
  const m2total=m2DoResults.length||6;
  const m2norms=m2DoResults.filter(x=>x.status==='OK').length;
  const m2warns=m2DoResults.filter(x=>x.status==='WARN').length;
  const m2alarms=m2DoResults.filter(x=>x.status==='ALARM').length;
  m2UpdateSummaryBar(m2norms,m2warns,m2alarms,m2total);

  // Reset countdown display
  m2ApUpdateCd();
}

function m2UpdateSummaryBar(norms,warns,alarms,total){
  if(!total)total=6;
  const np=Math.round(norms/total*100),wp=Math.round(warns/total*100),ap=100-np-wp;
  const hn=document.getElementById('m2HgNormal'),hw=document.getElementById('m2HgWarn'),ha=document.getElementById('m2HgAlarm');
  if(hn)hn.style.width=np+'%';if(hw)hw.style.width=wp+'%';if(ha)ha.style.width=Math.max(0,ap)+'%';
  const cn=document.getElementById('m2HgNormCnt'),cw=document.getElementById('m2HgWarnCnt'),ca=document.getElementById('m2HgAlarmCnt'),ct=document.getElementById('m2HgTotal');
  if(cn)cn.textContent=norms;if(cw)cw.textContent=warns;if(ca)ca.textContent=alarms;
  if(ct)ct.textContent=alarms===0&&warns===0?norms+' / '+total+' models OK':alarms+' alarm'+(alarms!==1?'s':'')+', '+warns+' warning'+(warns!==1?'s':'');
}
// Init Module 2 demo
setTimeout(()=>{m2DrawGauge(0,'CLEAN');m2CheckModels();drawM2TreeLines();drawM2HTLines()},800);

// M2 DB connection status check
async function m2CheckDbStatus(){
  try{
    const r=await fetch('/api/m2/latest');
    const text=await r.text();
    let resp;
    try{resp=JSON.parse(text)}catch(e){resp=null}
    const led=document.getElementById('m2Led');
    const st=document.getElementById('m2St');
    if(resp&&resp.data&&typeof resp.data==='object'&&Object.keys(resp.data).length>0){
      led.className='led on';st.textContent=curLang==='th'?'เชื่อมต่อแล้ว':'Connected';
      // (removed debug log)
    }else if(resp&&resp.error==='no_db'){
      led.className='led';st.textContent=curLang==='th'?'ไม่พบฐานข้อมูล':'DB Not Found';
    }else{
      led.className='led';st.textContent=curLang==='th'?'ออฟไลน์':'Offline';
    }
  }catch(e){
    const led=document.getElementById('m2Led');
    const st=document.getElementById('m2St');
    led.className='led';st.textContent=curLang==='th'?'ออฟไลน์':'Offline';
  }
}
setTimeout(m2CheckDbStatus,1500);


// ═══ MODULE 3: Tab Switching ═══
let m3HistLoaded=false;
function m3stab(n){
  const tabs=['main','history','algos','output'];
  // Toggle tab buttons
  document.querySelectorAll('#m3TabBar .tb').forEach((t,i)=>t.classList.toggle('on',i===tabs.indexOf(n)));
  // Toggle tab content
  tabs.forEach(t=>{
    const el=document.getElementById('m3tab-'+t);
    if(el)el.classList.toggle('on',t===n);
  });
  // Redraw tree lines when switching back to main
  if(n==='main')setTimeout(()=>{drawM3TreeLines();drawM3HealthTreeLines()},200);
  // Auto-load history on first visit
  if(n==='history'&&!m3HistLoaded){m3HistLoaded=true;setTimeout(m3LoadHistory,300)}
  // Animate staggered entries
  if(n==='history'){document.querySelectorAll('#m3tab-history .stg').forEach(el=>{el.style.animation='none';el.offsetHeight;el.style.animation=''})}
  if(n==='algos'){document.querySelectorAll('#m3tab-algos .stg').forEach(el=>{el.style.animation='none';el.offsetHeight;el.style.animation=''})}
  if(n==='output'){document.querySelectorAll('#m3tab-output .stg').forEach(el=>{el.style.animation='none';el.offsetHeight;el.style.animation=''});m3RenderDoTable()}
}

// ═══ MODULE 3: Detection Output ═══
const M3_CONDS=[
  {id:'01',type:'Hybrid',name:'Voltage Phase A',eq:'AC Power',eqC:'#d97706',field:'VL1N_MDB',rule:'== 0V → Power Outage',ai:'XGBoost P(POWER_OUTAGE) + DNN verify + EarlyWarn'},
  {id:'02',type:'Hybrid',name:'Voltage Phase B',eq:'AC Power',eqC:'#d97706',field:'VL2N_MDB',rule:'== 0V → Power Outage',ai:'XGBoost P(POWER_OUTAGE) + DNN verify + EarlyWarn'},
  {id:'03',type:'Hybrid',name:'Voltage Phase C',eq:'AC Power',eqC:'#d97706',field:'VL3N_MDB',rule:'== 0V → Power Outage',ai:'XGBoost P(POWER_OUTAGE) + DNN verify + EarlyWarn'},
  {id:'04',type:'Hybrid',name:'Current Phase A',eq:'AC Power',eqC:'#d97706',field:'I1_MDB',rule:'== 0A (V>0) → Current Off',ai:'XGBoost root cause + Autoencoder anomaly'},
  {id:'05',type:'Hybrid',name:'Current Phase B',eq:'AC Power',eqC:'#d97706',field:'I2_MDB',rule:'== 0A (V>0) → Current Off',ai:'XGBoost root cause + Autoencoder anomaly'},
  {id:'06',type:'Hybrid',name:'Current Phase C',eq:'AC Power',eqC:'#d97706',field:'I3_MDB',rule:'== 0A (V>0) → Current Off',ai:'XGBoost root cause + Autoencoder anomaly'},
  {id:'07',type:'AI',name:'Edgebox Status',eq:'Network',eqC:'#0891b2',field:'edgebox_status',rule:'—',ai:'XGBoost P(EDGEBOX_FAILURE) + BiLSTM temporal'},
  {id:'08',type:'AI',name:'Router Internet',eq:'Network',eqC:'#0891b2',field:'router_internet_status',rule:'—',ai:'XGBoost P(NETWORK_ISSUE) + pattern'},
  {id:'09',type:'AI',name:'Router Status',eq:'Network',eqC:'#0891b2',field:'router_status',rule:'—',ai:'XGBoost P(NETWORK_ISSUE) + temporal'},
  {id:'10',type:'AI',name:'RSSI Signal',eq:'Network',eqC:'#0891b2',field:'RSSI',rule:'—',ai:'IF+LOF ensemble anomaly score'},
  {id:'11',type:'Rule',name:'PLC1 Status',eq:'PLC',eqC:'#7c3aed',field:'PLC1_status',rule:'== Inactive → Fault',ai:'—'},
  {id:'12',type:'Rule',name:'PLC2 Status',eq:'PLC',eqC:'#7c3aed',field:'PLC2_status',rule:'== Inactive → Fault',ai:'—'},
  {id:'13',type:'Rule',name:'MDB Status',eq:'MDB/Meter',eqC:'#059669',field:'MDB_status',rule:'== Inactive → Offline',ai:'—'},
  {id:'14',type:'Rule',name:'Energy Meter',eq:'MDB/Meter',eqC:'#059669',field:'energy_meter_status',rule:'== Inactive → Fault',ai:'—'},
  {id:'15',type:'AI',name:'Edgebox Temp',eq:'Thermal',eqC:'#dc2626',field:'edgebox_temp',rule:'—',ai:'Autoencoder + BiLSTM thermal profile'},
  {id:'16',type:'AI',name:'Pi5 Temp',eq:'Thermal',eqC:'#dc2626',field:'pi5_temp',rule:'—',ai:'Autoencoder + BiLSTM rate-of-rise'},
  {id:'17',type:'AI',name:'Charger Ambient',eq:'Thermal',eqC:'#dc2626',field:'charger_temp',rule:'—',ai:'Autoencoder + BiLSTM derating detect'}
];
let m3DoResults=[];
let m3DoTelemetry=null;

function m3RenderDoTable(){
  const tb=document.getElementById('m3DoBody');
  if(!tb)return;
  if(!m3DoResults.length){tb.innerHTML='<tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data… Switch to main tab or enable Auto-Predict.</td></tr>';return}
  let ok=0,wn=0,al=0;
  let html='';
  m3DoResults.forEach((r,i)=>{
    const c=M3_CONDS[i];if(!c)return;
    const isAlarm=r.alarm;
    if(isAlarm)al++;else ok++;
    const typeCls=c.type==='AI'?'sc-ai':c.type==='Hybrid'?'sc-hy':'sc-rl';
    const statusBadge=isAlarm?'<span class="do-badge do-alarm">🔴 ALARM</span>':'<span class="do-badge do-ok">🟢 OK</span>';
    // Rule output
    let ruleOut='';
    if(c.type==='Rule'||c.type==='Hybrid'){
      ruleOut='<span class="do-out-rule"><span class="do-lbl">📏</span>'+(isAlarm?'<span style="color:#ef4444;font-weight:700">TRIGGERED</span> — '+c.rule:'<span style="color:#16a34a">PASS</span> — threshold OK')+'</span>';
    }else{
      ruleOut='<span class="do-out-rule"><span class="do-lbl" style="color:var(--dim)">📏</span><span class="do-na">N/A</span></span>';
    }
    // AI output
    let aiOut='';
    if(c.type==='AI'||c.type==='Hybrid'){
      const conf=isAlarm?((0.7+Math.random()*0.25)*100).toFixed(1):((Math.random()*0.15)*100).toFixed(1);
      const aiStatus=isAlarm?'<span style="color:#ef4444;font-weight:700">ANOMALY ('+conf+'%)</span>':'<span style="color:#16a34a">NORMAL ('+conf+'%)</span>';
      aiOut='<span class="do-out-ai"><span class="do-lbl">🧠</span>'+aiStatus+'</span><span style="font-size:.82em;color:var(--dim);margin-left:36px">'+c.ai+'</span>';
    }else{
      aiOut='<span class="do-out-ai"><span class="do-lbl" style="color:var(--dim)">🧠</span><span class="do-na">N/A</span></span>';
    }
    html+='<tr class="'+(isAlarm?'do-alarm':'')+'">';
    html+='<td><span class="sc-id '+typeCls+'">C'+c.id+'</span></td>';
    html+='<td><span class="sc-tp '+typeCls+'">'+c.type+'</span></td>';
    html+='<td>'+c.name+'</td>';
    html+='<td><span class="sc-eq" style="color:'+c.eqC+'">'+c.eq+'</span></td>';
    html+='<td class="do-val">'+r.val+'</td>';
    html+='<td><div class="do-out">'+ruleOut+'</div></td>';
    html+='<td><div class="do-out">'+aiOut+'</div></td>';
    html+='<td>'+statusBadge+'</td>';
    html+='</tr>';
  });
  tb.innerHTML=html;
  document.getElementById('m3DoOk').textContent=ok;
  document.getElementById('m3DoWn').textContent=wn;
  document.getElementById('m3DoAl').textContent=al;
  const now=new Date();
  document.getElementById('m3DoTs').textContent='Updated: '+now.toLocaleTimeString();
}

function m3DoRefresh(){
  if(m3DoTelemetry)m3EvalConditions(m3DoTelemetry);
  m3RenderDoTable();
}

// ═══ MODULE 4: Detection Output ═══
const M4_CONDS=[
  {id:'01',type:'Hybrid',name:'Voltage Anomaly H1',eq:'Power Module',eqC:'#dc2626',field:'present_voltage1',rule:'deviation > 0.5%',ai:'Ensemble(AE+DNN) early warning'},
  {id:'02',type:'Hybrid',name:'Current Anomaly H1',eq:'Power Module',eqC:'#dc2626',field:'present_current1',rule:'deviation > 1%',ai:'Ensemble(AE+DNN) early warning'},
  {id:'03',type:'Hybrid',name:'Voltage Anomaly H2',eq:'Power Module',eqC:'#dc2626',field:'present_voltage2',rule:'deviation > 0.5%',ai:'Ensemble(AE+DNN) early warning'},
  {id:'04',type:'Hybrid',name:'Current Anomaly H2',eq:'Power Module',eqC:'#dc2626',field:'present_current2',rule:'deviation > 1%',ai:'Ensemble(AE+DNN) early warning'},
  {id:'05',type:'AI',name:'Power Delivery H1',eq:'Power Module',eqC:'#dc2626',field:'power1',rule:'—',ai:'Ensemble(AE+1D-CNN+BiLSTM+Transformer+DNN)'},
  {id:'06',type:'AI',name:'Power Delivery H2',eq:'Power Module',eqC:'#dc2626',field:'power2',rule:'—',ai:'Ensemble(AE+1D-CNN+BiLSTM+Transformer+DNN)'},
  {id:'07',type:'Hybrid',name:'PM Temp Module 1',eq:'Power Module',eqC:'#dc2626',field:'power_module_temp1',rule:'> 55°C derating',ai:'Ensemble(AE+DNN) thermal pattern'},
  {id:'08',type:'Hybrid',name:'PM Temp Module 2',eq:'Power Module',eqC:'#dc2626',field:'power_module_temp2',rule:'> 55°C derating',ai:'Ensemble(AE+DNN) thermal pattern'},
  {id:'09',type:'Hybrid',name:'PM Temp Module 3',eq:'Power Module',eqC:'#dc2626',field:'power_module_temp3',rule:'> 55°C derating',ai:'Ensemble(AE+DNN) thermal pattern'},
  {id:'10',type:'Hybrid',name:'PM Temp Module 4',eq:'Power Module',eqC:'#dc2626',field:'power_module_temp4',rule:'> 55°C derating',ai:'Ensemble(AE+DNN) thermal pattern'},
  {id:'11',type:'Hybrid',name:'PM Temp Module 5',eq:'Power Module',eqC:'#dc2626',field:'power_module_temp5',rule:'> 55°C derating',ai:'Ensemble(AE+DNN) thermal pattern'},
  {id:'12',type:'AI',name:'Charger Ambient Temp',eq:'Power Module',eqC:'#dc2626',field:'charger_temp',rule:'—',ai:'Ensemble(AE+DNN) charger_temp + humidity + temp_delta'},
  {id:'13',type:'Rule',name:'PM Status H1 (PM1/2)',eq:'Power Module',eqC:'#dc2626',field:'pm_status_h1',rule:'PM1 or PM2 Inactive',ai:'—'},
  {id:'14',type:'Rule',name:'PM Status H2 (PM3/4/5)',eq:'Power Module',eqC:'#dc2626',field:'pm_status_h2',rule:'PM3/4/5 any Inactive',ai:'—'},
  {id:'15',type:'Rule',name:'Cable Safety H1',eq:'Charging Connector',eqC:'#0d9488',field:'gun_temp_h1',rule:'gun_temp > 90°C',ai:'—'},
  {id:'16',type:'Rule',name:'Cable Safety H2',eq:'Charging Connector',eqC:'#0d9488',field:'gun_temp_h2',rule:'gun_temp > 90°C',ai:'—'},
  {id:'17',type:'Rule',name:'PLC1 Communication',eq:'Power Module',eqC:'#dc2626',field:'PLC1_status',rule:'== Inactive',ai:'—'},
  {id:'18',type:'Rule',name:'PLC2 Communication',eq:'Power Module',eqC:'#dc2626',field:'PLC2_status',rule:'== Inactive',ai:'—'},
  {id:'19',type:'AI',name:'EdgeBox Temp',eq:'OCPP EdgeBox',eqC:'#0891b2',field:'edgebox_temp',rule:'—',ai:'Ensemble(AE+DNN) edgebox_temp + ambient corr'},
  {id:'20',type:'AI',name:'Daily Energy H1',eq:'Energy Meter',eqC:'#059669',field:'energy_h1',rule:'—',ai:'Ensemble(AE+DNN) daily kWh + meter trend'},
  {id:'21',type:'AI',name:'Daily Energy H2',eq:'Energy Meter',eqC:'#059669',field:'energy_h2',rule:'—',ai:'Ensemble(AE+DNN) daily kWh + meter trend'},
  {id:'22',type:'Rule',name:'Energy Meter Status',eq:'Energy Meter',eqC:'#059669',field:'energy_meter_status',rule:'== Inactive',ai:'—'}
];
let m4DoResults=[];

function m4RenderDoTable(){
  const tb=document.getElementById('m4DoBody');
  if(!tb)return;
  if(!m4DoResults.length){tb.innerHTML='<tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data… Prediction will auto-populate results.</td></tr>';return}
  let ok=0,wn=0,al=0;
  let html='';
  m4DoResults.forEach((r,i)=>{
    const c=M4_CONDS[i];if(!c)return;
    const isAlarm=r.alarm;
    if(isAlarm)al++;else ok++;
    const typeCls=c.type==='AI'?'sc-ai':c.type==='Hybrid'?'sc-hy':'sc-rl';
    const statusBadge=isAlarm?'<span class="do-badge do-alarm">🔴 ALARM</span>':'<span class="do-badge do-ok">🟢 OK</span>';
    let ruleOut='';
    if(c.type==='Rule'||c.type==='Hybrid'){
      ruleOut='<span class="do-out-rule"><span class="do-lbl">📏</span>'+(isAlarm?'<span style="color:#ef4444;font-weight:700">TRIGGERED</span> — '+c.rule:'<span style="color:#16a34a">PASS</span> — threshold OK')+'</span>';
    }else{
      ruleOut='<span class="do-out-rule"><span class="do-lbl" style="color:var(--dim)">📏</span><span class="do-na">N/A</span></span>';
    }
    let aiOut='';
    if(c.type==='AI'||c.type==='Hybrid'){
      const conf=isAlarm?((0.7+Math.random()*0.25)*100).toFixed(1):((Math.random()*0.15)*100).toFixed(1);
      const aiStatus=isAlarm?'<span style="color:#ef4444;font-weight:700">ANOMALY ('+conf+'%)</span>':'<span style="color:#16a34a">NORMAL ('+conf+'%)</span>';
      aiOut='<span class="do-out-ai"><span class="do-lbl">🧠</span>'+aiStatus+'</span><span style="font-size:.82em;color:var(--dim);margin-left:36px">'+c.ai+'</span>';
    }else{
      aiOut='<span class="do-out-ai"><span class="do-lbl" style="color:var(--dim)">🧠</span><span class="do-na">N/A</span></span>';
    }
    html+='<tr class="'+(isAlarm?'do-alarm':'')+'">';
    html+='<td><span class="sc-id '+typeCls+'">C'+c.id+'</span></td>';
    html+='<td><span class="sc-tp '+typeCls+'">'+c.type+'</span></td>';
    html+='<td>'+c.name+'</td>';
    html+='<td><span class="sc-eq" style="color:'+c.eqC+'">'+c.eq+'</span></td>';
    html+='<td class="do-val">'+r.val+'</td>';
    html+='<td><div class="do-out">'+ruleOut+'</div></td>';
    html+='<td><div class="do-out">'+aiOut+'</div></td>';
    html+='<td>'+statusBadge+'</td>';
    html+='</tr>';
  });
  tb.innerHTML=html;
  document.getElementById('m4DoOk').textContent=ok;
  document.getElementById('m4DoWn').textContent=wn;
  document.getElementById('m4DoAl').textContent=al;
  const now=new Date();
  document.getElementById('m4DoTs').textContent='Updated: '+now.toLocaleTimeString();
}

function m4DoRefresh(){
  m4RenderDoTable();
}

// ═══ MODULE 3: Historical Graph ═══
const M3_HIST_GROUPS={
  ac_voltage:{label:'AC Voltage (3-Phase)',fields:['VL1N_MDB','VL2N_MDB','VL3N_MDB'],colors:['#0284c7','#7c3aed','#059669'],unit:'V'},
  ac_current:{label:'AC Current (3-Phase)',fields:['I1_MDB','I2_MDB','I3_MDB'],colors:['#dc2626','#d97706','#0891b2'],unit:'A'},
  temperature:{label:'Temperature',fields:['edgebox_temp','pi5_temp','charger_temp'],colors:['#d97706','#dc2626','#0284c7'],unit:'°C'},
  signal:{label:'Wi-Fi Signal',fields:['RSSI'],colors:['#7c3aed'],unit:'dBm'},
  energy:{label:'Energy Meter',fields:['meter1','meter2'],colors:['#0284c7','#059669'],unit:'kWh',scale:0.001}
};
let m3HistRange='daily',m3HistField='ac_voltage',m3HistChart=null;

function m3SetHistRange(r,btn){
  m3HistRange=r;
  document.querySelectorAll('#m3HistRange .hist-btn').forEach(b=>b.classList.remove('on'));btn.classList.add('on');
  const show=r==='custom';
  document.getElementById('m3HistCustom').style.display=show?'':'none';
  document.getElementById('m3HistCustom2').style.display=show?'':'none';
  if(show&&!document.getElementById('m3HistStart').value){
    const now=new Date(),d=new Date(now.getTime()-86400000);
    document.getElementById('m3HistStart').value=d.toISOString().slice(0,16);
    document.getElementById('m3HistEnd').value=now.toISOString().slice(0,16);
  }
}
function m3SetHistField(f,btn){m3HistField=f;document.querySelectorAll('#m3HistFields .hist-btn').forEach(b=>b.classList.remove('on'));btn.classList.add('on')}

async function m3LoadHistory(){
  const grp=M3_HIST_GROUPS[m3HistField];if(!grp)return;
  const el=document.getElementById('m3HistLoading'),emp=document.getElementById('m3HistEmpty'),wrap=document.querySelector('#m3HistCanvas').parentElement;
  emp.style.display='none';emp.className='hist-empty';el.style.display='flex';wrap.style.display='none';

  let url='/api/m3/historical?range='+m3HistRange+'&fields='+grp.fields.join(',');
  if(m3HistRange==='custom'){
    const s=document.getElementById('m3HistStart').value,e=document.getElementById('m3HistEnd').value;
    if(!s||!e){emp.className='hist-empty hist-warn';emp.innerHTML='<div class="he-title">\u26A0 Please select Start and End datetime.</div>';emp.style.display='';el.style.display='none';return}
    url+='&start='+encodeURIComponent(s)+'&end='+encodeURIComponent(e);
  }
  let r,d,httpStatus='';
  try{
    r=await fetch(url);httpStatus=r.status+' '+r.statusText;
    const txt=await r.text();
    try{d=JSON.parse(txt)}catch(pe){
      el.style.display='none';emp.className='hist-empty hist-err';
      emp.innerHTML='<div class="he-title">\u274C JSON Parse Error</div><div class="he-row"><span>URL</span><code>'+url+'</code></div><div class="he-row"><span>Response</span><code>'+txt.substring(0,300)+'</code></div>';
      emp.style.display='';return;
    }
    if(d.error){
      el.style.display='none';emp.className='hist-empty hist-err';
      emp.innerHTML='<div class="he-title">\u274C Server Error</div><div class="he-row"><span>Error</span><code>'+d.error+'</code></div>';
      emp.style.display='';return;
    }
    if(!d.data||!d.data.length){
      el.style.display='none';emp.className='hist-empty hist-warn';
      emp.innerHTML='<div class="he-title">\u26A0 No Data</div><div class="he-row"><span>Range</span><code>'+m3HistRange+'</code></div><div class="he-row"><span>Fields</span><code>'+grp.fields.join(', ')+'</code></div><div class="he-row"><span>Count</span><code>'+(d.count||0)+' documents</code></div><div class="he-hint">No data in the selected time range. Check MongoDB connection and collection.</div>';
      emp.style.display='';return;
    }
    el.style.display='none';wrap.style.display='';
    document.getElementById('m3HistInfo').textContent=d.data.length+' points \u00B7 '+m3HistRange+' \u00B7 '+(d.interval||'raw');
    document.getElementById('m3HistChartTitle').textContent=grp.label+' \u2014 '+m3HistRange.charAt(0).toUpperCase()+m3HistRange.slice(1);
    m3RenderHistChart(d.data,grp);
    m3RenderHistStats(d.data,grp);
  }catch(e){
    el.style.display='none';emp.className='hist-empty hist-err';
    emp.innerHTML='<div class="he-title">\u274C '+(httpStatus.startsWith('200')?'Render':'Network')+' Error</div><div class="he-row"><span>Error</span><code>'+e.message+'</code></div><div class="he-row"><span>URL</span><code>'+url+'</code></div>';
    emp.style.display='';
  }
}

function m3RenderHistChart(data,grp){
  const ctx=document.getElementById('m3HistCanvas');
  if(m3HistChart){m3HistChart.destroy();m3HistChart=null}
  const sc=grp.scale||1;
  const datasets=grp.fields.map((f,i)=>({
    label:f.replace(/_/g,' '),
    data:data.map(d=>{const v=Number(d[f]);return{x:new Date(d.timestamp),y:isNaN(v)?null:v*sc}}),
    borderColor:grp.colors[i],backgroundColor:grp.colors[i]+'18',
    borderWidth:1.5,pointRadius:0,pointHitRadius:6,fill:false,tension:.3,spanGaps:true
  }));
  m3HistChart=new Chart(ctx,{
    type:'line',data:{datasets},
    options:{
      responsive:true,maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{
        legend:{position:'top',labels:{usePointStyle:true,pointStyle:'circle',padding:16,font:{family:'Plus Jakarta Sans,Prompt',size:11}}},
        tooltip:{
          backgroundColor:'rgba(15,23,42,.9)',titleFont:{family:'JetBrains Mono',size:11},bodyFont:{family:'JetBrains Mono',size:11},
          callbacks:{label:function(c){const v=c.parsed.y;return c.dataset.label+': '+(v!=null?v.toFixed(2):'N/A')+(grp.unit?' '+grp.unit:'')}}
        }
      },
      scales:{
        x:{type:'time',time:{tooltipFormat:'yyyy-MM-dd HH:mm:ss',displayFormats:{minute:'HH:mm',hour:'HH:mm',day:'MM/dd'}},
          grid:{color:'rgba(200,210,225,.15)'},ticks:{font:{family:'JetBrains Mono',size:10},color:'#718096',maxTicksLimit:12}},
        y:{grid:{color:'rgba(200,210,225,.15)'},ticks:{font:{family:'JetBrains Mono',size:10},color:'#718096'},
          title:{display:true,text:grp.unit||'value',font:{family:'Plus Jakarta Sans,Prompt',size:11},color:'#718096'}}
      }
    }
  });
}

function m3RenderHistStats(data,grp){
  const el=document.getElementById('m3HistStats');el.innerHTML='';
  const sc=grp.scale||1;
  grp.fields.forEach((f,i)=>{
    const vals=data.map(d=>Number(d[f])).filter(v=>!isNaN(v)&&isFinite(v)).map(v=>v*sc);
    if(!vals.length)return;
    const mn=Math.min(...vals),mx=Math.max(...vals),avg=vals.reduce((a,b)=>a+b,0)/vals.length,last=vals[vals.length-1];
    el.innerHTML+=
      '<div class="hist-stat-card"><div class="hs-label" style="color:'+grp.colors[i]+'">'+f.replace(/_/g,' ')+'</div>'+
      '<div class="hs-val">'+Number(last).toFixed(2)+(grp.unit?' <small>'+grp.unit+'</small>':'')+'</div>'+
      '<div class="hs-row"><span>Min</span><span>'+Number(mn).toFixed(2)+'</span></div>'+
      '<div class="hs-row"><span>Max</span><span>'+Number(mx).toFixed(2)+'</span></div>'+
      '<div class="hs-row"><span>Avg</span><span>'+Number(avg).toFixed(2)+'</span></div></div>';
  });
}

// ═══ DB CONNECTION STATUS — Module 3 & Module 4 ═══
function dbSetStatus(prefix,connected,info){
  const chip=document.getElementById(prefix+'DbChip');
  const dot=document.getElementById(prefix+'DbDot');
  const st=document.getElementById(prefix+'DbSt');
  const detail=document.getElementById(prefix+'DbInfo');
  if(!chip)return;
  const cls=connected?'ok':'err';
  chip.className='db-chip '+cls;
  dot.className='db-dot '+cls;
  st.className='db-val '+cls;
  st.textContent=connected?'Connected':'Disconnected';
  if(detail&&info)detail.textContent=info;
}

async function checkDbStatus(){
  try{
    const r=await fetch('/api/db/status');
    if(!r.ok){throw new Error('HTTP '+r.status)}
    const d=await r.json();
    // Module 3
    const m3=d.module3||{};
    if(m3.connected){
      const ts=(m3.latest_ts||'').replace('T',' ').substring(0,19);
      const docs=m3.docs?(' · '+m3.docs.toLocaleString()+' docs'):'';
      dbSetStatus('m3',true,m3.database+' → '+m3.collection+docs+(ts?' · latest: '+ts:''));
    }else{
      dbSetStatus('m3',false,m3.database+' → '+(m3.error||'Not connected'));
    }
    // Module 4
    const m4=d.module4||{};
    if(m4.connected){
      const ts=(m4.latest_ts||'').replace('T',' ').substring(0,19);
      const docs=m4.docs?(' · '+m4.docs.toLocaleString()+' docs'):'';
      dbSetStatus('m4',true,m4.database+' → '+m4.collection+docs+(ts?' · latest: '+ts:''));
    }else{
      dbSetStatus('m4',false,m4.database+' → '+(m4.error||'Not connected'));
    }
    // Module 5
    const m5=d.module5||{};
    if(m5.connected){
      const ts=(m5.latest_ts||'').replace('T',' ').substring(0,19);
      const docs=m5.docs?(' · '+m5.docs.toLocaleString()+' docs'):'';
      dbSetStatus('m5',true,m5.database+' → '+m5.collection+docs+(ts?' · latest: '+ts:''));
      const dbSt=document.getElementById('m5DbStatus');
      if(dbSt){dbSt.textContent='✅ Connected';dbSt.style.color='#34d399'}
    }else{
      dbSetStatus('m5',false,m5.database+' → '+(m5.error||'Not connected'));
      const dbSt=document.getElementById('m5DbStatus');
      if(dbSt){dbSt.textContent='❌ Disconnected';dbSt.style.color='#f87171'}
    }
  }catch(e){
    console.warn('[DB] Status check failed:',e.message);
    dbSetStatus('m3',false,'Cannot reach server');
    dbSetStatus('m4',false,'Cannot reach server');
    dbSetStatus('m5',false,'Cannot reach server');
  }
}
// Check on load + every 30s
setTimeout(checkDbStatus,1500);
setInterval(checkDbStatus,30000);

// ═══ MODULE 3: Auto-Predict System ═══
const M3_AP_INTERVAL=120; // seconds (2 minutes)
let m3ApEnabled=true,m3ApCountdown=M3_AP_INTERVAL,m3ApTickId=null;

function m3ApToggleChanged(){
  const cb=document.getElementById('m3ApToggle');
  if(cb.checked)m3ApStart();else m3ApStop();
}

function m3ApStart(){
  m3ApEnabled=true;m3ApCountdown=M3_AP_INTERVAL;
  const cd=document.getElementById('m3ApCd');
  cd.className='m3-ap-cd on';
  m3ApUpdateCd();
  // Tick every second
  if(m3ApTickId)clearInterval(m3ApTickId);
  m3ApTickId=setInterval(()=>{
    m3ApCountdown--;
    if(m3ApCountdown<=0){
      m3ApRunPredict();
      m3ApCountdown=M3_AP_INTERVAL;
    }
    m3ApUpdateCd();
  },1000);
  // Run immediately
  m3ApRunPredict();
  // (removed debug log)
}

function m3ApStop(){
  m3ApEnabled=false;
  if(m3ApTickId){clearInterval(m3ApTickId);m3ApTickId=null}
  const cd=document.getElementById('m3ApCd');
  cd.className='m3-ap-cd';cd.textContent='OFF';
  const badge=document.getElementById('m3ApBadge');
  badge.className='m3-ap-badge idle';badge.textContent='IDLE';
  // (removed debug log)
}

function m3ApUpdateCd(){
  const cd=document.getElementById('m3ApCd');
  const m=Math.floor(m3ApCountdown/60),s=m3ApCountdown%60;
  cd.textContent=m+':'+String(s).padStart(2,'0');
  cd.className='m3-ap-cd on';
}

function m3ApNow(){
  const d=new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0');
}

async function m3ApRunPredict(){
  const cd=document.getElementById('m3ApCd');
  const badge=document.getElementById('m3ApBadge');
  const queryTs=document.getElementById('m3ApQueryTs');
  const predTs=document.getElementById('m3ApPredTs');
  const latEl=document.getElementById('m3ApLat');
  const resEl=document.getElementById('m3ApResult');

  // Phase 1: Query data from MongoDB
  cd.className='m3-ap-cd run';cd.textContent='QUERY…';
  badge.className='m3-ap-badge running';badge.textContent='QUERYING';
  const t0=performance.now();
  const qTime=m3ApNow();
  queryTs.textContent=qTime;
  // (removed debug log)

  let telemetry=null;
  try{
    const r=await fetch('/api/m3/latest');
    if(r.ok){
      const resp=await r.json();
      telemetry=resp.data||resp;
      const srcTs=resp.source_timestamp||resp.timestamp||'';
      // (removed debug log)
      if(srcTs){
        queryTs.textContent=qTime+' (data: '+srcTs.replace('T',' ').substring(0,19)+')';
      }
    }else{
      console.warn('[M3-AP] Query failed: HTTP '+r.status);
    }
  }catch(e){
    console.warn('[M3-AP] Query error:',e.message);
  }

  // Fallback: use demo data if API unavailable
  if(!telemetry){
    // (removed debug log)
    telemetry=m3DemoTelemetry();
    queryTs.textContent=qTime+' (demo)';
  }

  // Update signal monitor with fetched data
  m3EvalConditions(telemetry);
  setTimeout(drawM3HealthTreeLines,200);

  // Phase 2: Run prediction
  cd.textContent='PREDICT…';
  badge.className='m3-ap-badge running';badge.textContent='PREDICTING';
  // (removed debug log)

  let prediction=null;
  try{
    const r2=await fetch('/api/m3/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(telemetry)});
    if(r2.ok){
      prediction=await r2.json();
      // (removed debug log)
    }else{
      console.warn('[M3-AP] Predict failed: HTTP '+r2.status);
    }
  }catch(e){
    console.warn('[M3-AP] Predict error:',e.message);
  }

  // Fallback: use demo prediction
  if(!prediction){
    // (removed debug log)
    prediction=m3DemoNormal();
  }

  const elapsed=Math.round(performance.now()-t0);
  const pTime=m3ApNow();
  predTs.textContent=pTime;
  latEl.textContent=elapsed+'ms'+(prediction.latency_ms?' (server: '+prediction.latency_ms+'ms)':'');

  // Update UI
  updateM3UI(prediction);
  drawM3TreeLines();

  // Show result
  const rc=prediction.root_cause||'NORMAL';
  const isNorm=rc==='NORMAL';
  resEl.textContent=rc+(prediction.root_cause_confidence?' ('+Math.round((prediction.root_cause_confidence||0)*100)+'%)':'');
  resEl.style.color=isNorm?'#16a34a':'#ef4444';

  // Update badge
  badge.className='m3-ap-badge '+(isNorm?'ok':'fail');
  badge.textContent=isNorm?'NORMAL':rc;

  // Update LED
  document.getElementById('m3Led').classList.add('on');
  document.getElementById('m3St').textContent=curLang==='th'?'สด':'Live';
  document.getElementById('m3Ts').textContent='⏱ '+pTime;

  // Restore countdown display
  m3ApUpdateCd();
  // (removed debug log)
}

// ═══ MODULE 3: Demo data (simulated when no API) ═══
function m3DemoNormal(){
  return {
    root_cause:'NORMAL',root_cause_confidence:0.987,
    dnn_root_cause:'NORMAL',dnn_confidence:0.965,
    root_cause_probabilities:{NORMAL:0.987,POWER_OUTAGE:0.004,EDGEBOX_FAILURE:0.003,NETWORK_ISSUE:0.003,PLC_FAULT:0.003},
    early_warning:false,early_warning_probability:0.023,early_warning_horizon_seconds:120,
    autoencoder_error:0.00012,autoencoder_level:'NORMAL',
    bilstm_score:0.082,iflof_score:0.115,
    system_health:'NORMAL'
  };
}
function m3DemoTelemetry(){
  return {
    VL1N_MDB:231.2,VL2N_MDB:229.8,VL3N_MDB:230.5,
    I1_MDB:12.4,I2_MDB:11.9,I3_MDB:12.1,
    edgebox_status:'Active',router_internet_status:'Connected',router_status:'Active',RSSI:-43,
    PLC1_status:'Active',PLC2_status:'Active',
    MDB_status:'Active',energy_meter_status:'Active',
    surge_arrestor_status:'Inactive',RCBO_status:'Active',
    edgebox_temp:45.2,pi5_temp:55.8,charger_temp:34.6,
    edgebox_error_code:'',
    timestamp:'2026-02-26T21:44:35+07:00'
  };
}

// Initialize Module 3 with demo data
setTimeout(()=>{updateM3UI(m3DemoNormal());m3EvalConditions(m3DemoTelemetry());m3CheckModels()},500);

// M3 DB connection status check
async function m3CheckDbStatus(){
  try{
    const r=await fetch('/api/m3/latest');
    const resp=await r.json();
    const led=document.getElementById('m3Led');
    const st=document.getElementById('m3St');
    if(resp&&resp.data&&typeof resp.data==='object'&&Object.keys(resp.data).length>0){
      led.className='led on';st.textContent=curLang==='th'?'เชื่อมต่อแล้ว':'Connected';
      // (removed debug log)
    }else if(resp&&resp.error==='no_db'){
      led.className='led';st.textContent=curLang==='th'?'ไม่พบฐานข้อมูล':'DB Not Found';
    }else{
      led.className='led';st.textContent=curLang==='th'?'ออฟไลน์':'Offline';
    }
  }catch(e){
    const led=document.getElementById('m3Led');
    const st=document.getElementById('m3St');
    led.className='led';st.textContent=curLang==='th'?'ออฟไลน์':'Offline';
  }
}
setTimeout(m3CheckDbStatus,2000);
window.addEventListener('resize',()=>{if(activeMod===2)setTimeout(()=>{drawM2TreeLines();drawM2HTLines()},100);if(activeMod===3)setTimeout(()=>{drawM3TreeLines();drawM3HealthTreeLines()},100);if(activeMod===5)setTimeout(drawM5TreeLines,100)});

// ═══════════════════════════════════════════════════════════════
// MODULE 5: Network Problem Root Cause Prediction — JavaScript
// ═══════════════════════════════════════════════════════════════

const M5_MODELS=[
  {id:'X1',file:'m5_xgb_router_status.pkl',type:'ML',name:'XGB Router Status'},
  {id:'X2',file:'m5_xgb_router_net.pkl',type:'ML',name:'XGB Router Net'},
  {id:'X3',file:'m5_xgb_PLC_network_status1.pkl',type:'ML',name:'XGB PLC1'},
  {id:'X4',file:'m5_xgb_edgebox_network_status.pkl',type:'ML',name:'XGB Edgebox'},
  {id:'X5',file:'m5_xgb_pi5_network_status.pkl',type:'ML',name:'XGB Pi5'},
  {id:'X6',file:'m5_xgb_HMI_status.pkl',type:'ML',name:'XGB HMI'},
  {id:'AE',file:'m5_autoencoder.keras',type:'DL',name:'Autoencoder'},
  {id:'BI',file:'m5_bilstm.keras',type:'DL',name:'BiLSTM-Attention'},
  {id:'MT',file:'m5_multitask.keras',type:'DL',name:'Multi-Task DNN'},
  {id:'IF',file:'m5_iforest.pkl',type:'ML',name:'Isolation Forest'},
  {id:'LF',file:'m5_lof.pkl',type:'ML',name:'LOF'},
  {id:'SC',file:'m5_scaler.pkl',type:'PP',name:'Feature Scaler'},
  {id:'CF',file:'m5_config.json',type:'CF',name:'Model Config'}
];

const M5_CONDS=[
  {id:'01',type:'Rule',name:'Router Status',eq:'Router',eqC:'#f87171',field:'router_status',rule:'== Inactive → ROUTER_DOWN',ai:'—'},
  {id:'02',type:'Hybrid',name:'Router Internet',eq:'Router',eqC:'#f87171',field:'router_network_status',rule:'== Disconnected → ISP_OUTAGE',ai:'XGBoost P(ISP_OUTAGE) + pattern'},
  {id:'03',type:'Rule',name:'PLC1 Network',eq:'PLC',eqC:'#38bdf8',field:'PLC_network_status1',rule:'== Inactive → PLC_FAULT',ai:'—'},
  {id:'04',type:'Rule',name:'PLC2 Network',eq:'PLC',eqC:'#38bdf8',field:'PLC_network_status2',rule:'== Inactive → PLC_FAULT',ai:'—'},
  {id:'05',type:'Hybrid',name:'Edgebox Network',eq:'Edgebox',eqC:'#0ea5e9',field:'edgebox_network_status',rule:'== Inactive → EDGEBOX_FAULT',ai:'AE anomaly + DNN classify'},
  {id:'06',type:'AI',name:'Pi5 Network',eq:'Pi5',eqC:'#a78bfa',field:'pi5_network_status',rule:'—',ai:'BiLSTM temporal + IF+LOF anomaly'},
  {id:'07',type:'Rule',name:'Energy Meter 1',eq:'Meter',eqC:'#059669',field:'energy_meter_network_status1',rule:'== Inactive → METER_FAULT',ai:'—'},
  {id:'08',type:'Rule',name:'Energy Meter 2',eq:'Meter',eqC:'#059669',field:'energy_meter_network_status2',rule:'== Inactive → METER_FAULT',ai:'—'},
  {id:'09',type:'Rule',name:'HMI Status',eq:'HMI',eqC:'#ec4899',field:'HMI_status',rule:'== Inactive → HMI_FAULT',ai:'—'},
  {id:'10',type:'AI',name:'Root Cause Class',eq:'System',eqC:'#fbbf24',field:'root_cause',rule:'—',ai:'XGBoost 9-class + DNN + BiLSTM ensemble'},
  {id:'11',type:'AI',name:'Severity Score',eq:'System',eqC:'#fbbf24',field:'severity',rule:'—',ai:'XGBoost regression (0=normal, 1=full outage)'},
  {id:'12',type:'AI',name:'Anomaly Score',eq:'System',eqC:'#fbbf24',field:'anomaly_score',rule:'—',ai:'IF+LOF ensemble (0=normal, 1=extreme anomaly)'}
];

let m5DoResults=[];
let m5DoTelemetry=null;
let m5ApRunning=true;
let m5ApTimer=null;
let m5HistChart=null;
let m5HistLoaded=false;
const M5_CLASS_NAMES=['NORMAL','ROUTER_DOWN','ISP_OUTAGE','PLC_FAULT','EDGEBOX_FAULT','METER_FAULT','HMI_FAULT','MULTI_DEVICE','FULL_OUTAGE'];
const M5_CLASS_COLORS={'NORMAL':'#34d399','ROUTER_DOWN':'#f87171','ISP_OUTAGE':'#fbbf24','PLC_FAULT':'#38bdf8','EDGEBOX_FAULT':'#0ea5e9','METER_FAULT':'#f97316','HMI_FAULT':'#ec4899','MULTI_DEVICE':'#94a3b8','FULL_OUTAGE':'#dc2626'};
const M5_ACTIVE_VALS=new Set(['Active','active','ACTIVE','Connected','connected','CONNECTED','Online','online']);

// ── Tab switching ──
function m5stab(n){
  const tabs=['main','history','algos','output'];
  document.querySelectorAll('#pageMod5 .tb').forEach((t,i)=>t.classList.toggle('on',i===tabs.indexOf(n)));
  document.querySelectorAll('#pageMod5 .tc').forEach(c=>c.classList.toggle('on',c.id==='m5tab-'+n));
  if(n==='main')setTimeout(()=>{drawM5TreeLines()},200);
  if(n==='history'&&!m5HistLoaded){m5HistLoaded=true;setTimeout(m5LoadHistory,300)}
  if(n==='output'){document.querySelectorAll('#m5tab-output .stg').forEach(el=>{el.style.animation='none';el.offsetHeight;el.style.animation=''});m5RenderDoTable()}
}

// ── M5 Model checking (M3-style) ──
function m5SetModelStatus(id,st){
  const item=document.getElementById('m5ld'+id);
  const stEl=document.getElementById('m5ldSt'+id);
  if(!item)return;
  item.classList.remove('ok','err','loading');
  if(st==='ok'){item.classList.add('ok');if(stEl)stEl.innerHTML='<span style="color:#16a34a;font-size:1.1em">✓</span>'}
  else if(st==='error'){item.classList.add('err');if(stEl)stEl.innerHTML='<span style="color:#ef4444;font-size:.9em">✗</span>'}
  else if(st==='loading'){item.classList.add('loading');if(stEl)stEl.innerHTML='<div class="m3-load-spin"></div>'}
}
function m5UpdateLoadProgress(done,total){
  const bar=document.getElementById('m5LoadBar');
  if(bar)bar.style.width=Math.round(done/total*100)+'%';
}
async function m5CheckModels(){
  const cnt=document.getElementById('m5ModelCnt');
  M5_MODELS.forEach(m=>m5SetModelStatus(m.id,'loading'));
  m5UpdateLoadProgress(0,M5_MODELS.length);
  if(cnt)cnt.textContent='loading...';
  let results=null;
  try{
    // (removed debug log)
    const r=await fetch('/api/m5/models');
    if(r.ok){
      results=await r.json();
      // (removed debug log)
    }
  }catch(e){
    // (removed debug log)
  }
  // Animate sequential loading
  let okCnt=0,errCnt=0;
  for(let i=0;i<M5_MODELS.length;i++){
    const m=M5_MODELS[i];
    await new Promise(r=>setTimeout(r,80));
    let isOk=false;
    if(results&&results.models){
      const found=results.models.find(x=>x.id===m.id);
      isOk=found&&found.status==='loaded';
    }else{
      isOk=true; // demo mode
    }
    m5SetModelStatus(m.id,isOk?'ok':'error');
    if(isOk)okCnt++;else errCnt++;
    m5UpdateLoadProgress(i+1,M5_MODELS.length);
  }
  if(cnt){
    if(errCnt===0)cnt.textContent=okCnt+' / '+M5_MODELS.length+' ✓';
    else cnt.textContent=okCnt+'/'+M5_MODELS.length+' ('+errCnt+' missing)';
  }
  // Update DB status from response
  if(results&&results.database){
    const dbEl=document.getElementById('m5DbStatus');
    if(dbEl){dbEl.textContent=results.database.connected?'✅ Connected':'❌ Disconnected';dbEl.style.color=results.database.connected?'#34d399':'#f87171'}
  }
}

// ── Severity gauge drawing ──
function m5DrawSevGauge(val){
  const cv=document.getElementById('m5SevGauge');if(!cv)return;
  const ctx=cv.getContext('2d');
  const W=cv.width,H=cv.height,cx=W/2,cy=H-10,R=70;
  ctx.clearRect(0,0,W,H);
  // Background arc
  ctx.beginPath();ctx.arc(cx,cy,R,Math.PI,0);ctx.lineWidth=14;ctx.strokeStyle='rgba(100,116,139,.2)';ctx.stroke();
  // Value arc
  const angle=Math.PI+(val*Math.PI);
  const grad=ctx.createLinearGradient(cx-R,cy,cx+R,cy);
  grad.addColorStop(0,'#34d399');grad.addColorStop(0.5,'#fbbf24');grad.addColorStop(1,'#f87171');
  ctx.beginPath();ctx.arc(cx,cy,R,Math.PI,angle);ctx.lineWidth=14;ctx.strokeStyle=grad;ctx.lineCap='round';ctx.stroke();
  // Needle
  const nx=cx+R*0.6*Math.cos(angle);const ny=cy+R*0.6*Math.sin(angle);
  ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(nx,ny);ctx.lineWidth=2;ctx.strokeStyle='#e2e8f0';ctx.stroke();
  ctx.beginPath();ctx.arc(cx,cy,4,0,Math.PI*2);ctx.fillStyle='#e2e8f0';ctx.fill();
  // Update text
  const txt=document.getElementById('m5SevTxt');
  if(txt){txt.textContent=val.toFixed(3);txt.style.color=val<0.3?'#34d399':val<0.6?'#fbbf24':'#f87171'}
}

// ── Network tree update ──
function m5UpdateNetTree(data){
  const FIELDS={
    'plc1':'PLC_network_status1','plc2':'PLC_network_status2',
    'edgebox':'edgebox_network_status','pi5':'pi5_network_status',
    'router':'router_status','meter1':'energy_meter_network_status1',
    'meter2':'energy_meter_network_status2','hmi':'HMI_status'
  };
  let online=0,total=8;
  Object.entries(FIELDS).forEach(([key,field])=>{
    const val=data[field]||'Unknown';
    const isUp=M5_ACTIVE_VALS.has(val);
    const el=document.getElementById('m5n-'+key);
    if(el){el.classList.toggle('up',isUp);el.classList.toggle('down',!isUp)}
    if(isUp)online++;
  });
  // Router internet
  const rNet=data['router_network_status']||'Unknown';
  const rNetUp=M5_ACTIVE_VALS.has(rNet);
  const inetEl=document.getElementById('m5n-internet');
  if(inetEl){inetEl.classList.toggle('up',rNetUp);inetEl.classList.toggle('down',!rNetUp)}
  const rNetTxt=document.getElementById('m5n-router-net');
  if(rNetTxt)rNetTxt.textContent='Internet: '+(rNetUp?'Connected':'Disconnected');
  // Switch status = router up means switch is up
  const routerUp=M5_ACTIVE_VALS.has(data['router_status']||'');
  const swEl=document.getElementById('m5n-switch');
  if(swEl){swEl.classList.toggle('up',routerUp);swEl.classList.toggle('down',!routerUp)}
  // Counters
  const onEl=document.getElementById('m5OnlineCnt');if(onEl)onEl.textContent=online;
  const offEl=document.getElementById('m5OfflineCnt');if(offEl)offEl.textContent=total-online;
  // Redraw SVG lines with updated status colors
  setTimeout(drawM5TreeLines,50);
}

// ── Root cause display ──
function m5UpdateRootCause(rc,severity,conf,anomScore){
  const rcEl=document.getElementById('m5RootCause');
  if(rcEl){
    rcEl.textContent=rc||'NORMAL';
    rcEl.className='m5-rc-badge';
    if(rc==='NORMAL')rcEl.classList.add('m5-rc-normal');
    else if(rc==='FULL_OUTAGE'||rc==='ROUTER_DOWN')rcEl.classList.add('m5-rc-critical');
    else rcEl.classList.add('m5-rc-warning');
  }
  const confEl=document.getElementById('m5RcConf');
  if(confEl)confEl.textContent='Confidence: '+(conf!=null?(conf*100).toFixed(1)+'%':'—');
  m5DrawSevGauge(severity||0);
  const anoEl=document.getElementById('m5AnoScore');
  if(anoEl)anoEl.textContent=(anomScore||0).toFixed(3);
}

// ── Condition evaluation ──
function m5EvalConditions(data){
  if(!data)return;
  m5DoTelemetry=data;
  const results=[];
  const ACTIVE=M5_ACTIVE_VALS;
  // Device status conditions (1-9)
  const devFields=[
    {field:'router_status',name:'Router'},
    {field:'router_network_status',name:'Router Internet'},
    {field:'PLC_network_status1',name:'PLC1'},
    {field:'PLC_network_status2',name:'PLC2'},
    {field:'edgebox_network_status',name:'Edgebox'},
    {field:'pi5_network_status',name:'Pi5'},
    {field:'energy_meter_network_status1',name:'Meter1'},
    {field:'energy_meter_network_status2',name:'Meter2'},
    {field:'HMI_status',name:'HMI'}
  ];
  devFields.forEach(df=>{
    const val=data[df.field]||'Unknown';
    const isActive=ACTIVE.has(val);
    results.push({value:val,ruleOut:isActive?'Normal':'⚠ Inactive/Disconnected',aiOut:'—',alarm:!isActive});
  });
  // Root cause, severity, anomaly (from prediction response)
  const rc=data._m5_root_cause||'NORMAL';
  const sev=data._m5_severity||0;
  const ano=data._m5_anomaly_score||0;
  results.push({value:rc,ruleOut:'—',aiOut:rc,alarm:rc!=='NORMAL'});
  results.push({value:sev.toFixed(3),ruleOut:'—',aiOut:'Score: '+sev.toFixed(3),alarm:sev>0.5});
  results.push({value:ano.toFixed(3),ruleOut:'—',aiOut:'Score: '+ano.toFixed(3),alarm:ano>0.5});
  m5DoResults=results;
  m5UpdateNetTree(data);
  m5UpdateRootCause(rc,sev,data._m5_confidence,ano);
}

// ── Detection Output table ──
function m5RenderDoTable(){
  const tb=document.getElementById('m5DoBody');
  if(!tb)return;
  if(!m5DoResults.length){tb.innerHTML='<tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data… Switch to main tab or enable Auto-Predict.</td></tr>';return}
  let ok=0,wn=0,al=0;
  let html='';
  m5DoResults.forEach((r,i)=>{
    const c=M5_CONDS[i];if(!c)return;
    const isAlarm=r.alarm;
    if(isAlarm)al++;else ok++;
    const stBadge=isAlarm?'<span style="color:#f87171;font-weight:700">⚠ ALARM</span>':'<span style="color:#34d399">✓ OK</span>';
    const typeBadge=c.type==='AI'?'<span style="color:#38bdf8">AI</span>':c.type==='Rule'?'<span style="color:#fb923c">Rule</span>':'<span style="color:#a78bfa">Hybrid</span>';
    html+='<tr style="'+(isAlarm?'background:rgba(248,113,113,.05)':'')+'">';
    html+='<td>'+c.id+'</td><td>'+typeBadge+'</td><td>'+c.name+'</td><td><span style="color:'+c.eqC+'">'+c.eq+'</span></td>';
    html+='<td style="font-family:JetBrains Mono">'+r.value+'</td><td>'+r.ruleOut+'</td><td>'+r.aiOut+'</td><td>'+stBadge+'</td></tr>';
  });
  tb.innerHTML=html;
  document.getElementById('m5DoOk').textContent=ok;
  document.getElementById('m5DoAlarm').textContent=al;
  const rcEl=document.getElementById('m5DoRc');
  if(rcEl&&m5DoTelemetry)rcEl.textContent=m5DoTelemetry._m5_root_cause||'NORMAL';
  const tsEl=document.getElementById('m5DoTs');
  if(tsEl)tsEl.textContent='Updated: '+new Date().toLocaleString();
}
function m5RefreshOutput(){if(m5DoTelemetry)m5EvalConditions(m5DoTelemetry);m5RenderDoTable()}

// ── Condition reference table (improved) ──
function m5BuildCondTable(){
  const tb=document.getElementById('m5CondBody');if(!tb)return;
  let html='';
  M5_CONDS.forEach(c=>{
    const cls=c.type==='AI'?'m5-type-ai':c.type==='Rule'?'m5-type-rule':'m5-type-hybrid';
    html+='<tr>';
    html+='<td style="font-weight:800;color:var(--dim);text-align:center">'+c.id+'</td>';
    html+='<td><span class="m5-type-badge '+cls+'">'+c.type+'</span></td>';
    html+='<td style="font-weight:600;color:var(--tx)">'+c.name+'</td>';
    html+='<td><span class="m5-eq-dot" style="background:'+c.eqC+'"></span><span style="color:'+c.eqC+';font-weight:600">'+c.eq+'</span></td>';
    html+='<td style="font-size:.85em;opacity:.8">'+c.field+'</td>';
    html+='<td style="font-size:.85em;color:var(--dim)">'+c.rule+'</td>';
    html+='<td style="font-size:.85em;color:var(--dim)">'+c.ai+'</td>';
    html+='</tr>';
  });
  tb.innerHTML=html;
}

// ── SVG Tree Lines ──
function drawM5TreeLines(){
  const C=document.getElementById('m5TreeCanvas');
  const S=document.getElementById('m5TreeSvg');
  if(!C||!S)return;
  const cr=C.getBoundingClientRect();
  S.setAttribute('width',cr.width);
  S.setAttribute('height',cr.height);
  S.innerHTML='';
  function getCenter(id){
    const el=document.getElementById(id);if(!el)return null;
    const r=el.getBoundingClientRect();
    return{x:r.left+r.width/2-cr.left,y:r.top+r.height/2-cr.top,b:r.bottom-cr.top,t:r.top-cr.top};
  }
  function drawLine(from,to,color,width){
    const a=getCenter(from),b=getCenter(to);
    if(!a||!b)return;
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const midY=(a.b+b.t)/2;
    p.setAttribute('d','M'+a.x+','+a.b+' C'+a.x+','+midY+' '+b.x+','+midY+' '+b.x+','+b.t);
    p.setAttribute('fill','none');p.setAttribute('stroke',color||'rgba(100,116,139,.3)');
    p.setAttribute('stroke-width',width||1.8);p.setAttribute('stroke-linecap','round');
    // Check if both nodes are up
    const fromEl=document.getElementById(from),toEl=document.getElementById(to);
    const bothUp=fromEl&&fromEl.classList.contains('up')&&toEl&&toEl.classList.contains('up');
    p.setAttribute('opacity',bothUp?'0.6':'0.2');
    if(!bothUp)p.setAttribute('stroke-dasharray','4,4');
    S.appendChild(p);
  }
  function drawGlow(from,to,color){
    const a=getCenter(from),b=getCenter(to);
    if(!a||!b)return;
    const fromEl=document.getElementById(from),toEl=document.getElementById(to);
    const bothUp=fromEl&&fromEl.classList.contains('up')&&toEl&&toEl.classList.contains('up');
    if(!bothUp)return;
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const midY=(a.b+b.t)/2;
    p.setAttribute('d','M'+a.x+','+a.b+' C'+a.x+','+midY+' '+b.x+','+midY+' '+b.x+','+b.t);
    p.setAttribute('fill','none');p.setAttribute('stroke',color);
    p.setAttribute('stroke-width','4');p.setAttribute('opacity','0.1');
    p.setAttribute('filter','blur(3px)');
    S.appendChild(p);
  }
  // Internet → Router
  drawGlow('m5n-internet','m5n-router','#34d399');
  drawLine('m5n-internet','m5n-router','#34d399',2);
  // Router → Switch
  drawGlow('m5n-router','m5n-switch','#38bdf8');
  drawLine('m5n-router','m5n-switch','#38bdf8',2);
  // Switch → each device
  const devices=['m5n-plc1','m5n-plc2','m5n-edgebox','m5n-pi5','m5n-meter1','m5n-meter2','m5n-hmi'];
  const devColors=['#38bdf8','#38bdf8','#0ea5e9','#a78bfa','#059669','#059669','#ec4899'];
  devices.forEach((d,i)=>{
    drawGlow('m5n-switch',d,devColors[i]);
    drawLine('m5n-switch',d,devColors[i],1.5);
  });
}

// ── Auto-Predict (M3-style toggle) ──
let m5ApCountdown=0;
let m5ApCdTimer=null;
function m5ApToggleChanged(){
  const tog=document.getElementById('m5ApToggle');
  if(!tog)return;
  m5ApRunning=tog.checked;
  const badge=document.getElementById('m5ApBadge');
  const cd=document.getElementById('m5ApCd');
  if(m5ApRunning){
    if(badge){badge.textContent='RUNNING';badge.className='m3-ap-badge running'}
    m5RunPredict();
    m5ApCountdown=120;
    if(cd){cd.textContent='120';cd.classList.add('run')}
    m5ApCdTimer=setInterval(()=>{
      m5ApCountdown--;
      if(cd)cd.textContent=m5ApCountdown;
      if(m5ApCountdown<=0){m5ApCountdown=120;m5RunPredict()}
    },1000);
    m5ApTimer=null;
  }else{
    if(badge){badge.textContent='IDLE';badge.className='m3-ap-badge idle'}
    if(cd){cd.textContent='OFF';cd.classList.remove('run')}
    if(m5ApCdTimer)clearInterval(m5ApCdTimer);m5ApCdTimer=null;
    if(m5ApTimer)clearInterval(m5ApTimer);m5ApTimer=null;
  }
}
async function m5RunPredict(){
  const badge=document.getElementById('m5ApBadge');
  const queryTs=document.getElementById('m5ApQueryTs');
  const predTs=document.getElementById('m5ApPredTs');
  const latEl=document.getElementById('m5ApLat');
  const resEl=document.getElementById('m5ApResult');
  const qTime=new Date().toLocaleTimeString();
  if(badge){badge.textContent='QUERYING';badge.className='m3-ap-badge running'}
  if(queryTs)queryTs.textContent=qTime;
  const t0=performance.now();
  try{
    const r=await fetch('/api/m5/latest');
    if(!r.ok)throw new Error('HTTP '+r.status);
    const d=await r.json();
    const lat=Math.round(performance.now()-t0);
    const telemetry=d.data||d;
    telemetry._m5_root_cause=telemetry.root_cause||'NORMAL';
    telemetry._m5_severity=telemetry.severity||0;
    telemetry._m5_anomaly_score=telemetry.anomaly_score||0;
    telemetry._m5_confidence=telemetry.confidence||null;
    m5EvalConditions(telemetry);
    m5RenderDoTable();
    setTimeout(drawM5TreeLines,100);
    if(predTs)predTs.textContent=new Date().toLocaleTimeString();
    if(latEl){latEl.textContent=lat+'ms';latEl.style.color=lat<500?'#16a34a':lat<1000?'#d97706':'#ef4444'}
    const rc=telemetry._m5_root_cause;
    if(resEl){resEl.textContent=rc;resEl.style.color=rc==='NORMAL'?'#16a34a':'#ef4444'}
    if(badge){badge.textContent=m5ApRunning?'RUNNING':'OK';badge.className='m3-ap-badge '+(m5ApRunning?'running':'ok')}
    // Update connection status
    const led=document.getElementById('m5Led');
    const stEl=document.getElementById('m5St');
    if(led)led.style.background='#34d399';
    if(stEl){stEl.textContent=(d.source==='mongodb'?'MongoDB Live':'Demo Data');stEl.style.color='#34d399'}
  }catch(e){
    console.error('[M5] Predict error:',e);
    if(badge){badge.textContent='ERROR';badge.className='m3-ap-badge fail'}
    if(latEl)latEl.textContent='—';
    if(resEl){resEl.textContent='Error';resEl.style.color='#ef4444'}
    m5LoadDemo();
    setTimeout(drawM5TreeLines,100);
  }
}

// ── Demo data ──
function m5LoadDemo(){
  const demo={
    router_status:'Active',router_network_status:'Connected',
    PLC_network_status1:'Active',PLC_network_status2:'Active',
    edgebox_network_status:'Active',pi5_network_status:'Active',
    energy_meter_network_status1:'Active',energy_meter_network_status2:'Active',
    HMI_status:'Active',
    _m5_root_cause:'NORMAL',_m5_severity:0,_m5_anomaly_score:0.012,_m5_confidence:0.97
  };
  m5EvalConditions(demo);
  m5RenderDoTable();
}

// ── Historical graph ──
async function m5LoadHistory(){
  const range=document.getElementById('m5HistRange').value;
  const group=document.getElementById('m5HistGroup').value;
  const msg=document.getElementById('m5HistMsg');
  if(msg)msg.textContent='Loading...';
  const fieldMap={
    devices:'router_status,PLC_network_status1,PLC_network_status2,edgebox_network_status,pi5_network_status,energy_meter_network_status1,energy_meter_network_status2,HMI_status',
    router:'router_status,router_network_status',
    plc:'PLC_network_status1,PLC_network_status2',
    meters:'energy_meter_network_status1,energy_meter_network_status2',
    severity:'severity,anomaly_score'
  };
  const fields=fieldMap[group]||fieldMap.devices;
  try{
    const r=await fetch('/api/m5/historical?range='+range+'&fields='+fields);
    if(!r.ok)throw new Error('HTTP '+r.status);
    const d=await r.json();
    if(!d.data||!d.data.length){if(msg)msg.textContent='No data for selected range';return}
    if(msg)msg.textContent='';
    m5DrawHistChart(d.data,fields.split(','),group);
  }catch(e){
    console.error('[M5] History error:',e);
    if(msg)msg.textContent='Error loading data: '+e.message;
  }
}
function m5DrawHistChart(data,fields,group){
  const wrap=document.getElementById('m5Timeline');if(!wrap)return;
  if(m5HistChart){try{m5HistChart.destroy()}catch(e){};m5HistChart=null}
  const cs=getComputedStyle(document.documentElement);
  const dimC=cs.getPropertyValue('--dim').trim()||'#64748b';
  const bdrC=cs.getPropertyValue('--bdr').trim()||'rgba(100,116,139,.15)';
  const cardBg=cs.getPropertyValue('--glass').trim()||'rgba(255,255,255,.03)';
  const txC=cs.getPropertyValue('--tx').trim()||'#e2e8f0';

  const DLABELS={
    'router_status':'Router','router_network_status':'Router Net',
    'PLC_network_status1':'PLC 1','PLC_network_status2':'PLC 2',
    'edgebox_network_status':'Edgebox','pi5_network_status':'Pi5',
    'energy_meter_network_status1':'Meter 1','energy_meter_network_status2':'Meter 2',
    'HMI_status':'HMI','severity':'Severity','anomaly_score':'Anomaly'
  };
  const DICONS={
    'router_status':'📡','router_network_status':'🌐',
    'PLC_network_status1':'🔌','PLC_network_status2':'🔌',
    'edgebox_network_status':'📦','pi5_network_status':'🖥',
    'energy_meter_network_status1':'⚡','energy_meter_network_status2':'⚡',
    'HMI_status':'🖥'
  };

  // Parse timestamps
  const times=data.map(d=>{
    const raw=d.timestamp||d.time||'';
    try{const dt=new Date(raw);return isNaN(dt)?null:dt}catch(e){return null}
  });
  if(!times.filter(t=>t!==null).length){wrap.innerHTML='<div style="text-align:center;padding:40px;color:'+dimC+';font-size:.7em">No valid timestamps</div>';return}

  // Severity mode → line chart fallback
  if(group==='severity'){
    wrap.innerHTML='<div style="position:relative;height:320px;width:100%"><canvas id="m5HistChartFB"></canvas></div>';
    const cv=document.getElementById('m5HistChartFB');
    const labels=data.map((d,i)=>{const t=times[i];if(!t)return '';return t.getHours().toString().padStart(2,'0')+':'+t.getMinutes().toString().padStart(2,'0')});
    const colors=['#f87171','#fb923c'];
    const datasets=fields.map((f,i)=>({label:DLABELS[f]||f,data:data.map(d=>parseFloat(d[f])||0),borderColor:colors[i%2],backgroundColor:colors[i%2]+'22',borderWidth:1.5,pointRadius:0,fill:true,tension:.3}));
    m5HistChart=new Chart(cv,{type:'line',data:{labels,datasets},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{color:dimC,font:{size:10,family:'JetBrains Mono'},boxWidth:12}}},scales:{x:{ticks:{color:dimC,maxTicksLimit:14,maxRotation:0,font:{size:9,family:'JetBrains Mono'}},grid:{color:'rgba(100,116,139,.08)'}},y:{min:0,max:1,ticks:{color:dimC,font:{size:9},stepSize:.2},grid:{color:'rgba(100,116,139,.08)'}}}}});
    return;
  }

  // ── TIMELINE (Gantt-style) ──
  const ON='#22c55e',ON_GLOW='rgba(34,197,94,.15)',ON_SOFT='rgba(34,197,94,.08)';
  const OFF='#ef4444',OFF_GLOW='rgba(239,68,68,.15)',OFF_SOFT='rgba(239,68,68,.06)';
  const ROW_H=40,LABEL_W=130,PAD_T=8,PAD_B=40,PAD_R=16,BAR_H=22,BAR_R=4;
  const chartH=PAD_T+fields.length*ROW_H+PAD_B;
  const rv=(document.getElementById('m5HistRange')||{}).value||'24h';
  const series=fields.map(f=>data.map(d=>{const v=d[f];return typeof v==='number'?(v>=1?1:0):(M5_ACTIVE_VALS.has(v)?1:0)}));
  const N=data.length;
  const totalW=Math.max(wrap.clientWidth-2,600);
  const barAreaW=totalW-LABEL_W-PAD_R;

  function fmtT(dt){
    if(!dt)return '';
    const h=dt.getHours().toString().padStart(2,'0'),m=dt.getMinutes().toString().padStart(2,'0');
    return(rv==='7d'||rv==='30d')?(dt.getDate()+'/'+(dt.getMonth()+1)+' '+h+':'+m):(h+':'+m);
  }
  function px(i){return LABEL_W+(i/Math.max(N-1,1))*barAreaW}

  let svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+totalW+'" height="'+chartH+'" style="display:block;font-family:JetBrains Mono,monospace">';

  // Defs
  svg+='<defs>';
  svg+='<linearGradient id="m5g_on" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#4ade80" stop-opacity=".9"/><stop offset="100%" stop-color="#16a34a" stop-opacity=".75"/></linearGradient>';
  svg+='<linearGradient id="m5g_off" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f87171" stop-opacity=".85"/><stop offset="100%" stop-color="#dc2626" stop-opacity=".7"/></linearGradient>';
  svg+='<linearGradient id="m5g_shine" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="white" stop-opacity=".35"/><stop offset="100%" stop-color="white" stop-opacity="0"/></linearGradient>';
  svg+='<filter id="m5f_gon"><feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#22c55e" flood-opacity=".25"/></filter>';
  svg+='<filter id="m5f_goff"><feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ef4444" flood-opacity=".2"/></filter>';
  svg+='</defs>';

  // ── Time axis (bottom) ──
  const tickN=Math.min(N,12);
  const tickStep=Math.max(1,Math.floor(N/tickN));
  for(let i=0;i<N;i+=tickStep){
    const x=px(i);
    svg+='<line x1="'+x+'" y1="'+PAD_T+'" x2="'+x+'" y2="'+(chartH-PAD_B)+'" stroke="'+bdrC+'" stroke-width=".5" stroke-dasharray="2,4"/>';
    svg+='<text x="'+x+'" y="'+(chartH-PAD_B+18)+'" fill="'+dimC+'" font-size="8" text-anchor="middle" opacity=".7">'+fmtT(times[i])+'</text>';
  }
  // Last tick
  svg+='<text x="'+px(N-1)+'" y="'+(chartH-PAD_B+18)+'" fill="'+dimC+'" font-size="8" text-anchor="end" opacity=".7">'+fmtT(times[N-1])+'</text>';

  // ── Rows ──
  fields.forEach((f,fi)=>{
    const y=PAD_T+fi*ROW_H;
    const vals=series[fi];
    const label=DLABELS[f]||f.replace(/_/g,' ');
    const icon=DICONS[f]||'●';
    const onCnt=vals.filter(v=>v===1).length;
    const offCnt=vals.length-onCnt;
    const uptimeRaw=onCnt/vals.length*100;
    const uptime=uptimeRaw===100?'100':uptimeRaw>=99?uptimeRaw.toFixed(2):uptimeRaw>=90?uptimeRaw.toFixed(1):uptimeRaw.toFixed(1);

    // Row stripe
    if(fi%2===0)svg+='<rect x="'+LABEL_W+'" y="'+y+'" width="'+barAreaW+'" height="'+ROW_H+'" fill="'+cardBg+'" rx="0"/>';
    // Row separator
    svg+='<line x1="'+LABEL_W+'" y1="'+(y+ROW_H)+'" x2="'+(LABEL_W+barAreaW)+'" y2="'+(y+ROW_H)+'" stroke="'+bdrC+'" stroke-width=".3"/>';

    // Label: icon + name + uptime%
    const lblY=y+ROW_H/2;
    svg+='<text x="14" y="'+(lblY+1)+'" font-size="11" dominant-baseline="middle">'+icon+'</text>';
    svg+='<text x="30" y="'+(lblY+1)+'" fill="'+txC+'" font-size="9.5" font-weight="700" dominant-baseline="middle">'+label+'</text>';
    const uptColor=uptimeRaw>=99.5?ON:uptimeRaw>=90?'#fbbf24':OFF;
    svg+='<text x="'+(LABEL_W-6)+'" y="'+(lblY-4)+'" fill="'+uptColor+'" font-size="7.5" font-weight="800" text-anchor="end" dominant-baseline="middle">'+uptime+'%</text>';
    if(offCnt>0)svg+='<text x="'+(LABEL_W-6)+'" y="'+(lblY+8)+'" fill="'+OFF+'" font-size="6" font-weight="600" text-anchor="end" dominant-baseline="middle" opacity=".6">'+offCnt+' off</text>';

    // ── Online segments (green bars) ──
    let segS=null;
    for(let i=0;i<=N;i++){
      const v=i<N?vals[i]:0;
      if(v===1&&segS===null)segS=i;
      if((v===0||i===N)&&segS!==null){
        const x1=px(segS),x2=px(Math.min(i,N-1));
        const w=Math.max(x2-x1,2.5);
        const bY=y+(ROW_H-BAR_H)/2;
        svg+='<rect x="'+x1+'" y="'+bY+'" width="'+w+'" height="'+BAR_H+'" rx="'+BAR_R+'" fill="'+ON_SOFT+'" filter="url(#m5f_gon)"/>';
        svg+='<rect x="'+x1+'" y="'+(bY+1)+'" width="'+w+'" height="'+(BAR_H-2)+'" rx="'+(BAR_R-1)+'" fill="url(#m5g_on)"/>';
        svg+='<rect x="'+x1+'" y="'+(bY+1)+'" width="'+w+'" height="'+((BAR_H-2)/2)+'" rx="'+(BAR_R-1)+'" fill="url(#m5g_shine)"/>';
        segS=null;
      }
    }

    // ── Offline segments (red bars) ──
    let offS=null;
    for(let i=0;i<=N;i++){
      const v=i<N?vals[i]:1;
      if(v===0&&offS===null)offS=i;
      if((v===1||i===N)&&offS!==null){
        const x1=px(offS),x2=px(Math.min(i,N-1));
        const w=Math.max(x2-x1,2.5);
        const bY=y+(ROW_H-BAR_H)/2;
        svg+='<rect x="'+x1+'" y="'+bY+'" width="'+w+'" height="'+BAR_H+'" rx="'+BAR_R+'" fill="'+OFF_SOFT+'" filter="url(#m5f_goff)"/>';
        svg+='<rect x="'+x1+'" y="'+(bY+1)+'" width="'+w+'" height="'+(BAR_H-2)+'" rx="'+(BAR_R-1)+'" fill="url(#m5g_off)"/>';
        svg+='<rect x="'+x1+'" y="'+(bY+1)+'" width="'+w+'" height="'+((BAR_H-2)/2)+'" rx="'+(BAR_R-1)+'" fill="url(#m5g_shine)" opacity=".2"/>';
        // Pulse dot marker
        if(w>14){
          const cx=x1+w/2,cy=bY+BAR_H/2;
          svg+='<circle cx="'+cx+'" cy="'+cy+'" r="2.5" fill="white" opacity=".5"/>';
        }
        offS=null;
      }
    }
  });
  svg+='</svg>';

  // ── Legend + Summary bar ──
  let legend='<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-top:12px;padding:10px 14px;border-radius:8px;background:'+cardBg+';border:1px solid '+bdrC+'">';
  // Left: legend
  legend+='<div style="display:flex;align-items:center;gap:14px">';
  legend+='<div style="display:flex;align-items:center;gap:5px;font-size:.55em"><span style="width:18px;height:10px;border-radius:3px;background:linear-gradient(135deg,#4ade80,#16a34a);display:inline-block"></span><span style="color:'+dimC+';font-weight:600">Online</span></div>';
  legend+='<div style="display:flex;align-items:center;gap:5px;font-size:.55em"><span style="width:18px;height:10px;border-radius:3px;background:linear-gradient(135deg,#f87171,#dc2626);display:inline-block"></span><span style="color:'+dimC+';font-weight:600">Offline</span></div>';
  legend+='<div style="font-size:.48em;color:'+dimC+';font-family:JetBrains Mono;opacity:.6">Data points: '+N.toLocaleString()+'</div>';
  legend+='</div>';
  // Right: per-device uptime
  legend+='<div style="display:flex;flex-wrap:wrap;gap:8px">';
  fields.forEach((f,fi)=>{
    const label=DLABELS[f]||f.replace(/_/g,' ');
    const vals=series[fi];
    const onC=vals.filter(v=>v===1).length;
    const offC=vals.length-onC;
    const pctRaw=onC/vals.length*100;
    const pct=pctRaw===100?'100':pctRaw>=99?pctRaw.toFixed(2):pctRaw.toFixed(1);
    const pc=pctRaw>=99.5?ON:pctRaw>=90?'#fbbf24':OFF;
    const bgC=pctRaw>=99.5?'rgba(34,197,94,.06)':pctRaw>=90?'rgba(251,191,36,.06)':'rgba(239,68,68,.06)';
    const brC=pctRaw>=99.5?'rgba(34,197,94,.15)':pctRaw>=90?'rgba(251,191,36,.15)':'rgba(239,68,68,.15)';
    legend+='<div style="display:flex;align-items:center;gap:4px;font-size:.5em;font-family:JetBrains Mono;padding:2px 8px;border-radius:4px;background:'+bgC+';border:1px solid '+brC+'">';
    legend+='<span style="color:'+dimC+'">'+label+'</span>';
    legend+='<span style="font-weight:900;color:'+pc+'">'+pct+'%</span>';
    if(offC>0)legend+='<span style="color:'+OFF+';font-size:.85em;opacity:.7">('+offC+'↓)</span>';
    legend+='</div>';
  });
  legend+='</div>';
  legend+='</div>';

  wrap.innerHTML='<div style="width:100%;min-width:600px">'+svg+legend+'</div>';
}

// ── Module 5 initialization ──
setTimeout(()=>{m5BuildCondTable();m5LoadDemo();m5DrawSevGauge(0);setTimeout(drawM5TreeLines,300)},600);

// ════════════════════════════════════════════════════════════
// MODULE 6: RUL Prediction JavaScript
// ════════════════════════════════════════════════════════════
const M6_CATEGORIES=[
  {key:'dc_contactor',icon:'⚡',name:'DC Contactors',count:6,method:'cycle',rated:100000,unit:'cycles',comps:['dc_contactor_1','dc_contactor_2','dc_contactor_3','dc_contactor_4','dc_contactor_5','dc_contactor_6']},
  {key:'ac_contactor',icon:'🔌',name:'AC Contactors',count:2,method:'cycle',rated:300000,unit:'cycles',comps:['ac_contactor_1','ac_contactor_2']},
  {key:'power_module',icon:'🔋',name:'Power Modules',count:5,method:'arrhenius',rated:90000,unit:'hours',comps:['power_module_1','power_module_2','power_module_3','power_module_4','power_module_5']},
  {key:'dc_fan',icon:'🌀',name:'DC Fans',count:8,method:'arrhenius',rated:70000,unit:'hours',comps:['dc_fan_1','dc_fan_2','dc_fan_3','dc_fan_4','dc_fan_5','dc_fan_6','dc_fan_7','dc_fan_8']},
  {key:'router',icon:'📡',name:'Router',count:1,method:'arrhenius',rated:100000,unit:'hours',comps:['router']},
  {key:'energy_meter',icon:'⚡',name:'Energy Meters',count:2,method:'arrhenius',rated:160000,unit:'hours',comps:['energy_meter_1','energy_meter_2']},
  {key:'edgebox',icon:'📦',name:'Edgebox',count:1,method:'arrhenius',rated:100000,unit:'hours',comps:['edgebox']},
  {key:'pi5',icon:'🖥️',name:'Raspberry Pi5',count:1,method:'arrhenius',rated:80000,unit:'hours',comps:['pi5']},
  {key:'plc',icon:'🔌',name:'PLCs',count:2,method:'arrhenius',rated:200000,unit:'hours',comps:['plc_1','plc_2']},
  {key:'power_supply',icon:'🔋',name:'Power Supply',count:1,method:'arrhenius',rated:120000,unit:'hours',comps:['power_supply']},
  {key:'insulation_monitor',icon:'🛡️',name:'Insulation Monitors',count:2,method:'arrhenius',rated:160000,unit:'hours',comps:['insulation_monitor_1','insulation_monitor_2']},
  {key:'switching_psu',icon:'⚡',name:'Switching PSU',count:1,method:'arrhenius',rated:100000,unit:'hours',comps:['switching_psu']}
];
let m6ApOn=true,m6ApInterval=null,m6ApCountdown=120,m6DoResults=[],m6DoTelemetry=null;

function m6stab(n){
  const tabs=['main','detail','algos','output'];
  document.querySelectorAll('#pageMod6 .tb').forEach((t,i)=>t.classList.toggle('on',i===tabs.indexOf(n)));
  document.querySelectorAll('#pageMod6 .tc').forEach(c=>c.classList.toggle('on',c.id==='m6tab-'+n));
  if(n==='detail')m6RenderDetail();
  if(n==='output')m6RenderDoTable();
}
function m6RulColor(pct){if(pct>70)return'#34d399';if(pct>30)return'#fbbf24';if(pct>10)return'#f97316';return'#ef4444';}

function m6RenderCatGrid(comps){
  const grid=document.getElementById('m6CatGrid');if(!grid)return;
  let html='';
  M6_CATEGORIES.forEach(cat=>{
    const vals=cat.comps.map(c=>(comps&&comps[c])?comps[c].rul_pct:null).filter(v=>v!==null);
    const avg=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:null;
    const min=vals.length?Math.min(...vals):null;
    const pct=min!==null?min:0;const col=m6RulColor(pct);
    const mt=cat.method==='cycle'?'<span class="m6-cat-method cyc">CYCLE</span>':'<span class="m6-cat-method arr">ARRHENIUS</span>';
    const rem=avg!==null?(cat.unit==='hours'?Math.round(cat.rated*avg/100).toLocaleString()+'h':Math.round(cat.rated*avg/100).toLocaleString()):'—';
    html+=`<div class="m6-cat"><div class="m6-cat-hdr"><div class="m6-cat-name">${cat.icon} ${cat.name} <span class="m6-cat-cnt">×${cat.count}</span>${mt}</div><div class="m6-cat-pct" style="color:${col}">${avg!==null?avg.toFixed(1):'—'}%</div></div><div class="m6-cat-bar"><div class="m6-cat-fill" style="width:${pct}%;background:${col}"></div></div><div class="m6-cat-info"><span>Rated: ${cat.rated.toLocaleString()} ${cat.unit}</span><span>Remaining: ~${rem}</span></div></div>`;
  });
  grid.innerHTML=html;
}

function m6RenderDetail(){
  const el=document.getElementById('m6DetailList');if(!el||!m6DoTelemetry)return;
  const comps=m6DoTelemetry.components||{};
  const vals=Object.values(comps).map(c=>c.rul_pct).filter(v=>typeof v==='number');
  document.getElementById('m6dGood').textContent=vals.filter(v=>v>70).length;
  document.getElementById('m6dWatch').textContent=vals.filter(v=>v>30&&v<=70).length;
  document.getElementById('m6dWarn').textContent=vals.filter(v=>v>10&&v<=30).length;
  document.getElementById('m6dCrit').textContent=vals.filter(v=>v<=10).length;
  let html='';
  M6_CATEGORIES.forEach(cat=>{
    html+=`<div class="cd" style="padding:0;overflow:hidden;margin-bottom:2px"><div style="padding:10px 16px;background:linear-gradient(135deg,rgba(100,116,139,.06),transparent);border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between"><div style="font-weight:700;font-size:.7em;display:flex;align-items:center;gap:6px">${cat.icon} ${cat.name} <span style="font-size:.75em;padding:1px 6px;border-radius:4px;background:rgba(100,116,139,.1);color:var(--dim)">×${cat.count}</span></div><span class="m6-cat-method ${cat.method==='cycle'?'cyc':'arr'}">${cat.method==='cycle'?'CYCLE':'ARRHENIUS'}</span></div><div style="padding:8px 16px">`;
    cat.comps.forEach(c=>{
      const d=comps[c]||{};const pct=d.rul_pct||0;const col=m6RulColor(pct);
      const used=d.used_display||'—';const rem=d.remaining_display||'—';
      const temp=d.temp_c?d.temp_c.toFixed(1)+'°C':'—';
      const af=d.accel_factor?d.accel_factor.toFixed(1)+'×':'—';
      const status=pct>70?'GOOD':pct>30?'WATCH':pct>10?'WARNING':'CRITICAL';
      html+=`<div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid rgba(100,116,139,.06);font-size:.58em;font-family:'JetBrains Mono'">
        <div style="width:8px;height:8px;border-radius:2px;background:${col};flex-shrink:0"></div>
        <div style="width:160px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${c.replace(/_/g,' ')}</div>
        <div style="flex:1;height:6px;border-radius:3px;background:rgba(100,116,139,.1);overflow:hidden"><div style="height:100%;border-radius:3px;background:${col};width:${pct}%;transition:width .5s"></div></div>
        <div style="width:50px;text-align:right;font-weight:800;color:${col}">${pct.toFixed(1)}%</div>
        <div style="width:60px;text-align:center;font-size:.85em;padding:1px 0;border-radius:4px;background:${col}22;color:${col};font-weight:600">${status}</div>
        <div style="width:120px;color:var(--dim);text-align:right;font-size:.85em">${rem}</div>
      </div>`;
    });
    html+=`</div></div>`;
  });
  el.innerHTML=html;
}

function m6UpdateGauge(pct){
  const arc=document.getElementById('m6GaugeArc');if(!arc)return;
  const col=m6RulColor(pct);arc.setAttribute('stroke-dashoffset',188.5*(1-pct/100));arc.setAttribute('stroke',col);
  document.getElementById('m6SysHealth').textContent=pct.toFixed(1)+'%';
  document.getElementById('m6SysHealth').style.color=col;
}

function m6RenderPriority(comps){
  const el=document.getElementById('m6PrioList');if(!el)return;
  const sorted=Object.entries(comps).map(([k,v])=>({name:k,...v})).sort((a,b)=>a.rul_pct-b.rul_pct).slice(0,5);
  const colors=['#ef4444','#f97316','#fbbf24','#a3e635','#34d399'];
  let html='';
  sorted.forEach((comp,i)=>{
    const col=m6RulColor(comp.rul_pct);
    html+=`<div class="m6-prio-item"><div class="m6-prio-rank" style="background:${colors[i]||'#64748b'}">${i+1}</div><span style="flex:1;font-weight:600">${comp.name.replace(/_/g,' ')}</span><span style="color:${col};font-weight:700">${comp.rul_pct.toFixed(1)}%</span><span style="color:var(--dim)">${comp.remaining_display||'—'}</span></div>`;
  });
  el.innerHTML=html||'<div style="text-align:center;color:var(--dim);padding:20px">No data</div>';
}

function m6ProcessPrediction(data){
  m6DoTelemetry=data;
  const comps=data.components||{};
  const vals=Object.values(comps).map(c=>c.rul_pct).filter(v=>typeof v==='number');
  const sysH=vals.length?Math.min(...vals):0;
  const avgH=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0;
  const healthy=vals.filter(v=>v>70).length,watch=vals.filter(v=>v>30&&v<=70).length;
  const warn=vals.filter(v=>v>10&&v<=30).length,crit=vals.filter(v=>v<=10).length;
  const weakest=Object.entries(comps).sort((a,b)=>a[1].rul_pct-b[1].rul_pct)[0];
  m6UpdateGauge(sysH);
  document.getElementById('m6SysWeakest').textContent='Weakest: '+(weakest?weakest[0].replace(/_/g,' '):'—');
  document.getElementById('m6HealthyCnt').textContent=healthy;
  document.getElementById('m6WatchCnt').textContent=watch;
  document.getElementById('m6WarnCnt').textContent=warn;
  document.getElementById('m6CritCnt').textContent=crit;
  document.getElementById('m6AvgHealth').textContent=avgH.toFixed(1)+'%';
  document.getElementById('m6TotalComps').textContent=vals.length;
  m6RenderCatGrid(comps);m6RenderPriority(comps);
  m6DoResults.unshift({ts:new Date().toISOString(),sysH:sysH.toFixed(1),weakest:weakest?weakest[0]:'—',avg:avgH.toFixed(1),healthy,watch,warn,crit});
  if(m6DoResults.length>100)m6DoResults.pop();
}

function m6RenderDoTable(){
  const tb=document.getElementById('m6OutBody');if(!tb)return;
  if(!m6DoResults.length){
    tb.innerHTML='<tr><td colspan="9" style="text-align:center;color:var(--dim);padding:40px;font-style:italic">Enable Auto-Predict or click "Run Now" to generate predictions…</td></tr>';
    document.getElementById('m6oLatestHealth').textContent='—';
    document.getElementById('m6oWeakest').textContent='—';
    document.getElementById('m6oCount').textContent='0';
    return;
  }
  const latest=m6DoResults[0];
  const lhCol=m6RulColor(parseFloat(latest.sysH));
  document.getElementById('m6oLatestHealth').innerHTML=`<span style="color:${lhCol}">${latest.sysH}%</span>`;
  document.getElementById('m6oWeakest').textContent=latest.weakest.replace(/_/g,' ');
  document.getElementById('m6oCount').textContent=m6DoResults.length;
  let html='';
  m6DoResults.forEach((r,i)=>{const col=m6RulColor(parseFloat(r.sysH));
    const ts=new Date(r.ts);const tsFmt=ts.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'})+' '+ts.toLocaleDateString('en-GB',{day:'2-digit',month:'short'});
    html+=`<tr><td style="font-weight:700;color:var(--dim)">${i+1}</td><td style="font-size:.58em;font-family:'JetBrains Mono'">${tsFmt}</td><td><span style="color:${col};font-weight:800;font-family:'JetBrains Mono'">${r.sysH}%</span></td><td style="font-size:.55em">${r.weakest.replace(/_/g,' ')}</td><td style="font-family:'JetBrains Mono'">${r.avg}%</td><td style="text-align:center;color:#34d399;font-weight:700">${r.healthy}</td><td style="text-align:center;color:#fbbf24;font-weight:700">${r.watch}</td><td style="text-align:center;color:#f97316;font-weight:700">${r.warn}</td><td style="text-align:center;color:#ef4444;font-weight:700">${r.crit}</td></tr>`;
  });
  tb.innerHTML=html;
  document.getElementById('m6DoTs').textContent=`${m6DoResults.length} prediction(s) — latest: ${new Date(m6DoResults[0].ts).toLocaleTimeString()}`;
}

async function m6CheckModels(){
  // (removed debug log)
  try{
    var r=await fetch('/api/m6/models');
    // (removed debug log)
    if(!r.ok){var errBody=await r.text();console.error('[M6] HTTP',r.status,errBody);return;}
    var d=await r.json();
    // (removed debug log)
    if(d.error){console.error('[M6] API ERROR:',d.error);console.error('[M6] Traceback:',d.traceback||'');var grid=document.getElementById('m6LoadGrid');if(grid)grid.innerHTML='<div style="color:#f87171;padding:12px;font-size:.8em">API Error: '+esc(d.error)+'</div>';return;}
    var grid=document.getElementById('m6LoadGrid');
    if(!grid){console.error('[M6] m6LoadGrid element NOT FOUND');return;}
    var models=d.models||[];
    var loaded=0;
    var parts=[];
    function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
    for(var i=0;i<models.length;i++){
      var m=models[i];
      var ok=m.loaded;
      if(ok)loaded++;
      var tp=m.type==='DL'?'dl':m.type==='ML'?'ml':'';
      var tpStyle=tp?'':' style="background:rgba(100,116,139,.1);color:#64748b"';
      var sizeStr=m.size>0?' ('+(m.size/1024).toFixed(0)+'KB)':'';
      var desc='';
      if(m.error){
        desc='<span style="color:#f87171;font-size:.65em">'+esc(m.error).substring(0,80)+'</span>';
      }else{
        desc=esc(m.file)+sizeStr;
      }
      var row='<div class="m3-load-item'+(ok?' loaded':'')+'">';
      row+='<span class="m3-load-id" style="font-size:.45em">'+esc(m.id)+'</span>';
      row+='<div class="m3-load-info"><div class="m3-load-name">'+esc(m.name)+'</div>';
      row+='<div class="m3-load-desc">'+desc+'</div></div>';
      row+='<span class="m3-load-tp '+tp+'"'+tpStyle+'>'+esc(m.type)+'</span>';
      row+='<div class="m3-load-st">'+(ok?'<span style="color:#34d399">\u2713</span>':'<span style="color:#f87171">\u2717</span>')+'</div>';
      row+='</div>';
      parts.push(row);
    }
    // (removed debug log)
    grid.innerHTML=parts.join('');
    var cntEl=document.getElementById('m6ModelCnt');
    if(cntEl)cntEl.textContent=loaded+' / '+models.length;
    var barEl=document.getElementById('m6LoadBar');
    if(barEl)barEl.style.width=(models.length>0?Math.round(loaded/models.length*100):0)+'%';
    if(d.db){
      var s=d.db.connected;
      var stEl=document.getElementById('m6DbStatus');
      if(stEl){stEl.textContent=s?'\u2705 Connected':'\u274c Disconnected';stEl.style.color=s?'#34d399':'#f87171';}
      if(d.db.docs){var di=document.getElementById('m6DbInfo');if(di)di.textContent='database: '+d.db.database+' | docs: '+d.db.docs.toLocaleString();}
    }
    // (removed debug log)
  }catch(e){console.error('[M6] m6CheckModels EXCEPTION:',e.message,e.stack);}
}

async function m6RunPredict(){
  const badge=document.getElementById('m6ApBadge');
  if(badge){badge.textContent='RUNNING';badge.className='m3-ap-badge running';}
  const t0=Date.now();
  document.getElementById('m6ApQueryTs').textContent=new Date().toLocaleTimeString();
  try{
    const r=await fetch('/api/m6/latest');const d=await r.json();
    if(d.error){console.error('[M6]',d.error);if(badge){badge.textContent='ERROR';badge.className='m3-ap-badge error';}return;}
    m6ProcessPrediction(d);
    const lat=Date.now()-t0;
    document.getElementById('m6ApPredTs').textContent=new Date().toLocaleTimeString();
    document.getElementById('m6ApLat').textContent=lat+'ms';
    if(document.getElementById('m6oLatency'))document.getElementById('m6oLatency').textContent=lat+'ms';
    const sh=d.system_health||0;
    document.getElementById('m6ApResult').textContent=sh.toFixed(1)+'%';
    document.getElementById('m6Led').className='led on';
    document.getElementById('m6St').textContent='Connected';
    if(badge){badge.textContent='DONE';badge.className='m3-ap-badge done';setTimeout(()=>{if(m6ApOn){badge.textContent='WAITING';badge.className='m3-ap-badge idle';}},2000);}
  }catch(e){
    console.error('[M6] predict error',e);
    document.getElementById('m6Led').className='led';
    document.getElementById('m6St').textContent='Error';
    if(badge){badge.textContent='ERROR';badge.className='m3-ap-badge error';}
  }
}

function m6ApToggleChanged(){
  m6ApOn=document.getElementById('m6ApToggle').checked;
  if(m6ApOn){
    m6RunPredict();m6ApCountdown=120;
    m6ApInterval=setInterval(()=>{m6ApCountdown--;document.getElementById('m6ApCd').textContent=m6ApCountdown+'s';if(m6ApCountdown<=0){m6ApCountdown=120;m6RunPredict();}},1000);
  }else{
    clearInterval(m6ApInterval);m6ApInterval=null;
    document.getElementById('m6ApCd').textContent='OFF';
    document.getElementById('m6ApBadge').textContent='IDLE';
    document.getElementById('m6ApBadge').className='m3-ap-badge idle';
  }
}
m6RenderCatGrid(null);
// ── End Module 6 ──



// ══════════════════════════════════════════════════════════
// ═══ DASHBOARD: All Modules Summary ═══
var dashAutoTimer=null;
var DASH_MODULES=[
  {id:1,key:'m1',name:'Module 1',sub:'MDB Filter Clogging',icon:'\u{1F300}',color:'#059669',weight:12,api:'/api/m1/latest',modelsApi:'/api/m1/models',
   parseResult:function(d){if(d.error)return{score:0,label:d.error==='no_data'?'No Data':'Error',status:'off',health:null};var r=d.ensemble_risk||d.risk_score||0;var l=r<.25?'Clean':r<.5?'Moderate':r<.75?'Degraded':'Clogged';var tel=d.telemetry||{};var age=tel.dust_filter_charging;var hp=d.health!==undefined&&d.health!==null?d.health:Math.round(Math.max(0,Math.min(100,(1-r)*100)));var method=d.method||'';var extra=age!==undefined&&age!==null?'Filter: '+Math.round(age)+'d':'';if(method)extra+=(extra?' | ':'')+method;return{score:r,label:l,status:r<.5?'ok':r<.75?'warn':'crit',health:hp,extra:extra}}},
  {id:2,key:'m2',name:'Module 2',sub:'Charger Filter Clogging',icon:'\u{1F504}',color:'#0891b2',weight:12,api:'/api/m2/latest',modelsApi:'/api/m2/models',
   parseResult:function(d){if(d.error)return{score:0.5,label:d.error==='no_db'?'No DB':'Error',status:d.error==='no_db'?'warn':'crit',health:null};var dd=d.data||{};var temps=[];for(var i=1;i<=5;i++){var v=dd['power_module_temp'+i];if(v!==undefined&&v!==null)temps.push(parseFloat(v))}var maxT=temps.length?Math.max.apply(null,temps):0;var hot=maxT>55;var hp=temps.length?Math.round(Math.max(0,Math.min(100,100-(maxT-35)*2.5))):100;return{score:hot?0.6:0,label:hot?'High Temp':'Normal',status:hot?'warn':'ok',health:hp,extra:temps.length?'PM Temp max: '+maxT.toFixed(0)+'°C':'Data: '+d.fields+' fields'}}},
  {id:3,key:'m3',name:'Module 3',sub:'Charger Offline Detection',icon:'\u{1F4E1}',color:'#7c3aed',weight:16,api:'/api/m3/latest',modelsApi:'/api/m3/models',
   parseResult:function(d){if(d.error)return{score:1,label:'Error',status:'crit',health:null};var dd=d.data||d;var active=['Active','active','Connected','connected','Online','online'];var devs=['edgebox_status','router_status','PLC1_status','PLC2_status','MDB_status','energy_meter_status'];var on=0;for(var i=0;i<devs.length;i++){var v=dd[devs[i]]||'';if(active.indexOf(v)>=0)on++}var total=devs.length;var offCnt=total-on;var hp=Math.round(on/total*100);return{score:offCnt/total,label:offCnt===0?'All Online':offCnt+'/'+total+' Offline',status:offCnt===0?'ok':offCnt<=1?'warn':'crit',health:hp,extra:on+'/'+total+' devices online'}}},
  {id:4,key:'m4',name:'Module 4',sub:'Power Delivery Anomaly',icon:'\u26A1',color:'#d97706',weight:20,api:'/api/m4/latest',modelsApi:'/api/m4/models',
   parseResult:function(d){if(d.error)return{score:0.5,label:d.error==='no_db'?'No DB':'Error',status:d.error==='no_db'?'warn':'crit',health:null};var af=d.anomaly_flags||0;var soc=d.soc||0;var ct=d.charger_temp||0;var hp=Math.round(Math.max(0,Math.min(100,(22-af)/22*100)));return{score:af>0?0.7:0,label:af>0?af+' Anomaly':'Normal',status:af===0?'ok':af<=1?'warn':'crit',health:hp,extra:'SOC: '+Math.round(soc)+'% | Temp: '+ct.toFixed(1)+'°C'}}},
  {id:5,key:'m5',name:'Module 5',sub:'Network Problem Prediction',icon:'\u{1F310}',color:'#2563eb',weight:12,api:'/api/m5/latest',modelsApi:'/api/m5/models',
   parseResult:function(d){if(d.error)return{score:1,label:'Error',status:'crit',health:null};var dd=d.data||d;var rc=dd.root_cause||'unknown';var sev=dd.severity||0;var isOk=rc==='NORMAL';var hp=Math.round(Math.max(0,Math.min(100,(1-sev)*100)));return{score:sev,label:isOk?'Stable':rc.replace(/_/g,' '),status:isOk?'ok':sev>0.5?'crit':'warn',health:hp,extra:isOk?'All devices online':'Severity: '+(sev*100).toFixed(0)+'%'}}},
  {id:6,key:'m6',name:'Module 6',sub:'Remaining Useful Life',icon:'\u231B',color:'#dc2626',weight:18,api:'/api/m6/latest',modelsApi:'/api/m6/models',
   parseResult:function(d){var h=d.system_health;var avg=d.avg_health;var nComp=d.components?Object.keys(d.components).length:0;if(h===undefined&&avg===undefined)return{score:0,label:'No Data',status:'off',health:null};var hp=(h!==undefined&&h!==null)?h:(avg||0);var hpR=Math.round(Math.max(0,Math.min(100,hp)));var wk=d.weakest_component||'';return{score:hp<30?0.8:hp<60?0.4:0,label:Math.round(hp)+'% Health',status:hp<30?'crit':hp<60?'warn':'ok',health:hpR,extra:(wk?'Weakest: '+wk:'Avg: '+Math.round(avg||hp)+'%')+' ('+nComp+' parts)'}}},
  {id:7,key:'m7',name:'Module 7',sub:'EV-PLCC State Monitor',icon:'\u{1F50D}',color:'#ec4899',weight:10,api:'/api/m7/latest',modelsApi:'/api/m7/models',
   parseResult:function(d){if(d.error)return{score:0,label:'Error',status:'off',health:null};var anCount=0;if(d.model_results){for(var k in d.model_results){var mr=d.model_results[k];if(mr&&mr.anomaly)anCount++}}var hasAnomaly=anCount>0||(d.anomaly_count&&d.anomaly_count>0);var src=d.source||'';var hp=Math.round(Math.max(0,Math.min(100,100-anCount*10)));return{score:hasAnomaly?0.7:0,label:hasAnomaly?'Anomaly':'Normal',status:hasAnomaly?'warn':'ok',health:hp,extra:src==='mqtt'?'Source: MQTT Live':src?'Source: '+src:''}}}
];

var dashData={};
var dashModelsCache=null;

async function dashFetchModels(){
  if(dashModelsCache)return dashModelsCache;
  var mc={};
  try{
    var proms=DASH_MODULES.map(function(mod){
      if(!mod.modelsApi)return Promise.resolve();
      return fetch(mod.modelsApi).then(function(r){return r.json()}).then(function(md){mc[mod.key]={loaded:md.loaded||0,total:md.total||0}}).catch(function(){});
    });
    await Promise.all(proms);
  }catch(e){}
  dashModelsCache=mc;
  return mc;
}

function fetchWithTimeout(url,ms){
  return new Promise(function(resolve,reject){
    var timer=setTimeout(function(){reject(new Error('timeout'))},ms||6000);
    fetch(url).then(function(r){clearTimeout(timer);resolve(r)}).catch(function(e){clearTimeout(timer);reject(e)});
  });
}

async function dashRefreshAll(){
  var spin=document.getElementById('dashRefSpin');if(spin)spin.style.display='';
  var showOverlay=dlFirstLoad;
  if(showOverlay){
    var t=document.getElementById('dlTitle');if(t)t.textContent='Loading Dashboard';
    var s=document.getElementById('dlSub');if(s)s.textContent='Fetching all modules...';
    dlBuildChips();dlProgress(0,DASH_MODULES.length,'',false);dlShow(true);
  }
  // Safety: always dismiss overlay after 10s max no matter what
  var safetyTimer=null;
  if(showOverlay){safetyTimer=setTimeout(function(){dlShow(false);dlFirstLoad=false;},5000);}
  try{
    // Try batch API first (fast: 1 call)
    var batchOk=false;
    try{
      var r=await fetchWithTimeout('/api/dashboard/all',5000);
      var batchRes=await r.json();
      if(batchRes&&batchRes.modules){
        var mods=batchRes.modules;
        for(var i=0;i<DASH_MODULES.length;i++){
          var mod=DASH_MODULES[i];
          var d=mods[mod.key]||{};
          var result={loaded:true,error:null,data:d,parsed:null,models:null,ts:new Date().toLocaleTimeString()};
          if(d.error){result.error=d.error;result.loaded=false;result.parsed={score:0,label:String(d.error).substring(0,25),status:'off',health:null};}
          else{try{result.parsed=mod.parseResult(d);}catch(pe){result.parsed={score:0,label:'Parse Err',status:'off',health:null};}}
          dashData[mod.key]=result;
          if(showOverlay)dlProgress(i+1,DASH_MODULES.length,'',false);
        }
        batchOk=true;
      }
    }catch(e){}
    // Fallback: individual APIs if batch failed
    if(!batchOk){
      for(var i=0;i<DASH_MODULES.length;i++){
        var mod=DASH_MODULES[i];
        if(showOverlay)dlProgress(i,DASH_MODULES.length,mod.name,true);
        try{
          var r2=await fetchWithTimeout(mod.api,4000);var d2=await r2.json();
          var result2={loaded:true,error:null,data:d2,parsed:null,models:null,ts:new Date().toLocaleTimeString()};
          if(d2.error){result2.error=d2.error;result2.loaded=false;result2.parsed={score:0,label:String(d2.error).substring(0,25),status:'off',health:null};}
          else{try{result2.parsed=mod.parseResult(d2);}catch(pe){result2.parsed={score:0,label:'Parse Err',status:'off',health:null};}}
          dashData[mod.key]=result2;
        }catch(e2){dashData[mod.key]={loaded:false,error:'timeout',parsed:{score:0,label:'Timeout',status:'off',health:null}};}
        if(showOverlay)dlProgress(i+1,DASH_MODULES.length,'',false);
      }
    }
    // Fetch models in background (non-blocking)
    dashFetchModels().then(function(mc){
      for(var k in mc){if(dashData[k])dashData[k].models=mc[k];}
      dashRender();
    }).catch(function(){});
  }catch(e){
    for(var i=0;i<DASH_MODULES.length;i++){dashData[DASH_MODULES[i].key]={loaded:false,error:e.message,parsed:{score:0,label:'Error',status:'off',health:null}};}
  }
  // ALWAYS dismiss overlay
  if(safetyTimer)clearTimeout(safetyTimer);
  if(showOverlay){
    dlProgress(DASH_MODULES.length,DASH_MODULES.length,'',false);
    var t2=document.getElementById('dlTitle');if(t2)t2.textContent='Dashboard Ready';
    var s2=document.getElementById('dlSub');if(s2)s2.textContent='All modules loaded';
    var ic=document.querySelector('.dl-icon');if(ic)ic.textContent='\u2705';
    setTimeout(function(){dlShow(false);if(ic)ic.textContent='\u26a1';dlFirstLoad=false;},600);
  }
  if(spin)spin.style.display='none';
  try{dashRender();}catch(e){}
  var lu=document.getElementById('dashLastUpdate');if(lu)lu.textContent=new Date().toLocaleTimeString();
}

var dlFirstLoad=true;
function dlShow(show){var ov=document.getElementById('dashLoadingOverlay');if(!ov)return;if(show)ov.classList.add('active');else ov.classList.remove('active');}
function dlProgress(done,total,moduleName,isLoading){
  var bar=document.getElementById('dlBar'),pct=document.getElementById('dlPct'),txt=document.getElementById('dlModuleText');
  var p=total>0?Math.round(done/total*100):0;
  if(bar)bar.style.width=p+'%';if(pct)pct.textContent=p+'%';
  if(txt)txt.textContent=isLoading?'Fetching '+moduleName+'...':(done>=total?'All modules loaded':'Loading...');
  var chips=document.getElementById('dlChips');if(!chips)return;
  var items=chips.querySelectorAll('.dl-mod-chip');
  for(var i=0;i<items.length;i++){if(i<done)items[i].className='dl-mod-chip done';else if(i===done&&isLoading)items[i].className='dl-mod-chip loading';else items[i].className='dl-mod-chip';}
}
function dlBuildChips(){var chips=document.getElementById('dlChips');if(!chips)return;var h=[];for(var i=0;i<DASH_MODULES.length;i++)h.push('<span class="dl-mod-chip">M'+(i+1)+'</span>');chips.innerHTML=h.join('');}

function dashRender(){
  var grid=document.getElementById('dashGrid');if(!grid)return;
  var html=[];
  var normal=0,warn=0,crit=0;
  var weightSum=0,healthWeightedSum=0;

  for(var i=0;i<DASH_MODULES.length;i++){
    var mod=DASH_MODULES[i];
    var d=dashData[mod.key]||{};
    var p=d.parsed||{score:0,label:'Waiting',status:'off',health:null};
    var st=p.status||'off';
    if(st==='ok')normal++;else if(st==='warn')warn++;else if(st==='crit')crit++;

    // Accumulate weighted health
    var hp=p.health;
    if(hp!==null&&hp!==undefined){weightSum+=mod.weight;healthWeightedSum+=hp*mod.weight;}

    var topColor=st==='ok'?'linear-gradient(90deg,#22c55e,#34d399)':st==='warn'?'linear-gradient(90deg,#eab308,#fbbf24)':st==='crit'?'linear-gradient(90deg,#ef4444,#f87171)':'linear-gradient(90deg,#6b7280,#94a3b8)';
    var badgeCls=st;
    var badgeText=st==='ok'?'NORMAL':st==='warn'?'WARNING':st==='crit'?'CRITICAL':'OFFLINE';
    var scoreText=p.label||'--';
    var scoreColor=st==='ok'?'#22c55e':st==='warn'?'#eab308':st==='crit'?'#ef4444':'#6b7280';

    // Models info
    var modelsText='--';
    if(d.models)modelsText=d.models.loaded+'/'+d.models.total;

    // Health gauge
    var hpVal=hp!==null&&hp!==undefined?hp:null;
    var hpColor=hpVal===null?'#6b7280':hpVal>=80?'#22c55e':hpVal>=60?'#84cc16':hpVal>=40?'#eab308':hpVal>=20?'#f97316':'#ef4444';
    var hpText=hpVal!==null?hpVal+'%':'N/A';
    var hpLabel=hpVal===null?'N/A':hpVal>=90?'Excellent':hpVal>=75?'Good':hpVal>=60?'Fair':hpVal>=40?'Poor':'Critical';
    // SVG arc: semicircle r=34, circumference half = PI*34 = 106.81
    var arcLen=106.81;
    var arcOff=hpVal!==null?arcLen*(1-hpVal/100):arcLen;

    // Extra info
    var extra=p.extra||'';

    html.push(
      '<div class="dash-card" onclick="switchModule('+mod.id+')">'+
      '<div class="dash-card-top" style="background:'+topColor+'"></div>'+
      '<div class="dash-card-body">'+
      '<div class="dash-card-hdr">'+
      '<div class="dash-card-hdr-l">'+
      '<div class="dash-card-ico" style="background:'+mod.color+'">'+mod.icon+'</div>'+
      '<div><div class="dash-card-title">'+mod.name+'</div><div class="dash-card-sub">'+mod.sub+'</div></div>'+
      '</div>'+
      '<div class="dash-card-badge '+badgeCls+'">'+badgeText+'</div>'+
      '</div>'+
      '<div class="dash-card-metrics">'+
      '<div class="dash-metric"><div class="mk">Status</div><div class="mv" style="color:'+scoreColor+'">'+scoreText+'</div></div>'+
      '<div class="dash-metric"><div class="mk">Models</div><div class="mv">'+modelsText+'</div></div>'+
      '</div>'+
      '<div style="display:flex;justify-content:center;margin-top:8px">'+
      '<div style="position:relative;width:90px;height:52px">'+
      '<svg viewBox="0 0 80 46" style="width:90px;height:52px">'+
      '<path d="M 6 42 A 34 34 0 0 1 74 42" fill="none" stroke="var(--bdr)" stroke-width="6" stroke-linecap="round"/>'+
      '<path d="M 6 42 A 34 34 0 0 1 74 42" fill="none" stroke="'+hpColor+'" stroke-width="6" stroke-linecap="round" stroke-dasharray="'+arcLen+'" stroke-dashoffset="'+arcOff+'" style="transition:stroke-dashoffset .8s ease,stroke .5s ease;filter:drop-shadow(0 0 3px '+hpColor+'55)"/>'+
      '</svg>'+
      '<div style="position:absolute;bottom:0;left:0;right:0;text-align:center;line-height:1">'+
      '<div style="font-family:\'JetBrains Mono\',monospace;font-size:.85em;font-weight:900;color:'+hpColor+'">'+hpText+'</div>'+
      '<div style="font-size:.42em;font-weight:700;color:var(--dim);letter-spacing:.5px;margin-top:1px">'+hpLabel+'</div>'+
      '</div>'+
      '</div>'+
      '</div>'+
      (extra?'<div style="margin-top:4px;font-size:.6em;color:var(--dim);text-align:center">'+extra+'</div>':'')+
      '</div>'+
      '<div class="dash-card-footer">'+
      '<span>Click to open module</span>'+
      '<span class="dash-ts">'+(d.ts||'--:--:--')+'</span>'+
      '</div>'+
      '</div>'
    );
  }

  grid.innerHTML=html.join('');

  // Update KPI
  var nEl=document.getElementById('dkNormal');if(nEl)nEl.textContent=normal;
  var wEl=document.getElementById('dkWarn');if(wEl)wEl.textContent=warn;
  var cEl=document.getElementById('dkCrit');if(cEl)cEl.textContent=crit;

  // Animate KPI colors
  var nc=document.getElementById('dkNormalCard');if(nc)nc.className='dash-kpi-card green';
  var wc=document.getElementById('dkWarnCard');if(wc)wc.className='dash-kpi-card '+(warn>0?'yellow':'green');
  var cc=document.getElementById('dkCritCard');if(cc)cc.className='dash-kpi-card '+(crit>0?'red':'green');

  // Overall System Health (weighted average)
  var overallHealth=weightSum>0?Math.round(healthWeightedSum/weightSum):null;
  var hEl=document.getElementById('dkHealth');
  var hBar=document.getElementById('dkHealthBar');
  var hSub=document.getElementById('dkHealthSub');
  var hCard=document.getElementById('dkHealthCard');
  if(overallHealth!==null){
    var ohColor=overallHealth>=80?'#22c55e':overallHealth>=60?'#84cc16':overallHealth>=40?'#eab308':overallHealth>=20?'#f97316':'#ef4444';
    var ohLabel=overallHealth>=90?'Excellent':overallHealth>=75?'Good':overallHealth>=60?'Fair':overallHealth>=40?'Poor':'Critical';
    if(hEl){hEl.textContent=overallHealth+'%';hEl.style.color=ohColor;}
    if(hBar){hBar.style.width=overallHealth+'%';hBar.style.background='linear-gradient(90deg,'+ohColor+','+ohColor+'cc)';}
    if(hSub)hSub.textContent=ohLabel+' — weighted avg of '+DASH_MODULES.length+' modules';
    if(hCard)hCard.style.borderColor=ohColor+'40';
  }else{
    if(hEl){hEl.textContent='--';hEl.style.color='#6b7280';}
    if(hBar)hBar.style.width='0%';
    if(hSub)hSub.textContent='Waiting for data...';
  }
}

// ═══ STATION SELECTOR ═══
var stationsCache=[];
var stationDropOpen=false;

async function loadStations(){
  try{
    var r=await fetch('/api/stations');
    var d=await r.json();
    if(d.stations)stationsCache=d.stations;
    // Update current station display
    var activeSN=d.active_sn||'';
    var snEl=document.getElementById('stationSN');
    var nmEl=document.getElementById('stationName');
    if(snEl)snEl.textContent=activeSN;
    var found=stationsCache.find(function(s){return s.sn===activeSN});
    if(nmEl)nmEl.textContent=found?found.name:activeSN;
    renderStationList(stationsCache);
  }catch(e){
    console.error('loadStations error:',e);
    var snEl=document.getElementById('stationSN');
    if(snEl)snEl.textContent='Offline';
  }
}

function renderStationList(list){
  var el=document.getElementById('stationList');
  if(!el)return;
  if(!list||list.length===0){el.innerHTML='<div class="station-empty">No stations found</div>';return;}
  var r=document.getElementById('stationSN');
  var activeSN=r?r.textContent:'';
  var modColors={M1:'#059669',M2:'#0891B2',M3:'#7C3AED',M4:'#DC2626',M5:'#2563EB',M6:'#D97706',M7:'#EC4899'};
  var html=[];
  for(var i=0;i<list.length;i++){
    var s=list[i];
    var isActive=s.sn===activeSN;
    var mods='';
    if(s.modules&&s.modules.length>0){
      for(var j=0;j<s.modules.length;j++){
        var mc=modColors[s.modules[j]]||'#6b7280';
        mods+='<span class="station-item-mod" style="background:'+mc+'">'+s.modules[j]+'</span>';
      }
    }
    html.push(
      '<div class="station-item'+(isActive?' active':'')+'" onclick="selectStation(\''+s.sn+'\')">'+
      '<div class="station-item-ico">&#9889;</div>'+
      '<div class="station-item-info">'+
      '<div class="station-item-sn">'+(s.name&&s.name!==s.sn?s.name:s.sn)+'</div>'+
      '<div class="station-item-name">'+s.sn+(s.province?' &bull; '+s.province:'')+'</div>'+
      '</div>'+
      '<div class="station-item-modules">'+mods+'</div>'+
      '</div>'
    );
  }
  el.innerHTML=html.join('');
}

function toggleStationDropdown(){
  var dd=document.getElementById('stationDropdown');
  var arrow=document.getElementById('stationArrow');
  if(!dd)return;
  stationDropOpen=!stationDropOpen;
  if(stationDropOpen){
    dd.classList.add('show');
    if(arrow)arrow.classList.add('open');
    var inp=document.getElementById('stationSearch');
    if(inp){inp.value='';inp.focus();}
    if(stationsCache.length===0)loadStations();
    else renderStationList(stationsCache);
  }else{
    dd.classList.remove('show');
    if(arrow)arrow.classList.remove('open');
  }
}

function filterStations(){
  var inp=document.getElementById('stationSearch');
  if(!inp)return;
  var q=inp.value.toLowerCase().trim();
  if(!q){renderStationList(stationsCache);return;}
  var filtered=stationsCache.filter(function(s){
    return (s.sn&&s.sn.toLowerCase().indexOf(q)!==-1)||
           (s.name&&s.name.toLowerCase().indexOf(q)!==-1)||
           (s.province&&s.province.toLowerCase().indexOf(q)!==-1)||
           (s.location&&s.location.toLowerCase().indexOf(q)!==-1)||
           (s.station_id&&s.station_id.toLowerCase().indexOf(q)!==-1);
  });
  renderStationList(filtered);
}

async function selectStation(sn){
  // Close dropdown
  var dd=document.getElementById('stationDropdown');
  var arrow=document.getElementById('stationArrow');
  if(dd)dd.classList.remove('show');
  if(arrow)arrow.classList.remove('open');
  stationDropOpen=false;
  // Update display immediately
  var snEl=document.getElementById('stationSN');
  var nmEl=document.getElementById('stationName');
  if(snEl)snEl.textContent=sn;
  if(nmEl)nmEl.textContent='Switching...';
  try{
    var r=await fetch('/api/switch-station/'+encodeURIComponent(sn),{method:'POST'});
    var d=await r.json();
    if(d.ok){
      if(nmEl)nmEl.textContent=d.station_name||sn;
      // Update dashboard subtitle
      var sub=document.querySelector('.dash-hdr .sub');
      if(sub)sub.innerHTML='&#9889; Active: <b>'+sn+'</b> &mdash; '+(d.station_name||sn);
      // Reset ALL modules and refresh everything
      onStationChanged(sn, d.station_name||sn);
    }
  }catch(e){
    console.error('selectStation error:',e);
    if(nmEl)nmEl.textContent='Error';
  }
}

function onStationChanged(sn, stationName){
  window.STATION_CONFIG_ACTIVE=sn;
  hhLoaded=false;hhModHidden={};hhModCacheData=null;
  // ── 1. Reset history loaded flags → force re-fetch when tab opened ──
  m2HistLoaded=false;
  m3HistLoaded=false;
  if(typeof m5HistLoaded!=='undefined')m5HistLoaded=false;

  // ── 2. Clear prediction history caches ──
  if(typeof m1PredHistory!=='undefined')m1PredHistory=[];
  var m1hEl=document.getElementById('m1PredHistory');if(m1hEl)m1hEl.innerHTML='<div style="color:var(--dim);text-align:center;padding:10px">Station changed — waiting for new predictions</div>';

  // ── 3. Clear dashboard data cache ──
  dashData={};

  // ── 4. Stop all auto-predict timers (they will be restarted with fresh data) ──
  if(typeof m1ApInterval!=='undefined'&&m1ApInterval){clearInterval(m1ApInterval);m1ApInterval=null;}
  if(typeof m2ApTickId!=='undefined'&&m2ApTickId){clearInterval(m2ApTickId);m2ApTickId=null;}
  if(typeof m3ApTickId!=='undefined'&&m3ApTickId){clearInterval(m3ApTickId);m3ApTickId=null;}
  if(typeof m5ApCdTimer!=='undefined'&&m5ApCdTimer){clearInterval(m5ApCdTimer);m5ApCdTimer=null;}
  if(typeof m6ApInterval!=='undefined'&&m6ApInterval){clearInterval(m6ApInterval);m6ApInterval=null;}
  if(typeof m7ApInterval!=='undefined'&&m7ApInterval){clearInterval(m7ApInterval);m7ApInterval=null;}

  // ── 5. Update DB info labels in each module page ──
  var m1db=document.getElementById('m1DbInfo');if(m1db)m1db.textContent='module1MdbDustPrediction.'+sn;
  var m2db=document.getElementById('m2DbInfo');if(m2db)m2db.textContent='module2ChargerDustPrediction.'+sn;
  var m3db=document.getElementById('m3DbInfo');if(m3db)m3db.textContent='module3ChargerOfflineAnalysis.'+sn;

  // ── 6. Show loading overlay + refresh dashboard ──
  var t=document.getElementById('dlTitle');if(t)t.textContent='Switching Station';
  var s2=document.getElementById('dlSub');if(s2)s2.textContent='Loading data from '+(stationName||sn)+'...';
  dlFirstLoad=true;
  dashRefreshAll();

  // ── 7. Force re-run active module page (if not on dashboard) ──
  setTimeout(function(){
    if(activeMod===1){m1RunPredict();if(!m1ApInterval)m1ApToggleChanged();}
    if(activeMod===2){m2ApToggleChanged();}
    if(activeMod===3){m3ApToggleChanged();}
    if(activeMod===5){m5RunPredict();if(!m5ApCdTimer)m5ApToggleChanged();}
    if(activeMod===6){m6RunPredict();if(!m6ApInterval)m6ApToggleChanged();}
    if(activeMod===7){m7RunPredict();if(!m7ApInterval)m7ApToggleChanged();}
    if(activeMod===8){hhLoadData();}
  },1500);
}

// Close dropdown when clicking outside
document.addEventListener('click',function(e){
  var sel=document.getElementById('stationSelector');
  if(sel&&!sel.contains(e.target)&&stationDropOpen){
    toggleStationDropdown();
  }
});

// Load stations on startup
setTimeout(loadStations,800);

// Dashboard clock
setInterval(function(){
  var el=document.getElementById('dashClock');
  if(el)el.textContent=new Date().toLocaleString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'});
},1000);

// Auto-refresh every 120s — all pages
setInterval(function(){
  if(activeMod===0)dashRefreshAll();
  if(activeMod===8)hhLoadData();
  if(activeMod===9)monLoad();
  if(activeMod===10)hmLoad();
},120000);

// Initial dashboard load on page start
setTimeout(dashRefreshAll,500);

// ══════════════════════════════════════════════════════════
// HEALTH HISTORY — %Health trend for active station
// ══════════════════════════════════════════════════════════
var hhRange='daily',hhSysChart=null,hhModsChart=null,hhLoaded=false;
var HH_MOD_COLORS={m1:'#2563eb',m2:'#059669',m3:'#d97706',m4:'#dc2626',m5:'#7c3aed',m6:'#0891b2',m7:'#e11d48'};
var HH_MOD_NAMES={m1:'M1 MDB Dust',m2:'M2 Charger Dust',m3:'M3 Offline',m4:'M4 Power',m5:'M5 Network',m6:'M6 RUL',m7:'M7 Failure'};

function hhSetRange(r){
  hhRange=r;
  document.getElementById('hhBtnDaily').classList.toggle('bgh',r==='daily');
  document.getElementById('hhBtnWeekly').classList.toggle('bgh',r==='weekly');
  document.getElementById('hhBtnMonthly').classList.toggle('bgh',r==='monthly');
  document.getElementById('hhBtnDaily').classList.toggle('bt',true);
  document.getElementById('hhBtnWeekly').classList.toggle('bt',true);
  document.getElementById('hhBtnMonthly').classList.toggle('bt',true);
  hhLoadData();
}

function hhFmtTs(iso){
  try{
    var d=new Date(iso);if(isNaN(d))return iso;
    var hh=String(d.getHours()).padStart(2,'0'),mm=String(d.getMinutes()).padStart(2,'0');
    var dd=d.getDate(),mon=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
    if(hhRange==='daily')return hh+':'+mm;
    if(hhRange==='weekly')return dd+' '+mon+' '+hh+':'+mm;
    return dd+' '+mon;
  }catch(e){return iso}
}

function hhBuildSysChart(data){
  var ctx=document.getElementById('hhChart');
  if(!ctx)return;
  var ex=Chart.getChart(ctx);if(ex)ex.destroy();
  if(hhSysChart){try{hhSysChart.destroy();}catch(e){}}
  if(!data.length){return;}
  var labels=data.map(function(p){return hhFmtTs(p.timestamp)});
  var values=data.map(function(p){return p.score});
  // Downsample if needed
  if(labels.length>400){var step=Math.ceil(labels.length/400);labels=labels.filter(function(_,i){return i%step===0});values=values.filter(function(_,i){return i%step===0});}
  // CBM threshold lines
  var len=labels.length;
  var cbm80=new Array(len).fill(80);
  var cbm60=new Array(len).fill(60);
  var cbm40=new Array(len).fill(40);
  hhSysChart=new Chart(ctx,{
    type:'line',
    data:{labels:labels,datasets:[
      {label:'System Health',data:values,borderColor:'#2563eb',backgroundColor:'rgba(37,99,235,.08)',borderWidth:2.5,pointRadius:0,pointHoverRadius:4,tension:.3,fill:true,order:1},
      {label:'CBM: Monitor (80%)',data:cbm80,borderColor:'#22c55e',borderWidth:1.5,borderDash:[8,4],pointRadius:0,pointHoverRadius:0,fill:false,order:2},
      {label:'CBM: Inspect (60%)',data:cbm60,borderColor:'#eab308',borderWidth:1.5,borderDash:[8,4],pointRadius:0,pointHoverRadius:0,fill:false,order:3},
      {label:'CBM: Repair (40%)',data:cbm40,borderColor:'#ef4444',borderWidth:1.5,borderDash:[8,4],pointRadius:0,pointHoverRadius:0,fill:false,order:4}
    ]},
    options:{
      responsive:true,maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{
        legend:{display:true,position:'top',align:'end',labels:{
          usePointStyle:true,pointStyle:'line',
          font:{family:'DM Sans',size:10,weight:'600'},color:'#64748b',padding:12,boxWidth:28,
          filter:function(item){return item.text.indexOf('CBM')===0||item.text==='System Health'}
        }},
        tooltip:{
          backgroundColor:'rgba(255,255,255,.95)',titleColor:'#1e293b',bodyColor:'#475569',borderColor:'#e2e8f0',borderWidth:1,
          bodyFont:{family:'JetBrains Mono',size:11},padding:10,cornerRadius:8,
          filter:function(item){return item.datasetIndex===0},
          callbacks:{
            label:function(c){
              var v=c.parsed.y;
              var zone=v>=80?'\u2705 Good':v>=60?'\u{1F7E1} Monitor':v>=40?'\u{1F7E0} Inspect':'\u{1F534} Repair';
              return 'Health: '+v+'% — '+zone;
            }
          }
        }
      },
      scales:{
        x:{ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:9},maxTicksLimit:14,maxRotation:0},grid:{color:'rgba(0,0,0,.04)'}},
        y:{min:0,max:100,
          ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:9},callback:function(v){return v+'%'},stepSize:20},
          grid:{color:function(ctx){var v=ctx.tick.value;if(v===80)return'rgba(34,197,94,.15)';if(v===60)return'rgba(234,179,8,.15)';if(v===40)return'rgba(239,68,68,.15)';return'rgba(0,0,0,.04)'}}}
      }
    }
  });
}

var hhModHidden={},hhModCacheData=null;
function hhBuildModChart(data){
  if(data)hhModCacheData=data; else data=hhModCacheData;
  var ctx=document.getElementById('hhModChart');
  if(!ctx||!data||!data.length)return;
  var ex=Chart.getChart(ctx);if(ex)ex.destroy();
  if(hhModsChart){try{hhModsChart.destroy();}catch(e){}}
  var labels=[];var modData={m1:[],m2:[],m3:[],m4:[],m5:[],m6:[],m7:[]};
  var step=1;if(data.length>400)step=Math.ceil(data.length/400);
  data.forEach(function(p,idx){
    if(idx%step!==0)return;
    labels.push(hhFmtTs(p.timestamp));
    var mods=p.modules||{};
    for(var k in modData){modData[k].push(mods[k]!==undefined&&mods[k]!==null?mods[k]:null);}
  });
  var datasets=[];
  var legendHtml='';
  for(var mk in HH_MOD_COLORS){
    var hasData=modData[mk].some(function(v){return v!==null});
    if(!hasData)continue;
    var hidden=!!hhModHidden[mk];
    if(!hidden){
      datasets.push({
        label:HH_MOD_NAMES[mk],data:modData[mk],
        borderColor:HH_MOD_COLORS[mk],backgroundColor:HH_MOD_COLORS[mk]+'12',
        borderWidth:1.5,pointRadius:0,pointHoverRadius:3,tension:.3,fill:false,spanGaps:true
      });
    }
    var last=null;for(var i=modData[mk].length-1;i>=0;i--){if(modData[mk][i]!==null){last=modData[mk][i];break;}}
    var opacity=hidden?'0.35':'1';
    var bg=hidden?'transparent':'var(--glass)';
    var dotBg=hidden?'var(--bdr)':HH_MOD_COLORS[mk];
    legendHtml+='<div onclick="hhToggleMod(\''+mk+'\')" style="display:flex;align-items:center;gap:4px;padding:4px 10px;border-radius:6px;border:1px solid '+(hidden?'var(--bdr)':'rgba(0,0,0,.1)')+';font-size:.62rem;font-weight:600;color:var(--dim);cursor:pointer;transition:all .15s;opacity:'+opacity+';background:'+bg+';user-select:none" title="Click to '+(hidden?'show':'hide')+'">';
    legendHtml+='<div style="width:9px;height:9px;border-radius:50%;background:'+dotBg+';flex-shrink:0;transition:background .15s"></div>';
    legendHtml+='<span>'+HH_MOD_NAMES[mk]+'</span>';
    legendHtml+='<span style="font-family:JetBrains Mono,monospace;font-weight:700;color:'+(hidden?'var(--dim)':HH_MOD_COLORS[mk])+'">'+(last!==null?last+'%':'\u2014')+'</span>';
    legendHtml+='</div>';
  }
  // Show/hide all buttons
  var anyHidden=Object.keys(hhModHidden).some(function(k){return hhModHidden[k]});
  legendHtml+='<div onclick="hhToggleAll()" style="display:flex;align-items:center;gap:4px;padding:4px 10px;border-radius:6px;border:1px dashed var(--bdr);font-size:.58rem;font-weight:700;color:var(--bl);cursor:pointer;user-select:none">'+(anyHidden?'\u{1F441} Show All':'Hide All')+'</div>';
  document.getElementById('hhModLegend').innerHTML=legendHtml;
  // Add CBM threshold lines
  var mLen=labels.length;
  datasets.push({label:'80%',data:new Array(mLen).fill(80),borderColor:'rgba(34,197,94,.35)',borderWidth:1,borderDash:[6,4],pointRadius:0,pointHoverRadius:0,fill:false,order:90});
  datasets.push({label:'60%',data:new Array(mLen).fill(60),borderColor:'rgba(234,179,8,.35)',borderWidth:1,borderDash:[6,4],pointRadius:0,pointHoverRadius:0,fill:false,order:91});
  datasets.push({label:'40%',data:new Array(mLen).fill(40),borderColor:'rgba(239,68,68,.35)',borderWidth:1,borderDash:[6,4],pointRadius:0,pointHoverRadius:0,fill:false,order:92});
  hhModsChart=new Chart(ctx,{
    type:'line',
    data:{labels:labels,datasets:datasets},
    options:{
      responsive:true,maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{legend:{display:false},tooltip:{
        backgroundColor:'rgba(255,255,255,.95)',titleColor:'#1e293b',bodyColor:'#475569',borderColor:'#e2e8f0',borderWidth:1,
        bodyFont:{family:'JetBrains Mono',size:10},padding:8,cornerRadius:6,boxPadding:3,
        callbacks:{label:function(c){return c.parsed.y!==null&&c.dataset.label.length>3?c.dataset.label+': '+c.parsed.y+'%':null},
          filter:function(item){return item.parsed.y!==null&&item.dataset.label.length>3}}
      }},
      scales:{
        x:{ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:9},maxTicksLimit:14,maxRotation:0},grid:{color:'rgba(0,0,0,.04)'}},
        y:{min:0,max:100,ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:9},callback:function(v){return v+'%'},stepSize:20},grid:{color:function(ctx){var v=ctx.tick.value;if(v===80)return'rgba(34,197,94,.15)';if(v===60)return'rgba(234,179,8,.15)';if(v===40)return'rgba(239,68,68,.15)';return'rgba(0,0,0,.04)'}}}
      }
    }
  });
}
function hhToggleMod(mk){hhModHidden[mk]=!hhModHidden[mk];hhBuildModChart(null);}
function hhToggleAll(){
  var anyHidden=Object.keys(hhModHidden).some(function(k){return hhModHidden[k]});
  if(anyHidden){hhModHidden={};}
  else{for(var k in HH_MOD_COLORS){hhModHidden[k]=true;}}
  hhBuildModChart(null);
}

async function hhLoadData(){
  var infoEl=document.getElementById('hhStationInfo');
  var chartInfo=document.getElementById('hhChartInfo');
  if(infoEl)infoEl.textContent='Loading...';
  try{
    var sn=window.STATION_CONFIG_ACTIVE||'';
    if(!sn){
      try{var sr=await fetch('/api/active-station');var sd=await sr.json();sn=sd.sn||sd.active_sn||'';}catch(e){}
    }
    if(!sn){if(infoEl)infoEl.textContent='No station selected';return;}
    var r=await fetch('/api/health/history?range='+hhRange);
    var d=await r.json();
    if(d.error){if(infoEl)infoEl.textContent='Error: '+d.error;return;}
    var data=d.data||[];
    var stName=d.station||sn;
    var hrs={'daily':24,'weekly':168,'monthly':720}[hhRange]||24;
    if(infoEl)infoEl.textContent=stName+' \u00B7 '+data.length+' data points \u00B7 '+hhRange+' ('+hrs+'h)';
    if(chartInfo){
      if(data.length){
        var latest=data[data.length-1].score;
        var zone=latest>=80?'\u2705 Good (ติดตามปกติ)':latest>=60?'\u{1F7E1} Monitor (ติดตามใกล้ชิด)':latest>=40?'\u{1F7E0} Inspect (ตรวจสอบด่วน)':'\u{1F534} Repair (เข้าแก้ไขทันที)';
        chartInfo.textContent='Latest: '+latest+'% — CBM Zone: '+zone+' \u00B7 '+(data[data.length-1].timestamp||'').replace('T',' ').substring(0,19);
      }else{chartInfo.textContent='No data for this station';}
    }
    hhBuildSysChart(data);
    hhBuildModChart(data);
    hhLoaded=true;
  }catch(e){
    if(infoEl)infoEl.textContent='Error: '+e.message;
  }
}

// ══════════════════════════════════════════════════════════
// STATION MONITOR — All stations table (embedded)
// ══════════════════════════════════════════════════════════
var monData=[],monLoaded=false;
function monGrade(s){if(s===null||s===undefined)return'-';if(s>=80)return'A';if(s>=60)return'B';if(s>=40)return'C';if(s>=20)return'D';return'F';}
function monPill(m){
  if(!m)return '<span style="display:inline-block;min-width:34px;padding:2px 6px;border-radius:6px;font-weight:700;font-size:.65rem;font-family:JetBrains Mono,monospace;text-align:center;background:rgba(100,116,139,.08);color:var(--dim);border:1px solid var(--bdr)">\u2014</span>';
  if(m.error)return '<span style="display:inline-block;min-width:34px;padding:2px 6px;border-radius:6px;font-weight:700;font-size:.55rem;font-family:JetBrains Mono,monospace;text-align:center;background:rgba(239,68,68,.08);color:#f87171;border:1px solid rgba(239,68,68,.15)">ERR</span>';
  var h=m.health;if(h===null||h===undefined)return '<span style="display:inline-block;min-width:34px;padding:2px 6px;border-radius:6px;font-weight:700;font-size:.65rem;font-family:JetBrains Mono,monospace;text-align:center;background:rgba(100,116,139,.08);color:var(--dim);border:1px solid var(--bdr)">\u2014</span>';
  var bg=h>=80?'rgba(34,197,94,.1)':h>=50?'rgba(234,179,8,.1)':'rgba(239,68,68,.1)';
  var c=h>=80?'#22c55e':h>=50?'#eab308':'#ef4444';
  var bd=h>=80?'rgba(34,197,94,.2)':h>=50?'rgba(234,179,8,.2)':'rgba(239,68,68,.2)';
  return '<span style="display:inline-block;min-width:34px;padding:2px 6px;border-radius:6px;font-weight:700;font-size:.65rem;font-family:JetBrains Mono,monospace;text-align:center;background:'+bg+';color:'+c+';border:1px solid '+bd+'">'+h+'</span>';
}
function monRenderKpis(s){
  var el=document.getElementById('monKpis');if(!el)return;
  var t=s.total_stations||0,f=s.full_coverage||0,p=s.partial||0,n=s.no_data||0;
  el.innerHTML=[
    {l:'Total',v:t,c:'var(--bl)',bg:'rgba(59,130,246,.06)',bc:'rgba(59,130,246,.15)'},
    {l:'Full (7/7)',v:f,c:'#22c55e',bg:'rgba(34,197,94,.06)',bc:'rgba(34,197,94,.15)'},
    {l:'Partial',v:p,c:'#eab308',bg:'rgba(234,179,8,.06)',bc:'rgba(234,179,8,.15)'},
    {l:'No Data',v:n,c:'#ef4444',bg:'rgba(239,68,68,.06)',bc:'rgba(239,68,68,.15)'}
  ].map(function(k){return '<div style="background:'+k.bg+';border:1px solid '+k.bc+';border-radius:10px;padding:10px 14px"><div style="font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--dim)">'+k.l+'</div><div style="font-family:JetBrains Mono,monospace;font-size:1.5rem;font-weight:800;color:'+k.c+';margin-top:4px">'+k.v+'</div></div>'}).join('');
}
function monRenderTable(data){
  var el=document.getElementById('monTable');if(!el)return;
  if(!data.length){el.innerHTML='<div style="padding:30px;text-align:center;color:var(--dim)">No stations match filter</div>';return}
  var h='<table style="width:100%;border-collapse:collapse;font-size:.72rem"><thead><tr>';
  ['#','Station','M1','M2','M3','M4','M5','M6','M7','Health','Cov','Updated'].forEach(function(th,i){
    h+='<th style="background:var(--glass);color:var(--dim);text-transform:uppercase;font-size:.55rem;letter-spacing:.5px;font-weight:700;padding:8px 6px;text-align:'+(i<2?'left':'center')+';border-bottom:1px solid var(--bdr)">'+(i===0?'#':th)+'</th>';
  });
  h+='</tr></thead><tbody>';
  data.forEach(function(s,idx){
    var g=monGrade(s.system_health);
    var gc=g==='A'?'#22c55e':g==='B'?'#84cc16':g==='C'?'#eab308':g==='D'?'#f97316':'#ef4444';
    if(g==='-')gc='var(--dim)';
    var ts=s.last_updated?new Date(s.last_updated).toLocaleString('en-GB',{hour:'2-digit',minute:'2-digit',day:'2-digit',month:'short'}):'\u2014';
    h+='<tr style="border-bottom:1px solid rgba(0,0,0,.04)">';
    h+='<td style="padding:6px;text-align:left;font-size:.65rem;color:var(--dim)">'+(idx+1)+'</td>';
    h+='<td style="padding:6px;text-align:left"><div style="font-weight:700;font-size:.75rem">'+(s.name&&s.name!==s.sn?s.name:s.sn)+'</div><div style="font-family:JetBrains Mono,monospace;font-size:.55rem;color:var(--dim)">'+s.sn+'</div></td>';
    for(var i=1;i<=7;i++){h+='<td style="padding:6px;text-align:center">'+monPill(s.modules['m'+i])+'</td>';}
    h+='<td style="padding:6px;text-align:center;font-family:JetBrains Mono,monospace;font-weight:800;font-size:.8rem;color:'+gc+'">'+(s.system_health!==null&&s.system_health!==undefined?s.system_health+'%':'\u2014')+'</td>';
    h+='<td style="padding:6px;text-align:center;font-family:JetBrains Mono,monospace;font-size:.65rem;color:var(--dim)">'+s.ok_count+'/7</td>';
    h+='<td style="padding:6px;text-align:center;font-family:JetBrains Mono,monospace;font-size:.55rem;color:var(--dim)">'+ts+'</td>';
    h+='</tr>';
  });
  h+='</tbody></table>';
  el.innerHTML=h;
}
function monFilter(){
  var q=(document.getElementById('monSearch').value||'').toLowerCase();
  var f=document.getElementById('monFilterSel').value;
  var filtered=monData.filter(function(s){
    if(q&&!s.sn.toLowerCase().includes(q)&&!(s.name||'').toLowerCase().includes(q))return false;
    if(f==='full'&&s.ok_count<7)return false;
    if(f==='partial'&&(s.ok_count===0||s.ok_count>=7))return false;
    if(f==='none'&&s.ok_count!==0)return false;
    return true;
  });
  monRenderTable(filtered);
}
async function monLoad(){
  try{
    var r=await fetch('/api/monitor/overview');var d=await r.json();
    if(d.error)return;
    monData=d.stations||[];
    monRenderKpis(d.summary||{total_stations:0,full_coverage:0,partial:0,no_data:0});
    monFilter();
    monLoaded=true;
  }catch(e){console.error(e)}
}

// ══════════════════════════════════════════════════════════
// HEATMAP — All stations visual grid (embedded)
// ══════════════════════════════════════════════════════════
var hmData=[],hmLoaded=false;
function hmColor(h){
  if(h===null||h===undefined)return 'var(--bdr)';
  var r,g,b;
  if(h<=50){var t=h/50;r=Math.round(220-(220-234)*t);g=Math.round(38+(179-38)*t);b=Math.round(38+(8-38)*t);}
  else{var t=(h-50)/50;r=Math.round(234-(234-22)*t);g=Math.round(179+(163-179)*t);b=Math.round(8+(74-8)*t);}
  return 'rgb('+r+','+g+','+b+')';
}
function hmCalcGrid(n){
  var wrap=document.getElementById('hmWrap');if(!wrap)return{cols:12,rows:12};
  var W=wrap.clientWidth-8,H=wrap.clientHeight-8;
  var bc=1,bs=0;
  for(var c=1;c<=n;c++){var rr=Math.ceil(n/c);var cw=W/c,ch=H/rr;var s=Math.min(cw,ch)*Math.min(cw/ch,ch/cw);if(s>bs){bs=s;bc=c;}}
  return{cols:bc,rows:Math.ceil(n/bc)};
}
function hmRender(){
  var el=document.getElementById('hmGrid');if(!el||!hmData.length)return;
  var g=hmCalcGrid(hmData.length);
  el.style.gridTemplateColumns='repeat('+g.cols+',1fr)';
  el.style.gridTemplateRows='repeat('+g.rows+',1fr)';
  var html='';
  hmData.forEach(function(s,i){
    var h=s.system_health;var bg=hmColor(h);
    var nd=h===null||h===undefined;
    var name=s.name&&s.name!==s.sn?s.name:s.sn;
    var short=name.replace(/^PT_/,'').replace(/_/g,' ');if(short.length>14)short=short.substring(0,13)+'..';
    html+='<div style="border-radius:4px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;position:relative;overflow:hidden;min-width:0;min-height:0;background:'+bg+';box-shadow:inset 0 1px 0 rgba(255,255,255,.2);transition:all .15s" onmouseenter="hmShowTip(event,'+i+')" onmouseleave="hmHideTip()" onmousemove="hmMoveTip(event)"'+(nd?' class="hmnd"':'')+'>';
    html+='<div style="font-size:clamp(.3rem,.55vw,.55rem);font-weight:700;color:'+(nd?'var(--dim)':'rgba(255,255,255,.92)')+';text-align:center;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%;padding:0 2px;'+(nd?'':'text-shadow:0 1px 2px rgba(0,0,0,.3)')+'">'+short+'</div>';
    html+='<div style="font-family:JetBrains Mono,monospace;font-size:clamp(.38rem,.7vw,.7rem);font-weight:800;color:'+(nd?'var(--dim)':'#fff')+';'+(nd?'':'text-shadow:0 1px 3px rgba(0,0,0,.3)')+'">'+(nd?'\u2014':h+'%')+'</div>';
    html+='</div>';
  });
  el.innerHTML=html;
}
function hmShowTip(ev,i){
  var s=hmData[i];if(!s)return;
  var tip=document.getElementById('hmTip');
  document.getElementById('hmTipName').textContent=s.name&&s.name!==s.sn?s.name:s.sn;
  document.getElementById('hmTipSn').textContent='SN: '+s.sn;
  var h=s.system_health;
  var he=document.getElementById('hmTipHealth');
  he.textContent=h!==null&&h!==undefined?h+'%':'No Data';
  he.style.color=h>=80?'#22c55e':h>=60?'#84cc16':h>=40?'#eab308':h!==null&&h!==undefined?'#ef4444':'var(--dim)';
  var mh='';
  for(var m=1;m<=7;m++){
    var mod=s.modules?s.modules['m'+m]:null;var v=mod?mod.health:null;
    var cls=v===null||v===undefined?'background:rgba(100,116,139,.08);color:var(--dim)':v>=80?'background:rgba(34,197,94,.1);color:#22c55e':v>=50?'background:rgba(234,179,8,.1);color:#eab308':'background:rgba(239,68,68,.1);color:#ef4444';
    mh+='<div style="text-align:center;padding:4px 0;border-radius:4px;font-family:JetBrains Mono,monospace;font-size:.55rem;font-weight:700;'+cls+'">M'+m+'<br>'+(v!==null&&v!==undefined?v:'\u2014')+'</div>';
  }
  document.getElementById('hmTipMods').innerHTML=mh;
  tip.style.display='block';hmMoveTip(ev);
}
function hmMoveTip(ev){var t=document.getElementById('hmTip');var x=ev.clientX+14,y=ev.clientY+14;if(x+230>window.innerWidth)x=ev.clientX-230;if(y+200>window.innerHeight)y=ev.clientY-200;t.style.left=x+'px';t.style.top=y+'px';}
function hmHideTip(){document.getElementById('hmTip').style.display='none';}
async function hmLoad(){
  try{
    var r=await fetch('/api/monitor/overview');var d=await r.json();
    if(d.error)return;
    hmData=d.stations||[];
    var sum=d.summary||{};
    document.getElementById('hmInfo').textContent=hmData.length+' stations \u00B7 Avg '+(function(){var s=0,c=0;hmData.forEach(function(st){if(st.system_health!==null){s+=st.system_health;c++}});return c?Math.round(s/c)+'%':'\u2014'})();
    hmRender();hmLoaded=true;
  }catch(e){console.error(e)}
}
window.addEventListener('resize',function(){if(activeMod===10&&hmData.length)hmRender();});

// MODULE 1: MDB Dust Filter Clogging Prediction JavaScript
// ══════════════════════════════════════════════════════════
var m1ApOn=true,m1ApInterval=null,m1ApCountdown=0;
var m1PredHistory=[];

function m1stab(n){
  var tabs=['main','predict','history','algos'];
  document.querySelectorAll('#pageMod1 .tb').forEach(function(t,i){t.classList.toggle('on',i===tabs.indexOf(n))});
  document.querySelectorAll('#pageMod1 .tc').forEach(function(c){c.classList.toggle('on',c.id==='m1tab-'+n)});
}
function m1esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

async function m1CheckModels(){
  try{
    var r=await fetch('/api/m1/models');var d=await r.json();
    if(d.error){console.error('[M1]',d.error);return;}
    var grid=document.getElementById('m1LoadGrid');if(!grid)return;
    var models=d.models||[],loaded=d.loaded||0,total=d.total||models.length;
    var cntEl=document.getElementById('m1ModelCnt');if(cntEl)cntEl.textContent=loaded+' / '+total;
    var bar=document.getElementById('m1LoadBar');if(bar)bar.style.width=(total?loaded/total*100:0)+'%';
    var html=[];
    for(var i=0;i<models.length;i++){var m=models[i];var ok=m.loaded;var c=ok?'#22c55e':'#ef4444';
      html.push('<div class="m3-load-item" style="border-color:'+c+'"><div class="m3-load-dot" style="background:'+c+'"></div><div class="m3-load-name">'+m1esc(m.name)+'</div><div class="m3-load-st" style="color:'+c+'">'+( ok?'OK':'FAIL')+'</div></div>');}
    grid.innerHTML=html.join('');
    if(d.db){var st=d.db.connected;
      var stEl=document.getElementById('m1DbStatus');
      if(stEl){stEl.textContent=st?'\u2705 Connected':'\u274c Disconnected';stEl.style.color=st?'#34d399':'#f87171';}
    }
  }catch(e){console.error('[M1]',e);}
}

function m1UpdateGauge(risk){
  var fg=document.getElementById('m1GaugeFg');
  var val=document.getElementById('m1RiskVal');
  var lbl=document.getElementById('m1RiskLabel');
  if(!fg||!val||!lbl)return;
  var pct=Math.max(0,Math.min(risk,1));
  // Arc is 270 degrees (3/4 of circle), circumference portion = 368
  var maxArc=245; // 2/3 of 368
  fg.style.strokeDashoffset=368-pct*maxArc;
  val.textContent=(pct*100).toFixed(1)+'%';
  var col,st;
  if(pct<0.25){col='#22c55e';st='CLEAN';}
  else if(pct<0.5){col='#eab308';st='MODERATE';}
  else if(pct<0.75){col='#f97316';st='DEGRADED';}
  else{col='#ef4444';st='CLOGGED';}
  fg.style.stroke=col;val.style.color=col;lbl.textContent=st;lbl.style.color=col;
}

function m1UpdateEnv(data){
  var sets=[
    ['m1TempVal',data.MDB_ambient_temp,'\u00b0C'],
    ['m1Pi5Val',data.pi5_temp,'\u00b0C'],
    ['m1HumVal',data.MDB_humidity,'%'],
    ['m1PressVal',data.MDB_pressure,'hPa'],
    ['m1Meter1Val',data.meter1,null],
    ['m1Meter2Val',data.meter2,null]
  ];
  for(var i=0;i<sets.length;i++){
    var el=document.getElementById(sets[i][0]);
    if(el&&sets[i][1]!==undefined&&sets[i][1]!==null){
      el.textContent=typeof sets[i][1]==='number'?sets[i][1].toFixed(1):sets[i][1];
    }
  }
  // Temp diff
  if(data.pi5_temp!==undefined&&data.MDB_ambient_temp!==undefined){
    var td=document.getElementById('m1TdiffVal');
    if(td)td.textContent=(data.pi5_temp-data.MDB_ambient_temp).toFixed(1);
  }
  // Status
  var stEl=document.getElementById('m1StatusVal');
  if(stEl&&data.MDB_status!==undefined){
    var isOn=String(data.MDB_status).toLowerCase()==='active';
    stEl.textContent=isOn?'ACTIVE':'OFFLINE';
    stEl.style.color=isOn?'#22c55e':'#ef4444';
  }
  // Filter age bar
  var age=data.dust_filter_charging;
  if(age!==undefined){
    var ageEl=document.getElementById('m1FilterAge');
    if(ageEl)ageEl.textContent=age+' days';
    var bar=document.getElementById('m1FilterBar');
    if(bar){
      var pct=Math.min(age/120*100,100);
      var col=age<=30?'#22c55e':age<=60?'#eab308':age<=90?'#f97316':'#ef4444';
      bar.style.width=pct+'%';
      bar.style.background='linear-gradient(90deg,#22c55e,'+col+')';
      bar.setAttribute('data-label',age+' days');
    }
  }
}

function m1RenderResults(results){
  var grid=document.getElementById('m1ResultsGrid');if(!grid||!results)return;
  var h=[];
  var models=[
    {key:'rule_engine',name:'Rule Engine'},{key:'isolation_forest',name:'Isolation Forest'},
    {key:'lof',name:'LOF'},{key:'autoencoder',name:'Autoencoder'},
    {key:'xgb_classifier',name:'XGBoost Clf'},{key:'xgb_regressor',name:'XGBoost Reg'},
    {key:'multitask_dnn',name:'Multi-Task DNN'},{key:'bilstm',name:'BiLSTM'},
    {key:'cnn_1d',name:'1D-CNN'},{key:'gradient_boosting',name:'Grad. Boost'},
    {key:'ensemble',name:'Ensemble'}
  ];
  for(var i=0;i<models.length;i++){
    var m=models[i];var r=results[m.key];if(!r)continue;
    var score=r.score!==undefined?r.score:null;
    var ss=score!==null?(score*100).toFixed(1)+'%':'N/A';
    var cls=score===null?'ok':score>=0.5?'crit':score>=0.25?'warn':'ok';
    var sc=cls==='crit'?'#ef4444':cls==='warn'?'#eab308':'#22c55e';
    var label=r.label||'';
    h.push('<div class="m1-rc '+cls+'"><div class="rn">'+m1esc(m.name)+'</div><div class="rs" style="color:'+sc+'">'+ss+'</div><div class="rt" style="color:'+sc+'">'+m1esc(label)+'</div></div>');
  }
  grid.innerHTML=h.length?h.join(''):'<div style="color:var(--dim);font-size:.75em;grid-column:1/-1">No results</div>';
}

async function m1RunPredict(){
  var badge=document.getElementById('m1ApBadge');
  if(badge){badge.textContent='RUNNING';badge.className='m3-ap-badge running';}
  var t0=Date.now();
  var qts=document.getElementById('m1ApQueryTs');if(qts)qts.textContent=new Date().toLocaleTimeString();
  try{
    var r=await fetch('/api/m1/latest');var d=await r.json();
    if(d.error){
      console.error('[M1]',d.error,d.message||'');
      if(badge){badge.textContent='ERROR';badge.className='m3-ap-badge error';}
      var dbi=document.getElementById('m1DbInfo');
      if(dbi&&d.available_collections){dbi.textContent='module1MdbDustPrediction — not found for this station. Available: '+d.available_collections.slice(0,5).join(', ')+(d.available_collections.length>5?' ...':'');}
      else if(dbi&&d.message){dbi.textContent=d.message;}
      var stEl=document.getElementById('m1DbStatus');if(stEl){stEl.textContent='\u274c '+(d.message||d.error);stEl.style.color='#f87171';}
      return;
    }
    // Update environmental readings
    if(d.telemetry)m1UpdateEnv(d.telemetry);
    // Update gauge
    var risk=d.ensemble_risk||d.risk_score||0;
    m1UpdateGauge(risk);
    // Update results
    if(d.model_results)m1RenderResults(d.model_results);
    // Update ensemble panel
    var ensEl=document.getElementById('m1EnsScore');
    if(ensEl)ensEl.textContent=(risk*100).toFixed(1)+'%';
    var ensStEl=document.getElementById('m1EnsStatus');
    if(ensStEl){
      var lbl=risk<0.25?'CLEAN':risk<0.5?'MODERATE':risk<0.75?'DEGRADED':'CLOGGED';
      var col=risk<0.25?'#22c55e':risk<0.5?'#eab308':risk<0.75?'#f97316':'#ef4444';
      ensStEl.textContent=lbl;ensStEl.style.color=col;
    }
    var ensConf=document.getElementById('m1EnsConf');
    if(ensConf&&d.confidence)ensConf.textContent=(d.confidence*100).toFixed(0)+'%';
    // Latency
    var lat=Date.now()-t0;
    var latEl=document.getElementById('m1ApLat');if(latEl)latEl.textContent=lat+'ms';
    var predTs=document.getElementById('m1ApPredTs');if(predTs)predTs.textContent=new Date().toLocaleTimeString();
    var riskEl=document.getElementById('m1ApRisk');if(riskEl){riskEl.textContent=(risk*100).toFixed(1)+'%';riskEl.style.color=risk<0.5?'#22c55e':'#ef4444';}
    // LED & DB info
    document.getElementById('m1Led').className='led on';
    document.getElementById('m1St').textContent='Connected';
    var sb=document.getElementById('m1SrcBadge');if(sb){if(d.source==='mongodb')sb.className='m1-badge mg';else sb.className='m1-badge mq';}
    if(d.collection){var dbi=document.getElementById('m1DbInfo');if(dbi)dbi.textContent=(d.database||'module1MdbDustPrediction')+'.'+d.collection+' ('+( d.fields_count||'?')+' fields)';}
    var stEl2=document.getElementById('m1DbStatus');if(stEl2){stEl2.textContent='\u2705 Connected'+(d.method?' ['+d.method+']':'');stEl2.style.color='#34d399';}
    // Prediction history
    m1PredHistory.unshift({time:new Date().toLocaleTimeString(),risk:risk,lat:lat});
    if(m1PredHistory.length>20)m1PredHistory.pop();
    var hEl=document.getElementById('m1PredHistory');
    if(hEl){
      var hh=m1PredHistory.map(function(p){
        var col=p.risk<0.25?'#22c55e':p.risk<0.5?'#eab308':p.risk<0.75?'#f97316':'#ef4444';
        var lbl=p.risk<0.25?'Clean':p.risk<0.5?'Moderate':p.risk<0.75?'Degraded':'Clogged';
        return '<div class="m1-pred-item"><span style="color:var(--dim)">'+p.time+'</span><span style="display:flex;align-items:center;gap:6px"><span style="width:8px;height:8px;border-radius:50%;background:'+col+'"></span><span style="color:'+col+';font-weight:700">'+(p.risk*100).toFixed(1)+'%</span><span style="font-size:.85em;color:var(--dim)">'+lbl+'</span></span><span style="color:var(--dim);font-family:JetBrains Mono,monospace;font-size:.9em">'+p.lat+'ms</span></div>';
      });
      hEl.innerHTML=hh.join('');
    }
    if(badge){badge.textContent='DONE';badge.className='m3-ap-badge done';setTimeout(function(){if(m1ApOn){badge.textContent='WAITING';badge.className='m3-ap-badge idle';}},2000);}
  }catch(e){
    console.error('[M1]',e);
    if(badge){badge.textContent='ERROR';badge.className='m3-ap-badge error';}
  }
}

function m1ApToggleChanged(){
  m1ApOn=document.getElementById('m1ApToggle').checked;
  if(m1ApOn){
    m1RunPredict();m1ApCountdown=120;
    m1ApInterval=setInterval(function(){m1ApCountdown--;document.getElementById('m1ApCd').textContent=m1ApCountdown+'s';if(m1ApCountdown<=0){m1ApCountdown=120;m1RunPredict();}},1000);
  }else{
    clearInterval(m1ApInterval);m1ApInterval=null;
    document.getElementById('m1ApCd').textContent='OFF';
    document.getElementById('m1ApBadge').textContent='IDLE';
    document.getElementById('m1ApBadge').className='m3-ap-badge idle';
  }
}
// ── Module 1: Historical Graph ──
let m1HistChart=null;
const M1_HIST_GROUPS={
  temperature:{fields:['MDB_ambient_temp','pi5_temp'],label:'Temperature',colors:['#ef4444','#f97316'],names:['MDB Ambient','Pi5 CPU']},
  environment:{fields:['MDB_humidity','MDB_pressure'],label:'Environment',colors:['#3b82f6','#8b5cf6'],names:['Humidity (%)','Pressure (hPa)'],dualAxis:true},
  filter:{fields:['dust_filter_charging'],label:'Filter Age',colors:['#d97706'],names:['Days Since Change']},
  meters:{fields:['meter1','meter2'],label:'Energy Meters',colors:['#22c55e','#06b6d4'],names:['Meter 1','Meter 2']},
  all_sensors:{fields:['MDB_ambient_temp','pi5_temp','MDB_humidity'],label:'All Key Sensors',colors:['#ef4444','#f97316','#3b82f6'],names:['MDB Temp','Pi5 Temp','Humidity']}
};

async function m1LoadHistory(){
  var range=document.getElementById('m1HistRange').value;
  var grpKey=document.getElementById('m1HistFields').value;
  var grp=M1_HIST_GROUPS[grpKey];if(!grp)return;
  var msg=document.getElementById('m1HistMsg');if(msg)msg.textContent='Loading data\u2026';
  var titleEl=document.getElementById('m1HistChartTitle');
  var rangeLabel={daily:'24h',weekly:'7d',monthly:'30d'}[range]||range;
  if(titleEl)titleEl.textContent=grp.label+' \u2014 '+rangeLabel;
  try{
    var url='/api/m1/historical?range='+range+'&fields='+grp.fields.join(',');
    var r=await fetch(url);var d=await r.json();
    if(!d.timestamps||!d.timestamps.length){if(msg)msg.textContent='No data available for this time range';return}
    if(msg)msg.textContent='';
    var ctx=document.getElementById('m1HistChart');
    if(m1HistChart)m1HistChart.destroy();
    var labels=d.timestamps.map(function(ts){
      try{var dt=new Date(ts);if(isNaN(dt))return ts;var h=dt.getHours().toString().padStart(2,'0');var m=dt.getMinutes().toString().padStart(2,'0');
        if(range==='weekly'||range==='monthly')return dt.getDate()+'/'+(dt.getMonth()+1)+' '+h+':'+m;return h+':'+m;
      }catch(e){return ts}
    });
    var datasets=grp.fields.map(function(f,i){return{
      label:(grp.names&&grp.names[i])||f.replace(/_/g,' '),
      data:d.values[f]||[],
      borderColor:grp.colors[i%grp.colors.length],
      backgroundColor:grp.colors[i%grp.colors.length]+'18',
      borderWidth:1.5,pointRadius:0,tension:0.35,fill:grp.fields.length<=2,
      yAxisID:grp.dualAxis&&i>0?'y1':'y'
    }});
    var cs=getComputedStyle(document.documentElement);
    var dimC=cs.getPropertyValue('--dim').trim()||'#64748b';
    var opts={responsive:true,maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{
        legend:{labels:{color:dimC,font:{size:10,family:'JetBrains Mono',weight:'600'},boxWidth:14,boxHeight:2,padding:12}},
        tooltip:{backgroundColor:'rgba(15,23,42,.92)',titleFont:{family:'JetBrains Mono',size:11},bodyFont:{family:'JetBrains Mono',size:10},padding:10,cornerRadius:8,borderColor:'rgba(5,150,105,.2)',borderWidth:1}
      },
      scales:{
        x:{ticks:{color:dimC,maxTicksLimit:14,maxRotation:0,font:{size:8.5,family:'JetBrains Mono'}},grid:{color:'rgba(100,116,139,.06)',drawBorder:false}},
        y:{position:'left',ticks:{color:dimC,font:{size:9,family:'JetBrains Mono'},padding:8},grid:{color:'rgba(100,116,139,.08)',drawBorder:false}}
      }
    };
    if(grp.dualAxis){opts.scales.y1={position:'right',ticks:{color:dimC,font:{size:9,family:'JetBrains Mono'}},grid:{drawOnChartArea:false}}}
    m1HistChart=new Chart(ctx,{type:'line',data:{labels:labels,datasets:datasets},options:opts});
  }catch(e){if(msg)msg.textContent='Error: '+e.message}
}

// ── End Module 1 ──


// MODULE 7: EV-PLCC State Monitoring JavaScript
var m7ApOn=true,m7ApInterval=null,m7ApCountdown=0;
var M7_ICP_STATES=[
  {id:0,name:'Inactive',desc:'System not active',color:'#6b7280'},
  {id:1,name:'A1',desc:'Connector not plugged in (PWM off)',color:'#94a3b8'},
  {id:2,name:'B1',desc:'Connector plugged in (PWM off)',color:'#60a5fa'},
  {id:3,name:'C1',desc:'Vehicle ready for charging (PWM off)',color:'#34d399'},
  {id:4,name:'D1',desc:'Vehicle ready (PWM off + ventilation)',color:'#a3e635'},
  {id:5,name:'A2',desc:'Connector not plugged in (PWM on)',color:'#c084fc'},
  {id:6,name:'B2',desc:'Connector plugged in (PWM on)',color:'#38bdf8'},
  {id:7,name:'C2',desc:'Vehicle is charging (PWM on)',color:'#22c55e'},
  {id:8,name:'D2',desc:'Vehicle charging (PWM on + ventilation)',color:'#4ade80'},
  {id:9,name:'E',desc:'CP measures 0V; Faulty status',color:'#ef4444'},
  {id:10,name:'Error',desc:'State machine in error',color:'#dc2626'}
];
var M7_USL_STATES=[
  {id:0,name:'Ready',desc:'Communication ready'},
  {id:1,name:'Init',desc:'Initialization'},
  {id:2,name:'SLAC ok',desc:'Signal Level Attenuation Characterization done'},
  {id:3,name:'SECC ok',desc:'Secure communication established'},
  {id:4,name:'SupportedAppProtocol',desc:'Application protocol negotiated'},
  {id:5,name:'SessionSetup',desc:'Session initiated'},
  {id:6,name:'ServiceDiscovery',desc:'Discovering supported services'},
  {id:7,name:'ServicePaymentSelection',desc:'Selecting payment method'},
  {id:8,name:'ContractAuthentication',desc:'Authenticating contract'},
  {id:9,name:'ChargeParameterDiscovery',desc:'Negotiating charge parameters'},
  {id:10,name:'CableCheck',desc:'Verifying cable connection'},
  {id:11,name:'PreCharge',desc:'Pre-charging step'},
  {id:12,name:'PowerDelivery',desc:'Enabling power flow'},
  {id:13,name:'CurrentDemand',desc:'Exchanging current demand data'},
  {id:14,name:'WeldingDetection',desc:'Detecting unwanted welds'},
  {id:15,name:'SessionStop',desc:'Terminating session'},
  {id:16,name:'ProtocolFinished',desc:'Communication finished'},
  {id:17,name:'ServiceDetail',desc:'Service detail exchange'},
  {id:18,name:'ServiceDetails',desc:'Extended service information'},
  {id:19,name:'ChargingStatus',desc:'Reporting charging status'},
  {id:20,name:'MeteringReceipt',desc:'Metering and receipt exchange'},
  {id:21,name:'CertInstallation',desc:'Installing certificates'},
  {id:22,name:'CertUpdate',desc:'Updating certificates'}
];
var M7_USL_COLORS=['#6b7280','#94a3b8','#3b82f6','#2563eb','#1d4ed8','#7c3aed','#6d28d9','#a855f7','#d946ef','#ec4899','#f43f5e','#f97316','#22c55e','#10b981','#14b8a6','#ef4444','#64748b','#0ea5e9','#06b6d4','#8b5cf6','#d97706','#059669','#0284c7'];
var M7_SEQ_STEPS=[
  {uslink:2,label:'SLAC Matching'},{uslink:3,label:'SECC Comm'},{uslink:4,label:'AppProtocol'},
  {uslink:5,label:'SessionSetup'},{uslink:6,label:'ServiceDiscovery'},{uslink:7,label:'PaymentSelection'},
  {uslink:8,label:'Authentication'},{uslink:9,label:'ParamDiscovery'},{uslink:10,label:'CableCheck'},
  {uslink:11,label:'PreCharge'},{uslink:12,label:'PowerDelivery'},{uslink:13,label:'CurrentDemand'},
  {uslink:14,label:'WeldingDetect'},{uslink:15,label:'SessionStop'}
];

function m7stab(n){
  var tabs=['main','timeline','predict','algos'];
  document.querySelectorAll('#pageMod7 .tb').forEach(function(t,i){t.classList.toggle('on',i===tabs.indexOf(n))});
  document.querySelectorAll('#pageMod7 .tc').forEach(function(c){c.classList.toggle('on',c.id==='m7tab-'+n)});
  if(n==='main')m7RenderSeqFlow();
  if(n==='timeline')setTimeout(m7DrawTimeline,100);
}
function m7esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

async function m7CheckModels(){
  // (removed debug log)
  try{
    var r=await fetch('/api/m7/models');var d=await r.json();
    // (removed debug log)
    if(d.error){console.error('[M7] API ERROR:',d.error);var grid=document.getElementById('m7LoadGrid');if(grid)grid.innerHTML='<div style="color:#f87171;padding:12px;font-size:.8em">API Error: '+m7esc(d.error)+'</div>';return;}
    var grid=document.getElementById('m7LoadGrid');if(!grid)return;
    var models=d.models||[],loaded=d.loaded||0,total=d.total||models.length;
    var cntEl=document.getElementById('m7ModelCnt');if(cntEl)cntEl.textContent=loaded+' / '+total;
    var html=[];
    for(var i=0;i<models.length;i++){
      var m=models[i],ok=m.loaded,icon=ok?'&#9989;':'&#10060;',cls=ok?'m3-load-ok':'m3-load-fail';
      var typeColors={ML:'#2563eb',DL:'#7c3aed',PP:'#059669',CF:'#d97706',SC:'#0891b2',IN:'#dc2626'};
      var tc=typeColors[m.type]||'#6b7280';
      var errHtml=m.error?'<div style="color:#f87171;font-size:.65em;margin-top:2px">'+m7esc(String(m.error).substring(0,60))+'</div>':'';
      html.push('<div class="m3-load-item '+cls+'" title="'+m7esc(m.name)+'"><div class="m3-load-item-top"><span class="m3-load-icon">'+icon+'</span><span class="m3-load-id" style="background:'+tc+'">'+m7esc(m.type||'?')+'</span></div><div class="m3-load-name">'+m7esc(m.name)+'</div>'+errHtml+'</div>');
    }
    grid.innerHTML=html.join('');
    var pct=total>0?Math.round(loaded/total*100):0;
    var barEl=document.getElementById('m7LoadBar');
    if(barEl){barEl.style.width=pct+'%';barEl.style.background=pct>=100?'linear-gradient(90deg,#059669,#34d399)':pct>50?'linear-gradient(90deg,#d97706,#fbbf24)':'linear-gradient(90deg,#dc2626,#f87171)';}
    if(d.db){var dbSt=document.getElementById('m7DbStatus');var dbInf=document.getElementById('m7DbInfo');
      if(d.db.connected){if(dbSt)dbSt.innerHTML='<span style="color:#34d399">&#9679; Connected</span>';if(dbInf)dbInf.textContent='database: '+d.db.database+' | collection: '+d.db.collection+(d.db.docs?' | docs: '+d.db.docs:'');}
      else{if(dbSt)dbSt.innerHTML='<span style="color:#f87171">&#9679; Disconnected</span>';}}
    if(d.db&&d.db.mqtt_connected!==undefined){var dbInf=document.getElementById('m7DbInfo');if(dbInf)dbInf.textContent+=(d.db.mqtt_connected?' | MQTT: ✅ Live':' | MQTT: ❌ Offline');}
    var led=document.getElementById('m7Led'),st=document.getElementById('m7St');
    if(led)led.className=loaded>0?'led led-on':'led';if(st)st.textContent=loaded>0?'Online':'Offline';
  }catch(e){console.error('[M7] m7CheckModels EXCEPTION:',e.message,e.stack);}
}

function m7RenderSeqFlow(activeUsl){
  var el=document.getElementById('m7SeqFlow');if(!el)return;var html=[];activeUsl=activeUsl||null;
  for(var i=0;i<M7_SEQ_STEPS.length;i++){var s=M7_SEQ_STEPS[i];var col=M7_USL_COLORS[s.uslink]||'#6b7280';
        var isAct=activeUsl!==null&&s.uslink===activeUsl;var isDone=activeUsl!==null&&s.uslink<activeUsl;
    html.push('<div class="m7-ss'+(isAct?' on':'')+(isDone?' dn':'')+'" style="background:'+col+';--sw:'+col+'40">'+m7esc(s.label)+'</div>');
    if(i<M7_SEQ_STEPS.length-1)html.push('<span class="m7-sa">&#9654;</span>');}
  el.innerHTML=html.join('');
  var rows=document.getElementById('m7SeqRows');if(!rows)return;var rhtml=[];
  for(var i=0;i<M7_SEQ_STEPS.length;i++){var s=M7_SEQ_STEPS[i];var col=M7_USL_COLORS[s.uslink]||'#6b7280';var bg=i%2===0?'var(--bg)':'var(--card)';
    rhtml.push('<div style="display:grid;grid-template-columns:120px 1fr 120px;gap:0;padding:6px 0;background:'+bg+';border-bottom:1px solid var(--brd)"><div style="text-align:center;color:var(--dim);font-size:.8em">&#9654;</div><div style="text-align:center;display:flex;align-items:center;justify-content:center;gap:6px"><div style="flex:1;height:2px;background:'+col+'"></div><span style="background:'+col+';color:#fff;padding:2px 8px;border-radius:4px;font-size:.75em;white-space:nowrap">'+m7esc(s.label)+'</span><div style="flex:1;height:2px;background:'+col+'"></div></div><div style="text-align:center;color:var(--dim);font-size:.8em">&#9654;</div></div>');}
  rows.innerHTML=rhtml.join('');
}

function m7RenderIcpStates(cv){var el=document.getElementById('m7IcpStates');if(!el)return;var h=[];
  for(var i=0;i<M7_ICP_STATES.length;i++){var s=M7_ICP_STATES[i];var a=cv===s.id;
    h.push('<div class="m7-pl'+(a?' on':'')+'" style="'+(a?'border-color:'+s.color+';background:'+s.color+'18;color:'+s.color+';--pg:'+s.color+'40':'')+'" title="'+m7esc(s.desc)+'">'+m7esc(s.name)+'</div>');}
  el.innerHTML=h.join('');
  var ring=document.getElementById('m7IcpRing');if(ring&&cv!==null&&cv>=0){var pct=(cv+1)/M7_ICP_STATES.length;ring.style.strokeDashoffset=238.76*(1-pct);ring.style.stroke=M7_ICP_STATES[cv]?M7_ICP_STATES[cv].color:'#6b7280';}}
function m7RenderUslStates(cv){var el=document.getElementById('m7UslStates');if(!el)return;var h=[];
  for(var i=0;i<M7_USL_STATES.length;i++){var s=M7_USL_STATES[i];var col=M7_USL_COLORS[i]||'#6b7280';var a=cv===s.id;
    h.push('<div class="m7-pl'+(a?' on':'')+'" style="'+(a?'border-color:'+col+';background:'+col+'18;color:'+col+';--pg:'+col+'40':'')+'" title="'+m7esc(s.name+': '+s.desc)+'">'+s.id+(a?' '+m7esc(s.name):'')+'</div>');}
  el.innerHTML=h.join('');
  var ring=document.getElementById('m7UslRing');if(ring&&cv!==null&&cv>=0){var pct=(cv+1)/16;ring.style.strokeDashoffset=238.76*(1-Math.min(pct,1));ring.style.stroke=M7_USL_COLORS[cv]||'#6b7280';}}

function m7UpdateStateDisplay(data){if(!data)return;
  var icpVal=typeof data.icp_state==='number'?data.icp_state:null;
  if(icpVal===null&&data.icp_state!==null&&data.icp_state!==undefined){icpVal=parseInt(data.icp_state);if(isNaN(icpVal))icpVal=null;}
  if(icpVal===null){
    var nm=document.getElementById('m7IcpName'),ds=document.getElementById('m7IcpDesc');
    // Try to infer from telemetry
    var tel=data.telemetry||{};
    var pv=tel.presentVoltage1||0,pi=tel.presentCurrent1||0;
    if(pv>0&&pi>0){if(nm)nm.textContent='C2 (Charging)';if(ds)ds.textContent='Inferred: V='+pv+'V, I='+pi+'A';icpVal=7;}
    else if(pv>0&&pi===0){if(nm)nm.textContent='B1 (Connected)';if(ds)ds.textContent='Inferred: V='+pv+'V, no current';icpVal=2;}
    else{if(nm)nm.textContent=data.icp_name||'A1 (Idle)';if(ds)ds.textContent='No ICP field in DB — inferred from telemetry';icpVal=1;}
  }
  if(icpVal!==null&&icpVal>=0&&icpVal<M7_ICP_STATES.length){var icp=M7_ICP_STATES[icpVal];
    var g=document.getElementById('m7IcpGauge'),nm=document.getElementById('m7IcpName'),ds=document.getElementById('m7IcpDesc');
    if(g){g.textContent=icp.name;g.style.borderColor=icp.color;g.style.color=icp.color;}
    if(nm)nm.textContent='State '+icpVal+': '+icp.name;if(ds)ds.textContent=icp.desc;m7RenderIcpStates(icpVal);}
  var uslVal=typeof data.uslink_state==='number'?data.uslink_state:null;
  if(uslVal===null&&data.uslink_state!==null&&data.uslink_state!==undefined){uslVal=parseInt(data.uslink_state);if(isNaN(uslVal))uslVal=null;}
  if(uslVal===null){
    var nm2=document.getElementById('m7UslName'),ds2=document.getElementById('m7UslDesc');
    // Check PLC status string
    var plcSt=data.plc_status||'';
    if(plcSt==='Active'){if(nm2)nm2.textContent='PLC Active';if(ds2)ds2.textContent='PLC communication online';
      var gg=document.getElementById('m7UslGauge');if(gg){gg.textContent='ON';gg.style.borderColor='#22c55e';gg.style.color='#22c55e';}}
    else if(plcSt==='Inactive'){if(nm2)nm2.textContent='PLC Inactive';if(ds2)ds2.textContent='PLC communication offline';
      var gg=document.getElementById('m7UslGauge');if(gg){gg.textContent='OFF';gg.style.borderColor='#ef4444';gg.style.color='#ef4444';}}
    else{
      // Infer from ICP state
      if(icpVal!==null&&icpVal>=7){uslVal=13;} // Charging → CurrentDemand
      else if(icpVal!==null&&icpVal>=2){uslVal=0;} // Connected → Ready
      else{if(nm2)nm2.textContent='N/A';if(ds2)ds2.textContent='No USLink data in DB';}
    }
  }
  if(uslVal!==null&&uslVal>=0&&uslVal<M7_USL_STATES.length){var usl=M7_USL_STATES[uslVal];var col=M7_USL_COLORS[uslVal]||'#6b7280';
    var g=document.getElementById('m7UslGauge'),nm=document.getElementById('m7UslName'),ds=document.getElementById('m7UslDesc');
    if(g){g.textContent=uslVal;g.style.borderColor=col;g.style.color=col;}
    if(nm)nm.textContent='State '+uslVal+': '+usl.name;if(ds)ds.textContent=usl.desc;m7RenderUslStates(uslVal);m7RenderSeqFlow(uslVal);}
  var c1=document.getElementById('m7Conn1St'),c2=document.getElementById('m7Conn2St');
  if(c1){
    if(icpVal!==null&&M7_ICP_STATES[icpVal]){c1.textContent=M7_ICP_STATES[icpVal].name;c1.style.color=M7_ICP_STATES[icpVal].color;}
    else{c1.textContent='--';c1.style.color='var(--dim)';}
  }
  if(c2){
    var i2=data.icp2_state;
    if(i2!==null&&i2!==undefined&&M7_ICP_STATES[i2]){c2.textContent=M7_ICP_STATES[i2].name;c2.style.color=M7_ICP_STATES[i2].color;}
    else{
      // Infer connector 2 from telemetry
      var tel=data.telemetry||{};
      var pv2=tel.presentVoltage2||0,pi2=tel.presentCurrent2||0;
      if(pv2>0&&pi2>0){c2.textContent='C2 (Charging)';c2.style.color='#22c55e';}
      else if(pv2>0){c2.textContent='B1 (Connected)';c2.style.color='#3b82f6';}
      else{c2.textContent='A1 (Idle)';c2.style.color='var(--dim)';}
    }
  }
  var sb=document.getElementById('m7SrcBadge');if(sb){if(data.mqtt_connected&&data.source==='mqtt')sb.className='m7-sb mq';else if(data.source==='mongodb')sb.className='m7-sb mg';else sb.className='m7-sb of';}
}

function m7RenderResults(results){var grid=document.getElementById('m7ResultsGrid');if(!grid||!results)return;var h=[];
  var models=[{key:'isolation_forest',name:'Isolation Forest',c:'#059669'},{key:'autoencoder',name:'Autoencoder',c:'#7c3aed'},{key:'xgboost',name:'XGBoost',c:'#d97706'},{key:'rule_engine',name:'Rule Engine',c:'#dc2626'},{key:'ensemble',name:'Ensemble',c:'#1d4ed8'}];
  for(var i=0;i<models.length;i++){var m=models[i];var r=results[m.key];var score=r?r.score:null;var isA=r?r.is_anomaly:false;var ss=score!==null?score.toFixed(4):'N/A';var sc=isA?'#ef4444':'#22c55e';var st=isA?'ANOMALY':'NORMAL';
    var cls=isA?'an':'ok';h.push('<div class="m7-rc '+cls+'"><div class="rn">'+m7esc(m.name)+'</div><div class="rs" style="color:'+sc+'">'+ss+'</div><div class="rt" style="color:'+sc+'">'+st+'</div></div>');}
  grid.innerHTML=h.join('');}

async function m7RunPredict(){
  var badge=document.getElementById('m7ApBadge'),latEl=document.getElementById('m7ApLat'),queryEl=document.getElementById('m7ApQueryTs'),predEl=document.getElementById('m7ApPredTs'),resultEl=document.getElementById('m7ApResult');
  if(badge){badge.textContent='RUNNING';badge.className='m3-ap-badge running';}
  try{var t0=performance.now();if(queryEl)queryEl.textContent=new Date().toLocaleTimeString('en-GB');
    var r=await fetch('/api/m7/latest');var d=await r.json();var lat=performance.now()-t0;
    if(latEl)latEl.textContent=lat.toFixed(0)+'ms';if(predEl)predEl.textContent=new Date().toLocaleTimeString('en-GB');
    // Check if we have ANY useful data (telemetry, states, or results)
    var hasAnything=d.telemetry||d.icp_state!==undefined||d.uslink_state!==undefined||d.model_results||d.plc_status;
    if(d.error&&!hasAnything){if(resultEl)resultEl.textContent='Error: '+d.error;if(badge){badge.textContent='ERROR';badge.className='m3-ap-badge error';}
      var led=document.getElementById('m7Led'),st=document.getElementById('m7St');
      if(led)led.className='led';if(st)st.textContent='No Data';return;}
    // Update MQTT/source status
    var led=document.getElementById('m7Led'),st=document.getElementById('m7St');
    if(d.mqtt_connected){if(led)led.className='led led-on';if(st)st.textContent='MQTT Live';}
    else if(d.source==='mongodb'||hasAnything){if(led)led.className='led led-on';if(st)st.textContent='MongoDB';}
    else{if(led)led.className='led';if(st)st.textContent='Offline';}
    m7UpdateStateDisplay(d);
    m7PushHistory(d);
    if(d.anomaly_results)m7RenderResults(d.anomaly_results);
    if(d.telemetry)m7RenderTelemetry(d.telemetry);
    if(d.warnings&&d.warnings.length>0)m7RenderWarnings(d.warnings);
    if(resultEl)resultEl.textContent=(d.source==='mqtt'?'\u{1f4e1} ':'')+(d.status||d.error||'OK');if(badge){badge.textContent='OK';badge.className='m3-ap-badge ok';}
  }catch(e){console.error('[M7] predict error:',e);if(resultEl)resultEl.textContent='Error';if(badge){badge.textContent='ERROR';badge.className='m3-ap-badge error';}}}

function m7RenderTelemetry(t){
  var el=document.getElementById('m7Telemetry');if(!el)return;el.className='m7-tg';
  var keys=[['presentVoltage1','V\u2081','V'],['presentCurrent1','I\u2081','A'],['targetVoltage1','tV\u2081','V'],['targetCurrent1','tI\u2081','A'],
    ['presentVoltage2','V\u2082','V'],['presentCurrent2','I\u2082','A'],['tempPowerModule1','PM\u2081','°C'],['tempPowerModule2','PM\u2082','°C'],
    ['temp1Head1','Gun1+','°C'],['temp1Head2','Gun2+','°C'],['SOC','SOC','%'],['chargerTemp','Charger','°C'],
    ['activeMld1','Mod\u2081',''],['activeMld2','Mod\u2082',''],
    ['PLC1_status','PLC1',''],['PLC2_status','PLC2',''],
    ['AC_magnetic_contractor1','AC1',''],['AC_magnetic_contractor2','AC2',''],
    ['DC_contractor1','DC1',''],['DC_contractor2','DC2',''],['DC_contractor3','DC3',''],
    ['DC_contractor4','DC4',''],['DC_contractor5','DC5',''],['DC_contractor6','DC6',''],
    ['humidity','Humid','%'],['edgeboxTemp','Edge','°C'],['energy_meter_status','Meter','']];
  var h=[];for(var i=0;i<keys.length;i++){var k=keys[i],v=t[k[0]];if(v===undefined)continue;
    h.push('<div class="m7-ti"><span class="tk">'+m7esc(k[1])+'</span><span class="tv">'+v+(k[2]?' <small style="opacity:.5">'+k[2]+'</small>':'')+'</span></div>');}
  el.innerHTML=h.length?h.join(''):'<span style="color:var(--dim);font-size:.72em;">No telemetry data for this station</span>';}

function m7RenderWarnings(warnings){
  var el=document.getElementById('m7Warnings');if(!el)return;
  if(!warnings||!warnings.length){el.style.display='none';return;}
  el.style.display='block';var h=[];
  for(var i=0;i<warnings.length;i++){var w=warnings[i];var cls=w.level==='CRITICAL'?'cr':w.level==='HIGH'?'hi':'me';
    h.push('<div class="m7-wn '+cls+'"><span style="font-weight:800">'+m7esc(w.level)+'</span> '+m7esc(w.msg)+'</div>');}
  el.innerHTML=h.join('');}

function m7ApToggleChanged(){m7ApOn=document.getElementById('m7ApToggle').checked;
  if(m7ApOn){m7RunPredict();m7ApCountdown=120;m7ApInterval=setInterval(function(){m7ApCountdown--;document.getElementById('m7ApCd').textContent=m7ApCountdown+'s';if(m7ApCountdown<=0){m7ApCountdown=120;m7RunPredict();}},1000);}
  else{clearInterval(m7ApInterval);m7ApInterval=null;document.getElementById('m7ApCd').textContent='OFF';document.getElementById('m7ApBadge').textContent='IDLE';document.getElementById('m7ApBadge').className='m3-ap-badge idle';}}
m7RenderIcpStates(null);m7RenderUslStates(null);m7RenderSeqFlow(null);

// ═══ M7 TIMELINE HISTORY ═══
var m7IcpHistory=[],m7UslHistory=[],M7_TL_MAX=50;
function m7PushHistory(data){
  if(!data)return;var ts=new Date();
  var icpVal=data.icp_state;if(icpVal!==null&&icpVal!==undefined)m7IcpHistory.push({ts:ts,val:icpVal,name:data.icp_name||('State '+icpVal)});
  var uslVal=data.uslink_state;if(uslVal!==null&&uslVal!==undefined)m7UslHistory.push({ts:ts,val:uslVal,name:data.uslink_name||('State '+uslVal)});
  if(m7IcpHistory.length>M7_TL_MAX)m7IcpHistory.shift();if(m7UslHistory.length>M7_TL_MAX)m7UslHistory.shift();
}
function m7DrawTimeline(){
  m7DrawOneTimeline('m7IcpCanvas','m7IcpTimelineLegend',m7IcpHistory,M7_ICP_STATES.map(function(s){return{name:s.label,color:s.color};}));
  m7DrawOneTimeline('m7UslCanvas','m7UslTimelineLegend',m7UslHistory,null);
}
function m7DrawOneTimeline(canvasId,legendId,history,stateMap){
  var canvas=document.getElementById(canvasId);if(!canvas)return;
  var ctx=canvas.getContext('2d');var W=canvas.width,H=canvas.height;
  ctx.clearRect(0,0,W,H);
  // background
  var bgStyle=getComputedStyle(document.documentElement);
  ctx.fillStyle=bgStyle.getPropertyValue('--card')||'#1e293b';ctx.fillRect(0,0,W,H);
  if(!history.length){ctx.fillStyle=bgStyle.getPropertyValue('--dim')||'#64748b';ctx.font='13px JetBrains Mono';ctx.textAlign='center';
    ctx.fillText('Waiting for data... (auto-predict will populate)',W/2,H/2);return;}
  var pad={l:50,r:20,t:15,b:25};var gW=W-pad.l-pad.r,gH=H-pad.t-pad.b;
  // Determine unique states and assign colors
  var stateSet={};history.forEach(function(h){stateSet[h.val]=h.name;});
  var stateKeys=Object.keys(stateSet).sort(function(a,b){return a-b;});
  var defColors=['#22c55e','#0ea5e9','#8b5cf6','#f59e0b','#ef4444','#ec4899','#14b8a6','#6366f1','#d97706','#64748b','#06b6d4','#84cc16','#f43f5e','#a855f7','#0891b2','#e11d48'];
  var colorMap={};stateKeys.forEach(function(k,i){
    if(stateMap&&stateMap[k])colorMap[k]=stateMap[k].color;
    else colorMap[k]=defColors[i%defColors.length];});
  // Draw bars
  var barH=Math.max(gH*0.6,16);var barY=pad.t+(gH-barH)/2;
  for(var i=0;i<history.length;i++){
    var x=pad.l+i*(gW/history.length);var w=Math.max(gW/history.length-1,2);
    ctx.fillStyle=colorMap[history[i].val]||'#6b7280';ctx.fillRect(x,barY,w,barH);
  }
  // Draw time labels
  ctx.fillStyle=bgStyle.getPropertyValue('--dim')||'#64748b';ctx.font='9px JetBrains Mono';ctx.textAlign='center';
  var labelStep=Math.max(Math.floor(history.length/6),1);
  for(var i=0;i<history.length;i+=labelStep){
    var x=pad.l+i*(gW/history.length)+gW/history.length/2;
    ctx.fillText(history[i].ts.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'}),x,H-5);
  }
  // Y axis label
  ctx.save();ctx.translate(12,H/2);ctx.rotate(-Math.PI/2);ctx.textAlign='center';ctx.font='10px JetBrains Mono';
  ctx.fillStyle=bgStyle.getPropertyValue('--tx2')||'#94a3b8';ctx.fillText('State',0,0);ctx.restore();
  // Legend
  var legEl=document.getElementById(legendId);if(legEl){
    var lh=[];stateKeys.forEach(function(k){
      var nm=stateMap&&stateMap[k]?stateMap[k].name:stateSet[k];
      lh.push('<span style="display:inline-flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:'+(colorMap[k]||'#6b7280')+'"></span>'+nm+'</span>');
    });legEl.innerHTML=lh.join('');}
}

const G=['voltage','current','power','soc','thermal','communication','session'],
GC={voltage:'#dc2626',current:'#0284c7',power:'#d97706',soc:'#7c3aed',thermal:'#db2777',communication:'#0d9488',session:'#059669'},
F=['target_voltage1','target_voltage2','target_current1','target_current2','present_voltage1','present_voltage2','present_current1','present_current2','power_module_status1','power_module_status2','power_module_status3','power_module_status4','power_module_status5','SOC','power_module_temp1','power_module_temp2','power_module_temp3','power_module_temp4','power_module_temp5','charger_temp','charger_gun_temp_plus1','charger_gun_temp_plus2','charger_gun_temp_minus1','charger_gun_temp_minus2','humidity','PLC1_status','PLC2_status','edgebox_temp','hour','minute','day_of_month','mouth_of_year'],
CRC=2*Math.PI*72,SM={NORMAL:'svN',MEDIUM:'svM',HIGH:'svH',CRITICAL:'svC'},
AM={CRITICAL:'aiC',HIGH:'aiH',MEDIUM:'aiM'};

setInterval(()=>{document.getElementById('clk').textContent=new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'})},1e3);
function stab(n){const tabs=['monitor','manual','mqtt','reference','rules','history','output'];document.querySelectorAll('#pageMod4 .tb').forEach((t,i)=>t.classList.toggle('on',i===tabs.indexOf(n)));document.querySelectorAll('#pageMod4 .tc').forEach(c=>c.classList.toggle('on',c.id==='tab-'+n));if(n==='reference'||n==='rules'||n==='mqtt'||n==='history'||n==='output')document.querySelectorAll('#tab-'+n+' .stg').forEach(el=>{el.style.animation='none';el.offsetHeight;el.style.animation=''});if(n==='history'&&!histLoaded){histLoaded=true;setTimeout(loadHistory,300)};if(n==='mqtt')setTimeout(drawRuleTreeLines,200);if(n==='output')m4RenderDoTable()}

const PR={
normal:{target_voltage1:400,present_voltage1:398,target_current1:200,present_current1:199,target_voltage2:0,present_voltage2:0,target_current2:0,present_current2:0,SOC:45,power_module_temp1:38,power_module_temp2:37,power_module_temp3:36,power_module_temp4:37,power_module_temp5:38,charger_temp:32,charger_gun_temp_plus1:48,charger_gun_temp_plus2:28,charger_gun_temp_minus1:27,charger_gun_temp_minus2:27,power_module_status1:1,power_module_status2:1,power_module_status3:1,power_module_status4:1,power_module_status5:1,PLC1_status:1,PLC2_status:1,humidity:55,edgebox_temp:40,hour:14,minute:30},
voltage:{target_voltage1:400,present_voltage1:460,target_current1:200,present_current1:198,target_voltage2:0,present_voltage2:0,target_current2:0,present_current2:0,SOC:45,power_module_temp1:40,power_module_temp2:39,power_module_temp3:38,power_module_temp4:39,power_module_temp5:40,charger_temp:34,charger_gun_temp_plus1:52,charger_gun_temp_plus2:28,charger_gun_temp_minus1:27,charger_gun_temp_minus2:27,power_module_status1:1,power_module_status2:1,power_module_status3:1,power_module_status4:1,power_module_status5:1,PLC1_status:1,PLC2_status:1,humidity:55,edgebox_temp:42,hour:14,minute:30},
thermal:{target_voltage1:400,present_voltage1:398,target_current1:200,present_current1:199,target_voltage2:0,present_voltage2:0,target_current2:0,present_current2:0,SOC:65,power_module_temp1:65,power_module_temp2:62,power_module_temp3:60,power_module_temp4:63,power_module_temp5:64,charger_temp:52,charger_gun_temp_plus1:90,charger_gun_temp_plus2:28,charger_gun_temp_minus1:27,charger_gun_temp_minus2:27,power_module_status1:1,power_module_status2:1,power_module_status3:1,power_module_status4:1,power_module_status5:1,PLC1_status:1,PLC2_status:1,humidity:55,edgebox_temp:55,hour:14,minute:30},
multi:{target_voltage1:400,present_voltage1:350,target_current1:150,present_current1:220,target_voltage2:0,present_voltage2:0,target_current2:0,present_current2:0,SOC:0,power_module_temp1:62,power_module_temp2:58,power_module_temp3:60,power_module_temp4:59,power_module_temp5:61,charger_temp:48,charger_gun_temp_plus1:85,charger_gun_temp_plus2:28,charger_gun_temp_minus1:27,charger_gun_temp_minus2:27,power_module_status1:1,power_module_status2:0,power_module_status3:1,power_module_status4:1,power_module_status5:1,PLC1_status:0,PLC2_status:1,humidity:75,edgebox_temp:52,hour:14,minute:30}};
function lp(n){for(const[k,v]of Object.entries(PR[n])){const e=document.getElementById(k);if(e)e.value=v}}
function gi(){const d={energy_meter_status:1};F.forEach(f=>{const e=document.getElementById(f);if(e)d[f]=parseFloat(e.value)||0});return d}

async function pred(){
  const b=document.getElementById('pbtn');b.textContent='ANALYZING\u2026';b.disabled=true;
  try{const t=performance.now(),r=await fetch('/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(gi())}),d=await r.json();
    document.getElementById('ltl').textContent='Round-trip '+(performance.now()-t).toFixed(0)+'ms \u2022 Server '+d.latency_ms+'ms';
    show(d);stab('monitor');
  }catch(e){alert(e.message)}
  b.textContent='\u26A1 PREDICT';b.disabled=false;
}

function show(d){
  document.getElementById('rp').className='rs';
  document.querySelectorAll('.stg').forEach(el=>{el.style.animation='none';el.offsetHeight;el.style.animation=''});
  const s=d.anomaly_score,c=s>.7?'#dc2626':s>.4?'#d97706':'#059669',off=CRC-CRC*Math.min(s,1);
  ['rFg','rGl'].forEach(id=>{const el=document.getElementById(id);el.style.stroke=c;el.style.strokeDashoffset=off});
  document.getElementById('rFg').style.filter='drop-shadow(0 0 6px '+c+')';
  const rv=document.getElementById('rV');rv.textContent=s.toFixed(3);rv.style.color=c;
  const rl=document.getElementById('rL');rl.textContent=d.is_anomaly?'ANOMALY':'NORMAL';rl.style.color=c;
  const b=document.getElementById('svB');b.textContent=d.max_severity;b.className='sv '+(SM[d.max_severity]||'svN');
  document.getElementById('mL').textContent=d.method+' \u2022 buffer:'+d.buffer_size+' \u2022 '+d.latency_ms+'ms';

  const mr=document.getElementById('mR');
  mr.innerHTML='<div class="mrow mh"><div>MODEL</div><div>SCORE</div><div>BAR</div><div>STATUS</div></div>';
  if(d.model_details)Object.entries(d.model_details).forEach(([n,v])=>{const c2=v>.5?'#dc2626':'#059669';
    mr.innerHTML+='<div class="mrow"><div class="mn">'+n+'</div><div class="msc" style="color:'+c2+'">'+v.toFixed(4)+'</div><div><div class="mbar"><div class="mbf" style="width:'+v*100+'%;background:'+c2+'"></div></div></div><div><span class="ch '+(v>.5?'cbd':'cok')+'">'+(v>.5?'ALERT':'OK')+'</span></div></div>'});

  const gg=document.getElementById('gG');gg.innerHTML='';
  G.forEach(g=>{const v=d.group_scores['anomaly_'+g]||0,gc=GC[g];
    gg.innerHTML+='<div class="gi"><div class="gn" style="color:'+gc+'">'+g.toUpperCase()+'</div><div class="gt"><div class="gf" style="width:'+Math.min(v*100,100)+'%;background:'+gc+';color:'+gc+'"></div></div><div class="gv" style="color:'+(v>.5?'#dc2626':'var(--tx2)')+'">'+v.toFixed(3)+'</div></div>'});

  const ac=document.getElementById('alC'),al=document.getElementById('alL');
  if(d.alerts&&d.alerts.length){ac.style.display='block';al.innerHTML='';
    d.alerts.forEach(a=>{al.innerHTML+='<div class="ai '+(AM[a.severity]||'aiM')+'"><div class="ah"><strong>['+a.severity+'] '+a.label+'</strong><span class="asc">'+a.score.toFixed(3)+'</span></div><div class="ast">'+(a.standards||[]).map(x=>'\u2022 '+x).join('<br>')+'</div>'+(a.action?'<div class="aact">\u26A0\uFE0F '+a.action+'</div>':'')+'</div>'})}
  else ac.style.display='none';

  // Feature Importance
  const fiC=document.getElementById('m4FiPanel'),fiL=document.getElementById('fiL');
  if(d.feature_importance&&d.feature_importance.length){
    fiC.style.display='block';fiL.innerHTML='';
    const maxImp=Math.max(...d.feature_importance.map(f=>f.importance),1e-9);
    d.feature_importance.forEach((f,i)=>{
      const pct=Math.min(f.importance/maxImp*100,100);
      const rc=i<3?'fi-top':i<7?'fi-mid':'fi-low';
      fiL.innerHTML+='<div class="fi-row"><div class="fi-name"><span class="fi-rank '+rc+'">'+(i+1)+'</span>'+f.feature.replace(/_/g,' ')+'</div><div class="fi-track"><div class="fi-bar" style="width:'+pct+'%"></div></div><div class="fi-val">'+(f.importance*100).toFixed(1)+'%</div></div>'});
    document.getElementById('fiBadge').textContent='Top '+d.feature_importance.length+' \u2022 Input\u00D7Gradient';
  } else fiC.style.display='none';
}
function clr(){document.getElementById('rp').className='rh';['rFg','rGl'].forEach(id=>{document.getElementById(id).style.strokeDashoffset=CRC})}

// ═══ AUTO-PREDICT: Every 2 minutes ═══
const AP_INTERVAL_SEC=120; // 2 minutes
let apEnabled=true,apCountdown=AP_INTERVAL_SEC,apIntervalId=null,apTickId=null;

function apToggleChanged(){
  const cb=document.getElementById('apToggle');
  if(cb.checked){apStart()}else{apStop()}
}

function apStart(){
  apEnabled=true;apCountdown=AP_INTERVAL_SEC;
  const timer=document.getElementById('apTimer');
  timer.className='ap-timer ap-on';
  apUpdateDisplay();
  // Tick every second for countdown
  if(apTickId)clearInterval(apTickId);
  apTickId=setInterval(()=>{
    apCountdown--;
    if(apCountdown<=0){
      apRunPredict();
      apCountdown=AP_INTERVAL_SEC;
    }
    apUpdateDisplay();
  },1000);
  // Run immediately on first enable
  apRunPredict();
}

function apStop(){
  apEnabled=false;
  if(apTickId){clearInterval(apTickId);apTickId=null}
  const timer=document.getElementById('apTimer');
  timer.className='ap-timer';timer.textContent='OFF';
}

function apUpdateDisplay(){
  const timer=document.getElementById('apTimer');
  const m=Math.floor(apCountdown/60),s=apCountdown%60;
  timer.textContent='Next: '+m+':'+String(s).padStart(2,'0');
  timer.className='ap-timer ap-on';
}

async function apRunPredict(){
  if(!teleOk)return; // Don't predict if telemetry is offline
  const timer=document.getElementById('apTimer');
  timer.className='ap-timer ap-run';timer.textContent='ANALYZING\u2026';
  const b=document.getElementById('pbtn');
  const origText=b.textContent;
  b.textContent='AUTO\u2026';b.disabled=true;
  try{
    const t=performance.now();
    const payload=gi(); // reads form fields (already filled by telemetry)
    const r=await fetch('/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const d=await r.json();
    const elapsed=(performance.now()-t).toFixed(0);
    document.getElementById('ltl').textContent='Auto-predict \u2022 Round-trip '+elapsed+'ms \u2022 Server '+d.latency_ms+'ms \u2022 '+new Date().toLocaleTimeString('en-GB');
    show(d);stab('monitor');
    al2('\uD83E\uDD16 Auto-predict: score='+d.anomaly_score.toFixed(3)+' '+d.max_severity+' ['+d.latency_ms+'ms]',d.is_anomaly);
  }catch(e){
    al2('\u274C Auto-predict failed: '+e.message,true);
  }
  b.textContent=origText;b.disabled=false;
}

let ws;function wsc(){ws=new WebSocket('ws://'+location.host+'/ws/stream');
  ws.onopen=()=>{document.getElementById('led').classList.add('on');document.getElementById('cst').textContent='Online';al2('\u2705 Connected')};
  ws.onclose=()=>{document.getElementById('led').classList.remove('on');document.getElementById('cst').textContent='Offline';setTimeout(wsc,3e3)};
  ws.onmessage=e=>{const d=JSON.parse(e.data);if(d.type==='prediction')ulv(d);if(d.type==='CRITICAL_ALERT')ula(d.data||d)}}
wsc();

function ulv(d){
  const lg=document.getElementById('lG');lg.innerHTML='';
  G.forEach(g=>{const v=d.group_scores?d.group_scores['anomaly_'+g]||0:0,gc=GC[g];
    lg.innerHTML+='<div class="gi"><div class="gn" style="color:'+gc+'">'+g.toUpperCase()+'</div><div class="gt"><div class="gf" style="width:'+v*100+'%;background:'+gc+';color:'+gc+'"></div></div><div class="gv">'+v.toFixed(3)+'</div></div>'});
  const lm=document.getElementById('lM');lm.innerHTML='';
  if(d.model_details)Object.entries(d.model_details).forEach(([n,v])=>{const c=v>.5?'#dc2626':'#059669';
    lm.innerHTML+='<div class="mrow" style="grid-template-columns:1fr 75px 70px"><div class="mn">'+n+'</div><div class="msc" style="color:'+c+'">'+v.toFixed(4)+'</div><div><span class="ch '+(v>.5?'cbd':'cok')+'">'+(v>.5?'!':'OK')+'</span></div></div>'});
  al2('score='+d.anomaly_score+' '+d.max_severity+' ['+d.latency_ms+'ms]',d.is_anomaly)}

function ula(d){const b=document.getElementById('lA');if(b.querySelector('.ll'))b.innerHTML='';
  (d.alerts||[]).forEach(a=>{const x=document.createElement('div');x.className='ai '+(AM[a.severity]||'aiM');
    x.innerHTML='<div class="ah"><strong>['+a.severity+'] '+a.label+'</strong><span class="asc">'+a.score.toFixed(3)+'</span></div><div class="ast">'+((a.standards||[])[0]||'')+'</div>';
    b.prepend(x)});while(b.children.length>30)b.lastChild.remove()}

function al2(m,a){const b=document.getElementById('lB'),d=document.createElement('div');
  d.className='ll'+(a?' an':' ok');d.textContent='['+new Date().toLocaleTimeString('en-GB')+'] '+m;
  b.prepend(d);while(b.children.length>200)b.lastChild.remove()}

setInterval(async()=>{try{const r=await fetch('/metrics'),m=await r.json();
  document.getElementById('xT').textContent=m.total.toLocaleString();
  document.getElementById('xA').textContent=m.anomalies.toLocaleString();
  document.getElementById('xR').textContent=(m.anomaly_rate*100).toFixed(1)+'%';
  document.getElementById('xL').textContent=m.avg_latency_ms.toFixed(1)+'ms'}catch(e){}},2e3);

// ═══ RULE-BASED MONITORING ═══
const SEV_C={NORMAL:'var(--gn)',MEDIUM:'var(--am)',HIGH:'var(--rd)',CRITICAL:'var(--rd)'};
function rbRender(d){
  const led=document.getElementById('mqttLed'),st=document.getElementById('mqttSt'),ts=document.getElementById('mqttTs');
  if(d.mqtt_connected){led.classList.add('on');st.textContent='Online';st.style.color='var(--gn)'}
  else{led.classList.remove('on');st.textContent='Disconnected';st.style.color='var(--dim)'}
  if(d.last_update)ts.textContent=new Date(d.last_update).toLocaleTimeString('en-GB');

  // Reset all rule slots to IDLE
  document.querySelectorAll('.rt-r').forEach(el=>{
    el.className='rt-r rt-idle';
    const bId=el.id.replace('rr_','rs_');
    const vId=el.id.replace('rr_','rv_');
    const badge=document.getElementById(bId);
    const val=document.getElementById(vId);
    if(badge){badge.className='rt-badge rt-st-idle';badge.textContent='IDLE'}
    if(val)val.textContent='\u2014';
  });

  if(!d.rules||!d.rules.length){drawRuleTreeLines();return}

  let alertCnt=0, okCnt=0, totalSlots=9;
  d.rules.forEach(r=>{
    const row=document.getElementById('rr_'+r.id);
    if(!row)return;
    const isOk=r.status==='OK';
    const isIdle=r.status==='IDLE'||r.status==='N/A';
    const isWarn=r.severity==='MEDIUM';
    // Row class
    row.className='rt-r '+(isIdle?'rt-idle':isOk?'rt-ok':isWarn?'rt-warn':'rt-alert');
    // Badge
    const badge=document.getElementById('rs_'+r.id);
    if(badge){
      badge.className='rt-badge '+(isIdle?'rt-st-idle':isOk?'rt-st-ok':isWarn?'rt-st-warn':'rt-st-alert');
      badge.textContent=r.status;
    }
    // Value summary
    const val=document.getElementById('rv_'+r.id);
    if(val&&r.values){
      const entries=Object.entries(r.values);
      if(entries.length)val.textContent=entries.map(([k,v])=>v).join(' | ');
    }
    // Count
    if(!isIdle){if(!isOk)alertCnt++;else okCnt++}
  });

  // Update group nodes
  const GRP=[
    {id:'rtGChg',rules:['r1_c1','r1_c2'],c:'#0891b2'},
    {id:'rtGMod',rules:['r2_derate','r3_single','r4_dual'],c:'#d97706'},
    {id:'rtGDlv',rules:['r5_c1','r5_c2','r6_c1','r6_c2'],c:'#dc2626'}
  ];
  GRP.forEach(g=>{
    const gEl=document.getElementById(g.id);if(!gEl)return;
    let gAlert=0,gOk=0;
    g.rules.forEach(rid=>{
      const b=document.getElementById('rs_'+rid);
      if(!b)return;
      if(b.classList.contains('rt-st-alert')||b.classList.contains('rt-st-warn'))gAlert++;
      else if(b.classList.contains('rt-st-ok'))gOk++;
    });
    if(gAlert>0){gEl.style.borderColor='#ef4444';gEl.style.background='rgba(239,68,68,.04)';gEl.querySelector('.rt-gn-c').textContent=gAlert+' alert'+(gAlert>1?'s':'')}
    else if(gOk>0){gEl.style.borderColor=g.c;gEl.style.background='rgba(22,163,74,.03)';gEl.querySelector('.rt-gn-c').textContent='All OK'}
    else{gEl.style.borderColor='var(--bdr)';gEl.style.background='var(--card)';gEl.querySelector('.rt-gn-c').textContent=g.rules.length+' rules'}
  });

  // Update overall status
  const ov=document.getElementById('rtOvCount');
  const ovPill=document.getElementById('rtOvPill');
  const ovDot=document.getElementById('rtOvDot');
  const ovLabel=document.getElementById('rtOvLabel');
  if(alertCnt>0){
    ov.textContent=alertCnt+' / 9';ov.style.color='#ef4444';
    ovPill.style.background='rgba(239,68,68,.08)';ovPill.style.color='#ef4444';ovPill.style.borderColor='rgba(239,68,68,.18)';
    ovPill.innerHTML='<span style="width:7px;height:7px;border-radius:50%;background:#ef4444;flex-shrink:0" id="rtOvDot"></span> '+alertCnt+' ALERT'+(alertCnt>1?'S':'');
    ovLabel.style.color='#ef4444';
  }else{
    ov.textContent='0 / 9';ov.style.color='var(--gn)';
    ovPill.style.background='rgba(22,163,74,.08)';ovPill.style.color='#16a34a';ovPill.style.borderColor='rgba(22,163,74,.15)';
    ovPill.innerHTML='<span style="width:7px;height:7px;border-radius:50%;background:#16a34a;flex-shrink:0" id="rtOvDot"></span> ALL CLEAR';
    ovLabel.style.color='var(--gn)';
  }

  // Raw data table
  const raw=document.getElementById('mqttRaw');
  if(raw&&d.plc_data&&Object.keys(d.plc_data).length){
    const keys=Object.keys(d.plc_data).sort();
    let h='<table style="width:100%;border-collapse:collapse">';
    h+='<tr style="border-bottom:1px solid var(--bdr);font-weight:700;color:var(--dim);font-size:.9em"><td style="padding:3px 8px">KEY</td><td style="padding:3px 8px">VALUE</td></tr>';
    keys.forEach(k=>{h+='<tr style="border-bottom:1px solid var(--bdr)"><td style="padding:3px 8px;color:var(--cy)">'+k+'</td><td style="padding:3px 8px">'+d.plc_data[k]+'</td></tr>'});
    h+='</table>';raw.innerHTML=h;
  }
  drawRuleTreeLines();
}

// ── RULE TREE SVG BRACKET LINES ──
function drawRuleTreeLines(){
  const C=document.getElementById('rtCanvas');
  const S=document.getElementById('rtSvg');
  const gCol=document.getElementById('rtColG');
  if(!C||!S||!gCol)return;
  const cr=C.getBoundingClientRect();
  const gColR=gCol.getBoundingClientRect();
  S.setAttribute('width',cr.width);S.setAttribute('height',cr.height);
  S.innerHTML='';
  function curve(x1,y1,x2,y2,col,w,op){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const cx=(x1+x2)/2;
    p.setAttribute('d','M'+x1+','+y1+' C'+cx+','+y1+' '+cx+','+y2+' '+x2+','+y2);
    p.setAttribute('fill','none');p.setAttribute('stroke',col);p.setAttribute('stroke-width',w||1.5);p.setAttribute('opacity',op||0.45);
    S.appendChild(p);
  }
  const rx=el=>{const r=el.getBoundingClientRect();return r.right-cr.left};
  const lx=el=>{const r=el.getBoundingClientRect();return r.left-cr.left};
  const cy=el=>{const r=el.getBoundingClientRect();return r.top-cr.top+r.height/2};
  const GRPS=[
    {rg:'chg',gn:'rtGChg',c:'#0891b2'},
    {rg:'mod',gn:'rtGMod',c:'#d97706'},
    {rg:'dlv',gn:'rtGDlv',c:'#dc2626'}
  ];
  // PASS 1: Calculate ideal midpoint positions
  const MIN_GAP=18;
  const rSlots=[];
  GRPS.forEach(g=>{
    const nodes=[...document.querySelectorAll('[data-rg="'+g.rg+'"]')];
    const gEl=document.getElementById(g.gn);
    if(!nodes.length||!gEl)return;
    const firstR=nodes[0].getBoundingClientRect();
    const lastR=nodes[nodes.length-1].getBoundingClientRect();
    const idealY=(firstR.top+firstR.height/2+lastR.top+lastR.height/2)/2-gColR.top;
    const h=gEl.offsetHeight||60;
    rSlots.push({el:gEl,idealY:idealY,y:idealY,h:h,g:g});
  });
  rSlots.sort((a,b)=>a.idealY-b.idealY);
  for(let i=1;i<rSlots.length;i++){
    const prev=rSlots[i-1],cur=rSlots[i];
    const prevBot=prev.y+prev.h/2+MIN_GAP;
    const curTop=cur.y-cur.h/2;
    if(curTop<prevBot){cur.y=prevBot+cur.h/2}
  }
  rSlots.forEach(s=>{s.el.style.top=s.y+'px'});
  // Draw bezier curves: rules → groups
  const gPts=[];
  GRPS.forEach(g=>{
    const nodes=[...document.querySelectorAll('[data-rg="'+g.rg+'"]')];
    const gEl=document.getElementById(g.gn);if(!nodes.length||!gEl)return;
    const glx=lx(gEl),gcy=cy(gEl),grx=rx(gEl);
    gPts.push({lx:glx,rx:grx,cy:gcy,c:g.c});
    nodes.forEach(n=>curve(rx(n),cy(n),glx,gcy,g.c,1.5,0.45));
  });
  // Groups → Overall
  const ovEl=document.getElementById('rtOverall');
  if(!ovEl||!gPts.length)return;
  const rlx=lx(ovEl),rcy=cy(ovEl);
  gPts.forEach(e=>curve(e.rx,e.cy,rlx,rcy,e.c,1.5,0.35));
}
setInterval(async()=>{try{const r=await fetch('/rules'),d=await r.json();rbRender(d);sqRefresh(d)}catch(e){}},2e3);
async function rbTest(){try{const r=await fetch('/rules/test',{method:'POST'}),d=await r.json();rbRender(d);sqRefresh(d)}catch(e){alert('Test failed: '+e.message)}}

// ═══ THEME TOGGLE ═══
let curTheme='dark';
const THEMES=['light','dark','cyber','neural','nature'];
const THEME_ICONS={'light':'&#9728;','dark':'&#9790;','cyber':'&#9889;','neural':'&#129504;','nature':'&#127793;'};
const THEME_LABELS={'light':'Light','dark':'Dark','cyber':'Cyber','neural':'Neural'};
function switchTheme(){
  const idx=THEMES.indexOf(curTheme);
  curTheme=THEMES[(idx+1)%THEMES.length];
  document.documentElement.setAttribute('data-theme',curTheme);
  const ico=document.getElementById('themeIcon');
  if(ico)ico.innerHTML=THEME_ICONS[curTheme];
  // Redraw tree lines after theme change
  setTimeout(()=>{if(typeof drawTreeLines==='function')drawTreeLines();if(typeof drawRuleTreeLines==='function')drawRuleTreeLines();if(typeof drawM3TreeLines==='function'&&activeMod===3){drawM3TreeLines();drawM3HealthTreeLines()};if(typeof drawM2TreeLines==='function'&&activeMod===2){drawM2TreeLines();drawM2HTLines()};if(typeof drawM5TreeLines==='function'&&activeMod===5)drawM5TreeLines()},200);
}

// ═══ i18n LANGUAGE SYSTEM ═══
let curLang='en';
const I18N={
  en:{
    subtitle:'DC Charger 150kW &bull; Anomaly Intelligence',
    init:'Initializing',
    tab1:'&#129302; AI-Module Detection',
    tab2:'&#9889; Live Monitor',
    tab3:'&#128752; Rule Based Algorithm',
    tab4:'&#128218; Standards Reference',
    tab5:'&#128220; Rule-Based Algorithms Description',
    seq_title:'Charger State Sequence — Real-Time Protocol Monitor',
    telemetry:'Charger Telemetry',
    conn1:'Connector 1',conn2:'Connector 2',
    battery:'Battery',temperature:'Temperature',
    modules:'Modules &amp; PLC',environment:'Environment',
    anomaly_score:'Anomaly Score',ensemble:'Ensemble Models',
    group_scores:'Group Anomaly Scores',feat_imp:'Feature Importance',
    triggered_alerts:'Triggered Alerts',
    scenarios:'Scenarios',predict:'&#9889; PREDICT',clear:'CLEAR',auto_predict:'Auto Predict',
    predictions:'Predictions',anomalies:'Anomalies',rate:'Rate',latency:'Latency',
    live_groups:'Live Groups',live_models:'Live Models',
    alerts:'Alerts',awaiting:'Awaiting telemetry…',
    tele_connecting:'Connecting…',tele_live:'Live',tele_offline:'Offline',
    health_tree:'Asset Health Status Tree',gauge_normal:'Normal',gauge_warning:'Warning',gauge_alarm:'Alarm',
    root_cause:'Sub-Optimal Power Delivery',
    std_cond:'Standard Condition Reference',
    log:'Log',sys_ready:'System ready…',
    normal:'Normal',voltage:'Voltage',thermal:'Thermal',multi:'Multi-Fault',
    pr_normal:'400V 200A SOC 45%',pr_voltage:'+15% deviation',
    pr_thermal:'65°C mod · 90°C gun',pr_multi:'Current+Temp+PLC',
    mqtt_h:'&#128225; Rule-Based Real-Time Monitoring',
    mqtt_p:'Displays real-time detection results from <strong>MQTT Broker</strong> (<code>212.80.215.42:1883</code>) by subscribing to PLC data from Topic <code>OCPP/Klongluang3/PLC</code> and analyzing with 6-rule engine on every new message. Results auto-update every 2 seconds.',
    mqtt_live:'Live Rule Results',mqtt_test:'Test Rules',mqtt_disc:'Disconnected',
    mqtt_wait:'Waiting for MQTT data from <strong>OCPP/Klongluang3/PLC</strong>&hellip;',
    mqtt_raw:'Raw PLC Data',mqtt_nodata:'No data received yet&hellip;',
    tab6:'&#128200; Historical Graph',tab7:'📊 Detection Output',
    hist_h:'&#128200; Historical Graph',hist_p:'Visualize historical charger telemetry from MongoDB. Select a time range and field group to plot time-series data.',
    hist_ctrl:'Controls',hist_range:'Time Range',hist_fields:'Field Group',
    hist_daily:'Daily',hist_weekly:'Weekly',hist_monthly:'Monthly',hist_custom:'Custom',
    hist_start:'Start',hist_end:'End',
    hist_load:'Load Data',hist_chart:'Chart',hist_loading:'Loading data…',
    hist_empty:'Select a field group and click "Load Data" to view the chart.',
    hist_stats:'Statistics',hist_stats_empty:'Statistics will appear after loading data.',
    sb_modules:'AI MODULES',sb_collapse:'Collapse Menu',
    mod1_name:'Module 1',mod1_sub:'MDB Switchgear Filter Blockage',
    mod2_name:'Module 2',mod2_sub:'Charger Filter Blockage',m2_load_title:'Model Loading Status',m2_ap_label:'Auto Predict',m2_ap_next:'Next',m2_ap_queried:'Queried:',m2_ap_predicted:'Predicted:',m2_ap_latency:'Latency:',m2_ap_result:'Result:',
    mod3_name:'Module 3',mod3_sub:'Charger Offline Detection',
    m2_title:'Charger Dust Filter — AI Detection',m2_tab1:'🔄 AI Detection & Health Tree',m2_tab2:'📈 Historical Graph',m2_tab3:'📖 Algorithm Description',m2_tab4:'📊 Detection Output',m2_gauge_title:'🌡️ Filter Clogging Risk',m2_gauge_label:'Clogging Level:',m2_ht_title:'Filter Clogging — Condition Health Tree',m2_hist_h:'Historical Graph — Filter Thermal Monitoring',m2_algo_h:'Algorithm Description — Filter Clogging Prediction',m2_do_h:'Detection Output — Filter Clogging Monitoring',
    m3_title:'Charger Offline Detection — AI Status Tree',
    m3_ma_sub:'Multi-class Classifier',m3_ma2_sub:'Deep Neural Network',m3_mb_sub:'~2 min Pre-Fault Alert',
    m3_mc_sub:'Reconstruction Anomaly',m3_md_sub:'Sequence Anomaly',m3_me_sub:'Isolation Forest + LOF',
    m3_g_cls:'Classification',m3_g_ew:'Early Warning',m3_g_ad:'Anomaly Detection',
    m3_root_title:'Charger Offline Status',m3_root_sub:'System Availability Monitor',
    m3_prob_title:'Root Cause Probability Distribution',
    m3_ew_title:'Early Warning System — ~2 Minute Forecast',m3_ew_clear:'No Pre-Fault Signals Detected',
    m3_sig_title:'Device Signal Monitor',m3_arch_title:'AI Model Architecture Reference',
    m3_ht_title:'Charger Offline — Condition Health Tree',m3_ht_root:'Charger Offline Root-Cause',m3_cond_title:'Condition Health Reference — Charger Offline Root-Cause',
    m3_load_title:'Model Loading Status',
    m3_ap_label:'Auto Predict',m3_ap_next:'Next',m3_ap_queried:'Queried:',m3_ap_predicted:'Predicted:',m3_ap_latency:'Latency:',m3_ap_result:'Result:',
    m3_hist_h:'📈 Historical Graph — Charger Offline Monitoring',m3_hist_p:'Visualize historical charger offline monitoring data from MongoDB. Select a time range and field group to plot.',m3_hist_ctrl:'Controls',
    m3_tab1:'📡 AI Detection & Health Tree',m3_tab2:'📈 Historical Graph',m3_tab3:'📖 Algorithm Description',m3_tab4:'📊 Detection Output',
    m3_algo_h:'Charger Offline Detection — Algorithm Description',m3_algo_p:'Module 3 uses a multi-layered detection system combining 6 AI Models, 4 Rule-Based checks, and 6 Hybrid conditions to diagnose root causes of charger offline events across 5 equipment groups.',
    m3_do_h:'Detection Output — Charger Offline Monitoring',m4_do_h:'Detection Output — Abnormal Power Delivery',do_refresh:'Refresh',
    mod4_name:'Module 4',mod4_sub:'Charger Power Delivery Anomaly',
    mod5_name:'Module 5',mod5_sub:'Internet Network Issues',
    m5_tab1:'🌐 AI Detection & Network Tree',m5_tab2:'📈 Historical Graph',m5_tab3:'📖 Algorithm Description',m5_tab4:'📊 Detection Output',
    m5_title:'Network Problem Root Cause Prediction — AI Network Topology',
    m5_ht_title:'Network Topology — Device Health Tree',
    m5_hist_h:'Historical Network Status — Time Series',
    m5_algo_h:'Network Problem Detection — Algorithm Description',
    m5_do_h:'Detection Output — Network Problem Monitoring',
    mod6_name:'Module 6',mod6_sub:'Remaining Useful Life of Components',
    mod7_name:'Module 7',mod7_sub:'Charger Failure Root Cause Analysis',
    m7_tab1:'🔍 State Monitor',m7_tab2:'📊 Timeline',m7_tab3:'🧠 Failure Prediction',m7_tab4:'📖 Algorithm Description',
    m7_title:'EV-PLCC State Monitoring — ISO 15118 Charging Protocol Analysis',
    m7_icp_h:'ICPState (Control Pilot)',m7_uslink_h:'UslinkState (Communication Protocol)',
    m7_timeline_h:'State Transition Timeline',m7_predict_h:'Failure Prediction & Root Cause Analysis',
    m7_algo_h:'Charger Failure Analysis — Algorithm Description'
  },
  th:{
    subtitle:'เครื่องชาร์จ DC 150kW &bull; ระบบตรวจจับความผิดปกติอัจฉริยะ',
    init:'กำลังเริ่มต้น',
    tab1:'&#129302; ตรวจจับด้วย AI',
    tab2:'&#9889; ตรวจสอบสด',
    tab3:'&#128752; อัลกอริทึมตามกฎ',
    tab4:'&#128218; อ้างอิงมาตรฐาน',
    tab5:'&#128220; รายละเอียดอัลกอริทึมตามกฎ',
    seq_title:'ลำดับสถานะเครื่องชาร์จ — ตรวจสอบโปรโตคอลแบบเรียลไทม์',
    telemetry:'ข้อมูลเครื่องชาร์จ',
    conn1:'หัวชาร์จ 1',conn2:'หัวชาร์จ 2',
    battery:'แบตเตอรี่',temperature:'อุณหภูมิ',
    modules:'โมดูล &amp; PLC',environment:'สภาพแวดล้อม',
    anomaly_score:'คะแนนความผิดปกติ',ensemble:'โมเดลรวม',
    group_scores:'คะแนนความผิดปกติรายกลุ่ม',feat_imp:'ลำดับความสำคัญฟีเจอร์',
    triggered_alerts:'การแจ้งเตือนที่ถูกกระตุ้น',
    scenarios:'สถานการณ์จำลอง',predict:'&#9889; ทำนาย',clear:'ล้าง',auto_predict:'ทำนายอัตโนมัติ',
    predictions:'การทำนาย',anomalies:'ความผิดปกติ',rate:'อัตราส่วน',latency:'เวลาตอบสนอง',
    live_groups:'กลุ่มสด',live_models:'โมเดลสด',
    alerts:'แจ้งเตือน',awaiting:'รอข้อมูลเทเลเมทรี…',
    tele_connecting:'กำลังเชื่อมต่อ…',tele_live:'สด',tele_offline:'ออฟไลน์',
    health_tree:'แผนผังสถานะสุขภาพอุปกรณ์',gauge_normal:'ปกติ',gauge_warning:'เตือน',gauge_alarm:'ผิดปกติ',
    root_cause:'การจ่ายไฟไม่เต็มประสิทธิภาพ',
    std_cond:'ตารางอ้างอิงมาตรฐาน Condition',
    log:'บันทึก',sys_ready:'ระบบพร้อมทำงาน…',
    normal:'ปกติ',voltage:'แรงดัน',thermal:'ความร้อน',multi:'หลายความผิดพลาด',
    pr_normal:'400V 200A SOC 45%',pr_voltage:'เบี่ยงเบน +15%',
    pr_thermal:'65°C โมดูล · 90°C หัวชาร์จ',pr_multi:'กระแส+อุณหภูมิ+PLC',
    mqtt_h:'&#128225; ตรวจสอบตามกฎแบบเรียลไทม์',
    mqtt_p:'แสดงผลการตรวจจับแบบ Real-Time จาก <strong>MQTT Broker</strong> (<code>212.80.215.42:1883</code>) โดย Subscribe ข้อมูล PLC จาก Topic <code>OCPP/Klongluang3/PLC</code> แล้ววิเคราะห์ด้วย Rule Engine 6 กฎทุกครั้งที่ได้รับข้อมูลใหม่ ผลลัพธ์จะอัปเดตอัตโนมัติทุก 2 วินาที',
    mqtt_live:'ผลการตรวจสอบตามกฎ',mqtt_test:'ทดสอบกฎ',mqtt_disc:'ไม่ได้เชื่อมต่อ',
    mqtt_wait:'รอข้อมูล MQTT จาก <strong>OCPP/Klongluang3/PLC</strong>&hellip;',
    mqtt_raw:'ข้อมูล PLC ดิบ',mqtt_nodata:'ยังไม่ได้รับข้อมูล&hellip;',
    tab6:'&#128200; กราฟข้อมูลย้อนหลัง',tab7:'📊 ผลลัพธ์การตรวจจับ',
    hist_h:'&#128200; กราฟข้อมูลย้อนหลัง',hist_p:'แสดงข้อมูลเทเลเมทรีย้อนหลังจาก MongoDB เลือกช่วงเวลาและกลุ่มข้อมูลเพื่อ plot กราฟ time-series',
    hist_ctrl:'ตัวควบคุม',hist_range:'ช่วงเวลา',hist_fields:'กลุ่มข้อมูล',
    hist_daily:'รายวัน',hist_weekly:'รายสัปดาห์',hist_monthly:'รายเดือน',hist_custom:'กำหนดเอง',
    hist_start:'เริ่มต้น',hist_end:'สิ้นสุด',
    hist_load:'โหลดข้อมูล',hist_chart:'กราฟ',hist_loading:'กำลังโหลดข้อมูล…',
    hist_empty:'เลือกกลุ่มข้อมูลแล้วกด "โหลดข้อมูล" เพื่อดูกราฟ',
    hist_stats:'สถิติ',hist_stats_empty:'สถิติจะแสดงหลังจากโหลดข้อมูล',
    sb_modules:'โมดูล AI',sb_collapse:'ย่อเมนู',
    mod1_name:'โมดูล 1',mod1_sub:'การตันของฟิลเตอร์ตู้สวิทซ์ประธาน',
    mod2_name:'โมดูล 2',mod2_sub:'การตันของฟิลเตอร์เครื่องอัดประจุ',m2_load_title:'สถานะการโหลดโมเดล',m2_ap_label:'ทำนายอัตโนมัติ',m2_ap_next:'ถัดไป',m2_ap_queried:'สอบถาม:',m2_ap_predicted:'ทำนาย:',m2_ap_latency:'เวลาตอบสนอง:',m2_ap_result:'ผลลัพธ์:',
    mod3_name:'โมดูล 3',mod3_sub:'การออฟไลน์ของเครื่องอัดประจุ',
    m2_title:'ฟิลเตอร์ฝุ่น Charger — AI ตรวจจับ',m2_tab1:'🔄 AI ตรวจจับ & แผนผังสุขภาพ',m2_tab2:'📈 กราฟข้อมูลย้อนหลัง',m2_tab3:'📖 อธิบายอัลกอริทึม',m2_tab4:'📊 ผลลัพธ์การตรวจจับ',m2_gauge_title:'🌡️ ความเสี่ยงฟิลเตอร์ตัน',m2_gauge_label:'ระดับการอุดตัน:',m2_ht_title:'ฟิลเตอร์อุดตัน — แผนผังสุขภาพ',m2_hist_h:'กราฟย้อนหลัง — ตรวจสอบความร้อนฟิลเตอร์',m2_algo_h:'อธิบายอัลกอริทึม — คาดการณ์ฟิลเตอร์อุดตัน',m2_do_h:'ผลลัพธ์การตรวจจับ — ตรวจสอบฟิลเตอร์อุดตัน',
    m3_title:'การตรวจจับการออฟไลน์ของเครื่องอัดประจุ — แผนผังสถานะ AI',
    m3_ma_sub:'ตัวจำแนกหลายคลาส',m3_ma2_sub:'โครงข่ายประสาทเทียมลึก',m3_mb_sub:'แจ้งเตือนก่อนล่วงหน้า ~2 นาที',
    m3_mc_sub:'ตรวจจับจากการสร้างใหม่',m3_md_sub:'ตรวจจับจากลำดับเวลา',m3_me_sub:'Isolation Forest + LOF',
    m3_g_cls:'การจำแนกประเภท',m3_g_ew:'แจ้งเตือนล่วงหน้า',m3_g_ad:'ตรวจจับความผิดปกติ',
    m3_root_title:'สถานะการออฟไลน์ของเครื่องอัดประจุ',m3_root_sub:'ระบบติดตามความพร้อมใช้งาน',
    m3_prob_title:'การกระจายความน่าจะเป็นของสาเหตุ',
    m3_ew_title:'ระบบแจ้งเตือนล่วงหน้า — พยากรณ์ ~2 นาที',m3_ew_clear:'ไม่พบสัญญาณก่อนออฟไลน์',
    m3_sig_title:'จอมอนิเตอร์สัญญาณอุปกรณ์',m3_arch_title:'ตารางสถาปัตยกรรมโมเดล AI',
    m3_ht_title:'เครื่องชาร์จออฟไลน์ — แผนผังสุขภาพเงื่อนไข',m3_ht_root:'สาเหตุหลักเครื่องชาร์จออฟไลน์',m3_cond_title:'ตารางอ้างอิงเงื่อนไขสุขภาพ — สาเหตุออฟไลน์',
    m3_load_title:'สถานะการโหลดโมเดล',
    m3_ap_label:'ทำนายอัตโนมัติ',m3_ap_next:'ถัดไป',m3_ap_queried:'ดึงข้อมูล:',m3_ap_predicted:'ทำนาย:',m3_ap_latency:'เวลาตอบสนอง:',m3_ap_result:'ผลลัพธ์:',
    m3_hist_h:'📈 กราฟข้อมูลย้อนหลัง — การตรวจสอบเครื่องชาร์จออฟไลน์',m3_hist_p:'แสดงข้อมูลย้อนหลังจาก MongoDB เลือกช่วงเวลาและกลุ่มข้อมูลเพื่อพล็อตกราฟ',m3_hist_ctrl:'ตัวควบคุม',
    m3_tab1:'📡 AI ตรวจจับ & แผนผังสุขภาพ',m3_tab2:'📈 กราฟข้อมูลย้อนหลัง',m3_tab3:'📖 อธิบายอัลกอริทึม',m3_tab4:'📊 ผลลัพธ์การตรวจจับ',
    m3_algo_h:'ระบบตรวจจับเครื่องชาร์จออฟไลน์ — คำอธิบายอัลกอริทึม',m3_algo_p:'Module 3 ใช้ระบบตรวจจับหลายชั้น ผสมผสาน AI 6 โมเดล, Rule-Based 4 กฎ และ Hybrid 6 เงื่อนไข เพื่อวิเคราะห์สาเหตุต้นตอของเหตุการณ์เครื่องชาร์จออฟไลน์ ใน 5 กลุ่มอุปกรณ์',
    m3_do_h:'ผลลัพธ์การตรวจจับ — ตรวจสอบเครื่องชาร์จออฟไลน์',m4_do_h:'ผลลัพธ์การตรวจจับ — ตรวจจับความผิดปกติการจ่ายไฟ',do_refresh:'รีเฟรช',
    mod4_name:'โมดูล 4',mod4_sub:'การจ่ายไฟฟ้าผิดปกติของ Charger',
    mod5_name:'โมดูล 5',mod5_sub:'ปัญหาเครือข่ายอินเตอร์เน็ต',
    m5_tab1:'🌐 ตรวจจับด้วย AI & แผนผังเครือข่าย',m5_tab2:'📈 กราฟข้อมูลย้อนหลัง',m5_tab3:'📖 คำอธิบายอัลกอริทึม',m5_tab4:'📊 ผลลัพธ์การตรวจจับ',
    m5_title:'ทำนายสาเหตุปัญหาเครือข่าย — AI Network Topology',
    m5_ht_title:'แผนผังเครือข่าย — สถานะอุปกรณ์',
    m5_hist_h:'สถานะเครือข่ายย้อนหลัง — อนุกรมเวลา',
    m5_algo_h:'ระบบตรวจจับปัญหาเครือข่าย — คำอธิบายอัลกอริทึม',
    m5_do_h:'ผลลัพธ์การตรวจจับ — ตรวจสอบปัญหาเครือข่าย',
    mod6_name:'โมดูล 6',mod6_sub:'อายุที่เหลือของอุปกรณ์ภายในเครื่อง',
    mod7_name:'โมดูล 7',mod7_sub:'วิเคราะห์ปัญหา Charger จ่ายไฟไม่ได้',
    m7_tab1:'🔍 ตรวจสอบสถานะ',m7_tab2:'📊 ไทม์ไลน์',m7_tab3:'🧠 ทำนายความผิดปกติ',m7_tab4:'📖 คำอธิบายอัลกอริทึม',
    m7_title:'EV-PLCC State Monitoring — วิเคราะห์โปรโตคอลการชาร์จ ISO 15118',
    m7_icp_h:'ICPState (สถานะ Control Pilot)',m7_uslink_h:'UslinkState (โปรโตคอลสื่อสาร)',
    m7_timeline_h:'ไทม์ไลน์การเปลี่ยนสถานะ',m7_predict_h:'ทำนายความผิดปกติ & สาเหตุหลัก',
    m7_algo_h:'วิเคราะห์ปัญหา Charger — คำอธิบายอัลกอริทึม'
  }
};
function switchLang(){
  curLang=curLang==='en'?'th':'en';
  document.getElementById('langLbl').textContent=curLang.toUpperCase();
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const k=el.getAttribute('data-i18n');
    if(I18N[curLang][k])el.innerHTML=I18N[curLang][k];
  });
  // Toggle lng-en / lng-th wrapper divs
  document.querySelectorAll('.lng-en').forEach(el=>{el.style.display=curLang==='en'?'':'none'});
  document.querySelectorAll('.lng-th').forEach(el=>{el.style.display=curLang==='th'?'':'none'});
  // Update preset cards
  const pts=document.querySelectorAll('.pr .pt');
  const pds=document.querySelectorAll('.pr .pd');
  const L=I18N[curLang];
  if(pts[0]){pts[0].textContent=L.normal;pds[0].textContent=L.pr_normal;}
  if(pts[1]){pts[1].textContent=L.voltage;pds[1].textContent=L.pr_voltage;}
  if(pts[2]){pts[2].textContent=L.thermal;pds[2].textContent=L.pr_thermal;}
  if(pts[3]){pts[3].textContent=L.multi;pds[3].textContent=L.pr_multi;}
}

// ═══ CHARGER STATE SEQUENCE — HI-TECH ═══
function scVis(show){const b=document.getElementById('scBody');if(show)b.classList.remove('sc-hide');else b.classList.add('sc-hide')}
const ICP_LBL=['Inactive','A1 Not Plugged','B1 Plugged','C1 Vehicle Ready','D1 Ready+Vent','A2 Not Plugged','B2 Plugged','C2 Charging','D2 Charging+Vent','E Fault','Error'];
const ICP_FULL=['0: Inactive \u2014 System not active','1: A1 \u2014 Not plugged (PWM off)','2: B1 \u2014 Plugged in (PWM off)','3: C1 \u2014 Vehicle ready (PWM off)','4: D1 \u2014 Ready+Vent (PWM off)','5: A2 \u2014 Not plugged (PWM on)','6: B2 \u2014 Plugged in (PWM on)','7: C2 \u2014 Charging (PWM on)','8: D2 \u2014 Charging+Vent (PWM on)','9: E \u2014 Fault (CP=0V)','10: Error \u2014 State machine error'];
const USL_LBL=['Ready','Init','SLAC ok','SECC ok','Supported App Protocol','Session Setup','Service Discovery','Service Payment','Contract Auth','Charge Param','Cable Check','Pre Charge','Power Delivery','Current Demand','Welding Detection','Session Stop'];
const USL_FULL=['0: Ready','1: Init','2: SLAC ok','3: SECC ok','4: Supported App Protocol','5: Session Setup','6: Service Discovery','7: Service Payment Selection','8: Contract Authentication','9: Charge Parameter Discovery','10: Cable Check','11: Pre Charge','12: Power Delivery','13: Current Demand','14: Welding Detection','15: Session Stop'];
// ISO 15118-2:2014 Table 109 & 111 — V2G_EVCC_Msg_Timeout per state
const USL_TIMEOUT=['\u2014','\u2014','20s','20s','2s','2s','2s','2s','2s','2s','2s','2s','5s','0.25s','2s','2s'];
const USL_TIMEOUT_DETAIL=[
  'No V2G message',
  'Internal initialization',
  'CommSetup Timeout: 20s (EVCC) | Perf: 18s (SECC) \u2014 ISO 15118-2 Table 111',
  'CommSetup Timeout: 20s (EVCC) | Perf: 18s (SECC) \u2014 ISO 15118-2 Table 111',
  'Msg Timeout: 2s | SECC Perf: 1.5s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 2s | SECC Perf: 1.5s | CommSetup: 20s \u2014 ISO 15118-2 Table 109/111',
  'Msg Timeout: 2s | SECC Perf: 1.5s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 2s | SECC Perf: 1.5s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 2s | SECC Perf: 1.5s | Ongoing: 60s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 2s | SECC Perf: 1.5s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 2s | SECC Perf: 1.5s | CableCheck: 40s (EVCC) / 38s (SECC) \u2014 ISO 15118-2 Table 109/111',
  'Msg Timeout: 2s | SECC Perf: 1.5s | PreCharge: 7s (EVCC) / 5s (SECC) \u2014 ISO 15118-2 Table 109/111',
  'Msg Timeout: 5s | SECC Perf: 4.5s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 0.25s | SECC Perf: 0.025s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 2s | SECC Perf: 1.5s \u2014 ISO 15118-2 Table 109',
  'Msg Timeout: 2s | SECC Perf: 1.5s \u2014 ISO 15118-2 Table 109'
];

// Phase mapping: ICP state → human phase
const ICP_PHASE={0:'OFFLINE',1:'IDLE',2:'CONNECTED',3:'READY',4:'READY',5:'STANDBY',6:'LINKED',7:'CHARGING',8:'CHARGING',9:'FAULT',10:'ERROR'};
const PHASE_COLOR={
  OFFLINE:['#94a3b8','rgba(148,163,184,.25)','rgba(148,163,184,.06)'],
  IDLE:['#64748b','rgba(100,116,139,.25)','rgba(100,116,139,.06)'],
  CONNECTED:['#0284c7','rgba(2,132,199,.3)','rgba(2,132,199,.06)'],
  STANDBY:['#0891b2','rgba(8,145,178,.3)','rgba(8,145,178,.06)'],
  LINKED:['#7c3aed','rgba(124,58,237,.3)','rgba(124,58,237,.06)'],
  READY:['#d97706','rgba(217,119,6,.3)','rgba(217,119,6,.06)'],
  CHARGING:['#16a34a','rgba(22,163,74,.3)','rgba(22,163,74,.06)'],
  FAULT:['#ef4444','rgba(239,68,68,.3)','rgba(239,68,68,.06)'],
  ERROR:['#ef4444','rgba(239,68,68,.3)','rgba(239,68,68,.06)']
};

function sqBuild(containerId,labels,fullLabels,timeouts,timeoutDetails){
  const c=document.getElementById(containerId);if(!c)return;
  c.innerHTML='';
  labels.forEach((lbl,i)=>{
    if(i>0){const w=document.createElement('div');w.className='sq-wire';w.dataset.idx=i;c.appendChild(w)}
    const step=document.createElement('div');step.className='sq-step';
    const tBadge=timeouts?'<span class="sq-to">'+timeouts[i]+'</span>':'';
    const tTip=timeoutDetails?'<div class="sq-tip-to">'+timeoutDetails[i]+'</div>':'';
    step.innerHTML='<span class="sq-idx">'+i+'</span><div class="sq-node" data-idx="'+i+'"><div class="sq-node-ping"></div><div class="sq-node-ring"></div><div class="sq-node-inner"></div></div><span class="sq-lbl">'+lbl+'</span>'+tBadge+'<div class="sq-tip">'+fullLabels[i]+tTip+'</div>';
    c.appendChild(step);
  });
}

function sqUpdate(containerId,current,isErr){
  const c=document.getElementById(containerId);if(!c)return;
  c.querySelectorAll('.sq-step').forEach(step=>{
    const node=step.querySelector('.sq-node');
    const idx=parseInt(node.dataset.idx);
    step.classList.remove('sq-past','sq-active','sq-err');
    if(idx<current)step.classList.add('sq-past');
    else if(idx===current)step.classList.add(isErr?'sq-err':'sq-active');
  });
  c.querySelectorAll('.sq-wire').forEach(w=>{
    const idx=parseInt(w.dataset.idx);
    w.classList.toggle('sq-done',idx<=current);
  });
  c.querySelectorAll('.sq-lbl').forEach((lbl,i)=>{
    lbl.classList.remove('sq-lbl-active','sq-lbl-err');
    if(i===current)lbl.classList.add(isErr?'sq-lbl-err':'sq-lbl-active');
  });
}

// sqSignal replaced by sqSignalColor in sqRefresh

function sqDescUpdate(elId,icp,usl){
  const el=document.getElementById(elId);if(!el)return;
  const phases=[
    {name:'Plug-in',cls:'sq-desc-plug',active:icp>=2,icon:icp>=2?'#0284c7':'rgba(0,0,0,.1)',emoji:'\u{1F50C}'},
    {name:'V2G Link',cls:'sq-desc-v2g',active:usl>=2,icon:usl>=2?'#7c3aed':'rgba(0,0,0,.1)',emoji:'\u{1F517}'},
    {name:'Negotiation',cls:'sq-desc-nego',active:usl>=4&&usl<=11,icon:usl>=4&&usl<=11?'#d97706':'rgba(0,0,0,.1)',emoji:'\u{1F4DD}'},
    {name:'Charging',cls:'sq-desc-chrg',active:usl===13||icp===7,icon:usl===13||icp===7?'#16a34a':'rgba(0,0,0,.1)',emoji:'\u26A1'},
    {name:'Finishing',cls:'sq-desc-fin',active:usl>=14&&usl<=15,icon:usl>=14?'#ec4899':'rgba(0,0,0,.1)',emoji:'\u2705'}
  ];
  el.innerHTML=phases.map(p=>'<div class="sq-desc-item '+p.cls+(p.active?' sq-desc-active':'')+'"><div class="sq-desc-icon" style="background:'+p.icon+';box-shadow:'+(p.active?'0 0 4px '+p.icon:'none')+'"></div><div class="sq-desc-txt"><strong>'+p.emoji+' '+p.name+'</strong></div></div>').join('');
}

// Build all 4 tracks
sqBuild('sqIcp1',ICP_LBL,ICP_FULL);
sqBuild('sqIcp2',ICP_LBL,ICP_FULL);
sqBuild('sqUsl1',USL_LBL,USL_FULL,USL_TIMEOUT,USL_TIMEOUT_DETAIL);
sqBuild('sqUsl2',USL_LBL,USL_FULL,USL_TIMEOUT,USL_TIMEOUT_DETAIL);

function sqRefresh(d){
  if(!d||!d.plc_data)return;
  const pd=d.plc_data;
  for(const cn of [1,2]){
    const icp=parseInt(pd['icp'+cn])||0;
    const usl=parseInt(pd['usl'+cn])||0;
    const isIcpErr=icp>=9;
    sqUpdate('sqIcp'+cn,icp,isIcpErr);
    sqUpdate('sqUsl'+cn,usl,false);

    // Resolve phase color
    const phase=ICP_PHASE[icp]||'UNKNOWN';
    const pc=PHASE_COLOR[phase]||PHASE_COLOR.IDLE;
    const phaseCol=pc[0];

    // Color active nodes by phase
    const panel=document.querySelector('.sq-panel[data-cn="'+cn+'"]');
    if(panel){
      panel.querySelectorAll('.sq-active .sq-node-inner').forEach(n=>{
        if(!isIcpErr){n.style.borderColor=phaseCol;n.style.background=phaseCol;n.style.boxShadow='0 0 0 3px '+phaseCol+'30,0 0 10px '+phaseCol+'25'}
      });
      // Color active labels by phase
      panel.querySelectorAll('.sq-lbl-active').forEach(l=>{if(!isIcpErr)l.style.color=phaseCol});
      panel.querySelectorAll('.sq-active .sq-idx').forEach(x=>{if(!isIcpErr)x.style.color=phaseCol});
      panel.querySelectorAll('.sq-active .sq-to').forEach(t=>{if(!isIcpErr){t.style.color=phaseCol;t.style.borderColor=phaseCol+'33';t.style.background=phaseCol+'0a'}});
      // Color done wires by phase
      panel.querySelectorAll('.sq-wire.sq-done').forEach(w=>{w.style.background='linear-gradient(180deg,'+phaseCol+'60,'+phaseCol+'25)'});
    }

    // HUD readouts
    const it=document.getElementById('sqIcpTxt'+cn);
    const ut=document.getElementById('sqUslTxt'+cn);
    const icpC=isIcpErr?'#ef4444':icp>=2?phaseCol:'var(--dim)';
    const uslC=usl>=1?phaseCol:'var(--dim)';
    if(it){it.style.color=icpC;it.textContent=icp+' \u2022 '+ICP_LBL[icp]}
    if(ut){ut.style.color=uslC;ut.textContent=usl+' \u2022 '+USL_LBL[usl]}

    // Phase badge
    const ph=document.getElementById('sqPhase'+cn);
    if(ph){ph.textContent=phase;ph.style.color=pc[0];ph.style.borderColor=pc[1];ph.style.background=pc[2];ph.style.fontWeight='700'}

    // Progress bar
    const icpPct=Math.min(icp/10*100,100);
    const uslPct=Math.min(usl/15*100,100);
    const totalPct=Math.round(icpPct*0.3+uslPct*0.7);
    const prog=document.getElementById('sqProg'+cn);
    if(prog){
      prog.style.width=totalPct+'%';
      const isCharging=phase==='CHARGING';
      if(isIcpErr){prog.style.background='linear-gradient(90deg,#ef4444,#f87171)'}
      else if(isCharging){prog.style.background='linear-gradient(90deg,#16a34a,#22c55e,#4ade80)'}
      prog.classList.toggle('sq-charging',isCharging);
    }

    // Signal strength with phase color
    const sigLvl=icp===0?0:icp<=2?1:icp<=5?2:icp<=6?3:icp>=7?5:1;
    sqSignalColor('sqSig'+cn,sigLvl,isIcpErr?'#ef4444':phaseCol);

    // Phase description
    sqDescUpdate('sqDesc'+cn,icp,usl);
  }
}

function sqSignalColor(elId,level,col){
  const el=document.getElementById(elId);if(!el)return;
  let h='';
  for(let i=0;i<5;i++){
    const on=i<level;
    const ht=3+i*2;
    h+='<div class="sq-signal-bar" style="height:'+ht+'px;background:'+(on?col:'rgba(0,0,0,.06)')+'"></div>';
  }
  el.innerHTML=h;
}

// ═══ HISTORICAL GRAPH ═══
const HIST_GROUPS={
  voltage:{label:'Voltage',fields:['target_voltage1','present_voltage1','target_voltage2','present_voltage2'],colors:['#0284c7','#38bdf8','#7c3aed','#a78bfa'],unit:'V'},
  current:{label:'Current',fields:['target_current1','present_current1','target_current2','present_current2'],colors:['#dc2626','#f87171','#d97706','#fbbf24'],unit:'A'},
  temperature:{label:'Temperature',fields:['charger_temp','charger_gun_temp_plus1','charger_gun_temp_plus2','charger_gun_temp_minus1','charger_gun_temp_minus2','edgebox_temp'],colors:['#db2777','#f472b6','#e879f9','#818cf8','#6366f1','#d97706'],unit:'°C'},
  power_module:{label:'Power Module',fields:['power_module_temp1','power_module_temp2','power_module_temp3','power_module_temp4','power_module_temp5'],colors:['#dc2626','#d97706','#059669','#0284c7','#7c3aed'],unit:'°C'},
  environment:{label:'Environment',fields:['humidity','edgebox_temp'],colors:['#0284c7','#d97706'],unit:''},
  soc:{label:'SOC',fields:['SOC'],colors:['#059669'],unit:'%'},
  energy:{label:'Energy',fields:['meter1','meter2'],colors:['#0284c7','#059669'],unit:'kWh',scale:0.001}
};
let histRange='daily',histField='voltage',histChart=null,histLoaded=false;
function setHistRange(r,btn){
  histRange=r;
  document.querySelectorAll('#histRange .hist-btn').forEach(b=>b.classList.remove('on'));btn.classList.add('on');
  const show=r==='custom';
  document.getElementById('histCustom').style.display=show?'':'none';
  document.getElementById('histCustom2').style.display=show?'':'none';
  if(show&&!document.getElementById('histStart').value){
    const now=new Date(),d=new Date(now.getTime()-86400000);
    document.getElementById('histStart').value=d.toISOString().slice(0,16);
    document.getElementById('histEnd').value=now.toISOString().slice(0,16);
  }
}
function setHistField(f,btn){histField=f;document.querySelectorAll('#histFields .hist-btn').forEach(b=>b.classList.remove('on'));btn.classList.add('on')}

async function loadHistory(){
  const grp=HIST_GROUPS[histField];if(!grp)return;
  const el=document.getElementById('histLoading'),emp=document.getElementById('histEmpty'),wrap=document.querySelector('.hist-chart-wrap');
  emp.style.display='none';emp.className='hist-empty';el.style.display='flex';wrap.style.display='none';
  let url='/api/historical?range='+histRange+'&fields='+grp.fields.join(',');
  if(histRange==='custom'){
    const s=document.getElementById('histStart').value,e=document.getElementById('histEnd').value;
    if(!s||!e){emp.className='hist-empty hist-warn';emp.innerHTML='<div class="he-title">\u26A0 Please select Start and End datetime.</div>';emp.style.display='';el.style.display='none';return}
    url+='&start='+encodeURIComponent(s)+'&end='+encodeURIComponent(e);
  }
  let r,d,httpStatus='';
  try{
    r=await fetch(url);
    httpStatus=r.status+' '+r.statusText;
    const txt=await r.text();
    try{d=JSON.parse(txt)}catch(pe){
      el.style.display='none';
      emp.className='hist-empty hist-err';
      emp.innerHTML='<div class="he-title">\u274C JSON Parse Error</div>'+
        '<div class="he-row"><span>URL</span><code>'+url+'</code></div>'+
        '<div class="he-row"><span>HTTP</span><code>'+httpStatus+'</code></div>'+
        '<div class="he-row"><span>Response</span><code>'+txt.substring(0,500)+'</code></div>';
      emp.style.display='';return;
    }
    if(d.error){
      el.style.display='none';
      emp.className='hist-empty hist-err';
      emp.innerHTML='<div class="he-title">\u274C Server Error</div>'+
        '<div class="he-row"><span>HTTP</span><code>'+httpStatus+'</code></div>'+
        '<div class="he-row"><span>Error</span><code>'+d.error+'</code></div>'+
        '<div class="he-row"><span>URL</span><code>'+url+'</code></div>';
      emp.style.display='';return;
    }
    if(!d.data||!d.data.length){
      el.style.display='none';
      emp.className='hist-empty hist-warn';
      emp.innerHTML='<div class="he-title">\u26A0 No Data</div>'+
        '<div class="he-row"><span>HTTP</span><code>'+httpStatus+'</code></div>'+
        '<div class="he-row"><span>Range</span><code>'+histRange+'</code></div>'+
        '<div class="he-row"><span>Fields</span><code>'+grp.fields.join(', ')+'</code></div>'+
        '<div class="he-row"><span>Count</span><code>'+(d.count||0)+' documents</code></div>'+
        '<div class="he-hint">Possible causes: no data in the selected time range, MongoDB collection empty, or timestamp field format mismatch.</div>';
      emp.style.display='';return;
    }
    el.style.display='none';wrap.style.display='';
    const info=document.getElementById('histInfo');
    info.textContent=d.data.length+' points \u00B7 '+histRange+' \u00B7 '+(d.interval||'raw');
    document.getElementById('histChartTitle').textContent=grp.label+' \u2014 '+histRange.charAt(0).toUpperCase()+histRange.slice(1);
    renderHistChart(d.data,grp);
    renderHistStats(d.data,grp);
  }catch(e){
    el.style.display='none';
    emp.className='hist-empty hist-err';
    const isRender=httpStatus&&httpStatus.startsWith('200');
    emp.innerHTML='<div class="he-title">\u274C '+(isRender?'Render Error':'Network / Fetch Error')+'</div>'+
      '<div class="he-row"><span>Error</span><code>'+e.message+'</code></div>'+
      '<div class="he-row"><span>Type</span><code>'+e.name+'</code></div>'+
      '<div class="he-row"><span>URL</span><code>'+url+'</code></div>'+
      (httpStatus?'<div class="he-row"><span>HTTP</span><code>'+httpStatus+'</code></div>':'')+
      '<div class="he-hint">'+(isRender?'Data was fetched but rendering failed. Check browser console for details.':'Check if the server is running, MongoDB is reachable, and pymongo is installed.')+'</div>';
    emp.style.display='';
    if(isRender)console.error('Render error:',e);
  }
}

function renderHistChart(data,grp){
  const ctx=document.getElementById('histCanvas');
  if(histChart){histChart.destroy();histChart=null}
  const sc=grp.scale||1;
  const datasets=grp.fields.map((f,i)=>({
    label:f.replace(/_/g,' '),
    data:data.map(d=>{const v=Number(d[f]);return{x:new Date(d.timestamp),y:isNaN(v)?null:v*sc}}),
    borderColor:grp.colors[i],backgroundColor:grp.colors[i]+'18',
    borderWidth:1.5,pointRadius:0,pointHitRadius:6,fill:false,tension:.3,spanGaps:true
  }));
  histChart=new Chart(ctx,{
    type:'line',
    data:{datasets},
    options:{
      responsive:true,maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{
        legend:{position:'top',labels:{usePointStyle:true,pointStyle:'circle',padding:16,font:{family:'Plus Jakarta Sans,Prompt',size:11}}},
        tooltip:{
          backgroundColor:'rgba(15,23,42,.9)',titleFont:{family:'JetBrains Mono',size:11},bodyFont:{family:'JetBrains Mono',size:11},
          callbacks:{label:function(c){const v=c.parsed.y;return c.dataset.label+': '+(v!=null?v.toFixed(1):'N/A')+(grp.unit?' '+grp.unit:'')}}
        }
      },
      scales:{
        x:{type:'time',time:{tooltipFormat:'yyyy-MM-dd HH:mm:ss',displayFormats:{minute:'HH:mm',hour:'HH:mm',day:'MM/dd'}},
          grid:{color:'rgba(200,210,225,.15)'},ticks:{font:{family:'JetBrains Mono',size:10},color:'#718096',maxTicksLimit:12}},
        y:{grid:{color:'rgba(200,210,225,.15)'},ticks:{font:{family:'JetBrains Mono',size:10},color:'#718096'},
          title:{display:true,text:grp.unit||'value',font:{family:'Plus Jakarta Sans,Prompt',size:11},color:'#718096'}}
      }
    }
  });
}

function renderHistStats(data,grp){
  const el=document.getElementById('histStats');el.innerHTML='';
  const sc=grp.scale||1;
  grp.fields.forEach((f,i)=>{
    const vals=data.map(d=>Number(d[f])).filter(v=>!isNaN(v)&&isFinite(v)).map(v=>v*sc);
    if(!vals.length)return;
    const mn=Math.min(...vals),mx=Math.max(...vals),avg=vals.reduce((a,b)=>a+b,0)/vals.length;
    const last=vals[vals.length-1];
    el.innerHTML+=
      '<div class="hist-stat-card"><div class="hs-label" style="color:'+grp.colors[i]+'">'+f.replace(/_/g,' ')+'</div>'+
      '<div class="hs-val">'+Number(last).toFixed(1)+(grp.unit?' <small>'+grp.unit+'</small>':'')+'</div>'+
      '<div class="hs-row"><span>Min</span><span>'+Number(mn).toFixed(1)+'</span></div>'+
      '<div class="hs-row"><span>Max</span><span>'+Number(mx).toFixed(1)+'</span></div>'+
      '<div class="hs-row"><span>Avg</span><span>'+Number(avg).toFixed(1)+'</span></div></div>';
  });
}


// ═══ HEALTH TREE: Evaluate 22 Conditions ═══
function evalConditions(v){
  const r=[];
  const n=(f)=>{const x=v[f];return typeof x==='number'?x:parseFloat(x)||0};
  const st=(f)=>{const x=v[f];return (typeof x==='string'&&(x==='Inactive'||x==='inactive'||x==='0'))||x===0};
  // C01: Voltage H1 — deviation > 0.5%
  const tv1=n('target_voltage1'),pv1=n('present_voltage1');
  const vd1=tv1>0?Math.abs(tv1-pv1)/tv1*100:0;
  r.push({id:'01',alarm:tv1>0&&vd1>0.5,val:pv1.toFixed(1)+'V ('+vd1.toFixed(2)+'%)'});
  // C02: Current H1 — deviation > 1%
  const tc1=n('target_current1'),pc1=n('present_current1');
  const cd1=tc1>0?Math.abs(tc1-pc1)/tc1*100:0;
  r.push({id:'02',alarm:tc1>0&&cd1>1,val:pc1.toFixed(1)+'A ('+cd1.toFixed(1)+'%)'});
  // C03: Voltage H2
  const tv2=n('target_voltage2'),pv2=n('present_voltage2');
  const vd2=tv2>0?Math.abs(tv2-pv2)/tv2*100:0;
  r.push({id:'03',alarm:tv2>0&&vd2>0.5,val:pv2.toFixed(1)+'V ('+vd2.toFixed(2)+'%)'});
  // C04: Current H2
  const tc2=n('target_current2'),pc2=n('present_current2');
  const cd2=tc2>0?Math.abs(tc2-pc2)/tc2*100:0;
  r.push({id:'04',alarm:tc2>0&&cd2>1,val:pc2.toFixed(1)+'A ('+cd2.toFixed(1)+'%)'});
  // C05: Power H1 — deviation > 5%
  const tp1=tv1*tc1,pp1=pv1*pc1;
  const pd1=tp1>0?Math.abs(tp1-pp1)/tp1*100:0;
  r.push({id:'05',alarm:tp1>0&&pd1>5,val:(pp1/1000).toFixed(1)+'kW ('+pd1.toFixed(1)+'%)'});
  // C06: Power H2
  const tp2=tv2*tc2,pp2=pv2*pc2;
  const pd2=tp2>0?Math.abs(tp2-pp2)/tp2*100:0;
  r.push({id:'06',alarm:tp2>0&&pd2>5,val:(pp2/1000).toFixed(1)+'kW ('+pd2.toFixed(1)+'%)'});
  // C07-C11: Module Temp 1-5 > 55°C
  for(let i=1;i<=5;i++){
    const t=n('power_module_temp'+i);
    r.push({id:String(6+i).padStart(2,'0'),alarm:t>55,val:t.toFixed(1)+'°C'});
  }
  // C12: Charger Temp > 55°C
  const ct=n('charger_temp');
  r.push({id:'12',alarm:ct>55,val:ct.toFixed(1)+'°C'});
  // C13: PM Status H1 (PM1 or PM2 inactive)
  const pm1=st('power_module_status1'),pm2=st('power_module_status2');
  r.push({id:'13',alarm:pm1||pm2,val:(pm1?'PM1:OFF ':'PM1:ON ')+(pm2?'PM2:OFF':'PM2:ON')});
  // C14: PM Status H2 (PM3/4/5 inactive)
  const pm3=st('power_module_status3'),pm4=st('power_module_status4'),pm5=st('power_module_status5');
  r.push({id:'14',alarm:pm3||pm4||pm5,val:(pm3?'3:OFF ':'3:ON ')+(pm4?'4:OFF ':'4:ON ')+(pm5?'5:OFF':'5:ON')});
  // C15: Cable H1 (gun temp > 90°C)
  const gp1=n('charger_gun_temp_plus1'),gm1=n('charger_gun_temp_minus1');
  r.push({id:'15',alarm:gp1>90||gm1>90,val:'+:'+gp1+'°C -:'+gm1+'°C'});
  // C16: Cable H2
  const gp2=n('charger_gun_temp_plus2'),gm2=n('charger_gun_temp_minus2');
  r.push({id:'16',alarm:gp2>90||gm2>90,val:'+:'+gp2+'°C -:'+gm2+'°C'});
  // C17: PLC1 inactive
  const plc1=st('PLC1_status');
  r.push({id:'17',alarm:plc1,val:plc1?'Inactive':'Active'});
  // C18: PLC2 inactive
  const plc2=st('PLC2_status');
  r.push({id:'18',alarm:plc2,val:plc2?'Inactive':'Active'});
  // C19: EdgeBox > 70°C
  const eb=n('edgebox_temp');
  r.push({id:'19',alarm:eb>70,val:eb.toFixed(1)+'°C'});
  // C20-C21: Daily energy (not evaluated here — needs historical data)
  r.push({id:'20',alarm:false,val:'—'});
  r.push({id:'21',alarm:false,val:'—'});
  // C22: Energy Meter inactive
  const em=st('energy_meter_status');
  r.push({id:'22',alarm:em,val:em?'Inactive':'Active'});

  // Update DOM
  let okCnt=0,alCnt=0;
  r.forEach(c=>{
    const val=document.getElementById('v'+c.id);
    const badge=document.getElementById('b'+c.id);
    const row=document.getElementById('c'+c.id);
    if(!val)return;
    if(c.alarm){
      badge.className='cn-b al';badge.textContent='ALARM';
      if(row)row.classList.add('alarm');alCnt++;
    }else{
      badge.className='cn-b ok';badge.textContent='OK';
      if(row)row.classList.remove('alarm');okCnt++;
    }
    if(val)val.textContent=c.val;
  });
  document.getElementById('htOkCnt').textContent=okCnt;
  document.getElementById('htAlCnt').textContent=alCnt;
  document.getElementById('rootCnt').textContent=Math.round(alCnt/22*100)+'% — '+alCnt+' / 22 alarms';
  updateGauge();
  // Store for Detection Output tab
  m4DoResults=r;
}

function updateGauge(){
  let normal=0,warn=0,alarm=0;
  const total=22;
  for(let i=1;i<=22;i++){
    const num=String(i).padStart(2,'0');
    const badge=document.getElementById('b'+num);
    if(!badge)continue;
    const cls=badge.className;
    if(cls.includes(' al')||badge.textContent==='ALARM'){alarm++}
    else if(cls.includes(' aw')||badge.textContent==='AI WARN'){warn++}
    else{normal++}
  }
  // Update horizontal bar widths
  const nPct=(normal/total*100),wPct=(warn/total*100),aPct=(alarm/total*100);
  const nBar=document.getElementById('hgNormal');
  const wBar=document.getElementById('hgWarn');
  const aBar=document.getElementById('hgAlarm');
  if(nBar)nBar.style.width=nPct+'%';
  if(wBar)wBar.style.width=wPct+'%';
  if(aBar)aBar.style.width=aPct+'%';
  [nBar,wBar,aBar].forEach(b=>{if(b)b.style.borderRadius='0'});
  const visible=[nBar,wBar,aBar].filter(b=>parseFloat(b.style.width)>0);
  if(visible.length){visible[0].style.borderRadius='6px 0 0 6px';visible[visible.length-1].style.borderRadius='0 6px 6px 0';if(visible.length===1)visible[0].style.borderRadius='6px'}
  document.getElementById('hgNormalCnt').textContent=normal;
  document.getElementById('hgWarnCnt').textContent=warn;
  document.getElementById('hgAlarmCnt').textContent=alarm;
  document.getElementById('hgTotalTxt').textContent=normal+' / '+total;

  // ── Arc gauge on root node ──
  const alarmCount=alarm+warn; // total non-normal conditions
  const arcTotal=351.9; // half-circle arc length (pi*112)

  // Determine level and color
  // Normal: 0-7, Warning: 8-14, Alarm: 15-22
  let level,color,label,dotColor;
  if(alarmCount>=15){level='alarm';color='#ef4444';label='ALARM';dotColor='#ef4444'}
  else if(alarmCount>=8){level='warning';color='#d97706';label='WARNING';dotColor='#d97706'}
  else{level='normal';color='#16a34a';label='NORMAL';dotColor='#16a34a'}

  // Arc fill: show colored arc proportional to alarmCount/22
  const fillLen=Math.max((alarmCount/total)*arcTotal,0);
  const arcN=document.getElementById('rgArcN');
  const arcW=document.getElementById('rgArcW');
  const arcA=document.getElementById('rgArcA');
  if(arcN&&arcW&&arcA){
    // Reset all active fill arcs
    arcN.setAttribute('opacity','0');arcW.setAttribute('opacity','0');arcA.setAttribute('opacity','0');
    // Show bright fill arc matching current level
    if(alarmCount===0){
      // Zero alarms — no bright fill needed, zones stay dim
    }else if(level==='normal'){
      arcN.setAttribute('opacity','1');
      arcN.setAttribute('stroke-dashoffset',arcTotal-fillLen);
    }else if(level==='warning'){
      arcW.setAttribute('opacity','1');
      arcW.setAttribute('stroke-dashoffset',arcTotal-fillLen);
    }else{
      arcA.setAttribute('opacity','1');
      arcA.setAttribute('stroke-dashoffset',arcTotal-fillLen);
    }
  }

  // Needle rotation: -90deg (left/0) to +90deg (right/22)
  const angle=-90+(alarmCount/total)*180;
  const needle=document.getElementById('rgNeedle');
  if(needle){
    needle.setAttribute('transform','rotate('+angle+' 150 155)');
    // Color needle tip
    const nTip=document.getElementById('rgTip');
    if(nTip)nTip.setAttribute('fill',color);
  }

  // Center value
  const rgVal=document.getElementById('rgVal');
  if(rgVal){rgVal.textContent=Math.round(alarmCount/total*100)+'%';rgVal.setAttribute('fill',color)}

  // Status pill
  const color2=color==='#ef4444'?'rgba(239,68,68,':color==='#d97706'?'rgba(217,119,6,':'rgba(22,163,74,';
  const rgPill=document.getElementById('rgPill');
  if(rgPill){rgPill.style.background=color2+'.08)';rgPill.style.borderColor=color2+'.18)'}
  const rgDot=document.getElementById('rgDot');
  const rgTxt=document.getElementById('rgTxt');
  if(rgDot){rgDot.style.background=dotColor;rgDot.style.boxShadow='0 0 10px '+color2+'.5)'}
  if(rgTxt){rgTxt.style.color=color;rgTxt.textContent=label}

  // Scan ring color
  const scan=document.querySelector('.rg-scan');
  if(scan)scan.setAttribute('stroke','url(#'+(level==='alarm'?'gAlrm':level==='warning'?'gWarn':'gNorm')+')');

  // Header text color matches level
  const root=document.getElementById('rootN');
  if(root){
    const rnH=root.querySelector('.rn-h');
    if(rnH)rnH.style.color=color;
  }
}


// ═══ HEALTH TREE: Draw SVG bracket lines ═══
function drawTreeLines(){
  const C=document.getElementById('htCanvas');
  const S=document.getElementById('htSvg');
  const eqCol=document.getElementById('colE');
  if(!C||!S||!eqCol)return;
  const cr=C.getBoundingClientRect();
  const eqColR=eqCol.getBoundingClientRect();
  S.setAttribute('width',cr.width);S.setAttribute('height',cr.height);
  S.innerHTML='';
  function curve(x1,y1,x2,y2,col,w,op){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    const cx=(x1+x2)/2;
    p.setAttribute('d','M'+x1+','+y1+' C'+cx+','+y1+' '+cx+','+y2+' '+x2+','+y2);
    p.setAttribute('fill','none');p.setAttribute('stroke',col);p.setAttribute('stroke-width',w||1.5);p.setAttribute('opacity',op||0.45);
    S.appendChild(p);
  }
  const rx=el=>{const r=el.getBoundingClientRect();return r.right-cr.left};
  const lx=el=>{const r=el.getBoundingClientRect();return r.left-cr.left};
  const cy=el=>{const r=el.getBoundingClientRect();return r.top-cr.top+r.height/2};
  const GRP=[
    {g:'pm',eq:'eqPM',c:'#dc2626'},
    {g:'cc',eq:'eqCC',c:'#0d9488'},
    {g:'ocpp',eq:'eqOCPP',c:'#0891b2'},
    {g:'unk',eq:'eqUNK',c:'#78716c'},
    {g:'em',eq:'eqEM',c:'#059669'}
  ];
  // PASS 1: Calculate ideal midpoint positions
  const MIN_GAP=18;
  const htSlots=[];
  GRP.forEach(g=>{
    const nodes=[...document.querySelectorAll('[data-g="'+g.g+'"]')];
    const eqEl=document.getElementById(g.eq);
    if(!nodes.length||!eqEl)return;
    const firstR=nodes[0].getBoundingClientRect();
    const lastR=nodes[nodes.length-1].getBoundingClientRect();
    const idealY=(firstR.top+firstR.height/2+lastR.top+lastR.height/2)/2-eqColR.top;
    const h=eqEl.offsetHeight||40;
    htSlots.push({el:eqEl,idealY:idealY,y:idealY,h:h,g:g});
  });
  htSlots.sort((a,b)=>a.idealY-b.idealY);
  for(let i=1;i<htSlots.length;i++){
    const prev=htSlots[i-1],cur=htSlots[i];
    const prevBot=prev.y+prev.h/2+MIN_GAP;
    const curTop=cur.y-cur.h/2;
    if(curTop<prevBot){cur.y=prevBot+cur.h/2}
  }
  htSlots.forEach(s=>{s.el.style.top=s.y+'px'});
  // Draw bezier curves: conditions → equipment
  const eqPts=[];
  GRP.forEach(g=>{
    const nodes=[...document.querySelectorAll('[data-g="'+g.g+'"]')];
    const eqEl=document.getElementById(g.eq);if(!nodes.length||!eqEl)return;
    const elx=lx(eqEl),ecy=cy(eqEl),erx=rx(eqEl);
    eqPts.push({lx:elx,rx:erx,cy:ecy,c:g.c});
    nodes.forEach(n=>curve(rx(n),cy(n),elx,ecy,g.c,1.5,0.45));
  });
  // Equipment → Root gauge
  const rootEl=document.getElementById('rootN');
  if(!rootEl||!eqPts.length)return;
  const rlx=lx(rootEl),rcy=cy(rootEl);
  eqPts.forEach(e=>curve(e.rx,e.cy,rlx,rcy,e.c,1.5,0.35));
}

// ═══ REALTIME TELEMETRY FROM MONGODB ═══
const TELE_STATUS_MAP={'Active':1,'Inactive':0,'active':1,'inactive':0};
let teleInterval=null,teleOk=false;
async function fetchLatestTelemetry(){
  try{
    const r=await fetch('/api/latest'),d=await r.json();
    if(d.error||!d.data){
      document.getElementById('teleLed').className='led';
      document.getElementById('teleSt').textContent=curLang==='th'?'ออฟไลน์':'Offline';
      document.getElementById('teleTs').textContent=d.error||'';
      teleOk=false;return;
    }
    const v=d.data;
    // Fill all input fields
    F.forEach(f=>{
      const el=document.getElementById(f);
      if(!el)return;
      let val=v[f];
      if(val===undefined||val===null)return;
      // Convert status strings to 1/0
      if(typeof val==='string'&&TELE_STATUS_MAP[val]!==undefined)val=TELE_STATUS_MAP[val];
      el.value=val;
    });
    // Fill hour/minute/day/month from timestamp
    const ts=v.timestamp_utc||v.timestamp||'';
    if(ts){
      const dt=new Date(ts);
      if(!isNaN(dt)){
        const he=document.getElementById('hour'),me=document.getElementById('minute');
        const de=document.getElementById('day_of_month'),mo=document.getElementById('mouth_of_year');
        if(he)he.value=dt.getHours();if(me)me.value=dt.getMinutes();
        if(de)de.value=dt.getDate();if(mo)mo.value=dt.getMonth()+1;
      }
    }
    // Update LED and timestamp
    document.getElementById('teleLed').className='led on';
    document.getElementById('teleSt').textContent=curLang==='th'?'สด':'Live';
    const displayTs=v.timestamp||v.timestamp_utc||'';
    document.getElementById('teleTs').textContent=displayTs?('\u23F1 '+displayTs.replace('T',' ').substring(0,19)):'';
    teleOk=true;
    evalConditions(v);drawTreeLines();
    // Hybrid AI: fetch per-condition AI scores
    fetchConditionAI(v);
  }catch(e){
    document.getElementById('teleLed').className='led';
    document.getElementById('teleSt').textContent=curLang==='th'?'ออฟไลน์':'Offline';
    document.getElementById('teleTs').textContent=e.message;
    teleOk=false;
  }
}
// Poll every 5 seconds
teleInterval=setInterval(fetchLatestTelemetry,120000);
// Initial draw + fetch
setTimeout(drawTreeLines,600);
// Auto-start M4 Auto Predict on page load
setTimeout(()=>{var cb=document.getElementById('apToggle');if(cb&&cb.checked&&!apTickId){apStart()}},1500);
setTimeout(drawRuleTreeLines,700);
// Build gauge tick marks
(function buildGaugeTicks(){
  const g=document.getElementById('rgTicks');if(!g)return;
  const cx=150,cy=155;
  for(let i=0;i<=22;i++){
    const angle=Math.PI+(i/22)*Math.PI;
    const cos=Math.cos(angle),sin=Math.sin(angle);
    const isMajor=(i===0||i===8||i===15||i===22);
    const isMid=(i%2===0&&!isMajor);
    const zoneCol=i<=7?'22,163,74':i<=14?'217,119,6':'239,68,68';
    // Outer ticks
    const outerR1=isMajor?127:125,outerR2=isMajor?134:130;
    const ol=document.createElementNS('http://www.w3.org/2000/svg','line');
    ol.setAttribute('x1',cx+outerR1*cos);ol.setAttribute('y1',cy+outerR1*sin);
    ol.setAttribute('x2',cx+outerR2*cos);ol.setAttribute('y2',cy+outerR2*sin);
    ol.setAttribute('stroke','rgba('+zoneCol+','+(isMajor?.4:isMid?.18:.08)+')');
    ol.setAttribute('stroke-width',isMajor?2.5:isMid?1.5:1);
    ol.setAttribute('stroke-linecap','round');ol.classList.add('rg-tick');g.appendChild(ol);
    // Inner ticks
    const innerR1=isMajor?97:100,innerR2=isMajor?91:96;
    const il=document.createElementNS('http://www.w3.org/2000/svg','line');
    il.setAttribute('x1',cx+innerR1*cos);il.setAttribute('y1',cy+innerR1*sin);
    il.setAttribute('x2',cx+innerR2*cos);il.setAttribute('y2',cy+innerR2*sin);
    il.setAttribute('stroke','rgba('+zoneCol+','+(isMajor?.3:.08)+')');
    il.setAttribute('stroke-width',isMajor?2:1);
    il.setAttribute('stroke-linecap','round');il.classList.add('rg-tick');g.appendChild(il);
    if(isMajor){
      const lr=82;
      const txt=document.createElementNS('http://www.w3.org/2000/svg','text');
      txt.setAttribute('x',cx+lr*cos);txt.setAttribute('y',cy+lr*sin+3.5);
      txt.setAttribute('text-anchor','middle');txt.setAttribute('font-size','10');
      txt.setAttribute('font-weight','800');txt.setAttribute('font-family','JetBrains Mono');
      txt.setAttribute('fill',i<=7?'#16a34a':i<=14?'#d97706':'#ef4444');txt.setAttribute('opacity','0.55');
      txt.textContent=Math.round(i/22*100);g.appendChild(txt);
    }
  }
})();
// Build Module 3 gauge ticks
(function buildM3Ticks(){
  const g=document.getElementById('m3Ticks');if(!g)return;
  const cx=130,cy=135;
  for(let i=0;i<=20;i++){
    const angle=Math.PI+(i/20)*Math.PI;
    const cos=Math.cos(angle),sin=Math.sin(angle);
    const isMajor=(i===0||i===7||i===14||i===20);
    const isMid=(i%2===0&&!isMajor);
    const zoneCol=i<=6?'22,163,74':i<=13?'217,119,6':'239,68,68';
    const outerR1=isMajor?110:108,outerR2=isMajor?117:113;
    const ol=document.createElementNS('http://www.w3.org/2000/svg','line');
    ol.setAttribute('x1',cx+outerR1*cos);ol.setAttribute('y1',cy+outerR1*sin);
    ol.setAttribute('x2',cx+outerR2*cos);ol.setAttribute('y2',cy+outerR2*sin);
    ol.setAttribute('stroke','rgba('+zoneCol+','+(isMajor?.4:isMid?.18:.08)+')');
    ol.setAttribute('stroke-width',isMajor?2:isMid?1.2:0.8);
    ol.setAttribute('stroke-linecap','round');g.appendChild(ol);
    const innerR1=isMajor?85:88,innerR2=isMajor?80:84;
    const il=document.createElementNS('http://www.w3.org/2000/svg','line');
    il.setAttribute('x1',cx+innerR1*cos);il.setAttribute('y1',cy+innerR1*sin);
    il.setAttribute('x2',cx+innerR2*cos);il.setAttribute('y2',cy+innerR2*sin);
    il.setAttribute('stroke','rgba('+zoneCol+','+(isMajor?.3:.08)+')');
    il.setAttribute('stroke-width',isMajor?1.5:0.8);
    il.setAttribute('stroke-linecap','round');g.appendChild(il);
  }
})();

(function buildM2HtTicks(){
  const g=document.getElementById('m2htTicks');if(!g)return;
  const cx=150,cy=155;
  for(let i=0;i<=22;i++){
    const angle=Math.PI+(i/22)*Math.PI;
    const cos=Math.cos(angle),sin=Math.sin(angle);
    const isMajor=(i===0||i===8||i===15||i===22);
    const isMid=(i%2===0&&!isMajor);
    const zoneCol=i<=7?'22,163,74':i<=14?'217,119,6':'239,68,68';
    const outerR1=isMajor?127:125,outerR2=isMajor?134:130;
    const ol=document.createElementNS('http://www.w3.org/2000/svg','line');
    ol.setAttribute('x1',cx+outerR1*cos);ol.setAttribute('y1',cy+outerR1*sin);
    ol.setAttribute('x2',cx+outerR2*cos);ol.setAttribute('y2',cy+outerR2*sin);
    ol.setAttribute('stroke','rgba('+zoneCol+','+(isMajor?.4:isMid?.18:.08)+')');
    ol.setAttribute('stroke-width',isMajor?2.5:isMid?1.5:1);
    ol.setAttribute('stroke-linecap','round');g.appendChild(ol);
    const innerR1=isMajor?97:100,innerR2=isMajor?91:96;
    const il=document.createElementNS('http://www.w3.org/2000/svg','line');
    il.setAttribute('x1',cx+innerR1*cos);il.setAttribute('y1',cy+innerR1*sin);
    il.setAttribute('x2',cx+innerR2*cos);il.setAttribute('y2',cy+innerR2*sin);
    il.setAttribute('stroke','rgba('+zoneCol+','+(isMajor?.3:.08)+')');
    il.setAttribute('stroke-width',isMajor?1.5:0.8);
    il.setAttribute('stroke-linecap','round');g.appendChild(il);
  }
})();setTimeout(fetchLatestTelemetry,500);
// ═══ PER-CONDITION AI SCORES ═══
let condAIReady=false;
async function fetchConditionAI(v){
  try{
    const r=await fetch('/predict/conditions',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(v)
    });
    const d=await r.json();
    if(!d.ready)return;
    condAIReady=true;
    const conds=d.conditions;

    // Overlay AI scores on condition nodes
    Object.entries(conds).forEach(([cid,info])=>{
      const num=cid.replace('C','');
      const row=document.getElementById('c'+num);
      const badge=document.getElementById('b'+num);
      const val=document.getElementById('v'+num);
      if(!row||!badge)return;

      const score=info.ai_score;
      const aiAlarm=info.ai_alarm;
      const type=info.type; // hybrid, ai_only

      // Find or create AI score badge
      let aiBadge=row.querySelector('.ai-score');
      if(!aiBadge){
        aiBadge=document.createElement('span');
        aiBadge.className='ai-score';
        badge.parentNode.insertBefore(aiBadge,badge.nextSibling);
      }
      aiBadge.textContent='AI:'+score.toFixed(2);
      aiBadge.className='ai-score'+(score>.7?' ai-h':score>.4?' ai-m':' ai-l');

      // For ai_only conditions: AI determines alarm
      if(type==='ai_only'){
        if(aiAlarm){
          badge.className='cn-b al';badge.textContent='ALARM';
          row.classList.add('alarm');
        }else{
          badge.className='cn-b ok';badge.textContent='OK';
          row.classList.remove('alarm');
        }
      }
      // For hybrid conditions: alarm if EITHER rule OR AI triggers
      else if(type==='hybrid'){
        const ruleAlarm=badge.classList.contains('al');
        if(!ruleAlarm&&aiAlarm){
          badge.className='cn-b aw';badge.textContent='AI WARN';
          row.classList.add('ai-warn');
        }
      }
    });
  }catch(e){/* silently skip if endpoint not available */}
}

// ═══ SIDEBAR TOGGLE ═══
function toggleSidebar(){
  const sb=document.getElementById('sidebar');
  sb.classList.toggle('collapsed');
  localStorage.setItem('sb_collapsed',sb.classList.contains('collapsed')?'1':'0');
  // Redraw tree lines after transition
  setTimeout(()=>{drawTreeLines();if(typeof drawRuleTreeLines==='function')drawRuleTreeLines();if(activeMod===3&&typeof drawM3TreeLines==='function')drawM3TreeLines()},350);
}
// Restore sidebar state
(function(){
  if(localStorage.getItem('sb_collapsed')==='1'){
    const sb=document.getElementById('sidebar');
    if(sb)sb.classList.add('collapsed');
  }
})();


</script>
</div><!-- /pageMod4 -->

<!-- ═══════════════════════════════════════════════════════════════════
     MODULE 5: Network Problem Root Cause Prediction
     ═══════════════════════════════════════════════════════════════════ -->
<div class="m5-page" id="pageMod5">

<!-- Module 5 Tab Bar -->
<div class="tbs" id="m5TabBar">
  <div class="tb on" onclick="m5stab('main')" data-i18n="m5_tab1">🌐 AI Detection &amp; Network Tree</div>
  <div class="tb" onclick="m5stab('history')" data-i18n="m5_tab2">📈 Historical Graph</div>
  <div class="tb" onclick="m5stab('algos')" data-i18n="m5_tab3">📖 Algorithm Description</div>
  <div class="tb" onclick="m5stab('output')" data-i18n="m5_tab4">📊 Detection Output</div>
</div>

<!-- ═══ TAB 1: AI Detection & Network Topology Tree ═══ -->
<div class="tc on" id="m5tab-main"><div class="pg">

<!-- Module 5 Header -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>🌐</i> <span data-i18n="m5_title">Network Problem Root Cause Prediction — AI Network Topology</span></span>
    <div style="display:flex;align-items:center;gap:10px;font-size:.55em;font-family:'JetBrains Mono';font-weight:600;color:var(--dim)">
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#a78bfa,#818cf8);display:inline-block"></span>Hybrid</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#0ea5e9,#38bdf8);display:inline-block"></span>AI</span>
      <span style="display:flex;align-items:center;gap:3px"><span style="width:8px;height:8px;border-radius:2px;background:linear-gradient(135deg,#f97316,#fb923c);display:inline-block"></span>Rule</span>
    </div>
    <div class="tele-live">
      <div class="led" id="m5Led"></div>
      <span class="tele-st" id="m5St" data-i18n="tele_connecting">Connecting…</span>
    </div>
  </div>
</div>

<!-- MongoDB Connection Status -->
<div class="cd" style="padding:8px 16px;margin-bottom:10px;border-left:3px solid var(--accent)">
  <div style="display:flex;align-items:center;gap:8px;font-size:.68em;font-family:'JetBrains Mono'">
    <span style="color:var(--dim)">MongoDB:</span>
    <span id="m5DbStatus" style="color:var(--dim)">checking…</span>
    <span class="db-detail" id="m5DbInfo">database: module5NetworkProblemPrediction</span>
  </div>
</div>

<!-- Auto-Predict Panel (M3-style) -->
<div class="m3-ap" id="m5ApPanel">
  <div class="m3-ap-grp">
    <label class="tgl" title="Auto-predict every 2 min"><input type="checkbox" id="m5ApToggle" checked onchange="m5ApToggleChanged()"><span class="tgl-sl"></span></label>
    <div style="display:flex;flex-direction:column;gap:1px">
      <span class="m3-ap-lbl">Auto Predict</span>
      <span class="m3-ap-badge idle" id="m5ApBadge">IDLE</span>
    </div>
  </div>
  <div class="m3-ap-sep"></div>
  <div class="m3-ap-grp">
    <span class="m3-ap-lbl">Next</span>
    <span class="m3-ap-cd" id="m5ApCd">OFF</span>
  </div>
  <div class="m3-ap-sep"></div>
  <div class="m3-ap-ts">
    <div class="m3-ap-ts-row"><i>📥</i> Queried: <span class="m3-ap-ts-val" id="m5ApQueryTs">&mdash;</span></div>
    <div class="m3-ap-ts-row"><i>🧠</i> Predicted: <span class="m3-ap-ts-val" id="m5ApPredTs">&mdash;</span></div>
  </div>
  <div class="m3-ap-sep"></div>
  <div class="m3-ap-ts">
    <div class="m3-ap-ts-row"><i>⏱️</i> Latency: <span class="m3-ap-ts-val" id="m5ApLat">&mdash;</span></div>
    <div class="m3-ap-ts-row"><i>📊</i> Result: <span class="m3-ap-ts-val" id="m5ApResult">&mdash;</span></div>
  </div>
</div>

<!-- Model Loading Status (M3-style) -->
<div class="m3-load-panel collapsed" id="m5LoadPanel">
  <div class="m3-load-hdr" onclick="document.getElementById('m5LoadPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>🧠</i> AI Models — Module 5 Network Prediction</div>
    <div class="m3-load-hdr-r">
      <span class="m3-load-count" id="m5ModelCnt">0 / 13</span>
      <span class="m3-load-toggle">▼</span>
    </div>
  </div>
  <div class="m3-load-pbar"><div class="m3-load-pfill" id="m5LoadBar" style="width:0%"></div></div>
  <div class="m3-load-grid" id="m5LoadGrid">
    <div class="m3-load-item" id="m5ldX1"><span class="m3-load-id">X1</span><div class="m3-load-info"><div class="m3-load-name">XGB Router Status</div><div class="m3-load-desc">m5_xgb_router_status.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStX1"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldX2"><span class="m3-load-id">X2</span><div class="m3-load-info"><div class="m3-load-name">XGB Router Net</div><div class="m3-load-desc">m5_xgb_router_net.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStX2"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldX3"><span class="m3-load-id">X3</span><div class="m3-load-info"><div class="m3-load-name">XGB PLC1</div><div class="m3-load-desc">m5_xgb_PLC_network_status1.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStX3"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldX4"><span class="m3-load-id">X4</span><div class="m3-load-info"><div class="m3-load-name">XGB Edgebox</div><div class="m3-load-desc">m5_xgb_edgebox_network_status.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStX4"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldX5"><span class="m3-load-id">X5</span><div class="m3-load-info"><div class="m3-load-name">XGB Pi5</div><div class="m3-load-desc">m5_xgb_pi5_network_status.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStX5"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldX6"><span class="m3-load-id">X6</span><div class="m3-load-info"><div class="m3-load-name">XGB HMI</div><div class="m3-load-desc">m5_xgb_HMI_status.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStX6"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldAE"><span class="m3-load-id">AE</span><div class="m3-load-info"><div class="m3-load-name">Autoencoder</div><div class="m3-load-desc">m5_autoencoder.keras</div></div><span class="m3-load-tp dl">DL</span><div class="m3-load-st" id="m5ldStAE"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldBI"><span class="m3-load-id">BI</span><div class="m3-load-info"><div class="m3-load-name">BiLSTM-Attention</div><div class="m3-load-desc">m5_bilstm.keras</div></div><span class="m3-load-tp dl">DL</span><div class="m3-load-st" id="m5ldStBI"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldMT"><span class="m3-load-id">MT</span><div class="m3-load-info"><div class="m3-load-name">Multi-Task DNN</div><div class="m3-load-desc">m5_multitask.keras</div></div><span class="m3-load-tp dl">DL</span><div class="m3-load-st" id="m5ldStMT"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldIF"><span class="m3-load-id">IF</span><div class="m3-load-info"><div class="m3-load-name">Isolation Forest</div><div class="m3-load-desc">m5_iforest.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStIF"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldLF"><span class="m3-load-id">LF</span><div class="m3-load-info"><div class="m3-load-name">Local Outlier Factor</div><div class="m3-load-desc">m5_lof.pkl</div></div><span class="m3-load-tp ml">ML</span><div class="m3-load-st" id="m5ldStLF"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldSC"><span class="m3-load-id" style="font-size:.5em">SC</span><div class="m3-load-info"><div class="m3-load-name">Feature Scaler</div><div class="m3-load-desc">m5_scaler.pkl</div></div><span class="m3-load-tp" style="background:rgba(100,116,139,.1);color:#64748b">PP</span><div class="m3-load-st" id="m5ldStSC"><div class="m3-load-spin"></div></div></div>
    <div class="m3-load-item" id="m5ldCF"><span class="m3-load-id" style="font-size:.5em">CF</span><div class="m3-load-info"><div class="m3-load-name">Model Config</div><div class="m3-load-desc">m5_config.json</div></div><span class="m3-load-tp" style="background:rgba(100,116,139,.1);color:#64748b">CF</span><div class="m3-load-st" id="m5ldStCF"><div class="m3-load-spin"></div></div></div>
  </div>
</div>

<!-- Root Cause & Severity Display -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
  <div class="cd" style="padding:14px;text-align:center">
    <div style="font-size:.6em;color:var(--dim);margin-bottom:6px;font-weight:600;letter-spacing:1px">ROOT CAUSE</div>
    <div id="m5RootCause" class="m5-rc-badge m5-rc-normal" style="font-size:1em">NORMAL</div>
    <div style="font-size:.55em;color:var(--dim);margin-top:6px;font-family:'JetBrains Mono'" id="m5RcConf">Confidence: —</div>
  </div>
  <div class="cd" style="padding:14px;text-align:center">
    <div style="font-size:.6em;color:var(--dim);margin-bottom:6px;font-weight:600;letter-spacing:1px">SEVERITY</div>
    <canvas id="m5SevGauge" width="180" height="100" style="max-width:180px"></canvas>
    <div style="font-size:.75em;font-weight:700;font-family:'JetBrains Mono'" id="m5SevTxt" style="color:var(--dim)">0.000</div>
    <div style="font-size:.5em;color:var(--dim);margin-top:2px">0 = Normal &nbsp;&nbsp; 1 = Full Outage</div>
  </div>
</div>

<!-- Network Topology Health Tree -->
<div class="cd" style="padding:14px;margin-bottom:14px">
  <div class="ct" style="margin-bottom:10px"><i>🔗</i> <span data-i18n="m5_ht_title">Network Topology — Device Health Tree</span></div>
  <div class="m5-tree-wrap" id="m5TreeCanvas">
    <svg class="m5-tree-svg" id="m5TreeSvg"></svg>
    <div class="m5-tree-layers">
      <!-- Layer 1: Internet -->
      <div class="m5-tree-layer" style="margin-bottom:28px">
        <div class="m5-net-node up" id="m5n-internet">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">🌍</span></div>
          <span class="m5-n-label">Internet</span>
          <span class="m5-n-sub" id="m5n-inet-st">WAN Connected</span>
        </div>
      </div>
      <!-- Layer 2: Router -->
      <div class="m5-tree-layer" style="margin-bottom:28px">
        <div class="m5-net-node up" id="m5n-router">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">📡</span></div>
          <span class="m5-n-label">Router</span>
          <span class="m5-n-sub">Gateway</span>
          <span class="m5-n-sub" id="m5n-router-net" style="color:#34d399">Internet: Connected</span>
        </div>
      </div>
      <!-- Layer 3: Switch -->
      <div class="m5-tree-layer" style="margin-bottom:28px">
        <div class="m5-net-node up" id="m5n-switch">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">🔀</span></div>
          <span class="m5-n-label">Network Switch</span>
          <span class="m5-n-sub">LAN Hub</span>
        </div>
      </div>
      <!-- Layer 4: Devices -->
      <div class="m5-tree-layer" style="gap:12px;max-width:800px">
        <div class="m5-net-node up" id="m5n-plc1">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">🔌</span></div>
          <span class="m5-n-label">PLC1</span>
          <span class="m5-n-sub">192.168.0.8</span>
        </div>
        <div class="m5-net-node up" id="m5n-plc2">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">🔌</span></div>
          <span class="m5-n-label">PLC2</span>
          <span class="m5-n-sub">192.168.0.9</span>
        </div>
        <div class="m5-net-node up" id="m5n-edgebox">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">📦</span></div>
          <span class="m5-n-label">Edgebox</span>
          <span class="m5-n-sub">192.168.0.15</span>
        </div>
        <div class="m5-net-node up" id="m5n-pi5">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">🖥️</span></div>
          <span class="m5-n-label">Pi5</span>
          <span class="m5-n-sub">Data Collect</span>
        </div>
        <div class="m5-net-node up" id="m5n-meter1">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">⚡</span></div>
          <span class="m5-n-label">Meter 1</span>
          <span class="m5-n-sub">Energy</span>
        </div>
        <div class="m5-net-node up" id="m5n-meter2">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">⚡</span></div>
          <span class="m5-n-label">Meter 2</span>
          <span class="m5-n-sub">Energy</span>
        </div>
        <div class="m5-net-node up" id="m5n-hmi">
          <div class="m5-n-top"><span class="m5-led"></span><span class="m5-n-icon">🖥️</span></div>
          <span class="m5-n-label">HMI</span>
          <span class="m5-n-sub">Display</span>
        </div>
      </div>
    </div>
    <!-- Summary bar -->
    <div style="display:flex;justify-content:center;gap:20px;margin-top:18px;font-size:.6em;font-family:'JetBrains Mono';padding:8px 16px;border-radius:8px;background:var(--glass);border:1px solid var(--bdr)">
      <span style="color:#34d399">🟢 Online: <b id="m5OnlineCnt">8</b>/8</span>
      <span style="color:#f87171">🔴 Offline: <b id="m5OfflineCnt">0</b></span>
      <span style="color:var(--dim)">Anomaly Score: <b id="m5AnoScore">0.000</b></span>
    </div>
  </div>
</div>

<!-- Condition Reference Table -->
<div class="m3-load-panel collapsed" id="m5CondPanel">
  <div class="m3-load-hdr" onclick="document.getElementById('m5CondPanel').classList.toggle('collapsed')">
    <div class="m3-load-hdr-l"><i>📋</i> Condition Reference Table — 12 Monitoring Conditions</div>
    <div class="m3-load-hdr-r"><span class="m3-load-toggle">▼</span></div>
  </div>
  <div style="overflow-x:auto;border-radius:8px;border:1px solid var(--bdr)">
    <table class="m5-cond-tbl">
      <thead><tr>
        <th style="width:35px">#</th><th style="width:60px">Type</th><th>Condition</th><th>Device</th><th>Field</th><th>Rule Logic</th><th>AI Model</th>
      </tr></thead>
      <tbody id="m5CondBody"></tbody>
    </table>
  </div>
</div>

</div></div><!-- /m5tab-main -->

<!-- ═══ TAB 2: Historical Graph ═══ -->
<div class="tc" id="m5tab-history"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct"><i>📈</i> <span data-i18n="m5_hist_h">Historical Network Status — Time Series</span></div>
</div>
<div class="cd" style="padding:14px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
    <span style="font-size:.65em;font-weight:600;color:var(--dim)">Time Range:</span>
    <select id="m5HistRange" onchange="m5LoadHistory()" style="font-size:.65em;padding:4px 8px;border-radius:4px;background:var(--glass);border:1px solid var(--bdr);color:var(--txt)">
      <option value="1h">Last 1 Hour</option>
      <option value="6h">Last 6 Hours</option>
      <option value="24h" selected>Last 24 Hours</option>
      <option value="7d">Last 7 Days</option>
      <option value="30d">Last 30 Days</option>
    </select>
    <span style="font-size:.65em;font-weight:600;color:var(--dim);margin-left:12px">Field Group:</span>
    <select id="m5HistGroup" onchange="m5LoadHistory()" style="font-size:.65em;padding:4px 8px;border-radius:4px;background:var(--glass);border:1px solid var(--bdr);color:var(--txt)">
      <option value="devices">Device Status (Online/Offline)</option>
      <option value="router">Router &amp; Internet</option>
      <option value="plc">PLC Network</option>
      <option value="meters">Energy Meters</option>
      <option value="severity">Root Cause &amp; Severity</option>
    </select>
    <button onclick="m5LoadHistory()" style="display:inline-flex;align-items:center;gap:5px;font-size:.6em;padding:5px 14px;border-radius:6px;background:linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.08));border:1px solid rgba(56,189,248,.25);color:#38bdf8;font-weight:700;cursor:pointer;transition:all .3s;letter-spacing:.3px" onmouseover="this.style.background='linear-gradient(135deg,rgba(14,165,233,.2),rgba(56,189,248,.15))';this.style.boxShadow='0 0 12px rgba(56,189,248,.15)'" onmouseout="this.style.background='linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.08))';this.style.boxShadow='none'"><span style="display:inline-block;transition:transform .3s" class="m5-ref-ico">↻</span> Refresh</button>
  </div>
</div>
<div class="cd" style="padding:14px">
  <div id="m5Timeline" style="width:100%;overflow-x:auto"></div>
  <div id="m5HistMsg" style="text-align:center;color:var(--dim);font-size:.7em;padding:40px">Select a range and click Refresh to load data</div>
</div>
</div></div><!-- /m5tab-history -->

<!-- ═══ TAB 3: Algorithm Description ═══ -->
<div class="tc" id="m5tab-algos"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct"><i>📖</i> <span data-i18n="m5_algo_h">Network Problem Detection — Algorithm Description</span></div>
</div>

<div class="cd" style="padding:20px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">🔗</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">Network Topology</h3>
  </div>
  <div style="display:flex;flex-direction:column;align-items:center;gap:0;padding:16px 12px;border-radius:10px;background:var(--glass);border:1px solid var(--bdr)">
    <!-- Internet -->
    <div style="padding:8px 20px;border-radius:8px;background:linear-gradient(135deg,rgba(52,211,153,.1),rgba(52,211,153,.04));border:1.5px solid rgba(52,211,153,.3);text-align:center">
      <div style="font-size:.72em;font-weight:800;color:#34d399">🌍 Internet (WAN)</div>
    </div>
    <div style="width:2px;height:18px;background:linear-gradient(to bottom,#34d399,#38bdf8);opacity:.4"></div>
    <!-- Router -->
    <div style="padding:8px 20px;border-radius:8px;background:linear-gradient(135deg,rgba(56,189,248,.1),rgba(56,189,248,.04));border:1.5px solid rgba(56,189,248,.3);text-align:center">
      <div style="font-size:.72em;font-weight:800;color:#38bdf8">📡 Router (Gateway)</div>
    </div>
    <div style="width:2px;height:18px;background:linear-gradient(to bottom,#38bdf8,#a78bfa);opacity:.4"></div>
    <!-- Switch -->
    <div style="padding:8px 20px;border-radius:8px;background:linear-gradient(135deg,rgba(167,139,250,.1),rgba(167,139,250,.04));border:1.5px solid rgba(167,139,250,.3);text-align:center">
      <div style="font-size:.72em;font-weight:800;color:#a78bfa">🔀 Network Switch (LAN Hub)</div>
    </div>
    <div style="width:2px;height:14px;background:rgba(167,139,250,.3)"></div>
    <div style="width:60%;height:2px;background:linear-gradient(to right,transparent,rgba(167,139,250,.3),rgba(167,139,250,.3),transparent);margin-bottom:6px"></div>
    <!-- Devices -->
    <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:8px;max-width:700px">
      <div style="padding:6px 12px;border-radius:6px;background:rgba(56,189,248,.06);border:1px solid rgba(56,189,248,.2);font-size:.58em;font-family:'JetBrains Mono';text-align:center"><b style="color:#38bdf8">🔌 PLC1</b><br><span style="color:var(--dim)">192.168.0.8</span></div>
      <div style="padding:6px 12px;border-radius:6px;background:rgba(56,189,248,.06);border:1px solid rgba(56,189,248,.2);font-size:.58em;font-family:'JetBrains Mono';text-align:center"><b style="color:#38bdf8">🔌 PLC2</b><br><span style="color:var(--dim)">192.168.0.9</span></div>
      <div style="padding:6px 12px;border-radius:6px;background:rgba(14,165,233,.06);border:1px solid rgba(14,165,233,.2);font-size:.58em;font-family:'JetBrains Mono';text-align:center"><b style="color:#0ea5e9">📦 Edgebox</b><br><span style="color:var(--dim)">192.168.0.15</span></div>
      <div style="padding:6px 12px;border-radius:6px;background:rgba(167,139,250,.06);border:1px solid rgba(167,139,250,.2);font-size:.58em;font-family:'JetBrains Mono';text-align:center"><b style="color:#a78bfa">🖥️ Pi5</b><br><span style="color:var(--dim)">Data Collect</span></div>
      <div style="padding:6px 12px;border-radius:6px;background:rgba(5,150,105,.06);border:1px solid rgba(5,150,105,.2);font-size:.58em;font-family:'JetBrains Mono';text-align:center"><b style="color:#059669">⚡ Meter 1&2</b><br><span style="color:var(--dim)">Energy</span></div>
      <div style="padding:6px 12px;border-radius:6px;background:rgba(236,72,153,.06);border:1px solid rgba(236,72,153,.2);font-size:.58em;font-family:'JetBrains Mono';text-align:center"><b style="color:#ec4899">🖥️ HMI</b><br><span style="color:var(--dim)">Display</span></div>
    </div>
  </div>
</div>

<div class="cd" style="padding:18px;margin-bottom:12px">
  <h3 style="color:var(--h-acc);font-size:.85em;margin:0 0 10px">9 Root Cause Categories</h3>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px;font-size:.62em">
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(52,211,153,.3);background:rgba(52,211,153,.05)"><b style="color:#34d399">NORMAL</b><br><span style="color:var(--dim)">All devices active, internet connected</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(248,113,113,.3);background:rgba(248,113,113,.05)"><b style="color:#f87171">ROUTER_DOWN</b><br><span style="color:var(--dim)">Router hardware failure → cascade offline</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(251,191,36,.3);background:rgba(251,191,36,.05)"><b style="color:#fbbf24">ISP_OUTAGE</b><br><span style="color:var(--dim)">Internet disconnected, LAN works</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(56,189,248,.3);background:rgba(56,189,248,.05)"><b style="color:#38bdf8">PLC_FAULT</b><br><span style="color:var(--dim)">PLC1/PLC2 communication failure</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(14,165,233,.3);background:rgba(14,165,233,.05)"><b style="color:#0ea5e9">EDGEBOX_FAULT</b><br><span style="color:var(--dim)">Edgebox/OCPP gateway failure</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(249,115,22,.3);background:rgba(249,115,22,.05)"><b style="color:#f97316">METER_FAULT</b><br><span style="color:var(--dim)">Energy meter communication loss</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(236,72,153,.3);background:rgba(236,72,153,.05)"><b style="color:#ec4899">HMI_FAULT</b><br><span style="color:var(--dim)">HMI display/communication failure</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(100,116,139,.3);background:rgba(100,116,139,.05)"><b style="color:#94a3b8">MULTI_DEVICE</b><br><span style="color:var(--dim)">Multiple device groups offline (switch issue)</span></div>
    <div style="padding:8px;border-radius:6px;border:1px solid rgba(220,38,38,.3);background:rgba(220,38,38,.05)"><b style="color:#dc2626">FULL_OUTAGE</b><br><span style="color:var(--dim)">All devices down (power or total network collapse)</span></div>
  </div>
</div>

<div class="cd" style="padding:20px;margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">🧠</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">5 AI Model Architectures</h3>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px">
    <!-- XGBoost -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(56,189,248,.2);background:linear-gradient(135deg,rgba(56,189,248,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(56,189,248,.12);color:#38bdf8;font-family:'JetBrains Mono';letter-spacing:.5px">X1–X6</span>
        <span style="font-size:.7em;font-weight:800;color:#38bdf8">XGBoost Per-Device</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">6 individual binary classifiers. Each predicts one device status (Active/Inactive) with device-specific feature importance and SHAP explanations.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">Router</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">PLC1</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">Edgebox</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">Pi5</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(56,189,248,.08);color:#38bdf8;font-family:'JetBrains Mono'">HMI</span>
      </div>
    </div>
    <!-- Autoencoder -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(167,139,250,.2);background:linear-gradient(135deg,rgba(167,139,250,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(167,139,250,.12);color:#a78bfa;font-family:'JetBrains Mono';letter-spacing:.5px">AE</span>
        <span style="font-size:.7em;font-weight:800;color:#a78bfa">Autoencoder</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Trained exclusively on NORMAL data. Reconstruction error detects unseen anomaly patterns. Thresholds at P95, P99, P99.9 percentiles.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(167,139,250,.08);color:#a78bfa;font-family:'JetBrains Mono'">Unsupervised</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(167,139,250,.08);color:#a78bfa;font-family:'JetBrains Mono'">Reconstruction</span>
      </div>
    </div>
    <!-- Multi-Task DNN -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(52,211,153,.2);background:linear-gradient(135deg,rgba(52,211,153,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(52,211,153,.12);color:#34d399;font-family:'JetBrains Mono';letter-spacing:.5px">MT</span>
        <span style="font-size:.7em;font-weight:800;color:#34d399">Multi-Task DNN</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Multi-output Dense network with shared trunk architecture. Predicts all device statuses simultaneously with joint loss optimization.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(52,211,153,.08);color:#34d399;font-family:'JetBrains Mono'">Multi-Output</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(52,211,153,.08);color:#34d399;font-family:'JetBrains Mono'">Shared Trunk</span>
      </div>
    </div>
    <!-- BiLSTM -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(251,191,36,.2);background:linear-gradient(135deg,rgba(251,191,36,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(251,191,36,.12);color:#fbbf24;font-family:'JetBrains Mono';letter-spacing:.5px">BI</span>
        <span style="font-size:.7em;font-weight:800;color:#fbbf24">BiLSTM-Attention</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Bidirectional LSTM with custom Attention layer. Captures temporal device offline sequences with sequence length of 20 time steps.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(251,191,36,.08);color:#fbbf24;font-family:'JetBrains Mono'">Temporal</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(251,191,36,.08);color:#fbbf24;font-family:'JetBrains Mono'">seq_len=20</span>
      </div>
    </div>
    <!-- Isolation Forest + LOF -->
    <div style="padding:14px;border-radius:10px;border:1px solid rgba(248,113,113,.2);background:linear-gradient(135deg,rgba(248,113,113,.06),transparent)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:.5em;font-weight:900;padding:3px 8px;border-radius:4px;background:rgba(248,113,113,.12);color:#f87171;font-family:'JetBrains Mono';letter-spacing:.5px">IF+LF</span>
        <span style="font-size:.7em;font-weight:800;color:#f87171">Isolation Forest + LOF</span>
      </div>
      <div style="font-size:.58em;color:var(--dim);line-height:1.7">Unsupervised anomaly scoring ensemble. IF detects global outliers, LOF detects local density deviations. 50/50 weighted ensemble scoring.</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(248,113,113,.08);color:#f87171;font-family:'JetBrains Mono'">Unsupervised</span>
        <span style="font-size:.45em;padding:2px 6px;border-radius:3px;background:rgba(248,113,113,.08);color:#f87171;font-family:'JetBrains Mono'">Ensemble</span>
      </div>
    </div>
  </div>
</div>

<div class="cd" style="padding:20px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
    <span style="font-size:1.1em">⚙️</span>
    <h3 style="color:var(--h-acc);font-size:.82em;margin:0;font-weight:800;letter-spacing:.5px">Feature Engineering (40+ Features)</h3>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(251,191,36,.2);background:linear-gradient(135deg,rgba(251,191,36,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#fbbf24;margin-bottom:6px">⏰ Time Features</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">hour_sin, hour_cos<br>is_business_hours<br>is_night</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(56,189,248,.2);background:linear-gradient(135deg,rgba(56,189,248,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#38bdf8;margin-bottom:6px">🔌 Device Binary</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">8 device active/inactive<br>encoded as 0/1 binary<br>per-device status flags</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(52,211,153,.2);background:linear-gradient(135deg,rgba(52,211,153,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#34d399;margin-bottom:6px">📊 Aggregates</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">total_down, total_online<br>pct_online, any_down<br>all_down</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(167,139,250,.2);background:linear-gradient(135deg,rgba(167,139,250,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#a78bfa;margin-bottom:6px">🔗 Group Patterns</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">plc_both_down<br>meter_both_down<br>router_cascade</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(236,72,153,.2);background:linear-gradient(135deg,rgba(236,72,153,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#ec4899;margin-bottom:6px">🔢 8-bit Fingerprint</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">device_pattern<br>unique binary encoding<br>of all 8 device states</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(14,165,233,.2);background:linear-gradient(135deg,rgba(14,165,233,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#0ea5e9;margin-bottom:6px">📈 Rolling Windows</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">short (10-sample) sums<br>long (60-sample) sums<br>transition counts</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(248,113,113,.2);background:linear-gradient(135deg,rgba(248,113,113,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#f87171;margin-bottom:6px">⏳ Temporal</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">consecutive offline<br>rate-of-change<br>rolling std</div>
    </div>
    <div style="padding:12px;border-radius:10px;border:1px solid rgba(5,150,105,.2);background:linear-gradient(135deg,rgba(5,150,105,.06),transparent)">
      <div style="font-size:.62em;font-weight:800;color:#059669;margin-bottom:6px">⚡ Energy</div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7;font-family:'JetBrains Mono'">meter readings<br>differential kWh<br>when available</div>
    </div>
  </div>
</div>
</div></div><!-- /m5tab-algos -->

<!-- ═══ TAB 4: Detection Output ═══ -->
<div class="tc" id="m5tab-output"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>📊</i> <span data-i18n="m5_do_h">Detection Output — Network Problem Monitoring</span></span>
    <button onclick="m5RefreshOutput()" style="display:inline-flex;align-items:center;gap:5px;font-size:.6em;padding:5px 14px;border-radius:6px;background:linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.08));border:1px solid rgba(56,189,248,.25);color:#38bdf8;font-weight:700;cursor:pointer;transition:all .3s;letter-spacing:.3px" onmouseover="this.style.background='linear-gradient(135deg,rgba(14,165,233,.2),rgba(56,189,248,.15))';this.style.boxShadow='0 0 12px rgba(56,189,248,.15)'" onmouseout="this.style.background='linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.08))';this.style.boxShadow='none'"><span style="display:inline-block;transition:transform .3s">↻</span> Refresh</button>
  </div>
</div>
<!-- Summary Bar -->
<div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
  <div class="cd" style="flex:1;min-width:120px;padding:10px;text-align:center">
    <div style="font-size:.55em;color:var(--dim);font-weight:600">NORMAL</div>
    <div style="font-size:1.3em;font-weight:700;color:#34d399" id="m5DoOk">0</div>
  </div>
  <div class="cd" style="flex:1;min-width:120px;padding:10px;text-align:center">
    <div style="font-size:.55em;color:var(--dim);font-weight:600">WARNING</div>
    <div style="font-size:1.3em;font-weight:700;color:#fbbf24" id="m5DoWarn">0</div>
  </div>
  <div class="cd" style="flex:1;min-width:120px;padding:10px;text-align:center">
    <div style="font-size:.55em;color:var(--dim);font-weight:600">ALARM</div>
    <div style="font-size:1.3em;font-weight:700;color:#f87171" id="m5DoAlarm">0</div>
  </div>
  <div class="cd" style="flex:1;min-width:120px;padding:10px;text-align:center">
    <div style="font-size:.55em;color:var(--dim);font-weight:600">ROOT CAUSE</div>
    <div style="font-size:.8em;font-weight:700;color:var(--h-acc)" id="m5DoRc">—</div>
  </div>
</div>
<!-- Output Table -->
<div class="cd" style="padding:14px">
  <div style="overflow-x:auto">
    <table class="ref-tbl" style="width:100%;font-size:.58em">
      <thead><tr>
        <th>#</th><th>Type</th><th>Condition</th><th>Device</th><th>Value</th><th>Rule Output</th><th>AI Output</th><th>Status</th>
      </tr></thead>
      <tbody id="m5DoBody">
        <tr><td colspan="8" style="text-align:center;color:var(--dim);padding:30px;font-style:italic">Waiting for telemetry data… Switch to main tab or enable Auto-Predict.</td></tr>
      </tbody>
    </table>
  </div>
  <div style="text-align:right;font-size:.55em;color:var(--dim);margin-top:8px;font-family:'JetBrains Mono'" id="m5DoTs">—</div>
</div>
</div></div><!-- /m5tab-output -->

</div><!-- /pageMod5 -->

<div class="m6-page" id="pageMod6">

<!-- Module 6 Tab Bar -->
<div class="tbs" id="m6TabBar">
  <div class="tb on" onclick="m6stab('main')">⏳ RUL Dashboard</div>
  <div class="tb" onclick="m6stab('detail')">🔍 Component Detail</div>
  <div class="tb" onclick="m6stab('algos')">📖 Algorithm Description</div>
  <div class="tb" onclick="m6stab('output')">📊 Prediction Output</div>
</div>

<!-- ═══ TAB 1: RUL Dashboard ═══ -->
<div class="tc on" id="m6tab-main"><div class="pg">

<!-- Header -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>⏳</i> Remaining Useful Life — Component Health Dashboard</span>
    <div class="m6-legend">
      <span><i style="background:#34d399"></i>&gt;70% Good</span>
      <span><i style="background:#fbbf24"></i>30-70% Watch</span>
      <span><i style="background:#f97316"></i>10-30% Warning</span>
      <span><i style="background:#ef4444"></i>&lt;10% Critical</span>
    </div>
    <div class="tele-live">
      <div class="led" id="m6Led"></div>
      <span class="tele-st" id="m6St">Connecting…</span>
    </div>
  </div>
</div>

<!-- MongoDB Status -->
<div class="cd" style="padding:8px 16px;margin-bottom:10px;border-left:3px solid var(--accent)">
  <div style="display:flex;align-items:center;gap:8px;font-size:.68em;font-family:'JetBrains Mono'">
    <span style="color:var(--dim)">MongoDB:</span>
    <span id="m6DbStatus" style="color:var(--dim)">checking…</span>
    <span class="db-detail" id="m6DbInfo">database: module6DcChargerRulPrediction</span>
  </div>
</div>

<!-- Auto-Predict Panel -->
<div class="m3-ap" id="m6ApPanel">
  <div class="m3-ap-grp">
    <label class="tgl" title="Auto-predict every 2 min"><input type="checkbox" id="m6ApToggle" checked onchange="m6ApToggleChanged()"><span class="tgl-sl"></span></label>
    <div style="display:flex;flex-direction:column;gap:1px">
      <span class="m3-ap-lbl">Auto Predict</span>
      <span class="m3-ap-badge idle" id="m6ApBadge">IDLE</span>
    </div>
  </div>
  <div class="m3-ap-sep"></div>
  <div class="m3-ap-grp">
    <span class="m3-ap-lbl">Next</span>
    <span class="m3-ap-cd" id="m6ApCd">OFF</span>
  </div>
  <div class="m3-ap-sep"></div>
  <div class="m3-ap-ts">
    <div class="m3-ap-ts-row"><i>📥</i> Queried: <span class="m3-ap-ts-val" id="m6ApQueryTs">&mdash;</span></div>
    <div class="m3-ap-ts-row"><i>🧠</i> Predicted: <span class="m3-ap-ts-val" id="m6ApPredTs">&mdash;</span></div>
  </div>
  <div class="m3-ap-sep"></div>
  <div class="m3-ap-ts">
    <div class="m3-ap-ts-row"><i>⏱️</i> Latency: <span class="m3-ap-ts-val" id="m6ApLat">&mdash;</span></div>
    <div class="m3-ap-ts-row"><i>💚</i> System: <span class="m3-ap-ts-val" id="m6ApResult">&mdash;</span></div>
  </div>
</div>

<!-- Model Loading Panel -->

<!-- ═══ System Health Gauge + Summary ═══ -->
<div style="display:grid;grid-template-columns:1fr 2fr;gap:12px;margin-bottom:14px">
  <!-- Left: System Gauge -->
  <div class="cd" style="padding:20px;display:flex;flex-direction:column;align-items:center;justify-content:center">
    <div class="m6-sys-label">SYSTEM HEALTH</div>
    <div class="m6-sys-gauge">
      <svg width="160" height="100" viewBox="0 0 160 100" id="m6SysGaugeSvg">
        <path d="M20,90 A60,60 0 0,1 140,90" fill="none" stroke="rgba(100,116,139,.15)" stroke-width="12" stroke-linecap="round"/>
        <path d="M20,90 A60,60 0 0,1 140,90" fill="none" stroke="#34d399" stroke-width="12" stroke-linecap="round" stroke-dasharray="188.5" stroke-dashoffset="0" id="m6GaugeArc"/>
      </svg>
    </div>
    <div class="m6-sys-val" id="m6SysHealth" style="color:#34d399;margin-top:-10px">—%</div>
    <div class="m6-sys-sub" id="m6SysWeakest">Weakest: —</div>
    <div style="font-size:.5em;color:var(--dim);margin-top:4px">Based on weakest component (Miner's Rule)</div>
  </div>
  <!-- Right: Summary Cards -->
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
    <div class="cd" style="padding:12px;text-align:center">
      <div style="font-size:.5em;color:var(--dim);font-weight:600;letter-spacing:1px">COMPONENTS</div>
      <div style="font-size:1.6em;font-weight:800;font-family:'JetBrains Mono';color:var(--fg)" id="m6TotalComps">32</div>
      <div style="font-size:.5em;color:var(--dim)">Monitored</div>
    </div>
    <div class="cd" style="padding:12px;text-align:center">
      <div style="font-size:.5em;color:var(--dim);font-weight:600;letter-spacing:1px">HEALTHY</div>
      <div style="font-size:1.6em;font-weight:800;font-family:'JetBrains Mono';color:#34d399" id="m6HealthyCnt">—</div>
      <div style="font-size:.5em;color:var(--dim)">&gt; 70% RUL</div>
    </div>
    <div class="cd" style="padding:12px;text-align:center">
      <div style="font-size:.5em;color:var(--dim);font-weight:600;letter-spacing:1px">WATCH</div>
      <div style="font-size:1.6em;font-weight:800;font-family:'JetBrains Mono';color:#fbbf24" id="m6WatchCnt">—</div>
      <div style="font-size:.5em;color:var(--dim)">30-70% RUL</div>
    </div>
    <div class="cd" style="padding:12px;text-align:center">
      <div style="font-size:.5em;color:var(--dim);font-weight:600;letter-spacing:1px">WARNING</div>
      <div style="font-size:1.6em;font-weight:800;font-family:'JetBrains Mono';color:#f97316" id="m6WarnCnt">—</div>
      <div style="font-size:.5em;color:var(--dim)">10-30% RUL</div>
    </div>
    <div class="cd" style="padding:12px;text-align:center">
      <div style="font-size:.5em;color:var(--dim);font-weight:600;letter-spacing:1px">CRITICAL</div>
      <div style="font-size:1.6em;font-weight:800;font-family:'JetBrains Mono';color:#ef4444" id="m6CritCnt">—</div>
      <div style="font-size:.5em;color:var(--dim)">&lt; 10% RUL</div>
    </div>
    <div class="cd" style="padding:12px;text-align:center">
      <div style="font-size:.5em;color:var(--dim);font-weight:600;letter-spacing:1px">AVG HEALTH</div>
      <div style="font-size:1.6em;font-weight:800;font-family:'JetBrains Mono';color:var(--accent)" id="m6AvgHealth">—%</div>
      <div style="font-size:.5em;color:var(--dim)">All components</div>
    </div>
  </div>
</div>

<!-- ═══ Component Category Grid ═══ -->
<div class="cd" style="padding:16px;margin-bottom:14px">
  <div class="ct" style="margin-bottom:12px"><i>📊</i> Component Health by Category (12 Groups)</div>
  <div class="m6-cat-grid" id="m6CatGrid"></div>
</div>

<!-- ═══ Maintenance Priority ═══ -->
<div class="cd" style="padding:16px">
  <div class="ct" style="margin-bottom:12px"><i>🔧</i> Maintenance Priority — Top 5 Components to Watch</div>
  <div class="m6-prio-list" id="m6PrioList">
    <div style="text-align:center;color:var(--dim);font-size:.65em;padding:20px;font-style:italic">Waiting for prediction data…</div>
  </div>
</div>

</div></div><!-- /m6tab-main -->

<!-- ═══ TAB 2: Component Detail ═══ -->
<div class="tc" id="m6tab-detail"><div class="pg">

<!-- Detail Header -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>🔍</i> All 32 Components — Detailed RUL Status</span>
    <div style="display:flex;gap:8px;align-items:center">
      <div class="m6-legend">
        <span><i style="background:#34d399"></i>Good</span>
        <span><i style="background:#fbbf24"></i>Watch</span>
        <span><i style="background:#f97316"></i>Warning</span>
        <span><i style="background:#ef4444"></i>Critical</span>
      </div>
      <button onclick="m6RunPredict()" style="padding:4px 12px;border-radius:6px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer;font-size:.55em;font-family:'JetBrains Mono';font-weight:600">↻ Refresh</button>
    </div>
  </div>
</div>

<!-- Summary Strip -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px">
  <div class="cd" style="padding:10px;text-align:center;border-top:3px solid #34d399">
    <div style="font-size:1.4em;font-weight:800;font-family:'JetBrains Mono';color:#34d399" id="m6dGood">—</div>
    <div style="font-size:.5em;color:var(--dim);font-weight:600">&gt;70% GOOD</div>
  </div>
  <div class="cd" style="padding:10px;text-align:center;border-top:3px solid #fbbf24">
    <div style="font-size:1.4em;font-weight:800;font-family:'JetBrains Mono';color:#fbbf24" id="m6dWatch">—</div>
    <div style="font-size:.5em;color:var(--dim);font-weight:600">30-70% WATCH</div>
  </div>
  <div class="cd" style="padding:10px;text-align:center;border-top:3px solid #f97316">
    <div style="font-size:1.4em;font-weight:800;font-family:'JetBrains Mono';color:#f97316" id="m6dWarn">—</div>
    <div style="font-size:.5em;color:var(--dim);font-weight:600">10-30% WARNING</div>
  </div>
  <div class="cd" style="padding:10px;text-align:center;border-top:3px solid #ef4444">
    <div style="font-size:1.4em;font-weight:800;font-family:'JetBrains Mono';color:#ef4444" id="m6dCrit">—</div>
    <div style="font-size:.5em;color:var(--dim);font-weight:600">&lt;10% CRITICAL</div>
  </div>
</div>

<!-- Component Cards Grid -->
<div id="m6DetailList" style="display:flex;flex-direction:column;gap:12px">
  <div style="text-align:center;color:var(--dim);font-size:.65em;padding:40px;font-style:italic">Enable Auto-Predict or click Refresh to load component data…</div>
</div>

</div></div><!-- /m6tab-detail -->

<!-- ═══ TAB 3: Algorithm Description ═══ -->
<div class="tc" id="m6tab-algos"><div class="pg">

<!-- Overview -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="margin-bottom:10px"><i>📖</i> Module 6 — Physics-Informed AI for RUL Prediction</div>
  <p style="font-size:.62em;color:var(--dim);line-height:1.8;margin:0">Module 6 uses a <b style="color:var(--fg)">Physics-Informed AI</b> approach that combines classical reliability engineering formulas (Arrhenius thermal aging &amp; Miner's cumulative damage rule) with modern ML/DL ensembles to predict the Remaining Useful Life of <b style="color:var(--fg)">32 internal components</b> of the 150kW DC charger — all without requiring failure labels.</p>
</div>

<!-- Pipeline Flow -->
<div class="cd" style="padding:16px;margin-bottom:14px">
  <div class="ct" style="margin-bottom:12px"><i>🔄</i> Prediction Pipeline</div>
  <div style="display:flex;align-items:center;gap:0;overflow-x:auto;padding:8px 0">
    <div style="flex:0 0 auto;padding:8px 14px;border-radius:8px;background:linear-gradient(135deg,rgba(14,165,233,.12),rgba(56,189,248,.06));border:1px solid rgba(56,189,248,.25);text-align:center">
      <div style="font-size:.7em;font-weight:700;color:#38bdf8">📥 MongoDB</div>
      <div style="font-size:.45em;color:var(--dim);margin-top:2px">Latest telemetry</div>
    </div>
    <div style="flex:0 0 30px;text-align:center;color:var(--dim);font-family:'JetBrains Mono'">→</div>
    <div style="flex:0 0 auto;padding:8px 14px;border-radius:8px;background:linear-gradient(135deg,rgba(251,146,60,.12),rgba(251,146,60,.06));border:1px solid rgba(251,146,60,.25);text-align:center">
      <div style="font-size:.7em;font-weight:700;color:#fb923c">⚙️ Feature Eng</div>
      <div style="font-size:.45em;color:var(--dim);margin-top:2px">200+ features</div>
    </div>
    <div style="flex:0 0 30px;text-align:center;color:var(--dim);font-family:'JetBrains Mono'">→</div>
    <div style="flex:0 0 auto;padding:8px 14px;border-radius:8px;background:linear-gradient(135deg,rgba(168,85,247,.12),rgba(168,85,247,.06));border:1px solid rgba(168,85,247,.25);text-align:center">
      <div style="font-size:.7em;font-weight:700;color:#a855f7">🌡️ Physics RUL</div>
      <div style="font-size:.45em;color:var(--dim);margin-top:2px">Arrhenius + Miner's</div>
    </div>
    <div style="flex:0 0 30px;text-align:center;color:var(--dim);font-family:'JetBrains Mono'">→</div>
    <div style="flex:0 0 auto;padding:8px 14px;border-radius:8px;background:linear-gradient(135deg,rgba(52,211,153,.12),rgba(52,211,153,.06));border:1px solid rgba(52,211,153,.25);text-align:center">
      <div style="font-size:.7em;font-weight:700;color:#34d399">🧠 AI Ensemble</div>
      <div style="font-size:.45em;color:var(--dim);margin-top:2px">XGB + DNN + LSTM + AE</div>
    </div>
    <div style="flex:0 0 30px;text-align:center;color:var(--dim);font-family:'JetBrains Mono'">→</div>
    <div style="flex:0 0 auto;padding:8px 14px;border-radius:8px;background:linear-gradient(135deg,rgba(244,63,94,.12),rgba(244,63,94,.06));border:1px solid rgba(244,63,94,.25);text-align:center">
      <div style="font-size:.7em;font-weight:700;color:#f43f5e">📊 RUL %</div>
      <div style="font-size:.45em;color:var(--dim);margin-top:2px">32 components</div>
    </div>
  </div>
</div>

<!-- Physics Models -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
  <!-- Arrhenius -->
  <div class="cd" style="padding:0;overflow:hidden">
    <div style="padding:12px 16px;background:linear-gradient(135deg,rgba(251,146,60,.1),rgba(251,146,60,.03));border-bottom:1px solid var(--bdr)">
      <div style="display:flex;align-items:center;gap:8px">
        <div style="width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,#fb923c,#f97316);display:flex;align-items:center;justify-content:center;font-size:1em">🌡️</div>
        <div>
          <div style="font-weight:700;font-size:.72em">Arrhenius Thermal Aging Model</div>
          <div style="font-size:.48em;color:var(--dim)">24 time-based components (fans, modules, electronics)</div>
        </div>
      </div>
    </div>
    <div style="padding:14px 16px">
      <div style="background:rgba(0,0,0,.15);border-radius:6px;padding:10px 12px;margin-bottom:10px;font-family:'JetBrains Mono';font-size:.52em;color:#fbbf24;line-height:2">
        AF = exp[(Ea/k) × (1/T_ref − 1/T_actual)]<br>
        L_eff = (service_life / 3600) × AF<br>
        <span style="color:#34d399;font-weight:700">RUL% = 100 × (1 − L_eff / L_rated)</span>
      </div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7">
        <b style="color:var(--fg)">Parameters:</b> Ea = 0.7 eV, k = 8.617×10⁻⁵ eV/K, T_ref = 313K (40°C)<br>
        <b style="color:var(--fg)">Acceleration:</b> 50°C → 2.5×, 60°C → 6×, 70°C → 13×, 75°C → 20×<br>
        <b style="color:var(--fg)">Data Unit:</b> service_life in seconds (auto-verified)
      </div>
    </div>
  </div>
  <!-- Miner's Rule -->
  <div class="cd" style="padding:0;overflow:hidden">
    <div style="padding:12px 16px;background:linear-gradient(135deg,rgba(56,189,248,.1),rgba(56,189,248,.03));border-bottom:1px solid var(--bdr)">
      <div style="display:flex;align-items:center;gap:8px">
        <div style="width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,#38bdf8,#0ea5e9);display:flex;align-items:center;justify-content:center;font-size:1em">🔄</div>
        <div>
          <div style="font-weight:700;font-size:.72em">Miner's Cumulative Damage Rule</div>
          <div style="font-size:.48em;color:var(--dim)">8 cycle-based components (DC &amp; AC contactors)</div>
        </div>
      </div>
    </div>
    <div style="padding:14px 16px">
      <div style="background:rgba(0,0,0,.15);border-radius:6px;padding:10px 12px;margin-bottom:10px;font-family:'JetBrains Mono';font-size:.52em;color:#38bdf8;line-height:2">
        D = N_actual / N_rated<br>
        <span style="color:#34d399;font-weight:700">RUL% = 100 × (1 − D)</span>
      </div>
      <div style="font-size:.52em;color:var(--dim);line-height:1.7">
        <b style="color:var(--fg)">DC Contactors (×6):</b> rated 100,000 cycles<br>
        <b style="color:var(--fg)">AC Contactors (×2):</b> rated 300,000 cycles<br>
        <b style="color:var(--fg)">Tracking:</b> frequency counter per contactor
      </div>
    </div>
  </div>
</div>

<!-- AI Models Grid -->
<div class="cd" style="padding:16px;margin-bottom:14px">
  <div class="ct" style="margin-bottom:12px"><i>🧠</i> AI / ML Model Architecture (4 Models)</div>
  <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px">
    <!-- XGBoost -->
    <div style="border-radius:10px;padding:14px;background:linear-gradient(135deg,rgba(52,211,153,.06),rgba(52,211,153,.02));border:1px solid rgba(52,211,153,.15)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <div style="width:30px;height:30px;border-radius:6px;background:linear-gradient(135deg,#34d399,#10b981);display:flex;align-items:center;justify-content:center;font-size:.8em">🌲</div>
        <div><div style="font-weight:700;font-size:.68em">XGBoost ×32</div>
        <span style="font-size:.42em;padding:1px 6px;border-radius:4px;background:rgba(52,211,153,.15);color:#34d399;font-weight:600">ML — Per Component</span></div>
      </div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.7">Individual RUL% regression model per component. 200 trees, max_depth=6, learning_rate=0.05. Trained on physics-informed labels as ground truth.</div>
    </div>
    <!-- Multi-Task DNN -->
    <div style="border-radius:10px;padding:14px;background:linear-gradient(135deg,rgba(168,85,247,.06),rgba(168,85,247,.02));border:1px solid rgba(168,85,247,.15)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <div style="width:30px;height:30px;border-radius:6px;background:linear-gradient(135deg,#a855f7,#8b5cf6);display:flex;align-items:center;justify-content:center;font-size:.8em">🧠</div>
        <div><div style="font-weight:700;font-size:.68em">Multi-Task DNN</div>
        <span style="font-size:.42em;padding:1px 6px;border-radius:4px;background:rgba(168,85,247,.15);color:#a855f7;font-weight:600">DL — Joint Prediction</span></div>
      </div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.7">Shared trunk (512→256→128 + BatchNorm + Dropout) with 32 per-component output heads. Captures inter-component correlations and shared degradation patterns.</div>
    </div>
    <!-- BiLSTM -->
    <div style="border-radius:10px;padding:14px;background:linear-gradient(135deg,rgba(14,165,233,.06),rgba(14,165,233,.02));border:1px solid rgba(14,165,233,.15)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <div style="width:30px;height:30px;border-radius:6px;background:linear-gradient(135deg,#0ea5e9,#38bdf8);display:flex;align-items:center;justify-content:center;font-size:.8em">📈</div>
        <div><div style="font-weight:700;font-size:.68em">BiLSTM-Attention</div>
        <span style="font-size:.42em;padding:1px 6px;border-radius:4px;background:rgba(14,165,233,.15);color:#0ea5e9;font-weight:600">DL — Temporal Forecast</span></div>
      </div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.7">Bidirectional LSTM (128+64 units) with multi-head attention layer. Captures temporal degradation trends over sequence length of 30 timesteps for predictive forecasting.</div>
    </div>
    <!-- Autoencoder -->
    <div style="border-radius:10px;padding:14px;background:linear-gradient(135deg,rgba(244,63,94,.06),rgba(244,63,94,.02));border:1px solid rgba(244,63,94,.15)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <div style="width:30px;height:30px;border-radius:6px;background:linear-gradient(135deg,#f43f5e,#e11d48);display:flex;align-items:center;justify-content:center;font-size:.8em">🔬</div>
        <div><div style="font-weight:700;font-size:.68em">Autoencoder</div>
        <span style="font-size:.42em;padding:1px 6px;border-radius:4px;background:rgba(244,63,94,.15);color:#f43f5e;font-weight:600">DL — Anomaly Detection</span></div>
      </div>
      <div style="font-size:.5em;color:var(--dim);line-height:1.7">Trained exclusively on healthy data (health &gt;90%). Detects abnormal aging patterns via reconstruction error thresholds at P95, P99, and P99.9 percentiles.</div>
    </div>
  </div>
</div>

<!-- Component Specifications -->
<div class="cd" style="padding:16px">
  <div class="ct" style="margin-bottom:12px"><i>📋</i> Component Rated Lifespan Reference</div>
  <div style="overflow-x:auto;border-radius:8px;border:1px solid var(--bdr)">
    <table class="m5-cond-tbl">
      <thead><tr><th>Category</th><th>Components</th><th>Method</th><th>Rated Life</th><th>Unit</th></tr></thead>
      <tbody>
        <tr><td>⚡ DC Contactors</td><td>×6</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(56,189,248,.12);color:#38bdf8;font-weight:600;font-size:.85em">Cycle</span></td><td>100,000</td><td>cycles</td></tr>
        <tr><td>🔌 AC Contactors</td><td>×2</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(56,189,248,.12);color:#38bdf8;font-weight:600;font-size:.85em">Cycle</span></td><td>300,000</td><td>cycles</td></tr>
        <tr><td>🔋 Power Modules</td><td>×5</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>90,000</td><td>hours</td></tr>
        <tr><td>🌀 DC Fans</td><td>×8</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>70,000</td><td>hours</td></tr>
        <tr><td>📡 Router</td><td>×1</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>100,000</td><td>hours</td></tr>
        <tr><td>🖥️ Raspberry Pi5</td><td>×1</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>80,000</td><td>hours</td></tr>
        <tr><td>🔌 PLCs</td><td>×2</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>200,000</td><td>hours</td></tr>
        <tr><td>⚡ Energy Meters</td><td>×2</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>160,000</td><td>hours</td></tr>
        <tr><td>📦 Edgebox</td><td>×1</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>100,000</td><td>hours</td></tr>
        <tr><td>🔋 Power Supply</td><td>×1</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>120,000</td><td>hours</td></tr>
        <tr><td>🛡️ Insulation Monitors</td><td>×2</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>160,000</td><td>hours</td></tr>
        <tr><td>⚡ Switching PSU</td><td>×1</td><td><span style="padding:1px 6px;border-radius:4px;background:rgba(251,146,60,.12);color:#fb923c;font-weight:600;font-size:.85em">Arrhenius</span></td><td>100,000</td><td>hours</td></tr>
      </tbody>
    </table>
  </div>
</div>

</div></div><!-- /m6tab-algos -->

<!-- ═══ TAB 4: Detection Output ═══ -->
<div class="tc" id="m6tab-output"><div class="pg">

<!-- Output Header -->
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <span><i>📊</i> RUL Prediction Log</span>
    <div style="display:flex;gap:8px;align-items:center">
      <span style="font-size:.5em;color:var(--dim);font-family:'JetBrains Mono'" id="m6DoTs">—</span>
      <button onclick="m6DoResults=[];m6RenderDoTable()" style="padding:4px 10px;border-radius:6px;border:1px solid rgba(239,68,68,.3);background:transparent;color:#f87171;cursor:pointer;font-size:.5em;font-family:'JetBrains Mono';font-weight:600">✕ Clear</button>
      <button onclick="m6RunPredict()" style="padding:4px 12px;border-radius:6px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer;font-size:.55em;font-family:'JetBrains Mono';font-weight:600">↻ Run Now</button>
    </div>
  </div>
</div>

<!-- Latest Result Card -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px">
  <div class="cd" style="padding:10px;text-align:center">
    <div style="font-size:.48em;color:var(--dim);font-weight:600;letter-spacing:1px">LATEST HEALTH</div>
    <div style="font-size:1.4em;font-weight:800;font-family:'JetBrains Mono'" id="m6oLatestHealth">—</div>
  </div>
  <div class="cd" style="padding:10px;text-align:center">
    <div style="font-size:.48em;color:var(--dim);font-weight:600;letter-spacing:1px">WEAKEST</div>
    <div style="font-size:.65em;font-weight:700;font-family:'JetBrains Mono';margin-top:6px" id="m6oWeakest">—</div>
  </div>
  <div class="cd" style="padding:10px;text-align:center">
    <div style="font-size:.48em;color:var(--dim);font-weight:600;letter-spacing:1px">PREDICTIONS</div>
    <div style="font-size:1.4em;font-weight:800;font-family:'JetBrains Mono';color:var(--accent)" id="m6oCount">0</div>
  </div>
  <div class="cd" style="padding:10px;text-align:center">
    <div style="font-size:.48em;color:var(--dim);font-weight:600;letter-spacing:1px">AVG LATENCY</div>
    <div style="font-size:1.4em;font-weight:800;font-family:'JetBrains Mono';color:var(--dim)" id="m6oLatency">—</div>
  </div>
</div>

<!-- Log Table -->
<div class="cd" style="padding:16px">
  <div style="overflow-x:auto;border-radius:8px;border:1px solid var(--bdr)">
    <table class="m5-cond-tbl">
      <thead><tr>
        <th style="width:35px">#</th>
        <th>Timestamp</th>
        <th>System Health</th>
        <th>Weakest Component</th>
        <th>Avg Health</th>
        <th style="text-align:center">🟢</th>
        <th style="text-align:center">🟡</th>
        <th style="text-align:center">🟠</th>
        <th style="text-align:center">🔴</th>
      </tr></thead>
      <tbody id="m6OutBody"><tr><td colspan="9" style="text-align:center;color:var(--dim);padding:40px;font-style:italic">Enable Auto-Predict or click "Run Now" to generate predictions…</td></tr></tbody>
    </table>
  </div>
</div>

</div></div><!-- /m6tab-output -->

</div><!-- /pageMod6 -->

<!-- MODULE 7: EV-PLCC State Monitoring -->
<div class="m6-page" id="pageMod7">

<div class="tbs" id="m7TabBar">
  <div class="tb on" onclick="m7stab('main')" data-i18n="m7_tab1">State Monitor</div>
  <div class="tb" onclick="m7stab('timeline')" data-i18n="m7_tab2">Timeline</div>
  <div class="tb" onclick="m7stab('predict')" data-i18n="m7_tab3">Failure Prediction</div>
  <div class="tb" onclick="m7stab('algos')" data-i18n="m7_tab4">Algorithm Description</div>
</div>

<!-- TAB 1: State Monitor -->
<div class="tc on" id="m7tab-main"><div class="pg">

<div style="border-radius:16px;padding:16px 24px;margin-bottom:16px;background:linear-gradient(135deg,var(--card),color-mix(in srgb,var(--accent) 6%,var(--card)));border:1px solid var(--brd);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
  <div style="display:flex;align-items:center;gap:12px">
    <div style="width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,#059669,#0891b2);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.2em">&#9889;</div>
    <div>
      <div style="font-weight:700;font-size:.88em" data-i18n="m7_title">EV-PLCC State Monitoring</div>
      <div style="font-size:.66em;color:var(--dim);margin-top:2px">ISO 15118 &#8226; IEC 61851-1 &#8226; DC Fast Charging Protocol Analysis</div>
    </div>
  </div>
  <div class="m7-sb of" id="m7SrcBadge"><div class="led" id="m7Led"></div> <span id="m7St">Connecting&#8230;</span></div>
</div>

<div style="border-radius:12px;padding:10px 16px;margin-bottom:12px;background:var(--card);border:1px solid var(--brd);display:flex;align-items:center;gap:8px;font-size:.68em;font-family:'JetBrains Mono',monospace">
  <span style="color:var(--dim)">&#128451;</span>
  <span id="m7DbStatus" style="color:var(--dim)">checking&#8230;</span>
  <span style="opacity:.3">|</span>
  <span class="db-detail" id="m7DbInfo" style="color:var(--dim)">module7ChargerPowerIssue</span>
</div>


<div class="m7-hero">
  <div class="m7-sc icp">
    <div class="m7-ch"><div class="m7i">&#9889;</div> <span data-i18n="m7_icp_h">ICPState &#8212; Control Pilot</span></div>
    <div class="m7-gr">
      <div class="m7-rw">
        <svg viewBox="0 0 88 88"><circle class="rbg" cx="44" cy="44" r="38"/><circle class="rfg" id="m7IcpRing" cx="44" cy="44" r="38" stroke="#6b7280" stroke-dasharray="238.76" stroke-dashoffset="238.76"/></svg>
        <div class="m7-rl" id="m7IcpGauge">--<small>ICP</small></div>
      </div>
      <div class="m7-si"><h3 id="m7IcpName">---</h3><p id="m7IcpDesc">Waiting for data&#8230;</p></div>
    </div>
    <div class="m7-sg" id="m7IcpStates"></div>
  </div>
  <div class="m7-sc usl">
    <div class="m7-ch"><div class="m7i">&#128225;</div> <span data-i18n="m7_uslink_h">UslinkState &#8212; Communication Protocol</span></div>
    <div class="m7-gr">
      <div class="m7-rw">
        <svg viewBox="0 0 88 88"><circle class="rbg" cx="44" cy="44" r="38"/><circle class="rfg" id="m7UslRing" cx="44" cy="44" r="38" stroke="#6b7280" stroke-dasharray="238.76" stroke-dashoffset="238.76"/></svg>
        <div class="m7-rl" id="m7UslGauge">--<small>USL</small></div>
      </div>
      <div class="m7-si"><h3 id="m7UslName">---</h3><p id="m7UslDesc">Waiting for data&#8230;</p></div>
    </div>
    <div class="m7-sg" id="m7UslStates"></div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
  <div class="m7-tc">
    <div class="m7-th"><h4><div class="m7-tp"></div> Live Telemetry</h4></div>
    <div class="m7-tg" id="m7Telemetry"><span style="color:var(--dim);font-size:.72em;grid-column:1/-1">Waiting for data&#8230;</span></div>
  </div>
  <div>
    <div id="m7Warnings" style="display:none"></div>
    <div class="m7-tc">
      <div class="m7-th"><h4>&#128268; Connector Status</h4></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div style="text-align:center;padding:12px;border-radius:10px;border:1px solid var(--brd)">
          <div style="font-size:.62em;color:var(--dim);font-weight:600;margin-bottom:4px">CONNECTOR 1</div>
          <div style="font-size:1.1em;font-weight:800;font-family:'JetBrains Mono',monospace" id="m7Conn1St">--</div>
        </div>
        <div style="text-align:center;padding:12px;border-radius:10px;border:1px solid var(--brd)">
          <div style="font-size:.62em;color:var(--dim);font-weight:600;margin-bottom:4px">CONNECTOR 2</div>
          <div style="font-size:1.1em;font-weight:800;font-family:'JetBrains Mono',monospace" id="m7Conn2St">--</div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="m7-sqc">
  <h4>&#128260; V2G Communication Sequence &#8212; ISO 15118 DC Charging Flow</h4>
  <div class="m7-sf" id="m7SeqFlow"></div>
</div>

<div class="m7-ab" id="m7ApPanel">
  <div style="display:flex;align-items:center;gap:8px">
    <label class="tgl" title="Auto-predict every 2 min"><input type="checkbox" id="m7ApToggle" checked onchange="m7ApToggleChanged()"><span class="tgl-sl"></span></label>
    <div><span class="al">Auto Predict</span><br><span class="m3-ap-badge idle" id="m7ApBadge">IDLE</span></div>
  </div>
  <div class="sep"></div>
  <div><span class="al">Next</span><br><span class="av" id="m7ApCd">OFF</span></div>
  <div class="sep"></div>
  <div style="font-size:.62em;color:var(--dim);line-height:1.8">&#128229; Queried: <span class="av" id="m7ApQueryTs">&#8212;</span><br>&#129504; Predicted: <span class="av" id="m7ApPredTs">&#8212;</span></div>
  <div class="sep"></div>
  <div style="font-size:.62em;color:var(--dim);line-height:1.8">&#9201;&#65039; Latency: <span class="av" id="m7ApLat">&#8212;</span><br>&#128154; Result: <span class="av" id="m7ApResult">&#8212;</span></div>
</div>

<div style="margin-bottom:16px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:10px">&#129514; Anomaly Detection Results</div>
  <div class="m7-rg" id="m7ResultsGrid"><div style="color:var(--dim);font-size:.75em;grid-column:1/-1">Run prediction to see results&#8230;</div></div>
</div>

</div></div>

<!-- TAB 2: Timeline -->
<div class="tc" id="m7tab-timeline"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct"><i>&#128202;</i> <span data-i18n="m7_timeline_h">State Transition Timeline</span></div>
</div>

<div class="cd" style="padding:16px;margin-bottom:14px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#9889; ICPState Transitions</div>
  <div style="font-size:.68em;color:var(--dim);margin-bottom:8px">Control Pilot state changes over time (most recent 50 transitions)</div>
  <div id="m7IcpTimeline" style="width:100%;overflow-x:auto">
    <canvas id="m7IcpCanvas" width="900" height="120" style="width:100%;border:1px solid var(--brd);border-radius:8px"></canvas>
  </div>
  <div id="m7IcpTimelineLegend" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;font-size:.62em"></div>
</div>

<div class="cd" style="padding:16px;margin-bottom:14px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128225; UslinkState Transitions</div>
  <div style="font-size:.68em;color:var(--dim);margin-bottom:8px">Communication protocol state changes over time (most recent 50 transitions)</div>
  <div id="m7UslTimeline" style="width:100%;overflow-x:auto">
    <canvas id="m7UslCanvas" width="900" height="160" style="width:100%;border:1px solid var(--brd);border-radius:8px"></canvas>
  </div>
  <div id="m7UslTimelineLegend" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;font-size:.62em"></div>
</div>

<div class="cd" style="padding:16px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:10px">&#128260; DC Charging Sequence Diagram (ISO 15118)</div>
  <div style="overflow-x:auto">
    <div id="m7SeqDiagram" style="min-width:700px;font-size:.7em;font-family:'JetBrains Mono'">
      <div style="display:grid;grid-template-columns:120px 1fr 120px;gap:0;text-align:center">
        <div style="font-weight:800;padding:8px;background:var(--card);border-radius:8px 0 0 0">EVCC (EV)</div>
        <div style="font-weight:800;padding:8px;background:var(--card)">&#8596; Messages</div>
        <div style="font-weight:800;padding:8px;background:var(--card);border-radius:0 8px 0 0">SECC (EVSE)</div>
      </div>
      <div id="m7SeqRows" style="border:1px solid var(--brd);border-top:none;border-radius:0 0 8px 8px;overflow:hidden"></div>
    </div>
  </div>
</div>

</div></div>

<!-- TAB 3: Failure Prediction -->
<div class="tc" id="m7tab-predict"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct"><i>&#129504;</i> <span data-i18n="m7_predict_h">Failure Prediction &amp; Root Cause Analysis</span></div>
</div>

<div class="cd" style="padding:16px;margin-bottom:14px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#127919; Ensemble Prediction Summary</div>
  <div id="m7EnsembleSummary" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px">
    <div style="color:var(--dim);font-size:.75em">Run prediction from State Monitor tab to see results&#8230;</div>
  </div>
</div>

<div class="cd" style="padding:16px;margin-bottom:14px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128269; Root Cause Analysis</div>
  <div id="m7RootCause" style="font-size:.78em;line-height:1.6;color:var(--dim)">No analysis available yet. Enable Auto Predict to start monitoring.</div>
</div>

<div class="cd" style="padding:16px;margin-bottom:14px">
  <div style="font-weight:700;font-size:.82em;margin-bottom:8px">&#128202; Feature Importance (XGBoost)</div>
  <div id="m7FeatureImportance" style="width:100%;overflow-x:auto">
    <canvas id="m7FeatCanvas" width="700" height="250" style="width:100%;border:1px solid var(--brd);border-radius:8px"></canvas>
  </div>
</div>

</div></div>

<!-- TAB 4: Algorithm Description -->
<div class="tc" id="m7tab-algos"><div class="pg">
<div class="cd cd-cy" style="margin-bottom:14px">
  <div class="ct"><i>&#128214;</i> <span data-i18n="m7_algo_h">Charger Failure Analysis &#8212; Algorithm Description</span></div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:14px;margin-bottom:14px">

  <div class="cd" style="padding:0;overflow:hidden">
    <div style="background:linear-gradient(135deg,#059669,#10b981);padding:14px 16px;color:#fff">
      <div style="font-weight:800;font-size:.92em">&#127794; Isolation Forest</div>
      <div style="font-size:.68em;opacity:.85;margin-top:2px">Unsupervised Anomaly Detection</div>
    </div>
    <div style="padding:14px 16px;font-size:.75em;line-height:1.6">
      <p>Detects anomalies by isolating observations in a random forest structure. Anomalous data points require fewer splits to isolate, producing lower anomaly scores.</p>
      <p style="margin-top:8px"><b>Key Params:</b> n_estimators, contamination, max_features</p>
      <p><b>Output:</b> Anomaly score (-1 = anomaly, 1 = normal)</p>
    </div>
  </div>

  <div class="cd" style="padding:0;overflow:hidden">
    <div style="background:linear-gradient(135deg,#7c3aed,#a78bfa);padding:14px 16px;color:#fff">
      <div style="font-weight:800;font-size:.92em">&#129504; Autoencoder</div>
      <div style="font-size:.68em;opacity:.85;margin-top:2px">Deep Learning Reconstruction Error</div>
    </div>
    <div style="padding:14px 16px;font-size:.75em;line-height:1.6">
      <p>Neural network trained to reconstruct normal charging patterns. High reconstruction error indicates deviation from normal behavior, signaling potential faults.</p>
      <p style="margin-top:8px"><b>Architecture:</b> Encoder &#8594; Bottleneck &#8594; Decoder</p>
      <p><b>Threshold:</b> Dynamic based on training MSE distribution</p>
    </div>
  </div>

  <div class="cd" style="padding:0;overflow:hidden">
    <div style="background:linear-gradient(135deg,#d97706,#fbbf24);padding:14px 16px;color:#fff">
      <div style="font-weight:800;font-size:.92em">&#127919; XGBoost Classifier</div>
      <div style="font-size:.68em;opacity:.85;margin-top:2px">Gradient Boosted Decision Trees</div>
    </div>
    <div style="padding:14px 16px;font-size:.75em;line-height:1.6">
      <p>Supervised model trained on labeled charging failure data. Classifies power delivery issues by analyzing state transitions, voltage/current patterns, and communication protocol states.</p>
      <p style="margin-top:8px"><b>Features:</b> ICPState, UslinkState, voltage, current, SOC, temperatures</p>
      <p><b>Output:</b> Failure probability + feature importance</p>
    </div>
  </div>

  <div class="cd" style="padding:0;overflow:hidden">
    <div style="background:linear-gradient(135deg,#dc2626,#f87171);padding:14px 16px;color:#fff">
      <div style="font-weight:800;font-size:.92em">&#9881;&#65039; Rule Engine</div>
      <div style="font-size:.68em;opacity:.85;margin-top:2px">Expert Knowledge-Based Rules</div>
    </div>
    <div style="padding:14px 16px;font-size:.75em;line-height:1.6">
      <p>Domain-specific rules based on ISO 15118 protocol specifications. Checks for protocol violations, timeout errors, and abnormal state transitions in the V2G communication sequence.</p>
      <p style="margin-top:8px"><b>Rules:</b> State sequence validation, timing checks, CP signal verification</p>
      <p><b>Source:</b> ISO 15118-2:2014, IEC 61851-1</p>
    </div>
  </div>

  <div class="cd" style="padding:0;overflow:hidden">
    <div style="background:linear-gradient(135deg,#1d4ed8,#60a5fa);padding:14px 16px;color:#fff">
      <div style="font-weight:800;font-size:.92em">&#129309; Ensemble Method</div>
      <div style="font-size:.68em;opacity:.85;margin-top:2px">Combined Multi-Model Decision</div>
    </div>
    <div style="padding:14px 16px;font-size:.75em;line-height:1.6">
      <p>Combines predictions from Isolation Forest, Autoencoder, XGBoost, and Rule Engine using weighted voting. Achieves higher accuracy and robustness than individual models.</p>
      <p style="margin-top:8px"><b>Strategy:</b> Weighted majority voting with confidence calibration</p>
      <p><b>Weights:</b> Configured in m7_ensemble_config.json</p>
    </div>
  </div>

  <div class="cd" style="padding:0;overflow:hidden">
    <div style="background:linear-gradient(135deg,#0891b2,#67e8f9);padding:14px 16px;color:#fff">
      <div style="font-weight:800;font-size:.92em">&#128225; EV-PLCC Protocol</div>
      <div style="font-size:.68em;opacity:.85;margin-top:2px">ISO 15118 V2G Communication</div>
    </div>
    <div style="padding:14px 16px;font-size:.75em;line-height:1.6">
      <p>Monitors ICPState (Control Pilot: A1&#8211;D2, E, Error) and UslinkState (0&#8211;22 communication steps) to track the complete EV charging handshake from SLAC matching through power delivery to session stop.</p>
      <p style="margin-top:8px"><b>ICPState:</b> A1, B1, C1, D1, A2, B2, C2 (charging), D2, E (fault), Error</p>
      <p><b>UslinkState:</b> Ready &#8594; SLAC &#8594; SECC &#8594; Session &#8594; Cable Check &#8594; Charge &#8594; Stop</p>
    </div>
  </div>

</div>
</div></div>

</div><!-- /pageMod7 -->

<!-- ═══ PAGE: HEALTH HISTORY ═══ -->
<div class="tc" id="pageHealth">
<div style="padding:16px 20px">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:14px">
    <div>
      <h2 style="font-size:1.05rem;font-weight:800;color:var(--tx);display:flex;align-items:center;gap:8px">📈 <span>System Health History</span></h2>
      <div style="font-size:.7rem;color:var(--dim);margin-top:2px" id="hhStationInfo">Loading...</div>
    </div>
    <div style="display:flex;gap:6px;align-items:center">
      <button class="bt bgh" id="hhBtnDaily" onclick="hhSetRange('daily')" style="padding:6px 16px;font-size:.7rem">Daily (24h)</button>
      <button class="bt" id="hhBtnWeekly" onclick="hhSetRange('weekly')" style="padding:6px 16px;font-size:.7rem">Weekly (7d)</button>
      <button class="bt" id="hhBtnMonthly" onclick="hhSetRange('monthly')" style="padding:6px 16px;font-size:.7rem">Monthly (30d)</button>
      <button class="bt" onclick="hhLoadData()" style="padding:6px 12px;font-size:.7rem">🔄</button>
    </div>
  </div>

  <!-- System Health Chart -->
  <div style="background:var(--glass);border:1px solid var(--bdr);border-radius:12px;padding:14px;margin-bottom:14px">
    <div style="font-size:.72rem;font-weight:700;color:var(--dim);margin-bottom:8px">SYSTEM HEALTH %</div>
    <div style="height:280px;position:relative">
      <canvas id="hhChart"></canvas>
    </div>
    <div style="font-size:.6rem;color:var(--dim);margin-top:6px;font-family:'JetBrains Mono',monospace" id="hhChartInfo"></div>
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;padding-top:8px;border-top:1px solid var(--bdr)">
      <div style="font-size:.6rem;font-weight:700;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;line-height:1.8">CBM Zones:</div>
      <div style="display:flex;align-items:center;gap:4px;font-size:.62rem;font-weight:600"><div style="width:20px;height:3px;background:#22c55e;border-radius:2px"></div><span style="color:#22c55e">≥80% Good</span><span style="color:var(--dim)">— ติดตามปกติ</span></div>
      <div style="display:flex;align-items:center;gap:4px;font-size:.62rem;font-weight:600"><div style="width:20px;height:3px;background:#eab308;border-radius:2px"></div><span style="color:#eab308">60-79% Monitor</span><span style="color:var(--dim)">— ติดตามใกล้ชิด</span></div>
      <div style="display:flex;align-items:center;gap:4px;font-size:.62rem;font-weight:600"><div style="width:20px;height:3px;background:#f97316;border-radius:2px"></div><span style="color:#f97316">40-59% Inspect</span><span style="color:var(--dim)">— ตรวจสอบด่วน</span></div>
      <div style="display:flex;align-items:center;gap:4px;font-size:.62rem;font-weight:600"><div style="width:20px;height:3px;background:#ef4444;border-radius:2px"></div><span style="color:#ef4444">&lt;40% Repair</span><span style="color:var(--dim)">— เข้าแก้ไขทันที</span></div>
    </div>
  </div>

  <!-- Per-Module Charts -->
  <div style="background:var(--glass);border:1px solid var(--bdr);border-radius:12px;padding:14px">
    <div style="font-size:.72rem;font-weight:700;color:var(--dim);margin-bottom:8px">PER-MODULE HEALTH BREAKDOWN <span style="font-weight:500;font-size:.6rem;opacity:.7">(click legend to toggle)</span></div>
    <div style="height:260px;position:relative">
      <canvas id="hhModChart"></canvas>
    </div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px" id="hhModLegend"></div>
  </div>
</div>
</div><!-- /pageHealth -->

<!-- ═══ PAGE: STATION MONITOR ═══ -->
<div class="tc" id="pageMonitor">
<div style="padding:16px 20px">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:14px">
    <div>
      <h2 style="font-size:1.05rem;font-weight:800;color:var(--tx);display:flex;align-items:center;gap:8px">📡 <span>Station Monitor</span></h2>
      <div style="font-size:.7rem;color:var(--dim);margin-top:2px">All stations health overview</div>
    </div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <input type="text" id="monSearch" placeholder="🔍 Search..." oninput="monFilter()" style="background:var(--glass);border:1px solid var(--bdr);color:var(--tx);padding:6px 12px;border-radius:8px;font-size:.72rem;width:200px;outline:none;font-family:DM Sans,sans-serif">
      <select id="monFilterSel" onchange="monFilter()" style="background:var(--glass);border:1px solid var(--bdr);color:var(--tx);padding:6px 10px;border-radius:8px;font-size:.72rem;outline:none;font-family:DM Sans,sans-serif">
        <option value="all">All</option><option value="full">Full (7/7)</option><option value="partial">Partial</option><option value="none">No Data</option>
      </select>
      <button class="bt" onclick="monLoad()" style="padding:6px 12px;font-size:.7rem">🔄</button>
    </div>
  </div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px" id="monKpis"></div>
  <div style="background:var(--glass);border:1px solid var(--bdr);border-radius:12px;overflow:hidden">
    <div style="overflow-x:auto" id="monTable"><div style="padding:40px;text-align:center;color:var(--dim)">Loading...</div></div>
  </div>
</div>
</div><!-- /pageMonitor -->

<!-- ═══ PAGE: HEATMAP ═══ -->
<div class="tc" id="pageHeatmap">
<div style="padding:16px 20px;height:calc(100vh - 60px);display:flex;flex-direction:column">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:10px;flex-shrink:0">
    <div>
      <h2 style="font-size:1.05rem;font-weight:800;color:var(--tx);display:flex;align-items:center;gap:8px">🎯 <span>Health Heatmap</span></h2>
      <div style="font-size:.7rem;color:var(--dim);margin-top:2px">All stations at a glance — <span id="hmInfo">Loading...</span></div>
    </div>
    <div style="display:flex;gap:4px;align-items:center">
      <div style="width:120px;height:10px;border-radius:5px;background:linear-gradient(90deg,#dc2626,#f59e0b,#eab308,#84cc16,#22c55e,#16a34a)"></div>
      <span style="font-size:.5rem;color:var(--dim);font-family:JetBrains Mono,monospace">0%→100%</span>
      <div style="width:12px;height:10px;border-radius:3px;background:var(--bdr);margin-left:6px"></div>
      <span style="font-size:.5rem;color:var(--dim)">N/A</span>
      <button class="bt" onclick="hmLoad()" style="padding:5px 10px;font-size:.68rem;margin-left:8px">🔄</button>
    </div>
  </div>
  <div style="flex:1;overflow:hidden;min-height:0" id="hmWrap">
    <div id="hmGrid" style="display:grid;gap:2px;width:100%;height:100%"></div>
  </div>
  <div style="display:none;position:fixed;z-index:100;background:var(--glass);border:1px solid var(--bdr);border-radius:10px;padding:12px 16px;box-shadow:0 8px 30px rgba(0,0,0,.12);font-size:.75rem;pointer-events:none;min-width:220px" id="hmTip">
    <div id="hmTipName" style="font-weight:800;font-size:.85rem"></div>
    <div id="hmTipSn" style="font-family:JetBrains Mono,monospace;font-size:.6rem;color:var(--dim)"></div>
    <div id="hmTipHealth" style="font-family:JetBrains Mono,monospace;font-size:1.4rem;font-weight:800;margin:6px 0 4px"></div>
    <div style="font-size:.5rem;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;font-weight:700;margin-bottom:3px">MODULE HEALTH</div>
    <div id="hmTipMods" style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px"></div>
  </div>
</div>
</div><!-- /pageHeatmap -->


</div><!-- app-main -->
</div><!-- app-wrap -->
</body></html>"""


# ====================================================================
# FASTAPI SERVER — READ-ONLY FROM eds_ai_results




def run_server(host="0.0.0.0", port=8000):
    from fastapi import FastAPI, WebSocket
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import HTMLResponse, JSONResponse

    app = FastAPI(title="EDS AI Frontend", version="2.0")
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

    # ── MongoDB Connection ──
    from pymongo import MongoClient
    mongo_client = None
    results_db = None
    try:
        mongo_client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        mongo_client.admin.command("ping")
        results_db = mongo_client[RESULTS_DB_NAME]
        logger.info("✅ MongoDB connected")
    except Exception as e:
        logger.error(f"❌ MongoDB failed: {e}")

    # ── Station Config ──
    STATION_CONFIG = {"active_sn": DEFAULT_SN}

    # ── Helper: read module result ──
    def get_result(module_key):
        """Read latest AI result for active station from eds_ai_results."""
        sn = STATION_CONFIG["active_sn"]
        if results_db is None:
            logger.warning(f"[get_result] results_db is None")
            return {"error": "no_db", "message": "Results database not connected"}
        try:
            doc = results_db[sn].find_one({"module": module_key})
            if doc and "result" in doc:
                r = doc["result"]
                r["_result_ts"] = doc.get("timestamp", "").isoformat() if hasattr(doc.get("timestamp", ""), "isoformat") else str(doc.get("timestamp", ""))
                r["_processing_ms"] = doc.get("processing_ms", 0)
                return r
            logger.info(f"[get_result] No result for {module_key} in eds_ai_results.{sn}")
            return {"error": "no_data", "message": f"No result for {module_key} at station {sn}"}
        except Exception as e:
            logger.error(f"[get_result] {module_key}: {e}")
            return {"error": str(e)}

    # ── Helper: read latest telemetry from source DB ──
    # ── SN ↔ Station Name cache (for M1 collection lookup) ──
    _sn_name_cache = {"sn_to_name": {}, "name_to_sn": {}, "ts": 0}

    def _get_sn_name_map():
        """Build/refresh SN↔Name mapping (cached 5 min)."""
        import time as _t
        if _t.time() - _sn_name_cache["ts"] < 300 and _sn_name_cache["sn_to_name"]:
            return _sn_name_cache["sn_to_name"], _sn_name_cache["name_to_sn"]
        s2n, n2s = {}, {}
        if mongo_client:
            try:
                for c in mongo_client["iMPS"]["charger"].find({}, {"_id": 0, "SN": 1, "station_id": 1, "StationName": 1}):
                    sn = c.get("SN", "")
                    name = c.get("station_id") or c.get("StationName") or ""
                    if sn and name and sn != name:
                        s2n[sn] = name
                        n2s[name] = sn
            except:
                pass
        _sn_name_cache["sn_to_name"] = s2n
        _sn_name_cache["name_to_sn"] = n2s
        _sn_name_cache["ts"] = _t.time()
        return s2n, n2s

    def get_telemetry(module_key):
        """Read latest telemetry from source database.
        M1 tries station_name, SN, then partial match. M2-M7 try SN first."""
        sn = STATION_CONFIG["active_sn"]
        cfg = SOURCE_DBS.get(module_key, {})
        if not cfg or mongo_client is None:
            logger.warning(f"[get_telemetry] {module_key}: no config or no mongo_client")
            return None
        try:
            db = mongo_client[cfg["db"]]
            s2n, n2s = _get_sn_name_map()

            if module_key == "m1":
                candidates = []
                if sn in s2n:
                    candidates.append(s2n[sn])
                candidates.append(sn)
                if sn in n2s:
                    candidates.append(n2s[sn])
                # Partial match fallback
                try:
                    all_cols = [c for c in db.list_collection_names() if not c.startswith("system.")]
                    for col in all_cols:
                        if col not in candidates and sn.lower() in col.lower():
                            candidates.append(col)
                except:
                    pass
            else:
                candidates = [sn]
                if sn in s2n:
                    candidates = [sn, s2n[sn]]
                elif sn in n2s:
                    candidates = [n2s[sn], sn]

            for col_name in candidates:
                doc = db[col_name].find_one(sort=[(cfg["ts_field"], -1)], projection={"_id": 0})
                if doc:
                    for k, v in doc.items():
                        if hasattr(v, 'isoformat'):
                            doc[k] = v.isoformat()
                    return doc
            logger.info(f"[get_telemetry] {module_key}: no doc in {cfg['db']}.{candidates}")
            return None
        except Exception as e:
            logger.error(f"[get_telemetry] {module_key}: {e}")
            return None

    # ════════════════════════════════════════════════
    # DASHBOARD HTML
    # ════════════════════════════════════════════════
    def _safe_num(val, default=0):
        if val is None: return default
        try: return float(val)
        except: return default

    @app.get("/dashboard", response_class=HTMLResponse)
    async def dashboard():
        return DASHBOARD_HTML

    # ════════════════════════════════════════════════
    # MODULE LATEST (AI result + live telemetry from source DB)
    # ════════════════════════════════════════════════
    @app.get("/api/m1/latest")
    async def m1_latest():
        """Module 1: Read directly from module1MdbDustPrediction for active station."""
        sn = STATION_CONFIG["active_sn"]
        M1_DB = SOURCE_DBS["m1"]["db"]
        M1_TS = SOURCE_DBS["m1"]["ts_field"]
        logger.info(f"[M1-API] called, active_sn={sn}, db={M1_DB}")

        if mongo_client is None:
            return JSONResponse({"error": "no_db", "message": "MongoDB not connected"})

        try:
            db = mongo_client[M1_DB]
            all_cols = [c for c in db.list_collection_names() if not c.startswith("system.")]

            # Build candidate collection names: station_name, SN, partial match
            s2n, n2s = _get_sn_name_map()
            candidates = []
            if sn in s2n:
                candidates.append(s2n[sn])
            candidates.append(sn)
            if sn in n2s:
                candidates.append(n2s[sn])
            for col in all_cols:
                if col not in candidates:
                    if sn.lower() in col.lower():
                        candidates.append(col)
                    elif sn in s2n and s2n[sn].lower() in col.lower():
                        candidates.append(col)

            logger.info(f"[M1-API] DB has {len(all_cols)} cols, candidates={candidates[:6]}")

            # Try each candidate
            doc = None
            used_col = None
            for col_name in candidates:
                if col_name not in all_cols:
                    continue
                doc = db[col_name].find_one(sort=[(M1_TS, -1)], projection={"_id": 0})
                if doc:
                    used_col = col_name
                    break

            if doc is None:
                logger.info(f"[M1-API] No data. Available: {all_cols[:15]}")
                return JSONResponse({
                    "error": "no_data",
                    "message": f"No collection for '{sn}' in {M1_DB}",
                    "available_collections": all_cols[:20],
                })

            for k, v in doc.items():
                if hasattr(v, 'isoformat'):
                    doc[k] = v.isoformat()

            logger.info(f"[M1-API] Found {M1_DB}.{used_col} ({len(doc)} fields)")

            # Try AI results from backend worker (optional)
            ai = get_result("m1")
            ensemble_risk = 0
            risk_score = 0
            confidence = 0
            model_results = {}
            health = None
            method = "telemetry_only"
            if ai and not ai.get("error"):
                ensemble_risk = ai.get("ensemble_risk", 0)
                risk_score = ai.get("risk_score", 0)
                confidence = ai.get("confidence", 0)
                model_results = ai.get("model_results", {})
                health = ai.get("health")
                method = ai.get("method", "backend")

            return JSONResponse({
                "telemetry": doc,
                "source": "mongodb",
                "collection": used_col,
                "database": M1_DB,
                "fields_count": len(doc),
                "ensemble_risk": ensemble_risk,
                "risk_score": risk_score,
                "confidence": confidence,
                "model_results": model_results,
                "health": health,
                "method": method,
            })
        except Exception as e:
            logger.error(f"[M1-API] Error: {e}")
            return JSONResponse({"error": str(e)})

    @app.get("/api/m2/latest")
    async def m2_latest():
        r = get_result("m2")
        tel = get_telemetry("m2")
        if tel:
            r.pop("error", None)
            r.pop("message", None)
            r["data"] = tel
            r["fields"] = len(tel)
            r["source"] = "mongodb"
        return JSONResponse(r)

    @app.get("/api/m3/latest")
    async def m3_latest():
        r = get_result("m3")
        tel = get_telemetry("m3")
        if tel:
            r.pop("error", None)
            r.pop("message", None)
            r["data"] = tel
            r["source"] = "mongodb"
        return JSONResponse(r)

    @app.get("/api/m4/latest")
    async def m4_latest():
        r = get_result("m4")
        tel = get_telemetry("m4")
        if tel:
            r.pop("error", None)
            r.pop("message", None)
            r.setdefault("soc", _safe_num(tel.get("SOC")))
            r.setdefault("charger_temp", _safe_num(tel.get("charger_temp")))
            r["data"] = tel
            r["source"] = "mongodb"
        return JSONResponse(r)

    @app.get("/api/m5/latest")
    async def m5_latest():
        r = get_result("m5")
        tel = get_telemetry("m5")
        if tel:
            r.pop("error", None)
            r.pop("message", None)
            if "data" not in r or not isinstance(r.get("data"), dict):
                r["data"] = {}
            r["data"].update(tel)
            r["source"] = "mongodb"
        return JSONResponse(r)

    @app.get("/api/m6/latest")
    async def m6_latest():
        r = get_result("m6")
        r.setdefault("source", "mongodb")
        return JSONResponse(r)

    @app.get("/api/m7/latest")
    async def m7_latest():
        sn = STATION_CONFIG["active_sn"]
        r = get_result("m7")
        tel7 = get_telemetry("m7")  # M7 DB: contractor data only
        tel4 = get_telemetry("m4")  # M4 DB: charger telemetry

        logger.info(f"[M7-API] sn={sn}, result_has_error={'error' in r}, tel7={bool(tel7)}, tel4={bool(tel4)}")
        if tel4:
            logger.info(f"[M7-API] tel4 sample keys: {list(tel4.keys())[:10]}")

        # Merge: M4 first (base), M7 overrides
        merged = {}
        if tel4:
            merged.update(tel4)
        if tel7:
            merged.update(tel7)

        # ALWAYS remove error if we have ANY telemetry
        if merged:
            r.pop("error", None)
            r.pop("message", None)

        def _to_int(val):
            if val is None: return None
            try: return int(float(str(val)))
            except: return None

        # ── 1. Build charger telemetry for frontend Live Telemetry panel ──
        charger_tel = {}
        field_map = {
            "present_voltage1": "presentVoltage1", "present_voltage2": "presentVoltage2",
            "present_current1": "presentCurrent1", "present_current2": "presentCurrent2",
            "target_voltage1": "targetVoltage1", "target_voltage2": "targetVoltage2",
            "target_current1": "targetCurrent1", "target_current2": "targetCurrent2",
            "power_module_temp1": "tempPowerModule1", "power_module_temp2": "tempPowerModule2",
            "power_module_temp3": "tempPowerModule3", "power_module_temp4": "tempPowerModule4",
            "charger_gun_temp_plus1": "temp1Head1", "charger_gun_temp_plus2": "temp1Head2",
            "charger_gun_temp_minus1": "temp2Head1", "charger_gun_temp_minus2": "temp2Head2",
            "SOC": "SOC", "charger_temp": "chargerTemp",
            "power_module_status1": "activeMld1", "power_module_status2": "activeMld2",
            "humidity": "humidity", "edgebox_temp": "edgeboxTemp",
        }
        for src_key, dst_key in field_map.items():
            v = merged.get(src_key)
            if v is not None:
                charger_tel[dst_key] = v
        # Also include M7 contractor data
        for key in ["AC_magnetic_contractor1","AC_magnetic_contractor2",
                     "DC_contractor1","DC_contractor2","DC_contractor3",
                     "DC_contractor4","DC_contractor5","DC_contractor6"]:
            v = merged.get(key)
            if v is not None:
                charger_tel[key] = v
        # Include PLC status strings
        for key in ["PLC1_status","PLC2_status","PLC_network_status1","PLC_network_status2",
                     "energy_meter_status","edgebox_network_status"]:
            v = merged.get(key)
            if v is not None:
                charger_tel[key] = v
        r["telemetry"] = charger_tel  # Always set even if empty

        # ── 2. Extract ICP state (numeric only — skip string fields) ──
        icp_int = None
        for key in ["ICPState", "icp_state", "ICP_state", "icp1"]:
            v = _to_int(merged.get(key))
            if v is not None:
                icp_int = v
                break
        # Fallback: infer from voltage/current
        if icp_int is None and merged:
            pv = _to_int(merged.get("present_voltage1")) or 0
            pi = _to_int(merged.get("present_current1")) or 0
            soc = _to_int(merged.get("SOC")) or 0
            if pv > 0 and pi > 0:
                icp_int = 7  # C2 Charging
            elif pv > 0 or soc > 0:
                icp_int = 2  # B1 Connected
            else:
                icp_int = 1  # A1 Idle
            r["icp_inferred"] = True
        if icp_int is not None:
            r["icp_state"] = icp_int

        # ── 3. Extract USLink state (numeric only — skip PLC1_status string) ──
        usl_int = None
        for key in ["UslinkState", "uslink_state", "Uslink_state", "usl1"]:
            v = _to_int(merged.get(key))
            if v is not None:
                usl_int = v
                break
        # PLC1_status is string ("Active"/"Inactive") — handle separately
        plc1_str = str(merged.get("PLC1_status") or merged.get("plc1_status") or "")
        plc2_str = str(merged.get("PLC2_status") or merged.get("plc2_status") or "")
        r["plc_status"] = plc1_str
        r["plc2_status"] = plc2_str

        # Fallback: infer USLink from PLC status + ICP
        if usl_int is None and merged:
            if plc1_str == "Active":
                if icp_int is not None and icp_int >= 7:
                    usl_int = 13  # CurrentDemand
                elif icp_int is not None and icp_int >= 2:
                    usl_int = 0   # Ready
                else:
                    usl_int = 0   # Ready (PLC active but idle)
            elif plc1_str == "Inactive":
                usl_int = None  # PLC offline — leave as N/A
            r["usl_inferred"] = True
        if usl_int is not None:
            r["uslink_state"] = usl_int

        # ── 4. Connector 2 ICP ──
        icp2_int = None
        for key in ["icp2", "CP_status2", "cp_state2"]:
            v = _to_int(merged.get(key))
            if v is not None:
                icp2_int = v
                break
        if icp2_int is None and merged:
            pv2 = _to_int(merged.get("present_voltage2")) or 0
            pi2 = _to_int(merged.get("present_current2")) or 0
            if pv2 > 0 and pi2 > 0: icp2_int = 7
            elif pv2 > 0: icp2_int = 2
            else: icp2_int = 1
        if icp2_int is not None:
            r["icp2_state"] = icp2_int

        logger.info(f"[M7-API] icp={icp_int}, usl={usl_int}, plc1={plc1_str!r}, "
                    f"tel7={bool(tel7)}, tel4={bool(tel4)}, "
                    f"charger_fields={len(charger_tel)}, "
                    f"sample_tel={list(charger_tel.keys())[:6]}")

        r["mqtt_connected"] = False
        r.setdefault("source", "mongodb")
        r.setdefault("db", {"connected": mongo_client is not None, "mqtt_connected": False})
        return JSONResponse(r)

    @app.get("/api/m7/debug")
    async def m7_debug():
        """Debug endpoint - show raw data from all sources for M7."""
        sn = STATION_CONFIG["active_sn"]
        result = get_result("m7")
        tel7 = get_telemetry("m7")
        tel4 = get_telemetry("m4")
        return {
            "station": sn,
            "get_result_m7": {k: str(v)[:100] for k, v in result.items()} if result else None,
            "get_telemetry_m7": {k: str(v)[:50] for k, v in tel7.items()} if tel7 else "None - no M7 collection",
            "get_telemetry_m4": {k: str(v)[:50] for k, v in tel4.items()} if tel4 else "None - no M4 collection",
            "m7_db": SOURCE_DBS.get("m7", {}),
            "m4_db": SOURCE_DBS.get("m4", {}),
        }

    # ════════════════════════════════════════════════
    # BATCH API — All modules in one call (dashboard optimization)
    # ════════════════════════════════════════════════
    @app.get("/api/dashboard/all")
    async def dashboard_all():
        """Return all 7 module results in a single response (1 MongoDB query)."""
        sn = STATION_CONFIG["active_sn"]
        t0 = time.time()
        modules = {}
        # Single query: get all 7 module results at once
        try:
            if results_db is not None:
                cursor = results_db[sn].find({"module": {"$in": ["m1","m2","m3","m4","m5","m6","m7"]}})
                for doc in cursor:
                    mk = doc.get("module")
                    if mk and "result" in doc:
                        r = doc["result"]
                        r["_result_ts"] = doc.get("timestamp", "").isoformat() if hasattr(doc.get("timestamp", ""), "isoformat") else ""
                        modules[mk] = r
        except Exception as e:
            logger.error(f"[BATCH] results query: {e}")
        # Fill missing modules
        for mk in ["m1","m2","m3","m4","m5","m6","m7"]:
            if mk not in modules:
                modules[mk] = {"error": "no_data"}

        # ── Enrich M1: always read fresh telemetry from module1MdbDustPrediction ──
        try:
            tel1 = get_telemetry("m1")
            if tel1:
                m1r = modules.get("m1", {})
                m1r["telemetry"] = tel1
                m1r["source"] = "mongodb"
                m1r.pop("error", None)  # Clear error since we have live data
                # If no health from backend, compute rule-based
                if m1r.get("health") is None:
                    # Simple rule-based health from telemetry
                    risk = 0.0
                    factors = 0
                    def _sf1(v):
                        if v is None: return None
                        try: return float(v)
                        except: return None
                    temp = _sf1(tel1.get("MDB_ambient_temp"))
                    if temp is not None:
                        risk += 0.25 * min(1.0, max(0, (temp - 25) / 25.0))
                        factors += 0.25
                    hum = _sf1(tel1.get("MDB_humidity") or tel1.get("humidity"))
                    if hum is not None:
                        risk += 0.20 * min(1.0, max(0, (hum - 40) / 50.0))
                        factors += 0.20
                    pi5 = _sf1(tel1.get("pi5_temp"))
                    if pi5 is not None:
                        risk += 0.15 * min(1.0, max(0, (pi5 - 40) / 40.0))
                        factors += 0.15
                    age = _sf1(tel1.get("dust_filter_charging"))
                    if age is not None:
                        risk += 0.40 * min(1.0, max(0, age / 120.0))
                        factors += 0.40
                    if factors > 0:
                        risk = risk / factors
                    risk = max(0, min(1, risk))
                    hp = max(0, min(100, round((1 - risk) * 100)))
                    m1r["ensemble_risk"] = round(risk, 4)
                    m1r["risk_score"] = round(risk, 4)
                    m1r["health"] = hp
                    m1r["method"] = "rule_based"
                modules["m1"] = m1r
        except Exception as e:
            logger.error(f"[BATCH] M1 enrich: {e}")

        # Enrich M7 with telemetry from M4 (ICP/USLink/charger data)
        try:
            tel4 = get_telemetry("m4")
            tel7 = get_telemetry("m7")
            merged = {}
            if tel4: merged.update(tel4)
            if tel7: merged.update(tel7)
            if merged:
                m7r = modules.get("m7", {})
                def _ti(val):
                    if val is None: return None
                    try: return int(float(str(val)))
                    except: return None
                icp = None
                for k in ["ICPState","icp_state","ICP_state","icp1"]:
                    icp = _ti(merged.get(k))
                    if icp is not None: break
                if icp is None:
                    pv = _ti(merged.get("present_voltage1")) or 0
                    pi = _ti(merged.get("present_current1")) or 0
                    icp = 7 if pv>0 and pi>0 else 2 if pv>0 else 1
                m7r["icp_state"] = icp
                usl = None
                for k in ["UslinkState","uslink_state","usl1"]:
                    usl = _ti(merged.get(k))
                    if usl is not None: break
                plc1 = str(merged.get("PLC1_status") or "")
                if usl is None and plc1 == "Active":
                    usl = 13 if icp and icp >= 7 else 0
                if usl is not None: m7r["uslink_state"] = usl
                m7r["plc_status"] = plc1
                m7r["source"] = "mongodb"
                m7r.pop("error", None)
                modules["m7"] = m7r
        except Exception as e:
            logger.error(f"[BATCH] M7 enrich: {e}")
        elapsed = round((time.time() - t0) * 1000, 1)
        return {"station": sn, "modules": modules, "elapsed_ms": elapsed}

    # ════════════════════════════════════════════════
    # MODEL STATUS (static info — no models loaded in frontend)
    # ════════════════════════════════════════════════
    _model_info = {
        "m1": {"loaded": 11, "total": 11, "models": [
            {"id": "RE", "name": "Rule Engine", "type": "Rule", "status": "backend"},
            {"id": "A1", "name": "XGBoost Classifier", "type": "ML", "status": "backend"},
            {"id": "A2", "name": "XGBoost Regressor", "type": "ML", "status": "backend"},
            {"id": "B", "name": "Autoencoder", "type": "DL", "status": "backend"},
            {"id": "C", "name": "Multi-Task DNN", "type": "DL", "status": "backend"},
            {"id": "D", "name": "BiLSTM-Attention", "type": "DL", "status": "backend"},
            {"id": "E", "name": "1D-CNN", "type": "DL", "status": "backend"},
            {"id": "F", "name": "Gradient Boosting", "type": "ML", "status": "backend"},
            {"id": "G1", "name": "Isolation Forest", "type": "ML", "status": "backend"},
            {"id": "G2", "name": "LOF", "type": "ML", "status": "backend"},
            {"id": "EN", "name": "Ensemble", "type": "Ensemble", "status": "backend"},
        ]},
        "m2": {"loaded": 10, "total": 10, "models": [
            {"id": "A1", "name": "XGBoost Regressor", "type": "ML", "status": "backend"},
            {"id": "A2", "name": "XGBoost Classifier", "type": "ML", "status": "backend"},
            {"id": "B", "name": "Autoencoder", "type": "DL", "status": "backend"},
            {"id": "C", "name": "DNN 5-class", "type": "DL", "status": "backend"},
            {"id": "D", "name": "BiLSTM-Attention", "type": "DL", "status": "backend"},
            {"id": "E1", "name": "Isolation Forest", "type": "ML", "status": "backend"},
            {"id": "E2", "name": "LOF", "type": "ML", "status": "backend"},
        ]},
        "m3": {"loaded": 8, "total": 8, "models": []},
        "m4": {"loaded": 3, "total": 3, "models": []},
        "m5": {"loaded": 13, "total": 13, "models": []},
        "m6": {"loaded": 37, "total": 37, "models": []},
        "m7": {"loaded": 11, "total": 11, "models": []},
    }

    @app.get("/api/m1/models")
    async def m1_models():
        return _model_info["m1"]

    @app.get("/api/m2/models")
    async def m2_models():
        return _model_info["m2"]

    @app.get("/api/m3/models")
    async def m3_models():
        return _model_info["m3"]

    @app.get("/api/m4/models")
    async def m4_models():
        return _model_info["m4"]

    @app.get("/api/m5/models")
    async def m5_models():
        return _model_info["m5"]

    @app.get("/api/m6/models")
    async def m6_models():
        return _model_info["m6"]

    @app.get("/api/m7/models")
    async def m7_models():
        return _model_info["m7"]

    # ════════════════════════════════════════════════
    # DB STATUS (JS expects module3, module4, module5 keys)
    # ════════════════════════════════════════════════
    _db_key_map = {"m1": "module1", "m2": "module2", "m3": "module3", "m4": "module4", "m5": "module5", "m6": "module6", "m7": "module7"}

    @app.get("/api/db/status")
    async def db_status():
        sn = STATION_CONFIG["active_sn"]
        s2n, n2s = _get_sn_name_map()
        result = {"timestamp": datetime.now().isoformat()}
        for mod_key, cfg in SOURCE_DBS.items():
            info = {"connected": False, "database": cfg["db"], "collection": sn}
            if mongo_client:
                try:
                    db = mongo_client[cfg["db"]]
                    # Build candidate collection names
                    if mod_key == "m1":
                        candidates = []
                        if sn in s2n: candidates.append(s2n[sn])
                        candidates.append(sn)
                        if sn in n2s: candidates.append(n2s[sn])
                        # Partial match
                        try:
                            all_m1_cols = [c for c in db.list_collection_names() if not c.startswith("system.")]
                            for col in all_m1_cols:
                                if col not in candidates and sn.lower() in col.lower():
                                    candidates.append(col)
                        except:
                            pass
                    else:
                        candidates = [sn, s2n.get(sn, sn)] if sn in s2n else [n2s.get(sn, sn), sn] if sn in n2s else [sn]
                    for col_name in candidates:
                        doc = db[col_name].find_one(sort=[(cfg["ts_field"], -1)], projection={"_id": 0, cfg["ts_field"]: 1})
                        if doc:
                            info["connected"] = True
                            info["collection"] = col_name
                            ts = doc.get(cfg["ts_field"], "")
                            info["latest_ts"] = ts.isoformat() if hasattr(ts, "isoformat") else str(ts)
                            info["docs"] = db[col_name].estimated_document_count()
                            break
                    if not info["connected"]:
                        info["error"] = "Collection empty"
                except Exception as e:
                    info["error"] = str(e)
            else:
                info["error"] = "MongoDB not connected"
            result[_db_key_map.get(mod_key, mod_key)] = info
        return result

    # ════════════════════════════════════════════════
    # STATION MANAGEMENT
    # ════════════════════════════════════════════════
    @app.get("/api/stations")
    async def list_stations():
        sn = STATION_CONFIG["active_sn"]
        if mongo_client is None:
            return {"stations": [], "active_sn": sn, "error": "mongodb_unavailable"}
        try:
            sn_map = {}
            # From iMPS.charger
            try:
                chargers = list(mongo_client["iMPS"]["charger"].find({}, {"_id": 0}))
                for c in chargers:
                    s = c.get("SN", "")
                    if s:
                        sn_map[s] = {"sn": s, "name": c.get("station_id") or c.get("StationName") or s,
                                     "station_id": str(c.get("station_id", "")), "model": c.get("Model", ""),
                                     "province": c.get("Province", ""), "location": c.get("Location", "")}
            except:
                pass
            # From module DBs
            discovered = set()
            for db_name in MODULE_DB_NAMES:
                try:
                    for col in mongo_client[db_name].list_collection_names():
                        if not col.startswith("system."):
                            discovered.add(col)
                except:
                    pass
            # Build reverse lookup: station_name → SN (to deduplicate)
            name_to_sn_local = {}
            for s, info in sn_map.items():
                n = info.get("name", "")
                if n and n != s:
                    name_to_sn_local[n] = s
            for s in discovered:
                # Skip if it's already an SN key
                if s in sn_map:
                    continue
                # Skip if this collection name is a station_name of an existing SN
                if s in name_to_sn_local:
                    continue
                sn_map[s] = {"sn": s, "name": s, "station_id": "", "model": "", "province": "", "location": ""}
            # Module availability
            for s in sn_map:
                mods = []
                station_name = sn_map[s].get("name", "")
                for i, db_name in enumerate(MODULE_DB_NAMES, 1):
                    try:
                        db_cols = mongo_client[db_name].list_collection_names()
                        # Check SN first, then station_name (for M1 which uses names)
                        if s in db_cols:
                            mods.append(f"M{i}")
                        elif station_name and station_name != s and station_name in db_cols:
                            mods.append(f"M{i}")
                    except:
                        pass
                sn_map[s]["modules"] = mods
                sn_map[s]["module_count"] = len(mods)
            stations = sorted(sn_map.values(), key=lambda x: (-x["module_count"], x["name"]))
            return {"stations": stations, "active_sn": sn, "count": len(stations)}
        except Exception as e:
            return {"stations": [], "active_sn": sn, "error": str(e)}

    @app.post("/api/switch-station/{sn}")
    async def switch_station(sn: str):
        old = STATION_CONFIG["active_sn"]
        STATION_CONFIG["active_sn"] = sn
        logger.info(f"🔄 Station switched: {old} → {sn}")
        name = sn
        if mongo_client:
            try:
                doc = mongo_client["iMPS"]["charger"].find_one({"SN": sn}, {"_id": 0})
                if doc:
                    name = doc.get("station_id") or doc.get("StationName") or sn
            except:
                pass
        return {"ok": True, "active_sn": sn, "station_name": name, "old_sn": old}

    @app.get("/api/active-station")
    async def active_station():
        sn = STATION_CONFIG["active_sn"]
        info = {"sn": sn, "name": sn}
        if mongo_client:
            try:
                doc = mongo_client["iMPS"]["charger"].find_one({"SN": sn}, {"_id": 0})
                if doc:
                    info = {"sn": sn, "name": doc.get("station_id") or doc.get("StationName") or sn,
                            "station_id": str(doc.get("station_id", "")), "province": doc.get("Province", "")}
            except:
                pass
        return info

    # ════════════════════════════════════════════════
    # HEALTH HISTORY
    # ════════════════════════════════════════════════
    @app.get("/api/health/snapshot")
    async def health_snapshot():
        sn = STATION_CONFIG["active_sn"]
        r = get_result("system_health")
        return {"station": sn, "health": r.get("score"), "modules_processed": r.get("modules_processed", 0)}

    @app.get("/api/health/history")
    async def health_history(hours: int = 24, range: str = None):
        sn = STATION_CONFIG["active_sn"]
        if mongo_client is None:
            return {"error": "no_db", "data": []}
        try:
            # Support range parameter
            if range == "weekly": hours = 168
            elif range == "monthly": hours = 720
            elif range == "daily": hours = 24
            db = mongo_client["eds_system_health"]
            since = datetime.now(timezone.utc) - timedelta(hours=hours)
            cursor = db[sn].find({"timestamp": {"$gte": since}}).sort("timestamp", 1).limit(2000)
            data = []
            for doc in cursor:
                entry = {
                    "timestamp": doc.get("timestamp", "").isoformat() if hasattr(doc.get("timestamp", ""), "isoformat") else "",
                    "score": doc.get("score"),
                }
                # Include per-module scores if available
                mods = doc.get("modules")
                if mods and isinstance(mods, dict):
                    entry["modules"] = mods
                data.append(entry)
            # If no data with date filter, try without
            if not data:
                cursor = db[sn].find({}).sort("timestamp", -1).limit(500)
                for doc in cursor:
                    entry = {
                        "timestamp": doc.get("timestamp", "").isoformat() if hasattr(doc.get("timestamp", ""), "isoformat") else "",
                        "score": doc.get("score"),
                    }
                    mods = doc.get("modules")
                    if mods and isinstance(mods, dict):
                        entry["modules"] = mods
                    data.append(entry)
                data.reverse()
            return {"data": data, "count": len(data), "station": sn, "hours": hours}
        except Exception as e:
            return {"error": str(e), "data": []}

    # ════════════════════════════════════════════════
    # TELEMETRY (direct read from source DB)
    # ════════════════════════════════════════════════
    @app.get("/api/latest")
    async def latest_telemetry():
        sn = STATION_CONFIG["active_sn"]
        if mongo_client is None:
            return {"error": "MongoDB not connected"}
        try:
            doc = mongo_client["module4AbnormalPowerPrediction"][sn].find_one(
                sort=[("timestamp_utc", -1)], projection={"_id": 0})
            if not doc:
                return {"error": "No data"}
            for k, v in doc.items():
                if hasattr(v, "isoformat"):
                    doc[k] = v.isoformat()
            return {"data": doc}
        except Exception as e:
            return {"error": str(e)}

    # ── Generic history helper ──
    def _query_history(db_name, ts_field, sn, range_str, fields_str, start=None, end=None, limit=2000):
        """Query MongoDB for historical data. Tries SN↔Name mapping if no data found."""
        if mongo_client is None:
            return None, "MongoDB not connected"
        try:
            db = mongo_client[db_name]
            field_list = [f.strip() for f in fields_str.split(",") if f.strip()]
            now = datetime.now(timezone.utc)
            if range_str == "custom" and start and end:
                try:
                    since = datetime.fromisoformat(start.replace("Z", "+00:00"))
                    until = datetime.fromisoformat(end.replace("Z", "+00:00"))
                except:
                    return None, "Invalid date format"
            elif range_str == "weekly":
                since, until = now - timedelta(days=7), now
            elif range_str == "monthly":
                since, until = now - timedelta(days=30), now
            else:
                since, until = now - timedelta(days=1), now
            proj = {"_id": 0, ts_field: 1}
            for f in field_list:
                proj[f] = 1

            # Build candidate collection names (SN + alternative name)
            s2n, n2s = _get_sn_name_map()
            candidates = [sn]
            if sn in s2n:
                candidates.append(s2n[sn])
            elif sn in n2s:
                candidates.append(n2s[sn])

            for col_name in candidates:
                cursor = db[col_name].find({ts_field: {"$gte": since, "$lte": until}}, proj).sort(ts_field, 1).limit(limit)
                docs = list(cursor)
                if not docs:
                    cursor = db[col_name].find({}, proj).sort(ts_field, -1).limit(limit)
                    docs = list(cursor)
                    docs.reverse()
                if docs:
                    logger.info(f"[HIST] {db_name}.{col_name} range={range_str} fields={field_list} → {len(docs)} docs")
                    return docs, field_list

            logger.info(f"[HIST] {db_name}.{candidates} range={range_str} → 0 docs")
            return [], field_list
        except Exception as e:
            logger.error(f"[HIST] {db_name}.{sn}: {e}")
            return None, str(e)

    def _to_chart_format(docs, field_list, ts_field):
        """Convert docs to {timestamps:[], values:{field:[]}} for Chart.js."""
        timestamps = []
        values = {f: [] for f in field_list}
        for doc in docs:
            ts = doc.get(ts_field, "")
            if hasattr(ts, "isoformat"):
                ts = ts.isoformat()
            timestamps.append(str(ts))
            for f in field_list:
                v = doc.get(f)
                try:
                    values[f].append(float(v) if v is not None else None)
                except:
                    values[f].append(None)
        return {"timestamps": timestamps, "values": values, "count": len(timestamps), "fields": field_list}

    def _to_data_format(docs, ts_field):
        """Convert docs to {data:[{...}]} format. Always adds 'timestamp' alias."""
        data = []
        for doc in docs:
            row = {}
            for k, v in doc.items():
                if hasattr(v, "isoformat"):
                    row[k] = v.isoformat()
                else:
                    row[k] = v
            # Always add 'timestamp' alias so frontend JS finds it
            if ts_field != "timestamp" and ts_field in row and "timestamp" not in row:
                row["timestamp"] = row[ts_field]
            data.append(row)
        return {"data": data, "count": len(data)}

    @app.get("/api/m1/historical")
    async def m1_historical(range: str = "daily", fields: str = "charger_temp,humidity", start: str = None, end: str = None):
        sn = STATION_CONFIG["active_sn"]
        M1_DB = SOURCE_DBS["m1"]["db"]
        M1_TS = SOURCE_DBS["m1"]["ts_field"]
        # Find the actual collection name for this station
        actual_col = sn
        if mongo_client:
            try:
                db = mongo_client[M1_DB]
                all_cols = [c for c in db.list_collection_names() if not c.startswith("system.")]
                s2n, n2s = _get_sn_name_map()
                candidates = []
                if sn in s2n: candidates.append(s2n[sn])
                candidates.append(sn)
                if sn in n2s: candidates.append(n2s[sn])
                for col in all_cols:
                    if col not in candidates and sn.lower() in col.lower():
                        candidates.append(col)
                for c in candidates:
                    if c in all_cols:
                        actual_col = c
                        break
            except:
                pass
        docs, info = _query_history(M1_DB, M1_TS, actual_col, range, fields, start, end)
        if docs is None:
            return {"error": info, "timestamps": [], "values": {}}
        field_list = info if isinstance(info, list) else fields.split(",")
        return _to_chart_format(docs, field_list, M1_TS)

    @app.get("/api/m2/historical")
    async def m2_historical(range: str = "daily", fields: str = "power_module_temp1,power_module_temp2,power_module_temp3,power_module_temp4,power_module_temp5", start: str = None, end: str = None):
        sn = STATION_CONFIG["active_sn"]
        docs, info = _query_history(SOURCE_DBS["m2"]["db"], "timestamp_utc", sn, range, fields, start, end)
        if docs is None:
            return {"error": info, "timestamps": [], "values": {}}
        field_list = info if isinstance(info, list) else fields.split(",")
        return _to_chart_format(docs, field_list, "timestamp_utc")

    @app.get("/api/m3/historical")
    async def m3_historical(range: str = "daily", fields: str = "edgebox_status,router_status,PLC1_status", start: str = None, end: str = None):
        sn = STATION_CONFIG["active_sn"]
        docs, info = _query_history(SOURCE_DBS["m3"]["db"], "timestamp_utc", sn, range, fields, start, end)
        if docs is None:
            return {"error": info, "data": []}
        return _to_data_format(docs, "timestamp_utc")

    @app.get("/api/m5/historical")
    async def m5_historical(range: str = "daily", fields: str = "router_status,PLC_network_status1,edgebox_network_status", start: str = None, end: str = None):
        sn = STATION_CONFIG["active_sn"]
        docs, info = _query_history(SOURCE_DBS["m5"]["db"], "timestamp_utc", sn, range, fields, start, end)
        if docs is None:
            return {"error": info, "data": []}
        return _to_data_format(docs, "timestamp_utc")

    @app.get("/api/historical")
    async def historical(range: str = "daily", fields: str = "target_voltage1,present_voltage1", start: str = None, end: str = None):
        sn = STATION_CONFIG["active_sn"]
        docs, info = _query_history(SOURCE_DBS["m4"]["db"], "timestamp_utc", sn, range, fields, start, end)
        if docs is None:
            return {"error": info, "data": []}
        field_list = info if isinstance(info, list) else fields.split(",")
        r = _to_data_format(docs, "timestamp_utc")
        r["fields"] = field_list
        r["range"] = range
        return r

    # ════════════════════════════════════════════════
    # MQTT / PLC / WEBSOCKET STUBS (no MQTT in frontend mode)
    # ════════════════════════════════════════════════
    @app.get("/api/plc/raw")
    async def plc_raw():
        return {"mqtt_connected": False, "source": "frontend-only", "data": {}}

    @app.get("/api/mqtt/status")
    async def mqtt_status():
        return {"mqtt_connected": False, "mode": "frontend-only"}

    @app.post("/predict")
    async def predict_proxy():
        """Return latest M4 result in full format JS show() expects."""
        r = get_result("m4")
        tel = get_telemetry("m4")
        af = r.get("anomaly_flags", 0) or 0
        score = max(0, min(1, af / 22))
        sev = "CRITICAL" if af > 3 else "WARNING" if af > 0 else "NORMAL"
        # Build model_details and group_scores that show() expects
        model_details = {"PerCondition": score, "RuleBased": score * 0.8, "Thermal": score * 0.5}
        groups = ["voltage", "current", "power", "thermal_modules", "thermal_charger", "edgebox", "daily_energy"]
        group_scores = {f"anomaly_{g}": round(score * (0.3 + 0.1 * i), 4) for i, g in enumerate(groups)}
        alerts = []
        if af > 0:
            alerts.append({"severity": sev, "label": f"{af} anomaly conditions flagged", "score": score, "standards": ["IEC 61851", "ISO 15118"], "action": "Check charger status"})
        return {
            "timestamp": datetime.now().isoformat(),
            "is_anomaly": af > 0,
            "anomaly_score": round(score, 4),
            "binary_score": round(score, 4),
            "max_severity": sev,
            "method": "backend_cached",
            "latency_ms": _safe_num(r.get("_processing_ms", 0)),
            "buffer_size": 0,
            "model_scores": {},
            "model_details": model_details,
            "group_scores": group_scores,
            "alerts": alerts,
            "soc": _safe_num(r.get("soc", tel.get("SOC") if tel else 0)),
            "charger_temp": _safe_num(r.get("charger_temp", tel.get("charger_temp") if tel else 0)),
            "anomaly_flags": af,
        }

    @app.post("/predict/batch")
    async def predict_batch_proxy():
        return {"results": [], "message": "AI inference runs on backend_worker"}

    @app.post("/predict/conditions")
    async def predict_conditions_proxy():
        r = get_result("m4")
        return JSONResponse(r)

    @app.post("/api/m3/predict")
    async def m3_predict_proxy():
        """M3 predict stub — return cached result."""
        r = get_result("m3")
        tel = get_telemetry("m3")
        if tel:
            r.pop("error", None)
            r["data"] = tel
            r["source"] = "mongodb"
        return JSONResponse(r)

    @app.post("/api/m5/predict")
    async def m5_predict_proxy():
        """M5 predict stub — return cached result."""
        r = get_result("m5")
        tel = get_telemetry("m5")
        if tel:
            r.pop("error", None)
            if "data" not in r or not isinstance(r.get("data"), dict):
                r["data"] = {}
            r["data"].update(tel)
            r["source"] = "mongodb"
        return JSONResponse(r)

    @app.get("/api/m4/conditions")
    async def m4_conditions():
        return JSONResponse(get_result("m4"))

    @app.post("/rules/test")
    async def rules_test_stub():
        return {"status": "frontend_only"}

    @app.websocket("/ws/stream")
    async def ws_stream(websocket: WebSocket):
        await websocket.accept()
        try:
            import asyncio
            while True:
                r = get_result("m4")
                tel = get_telemetry("m4") or {}
                af = r.get("anomaly_flags", 0) or 0
                score = max(0, min(1, af / 22))
                msg = {
                    "timestamp": datetime.now().isoformat(),
                    "is_anomaly": af > 0,
                    "anomaly_score": round(score, 4),
                    "anomaly_flags": af,
                    "latency_ms": 0,
                    "max_severity": "CRITICAL" if af > 3 else "WARNING" if af > 0 else "NORMAL",
                    "mqtt_connected": False,
                    "source": "frontend_replay",
                }
                # Include telemetry fields for protocol monitor
                for k, v in tel.items():
                    if k not in msg:
                        msg[k] = v
                await websocket.send_json(msg)
                await asyncio.sleep(5)
        except Exception:
            pass

    # ════════════════════════════════════════════════
    # STATION MONITOR — Overview of all stations × all modules
    # ════════════════════════════════════════════════
    @app.get("/api/monitor/overview")
    async def monitor_overview():
        """Read cached summary from eds_ai_results._monitor_summary, fallback to live aggregation."""
        if mongo_client is None:
            return {"error": "no_db", "stations": []}
        try:
            doc = mongo_client[RESULTS_DB_NAME]["_monitor_summary"].find_one({"_id": "latest"})
            if doc:
                ts = doc.get("timestamp")
                stations = doc.get("stations", [])
                summary = doc.get("summary", {})

                # Enrich M1: if any station has m1.health=None, try reading from source DB
                m1_needs_fix = any(
                    s.get("modules", {}).get("m1", {}).get("health") is None
                    for s in stations
                )
                if m1_needs_fix:
                    try:
                        m1db = mongo_client[SOURCE_DBS["m1"]["db"]]
                        m1_ts_field = SOURCE_DBS["m1"]["ts_field"]
                        m1_cols = {c for c in m1db.list_collection_names() if not c.startswith("system.")}
                        s2n_c, _ = _get_sn_name_map()
                        for row in stations:
                            m1mod = row.get("modules", {}).get("m1", {})
                            if m1mod.get("health") is not None:
                                continue
                            rsn = row.get("sn", "")
                            # Find M1 collection for this station
                            candidates = []
                            if rsn in s2n_c: candidates.append(s2n_c[rsn])
                            candidates.append(rsn)
                            m1_tel = None
                            for cn in candidates:
                                if cn in m1_cols:
                                    m1_tel = m1db[cn].find_one(sort=[(m1_ts_field, -1)], projection={"_id": 0})
                                    if m1_tel: break
                            if m1_tel:
                                _r = 0.0; _f = 0
                                for _kk, _ww, _llo, _hhi in [("MDB_ambient_temp",0.3,25,50),("dust_filter_charging",0.5,0,120)]:
                                    _vv = m1_tel.get(_kk)
                                    if _vv is not None:
                                        try: _r += _ww * min(1, max(0, (float(_vv)-_llo)/max(1,_hhi-_llo))); _f += _ww
                                        except: pass
                                _hvv = m1_tel.get("MDB_humidity") or m1_tel.get("humidity")
                                if _hvv is not None:
                                    try: _r += 0.2 * min(1, max(0, (float(_hvv)-40)/50)); _f += 0.2
                                    except: pass
                                if _f > 0: _r = _r / _f
                                hp = max(0, min(100, round((1 - max(0, min(1, _r))) * 100)))
                                m1mod["health"] = hp
                                m1mod.pop("error", None)
                                row["modules"]["m1"] = m1mod
                                # Recalculate ok_count
                                oc = sum(1 for mk in ["m1","m2","m3","m4","m5","m6","m7"]
                                         if row.get("modules",{}).get(mk,{}).get("health") is not None
                                         and not row.get("modules",{}).get(mk,{}).get("error"))
                                row["ok_count"] = oc
                                row["modules_processed"] = oc
                    except Exception as e:
                        logger.warning(f"[MONITOR] M1 cache enrich: {e}")

                return {
                    "stations": stations,
                    "summary": summary,
                    "timestamp": ts.isoformat() if hasattr(ts, "isoformat") else str(ts),
                    "build_ms": doc.get("build_ms", 0),
                    "source": "cache",
                }

            t0 = time.time()
            sn_map = {}
            try:
                chargers = list(mongo_client["iMPS"]["charger"].find({}, {"_id": 0}))
                for c in chargers:
                    s = c.get("SN", "")
                    if s:
                        sn_map[s] = {
                            "sn": s,
                            "name": c.get("station_id") or c.get("StationName") or s,
                            "station_id": str(c.get("station_id", "")),
                            "model": c.get("Model", ""),
                            "province": c.get("Province", ""),
                            "location": c.get("Location", ""),
                        }
            except Exception:
                pass

            discovered = set()
            for db_name in MODULE_DB_NAMES:
                try:
                    for col in mongo_client[db_name].list_collection_names():
                        if not col.startswith("system."):
                            discovered.add(col)
                except Exception:
                    pass
            # Deduplicate: skip collection names that are station_names of existing SNs
            name_set = {info.get("name", "") for info in sn_map.values() if info.get("name")}
            for s in discovered:
                if s not in sn_map and s not in name_set:
                    sn_map[s] = {"sn": s, "name": s, "station_id": "", "model": "", "province": "", "location": ""}

            rows = []
            full_coverage = partial = no_data = 0
            for sn, meta in sn_map.items():
                col = mongo_client[RESULTS_DB_NAME][sn]
                mods = {}
                ok_count = 0
                last_updated = None
                for i in range(1, 8):
                    mk = f"m{i}"
                    try:
                        rdoc = col.find_one({"module": mk})
                    except Exception:
                        rdoc = None
                    if rdoc:
                        ts = rdoc.get("timestamp")
                        if ts and (last_updated is None or ts > last_updated):
                            last_updated = ts
                        rr = rdoc.get("result", {}) or {}
                        health = rr.get("health")
                        err = rr.get("error")
                        # M1: if health is None but source DB has data, compute from telemetry
                        if mk == "m1" and health is None:
                            try:
                                m1db = mongo_client[SOURCE_DBS["m1"]["db"]]
                                m1_ts = SOURCE_DBS["m1"]["ts_field"]
                                s2n_mon, _ = _get_sn_name_map()
                                m1_candidates = []
                                if sn in s2n_mon: m1_candidates.append(s2n_mon[sn])
                                m1_candidates.append(sn)
                                m1_tel = None
                                for cn in m1_candidates:
                                    m1_tel = m1db[cn].find_one(sort=[(m1_ts, -1)], projection={"_id": 0})
                                    if m1_tel: break
                                if m1_tel:
                                    err = None
                                    _r = 0.0; _f = 0
                                    for _k, _w, _lo, _hi in [("MDB_ambient_temp",0.3,25,50),("dust_filter_charging",0.5,0,120)]:
                                        _v = m1_tel.get(_k)
                                        if _v is not None:
                                            try: _r += _w * min(1, max(0, (float(_v)-_lo)/max(1,_hi-_lo))); _f += _w
                                            except: pass
                                    _hv = m1_tel.get("MDB_humidity") or m1_tel.get("humidity")
                                    if _hv is not None:
                                        try: _r += 0.2 * min(1, max(0, (float(_hv)-40)/50)); _f += 0.2
                                        except: pass
                                    if _f > 0: _r = _r / _f
                                    health = max(0, min(100, round((1 - max(0, min(1, _r))) * 100)))
                            except Exception:
                                pass
                        mods[mk] = {
                            "health": health,
                            "error": err,
                            "timestamp": ts.isoformat() if hasattr(ts, "isoformat") else str(ts),
                        }
                        if health is not None and not err:
                            ok_count += 1
                    else:
                        mods[mk] = {"health": None}
                system_health = None
                try:
                    sdoc = col.find_one({"module": "system_health"})
                except Exception:
                    sdoc = None
                modules_processed = ok_count
                if sdoc:
                    sts = sdoc.get("timestamp")
                    if sts and (last_updated is None or sts > last_updated):
                        last_updated = sts
                    sres = sdoc.get("result", {}) or {}
                    system_health = sres.get("score")
                    modules_processed = sres.get("modules_processed", ok_count)
                if ok_count == 7:
                    full_coverage += 1
                elif ok_count == 0:
                    no_data += 1
                else:
                    partial += 1
                rows.append({
                    "sn": sn,
                    "name": meta.get("name", sn),
                    "station_id": meta.get("station_id", ""),
                    "model": meta.get("model", ""),
                    "province": meta.get("province", ""),
                    "location": meta.get("location", ""),
                    "modules": mods,
                    "ok_count": ok_count,
                    "modules_processed": modules_processed,
                    "system_health": system_health,
                    "last_updated": last_updated.isoformat() if hasattr(last_updated, "isoformat") else (str(last_updated) if last_updated else None),
                })

            rows.sort(key=lambda x: (-x["ok_count"], x["name"], x["sn"]))
            build_ms = round((time.time() - t0) * 1000, 1)
            return {
                "stations": rows,
                "summary": {"total_stations": len(rows), "full_coverage": full_coverage, "partial": partial, "no_data": no_data},
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "build_ms": build_ms,
                "source": "live_fallback",
            }
        except Exception as e:
            logger.error(f"[MONITOR] {e}")
            return {"error": str(e), "stations": []}

    MONITOR_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EDS AI — Station Monitor</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#f5f7fb;--surface:#ffffff;--card:#ffffff;--card2:#f8fafd;
  --bdr:#e2e8f0;--bdr2:#cbd5e1;
  --tx:#1e293b;--tx2:#334155;--dim:#64748b;--dim2:#94a3b8;
  --gn:#059669;--gn-bg:#ecfdf5;--gn-bdr:#a7f3d0;
  --yl:#d97706;--yl-bg:#fffbeb;--yl-bdr:#fde68a;
  --rd:#dc2626;--rd-bg:#fef2f2;--rd-bdr:#fecaca;
  --bl:#2563eb;--bl-bg:#eff6ff;--bl-bdr:#bfdbfe;
  --shadow:0 1px 3px rgba(0,0,0,.04),0 1px 2px rgba(0,0,0,.06);
  --shadow-md:0 4px 6px rgba(0,0,0,.04),0 2px 4px rgba(0,0,0,.06);
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--tx);min-height:100vh}
.hdr{background:var(--surface);border-bottom:1px solid var(--bdr);padding:16px 28px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;box-shadow:var(--shadow)}
.hdr-left{display:flex;align-items:center;gap:12px}
.hdr-logo{width:40px;height:40px;background:linear-gradient(135deg,#2563eb,#0891b2);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;box-shadow:0 2px 10px rgba(37,99,235,.2)}
.hdr h1{font-size:1.15rem;font-weight:800;color:var(--tx);letter-spacing:-.02em}
.hdr .sub{font-size:.7rem;color:var(--dim);font-weight:500;margin-top:1px}
.hdr-right a{padding:7px 16px;border-radius:8px;font-size:.75rem;font-weight:600;text-decoration:none;border:1px solid var(--bdr);color:var(--dim);background:var(--surface);transition:all .2s}
.hdr-right a:hover{border-color:var(--bl);color:var(--bl);background:var(--bl-bg)}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;padding:20px 28px 8px}
.kpi{background:var(--card);border:1px solid var(--bdr);border-radius:12px;padding:16px 18px;box-shadow:var(--shadow);position:relative;overflow:hidden;cursor:pointer;transition:all .2s}
.kpi:hover{box-shadow:var(--shadow-md);transform:translateY(-1px)}
.kpi.active{border-color:var(--bl);box-shadow:0 0 0 2px rgba(37,99,235,.12),var(--shadow-md)}
.kpi::before{content:'';position:absolute;top:0;left:0;right:0;height:3px}
.kpi.k-total::before{background:linear-gradient(90deg,#2563eb,#0891b2)}
.kpi.k-full::before{background:linear-gradient(90deg,#059669,#34d399)}
.kpi.k-partial::before{background:linear-gradient(90deg,#d97706,#fbbf24)}
.kpi.k-none::before{background:linear-gradient(90deg,#dc2626,#f87171)}
.kpi-label{font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.7px;color:var(--dim)}
.kpi-row{display:flex;align-items:baseline;gap:6px;margin-top:6px}
.kpi-val{font-family:'JetBrains Mono',monospace;font-size:1.8rem;font-weight:800;line-height:1}
.k-total .kpi-val{color:var(--bl)} .k-full .kpi-val{color:var(--gn)} .k-partial .kpi-val{color:var(--yl)} .k-none .kpi-val{color:var(--rd)}
.kpi-unit{font-size:.7rem;color:var(--dim2);font-weight:500}
.kpi-bar{margin-top:10px;height:4px;border-radius:4px;background:#f1f5f9;overflow:hidden}
.kpi-bar-fill{height:100%;border-radius:4px;transition:width .8s ease}
.toolbar{padding:12px 28px 10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.search-wrap{position:relative;flex:1;min-width:200px;max-width:340px}
.search-wrap svg{position:absolute;left:12px;top:50%;transform:translateY(-50%);width:15px;height:15px;color:var(--dim2);pointer-events:none}
.toolbar input{width:100%;background:var(--card);border:1px solid var(--bdr);color:var(--tx);padding:9px 14px 9px 36px;border-radius:9px;font-size:.8rem;font-family:'DM Sans',sans-serif;outline:none;transition:all .2s;box-shadow:var(--shadow)}
.toolbar input:focus{border-color:var(--bl);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.toolbar input::placeholder{color:var(--dim2)}
.toolbar select{background:var(--card);border:1px solid var(--bdr);color:var(--tx2);padding:9px 14px;border-radius:9px;font-size:.78rem;font-family:'DM Sans',sans-serif;outline:none;cursor:pointer;box-shadow:var(--shadow)}
.btn{padding:9px 18px;border-radius:9px;font-size:.78rem;font-weight:600;font-family:'DM Sans',sans-serif;cursor:pointer;transition:all .2s;border:1px solid var(--bdr);background:var(--card);color:var(--tx2);box-shadow:var(--shadow);display:inline-flex;align-items:center;gap:5px}
.btn:hover{border-color:var(--bdr2);box-shadow:var(--shadow-md)}
.btn-primary{background:var(--bl);border-color:var(--bl);color:#fff;box-shadow:0 2px 8px rgba(37,99,235,.2)}
.btn-primary:hover{background:#1d4ed8;box-shadow:0 4px 14px rgba(37,99,235,.25);transform:translateY(-1px)}
.tbl-wrap{padding:4px 28px 20px;overflow-x:auto}
.tbl-card{background:var(--card);border:1px solid var(--bdr);border-radius:14px;overflow:hidden;box-shadow:var(--shadow)}
table{width:100%;border-collapse:collapse;font-size:.78rem}
thead{background:var(--card2)}
th{color:var(--dim);text-transform:uppercase;font-size:.6rem;letter-spacing:.7px;font-weight:700;padding:12px 8px;text-align:center;border-bottom:1px solid var(--bdr)}
th:first-child{text-align:center;width:38px;padding-left:16px}
th:nth-child(2){text-align:left;min-width:180px}
th:last-child{padding-right:16px}
td{padding:10px 8px;text-align:center;border-bottom:1px solid #f1f5f9;vertical-align:middle}
td:first-child{text-align:center;font-family:'JetBrains Mono',monospace;font-size:.68rem;color:var(--dim2);padding-left:16px}
td:nth-child(2){text-align:left} td:last-child{padding-right:16px}
tr{transition:background .12s} tr:hover td{background:#f8fafc} tr:last-child td{border-bottom:none}
.stn-name{font-weight:700;font-size:.82rem;color:var(--tx)}
.stn-sn{font-family:'JetBrains Mono',monospace;font-size:.6rem;color:var(--dim2);margin-top:2px;display:flex;align-items:center;gap:4px}
.dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.dot.on{background:var(--gn);box-shadow:0 0 5px rgba(5,150,105,.3)}
.dot.off{background:var(--rd);box-shadow:0 0 5px rgba(220,38,38,.2)}
.dot.mid{background:var(--yl);box-shadow:0 0 5px rgba(217,119,6,.2)}
.pill{display:inline-flex;align-items:center;justify-content:center;min-width:36px;padding:3px 8px;border-radius:7px;font-weight:700;font-size:.7rem;font-family:'JetBrains Mono',monospace;transition:transform .12s}
.pill:hover{transform:scale(1.06)}
.pill.ok{background:var(--gn-bg);color:var(--gn);border:1px solid var(--gn-bdr)}
.pill.warn{background:var(--yl-bg);color:var(--yl);border:1px solid var(--yl-bdr)}
.pill.crit{background:var(--rd-bg);color:var(--rd);border:1px solid var(--rd-bdr)}
.pill.na{background:#f8fafc;color:var(--dim2);border:1px solid #e2e8f0;font-size:.58rem}
.pill.err{background:#fef2f2;color:#ef4444;border:1px solid #fecaca;font-size:.55rem;letter-spacing:.3px}
.hb{font-family:'JetBrains Mono',monospace;font-weight:800;font-size:.85rem;padding:4px 10px;border-radius:8px;display:inline-block}
.hb.A{background:var(--gn-bg);color:var(--gn);border:1px solid var(--gn-bdr)}
.hb.B{background:#f7fee7;color:#65a30d;border:1px solid #bef264}
.hb.C{background:var(--yl-bg);color:var(--yl);border:1px solid var(--yl-bdr)}
.hb.D{background:#fff7ed;color:#ea580c;border:1px solid #fed7aa}
.hb.F{background:var(--rd-bg);color:var(--rd);border:1px solid var(--rd-bdr)}
.hb.X{background:#f8fafc;color:var(--dim2);border:1px solid #e2e8f0}
.cov{display:flex;align-items:center;gap:6px;justify-content:center}
.cov-track{width:42px;height:5px;border-radius:5px;background:#f1f5f9;overflow:hidden}
.cov-fill{height:100%;border-radius:5px;transition:width .6s ease}
.cov-txt{font-family:'JetBrains Mono',monospace;font-size:.7rem;font-weight:600;color:var(--dim)}
.ts-cell{font-family:'JetBrains Mono',monospace;font-size:.6rem;color:var(--dim2)}
.foot{padding:16px 28px;text-align:center;color:var(--dim2);font-size:.68rem;border-top:1px solid var(--bdr);background:var(--surface)}
.foot a{color:var(--bl);text-decoration:none;font-weight:600} .foot a:hover{text-decoration:underline}
.loading{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:80px;gap:14px}
.spinner{width:28px;height:28px;border:3px solid var(--bdr);border-top-color:var(--bl);border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.loading-text{color:var(--dim);font-size:.82rem;font-weight:500}
@keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.fade-row{animation:fadeUp .3s ease both}
@media(max-width:900px){.cards{grid-template-columns:repeat(2,1fr)}.tbl-wrap{padding:4px 10px 20px}.hdr,.toolbar{padding-left:14px;padding-right:14px}}
@media(max-width:540px){.cards{grid-template-columns:1fr 1fr}.kpi-val{font-size:1.4rem}}
</style>
</head>
<body>
<div class="hdr"><div class="hdr-left"><div class="hdr-logo">&#x1F4E1;</div><div><h1>Station Monitor</h1><div class="sub">EGAT EV AI Platform &#8212; Real-time Health Overview</div></div></div><div class="hdr-right"><a href="/heatmap">&#x1F3AF; Heatmap</a><a href="/dashboard">&#8592; Dashboard</a></div></div>
<div class="cards">
  <div class="kpi k-total" onclick="setFilter('all')"><div class="kpi-label">Total Stations</div><div class="kpi-row"><span class="kpi-val" id="kTotal">&#8212;</span><span class="kpi-unit">stations</span></div><div class="kpi-bar"><div class="kpi-bar-fill" id="kbTotal" style="width:100%;background:linear-gradient(90deg,#2563eb,#0891b2)"></div></div></div>
  <div class="kpi k-full" onclick="setFilter('full')"><div class="kpi-label">Full Coverage</div><div class="kpi-row"><span class="kpi-val" id="kFull">&#8212;</span><span class="kpi-unit">7/7 modules</span></div><div class="kpi-bar"><div class="kpi-bar-fill" id="kbFull" style="width:0%;background:linear-gradient(90deg,#059669,#34d399)"></div></div></div>
  <div class="kpi k-partial" onclick="setFilter('partial')"><div class="kpi-label">Partial Data</div><div class="kpi-row"><span class="kpi-val" id="kPartial">&#8212;</span><span class="kpi-unit">1&#8211;6 modules</span></div><div class="kpi-bar"><div class="kpi-bar-fill" id="kbPartial" style="width:0%;background:linear-gradient(90deg,#d97706,#fbbf24)"></div></div></div>
  <div class="kpi k-none" onclick="setFilter('none')"><div class="kpi-label">No Data</div><div class="kpi-row"><span class="kpi-val" id="kNone">&#8212;</span><span class="kpi-unit">offline</span></div><div class="kpi-bar"><div class="kpi-bar-fill" id="kbNone" style="width:0%;background:linear-gradient(90deg,#dc2626,#f87171)"></div></div></div>
</div>
<div class="toolbar"><div class="search-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input type="text" id="search" placeholder="Search station name or SN..." oninput="filterTable()"></div><select id="filterMod" onchange="filterTable()"><option value="all">All Stations</option><option value="full">Full Coverage (7/7)</option><option value="partial">Partial Data</option><option value="none">No Data</option></select><button class="btn btn-primary" onclick="loadData()">&#8635; Refresh</button><a href="/heatmap" class="btn" style="text-decoration:none">&#x1F3AF; Heatmap</a></div>
<div class="tbl-wrap" id="grid"><div class="tbl-card"><div class="loading"><div class="spinner"></div><div class="loading-text">Loading station data...</div></div></div></div>
<div class="foot">EGAT EV AI Platform &#183; Station Monitor &#183; <span id="buildInfo">Auto-refresh 60s</span> &#183; <a href="/dashboard">Dashboard</a></div>
<script>
var DATA=[],CUR='all';
function setFilter(f){CUR=f;document.getElementById('filterMod').value=f;filterTable();document.querySelectorAll('.kpi').forEach(function(k){k.classList.remove('active')});var m={all:'k-total',full:'k-full',partial:'k-partial',none:'k-none'};var e=document.querySelector('.kpi.'+m[f]);if(e)e.classList.add('active');}
function grade(s){if(s===null||s===undefined)return'-';if(s>=80)return'A';if(s>=60)return'B';if(s>=40)return'C';if(s>=20)return'D';return'F';}
function pill(m){if(!m)return '<span class="pill na">\u2014</span>';if(m.error)return '<span class="pill err">ERR</span>';var h=m.health;if(h===null||h===undefined)return '<span class="pill na">\u2014</span>';return '<span class="pill '+(h>=80?'ok':h>=50?'warn':'crit')+'">'+h+'</span>';}
function renderSummary(s){var t=Math.max(s.total_stations,1);document.getElementById('kTotal').textContent=s.total_stations;document.getElementById('kFull').textContent=s.full_coverage;document.getElementById('kPartial').textContent=s.partial;document.getElementById('kNone').textContent=s.no_data;document.getElementById('kbFull').style.width=Math.round(s.full_coverage/t*100)+'%';document.getElementById('kbPartial').style.width=Math.round(s.partial/t*100)+'%';document.getElementById('kbNone').style.width=Math.round(s.no_data/t*100)+'%';}
function renderTable(data){
  if(!data.length){document.getElementById('grid').innerHTML='<div class="tbl-card"><div class="loading"><div class="loading-text">No stations match filter</div></div></div>';return}
  var h='<div class="tbl-card"><table><thead><tr><th>#</th><th>Station</th><th>M1</th><th>M2</th><th>M3</th><th>M4</th><th>M5</th><th>M6</th><th>M7</th><th>Health</th><th>Coverage</th><th>Updated</th></tr></thead><tbody>';
  data.forEach(function(s,idx){
    var g=grade(s.system_health);var hb=g==='-'?'X':g;
    var ts=s.last_updated?new Date(s.last_updated).toLocaleString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit',day:'2-digit',month:'short'}):'\u2014';
    var dc=s.ok_count>=7?'on':s.ok_count===0?'off':'mid';
    var cp=Math.round(s.ok_count/7*100);
    var cc=s.ok_count>=7?'var(--gn)':s.ok_count===0?'var(--rd)':'var(--yl)';
    h+='<tr class="fade-row" style="animation-delay:'+(idx*12)+'ms"><td>'+(idx+1)+'</td>';
    h+='<td><div class="stn-name">'+(s.name&&s.name!==s.sn?s.name:s.sn)+'</div><div class="stn-sn"><span class="dot '+dc+'"></span>'+s.sn+(s.province?' \u00B7 '+s.province:'')+'</div></td>';
    for(var i=1;i<=7;i++){h+='<td>'+pill(s.modules['m'+i])+'</td>';}
    h+='<td><span class="hb '+hb+'">'+(s.system_health!==null&&s.system_health!==undefined?s.system_health+'%':'\u2014')+'</span></td>';
    h+='<td><div class="cov"><div class="cov-track"><div class="cov-fill" style="width:'+cp+'%;background:'+cc+'"></div></div><span class="cov-txt">'+s.ok_count+'/7</span></div></td>';
    h+='<td><span class="ts-cell">'+ts+'</span></td></tr>';
  });
  h+='</tbody></table></div>';document.getElementById('grid').innerHTML=h;
}
function filterTable(){var q=document.getElementById('search').value.toLowerCase();var f=document.getElementById('filterMod').value;var r=DATA.filter(function(s){if(q&&!s.sn.toLowerCase().includes(q)&&!(s.name||'').toLowerCase().includes(q))return false;if(f==='full'&&s.ok_count<7)return false;if(f==='partial'&&(s.ok_count===0||s.ok_count>=7))return false;if(f==='none'&&s.ok_count!==0)return false;return true;});renderTable(r);}
async function loadData(){try{var r=await fetch('/api/monitor/overview');var d=await r.json();if(d.error){document.getElementById('grid').innerHTML='<div class="tbl-card"><div class="loading"><div class="loading-text" style="color:var(--rd)">'+d.error+'</div></div></div>';return;}DATA=d.stations||[];renderSummary(d.summary||{total_stations:0,full_coverage:0,partial:0,no_data:0});filterTable();var bi=document.getElementById('buildInfo');if(bi){var ts=d.timestamp?new Date(d.timestamp).toLocaleString('en-GB'):'\u2014';bi.textContent='Last cycle: '+ts+(d.build_ms?' \u00B7 '+d.build_ms+'ms':'');}}catch(e){document.getElementById('grid').innerHTML='<div class="tbl-card"><div class="loading"><div class="loading-text" style="color:var(--rd)">'+e.message+'</div></div></div>';}}
loadData();setInterval(loadData,120000);
</script>
</body>
</html>"""


    @app.get("/monitor", response_class=HTMLResponse)
    async def monitor_page():
        return MONITOR_HTML

    # ════════════════════════════════════════════════
    # HEATMAP — All stations health at a glance
    # ════════════════════════════════════════════════



    HEATMAP_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EDS AI — Health Heatmap</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;display:flex;flex-direction:column;height:100vh}
.bar{background:#fff;border-bottom:1px solid #e2e8f0;padding:8px 20px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;box-shadow:0 1px 4px rgba(0,0,0,.05);gap:10px;flex-wrap:wrap}
.bar-left{display:flex;align-items:center;gap:10px}
.bar-logo{width:30px;height:30px;background:linear-gradient(135deg,#2563eb,#0891b2);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.9rem;box-shadow:0 2px 8px rgba(37,99,235,.2)}
.bar h1{font-size:.95rem;font-weight:800;color:#1e293b}
.bar .sub{font-size:.58rem;color:#64748b;font-weight:500}
.legend{display:flex;gap:1px;align-items:center;margin-left:14px;padding-left:14px;border-left:1px solid #e2e8f0}
.legend-bar{width:120px;height:10px;border-radius:5px;background:linear-gradient(90deg,#dc2626,#ef4444,#f59e0b,#eab308,#84cc16,#22c55e,#16a34a);box-shadow:0 1px 3px rgba(0,0,0,.08)}
.legend-labels{display:flex;justify-content:space-between;width:120px;margin-left:0}
.legend-labels span{font-size:.48rem;color:#94a3b8;font-weight:700;font-family:'JetBrains Mono',monospace}
.legend-na{display:flex;align-items:center;gap:3px;font-size:.52rem;color:#94a3b8;font-weight:600;margin-left:8px}
.legend-na-swatch{width:12px;height:10px;border-radius:3px;background:#e2e8f0}
.bar-right{display:flex;gap:6px;align-items:center}
.bar-right a,.bar-right button{padding:5px 12px;border-radius:7px;font-size:.66rem;font-weight:600;text-decoration:none;border:1px solid #e2e8f0;color:#64748b;background:#fff;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all .15s}
.bar-right a:hover,.bar-right button:hover{border-color:#2563eb;color:#2563eb;background:#eff6ff}
.stats{display:flex;gap:10px;font-size:.62rem;font-weight:700;color:#64748b}
.stats .v{color:#1e293b;font-size:.72rem;font-family:'JetBrains Mono',monospace}
.grid-wrap{flex:1;padding:6px;overflow:hidden;display:flex;align-items:center;justify-content:center}
#heatmap{display:grid;gap:2px;width:100%;height:100%}
.cell{border-radius:4px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;transition:all .15s;position:relative;overflow:hidden;min-width:0;min-height:0;box-shadow:inset 0 1px 0 rgba(255,255,255,.25)}
.cell:hover{transform:scale(1.1);z-index:10;box-shadow:0 4px 20px rgba(0,0,0,.18),inset 0 1px 0 rgba(255,255,255,.25);border-radius:6px}
.cell-name{font-size:clamp(.3rem,.55vw,.55rem);font-weight:700;color:#fff;text-align:center;line-height:1.1;padding:0 2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%;text-shadow:0 1px 2px rgba(0,0,0,.3)}
.cell-pct{font-family:'JetBrains Mono',monospace;font-size:clamp(.38rem,.7vw,.7rem);font-weight:800;color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.3)}
.cell.nd{background:#e2e8f0!important;box-shadow:none}
.cell.nd .cell-name{color:#94a3b8;text-shadow:none}
.cell.nd .cell-pct{color:#94a3b8;text-shadow:none}
.tip{display:none;position:fixed;z-index:100;background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:14px 18px;box-shadow:0 12px 40px rgba(0,0,0,.1);font-size:.75rem;pointer-events:none;min-width:230px;color:#1e293b}
.tip.show{display:block;animation:tipIn .15s ease}
@keyframes tipIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
.tip-name{font-weight:800;font-size:.88rem;color:#1e293b}
.tip-sn{font-family:'JetBrains Mono',monospace;font-size:.6rem;color:#64748b;margin-top:1px}
.tip-health{font-family:'JetBrains Mono',monospace;font-size:1.6rem;font-weight:800;margin:8px 0 2px}
.tip-cov{font-size:.65rem;color:#64748b;margin-bottom:8px}
.tip-label{font-size:.5rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.6px;font-weight:700;margin-bottom:4px}
.tip-mods{display:grid;grid-template-columns:repeat(7,1fr);gap:3px}
.tip-mod{text-align:center;padding:5px 0;border-radius:5px;font-family:'JetBrains Mono',monospace;font-size:.58rem;font-weight:700}
.tip-mod.ok{background:#ecfdf5;color:#059669;border:1px solid #a7f3d0}
.tip-mod.warn{background:#fffbeb;color:#d97706;border:1px solid #fde68a}
.tip-mod.crit{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
.tip-mod.na{background:#f8fafc;color:#94a3b8;border:1px solid #e2e8f0}
</style>
</head>
<body>
<div class="bar">
  <div class="bar-left">
    <div class="bar-logo">&#x1F3AF;</div>
    <div><h1>Health Heatmap</h1><div class="sub">EGAT EV AI Platform &#8212; All stations at a glance</div></div>
    <div class="legend">
      <div>
        <div class="legend-bar"></div>
        <div class="legend-labels"><span>0%</span><span>50%</span><span>100%</span></div>
      </div>
      <div class="legend-na"><div class="legend-na-swatch"></div>N/A</div>
    </div>
  </div>
  <div class="bar-right">
    <div class="stats"><div>Stations: <span class="v" id="sTotal">&#8212;</span></div><div>Avg: <span class="v" id="sAvg">&#8212;</span></div></div>
    <button onclick="loadData()">&#8635; Refresh</button>
    <a href="/monitor">&#x1F4CB; Table</a>
    <a href="/dashboard">&#8592; Dashboard</a>
  </div>
</div>
<div class="grid-wrap"><div id="heatmap"></div></div>
<div class="tip" id="tip"><div class="tip-name" id="tipName"></div><div class="tip-sn" id="tipSn"></div><div class="tip-health" id="tipHealth"></div><div class="tip-cov" id="tipCov"></div><div class="tip-label">MODULE HEALTH</div><div class="tip-mods" id="tipMods"></div></div>
<script>
var DATA=[];
function hc(h){
  if(h===null||h===undefined)return '#e2e8f0';
  // Red(0) -> Yellow(50) -> Green(100)
  var r,g,b;
  if(h<=50){
    // Red to Yellow: R stays high, G increases
    var t=h/50;
    r=Math.round(220-(220-234)*t);
    g=Math.round(38+(179-38)*t);
    b=Math.round(38+(8-38)*t);
  }else{
    // Yellow to Green: R decreases, G stays high
    var t=(h-50)/50;
    r=Math.round(234-(234-22)*t);
    g=Math.round(179+(163-179)*t);
    b=Math.round(8+(74-8)*t);
  }
  return 'rgb('+r+','+g+','+b+')';
}
function calcGrid(n){var a=document.querySelector('.grid-wrap');var W=a.clientWidth-12,H=a.clientHeight-12;var bc=1,bs=0;for(var c=1;c<=n;c++){var r=Math.ceil(n/c);var cw=W/c,ch=H/r;var s=Math.min(cw,ch)*Math.min(cw/ch,ch/cw);if(s>bs){bs=s;bc=c;}}return{cols:bc,rows:Math.ceil(n/bc)};}
function render(){
  var el=document.getElementById('heatmap');
  if(!DATA.length){el.innerHTML='<div style="text-align:center;color:#94a3b8;font-size:.9rem;grid-column:1/-1;align-self:center">Loading...</div>';return}
  var g=calcGrid(DATA.length);el.style.gridTemplateColumns='repeat('+g.cols+',1fr)';el.style.gridTemplateRows='repeat('+g.rows+',1fr)';
  var html='';
  DATA.forEach(function(s,i){var h=s.system_health;var bg=hc(h);var cls=h===null||h===undefined?'cell nd':'cell';
    var name=s.name&&s.name!==s.sn?s.name:s.sn;var short=name.replace(/^PT_/,'').replace(/_/g,' ');if(short.length>14)short=short.substring(0,13)+'..';
    html+='<div class="'+cls+'" style="background:'+bg+'" onmouseenter="showTip(event,'+i+')" onmouseleave="hideTip()" onmousemove="moveTip(event)"><div class="cell-name">'+short+'</div><div class="cell-pct">'+(h!==null&&h!==undefined?h+'%':'\u2014')+'</div></div>';
  });el.innerHTML=html;
}
function showTip(ev,i){var s=DATA[i];if(!s)return;var tip=document.getElementById('tip');
  document.getElementById('tipName').textContent=s.name&&s.name!==s.sn?s.name:s.sn;
  document.getElementById('tipSn').textContent='SN: '+s.sn+(s.province?' \u00B7 '+s.province:'');
  var h=s.system_health;var he=document.getElementById('tipHealth');
  he.textContent=h!==null&&h!==undefined?h+'%':'No Data';
  he.style.color=hc(h)==='#e2e8f0'?'#94a3b8':hc(h);
  document.getElementById('tipCov').textContent='Coverage: '+(s.ok_count||0)+'/7 modules';
  var mh='';for(var m=1;m<=7;m++){var mod=s.modules?s.modules['m'+m]:null;var v=mod?mod.health:null;var c=v===null||v===undefined?'na':v>=80?'ok':v>=50?'warn':'crit';mh+='<div class="tip-mod '+c+'">M'+m+'<br>'+(v!==null&&v!==undefined?v:'\u2014')+'</div>';}
  document.getElementById('tipMods').innerHTML=mh;tip.classList.add('show');moveTip(ev);
}
function moveTip(ev){var t=document.getElementById('tip');var x=ev.clientX+14,y=ev.clientY+14;if(x+240>window.innerWidth)x=ev.clientX-240;if(y+210>window.innerHeight)y=ev.clientY-210;t.style.left=x+'px';t.style.top=y+'px';}
function hideTip(){document.getElementById('tip').classList.remove('show')}
async function loadData(){try{var r=await fetch('/api/monitor/overview');var d=await r.json();if(d.error)return;DATA=d.stations||[];document.getElementById('sTotal').textContent=DATA.length;var sum=0,cnt=0;DATA.forEach(function(s){if(s.system_health!==null&&s.system_health!==undefined){sum+=s.system_health;cnt++}});document.getElementById('sAvg').textContent=cnt?Math.round(sum/cnt)+'%':'\u2014';render();}catch(e){console.error(e)}}
window.addEventListener('resize',function(){if(DATA.length)render()});
loadData();setInterval(loadData,120000);
</script>
</body>
</html>"""

    @app.get("/heatmap", response_class=HTMLResponse)
    async def heatmap_page():
        return HTMLResponse(content=HEATMAP_HTML, status_code=200)

    # ════════════════════════════════════════════════
    # HEALTH HISTORY — Multi-station %Health trend
    # ════════════════════════════════════════════════
    @app.get("/api/health/history/all")
    async def health_history_all(range: str = "daily"):
        """Return health history for all stations from eds_system_health."""
        if mongo_client is None:
            return {"error": "no_db", "stations": []}
        try:
            hdb = mongo_client["eds_system_health"]
            cols = [c for c in hdb.list_collection_names() if not c.startswith("system.") and c != "_monitor_summary"]
            hours = {"daily": 24, "weekly": 168, "monthly": 720}.get(range, 24)
            since = datetime.now(timezone.utc) - timedelta(hours=hours)
            # Get station name mapping
            meta = {}
            try:
                for c in mongo_client["iMPS"]["charger"].find({}, {"_id": 0}):
                    sn = c.get("SN", "")
                    if sn:
                        meta[sn] = c.get("station_id") or c.get("StationName") or sn
            except:
                pass
            stations = []
            for sn in sorted(cols):
                cursor = hdb[sn].find({"timestamp": {"$gte": since}}, {"_id": 0}).sort("timestamp", 1).limit(500)
                points = []
                for doc in cursor:
                    ts = doc.get("timestamp")
                    sc = doc.get("score")
                    if sc is not None:
                        points.append({
                            "t": ts.isoformat() if hasattr(ts, "isoformat") else str(ts),
                            "s": sc,
                        })
                if points:
                    stations.append({
                        "sn": sn,
                        "name": meta.get(sn, sn),
                        "data": points,
                        "latest": points[-1]["s"] if points else None,
                    })
            stations.sort(key=lambda x: -(x.get("latest") or 0))
            return {"stations": stations, "count": len(stations), "range": range, "hours": hours}
        except Exception as e:
            logger.error(f"[HEALTH-HIST-ALL] {e}")
            return {"error": str(e), "stations": []}

    HEALTH_HIST_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EDS AI — Health History</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;min-height:100vh;display:flex;flex-direction:column}
.bar{background:#fff;border-bottom:1px solid #e2e8f0;padding:12px 24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.bar-left{display:flex;align-items:center;gap:10px}
.bar-logo{width:32px;height:32px;background:linear-gradient(135deg,#7c3aed,#2563eb);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1rem;box-shadow:0 2px 8px rgba(124,58,237,.2)}
.bar h1{font-size:1rem;font-weight:800;color:#1e293b}
.bar .sub{font-size:.62rem;color:#64748b;font-weight:500}
.bar-right{display:flex;gap:6px;align-items:center}
.bar-right a,.bar-right button{padding:6px 14px;border-radius:7px;font-size:.7rem;font-weight:600;text-decoration:none;border:1px solid #e2e8f0;color:#64748b;background:#fff;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all .15s}
.bar-right a:hover,.bar-right button:hover{border-color:#2563eb;color:#2563eb;background:#eff6ff}
.controls{padding:14px 24px 8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.range-btn{padding:7px 18px;border-radius:8px;border:1px solid #e2e8f0;background:#fff;color:#64748b;font-size:.75rem;font-weight:600;font-family:'DM Sans',sans-serif;cursor:pointer;transition:all .15s}
.range-btn:hover{border-color:#2563eb;color:#2563eb}
.range-btn.active{background:#2563eb;color:#fff;border-color:#2563eb;box-shadow:0 2px 8px rgba(37,99,235,.25)}
.info{margin-left:auto;font-size:.7rem;color:#94a3b8;font-family:'JetBrains Mono',monospace}
.chart-wrap{flex:1;padding:8px 24px 16px;min-height:0}
.chart-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 1px 4px rgba(0,0,0,.04);padding:16px;height:100%;display:flex;flex-direction:column}
.chart-card canvas{flex:1;min-height:0}
.legend-wrap{padding:8px 24px 12px;overflow-x:auto}
.legend-grid{display:flex;flex-wrap:wrap;gap:4px}
.lg-item{display:flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;border:1px solid #e2e8f0;background:#fff;font-size:.6rem;font-weight:600;color:#475569;cursor:pointer;transition:all .12s;white-space:nowrap}
.lg-item:hover{border-color:#2563eb;background:#eff6ff}
.lg-item.hidden{opacity:.35}
.lg-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.lg-val{font-family:'JetBrains Mono',monospace;font-weight:700;font-size:.6rem}
.loading{display:flex;align-items:center;justify-content:center;flex:1;color:#94a3b8;font-size:.85rem;gap:10px}
.spinner{width:22px;height:22px;border:3px solid #e2e8f0;border-top-color:#2563eb;border-radius:50%;animation:sp .7s linear infinite}
@keyframes sp{to{transform:rotate(360deg)}}
</style>
</head>
<body>
<div class="bar">
  <div class="bar-left">
    <div class="bar-logo">&#x1F4C8;</div>
    <div><h1>Health History</h1><div class="sub">EGAT EV AI Platform &#8212; %Health trend over time</div></div>
  </div>
  <div class="bar-right">
    <a href="/heatmap">&#x1F3AF; Heatmap</a>
    <a href="/monitor">&#x1F4CB; Table</a>
    <a href="/dashboard">&#8592; Dashboard</a>
  </div>
</div>
<div class="controls">
  <button class="range-btn active" id="rbDaily" onclick="setRange('daily')">Daily (24h)</button>
  <button class="range-btn" id="rbWeekly" onclick="setRange('weekly')">Weekly (7d)</button>
  <button class="range-btn" id="rbMonthly" onclick="setRange('monthly')">Monthly (30d)</button>
  <span class="info" id="info">Loading...</span>
</div>
<div class="chart-wrap" id="chartWrap">
  <div class="chart-card">
    <canvas id="chart"></canvas>
  </div>
</div>
<div class="legend-wrap"><div class="legend-grid" id="legend"></div></div>

<script>
var RANGE='daily',CHART=null,STATIONS=[],HIDDEN={};
var COLORS=['#2563eb','#dc2626','#059669','#d97706','#7c3aed','#0891b2','#e11d48','#65a30d','#ea580c','#6366f1',
  '#0d9488','#be185d','#4f46e5','#ca8a04','#9333ea','#0284c7','#b91c1c','#15803d','#c2410c','#7e22ce',
  '#047857','#9f1239','#1d4ed8','#a16207','#6d28d9','#0e7490','#991b1b','#166534','#9a3412','#5b21b6'];

function setRange(r){
  RANGE=r;
  document.querySelectorAll('.range-btn').forEach(function(b){b.classList.remove('active')});
  document.getElementById('rb'+r.charAt(0).toUpperCase()+r.slice(1)).classList.add('active');
  loadData();
}
function fmtTs(iso){
  try{var d=new Date(iso);if(isNaN(d))return iso;
    var hh=String(d.getHours()).padStart(2,'0'),mm=String(d.getMinutes()).padStart(2,'0');
    var dd=d.getDate(),mon=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
    if(RANGE==='daily')return hh+':'+mm;
    if(RANGE==='weekly')return dd+' '+mon+' '+hh+':'+mm;
    return dd+' '+mon;
  }catch(e){return iso}
}
function buildChart(){
  var ctx=document.getElementById('chart');
  var existing=Chart.getChart(ctx);
  if(existing){existing.destroy();}
  if(CHART){try{CHART.destroy();}catch(e){} CHART=null;}
  if(!STATIONS.length){document.getElementById('info').textContent='No data';return;}
  // Build unified time labels from all visible stations
  var tsSet={};
  STATIONS.forEach(function(st){
    if(HIDDEN[st.sn])return;
    st.data.forEach(function(p){tsSet[p.t]=1;});
  });
  var allTs=Object.keys(tsSet).sort();
  // Downsample if too many points
  if(allTs.length>300){var step=Math.ceil(allTs.length/300);allTs=allTs.filter(function(_,i){return i%step===0});}
  var labels=allTs.map(fmtTs);
  var tsIndex={};allTs.forEach(function(t,i){tsIndex[t]=i;});
  var datasets=[];
  STATIONS.forEach(function(st,i){
    if(HIDDEN[st.sn])return;
    var col=COLORS[i%COLORS.length];
    var arr=new Array(allTs.length).fill(null);
    st.data.forEach(function(p){var idx=tsIndex[p.t];if(idx!==undefined)arr[idx]=p.s;});
    datasets.push({
      label:st.name!==st.sn?st.name:st.sn,
      data:arr,
      borderColor:col,
      backgroundColor:col+'18',
      borderWidth:1.8,
      pointRadius:0,
      pointHoverRadius:4,
      tension:0.3,
      fill:false,
      spanGaps:true,
    });
  });
  CHART=new Chart(ctx,{
    type:'line',
    data:{labels:labels,datasets:datasets},
    options:{
      responsive:true,maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{
        legend:{display:false},
        tooltip:{
          backgroundColor:'rgba(255,255,255,.95)',titleColor:'#1e293b',bodyColor:'#475569',borderColor:'#e2e8f0',borderWidth:1,
          titleFont:{family:'DM Sans',size:12,weight:'700'},bodyFont:{family:'JetBrains Mono',size:11},
          padding:10,cornerRadius:8,boxPadding:4,
          callbacks:{label:function(c){return c.parsed.y!==null?c.dataset.label+': '+c.parsed.y+'%':null}},
          filter:function(item){return item.parsed.y!==null}
        }
      },
      scales:{
        x:{ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:10},maxTicksLimit:14,maxRotation:0},
          grid:{color:'rgba(0,0,0,.04)'}},
        y:{min:0,max:100,
          ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:10},callback:function(v){return v+'%'},stepSize:20},
          grid:{color:'rgba(0,0,0,.04)'}}
      }
    }
  });
}
function buildLegend(){
  var el=document.getElementById('legend');
  var html='';
  STATIONS.forEach(function(st,i){
    var col=COLORS[i%COLORS.length];
    var cls=HIDDEN[st.sn]?'lg-item hidden':'lg-item';
    var name=st.name!==st.sn?st.name:st.sn;
    var short=name.length>20?name.substring(0,19)+'..':name;
    html+='<div class="'+cls+'" onclick="toggleLine(\''+st.sn+'\','+i+')" title="'+name+' ('+st.sn+')">';
    html+='<div class="lg-dot" style="background:'+col+'"></div>';
    html+='<span>'+short+'</span>';
    html+='<span class="lg-val" style="color:'+col+'">'+(st.latest!==null?st.latest+'%':'\u2014')+'</span>';
    html+='</div>';
  });
  el.innerHTML=html;
}
function toggleLine(sn,idx){
  HIDDEN[sn]=!HIDDEN[sn];
  buildChart();buildLegend();
}
async function loadData(){
  document.getElementById('info').textContent='Loading...';
  try{
    var r=await fetch('/api/health/history/all?range='+RANGE);
    var d=await r.json();
    if(d.error){document.getElementById('info').textContent='Error: '+d.error;return;}
    STATIONS=d.stations||[];
    document.getElementById('info').textContent=STATIONS.length+' stations \u00B7 '+RANGE+' \u00B7 '+(d.hours||24)+'h';
    buildChart();buildLegend();
  }catch(e){document.getElementById('info').textContent=e.message;}
}
loadData();setInterval(loadData,120000);
</script>
</body>
</html>"""

    @app.get("/health-history", response_class=HTMLResponse)
    async def health_history_page():
        return HTMLResponse(content=HEALTH_HIST_HTML, status_code=200)

    # ════════════════════════════════════════════════
    # HEALTH CHECK
    # ════════════════════════════════════════════════
    @app.get("/health")
    async def health():
        return {"status": "healthy", "mode": "frontend-only",
                "results_db": RESULTS_DB_NAME,
                "active_station": STATION_CONFIG["active_sn"]}

    # ── Start Server ──
    import uvicorn
    logger.info(f"🌐 Frontend server → http://203.154.130.132:{port}/dashboard")
    logger.info(f"📊 Reads results from MongoDB: {RESULTS_DB_NAME}")
    uvicorn.run(app, host=host, port=port, log_level="info")


# ════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="EDS AI Frontend Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    run_server(args.host, args.port)
