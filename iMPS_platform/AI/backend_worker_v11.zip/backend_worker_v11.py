"""
EGAT EV AI Platform — Backend Worker
Processes all AI modules for all stations, writes results to MongoDB.
Run: python backend_worker.py [--interval 120] [--once]
"""
import os, sys, time, json, logging, signal, argparse, math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional, Any
from collections import deque

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import joblib

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("eds-backend")

# ====================================================================
# CONFIG
# ====================================================================
MODEL_DIR = os.getenv("MODEL_DIR", "model_outputs")
COND_MODEL_DIR = os.getenv("COND_MODEL_DIR", "condition_models")

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEQ_LEN = 64
NUM_FEATURES = 49
NUM_CLASSES = 7
BINARY_THRESHOLD = 0.5
BUFFER_MAX = 10_000

# ====================================================================
# MQTT CONFIG (Rule-Based Monitoring)
# ====================================================================
MQTT_BROKER = os.getenv("MQTT_BROKER", "212.80.215.42")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = "OCPP/Klongluang3/PLC"

# ICP State Machine (IEC 61851-1 / Control Pilot states)
ICP_STATES = {
    0: "Inactive", 1: "A1 (Not plugged, PWM off)", 2: "B1 (Plugged, PWM off)",
    3: "C1 (Vehicle ready, PWM off)", 4: "D1 (Ready+Vent, PWM off)",
    5: "A2 (Not plugged, PWM on)", 6: "B2 (Plugged, PWM on)",
    7: "C2 (Charging, PWM on)", 8: "D2 (Charging+Vent, PWM on)",
    9: "E (Fault, CP=0V)", 10: "Error",
}
# USLink State (ISO 15118-2 / DIN SPEC 70121 V2G session states)
USL_STATES = {
    0: "Ready", 1: "Init", 2: "SLAC ok", 3: "SECC ok",
    4: "SupportedAppProtocol", 5: "SessionSetup", 6: "ServiceDiscovery",
    7: "ServicePaymentSelection", 8: "ContractAuthentication",
    9: "ChargeParameterDiscovery", 10: "CableCheck", 11: "PreCharge",
    12: "PowerDelivery", 13: "CurrentDemand", 14: "WeldingDetection",
    15: "SessionStop",
}

# CCS Type 2 375A — Boost Mode (Phoenix Contact Lab Test)
# {ambient_temp: {current_A: max_minutes or None=Continuous}}
CCS_DERATING = {
    20: {300:None,350:None,375:43,400:24,450:None,500:None},
    30: {300:None,350:None,375:57,400:28,450:17,500:None},
    40: {300:None,350:None,375:48,400:32,450:18,500:13},
    50: {300:None,350:35,375:26,400:19,450:12,500:9},
    55: {300:62,350:24,375:18,400:16,450:10,500:6},
}

ANOMALY_GROUPS = [
    "anomaly_voltage","anomaly_current","anomaly_power",
    "anomaly_soc","anomaly_thermal","anomaly_communication","anomaly_session",
]

GROUP_THRESHOLDS = {
    "anomaly_voltage": 0.5, "anomaly_current": 0.4, "anomaly_power": 0.5,
    "anomaly_soc": 0.5, "anomaly_thermal": 0.3, "anomaly_communication": 0.3,
    "anomaly_session": 0.4,
}

STANDARD_REFS = {
    "anomaly_voltage": {
        "severity":"HIGH",
        "standards":["ISO 15118-2 §8.4.5.4 (±5%)","DIN 70121 PreCharge (|ΔV|≤20V)","IEC 61851-23 ±2%"],
        "action":"Check voltage regulation & PreCharge circuit",
    },
    "anomaly_current": {
        "severity":"HIGH",
        "standards":["ISO 15118-2 FAILED_ChargingCurrentdifferential","DIN 70121 CurrentDemand (|ΔI|≤5A)"],
        "action":"Inspect current control loop & power electronics",
    },
    "anomaly_power": {
        "severity":"MEDIUM",
        "standards":["DIN 70121 CCS1.0 max 80kW","IEC 61851-23 rated 150kW"],
        "action":"Verify power sharing & connector load balancing",
    },
    "anomaly_soc": {
        "severity":"MEDIUM",
        "standards":["ISO 15118-2 Table 101 EVRESSSOC","DIN 70121 DC_EVStatus"],
        "action":"Check V2G communication & EV BMS reporting",
    },
    "anomaly_thermal": {
        "severity":"CRITICAL",
        "standards":["IEC 61851-23 §101.2 (-35°C~+55°C)","IEC 62196-3 Gun ≤90°C"],
        "action":"⚠️ URGENT: Check cooling, reduce power, inspect gun connector",
    },
    "anomaly_communication": {
        "severity":"CRITICAL",
        "standards":["ISO 15118-2 V2G Session","DIN 70121 PLC","CurrentDemandRes timeout"],
        "action":"⚠️ URGENT: Check PLC module, restart communication controller",
    },
    "anomaly_session": {
        "severity":"MEDIUM",
        "standards":["ISO 15118-2 [V2G2-838] Ramp-Down","IEC 61851-23 Module Sequencing"],
        "action":"Review session logs & power module sequencing",
    },
}


# ====================================================================
# MODEL DEFINITIONS
# ====================================================================
class ResBlock1D(nn.Module):
    def __init__(self, ch, ks=3, d=1):
        super().__init__()
        p = (ks-1)*d//2
        self.conv = nn.Sequential(nn.Conv1d(ch,ch,ks,padding=p,dilation=d),
            nn.BatchNorm1d(ch),nn.GELU(),nn.Conv1d(ch,ch,ks,padding=p,dilation=d),nn.BatchNorm1d(ch))
        self.act = nn.GELU()
    def forward(self,x): return self.act(x+self.conv(x))

class DeepAutoencoder(nn.Module):
    def __init__(self,d,z=16):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(d,512),nn.BatchNorm1d(512),nn.GELU(),nn.Dropout(.2),
            nn.Linear(512,256),nn.BatchNorm1d(256),nn.GELU(),nn.Dropout(.2),
            nn.Linear(256,128),nn.BatchNorm1d(128),nn.GELU(),nn.Dropout(.1),
            nn.Linear(128,64),nn.BatchNorm1d(64),nn.GELU(),nn.Linear(64,z))
        self.decoder = nn.Sequential(nn.Linear(z,64),nn.BatchNorm1d(64),nn.GELU(),nn.Dropout(.1),
            nn.Linear(64,128),nn.BatchNorm1d(128),nn.GELU(),nn.Dropout(.2),
            nn.Linear(128,256),nn.BatchNorm1d(256),nn.GELU(),nn.Dropout(.2),
            nn.Linear(256,512),nn.BatchNorm1d(512),nn.GELU(),nn.Linear(512,d))
    def forward(self,x): z=self.encoder(x); return self.decoder(z),z

class CNN1D_Anomaly(nn.Module):
    def __init__(self,d,seq=64,nc=7):
        super().__init__()
        self.input_proj=nn.Sequential(nn.Conv1d(d,256,7,padding=3),nn.BatchNorm1d(256),nn.GELU())
        self.res_blocks=nn.Sequential(ResBlock1D(256,7,1),ResBlock1D(256,5,2),ResBlock1D(256,5,4),
            ResBlock1D(256,3,8),ResBlock1D(256,3,16))
        self.pool=nn.AdaptiveAvgPool1d(1)
        self.classifier=nn.Sequential(nn.Linear(256,256),nn.GELU(),nn.Dropout(.3),
            nn.Linear(256,128),nn.GELU(),nn.Dropout(.2))
        self.head_binary=nn.Linear(128,1); self.head_multi=nn.Linear(128,nc)
    def forward(self,x):
        x=x.permute(0,2,1); x=self.pool(self.res_blocks(self.input_proj(x))).squeeze(-1)
        f=self.classifier(x); return self.head_binary(f),self.head_multi(f),f

class Attention(nn.Module):
    def __init__(self,d,h=8):
        super().__init__()
        self.attn=nn.MultiheadAttention(d,h,dropout=.1,batch_first=True); self.norm=nn.LayerNorm(d)
    def forward(self,x): o,_=self.attn(x,x,x); return self.norm(x+o)

class BiLSTM_Attention(nn.Module):
    def __init__(self,d,h=256,nl=3,nc=7):
        super().__init__()
        self.input_proj=nn.Sequential(nn.Linear(d,h),nn.LayerNorm(h),nn.GELU())
        self.lstm=nn.LSTM(h,h,nl,batch_first=True,bidirectional=True,dropout=.3); self.attn=Attention(h*2,8)
        self.pool=nn.AdaptiveAvgPool1d(1)
        self.classifier=nn.Sequential(nn.Linear(h*2,256),nn.GELU(),nn.Dropout(.3),
            nn.Linear(256,128),nn.GELU(),nn.Dropout(.2))
        self.head_binary=nn.Linear(128,1); self.head_multi=nn.Linear(128,nc)
    def forward(self,x):
        x=self.input_proj(x); o,_=self.lstm(x); o=self.attn(o)
        p=self.pool(o.permute(0,2,1)).squeeze(-1); f=self.classifier(p)
        return self.head_binary(f),self.head_multi(f),f

class PositionalEncoding(nn.Module):
    def __init__(self,d,m=512):
        super().__init__()
        pe=torch.zeros(m,d); pos=torch.arange(0,m).unsqueeze(1).float()
        div=torch.exp(torch.arange(0,d,2).float()*(-np.log(10000.)/d))
        pe[:,0::2]=torch.sin(pos*div); pe[:,1::2]=torch.cos(pos*div)
        self.register_buffer('pe',pe.unsqueeze(0))
    def forward(self,x): return x+self.pe[:,:x.size(1)]

class TransformerAnomaly(nn.Module):
    def __init__(self,d,dm=256,nh=8,nl=6,ff=1024,do=.2,nc=7):
        super().__init__()
        self.input_proj=nn.Sequential(nn.Linear(d,dm),nn.LayerNorm(dm))
        self.pos_enc=PositionalEncoding(dm)
        layer=nn.TransformerEncoderLayer(dm,nh,ff,do,'gelu',True,True)
        self.transformer=nn.TransformerEncoder(layer,nl)
        self.cls_token=nn.Parameter(torch.randn(1,1,dm))
        self.classifier=nn.Sequential(nn.Linear(dm,256),nn.GELU(),nn.Dropout(.3),
            nn.Linear(256,128),nn.GELU(),nn.Dropout(.2))
        self.head_binary=nn.Linear(128,1); self.head_multi=nn.Linear(128,nc)
    def forward(self,x):
        B=x.size(0); x=self.input_proj(x)
        x=torch.cat([self.cls_token.expand(B,-1,-1),x],1)
        x=self.transformer(self.pos_enc(x)); f=self.classifier(x[:,0])
        return self.head_binary(f),self.head_multi(f),f

class MultiTaskDNN(nn.Module):
    def __init__(self,d,nc=7):
        super().__init__()
        self.backbone=nn.Sequential(nn.Linear(d,1024),nn.BatchNorm1d(1024),nn.GELU(),nn.Dropout(.3),
            nn.Linear(1024,512),nn.BatchNorm1d(512),nn.GELU(),nn.Dropout(.3),
            nn.Linear(512,256),nn.BatchNorm1d(256),nn.GELU(),nn.Dropout(.2))
        self.experts=nn.ModuleList([nn.Sequential(nn.Linear(256,128),nn.GELU(),nn.Dropout(.2),
            nn.Linear(128,64),nn.GELU(),nn.Linear(64,1)) for _ in range(nc)])
        self.head_binary=nn.Sequential(nn.Linear(256,128),nn.GELU(),nn.Dropout(.2),nn.Linear(128,1))
    def forward(self,x):
        s=self.backbone(x); return self.head_binary(s),torch.cat([e(s) for e in self.experts],1),s


# ====================================================================
# INFERENCE ENGINE
# ====================================================================

# ====================================================================
# PER-CONDITION AI MODEL DEFINITIONS (from Colab training)
# ====================================================================
class CondAE(nn.Module):
    def __init__(self, nf, z=12):
        super().__init__()
        self.enc = nn.Sequential(
            nn.Linear(nf,256), nn.BatchNorm1d(256), nn.GELU(), nn.Dropout(.2),
            nn.Linear(256,128), nn.BatchNorm1d(128), nn.GELU(), nn.Dropout(.15),
            nn.Linear(128,64), nn.BatchNorm1d(64), nn.GELU(), nn.Dropout(.1),
            nn.Linear(64,z))
        self.dec = nn.Sequential(
            nn.Linear(z,64), nn.BatchNorm1d(64), nn.GELU(), nn.Dropout(.1),
            nn.Linear(64,128), nn.BatchNorm1d(128), nn.GELU(), nn.Dropout(.15),
            nn.Linear(128,256), nn.BatchNorm1d(256), nn.GELU(), nn.Dropout(.2),
            nn.Linear(256,nf))
    def forward(self, x):
        z = self.enc(x); return self.dec(z), z

class CondCNN(nn.Module):
    def __init__(self, nf, seq=64, nc=1):
        super().__init__()
        self.proj = nn.Sequential(nn.Conv1d(nf,128,1), nn.BatchNorm1d(128), nn.GELU())
        self.conv = nn.Sequential(
            nn.Conv1d(128,128,7,padding=3), nn.BatchNorm1d(128), nn.GELU(),
            nn.Conv1d(128,256,5,padding=2), nn.BatchNorm1d(256), nn.GELU(),
            nn.Conv1d(256,256,3,padding=1), nn.BatchNorm1d(256), nn.GELU(),
            nn.Conv1d(256,128,3,padding=1), nn.BatchNorm1d(128), nn.GELU(),
            nn.AdaptiveAvgPool1d(1))
        self.head = nn.Sequential(nn.Linear(128,64), nn.GELU(), nn.Dropout(.2), nn.Linear(64,nc))
    def forward(self, x):
        return self.head(self.conv(self.proj(x.permute(0,2,1))).squeeze(-1))

class CondLSTM(nn.Module):
    def __init__(self, nf, h=128, nl=3, nc=1):
        super().__init__()
        self.proj = nn.Sequential(nn.Linear(nf, h), nn.LayerNorm(h), nn.GELU())
        self.lstm = nn.LSTM(h, h, nl, batch_first=True, bidirectional=True, dropout=.2)
        self.attn = nn.MultiheadAttention(h*2, 8, dropout=.1, batch_first=True)
        self.norm = nn.LayerNorm(h*2)
        self.head = nn.Sequential(nn.Linear(h*2,64), nn.GELU(), nn.Dropout(.2), nn.Linear(64,nc))
    def forward(self, x):
        x = self.proj(x); o, _ = self.lstm(x)
        a, _ = self.attn(o, o, o)
        return self.head(self.norm(o + a).mean(dim=1))

class CondTF(nn.Module):
    def __init__(self, nf, dm=128, nh=8, nl=4, nc=1):
        super().__init__()
        self.proj = nn.Sequential(nn.Linear(nf, dm), nn.LayerNorm(dm))
        layer = nn.TransformerEncoderLayer(dm, nh, dm*4, .1, activation='gelu', batch_first=True, norm_first=True)
        self.tf = nn.TransformerEncoder(layer, nl)
        self.cls = nn.Parameter(torch.randn(1,1,dm))
        self.head = nn.Sequential(nn.Linear(dm,64), nn.GELU(), nn.Dropout(.2), nn.Linear(64,nc))
    def forward(self, x):
        B = x.size(0)
        x = torch.cat([self.cls.expand(B,-1,-1), self.proj(x)], 1)
        return self.head(self.tf(x)[:,0])

class CondDNN(nn.Module):
    def __init__(self, nf, nc=1):
        super().__init__()
        self.l1 = nn.Sequential(nn.Linear(nf,512), nn.BatchNorm1d(512), nn.GELU(), nn.Dropout(.3))
        self.l2 = nn.Sequential(nn.Linear(512,256), nn.BatchNorm1d(256), nn.GELU(), nn.Dropout(.25))
        self.l3 = nn.Sequential(nn.Linear(256,128), nn.BatchNorm1d(128), nn.GELU(), nn.Dropout(.2))
        self.l4 = nn.Sequential(nn.Linear(128,64), nn.BatchNorm1d(64), nn.GELU(), nn.Dropout(.1))
        self.skip = nn.Linear(512, 64)
        self.head = nn.Linear(64, nc)
    def forward(self, x):
        h1 = self.l1(x); h4 = self.l4(self.l3(self.l2(h1)))
        return self.head(h4 + self.skip(h1))

COND_MODEL_CLS = {'AE': CondAE, 'CNN': CondCNN, 'LSTM': CondLSTM, 'TF': CondTF, 'DNN': CondDNN}


# ====================================================================
# PER-CONDITION HYBRID ENGINE
# ====================================================================
class PerConditionEngine:
    """Hybrid AI+Rule per-condition anomaly detection."""

    RULE_ONLY = {'C13','C14','C15','C16','C17','C18','C22'}

    def __init__(self, model_dir=None):
        self.device = torch.device(DEVICE)
        self.groups = {}
        self.ready = False
        if model_dir is None:
            model_dir = COND_MODEL_DIR
        manifest_path = os.path.join(model_dir, "manifest.json")
        if not os.path.exists(manifest_path):
            logger.warning(f"⚠ Per-condition models not found at {model_dir}")
            return
        import json as _json
        manifest = _json.load(open(manifest_path))
        logger.info(f"Loading per-condition models from {model_dir}")

        for gn, gc in manifest.get("groups", {}).items():
            scaler_path = os.path.join(model_dir, gc["scaler"])
            if not os.path.exists(scaler_path):
                logger.warning(f"  ⚠ Scaler not found: {scaler_path}"); continue
            scaler = joblib.load(scaler_path)
            models = {}
            for mfile in gc.get("models", []):
                path = os.path.join(model_dir, mfile)
                if not os.path.exists(path): continue
                try:
                    ck = torch.load(path, map_location=self.device, weights_only=False)
                    mt = ck["model_type"]
                    nf = ck["n_features"]
                    nc = ck["n_conditions"]
                    cls = COND_MODEL_CLS.get(mt)
                    if cls is None: continue
                    if mt == "AE":
                        m = cls(nf, max(4, nf//3))
                    elif mt in ("CNN","LSTM","TF"):
                        m = cls(nf, ck.get("seq_len", 64), nc)
                    else:
                        m = cls(nf, nc)
                    m.load_state_dict(ck["model_state_dict"])
                    try:
                        m.to(self.device).eval()
                    except RuntimeError as _gpu_err:
                        if "cuDNN" in str(_gpu_err) or "cudnn" in str(_gpu_err):
                            logger.warning(f"  ⚠ {gn}/{mt}: cuDNN error, falling back to CPU")
                            m.to("cpu").eval()
                        else:
                            raise
                    models[mt] = m
                    logger.info(f"  ✅ {gn}/{mt} ({sum(p.numel() for p in m.parameters()):,}p)")
                except RuntimeError as _rt_err:
                    if "cuDNN" in str(_rt_err) or "cudnn" in str(_rt_err):
                        # cuDNN error during model construction — reload for CPU
                        try:
                            ck2 = torch.load(path, map_location="cpu", weights_only=False)
                            mt2 = ck2["model_type"]; nf2 = ck2["n_features"]; nc2 = ck2["n_conditions"]
                            cls2 = COND_MODEL_CLS.get(mt2)
                            if cls2:
                                if mt2 == "AE": m2 = cls2(nf2, max(4, nf2//3))
                                elif mt2 in ("CNN","LSTM","TF"): m2 = cls2(nf2, ck2.get("seq_len", 64), nc2)
                                else: m2 = cls2(nf2, nc2)
                                m2.load_state_dict(ck2["model_state_dict"])
                                m2.to("cpu").eval()
                                models[mt2] = m2
                                logger.info(f"  ✅ {gn}/{mt2} (CPU fallback, {sum(p.numel() for p in m2.parameters()):,}p)")
                        except Exception as _cpu_err:
                            logger.warning(f"  ⚠ {gn}/{mfile}: CPU fallback also failed: {_cpu_err}")
                    else:
                        logger.warning(f"  ⚠ {gn}/{mfile}: {_rt_err}")
                except Exception as e:
                    logger.warning(f"  ⚠ {gn}/{mfile}: {e}")
            if models:
                self.groups[gn] = {
                    "conditions": gc["conditions"],
                    "features": gc["features"],
                    "type": gc["type"],
                    "scaler": scaler,
                    "models": models,
                }
        self.ready = bool(self.groups)
        logger.info(f"Per-condition engine: {len(self.groups)} groups, ready={self.ready}")

    @staticmethod
    def _engineer_row(data):
        """Compute derived features from a single telemetry dict (matching notebook)."""
        d = {k: float(v) if isinstance(v, (int, float)) else 0 for k, v in data.items()}
        d["power_c1"] = d.get("present_voltage1",0) * d.get("present_current1",0) / 1000
        d["power_c2"] = d.get("present_voltage2",0) * d.get("present_current2",0) / 1000
        d["power_total"] = d["power_c1"] + d["power_c2"]
        tv1, pv1 = d.get("target_voltage1",0), d.get("present_voltage1",0)
        tv2, pv2 = d.get("target_voltage2",0), d.get("present_voltage2",0)
        d["volt_diff_c1"] = abs(pv1 - tv1)
        d["volt_diff_c2"] = abs(pv2 - tv2)
        d["volt_pct_dev_c1"] = d["volt_diff_c1"] / max(tv1, 1) * 100
        d["volt_pct_dev_c2"] = d["volt_diff_c2"] / max(tv2, 1) * 100
        tc1, pc1 = d.get("target_current1",0), d.get("present_current1",0)
        tc2, pc2 = d.get("target_current2",0), d.get("present_current2",0)
        d["curr_diff_c1"] = abs(pc1 - tc1)
        d["curr_diff_c2"] = abs(pc2 - tc2)
        d["overcurrent_c1"] = max(pc1 - tc1, 0)
        d["overcurrent_c2"] = max(pc2 - tc2, 0)
        temps = [d.get(f"power_module_temp{i}", 0) for i in range(1, 6)]
        d["max_module_temp"] = max(temps) if temps else 0
        d["min_module_temp"] = min(temps) if temps else 0
        d["mean_module_temp"] = sum(temps) / max(len(temps), 1)
        d["temp_spread"] = d["max_module_temp"] - d["min_module_temp"]
        gp = [d.get("charger_gun_temp_plus1", 0), d.get("charger_gun_temp_plus2", 0)]
        d["max_gun_temp"] = max(gp)
        d["temp_delta_charger_gun"] = d["max_gun_temp"] - d.get("charger_temp", 0)
        d["is_charging_c1"] = 1 if (tv1 > 0 or tc1 > 0) else 0
        d["is_charging_c2"] = 1 if (tv2 > 0 or tc2 > 0) else 0
        d["is_dual_charging"] = 1 if (d["is_charging_c1"] and d["is_charging_c2"]) else 0
        ms = [d.get(f"power_module_status{i}", 0) for i in range(1, 6)]
        d["active_modules"] = sum(1 for x in ms if x == 1 or x == "Active")
        import math
        h = d.get("hour", 12)
        d["hour_sin"] = math.sin(2 * math.pi * h / 24)
        d["hour_cos"] = math.cos(2 * math.pi * h / 24)
        # Meter features (set 0 if not available — realtime doesn't have daily aggregates)
        for f in ["energy_rate_c1","energy_rate_c2","meter_vs_power_c1","meter_vs_power_c2",
                   "efficiency_c1","efficiency_c2","meter1_trend","meter2_trend",
                   "daily_kwh_c1","daily_kwh_c2","day_of_week","is_weekend"]:
            if f not in d:
                d[f] = 0
        # Diff features default to 0 for single-row prediction
        for base in ["power_total","max_module_temp","volt_diff_c1","volt_diff_c2"]:
            d[f"{base}_diff1"] = d.get(f"{base}_diff1", 0)
            d[f"{base}_diff2"] = d.get(f"{base}_diff2", 0)
        return d

    @torch.no_grad()
    def predict(self, data_dict):
        """Returns per-condition AI scores: {C01: {ai_score, type}, ...}"""
        if not self.ready:
            return {}
        import numpy as np
        d = self._engineer_row(data_dict)
        results = {}

        for gn, g in self.groups.items():
            feat_vals = [d.get(f, 0) for f in g["features"]]
            x = np.array([feat_vals], dtype=np.float32)
            x = g["scaler"].transform(x)
            x_t = torch.FloatTensor(x).to(self.device)

            scores = []
            for mt, model in g["models"].items():
                try:
                    if mt == "AE":
                        rec, _ = model(x_t)
                        ae_err = float(((rec - x_t) ** 2).mean())
                        scores.append(min(ae_err / 2.0, 1.0))
                    elif mt == "DNN":
                        out = torch.sigmoid(model(x_t)).squeeze().cpu().numpy()
                        scores.append(float(out) if out.ndim == 0 else out.tolist())
                except Exception:
                    pass

            for i, cid in enumerate(g["conditions"]):
                ai_s = []
                for s in scores:
                    if isinstance(s, list):
                        ai_s.append(s[i] if i < len(s) else s[0])
                    else:
                        ai_s.append(s)
                score = float(np.mean(ai_s)) if ai_s else 0.0
                results[cid] = {
                    "ai_score": round(score, 4),
                    "ai_alarm": score > 0.5,
                    "type": g["type"],
                }
        return results



class InferenceEngine:
    REGISTRY = {
        "Autoencoder":(DeepAutoencoder,False), "CNN1D":(CNN1D_Anomaly,True),
        "BiLSTM_Attn":(BiLSTM_Attention,True), "Transformer":(TransformerAnomaly,True),
        "MultiTask_DNN":(MultiTaskDNN,False),
    }

    def __init__(self):
        self.device = torch.device(DEVICE)
        self.models = {}
        self.scaler = None
        self.ensemble_weights = {}
        self.feature_cols = []
        self.buffer = deque(maxlen=BUFFER_MAX)
        self.alert_cooldowns = {}
        self._load()

    def _load(self):
        logger.info(f"Loading models from '{MODEL_DIR}' → {self.device}")
        global NUM_FEATURES

        p = f"{MODEL_DIR}/scaler.pkl"
        if os.path.exists(p): self.scaler = joblib.load(p); logger.info("  ✅ Scaler")

        p = f"{MODEL_DIR}/feature_cols.csv"
        if os.path.exists(p):
            self.feature_cols = pd.read_csv(p).iloc[:,0].tolist()
            NUM_FEATURES = len(self.feature_cols)
            logger.info(f"  ✅ Features: {NUM_FEATURES}")

        p = f"{MODEL_DIR}/ensemble_weights.csv"
        if os.path.exists(p):
            self.ensemble_weights = pd.read_csv(p,index_col=0,header=None).iloc[:,0].to_dict()

        for name,(cls,is_seq) in self.REGISTRY.items():
            path = f"{MODEL_DIR}/{name}_final.pt"
            if not os.path.exists(path):
                logger.warning(f"  ⚠ {name} not found"); continue
            ckpt = torch.load(path, map_location=self.device, weights_only=False)
            nf = ckpt.get("num_features", NUM_FEATURES)
            nc = ckpt.get("num_classes", NUM_CLASSES)
            if cls==DeepAutoencoder: m=cls(nf,16)
            elif cls==CNN1D_Anomaly: m=cls(nf,SEQ_LEN,nc)
            elif cls==BiLSTM_Attention: m=cls(nf,256,3,nc)
            elif cls==TransformerAnomaly: m=cls(nf,256,8,6,1024,.2,nc)
            elif cls==MultiTaskDNN: m=cls(nf,nc)
            m.load_state_dict(ckpt["model_state_dict"])
            try:
                m.to(self.device).eval()
            except RuntimeError as _cudnn_err:
                if "cuDNN" in str(_cudnn_err) or "cudnn" in str(_cudnn_err):
                    logger.warning(f"  ⚠ {name}: cuDNN error, falling back to CPU")
                    m.to("cpu").eval()
                else:
                    raise
            self.models[name] = {"model":m, "sequential":is_seq}
            logger.info(f"  ✅ {name} ({sum(p.numel() for p in m.parameters()):,} params)")

        if not self.models:
            logger.warning("  ⚠ No models → rule-based mode only")

    @staticmethod
    def _engineer(df):
        X = df.copy()
        X["power_c1"]=X["present_voltage1"]*X["present_current1"]/1000
        X["power_c2"]=X["present_voltage2"]*X["present_current2"]/1000
        X["power_total"]=X["power_c1"]+X["power_c2"]
        X["volt_diff_c1"]=(X["present_voltage1"]-X["target_voltage1"]).abs()
        X["volt_diff_c2"]=(X["present_voltage2"]-X["target_voltage2"]).abs()
        X["volt_pct_dev_c1"]=X["volt_diff_c1"]/X["target_voltage1"].clip(lower=1)*100
        X["volt_pct_dev_c2"]=X["volt_diff_c2"]/X["target_voltage2"].clip(lower=1)*100
        X["curr_diff_c1"]=(X["present_current1"]-X["target_current1"]).abs()
        X["curr_diff_c2"]=(X["present_current2"]-X["target_current2"]).abs()
        X["overcurrent_c1"]=(X["present_current1"]-X["target_current1"]).clip(lower=0)
        X["overcurrent_c2"]=(X["present_current2"]-X["target_current2"]).clip(lower=0)
        tc=[f"power_module_temp{i}" for i in range(1,6)]
        X["max_module_temp"]=X[tc].max(axis=1); X["min_module_temp"]=X[tc].min(axis=1)
        X["mean_module_temp"]=X[tc].mean(axis=1); X["temp_spread"]=X["max_module_temp"]-X["min_module_temp"]
        X["max_gun_temp"]=X[["charger_gun_temp_plus1","charger_gun_temp_plus2"]].max(axis=1)
        X["temp_delta_charger_gun"]=X["max_gun_temp"]-X["charger_temp"]
        X["is_charging_c1"]=((X["target_voltage1"]>0)|(X["target_current1"]>0)).astype(int)
        X["is_charging_c2"]=((X["target_voltage2"]>0)|(X["target_current2"]>0)).astype(int)
        X["is_dual_charging"]=(X["is_charging_c1"]&X["is_charging_c2"]).astype(int)
        ms=[f"power_module_status{i}" for i in range(1,6)]
        X["active_modules"]=X[ms].sum(axis=1)
        for c in ["power_total","max_module_temp","volt_diff_c1","volt_diff_c2"]:
            X[f"{c}_diff1"]=X[c].diff(1).fillna(0); X[f"{c}_diff2"]=X[c].diff(2).fillna(0)
        X["hour_sin"]=np.sin(2*np.pi*X["hour"]/24)
        X["hour_cos"]=np.cos(2*np.pi*X["hour"]/24)
        return X

    @staticmethod
    def _rule_check(r):
        s={g:0.0 for g in ANOMALY_GROUPS}
        tv1,pv1=r.get("target_voltage1",0),r.get("present_voltage1",0)
        tv2,pv2=r.get("target_voltage2",0),r.get("present_voltage2",0)
        tc1,pc1=r.get("target_current1",0),r.get("present_current1",0)
        tc2,pc2=r.get("target_current2",0),r.get("present_current2",0)
        chg=tv1>0 or tv2>0 or tc1>0 or tc2>0
        if tv1>100 and abs(pv1-tv1)/tv1>.05: s["anomaly_voltage"]=min(abs(pv1-tv1)/tv1,1.)
        if tv2>100 and abs(pv2-tv2)/tv2>.05: s["anomaly_voltage"]=max(s["anomaly_voltage"],min(abs(pv2-tv2)/tv2,1.))
        if tc1>0 and pc1>tc1: s["anomaly_current"]=min((pc1-tc1)/max(tc1,1),1.)
        if tc2>0 and pc2>tc2: s["anomaly_current"]=max(s["anomaly_current"],min((pc2-tc2)/max(tc2,1),1.))
        p1,p2=pv1*pc1/1000,pv2*pc2/1000
        if p1>80 or p2>80: s["anomaly_power"]=min(max(p1,p2)/150,1.)
        if chg and r.get("SOC",50)==0: s["anomaly_soc"]=.9
        temps=[r.get(f"power_module_temp{i}",0) for i in range(1,6)]
        guns=[r.get("charger_gun_temp_plus1",0),r.get("charger_gun_temp_plus2",0)]
        if max(temps)>55: s["anomaly_thermal"]=min((max(temps)-55)/20,1.)
        if max(guns)>80: s["anomaly_thermal"]=max(s["anomaly_thermal"],.95)
        if chg and (r.get("PLC1_status",1)==0 or r.get("PLC2_status",1)==0): s["anomaly_communication"]=.95
        if tv1>200 and pv1==0: s["anomaly_session"]=.9
        return s

    def _to_tensor(self, data):
        df=pd.DataFrame([data]); df=self._engineer(df)
        if self.feature_cols:
            for c in self.feature_cols:
                if c not in df.columns: df[c]=0
            df=df[self.feature_cols]
        v=df.values.astype(np.float32)
        if self.scaler: v=self.scaler.transform(v).astype(np.float32)
        return torch.FloatTensor(v).to(self.device)

    def _seq_tensor(self):
        if len(self.buffer)<SEQ_LEN: return None
        buf=list(self.buffer)[-SEQ_LEN:]
        df=pd.DataFrame(buf); df=self._engineer(df)
        if self.feature_cols:
            for c in self.feature_cols:
                if c not in df.columns: df[c]=0
            df=df[self.feature_cols]
        v=df.values.astype(np.float32)
        if self.scaler: v=self.scaler.transform(v).astype(np.float32)
        return torch.FloatTensor(v).unsqueeze(0).to(self.device)

    @torch.no_grad()
    def predict(self, data):
        t0=time.perf_counter(); self.buffer.append(data)
        rule_scores=self._rule_check(data)
        if not self.models:
            return self._fmt(max(rule_scores.values()),rule_scores,time.perf_counter()-t0,"rule_based",None,[])

        x_tab=self._to_tensor(data); x_seq=self._seq_tensor()
        preds={}
        for name,info in self.models.items():
            mdl=info["model"]
            try:
                if info["sequential"]:
                    if x_seq is None: continue
                    bo,mo,_=mdl(x_seq)
                    preds[name]={"b":torch.sigmoid(bo).item(),"m":torch.sigmoid(mo).squeeze().cpu().numpy()}
                elif isinstance(mdl,DeepAutoencoder):
                    xh,_=mdl(x_tab)
                    err=F.mse_loss(xh,x_tab,reduction="none").mean(1).item()
                    preds[name]={"b":min(err/2.,1.),"m":None}
                else:
                    bo,mo,_=mdl(x_tab)
                    preds[name]={"b":torch.sigmoid(bo).item(),"m":torch.sigmoid(mo).squeeze().cpu().numpy()}
            except Exception as e:
                logger.error(f"{name}: {e}")

        tw=sum(self.ensemble_weights.get(n,1.) for n in preds)
        b_score=sum(self.ensemble_weights.get(n,1.)*p["b"] for n,p in preds.items())/max(tw,1e-9)
        mp={n:p["m"] for n,p in preds.items() if p["m"] is not None}
        if mp:
            twm=sum(self.ensemble_weights.get(n,1.) for n in mp)
            em=sum(self.ensemble_weights.get(n,1.)*p for n,p in mp.items())/max(twm,1e-9)
            g_scores={g:float(em[i]) for i,g in enumerate(ANOMALY_GROUPS)}
        else: g_scores=rule_scores

        return self._fmt(b_score,g_scores,time.perf_counter()-t0,"ensemble",
                         {n:round(p["b"],4) for n,p in preds.items()},
                         self._compute_importance(data))

    def _compute_importance(self, data, top_n=15):
        """Gradient-based feature importance via input×gradient attribution."""
        if not self.models or not self.feature_cols:
            return []

        # Prepare input
        df = pd.DataFrame([data]); df = self._engineer(df)
        if self.feature_cols:
            for c in self.feature_cols:
                if c not in df.columns: df[c] = 0
            df = df[self.feature_cols]
        raw = df.values.astype(np.float32)
        if self.scaler: raw = self.scaler.transform(raw).astype(np.float32)

        importances = np.zeros(len(self.feature_cols))
        count = 0

        # Must use enable_grad() because this is called from predict() which has @torch.no_grad()
        with torch.enable_grad():
            for name, info in self.models.items():
                mdl = info["model"]
                if info["sequential"]:
                    continue  # Skip sequential models (need buffer)
                try:
                    x = torch.FloatTensor(raw.copy()).to(self.device).requires_grad_(True)
                    if isinstance(mdl, DeepAutoencoder):
                        xh, _ = mdl(x)
                        score = F.mse_loss(xh, x.detach(), reduction="none").mean(1)
                    else:
                        bo, mo, _ = mdl(x)
                        score = torch.sigmoid(bo).squeeze()

                    score.backward()

                    if x.grad is not None:
                        imp = (x.detach() * x.grad.detach()).abs().squeeze().cpu().numpy()
                        w = self.ensemble_weights.get(name, 1.0)
                        importances += imp * w
                        count += w
                except Exception as e:
                    logger.debug(f"Importance skip {name}: {e}")

        if count > 0:
            importances /= count

        # Normalize so all values sum to 1
        total = importances.sum()
        if total > 0:
            importances /= total

        # Build sorted list
        pairs = [(self.feature_cols[i], float(importances[i]))
                 for i in range(len(self.feature_cols))]
        pairs.sort(key=lambda p: p[1], reverse=True)
        top = pairs[:top_n]
        # Re-normalize top_n so displayed values sum to 1
        ts = sum(v for _, v in top)
        if ts > 0:
            top = [(f, v / ts) for f, v in top]
        return top

    def _fmt(self, b_score, g_scores, elapsed, method, details=None, feat_imp=None):
        now=datetime.now()
        alerts=[]
        for g,score in g_scores.items():
            if score<=GROUP_THRESHOLDS.get(g,.5): continue
            ref=STANDARD_REFS.get(g,{})
            last=self.alert_cooldowns.get(g)
            cooldown=last and (now-last).total_seconds()<30
            if not cooldown: self.alert_cooldowns[g]=now
            alerts.append({"group":g,"label":g.replace("anomaly_","").upper(),
                "score":round(score,4),"severity":ref.get("severity","UNKNOWN"),
                "standards":ref.get("standards",[]),"action":ref.get("action",""),
                "in_cooldown":cooldown})
        sev={"CRITICAL":0,"HIGH":1,"MEDIUM":2}
        alerts.sort(key=lambda a:sev.get(a["severity"],9))
        return {"timestamp":now.isoformat(),"is_anomaly":b_score>BINARY_THRESHOLD,
            "anomaly_score":round(b_score,4),
            "group_scores":{k:round(v,4) for k,v in g_scores.items()},
            "alerts":alerts,"num_alerts":len(alerts),
            "max_severity":alerts[0]["severity"] if alerts else "NORMAL",
            "method":method,"latency_ms":round(elapsed*1000,2),
            "model_details":details or {},"buffer_size":len(self.buffer),
            "feature_importance":[{"feature":f,"importance":round(v,4)} for f,v in (feat_imp or [])]}


# ====================================================================
# RULE-BASED ENGINE (MQTT Real-Time Monitoring)
# ====================================================================
class RuleBasedEngine:
    """Rule-based anomaly detection from live MQTT PLC data."""

    def __init__(self):
        self.plc_data = {}
        self.rule_results = []
        self.mqtt_connected = False
        self.last_update = None
        self.charging_start = {}  # connector -> start time

    def update(self, data):
        """Process incoming MQTT PLC data and run all rules."""
        self.plc_data.update(data)
        self.last_update = datetime.now()
        self.rule_results = self._run_all(self.plc_data)
        return self.rule_results

    @staticmethod
    def _num(d, key, default=0):
        """Safely get numeric value from dict (handles str/int/float)."""
        v = d.get(key, default)
        try:
            return float(v)
        except (ValueError, TypeError):
            return default

    def _run_all(self, d):
        results = []
        n = self._num  # shorthand

        # Rule 1: Charging state → voltage/current consistency (per connector)
        for c in [1, 2]:
            icp = n(d, f"icp{c}")
            usl = n(d, f"usl{c}")
            pv = n(d, f"presentVoltage{c}")
            pc = n(d, f"presentCurrent{c}")
            tv = n(d, f"targetVoltage{c}")
            tc = n(d, f"targetCurrent{c}")
            vals = {"icp": icp, "usl": usl, "pV": round(pv,1), "pI": round(pc,1), "tV": round(tv,1), "tI": round(tc,1)}
            if icp == 7 and usl == 13:  # C2 + Current Demand
                ok_pv = pv > 0
                ok_pc = pc > 0
                ok_tv = tv > 0
                ok_tc = tc > 0
                ok = ok_pv and ok_pc and ok_tv and ok_tc
                issues = []
                if not ok_pv: issues.append(f"presentV{c}=0")
                if not ok_pc: issues.append(f"presentI{c}=0")
                if not ok_tv: issues.append(f"targetV{c}=0")
                if not ok_tc: issues.append(f"targetI{c}=0")
                results.append({
                    "id": f"r1_c{c}", "rule": "Charging State Check",
                    "connector": c, "status": "OK" if ok else "ALERT",
                    "severity": "NORMAL" if ok else "HIGH",
                    "detail": f"C{c} charging OK" if ok else f"C{c}: {', '.join(issues)} while ICP=C2/USL=CurrentDemand",
                    "values": vals
                })
            else:
                results.append({
                    "id": f"r1_c{c}", "rule": "Charging State Check",
                    "connector": c, "status": "IDLE", "severity": "NORMAL",
                    "detail": f"C{c} not in charging state (ICP={int(icp)}, USL={int(usl)})",
                    "values": vals
                })

        # Rule 2: Power Module Temperature Derating
        t1 = n(d, "tempPowerModule1")
        t2 = n(d, "tempPowerModule2")
        max_t = max(t1, t2)
        if max_t > 55:
            delta = max_t - 55
            derate_a = round(delta * 3.2, 1)
            derate_kw = round(delta * 1.0, 1)
            results.append({
                "id": "r2_derate", "rule": "Power Module Derating",
                "connector": 0, "status": "ALERT", "severity": "MEDIUM",
                "detail": f"Temp {max_t:.1f}\u00b0C > 55\u00b0C \u2192 derating {derate_a}A / {derate_kw}kW",
                "values": {"tempMod1": round(t1,1), "tempMod2": round(t2,1), "derateA": derate_a, "derateKW": derate_kw}
            })
        else:
            results.append({
                "id": "r2_derate", "rule": "Power Module Derating",
                "connector": 0, "status": "OK", "severity": "NORMAL",
                "detail": f"Module temp {max_t:.1f}\u00b0C \u2264 55\u00b0C \u2014 no derating",
                "values": {"tempMod1": round(t1,1), "tempMod2": round(t2,1)}
            })

        # Rule 3 & 4: Active Module Count
        icp1 = n(d, "icp1")
        icp2 = n(d, "icp2")
        am1 = int(n(d, "activeMld1"))
        am2 = int(n(d, "activeMld2"))
        charging_c1 = icp1 in [2, 7]  # B1 or C2
        charging_c2 = icp2 in [2, 7]

        if charging_c1 and charging_c2:
            # Dual charging: H1=2, H2=3
            ok1 = am1 == 2
            ok2 = am2 == 3
            results.append({
                "id": "r3_single", "rule": "Single Charging Module Count",
                "connector": 0, "status": "N/A", "severity": "NORMAL",
                "detail": "Dual charging active \u2014 see Rule 4",
                "values": {"activeMld1": am1, "activeMld2": am2}
            })
            results.append({
                "id": "r4_dual", "rule": "Dual Charging Module Split",
                "connector": 0, "status": "OK" if (ok1 and ok2) else "ALERT",
                "severity": "NORMAL" if (ok1 and ok2) else "HIGH",
                "detail": f"H1:{am1}/2 H2:{am2}/3" + ("" if (ok1 and ok2) else " \u2014 module allocation mismatch"),
                "values": {"activeMld1": am1, "activeMld2": am2, "expect1": 2, "expect2": 3}
            })
        elif charging_c1 or charging_c2:
            # Single charging: all 5 modules
            total = am1 + am2
            ok = total == 5
            results.append({
                "id": "r3_single", "rule": "Single Charging Module Count",
                "connector": 1 if charging_c1 else 2, "status": "OK" if ok else "ALERT",
                "severity": "NORMAL" if ok else "HIGH",
                "detail": f"Active: {total}/5 modules (H1:{am1}+H2:{am2})" + ("" if ok else " \u2014 missing modules!"),
                "values": {"activeMld1": am1, "activeMld2": am2, "total": total}
            })
            results.append({
                "id": "r4_dual", "rule": "Dual Charging Module Split",
                "connector": 0, "status": "N/A", "severity": "NORMAL",
                "detail": "Single charging active \u2014 see Rule 3",
                "values": {"activeMld1": am1, "activeMld2": am2}
            })
        else:
            # No charging
            results.append({
                "id": "r3_single", "rule": "Single Charging Module Count",
                "connector": 0, "status": "IDLE", "severity": "NORMAL",
                "detail": f"No connector charging (ICP1={int(icp1)}, ICP2={int(icp2)})",
                "values": {"activeMld1": am1, "activeMld2": am2}
            })
            results.append({
                "id": "r4_dual", "rule": "Dual Charging Module Split",
                "connector": 0, "status": "IDLE", "severity": "NORMAL",
                "detail": f"No connector charging (ICP1={int(icp1)}, ICP2={int(icp2)})",
                "values": {"activeMld1": am1, "activeMld2": am2}
            })

        # Rule 5: Under-delivery without CSMS Limit (per connector)
        for c in [1, 2]:
            icp = n(d, f"icp{c}")
            usl = n(d, f"usl{c}")
            pv = n(d, f"presentVoltage{c}")
            pc = n(d, f"presentCurrent{c}")
            tv = n(d, f"targetVoltage{c}")
            tc = n(d, f"targetCurrent{c}")
            lim = n(d, f"powerLimit{c}")
            vals = {"pV": round(pv,1), "tV": round(tv,1), "pI": round(pc,1), "tI": round(tc,1), "limit": lim}
            if icp == 7 and usl == 13:
                under_v = tv > 0 and pv < tv * 0.95
                under_i = tc > 0 and pc < tc * 0.95
                no_limit = lim == 0
                if (under_v or under_i) and no_limit:
                    results.append({
                        "id": f"r5_c{c}", "rule": "Under-Delivery (No CSMS Limit)",
                        "connector": c, "status": "ALERT", "severity": "MEDIUM",
                        "detail": f"C{c}: pV={pv:.0f}<tV={tv:.0f} pI={pc:.0f}<tI={tc:.0f} with no power limit",
                        "values": vals
                    })
                else:
                    results.append({
                        "id": f"r5_c{c}", "rule": "Under-Delivery (No CSMS Limit)",
                        "connector": c, "status": "OK", "severity": "NORMAL",
                        "detail": f"C{c}: delivery within 95% tolerance" + (f" (CSMS limit={lim:.0f})" if lim > 0 else ""),
                        "values": vals
                    })
            else:
                results.append({
                    "id": f"r5_c{c}", "rule": "Under-Delivery (No CSMS Limit)",
                    "connector": c, "status": "IDLE", "severity": "NORMAL",
                    "detail": f"C{c} not in charging state (ICP={int(icp)}, USL={int(usl)})",
                    "values": vals
                })

        # Rule 6: CCS Cable Temperature Derating (per connector)
        for c, prefix in [(1, "Head1"), (2, "Head2")]:
            t_plus = n(d, f"temp1{prefix}")
            t_minus = n(d, f"temp2{prefix}")
            head_temp = max(t_plus, t_minus)
            vals = {"tempPlus": round(t_plus,1), "tempMinus": round(t_minus,1)}
            if head_temp <= 0:
                results.append({
                    "id": f"r6_c{c}", "rule": "CCS Cable Temp Derating",
                    "connector": c, "status": "IDLE", "severity": "NORMAL",
                    "detail": f"H{c}: no temperature data (temp=0)",
                    "values": vals
                })
                continue
            # Find closest ambient bracket
            brackets = sorted(CCS_DERATING.keys())
            bracket = brackets[0]
            for b in brackets:
                if head_temp >= b:
                    bracket = b
            derate_info = CCS_DERATING.get(bracket, {})
            limited = []
            for amps, mins in sorted(derate_info.items()):
                if mins is not None:
                    limited.append(f"{amps}A\u2192{mins}min")
            sev = "NORMAL"
            if head_temp >= 50:
                sev = "HIGH"
            elif head_temp >= 40:
                sev = "MEDIUM"
            vals["bracket"] = bracket
            results.append({
                "id": f"r6_c{c}", "rule": "CCS Cable Temp Derating",
                "connector": c, "status": "ALERT" if head_temp >= 40 else "OK",
                "severity": sev,
                "detail": f"H{c}: {head_temp:.1f}\u00b0C (bracket {bracket}\u00b0C) \u2014 " + (", ".join(limited) if limited else "all continuous"),
                "values": vals
            })

        return results

    def get_status(self):
        return {
            "mqtt_connected": self.mqtt_connected,
            "last_update": self.last_update.isoformat() if self.last_update else None,
            "plc_data": self.plc_data,
            "rules": self.rule_results,
            "alerts": [r for r in self.rule_results if r["status"] == "ALERT"],
            "num_alerts": sum(1 for r in self.rule_results if r["status"] == "ALERT"),
            "num_rules": len(self.rule_results),
        }



# ====================================================================
# RESULTS DATABASE CONFIG
# ====================================================================
RESULTS_DB_NAME = "eds_ai_results"
HEALTH_DB_NAME = "eds_system_health"
MONGO_URI = os.getenv("MONGO_URI", "mongodb://imps_platform:eds_imps@203.154.130.132:27017/?authSource=admin")

# Source databases (where PLC telemetry is stored)
SOURCE_DBS = {
    "m1": {"db": "module1MdbDustPrediction", "ts_field": "timestamp"},
    "m2": {"db": "module2ChargerDustPrediction", "ts_field": "timestamp_utc"},
    "m3": {"db": "module3ChargerOfflineAnalysis", "ts_field": "timestamp_utc"},
    "m4": {"db": "module4AbnormalPowerPrediction", "ts_field": "timestamp_utc"},
    "m5": {"db": "module5NetworkProblemPrediction", "ts_field": "timestamp_utc"},
    "m6": {"db": "module6DcChargerRulPrediction", "ts_field": "timestamp_utc"},
    "m7": {"db": "module7ChargerPowerIssue", "ts_field": "timestamp"},
}

# Model directories
MODEL_DIRS = {
    "m1": os.getenv("M1_MODEL_DIR", "module1_models"),
    "m2": os.getenv("M2_MODEL_DIR", "module2_models"),
    "m3": os.getenv("M3_MODEL_DIR", "module3_models"),
    "m4": os.getenv("M4_MODEL_DIR", "condition_models"),
    "m5": os.getenv("M5_MODEL_DIR", "module5_models"),
    "m6": os.getenv("M6_MODEL_DIR", "module6_models"),
    "m7": os.getenv("M7_MODEL_DIR", "module7_models"),
}

# ====================================================================
# MODULE PROCESSORS
# ====================================================================

def read_latest(mongo_client, db_name, collection_name, ts_field="timestamp_utc"):
    """Read latest document from a MongoDB collection (with 5s timeout)."""
    try:
        db = mongo_client[db_name]
        doc = db[collection_name].find_one(
            sort=[(ts_field, -1)], projection={"_id": 0},
            max_time_ms=5000  # Fix #10: 5s timeout
        )
        if doc is None:
            doc = db[collection_name].find_one(
                sort=[("_id", -1)], projection={"_id": 0},
                max_time_ms=5000
            )
        if doc:
            for k, v in doc.items():
                if hasattr(v, 'isoformat'):
                    doc[k] = v.isoformat()
        return doc
    except Exception as e:
        logger.warning(f"  read_latest({db_name}.{collection_name}): {e}")
        return None


def process_m1(doc, engine):
    """Module 1: MDB Filter Clogging — run ensemble prediction.
    Falls back to rule-based scoring if engine is not loaded."""
    if doc is None:
        return {"error": "no_data", "ensemble_risk": 0, "risk_score": 0, "health": None}

    # ── If engine is available, use it ──
    if engine is not None:
        try:
            result = engine.predict(doc)
            risk = result.get("ensemble_risk", result.get("binary_score", 0))
            hp = max(0, min(100, round((1 - risk) * 100)))
            return {
                "ensemble_risk": risk,
                "risk_score": risk,
                "confidence": result.get("confidence", 0),
                "model_results": result.get("model_scores", {}),
                "health": hp,
                "telemetry": {k: doc.get(k) for k in ["charger_temp", "humidity", "edgebox_temp",
                              "MDB_ambient_temp", "pi5_temp", "MDB_humidity", "MDB_pressure",
                              "dust_filter_charging", "MDB_status"] if k in doc},
                "source": "mongodb",
                "method": "ai_engine",
            }
        except Exception as e:
            logger.error(f"  M1 engine error: {e}")
            # Fall through to rule-based

    # ── Rule-based fallback (same weighted scoring as Rule Engine algorithm) ──
    # Weights: filter_age 35%, MDB_temp 15%, temp_diff 15%, humidity 12%, pi5 10%, pressure 8%, status 5%
    try:
        risk = 0.0
        factors = 0

        # Filter age (35%) — higher age = higher risk
        filter_age = doc.get("dust_filter_charging")
        if filter_age is not None:
            try:
                age = float(filter_age)
                # 0 days = 0 risk, 120+ days = 1.0 risk
                risk += 0.35 * min(1.0, max(0, age / 120.0))
                factors += 0.35
            except:
                pass

        # MDB ambient temperature (15%) — higher temp = higher risk
        mdb_temp = doc.get("MDB_ambient_temp")
        if mdb_temp is not None:
            try:
                t = float(mdb_temp)
                # 25°C = 0 risk, 50°C+ = 1.0 risk
                risk += 0.15 * min(1.0, max(0, (t - 25) / 25.0))
                factors += 0.15
            except:
                pass

        # Temperature differential (15%) — larger diff = higher risk (blocked airflow)
        pi5_temp = doc.get("pi5_temp")
        if mdb_temp is not None and pi5_temp is not None:
            try:
                diff = abs(float(pi5_temp) - float(mdb_temp))
                # 0°C diff = 0 risk, 20°C+ diff = 1.0 risk
                risk += 0.15 * min(1.0, max(0, diff / 20.0))
                factors += 0.15
            except:
                pass

        # Humidity (12%) — higher humidity = higher risk
        humidity = doc.get("MDB_humidity") or doc.get("humidity")
        if humidity is not None:
            try:
                h = float(humidity)
                # 40% = 0 risk, 90%+ = 1.0 risk
                risk += 0.12 * min(1.0, max(0, (h - 40) / 50.0))
                factors += 0.12
            except:
                pass

        # Pi5 CPU temp (10%)
        if pi5_temp is not None:
            try:
                p = float(pi5_temp)
                # 40°C = 0 risk, 80°C+ = 1.0 risk
                risk += 0.10 * min(1.0, max(0, (p - 40) / 40.0))
                factors += 0.10
            except:
                pass

        # Pressure (8%) — abnormal pressure = risk
        pressure = doc.get("MDB_pressure")
        if pressure is not None:
            try:
                pres = float(pressure)
                # Normal ~1013 hPa, deviation = risk
                deviation = abs(pres - 1013) / 50.0
                risk += 0.08 * min(1.0, max(0, deviation))
                factors += 0.08
            except:
                pass

        # MDB status (5%) — offline = high risk
        status = doc.get("MDB_status")
        if status is not None:
            is_active = str(status).lower() in ("active", "online", "connected", "1")
            risk += 0.05 * (0.0 if is_active else 1.0)
            factors += 0.05

        # Normalize if not all factors present
        if factors > 0:
            risk = risk / factors * 1.0  # Scale to full range
        risk = max(0, min(1, risk))

        hp = max(0, min(100, round((1 - risk) * 100)))

        return {
            "ensemble_risk": round(risk, 4),
            "risk_score": round(risk, 4),
            "confidence": round(factors, 2),
            "model_results": {},
            "health": hp,
            "telemetry": {k: doc.get(k) for k in ["charger_temp", "humidity", "edgebox_temp",
                          "MDB_ambient_temp", "pi5_temp", "MDB_humidity", "MDB_pressure",
                          "dust_filter_charging", "MDB_status", "meter1", "meter2"] if k in doc},
            "source": "mongodb",
            "method": "rule_based_fallback",
        }
    except Exception as e:
        logger.error(f"  M1 rule-based error: {e}")
        return {"error": str(e), "ensemble_risk": 0, "health": 50, "method": "error_fallback"}


def process_m2(doc):
    """Module 2: Charger Filter Clogging — thermal analysis."""
    if doc is None:
        return {"error": "no_data", "health": None}
    temps = []
    for i in range(1, 6):
        v = doc.get(f"power_module_temp{i}")
        if v is not None:
            try: temps.append(float(v))
            except: pass
    max_t = max(temps) if temps else 0
    hot = max_t > 55
    hp = max(0, min(100, round(100 - (max_t - 35) * 2.5))) if temps else 100
    return {
        "data": doc,
        "fields": len(doc),
        "max_pm_temp": max_t,
        "health": hp,
        "status": "warn" if hot else "ok",
    }


def process_m3(doc):
    """Module 3: Charger Offline Detection — device status check."""
    if doc is None:
        return {"error": "no_data", "health": None}
    active_vals = ["Active", "active", "Connected", "connected", "Online", "online", "1", 1]
    devs = ["edgebox_status", "router_status", "PLC1_status", "PLC2_status", "MDB_status", "energy_meter_status"]
    online = sum(1 for d in devs if doc.get(d) in active_vals)
    total = len(devs)
    hp = round(online / total * 100)
    return {
        "data": doc,
        "online_count": online,
        "total_devices": total,
        "health": hp,
        "status": "ok" if online == total else ("warn" if online >= total - 1 else "crit"),
    }


def _safe_float(val, default=0.0):
    """Safely convert value to float, return default if None or invalid."""
    if val is None:
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        return default


def process_m4(doc, cond_engine=None, rule_engine=None):
    """Module 4: Power Delivery Anomaly — condition-based + rule engine."""
    if doc is None:
        return {"error": "no_data", "anomaly_flags": 0, "health": None}
    anomaly_flags = 0
    soc = _safe_float(doc.get("SOC"))
    ct = _safe_float(doc.get("charger_temp"))
    # Simple rule-based checks
    if _safe_float(doc.get("present_voltage1")) > 0 and _safe_float(doc.get("present_current1")) == 0:
        anomaly_flags += 1
    for i in range(1, 6):
        t = _safe_float(doc.get(f"power_module_temp{i}"))
        if t > 55:
            anomaly_flags += 1
    if cond_engine and cond_engine.ready:
        try:
            ai_scores = cond_engine.predict(doc)
            for k, v in ai_scores.items():
                if _safe_float(v.get("ai_score")) > 0.5:
                    anomaly_flags += 1
        except Exception as e:
            logger.warning(f"  M4 cond_engine error: {e}")
    hp = max(0, min(100, 100 - anomaly_flags * 15))
    return {
        "anomaly_flags": anomaly_flags,
        "soc": soc,
        "charger_temp": ct,
        "health": hp,
        "status": "ok" if anomaly_flags == 0 else ("warn" if anomaly_flags <= 2 else "crit"),
    }


def process_m5(doc):
    """Module 5: Network Problem — device status analysis."""
    if doc is None:
        return {"error": "no_data", "health": None}
    active_vals = ["Active", "active", "Connected", "connected", "Online", "online", "1", 1]
    # Try all known field names (different stations use different names)
    dev_groups = [
        ["router_status", "router_net"],
        ["PLC_network_status1", "PLC1_status", "plc_state1"],
        ["PLC_network_status2", "PLC2_status", "plc_state2"],
        ["edgebox_network_status", "edgebox_status"],
        ["pi5_network_status", "pi5_status"],
        ["energy_meter_network_status1", "energy_meter_status"],
    ]
    online = 0
    total = 0
    for group in dev_groups:
        val = None
        for key in group:
            v = doc.get(key)
            if v is not None:
                val = v
                break
        if val is not None:
            total += 1
            if val in active_vals:
                online += 1
    if total == 0:
        total = len(dev_groups)
    severity = 1 - (online / total) if total > 0 else 1
    root_cause = "NORMAL" if severity == 0 else "NETWORK_ISSUE"
    hp = max(0, min(100, round((1 - severity) * 100)))
    return {
        "data": {"root_cause": root_cause, "severity": severity, "online": online, "total": total},
        "health": hp,
        "status": "ok" if severity == 0 else ("warn" if severity < 0.5 else "crit"),
    }


def process_m6(doc):
    """Module 6: RUL — physics-based remaining useful life estimation.
    Uses Arrhenius model but properly calculates RUL% as:
      effective_life = rated_hours / acceleration_factor
      assumed_used = rated_hours * 0.3 (assume 30% life used — no actual hour counter)
      rul% = max(0, (effective_life - assumed_used) / effective_life * 100)
    """
    if doc is None:
        return {"error": "no_data", "system_health": None, "avg_health": None}
    components = {}
    # Arrhenius parameters
    ambient = _safe_float(doc.get("charger_temp", 30), 30)
    ea = 0.7; kb = 8.617e-5; t_ref = 298.15  # 25°C reference
    t_actual = max(ambient, 15) + 273.15  # clamp min 15°C
    try:
        af = math.exp((ea / kb) * (1/t_ref - 1/t_actual))
    except:
        af = 1.0
    af = max(1.0, min(af, 20.0))  # clamp 1-20x

    # Electronic components — RUL based on thermal stress
    # usage_factor: fraction of rated life consumed (lower = newer charger)
    elec_parts = {
        "router": {"rated": 70000, "usage_factor": 0.05},
        "energy_meter_1": {"rated": 80000, "usage_factor": 0.04},
        "energy_meter_2": {"rated": 80000, "usage_factor": 0.04},
        "edgebox": {"rated": 60000, "usage_factor": 0.06},
        "pi5": {"rated": 80000, "usage_factor": 0.05},
        "plc_1": {"rated": 100000, "usage_factor": 0.03},
        "plc_2": {"rated": 100000, "usage_factor": 0.03},
        "power_supply": {"rated": 60000, "usage_factor": 0.06},
        "insulation_monitor_1": {"rated": 80000, "usage_factor": 0.04},
        "insulation_monitor_2": {"rated": 80000, "usage_factor": 0.04},
        "switching_psu": {"rated": 60000, "usage_factor": 0.06},
    }
    for name, spec in elec_parts.items():
        # Temperature penalty: at 25°C af=1.0→rul=100%, at higher temps rul decreases
        # Max penalty is 50% at extreme temps (af=20x)
        temp_penalty = min(50, (af - 1) / 19 * 50)
        # Base aging assumes ~20% usage
        base_aging = spec["usage_factor"] * 100
        rul_pct = max(0, min(100, round(100 - base_aging - temp_penalty)))
        components[name] = {"rul_pct": rul_pct, "method": "arrhenius", "rated": spec["rated"]}

    # Contactors (cycle-based)
    contactors = {
        "dc_contactor_1": 100000, "dc_contactor_2": 100000, "dc_contactor_3": 100000,
        "dc_contactor_4": 100000, "dc_contactor_5": 100000, "dc_contactor_6": 100000,
        "ac_contactor_1": 300000, "ac_contactor_2": 300000,
    }
    # Read actual cycle counts from doc if available
    for name, rated in contactors.items():
        field = name.replace("_contactor_", "_contractor_").replace("dc_", "DC_").replace("ac_", "AC_magnetic_")
        cycles = _safe_float(doc.get(field, 0), 0)
        if cycles > 0:
            rul_pct = max(0, min(100, round((1 - cycles / rated) * 100)))
        else:
            rul_pct = 85  # assumed if no data
        components[name] = {"rul_pct": rul_pct, "method": "cycle_counting", "rated": rated}

    # Power modules — individual thermal stress
    for i in range(1, 6):
        t = _safe_float(doc.get(f"power_module_temp{i}", 35), 35)
        t = max(t, 15)
        t_k = t + 273.15
        try:
            pm_af = math.exp((ea / kb) * (1/t_ref - 1/t_k))
        except:
            pm_af = 1.0
        pm_af = max(1.0, min(pm_af, 20.0))
        temp_penalty = min(50, (pm_af - 1) / 19 * 50)
        rul = max(0, min(100, round(100 - 25 - temp_penalty)))  # 25% base aging
        components[f"power_module_{i}"] = {"rul_pct": rul, "method": "arrhenius", "rated": 80000}

    # Fans
    for i in range(1, 9):
        components[f"dc_fan_{i}"] = {"rul_pct": 80, "method": "runtime", "rated": 50000}

    all_pcts = [c["rul_pct"] for c in components.values()]
    # Use weighted average instead of min (min is too pessimistic)
    sys_health = round(sum(all_pcts) / len(all_pcts) * 0.8 + min(all_pcts) * 0.2) if all_pcts else 0
    avg_health = sum(all_pcts) / len(all_pcts) if all_pcts else 0
    weakest = min(components, key=lambda k: components[k]["rul_pct"]) if components else ""
    return {
        "system_health": sys_health,
        "avg_health": round(avg_health, 1),
        "components": components,
        "weakest_component": weakest,
        "health": sys_health,
    }


def process_m7(doc):
    """Module 7: EV-PLCC State — ISO 15118 protocol check."""
    if doc is None:
        return {"error": "no_data", "health": None}
    anomaly_count = 0
    # Try all possible field names for ICP (numeric ID 0-10)
    icp_raw = None
    for key in ["ICPState", "icp_state", "ICP_state", "icp1", "CP_status1", "cp_state1"]:
        v = doc.get(key)
        if v is not None:
            icp_raw = v
            break
    # Try all possible field names for USLink (numeric ID 0-22)
    usl_raw = None
    for key in ["UslinkState", "uslink_state", "Uslink_state", "usl1", "PLC1_status", "plc_state1"]:
        v = doc.get(key)
        if v is not None:
            usl_raw = v
            break
    # Convert to int (JS expects numeric)
    icp = None
    if icp_raw is not None:
        try: icp = int(float(str(icp_raw)))
        except: icp = None
    usl = None
    if usl_raw is not None:
        try: usl = int(float(str(usl_raw)))
        except: usl = None
    # ICP anomaly check
    valid_icp = [1, 2, 3, 4, 5, 6, 7, 8]  # A1-D2 are normal
    if icp is not None and icp not in valid_icp:
        anomaly_count += 1
    model_results = {
        "rule_engine": {"anomaly": anomaly_count > 0, "icp": icp, "usl": usl},
    }
    hp = max(0, min(100, 100 - anomaly_count * 10))
    # ICP/USLink name mapping
    icp_names = {0:"Inactive",1:"A1",2:"B1",3:"C1",4:"D1",5:"A2",6:"B2",7:"C2",8:"D2",9:"E",10:"Error"}
    usl_names = {0:"Ready",1:"Init",2:"SLAC ok",3:"SECC ok",4:"SupportedAppProtocol",5:"SessionSetup",
                 6:"ServiceDiscovery",7:"ServicePaymentSelection",8:"ContractAuthentication",
                 9:"ChargeParameterDiscovery",10:"CableCheck",11:"PreCharge",12:"PowerDelivery Start",
                 13:"CurrentDemand",14:"MeteringReceipt",15:"PowerDelivery Stop",16:"WeldingDetection",
                 17:"SessionStop",18:"Paused",19:"Renegotiation",20:"Error",21:"Timeout",22:"Unknown"}
    return {
        "model_results": model_results,
        "anomaly_count": anomaly_count,
        "health": hp,
        "source": "mongodb",
        "icp_state": icp,
        "uslink_state": usl,
        "icp_name": icp_names.get(icp, f"Unknown({icp})") if icp is not None else None,
        "uslink_name": usl_names.get(usl, f"Unknown({usl})") if usl is not None else None,
    }


# ====================================================================
# WRITE RESULTS TO MONGODB
# ====================================================================

def write_result(results_db, station_sn, module_key, result, processing_ms=0):
    """Write one module result to eds_ai_results.{station_sn}."""
    try:
        col = results_db[station_sn]
        doc = {
            "module": module_key,
            "timestamp": datetime.now(timezone.utc),
            "result": result,
            "processing_ms": processing_ms,
        }
        col.update_one(
            {"module": module_key},
            {"$set": doc},
            upsert=True
        )
        return True
    except Exception as e:
        logger.error(f"  write_result({station_sn}.{module_key}): {e}")
        return False


# ====================================================================
# DISCOVER STATIONS
# ====================================================================

def build_sn_name_map(mongo_client):
    """Build bidirectional SN ↔ station_name mapping from iMPS.charger + M1 DB.
    Returns: sn_to_name (dict), name_to_sn (dict)
    """
    sn_to_name = {}  # F1500624011 → Klongluang3
    name_to_sn = {}  # Klongluang3 → F1500624011

    # ── Step 1: Read ALL charger records (no projection — avoid missing fields) ──
    charger_docs = []
    try:
        charger_docs = list(mongo_client["iMPS"]["charger"].find({}, {"_id": 0}))
        if charger_docs:
            sample = charger_docs[0]
            logger.info(f"  [MAP] iMPS.charger: {len(charger_docs)} docs, fields={list(sample.keys())}")
    except Exception as e:
        logger.warning(f"  [MAP] iMPS.charger read failed: {e}")

    for c in charger_docs:
        sn = str(c.get("SN", "")).strip()
        # Try multiple possible name fields
        name = ""
        for key in ["station_id", "StationName", "stationName", "Station_Name", "station_name", "StationID"]:
            v = c.get(key)
            if v and str(v).strip():
                name = str(v).strip()
                break
        if sn and name and sn != name:
            sn_to_name[sn] = name
            name_to_sn[name] = sn

    # ── Step 2: Check M1 collections — match unmapped names against charger records ──
    try:
        m1_cols = set(mongo_client[SOURCE_DBS["m1"]["db"]].list_collection_names())
        m1_cols = {c for c in m1_cols if not c.startswith("system.")}
        logger.info(f"  [MAP] M1 collections: {m1_cols}")

        for col_name in m1_cols:
            if col_name in name_to_sn:
                logger.info(f"  [MAP] M1 '{col_name}' → already mapped to SN '{name_to_sn[col_name]}'")
                continue
            if col_name in sn_to_name:
                logger.info(f"  [MAP] M1 '{col_name}' is itself an SN → maps to name '{sn_to_name[col_name]}'")
                continue
            # Try to find matching charger record
            matched_sn = None
            for c in charger_docs:
                sn = str(c.get("SN", "")).strip()
                for key in ["station_id", "StationName", "stationName", "Station_Name", "station_name"]:
                    v = c.get(key)
                    if v and str(v).strip() == col_name and sn and sn != col_name:
                        matched_sn = sn
                        break
                if matched_sn:
                    break
            if matched_sn:
                sn_to_name[matched_sn] = col_name
                name_to_sn[col_name] = matched_sn
                logger.info(f"  [MAP] M1 '{col_name}' → matched to SN '{matched_sn}' (from charger record)")
            else:
                logger.warning(f"  [MAP] M1 '{col_name}' → NO matching SN found in iMPS.charger!")
    except Exception as e:
        logger.warning(f"  [MAP] M1 collection scan failed: {e}")

    logger.info(f"  [MAP] Total mappings: {len(sn_to_name)}")
    for sn, name in sorted(sn_to_name.items()):
        logger.info(f"    {sn} ↔ {name}")
    return sn_to_name, name_to_sn


def discover_stations(mongo_client, sn_to_name=None, name_to_sn=None):
    """Find all unique stations. Deduplicate SN vs station_name for the same physical station.
    Returns list of canonical keys (prefer SN over name)."""
    raw = set()
    # From iMPS.charger
    try:
        chargers = list(mongo_client["iMPS"]["charger"].find({}, {"SN": 1, "_id": 0}))
        for c in chargers:
            sn = c.get("SN", "")
            if sn:
                raw.add(sn)
    except Exception as e:
        logger.warning(f"  iMPS.charger error: {e}")
    # From module DB collections
    for mod_key, cfg in SOURCE_DBS.items():
        try:
            db = mongo_client[cfg["db"]]
            for col_name in db.list_collection_names():
                if not col_name.startswith("system."):
                    raw.add(col_name)
        except:
            pass

    # Deduplicate: if both SN and its station_name exist, keep only SN
    if name_to_sn:
        deduped = set()
        merged = []
        for key in raw:
            if key in name_to_sn:
                sn = name_to_sn[key]
                deduped.add(sn)
                merged.append(f"{key}→{sn}")
            else:
                deduped.add(key)
        if merged:
            logger.info(f"  [DEDUP] Merged {len(merged)} name→SN: {merged}")
        logger.info(f"  [DEDUP] {len(raw)} raw → {len(deduped)} unique stations")
        return sorted(deduped)
    return sorted(raw)


# ====================================================================
# MAIN PROCESSING LOOP
# ====================================================================

def process_station(mongo_client, results_db, sn, cond_engine=None, m1_engine=None,
                    sn_to_name=None, name_to_sn=None):
    """Run all module predictions for one station and write results.
    M1 uses station_name as collection, M2-M7 use SN."""
    logger.info(f"  ── Processing station: {sn} ──")
    if sn_to_name and sn in sn_to_name:
        logger.info(f"    [COL] M1→[{sn_to_name[sn]}, {sn}]  M2-M7→[{sn}]")
    modules_ok = 0
    results_cache = {}  # Fix #4: cache results to avoid re-reading from DB

    # Determine collection names for M1 vs M2-M7
    m1_col_names = [sn]
    if sn_to_name and sn in sn_to_name:
        m1_col_names = [sn_to_name[sn], sn]
    elif name_to_sn and sn in name_to_sn:
        m1_col_names = [sn, name_to_sn[sn]]

    m27_col_names = [sn]
    if sn_to_name and sn in sn_to_name:
        m27_col_names = [sn, sn_to_name[sn]]
    elif name_to_sn and sn in name_to_sn:
        m27_col_names = [name_to_sn[sn], sn]

    for mod_key, cfg in SOURCE_DBS.items():
        t0 = time.time()
        candidates = m1_col_names if mod_key == "m1" else m27_col_names

        # Try each candidate until we find data
        doc = None
        used_col = candidates[0]
        for col_name in candidates:
            doc = read_latest(mongo_client, cfg["db"], col_name, cfg["ts_field"])
            if doc is not None:
                used_col = col_name
                break

        if mod_key == "m1":
            result = process_m1(doc, m1_engine)
        elif mod_key == "m2":
            result = process_m2(doc)
        elif mod_key == "m3":
            result = process_m3(doc)
        elif mod_key == "m4":
            result = process_m4(doc, cond_engine)
        elif mod_key == "m5":
            result = process_m5(doc)
        elif mod_key == "m6":
            result = process_m6(doc)
        elif mod_key == "m7":
            result = process_m7(doc)
        else:
            continue

        elapsed = round((time.time() - t0) * 1000, 1)
        ok = write_result(results_db, sn, mod_key, result, elapsed)
        results_cache[mod_key] = result  # Fix #4: cache instead of re-read
        status = "✅" if ok and not result.get("error") else "⚠️"
        health = result.get("health", "N/A")
        col_info = f" [{used_col}]" if used_col != sn else ""
        logger.info(f"    {status} {mod_key.upper()}: health={health}, {elapsed}ms{col_info}")
        if ok:
            modules_ok += 1

    # Fix #4: Compute weighted health FROM CACHE (no DB re-reads)
    weights = {"m1": 12, "m2": 12, "m3": 16, "m4": 20, "m5": 12, "m6": 18, "m7": 10}
    weighted_sum = 0
    weight_total = 0
    module_scores = {}
    for mod_key, result in results_cache.items():
        h = result.get("health")
        if h is not None:
            w = weights.get(mod_key, 10)
            weighted_sum += h * w
            weight_total += w
            module_scores[mod_key] = h
    system_health = round(weighted_sum / weight_total) if weight_total > 0 else None
    write_result(results_db, sn, "system_health", {
        "score": system_health,
        "modules_processed": modules_ok,
        "total_modules": len(SOURCE_DBS),
    })

    # Write time-series health to eds_system_health.{SN}
    if system_health is not None:
        try:
            health_db = mongo_client[HEALTH_DB_NAME]
            health_col = health_db[sn]
            health_col.insert_one({
                "timestamp": datetime.now(timezone.utc),
                "score": system_health,
                "modules": module_scores,
                "modules_processed": modules_ok,
            })
            # Fix #5: TTL index created once in main(), not per-station
        except Exception as e:
            logger.warning(f"  Health history write failed for {sn}: {e}")

    logger.info(f"  ── {sn} done: {modules_ok}/{len(SOURCE_DBS)} modules, system_health={system_health} ──")
    return modules_ok



def _monitor_station_meta(mongo_client):
    """Read station metadata from iMPS.charger.  station_id → display name."""
    meta = {}
    try:
        docs = list(mongo_client["iMPS"]["charger"].find({}, {"_id": 0}))
        if docs:
            logger.info(f"  iMPS.charger: {len(docs)} docs, sample keys={list(docs[0].keys())}")
        for c in docs:
            sn = c.get("SN")
            if not sn:
                continue
            # station_id contains the human-readable station name
            station_name = c.get("station_id") or c.get("StationName") or sn
            meta[sn] = {
                "sn": sn,
                "name": str(station_name),
                "station_id": str(c.get("station_id", "")),
                "model": c.get("Model", ""),
                "province": c.get("Province", ""),
                "location": c.get("Location", ""),
            }
    except Exception as e:
        logger.warning(f"  monitor meta load failed: {e}")
    return meta


def build_monitor_summary(mongo_client, results_db):
    """Build cached all-station monitor summary for /api/monitor/overview."""
    t0 = time.time()
    sn_to_name, name_to_sn = build_sn_name_map(mongo_client)
    stations = discover_stations(mongo_client, sn_to_name, name_to_sn)
    meta_map = _monitor_station_meta(mongo_client)
    rows = []
    full_coverage = 0
    partial = 0
    no_data = 0

    for sn in stations:
        meta = meta_map.get(sn, {"sn": sn, "name": sn, "station_id": "", "model": "", "province": "", "location": ""})
        col = results_db[sn]
        mods = {}
        ok_count = 0
        last_updated = None

        # Fix #6: Single batch query per station instead of 8 individual queries
        try:
            all_mods = ["m1", "m2", "m3", "m4", "m5", "m6", "m7", "system_health"]
            cursor = col.find({"module": {"$in": all_mods}}, max_time_ms=3000)
            doc_map = {}
            for doc in cursor:
                doc_map[doc.get("module")] = doc
        except Exception:
            doc_map = {}

        for mod_key in SOURCE_DBS:
            doc = doc_map.get(mod_key)
            if doc:
                ts = doc.get("timestamp")
                if ts and (last_updated is None or ts > last_updated):
                    last_updated = ts
                result = doc.get("result", {}) or {}
                health = result.get("health")
                err = result.get("error")
                mod_entry = {
                    "health": health,
                    "error": err,
                    "timestamp": ts.isoformat() if hasattr(ts, 'isoformat') else str(ts),
                }
                mods[mod_key] = mod_entry
                if health is not None and not err:
                    ok_count += 1
            else:
                mods[mod_key] = {"health": None}

        sys_doc = doc_map.get("system_health")
        system_health = None
        modules_processed = ok_count
        if sys_doc:
            sys_ts = sys_doc.get("timestamp")
            if sys_ts and (last_updated is None or sys_ts > last_updated):
                last_updated = sys_ts
            sys_res = sys_doc.get("result", {}) or {}
            system_health = sys_res.get("score")
            modules_processed = sys_res.get("modules_processed", ok_count)

        if ok_count == len(SOURCE_DBS):
            full_coverage += 1
        elif ok_count == 0:
            no_data += 1
        else:
            partial += 1

        rows.append({
            "sn": sn,
            "name": meta.get("name", sn),
            "station_id": meta.get("station_id", ""),
            "model": meta.get("model", ""),
            "province": meta.get("province", ""),
            "location": meta.get("location", ""),
            "modules": mods,
            "ok_count": ok_count,
            "modules_processed": modules_processed,
            "system_health": system_health,
            "last_updated": last_updated.isoformat() if hasattr(last_updated, 'isoformat') else (str(last_updated) if last_updated else None),
        })

    rows.sort(key=lambda r: (-r["ok_count"], r["name"], r["sn"]))
    summary = {
        "total_stations": len(rows),
        "full_coverage": full_coverage,
        "partial": partial,
        "no_data": no_data,
    }
    build_ms = round((time.time() - t0) * 1000, 1)
    results_db["_monitor_summary"].update_one(
        {"_id": "latest"},
        {"$set": {
            "_id": "latest",
            "timestamp": datetime.now(timezone.utc),
            "stations": rows,
            "summary": summary,
            "build_ms": build_ms,
        }},
        upsert=True,
    )
    logger.info(f"  ✅ Monitor summary cached: {len(rows)} station(s), {build_ms}ms")
    return {"stations": rows, "summary": summary, "build_ms": build_ms}


def main():
    import argparse
    parser = argparse.ArgumentParser(description="EDS AI Backend Worker")
    parser.add_argument("--interval", type=int, default=120, help="Processing interval in seconds (default: 120)")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    parser.add_argument("--mongo-uri", default=MONGO_URI, help="MongoDB URI")
    args = parser.parse_args()

    logger.info("=" * 60)
    logger.info("  EGAT EV AI Platform — Backend Worker")
    logger.info("=" * 60)
    logger.info(f"  Interval : {args.interval}s")
    logger.info(f"  MongoDB  : {args.mongo_uri[:50]}...")
    logger.info(f"  Results DB: {RESULTS_DB_NAME}")
    logger.info(f"  Health DB : {HEALTH_DB_NAME} (1 collection per station, TTL 90 days)")

    # Connect to MongoDB
    from pymongo import MongoClient
    mongo_client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=10000)
    try:
        mongo_client.admin.command("ping")
        logger.info("  ✅ MongoDB connected")
    except Exception as e:
        logger.error(f"  ❌ MongoDB connection failed: {e}")
        sys.exit(1)

    results_db = mongo_client[RESULTS_DB_NAME]

    # Fix #5: Create TTL indexes once at startup (not per-station)
    _ttl_indexed = set()
    def ensure_ttl_index(sn):
        if sn not in _ttl_indexed:
            try:
                mongo_client[HEALTH_DB_NAME][sn].create_index(
                    "timestamp", expireAfterSeconds=90*24*3600)
                _ttl_indexed.add(sn)
            except:
                _ttl_indexed.add(sn)  # skip on error, don't retry

    # Load AI engines
    cond_engine = PerConditionEngine()
    m1_engine = None
    try:
        m1_engine = InferenceEngine()
        logger.info(f"  ✅ InferenceEngine loaded ({len(m1_engine.models)} models)")
    except Exception as e:
        logger.warning(f"  ⚠ InferenceEngine not loaded: {e}")

    # Graceful shutdown
    running = True
    def handle_signal(sig, frame):
        nonlocal running
        logger.info("Shutting down...")
        running = False
    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    # Main loop
    cycle = 0
    while running:
        cycle += 1
        logger.info(f"\n{'='*60}")
        logger.info(f"  Cycle #{cycle} — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"{'='*60}")

        # Build SN ↔ station_name mapping (once per cycle)
        sn_to_name, name_to_sn = build_sn_name_map(mongo_client)

        stations = discover_stations(mongo_client, sn_to_name, name_to_sn)
        logger.info(f"  Found {len(stations)} station(s): {stations[:5]}{'...' if len(stations)>5 else ''}")

        for sn in stations:
            try:
                ensure_ttl_index(sn)  # Fix #5: create TTL index once per station
                process_station(mongo_client, results_db, sn, cond_engine, m1_engine,
                                sn_to_name, name_to_sn)
            except Exception as e:
                logger.error(f"  ❌ Station {sn} failed: {e}")

        try:
            build_monitor_summary(mongo_client, results_db)
        except Exception as e:
            logger.error(f"  ❌ Monitor summary build failed: {e}")

        logger.info(f"  Cycle #{cycle} complete.")
        if args.once:
            logger.info("  --once flag: exiting.")
            break

        logger.info(f"  Sleeping {args.interval}s until next cycle...")
        for _ in range(args.interval):
            if not running:
                break
            time.sleep(1)

    mongo_client.close()
    logger.info("Backend worker stopped.")


if __name__ == "__main__":
    main()
