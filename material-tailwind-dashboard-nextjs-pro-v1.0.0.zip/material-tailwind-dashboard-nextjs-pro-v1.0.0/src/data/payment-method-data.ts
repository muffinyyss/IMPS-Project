export const paymentMethodData = [
  {
    img: "/img/logo/mastercard.webp",
    number: "****,****,****,7852",
  },
  {
    img: "/img/logo/visa.webp",
    number: "****,****,****,5248",
  },
];

export default paymentMethodData;
