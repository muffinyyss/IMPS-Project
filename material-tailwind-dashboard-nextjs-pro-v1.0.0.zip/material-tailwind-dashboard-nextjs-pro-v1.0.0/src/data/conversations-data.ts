export const conversationsData = [
  {
    img: "/img/kal-visuals-square.jpg",
    name: "Sophie B.",
    message: "Hi! I need more information...",
  },
  {
    img: "/img/marie.jpg",
    name: "Alexander",
    message: "Awesome work, can you...",
  },
  {
    img: "/img/ivana-square.jpg",
    name: "Ivanna",
    message: "About files I can...",
  },
  {
    img: "/img/team-4.jpeg",
    name: "Peterson",
    message: "Have a great afternoon...",
  },
  {
    img: "/img/team-3.jpg",
    name: "Bruce Mars",
    message: "Hi! I need more information...",
  },
];

export default conversationsData;
