export const masterCardData = {
  name: "Jack Peterson",
  date: "11/22",
  number: 4562112245947852,
};

export default masterCardData;
