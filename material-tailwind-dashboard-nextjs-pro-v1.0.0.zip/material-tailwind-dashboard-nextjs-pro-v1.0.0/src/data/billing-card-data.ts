export const billingCardData = [
  {
    title: "Oliver Liam",
    options: {
      "Company Name": "Viking Burrito",
      "Email Address": "oliver@burrito.com",
      "VAT Number": "FRB1235476",
    },
  },
  {
    title: "Lucas Harper",
    options: {
      "Company Name": "Stone Tech Zone",
      "Email Address": "lucas@stone-tech.com",
      "VAT Number": "FRB1235476",
    },
  },
  {
    title: "Ethan James",
    options: {
      "Company Name": "Fiber Notion",
      "Email Address": "ethan@fiber.com",
      "VAT Number": "FRB1235476",
    },
  },
];

export default billingCardData;
