export const invoiceCardData = [
  {
    date: "March, 01, 2023",
    detail: "#MS-415646",
    value: "$180",
  },
  {
    date: "February, 10, 2023",
    detail: "#RV-126749",
    value: "$250",
  },
  {
    date: "April, 05, 2023",
    detail: "#QW-103578",
    value: "$120",
  },
  {
    date: "June, 25, 2023",
    detail: "#MS-415646",
    value: "$180",
  },
  {
    date: "March, 01, 2023",
    detail: "#MS-415646",
    value: "$300",
  },
];

export default invoiceCardData;
