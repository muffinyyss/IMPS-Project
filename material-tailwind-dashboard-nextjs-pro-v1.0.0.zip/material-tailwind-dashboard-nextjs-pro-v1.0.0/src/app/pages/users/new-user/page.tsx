// component
import Steppers from "./components/steppers";

export default function NewUser() {
  return (
    <div className="tw-grid tw-h-[calc(100vh-128px)] tw-place-items-center">
      <Steppers />
    </div>
  );
}
