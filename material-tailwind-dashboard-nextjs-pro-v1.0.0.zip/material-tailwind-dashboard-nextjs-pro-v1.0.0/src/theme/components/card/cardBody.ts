export const cardBody = {
  defaultProps: {
    className: "",
  },
  styles: {
    base: {
      p: "tw-p-6",
    },
  },
};

export default cardBody;
