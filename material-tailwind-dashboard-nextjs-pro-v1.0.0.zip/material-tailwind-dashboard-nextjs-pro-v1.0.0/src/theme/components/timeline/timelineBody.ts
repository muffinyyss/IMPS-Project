export const timelineBody = {
  styles: {
    base: {
      display: "tw-flex",
      gap: "tw-gap-4",
    },
  },
};

export default timelineBody;
