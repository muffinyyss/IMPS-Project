export const timeline = {
  styles: {
    base: {
      display: "tw-w-full",
      position: "tw-flex",
      flexDirection: "tw-flex-col",
    },
  },
};

export default timeline;
