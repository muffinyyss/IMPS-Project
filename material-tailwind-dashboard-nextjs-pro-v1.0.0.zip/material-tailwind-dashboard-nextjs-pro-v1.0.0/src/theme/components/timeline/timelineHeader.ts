export const timelineHeader = {
  styles: {
    base: {
      display: "tw-flex",
      alignItems: "tw-items-center",
      gap: "tw-gap-4",
    },
  },
};

export default timelineHeader;
