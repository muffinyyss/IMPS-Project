export const speedDial = {
  defaultProps: {
    offset: 5,
    placement: "tw-top",
    dismiss: undefined,
    animate: {
      unmount: {},
      mount: {},
    },
  },
};

export default speedDial;
