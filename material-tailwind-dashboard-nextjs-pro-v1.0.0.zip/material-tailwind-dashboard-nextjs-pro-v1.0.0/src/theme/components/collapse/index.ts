export const collapse = {
  styles: {
    base: {
      display: "tw-block",
      width: "tw-w-full",
      basis: "tw-basis-full",
      overflow: "tw-overflow-hidden",
    },
  },
};

export default collapse;
