"use client";

/**
 * หน้า PM report — "ใบเดียว 2 ส่วนหลัก"
 *
 * เดิมแท็บ Charger / Station / MDB / CCB / CB_BOX แยกกัน 5 แท็บ 5 เอกสาร
 * ตอนนี้ไม่มีแท็บแล้ว รวมเป็นเอกสารใบเดียว (1 เลขที่ / 1 PDF / อนุมัติครั้งเดียว)
 * ที่ข้างในแบ่งเป็น 2 ส่วนหลัก — Station รวม Station/MDB/CCB/CB_BOX และ Charger
 * มีใบย่อยตู้ละ 1 ใบ เพราะสถานีหนึ่งมีหลายตู้ แต่ยังใช้เลขที่เอกสารใบเดียวกัน
 *
 * 3 หน้าจออยู่ในไฟล์เดียว เลือกด้วย query string:
 *   ไม่มีอะไร                       → ตารางใบ PM ของสถานีนี้
 *   ?view=form&job_id=              → หน้ารวม 2 ส่วนหลักของใบนั้น (hub)
 *   ?view=form&job_id=&section=     → ฟอร์มกรอกของส่วนนั้น (ใช้ฟอร์มเดิมทั้งดุ้น)
 *                                     ส่วน charger ส่ง &sn= ของตู้ไปด้วย
 *   ?view=form&edit_id= (ไม่มี job_id) → ลิงก์เก่าจากหน้า PM List ที่ชี้ไปเอกสาร
 *                                     ใบเดี่ยวก่อนรวมใบ — เปิดฟอร์มของชนิดนั้นตรง ๆ
 *
 * backend: routers/pmreport_station_job.py
 */

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  Button, Card, CardBody, CardHeader, Dialog, DialogBody, DialogFooter, DialogHeader, Input, Typography,
} from "@material-tailwind/react";
import {
  ArrowLeftIcon, CheckCircleIcon, ClipboardDocumentListIcon, DocumentArrowDownIcon, PencilSquareIcon, PlusIcon, XMarkIcon,
} from "@heroicons/react/24/outline";
import { discardOpenFormDraft } from "@/app/dashboard/pm-report/lib/discardDraft";
import { PmCancelEditContext, PmReviewActionContext } from "@/app/dashboard/pm-report/lib/reviewAction";
import { apiFetch } from "@/utils/api";
import { useLanguage, type Lang } from "@/utils/useLanguage";
import LoadingOverlay from "@/app/dashboard/components/Loadingoverlay";
import { PM_APPROVE_ROLES, PmStatusBadge, toPmFlow } from "@/app/dashboard/pm-report/components/flow";
import PmPlanForm from "@/app/dashboard/pm-report/components/PmPlanForm";
import PmWorkOrderInfo from "@/app/dashboard/pm-report/components/PmWorkOrderInfo";
import { pmBackRoute } from "@/app/dashboard/pm-report/lib/origin";

// ฟอร์มกรอกของแต่ละส่วน — ของเดิมทั้งหมด ไม่ได้แก้เนื้อ checklist
import StationPMForm from "@/app/dashboard/pm-report/station/input_PMreport/components/checkList";
import MDBPMForm from "@/app/dashboard/pm-report/mdb/input_PMreport/components/checkList";
import CCBPMForm from "@/app/dashboard/pm-report/ccb/input_PMreport/components/checkList";
import CBBOXPMForm from "@/app/dashboard/pm-report/cb-box/input_PMreport/components/checkList";
import ChargerPMForm from "@/app/dashboard/pm-report/charger/input_PMreport/components/checkList";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";

type SectionId = "station" | "mdb" | "ccb" | "cbbox" | "charger";

type SectionGroupId = "station" | "charger";

/** หน้าเว็บยุบฟอร์มจริง 5 ชนิดให้เหลือ 2 ส่วนหลัก โดยไม่เปลี่ยนโครงสร้างข้อมูล/PDF เดิม */
const SECTION_GROUPS: Array<{ id: SectionGroupId; sectionIds: SectionId[] }> = [
  { id: "station", sectionIds: ["station", "mdb", "ccb", "cbbox"] },
  { id: "charger", sectionIds: ["charger"] },
];

/** ส่วนที่ผูกกับตู้ (มีใบย่อยได้หลายใบ) ไม่ใช่กับสถานี */
const CHARGER_SECTION: SectionId = "charger";

/** role ที่กด "แก้ไข" ส่วนที่ส่งแล้วได้ — ต้องตรงกับ backend (pmreport_station_job.EDIT_SENT_ROLES) */
const PM_EDIT_SENT_ROLES = ["technician", "planner", "admin", "super_admin"];

const SECTION_FORMS: Record<SectionId, React.ComponentType> = {
  station: StationPMForm,
  mdb: MDBPMForm,
  ccb: CCBPMForm,
  cbbox: CBBOXPMForm,
  charger: ChargerPMForm,
};

const SECTION_TITLE: Record<SectionId, { th: string; en: string }> = {
  station: { th: "Station", en: "Station" },
  mdb: { th: "MDB", en: "MDB" },
  ccb: { th: "CCB", en: "CCB" },
  cbbox: { th: "CB_BOX", en: "CB_BOX" },
  charger: { th: "ตู้ชาร์จ", en: "Charger" },
};

const SECTION_HINT: Record<SectionId, { th: string; en: string }> = {
  station: { th: "โครงสร้างสถานี ป้าย ไฟส่องสว่าง ถังดับเพลิง", en: "Structure, signs, lighting, fire extinguisher" },
  mdb: { th: "ตู้ MDB เบรกเกอร์ แรงดันไฟฟ้า Trip test", en: "MDB cabinet, breakers, voltage, trip tests" },
  ccb: { th: "ตู้ CCB เบรกเกอร์ย่อย แรงดันไฟฟ้า", en: "CCB cabinet, sub-breakers, voltage" },
  cbbox: { th: "CB Box จุดต่อ และอุปกรณ์ป้องกัน", en: "CB Box, connections and protection devices" },
  charger: { th: "ตู้ชาร์จทุกตู้ในสถานี — กรอกทีละตู้", en: "Every charger at this station — one checklist each" },
};

const SECTION_GROUP_HINT: Record<SectionGroupId, { th: string; en: string }> = {
  station: {
    th: "รวมแบบตรวจ Station, MDB, CCB และ CB_BOX",
    en: "Includes the Station, MDB, CCB and CB_BOX checklists",
  },
  charger: SECTION_HINT.charger,
};

/** slug ที่ลิงก์เก่า (tab=… ของหน้า PM List) ใช้ → ส่วนในใบรวม */
const SLUG_TO_SECTION: Record<string, SectionId> = {
  station: "station",
  mdb: "mdb",
  ccb: "ccb",
  "cb-box": "cbbox",
  cbbox: "cbbox",
  charger: "charger",
};

type SectionState = {
  section: SectionId;
  label: { th: string; en: string };
  /** ส่วน charger เท่านั้น — SN ของตู้ที่ใบย่อยนี้ผูกอยู่ */
  sn: string;
  charger_no: string;
  report_id: string;
  status: string;
  side: string;
  inspector: string;
  /** ช่างกด N/A ไว้ — ส่วนนี้ไม่ต้องกรอก (มีได้เฉพาะส่วนที่ยังไม่มีเอกสาร) */
  na?: boolean;
};

type Job = {
  id: string;
  station_id: string;
  station_name: string;
  issue_id: string;
  doc_name: string;
  pm_date: string;
  wonum: string;
  inspector: string;
  status: string;
  sections: SectionState[];
  sections_done: number;
  sections_total: number;
  approved_by?: string;
  reject_remark?: string;
  /** ส่งครบทุกส่วนในแผนแล้ว ช่างกด "ปิดใบงาน" ได้ */
  ready_to_submit?: boolean;
  /** ส่วนที่ยังขาดก่อนกด "ปิดใบงาน" ได้ */
  missing?: { th: string; en: string }[];
  submitted_by?: string;
  /** เวลาที่ช่างกด "เริ่ม PM" (รับงาน) — เป็นค่าเริ่มต้นของเวลาเริ่ม PM ตอนปิดใบงาน */
  createdAt?: string;
  /** กรอกตอนกด "ปิดใบงาน" — เติมกลับให้ตอนกดใหม่หลังโดนตีกลับ */
  work_start?: string;
  work_finish?: string;
  maximo_labor?: string[];
  maximo_contractor?: string;
  /** ใบที่ไม่ได้ผูกกับ Maximo — ผู้ปฏิบัติงานเป็นบัญชี iMPS แทน laborcode */
  imps_labor?: string[];
};

type LaborOption = { laborcode: string; name: string; needs_name?: boolean };

type Me = { username: string; role: string };

const T = {
  pageTitle: { th: "Preventive Maintenance Checklist - Station", en: "Preventive Maintenance Checklist - Station" },
  pageSubtitle: {
    th: "ใบ PM ของสถานี — 2 ส่วนหลัก: Station และ Charger",
    en: "Station PM document — two main sections: Station and Charger",
  },
  newDoc: { th: "+ เปิดใบใหม่", en: "+ New document" },
  colNo: { th: "ลำดับ", en: "No." },
  colDocName: { th: "ชื่อเอกสาร", en: "Document" },
  colIssueId: { th: "รหัสเอกสาร", en: "Issue ID" },
  colPmDate: { th: "วันที่", en: "Date" },
  colSections: { th: "ส่วนที่กรอกแล้ว", en: "Sections filled" },
  colStatus: { th: "สถานะ", en: "Status" },
  colPdf: { th: "PDF", en: "PDF" },
  search: { th: "ค้นหา", en: "Search" },
  loading: { th: "กำลังโหลด…", en: "Loading…" },
  noData: { th: "ยังไม่มีใบ PM ของสถานีนี้", en: "No PM documents for this station yet" },
  selectStationFirst: { th: "กรุณาเลือกสถานีจากแถบบนก่อน", en: "Please select a station first" },

  dialogTitle: { th: "เปิดใบ PM ใหม่", en: "New PM document" },
  pmDateLabel: { th: "วันที่ตรวจสอบ", en: "PM date" },
  wonumLabel: { th: "เลขใบงาน Maximo (ถ้ามี)", en: "Maximo work order (optional)" },
  cancel: { th: "ยกเลิก", en: "Cancel" },
  create: { th: "เปิดใบ", en: "Create" },

  jobTitle: { th: "ใบบำรุงรักษาสถานี (PM)", en: "Station PM document" },
  station: { th: "สถานี", en: "Station" },
  docNo: { th: "เลขที่เอกสาร", en: "Issue ID" },
  docName: { th: "ชื่อเอกสาร", en: "Document" },
  pmDate: { th: "วันที่ PM", en: "PM date" },
  wonum: { th: "ใบงาน Maximo", en: "Maximo WO" },
  sectionsTitle: { th: "ส่วนของเอกสาร", en: "Document sections" },
  sectionsHint: {
    th: "2 ส่วนหลักอยู่ในเอกสารเลขที่เดียวกัน — MDB, CCB และ CB_BOX รวมอยู่ใน Station",
    en: "Both sections share one document number — MDB, CCB and CB_BOX are grouped under Station",
  },
  edit: { th: "แก้ไข", en: "Edit" },
  cancelEdit: { th: "ยกเลิกการแก้ไข", en: "Cancel edit" },
  cancelEditConfirm: {
    th: "สิ่งที่แก้ไขไว้ รวมถึงรูปที่แนบใหม่ จะถูกทิ้ง และเอกสารจะกลับเป็นข้อมูลที่บันทึกไว้ก่อนหน้า ต้องการยกเลิกการแก้ไขใช่หรือไม่?",
    en: "Your changes, including newly attached photos, will be discarded and the document will return to its previously saved version. Do you want to cancel editing?",
  },
  continueEdit: { th: "แก้ไขต่อ", en: "Continue editing" },
  confirmCancelEdit: { th: "ยืนยันยกเลิก", en: "Confirm cancel" },
  cancellingEdit: { th: "กำลังยกเลิก…", en: "Cancelling…" },
  view: { th: "ดู", en: "View" },
  notFilled: { th: "ยังไม่กรอก", en: "Not filled" },
  downloadPdf: { th: "PDF ทั้งใบ", en: "Full PDF" },
  pdfClosedOnly: { th: "โหลด PDF ได้หลังอนุมัติใบงานแล้ว (Closed)", en: "PDF is available once the document is approved (Closed)" },
  closeJob: { th: "ปิดใบงาน", en: "Close work order" },
  closingJob: { th: "กำลังปิดใบงาน…", en: "Closing…" },
  closeJobHint: {
    th: "กรอกเวลาทำงานจริงและช่างที่ลงเวลาเข้า Maximo แล้วส่งให้ผู้อนุมัติ — หลังจากนี้แก้ไขเอกสารไม่ได้ จนกว่าจะถูกตีกลับ",
    en: "Enter the actual work time and the technicians to log in Maximo, then send for approval. The document can't be edited afterwards unless it is sent back.",
  },
  closeJobHintNoMaximo: {
    th: "กรอกเวลาทำงานจริงและผู้ปฏิบัติงาน แล้วส่งให้ผู้อนุมัติ — หลังจากนี้แก้ไขเอกสารไม่ได้ จนกว่าจะถูกตีกลับ",
    en: "Enter the actual work time and who did the work, then send for approval. The document can't be edited afterwards unless it is sent back.",
  },
  impsLabor: { th: "ผู้ปฏิบัติงาน (บัญชี iMPS)", en: "Technicians (iMPS accounts)" },
  impsLaborEmpty: { th: "ไม่พบบัญชี iMPS ในบริษัทของคุณ", en: "No iMPS accounts found in your company" },
  errImpsLabor: { th: "กรุณาเลือกผู้ปฏิบัติงานอย่างน้อย 1 คน", en: "Select at least one technician" },
  workStart: { th: "วันที่เวลาเริ่ม PM", en: "PM start" },
  workFinish: { th: "วันที่เวลา PM เสร็จ", en: "PM finish" },
  maximoLabor: { th: "ช่างที่ลงเวลากับ Maximo", en: "Technicians to log in Maximo" },
  maximoLaborEmpty: { th: "โหลดรายชื่อช่างจาก Maximo ไม่ได้", en: "Could not load technicians from Maximo" },
  contractorName: { th: "ชื่อผู้รับเหมา", en: "Contractor name" },
  errWorkTime: { th: "กรุณากรอกวันที่เวลาเริ่มและเสร็จ", en: "Please enter the start and finish time" },
  errWorkOrder: { th: "เวลาเสร็จต้องไม่ก่อนเวลาเริ่ม", en: "Finish must not be before start" },
  errWorkFuture: {
    th: "เวลาทำงานต้องไม่เป็นเวลาในอนาคต — Maximo ไม่รับเวลาที่ยังมาไม่ถึง",
    en: "Work time cannot be in the future — Maximo rejects times that have not happened yet",
  },
  errLabor: { th: "กรุณาเลือกช่างที่ลงเวลากับ Maximo อย่างน้อย 1 คน", en: "Select at least one technician" },
  errContractor: { th: "กรุณาระบุชื่อผู้รับเหมา", en: "Please enter the contractor name" },
  confirmClose: { th: "ปิดใบงาน", en: "Close work order" },
  closeJobMissing: { th: "ยังกรอกไม่ครบ:", en: "Still missing:" },
  closeJobEmpty: { th: "ยังไม่มีส่วนไหนถูกกรอก", en: "No section has been filled yet" },
  sectionSent: { th: "กรอกแล้ว", en: "Done" },
  back: { th: "ย้อนกลับ", en: "Back" },

  approve: { th: "อนุมัติทั้งใบ", en: "Approve document" },
  reject: { th: "ตีกลับ", en: "Send back" },
  rejectReason: { th: "เหตุผลที่ตีกลับ", en: "Reason" },
  rejected: { th: "ถูกตีกลับให้แก้:", en: "Sent back for fixes:" },
  approved: { th: "อนุมัติแล้วโดย", en: "Approved by" },
  rejectConfirm: {
    th: "ตีกลับทั้งใบให้ช่างแก้ — ระบุเหตุผลให้ช่างรู้ว่าต้องแก้อะไร",
    en: "Send the whole document back for fixes. Tell the technician what to change.",
  },
  rejecting: { th: "กำลังตีกลับ…", en: "Sending back…" },

  errLoad: { th: "โหลดใบ PM ไม่สำเร็จ", en: "Failed to load PM documents" },
  errCreate: { th: "เปิดใบใหม่ไม่สำเร็จ", en: "Failed to create document" },
  errAction: { th: "ทำรายการไม่สำเร็จ", en: "Action failed" },

  noChargers: { th: "สถานีนี้ยังไม่มีตู้ชาร์จในระบบ", en: "No chargers registered at this station" },
  chargersDone: { th: "กรอกแล้ว", en: "filled" },
  na: { th: "N/A", en: "N/A" },
  markNa: { th: "ไม่ต้องกรอกส่วนนี้ (N/A)", en: "Mark as N/A (no need to fill)" },
  undoNa: { th: "ยกเลิก N/A — กลับไปต้องกรอก", en: "Undo N/A — fill this section" },
  naTitle: { th: "ไม่ต้องกรอกส่วนนี้ (N/A)", en: "Mark as N/A" },
  confirmNa: {
    th: "ส่วนที่ N/A ไม่ต้องกรอก และจะไม่อยู่ใน PDF — ยกเลิก N/A ได้จนกว่าจะกดปิดใบงาน",
    en: "This section won't need to be filled and won't appear in the PDF. You can undo N/A until the job is closed.",
  },
  confirmNaButton: { th: "ยืนยัน N/A", en: "Confirm N/A" },
  savingNa: { th: "กำลังบันทึก…", en: "Saving…" },
} as const;

const t = (k: keyof typeof T, lang: Lang) => T[k][lang === "en" ? "en" : "th"];
const pick = (v: { th: string; en: string }, lang: Lang) => (lang === "en" ? v.en : v.th);

function todayISO() {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** Date → ค่าของ input datetime-local ตามเวลาเครื่อง "YYYY-MM-DDTHH:MM" */
function toLocalDatetimeInput(d: Date) {
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

/**
 * ค่าเริ่มต้นของเวลาเริ่ม PM = วันนี้ + เวลาที่กดรับงาน (createdAt ของใบ)
 * ถ้ารับงานไว้ตั้งแต่วันก่อนแล้วเวลานั้นของวันนี้ยังมาไม่ถึง ใช้วันเวลารับงานจริงแทน (Maximo ไม่รับเวลาอนาคต)
 */
function defaultWorkStart(createdAt: string | undefined, now: Date) {
  if (!createdAt) return "";
  // backend ส่ง datetime ของ Mongo เป็น UTC ไม่มี offset ต่อท้าย — ต้องบอกเองว่าเป็น UTC
  const accepted = new Date(/[zZ]|[+-]\d{2}:?\d{2}$/.test(createdAt) ? createdAt : `${createdAt}Z`);
  if (Number.isNaN(accepted.getTime())) return "";
  const today = new Date(now);
  today.setHours(accepted.getHours(), accepted.getMinutes(), 0, 0);
  return toLocalDatetimeInput(today <= now ? today : accepted);
}

function fmtDate(iso: string, lang: Lang) {
  if (!iso) return "-";
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(iso) ? `${iso}T00:00:00Z` : iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString(lang === "en" ? "en-GB" : "th-TH-u-ca-gregory", {
    day: "2-digit", month: "short", year: "numeric", timeZone: "UTC",
  });
}

/** ชื่อสถานะของ 1 ส่วนที่คนอ่านรู้เรื่อง — ใบเก่าเก็บเป็น "submitted" */
function sectionStatusLabel(status: string, lang: Lang, jobClosedByTech = true) {
  const s = String(status || "").trim().toLowerCase();
  if (!s) return t("notFilled", lang);
  if (s === "na") return t("na", lang);
  // ส่วนที่ช่างส่งจากฟอร์มแล้ว แต่ยังไม่ได้กด "ปิดใบงาน" — ยังไม่ได้รออนุมัติจริง
  if (s === "wait for approve") return jobClosedByTech ? "Wait for approve" : t("sectionSent", lang);
  if (s === "draft") return lang === "en" ? "Draft" : "กำลังกรอก";
  return "Closed";
}

/**
 * สถานะรวมของ 1 ส่วน — ส่วน charger มีหลายใบย่อย จึงต้องยุบให้เหลือสถานะเดียว
 *
 * ยังไม่มีใบไหนถูกกรอก = ""  (ยังไม่กรอก)
 * มีใบที่ยังกรอกไม่เสร็จ หรือกรอกไม่ครบทุกตู้ = draft
 * ส่งครบแล้วแต่ยังมีใบรออนุมัติ = wait for approve
 * ปิดครบทุกใบ = closed
 */
function aggregateStatus(allRows: SectionState[]): string {
  if (!allRows.length) return "";
  // ส่วนที่ N/A ไม่ต้องกรอก — ไม่เอามาคิดสถานะ, N/A ทั้งหมด = "na"
  const rows = allRows.filter((r) => !r.na);
  if (!rows.length) return "na";
  const filled = rows.filter((r) => !!r.report_id);
  if (!filled.length) return "";
  const statuses = filled.map((r) => String(r.status || "").trim().toLowerCase());
  if (filled.length < rows.length) return "draft";
  if (statuses.some((x) => x === "draft")) return "draft";
  if (statuses.some((x) => x === "wait for approve")) return "wait for approve";
  return "closed";
}

/** สถานะของ 1 ส่วน → ป้ายสีในหน้า hub และในตาราง */
function sectionChipClass(status: string) {
  const s = String(status || "").trim().toLowerCase();
  if (!s) return "tw-bg-gray-100 tw-text-gray-400 tw-border-gray-200";
  if (s === "na") return "tw-bg-gray-100 tw-text-gray-500 tw-border-gray-300";
  if (s === "wait for approve") return "tw-bg-purple-50 tw-text-purple-700 tw-border-purple-200";
  if (s === "draft") return "tw-bg-amber-50 tw-text-amber-700 tw-border-amber-200";
  return "tw-bg-green-50 tw-text-green-700 tw-border-green-200";
}

/**
 * ปุ่มชื่ออุปกรณ์ของใบลูก 1 ใบ — ไอคอนบอกว่าเปิดกรอก/แก้ไขหรือดู
 * ข้าง ๆ มีปุ่ม N/A ให้กดว่าส่วนนี้ไม่ต้องกรอก (เฉพาะส่วนที่ยังไม่มีเอกสาร และใบยังไม่ได้ปิดใบงาน)
 */
function SectionFillButton({
  job, state, lang, onOpen, onToggleNa, busy = false,
}: {
  job: Job;
  state: SectionState;
  lang: Lang;
  onOpen: (job: Job, s: SectionState) => void;
  onToggleNa: (job: Job, s: SectionState, na: boolean) => void;
  busy?: boolean;
}) {
  const filled = !!state.report_id;
  const status = String(state.status).trim().toLowerCase();
  const sent = filled && ["closed", "submitted", "wait for approve"].includes(status);
  const label = pick(state.label, lang);
  const action = sent ? t("view", lang) : filled ? t("edit", lang) : label;
  // ไอคอนหน้าชื่ออุปกรณ์บอกสถานะของฟอร์ม:
  //   ยังไม่กรอก = แบบฟอร์ม | ส่งแล้ว (เสร็จ) = เครื่องหมายถูกสีเขียว | กลับไปแก้ไข (บันทึกไว้แต่ยังไม่ส่ง) = ดินสอ
  const Icon = sent ? CheckCircleIcon : filled ? PencilSquareIcon : ClipboardDocumentListIcon;
  const iconClass = sent ? "tw-text-green-600" : filled ? "tw-text-amber-600" : "";
  const na = !!state.na;
  // ปิดใบงานแล้ว (รออนุมัติ/ปิด) เปลี่ยน N/A ไม่ได้ — ปุ่มหายไป เหลือแค่ป้าย N/A
  const canToggleNa = job.status === "draft" && !filled;
  return (
    // ไม่ยืดเต็มการ์ด — กว้างพอดีชื่ออุปกรณ์ + ปุ่ม N/A (มือถือยังเต็มความกว้างให้กดง่าย)
    <div className="tw-flex tw-w-full tw-items-stretch tw-gap-1.5 sm:tw-max-w-[15rem]">
      {na ? (
        <div
          title={`${label}: ${t("na", lang)}`}
          className="tw-flex tw-min-w-0 tw-flex-1 tw-items-center tw-justify-center tw-gap-1.5 tw-rounded-lg tw-border tw-border-dashed tw-border-gray-300 tw-bg-gray-50 tw-px-3 tw-py-2 tw-text-xs tw-font-bold tw-uppercase tw-text-gray-400"
        >
          <span className="tw-truncate tw-line-through">{label}</span>
          <span className="tw-rounded tw-bg-gray-200 tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-text-gray-600">
            {t("na", lang)}
          </span>
        </div>
      ) : (
        <Button
          size="sm"
          variant={filled ? "outlined" : "filled"}
          onClick={() => onOpen(job, state)}
          title={`${action}: ${label}`}
          aria-label={`${action}: ${label}`}
          className="tw-flex tw-min-w-0 tw-flex-1 tw-items-center tw-justify-center tw-gap-1.5"
        >
          <Icon className={`tw-h-4 tw-w-4 tw-shrink-0 ${iconClass}`} /> <span className="tw-truncate">{label}</span>
        </Button>
      )}
      {canToggleNa && (
        <Button
          size="sm"
          variant={na ? "filled" : "outlined"}
          color="gray"
          disabled={busy}
          onClick={() => onToggleNa(job, state, !na)}
          title={`${label}: ${na ? t("undoNa", lang) : t("markNa", lang)}`}
          aria-label={`${label}: ${na ? t("undoNa", lang) : t("markNa", lang)}`}
          aria-pressed={na}
          className="tw-shrink-0 tw-px-3"
        >
          {t("na", lang)}
        </Button>
      )}
    </div>
  );
}

export default function StationPmJobTables() {
  const { lang } = useLanguage();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [stationId, setStationId] = useState<string | null>(null);
  const [sn, setSn] = useState<string | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filtering, setFiltering] = useState("");
  const [acting, setActing] = useState(false);
  const [cancelEditOpen, setCancelEditOpen] = useState(false);
  const [cancellingEdit, setCancellingEdit] = useState(false);

  const [newOpen, setNewOpen] = useState(false);
  const [newDate, setNewDate] = useState(todayISO);
  const [newWonum, setNewWonum] = useState("");

  // ปิดใบงาน: เวลาทำงานจริง + ช่างที่ลงเวลา Maximo กรอกครั้งเดียวที่นี่ (ฟอร์มแต่ละส่วนไม่มีแล้ว)
  const [closeOpen, setCloseOpen] = useState(false);
  const [workStart, setWorkStart] = useState("");
  const [workFinish, setWorkFinish] = useState("");
  const [maximoLabor, setMaximoLabor] = useState<string[]>([]);
  const [maximoContractor, setMaximoContractor] = useState("");
  const [laborOptions, setLaborOptions] = useState<LaborOption[]>([]);
  // ใบที่ไม่ได้ผูกกับ Maximo: เลือกผู้ปฏิบัติงานจากบัญชี iMPS ใน company เดียวกับคนที่ login
  const [impsLabor, setImpsLabor] = useState<string[]>([]);
  const [coworkers, setCoworkers] = useState<string[]>([]);
  const [closeError, setCloseError] = useState("");

  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectRemark, setRejectRemark] = useState("");

  // ส่วนที่กำลังจะกด N/A — รอยืนยันใน pop-up
  const [naConfirm, setNaConfirm] = useState<{ job: Job; state: SectionState } | null>(null);
  const [naError, setNaError] = useState("");

  const jobId = searchParams.get("job_id") ?? "";
  // ทางเข้าจากใบงาน Maximo (หน้า PM List ส่งมา) — ทุกชนิดเข้าทางนี้หมดแล้ว
  const planningWonum = searchParams.get("planning") === "1" ? (searchParams.get("wonum") ?? "") : "";
  const woInfoWonum = searchParams.get("wo_info") === "1" ? (searchParams.get("wonum") ?? "") : "";
  // ช่างกด "เริ่ม PM" ได้จากทั้งสองทางเข้า — หน้าวางแผน (planning=1) คือทางเข้าปกติของช่างแล้ว
  // ส่วน wo_info=1 เหลือไว้ให้ลิงก์เก่าที่ผู้ใช้ bookmark ไว้ยังเปิดได้
  const openWonum = planningWonum || woInfoWonum;
  const section = (searchParams.get("section") ?? "") as SectionId | "";
  const editId = searchParams.get("edit_id") ?? "";
  const isFormView = searchParams.get("view") === "form" && !!jobId;
  // ใบงาน Maximo ของตู้ผูกกับ SN ไม่ใช่ station_id — ต้องบอก PmPlanForm/PmWorkOrderInfo ให้ถูก
  const woSource = SLUG_TO_SECTION[searchParams.get("tab") ?? ""] === CHARGER_SECTION ? "charger" : "station";

  // ── สถานีที่เลือกอยู่ — กติกาเดียวกับตาราง PM ตัวอื่น ──
  useEffect(() => {
    const fromUrl = searchParams.get("station_id");
    if (fromUrl) {
      setStationId(fromUrl);
      localStorage.setItem("selected_station_id", fromUrl);
      return;
    }
    setStationId(localStorage.getItem("selected_station_id"));
  }, [searchParams]);

  // ── ตู้ที่เลือกอยู่ — ใช้กับใบงาน Maximo ของ charger เท่านั้น
  // ส่วน charger ในใบรวมเลือกตู้จากการ์ดในหน้า hub ไม่ได้ใช้ค่านี้
  useEffect(() => {
    const fromUrl = searchParams.get("sn");
    if (fromUrl) {
      setSn(fromUrl);
      localStorage.setItem("selected_sn", fromUrl);
      return;
    }
    setSn(localStorage.getItem("selected_sn"));
  }, [searchParams]);

  useEffect(() => {
    (async () => {
      try {
        const res = await apiFetch("/me");
        if (!res.ok) return;
        const u = await res.json();
        setMe({ username: u?.username ?? "", role: String(u?.role ?? "").trim().toLowerCase() });
      } catch (err) {
        console.error("fetch /me error:", err);
      }
    })();
  }, []);

  // laborcode ฝั่ง Maximo — username ใน iMPS ใช้แทนกันไม่ได้ ต้องให้เลือกเอง
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await apiFetch("/cm-maximo/labor-codes");
        if (!res.ok) return;
        const data = await res.json();
        if (alive && Array.isArray(data?.items)) setLaborOptions(data.items);
      } catch { /* โหลดไม่ได้ = ไม่บังคับเลือก ไม่บล็อกการปิดใบงาน */ }
    })();
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await apiFetch("/companies/coworkers");
        if (!res.ok) return;
        const data = await res.json();
        if (alive && Array.isArray(data?.users)) setCoworkers(data.users);
      } catch (err) {
        console.error("load coworkers error:", err);
      }
    })();
    return () => { alive = false; };
  }, []);

  const loadJobs = useCallback(async () => {
    if (!stationId) { setJobs([]); setLoading(false); return; }
    setLoading(true);
    setError("");
    try {
      const res = await apiFetch(`/stationpmjob/list?station_id=${encodeURIComponent(stationId)}`, { cache: "no-store" });
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || `HTTP ${res.status}`);
      setJobs(Array.isArray(json?.items) ? json.items : []);
    } catch (err) {
      console.error("load station pm jobs error:", err);
      setError(err instanceof Error ? err.message : t("errLoad", lang));
      setJobs([]);
    } finally {
      setLoading(false);
    }
  }, [stationId, lang]);

  // ฟอร์มกับหน้ารวมใช้ route เดียวกัน จึงต้องโหลดสถานะใหม่เมื่อเปลี่ยนส่วน/กลับจากฟอร์ม
  useEffect(() => { void loadJobs(); }, [loadJobs, jobId, section]);

  const currentJob = useMemo(
    () => jobs.find((j) => j.id === jobId) ?? null,
    [jobs, jobId]
  );

  const canApprove = PM_APPROVE_ROLES.includes(me?.role ?? "");

  const goto = useCallback((params: Record<string, string | null>) => {
    const next = new URLSearchParams(searchParams.toString());
    next.delete("tab");
    Object.entries(params).forEach(([k, v]) => (v === null ? next.delete(k) : next.set(k, v)));
    router.push(`${pathname}?${next.toString()}`, { scroll: true });
  }, [pathname, router, searchParams]);

  const openJob = (job: Job) => goto({ view: "form", job_id: job.id, section: null, sn: null, edit_id: null, station_id: job.station_id });
  // เข้าหน้ารวมมาจาก PM List → ย้อนกลับไปหน้านั้น ไม่ใช่ตารางใบ PM ของสถานี
  const backToList = () => {
    const back = pmBackRoute(searchParams);
    if (back) { router.push(back); return; }
    goto({ view: null, job_id: null, section: null, sn: null, edit_id: null, review: null, action: null, pmtab: null });
  };

  /** เปิดฟอร์มของส่วนนั้น — มีเอกสารแล้วส่ง edit_id ไปให้ฟอร์มโหลดของเดิม */
  const openSection = (job: Job, s: SectionState) => {
    const closed = ["closed", "submitted"].includes(String(s.status).trim().toLowerCase());
    const waiting = String(s.status).trim().toLowerCase() === "wait for approve";
    goto({
      view: "form",
      job_id: job.id,
      section: s.section,
      station_id: job.station_id,
      // ฟอร์มของตู้อ่าน SN จาก URL — ส่วนอื่นไม่ต้องมี ลบทิ้งกันค้างจากส่วนก่อนหน้า
      sn: s.section === CHARGER_SECTION ? (s.sn || null) : null,
      edit_id: s.report_id || null,
      // ใบที่ปิดแล้ว/รออนุมัติ เปิดเป็นโหมดตรวจอ่านอย่างเดียว เหมือนที่ตารางเดิมทำ
      review: closed || waiting ? "1" : null,
      action: null, pmtab: null,
    });
  };

  /** กด/ยกเลิก N/A ของส่วนหนึ่ง — ส่วนที่ N/A ไม่ต้องกรอก ไม่นับเป็นส่วนที่ขาดตอนปิดใบงาน */
  // กด N/A ต้องยืนยันใน pop-up ก่อน (ยกเลิก N/A ทำได้ทันที ไม่ต้องถาม)
  const toggleNa = (job: Job, s: SectionState, na: boolean) => {
    if (acting) return;
    if (na) { setNaError(""); setNaConfirm({ job, state: s }); return; }
    void saveNa(job, s, false);
  };

  const saveNa = async (job: Job, s: SectionState, na: boolean) => {
    if (acting) return;
    setActing(true);
    try {
      const res = await apiFetch(
        `/stationpmjob/${encodeURIComponent(job.id)}/section-na?station_id=${encodeURIComponent(job.station_id)}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ section: s.section, sn: s.sn || "", na }),
        }
      );
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || t("errAction", lang));
      if (json?.job) setJobs((prev) => prev.map((j) => (j.id === json.job.id ? json.job : j)));
      else await loadJobs();
      setNaConfirm(null);
    } catch (err) {
      const msg = err instanceof Error ? err.message : t("errAction", lang);
      // กด N/A ผ่าน pop-up → ขึ้น error ใน pop-up เลย, ยกเลิก N/A ไม่มี pop-up จึงใช้ alert
      if (na) setNaError(msg); else alert(msg);
    } finally {
      setActing(false);
    }
  };

  /** ออกจากหน้าใบงาน — มาจาก PM List ก็กลับไปหน้านั้น */
  const leaveWo = useCallback(() => {
    const back = pmBackRoute(searchParams);
    if (back) { router.push(back); return; }
    goto({ view: null, planning: null, wo_info: null, wonum: null, started: null, pmtab: null, edit_id: null });
  }, [goto, router, searchParams]);

  /**
   * ช่างกด "เริ่ม PM" จากใบงาน → เปิด (หรือหยิบ) ใบ PM สถานีของใบงานนั้น
   * แล้วพาไปหน้ารวม 2 ส่วนหลัก ให้เลือกเองว่าจะกรอกส่วนไหนก่อน
   *
   * ใบงานของตู้ก็ลงหน้ารวมเหมือนกัน ไม่กระโดดเข้าส่วน Charger ให้ — ช่างต้องเห็นภาพรวม
   * ของใบก่อนว่ามีส่วนไหนต้องทำบ้าง (หน้ารวมมีตัวเลือกตู้ให้อยู่แล้ว)
   */
  const startPmFromWo = useCallback(async () => {
    if (!stationId || !openWonum) return;
    setActing(true);
    try {
      // วันที่ PM ของใบงานนั้น — หาไม่เจอก็ใช้วันนี้
      let pmDate = todayISO();
      try {
        const woRes = await apiFetch(
          `/maximo/pm/open?station_id=${encodeURIComponent(stationId)}&only_open=true&verify=false&limit=200`
        );
        const woJson = await woRes.json().catch(() => ({} as any));
        const hit = (Array.isArray(woJson?.items) ? woJson.items : [])
          .find((w: any) => String(w?.wonum ?? "") === openWonum);
        if (hit?.pm_date) pmDate = String(hit.pm_date).slice(0, 10);
      } catch { /* ใช้วันนี้แทน */ }

      const res = await apiFetch("/stationpmjob/open", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ station_id: stationId, pm_date: pmDate, wonum: openWonum }),
      });
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || t("errCreate", lang));
      await loadJobs();
      goto({
        view: "form", job_id: json?.job?.id ?? null, station_id: stationId,
        section: null, sn: null,
        wo_info: null, planning: null, started: null, pmtab: null,
        edit_id: null, review: null, action: null,
      });
    } catch (err) {
      alert(err instanceof Error ? err.message : t("errCreate", lang));
    } finally {
      setActing(false);
    }
  }, [stationId, openWonum, goto, loadJobs, lang]);

  const createJob = async () => {
    if (!stationId || acting) return;
    setActing(true);
    try {
      const res = await apiFetch("/stationpmjob/open", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ station_id: stationId, pm_date: newDate, wonum: newWonum.trim() || null }),
      });
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || t("errCreate", lang));
      setNewOpen(false);
      setNewWonum("");
      await loadJobs();
      if (json?.job?.id) goto({ view: "form", job_id: json.job.id, section: null, station_id: stationId });
    } catch (err) {
      alert(err instanceof Error ? err.message : t("errCreate", lang));
    } finally {
      setActing(false);
    }
  };

  /**
   * ช่างกด "ปิดใบงาน" → เปิดหน้าต่างกรอกเวลาทำงาน + ช่างที่ลงเวลา Maximo (เติมค่าเดิมถ้าเคยกรอก)
   * ยังไม่เคยกรอก: เริ่ม = วันนี้ + เวลาที่กดรับงาน, เสร็จ = ตอนนี้
   */
  const openCloseJob = () => {
    if (!currentJob || acting || !currentJob.ready_to_submit) return;
    const now = new Date();
    setWorkStart(currentJob.work_start || defaultWorkStart(currentJob.createdAt, now));
    setWorkFinish(currentJob.work_finish || toLocalDatetimeInput(now));
    setMaximoLabor(currentJob.maximo_labor || []);
    setMaximoContractor(currentJob.maximo_contractor || "");
    setImpsLabor(currentJob.imps_labor || []);
    setCloseError("");
    setCloseOpen(true);
  };

  const contractorPicked = laborOptions.some((o) => o.needs_name && maximoLabor.includes(o.laborcode));
  // ไม่มีเลขใบงาน Maximo = ไม่มีอะไรให้ลงเวลาใน Maximo (IN09) — ใช้บัญชี iMPS แทน
  const isMaximoJob = !!currentJob?.wonum;

  /** ตรวจแบบเดียวกับ backend (pm_flow.validate_work_time) — บอกให้แก้ก่อนยิง */
  const closeJobProblem = (): string => {
    if (!workStart || !workFinish) return t("errWorkTime", lang);
    if (workFinish < workStart) return t("errWorkOrder", lang);
    const nowLocal = toLocalDatetimeInput(new Date());
    if (workStart > nowLocal || workFinish > nowLocal) return t("errWorkFuture", lang);
    if (!isMaximoJob) return impsLabor.length === 0 ? t("errImpsLabor", lang) : "";
    if (laborOptions.length > 0 && maximoLabor.length === 0) return t("errLabor", lang);
    if (contractorPicked && !maximoContractor.trim()) return t("errContractor", lang);
    return "";
  };

  /** ส่งทั้งใบเข้าคิวอนุมัติ พร้อมเวลาทำงาน/ช่าง — backend เขียนลงทุกส่วนให้ */
  const submitCloseJob = async () => {
    if (!currentJob || acting) return;
    const problem = closeJobProblem();
    if (problem) { setCloseError(problem); return; }
    setActing(true);
    setCloseError("");
    try {
      const res = await apiFetch(
        `/stationpmjob/${encodeURIComponent(currentJob.id)}/submit?station_id=${encodeURIComponent(currentJob.station_id)}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            work_start: workStart,
            work_finish: workFinish,
            ...(isMaximoJob
              ? { maximo_labor: maximoLabor, maximo_contractor: contractorPicked ? maximoContractor.trim() : "" }
              : { imps_labor: impsLabor }),
          }),
        }
      );
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || t("errAction", lang));
      setCloseOpen(false);
      await loadJobs();
    } catch (err) {
      setCloseError(err instanceof Error ? err.message : t("errAction", lang));
    } finally {
      setActing(false);
    }
  };

  /** คืน true เมื่อสำเร็จ — หน้าฟอร์มใช้พากลับหน้ารวมหลังอนุมัติ/ตีกลับ */
  const approveJob = async (): Promise<boolean> => {
    if (!currentJob || acting) return false;
    setActing(true);
    try {
      const res = await apiFetch(
        `/stationpmjob/${encodeURIComponent(currentJob.id)}/approve?station_id=${encodeURIComponent(currentJob.station_id)}`,
        { method: "POST" }
      );
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || t("errAction", lang));
      await loadJobs();
      return true;
    } catch (err) {
      alert(err instanceof Error ? err.message : t("errAction", lang));
      return false;
    } finally {
      setActing(false);
    }
  };

  const rejectJob = async (): Promise<boolean> => {
    if (!currentJob || acting || !rejectRemark.trim()) return false;
    setActing(true);
    try {
      const res = await apiFetch(
        `/stationpmjob/${encodeURIComponent(currentJob.id)}/reject?station_id=${encodeURIComponent(currentJob.station_id)}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ remark: rejectRemark.trim() }),
        }
      );
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || t("errAction", lang));
      setRejectOpen(false);
      setRejectRemark("");
      await loadJobs();
      return true;
    } catch (err) {
      alert(err instanceof Error ? err.message : t("errAction", lang));
      return false;
    } finally {
      setActing(false);
    }
  };

  // ══════════════ ทางเข้าจากใบงาน Maximo ══════════════
  // ทุก role เข้าหน้าเดียวกันจาก PM List — ผู้วางแผนได้ฟอร์มวางแผน
  // ช่างได้หน้าเดียวกันแบบอ่านอย่างเดียว + ปุ่ม "เริ่ม PM" ท้ายหน้า
  if (planningWonum) {
    return (
      <PmPlanForm
        source={woSource}
        identifier={woSource === "charger" ? sn : stationId}
        wonum={planningWonum}
        onSaved={leaveWo}
        onCancel={leaveWo}
        onStart={() => { void startPmFromWo(); }}
      />
    );
  }
  // ช่างกดจาก PM List → ดูข้อมูลใบงานก่อน แล้วค่อยกด "เริ่ม PM"
  if (woInfoWonum) {
    return (
      <PmWorkOrderInfo
        source={woSource}
        identifier={woSource === "charger" ? sn : stationId}
        wonum={woInfoWonum}
        onStart={() => { void startPmFromWo(); }}
        onCancel={leaveWo}
      />
    );
  }

  // ══════════════ ฟอร์มของส่วนที่เลือก — ฟอร์มเดิมทั้งดุ้น ══════════════
  if (isFormView && section && SECTION_FORMS[section]) {
    const SectionForm = SECTION_FORMS[section];
    const openedSection = currentJob?.sections.find(
      (x) => x.section === section && (section !== CHARGER_SECTION || x.sn === (searchParams.get("sn") ?? ""))
    );
    // เปิดดูส่วนที่ส่งแล้ว → แก้ไขได้จนกว่าจะกด "ปิดใบงาน" (ใบยังเป็น In Progress)
    // เฉพาะ technician / planner / admin (super admin ได้ role admin) — ส่วนที่ปิดแล้ว / ใบที่ส่งอนุมัติแล้ว / หน้าอนุมัติ ดูได้อย่างเดียว
    const viewing = searchParams.get("review") === "1";
    const sectionStatus = String(openedSection?.status ?? "").trim().toLowerCase();
    // ผู้อนุมัติ (planner/admin) เปิดดูส่วนหนึ่งของใบที่ช่างกดปิดใบงานแล้ว → ย้อนกลับ / ตีกลับ / แก้ไข ได้จากในฟอร์มเลย
    // ตีกลับทำทั้งใบเหมือนปุ่มที่หน้ารวม ส่วนอนุมัติกดที่หน้ารวมเท่านั้น (ตรวจครบทุกส่วนก่อนค่อยอนุมัติทั้งใบ)
    const approving = viewing && canApprove && currentJob?.status === "Wait for approve"
      && !!openedSection?.report_id && !["closed", "submitted"].includes(sectionStatus);
    const canEditSent = viewing && PM_EDIT_SENT_ROLES.includes(me?.role ?? "") && !!openedSection?.report_id
      && !["closed", "submitted"].includes(sectionStatus)
      && (currentJob?.status === "draft" || approving);
    // ตัด review ออก = ฟอร์มเดิมในโหมดแก้ไข (key ใหม่ให้โหลดเอกสารใหม่ทั้งหมด พร้อมรูปเดิม)
    const startEdit = () => goto({ review: null, approve: null });
    const backToHub = () => goto({ section: null, sn: null, edit_id: null, review: null, approve: null });
    // ฟอร์มวางปุ่มนี้ตรงตำแหน่งปุ่ม "บันทึก" ของหน้ากรอก (ผ่าน PmReviewActionContext) หน้าตาเดียวกับปุ่มบันทึก
    const editButton = canEditSent ? (
      <Button type="button" onClick={startEdit} className="tw-text-sm tw-py-2.5 tw-bg-gray-800 hover:tw-bg-gray-900 tw-w-full sm:tw-w-auto tw-flex tw-items-center tw-justify-center tw-gap-1.5">
        <PencilSquareIcon className="tw-h-4 tw-w-4" /> {t("edit", lang)}
      </Button>
    ) : null;
    // ปุ่มชุดผู้อนุมัติ: ย้อนกลับ · ตีกลับ · แก้ไข (เรียงซ้าย→ขวา)
    const reviewActions = approving ? (
      <>
        <Button
          type="button"
          variant="outlined"
          disabled={acting}
          onClick={backToHub}
          className="tw-text-sm tw-py-2.5 tw-w-full sm:tw-w-auto tw-border-blue-gray-300 tw-text-blue-gray-700 hover:tw-border-blue-gray-500 hover:tw-bg-blue-gray-50 tw-flex tw-items-center tw-justify-center tw-gap-1.5"
        >
          <ArrowLeftIcon className="tw-h-4 tw-w-4" /> {t("back", lang)}
        </Button>
        <Button
          type="button"
          variant="outlined"
          color="red"
          disabled={acting}
          onClick={() => { setRejectRemark(""); setRejectOpen(true); }}
          className="tw-text-sm tw-py-2.5 tw-w-full sm:tw-w-auto"
        >
          {t("reject", lang)}
        </Button>
        {editButton}
      </>
    ) : editButton;
    // กำลังแก้ส่วนที่ส่งแล้ว (เข้ามาจากปุ่ม "แก้ไข") — ยกเลิกได้ ทิ้งสิ่งที่แก้ในเครื่องแล้วกลับหน้าดู
    // (ส่วนที่ยังเป็น draft เช่นโดนตีกลับ ไม่ได้มาจากปุ่มนี้ ใช้ปุ่มย้อนกลับตามเดิม)
    const editingSent = !viewing && !!openedSection?.report_id && sectionStatus === "wait for approve";
    const cancelEdit = async () => {
      if (cancellingEdit) return;
      setCancellingEdit(true);
      try {
        try { await discardOpenFormDraft(); } catch (err) { console.error("discard draft failed:", err); }
        setCancelEditOpen(false);
        goto({ review: "1", approve: null });
      } finally {
        setCancellingEdit(false);
      }
    };
    const cancelButton = editingSent && (
      <Button
        type="button"
        variant="outlined"
        onClick={() => setCancelEditOpen(true)}
        className="tw-text-sm tw-py-2.5 tw-w-full sm:tw-w-auto tw-border-blue-gray-300 tw-text-blue-gray-700 hover:tw-border-blue-gray-500 hover:tw-bg-blue-gray-50 tw-transition-all"
      >
        {t("cancelEdit", lang)}
      </Button>
    );
    return (
      <div className="tw-mt-4 sm:tw-mt-6 lg:tw-mt-8">
        <PmReviewActionContext.Provider value={reviewActions}>
          <PmCancelEditContext.Provider value={cancelButton}>
            <SectionForm key={viewing ? "view" : "edit"} />
          </PmCancelEditContext.Provider>
        </PmReviewActionContext.Provider>
        {/* modal รูปแบบเดียวกับหน้า CM (overlay + กล่อง max-w-md) — ไม่ใช้ Dialog ของ Material Tailwind ที่บังคับความกว้าง/ฟอนต์เอง */}
        {cancelEditOpen && editingSent && (
          <div
            className="tw-fixed tw-inset-0 tw-z-[9999] tw-flex tw-items-center tw-justify-center tw-bg-black/50 tw-p-4"
            onClick={() => { if (!cancellingEdit) setCancelEditOpen(false); }}
          >
            <div className="tw-w-full tw-max-w-md tw-rounded-2xl tw-bg-white tw-p-6 tw-shadow-2xl" onClick={e => e.stopPropagation()}>
              <h3 className="tw-flex tw-items-center tw-gap-2 tw-text-lg tw-font-bold tw-text-blue-gray-800 tw-mb-2">
                <XMarkIcon className="tw-h-5 tw-w-5 tw-text-amber-600" />
                {t("cancelEdit", lang)}
              </h3>
              <p className="tw-text-sm tw-text-blue-gray-600">
                {t("cancelEditConfirm", lang)}
              </p>
              <div className="tw-flex tw-items-center tw-justify-end tw-gap-3 tw-mt-5">
                <Button
                  type="button"
                  variant="outlined"
                  disabled={cancellingEdit}
                  onClick={() => setCancelEditOpen(false)}
                  className="tw-border-blue-gray-200 tw-text-blue-gray-700 hover:tw-border-blue-gray-300"
                >
                  {t("continueEdit", lang)}
                </Button>
                <Button
                  type="button"
                  disabled={cancellingEdit}
                  onClick={() => { void cancelEdit(); }}
                  className="tw-bg-amber-500 hover:tw-bg-amber-600 tw-text-white tw-font-semibold disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
                >
                  {t(cancellingEdit ? "cancellingEdit" : "confirmCancelEdit", lang)}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ตีกลับทั้งใบ — ต้องมีเหตุผล */}
        {rejectOpen && approving && (
          <div
            className="tw-fixed tw-inset-0 tw-z-[9999] tw-flex tw-items-center tw-justify-center tw-bg-black/50 tw-p-4"
            onClick={() => { if (!acting) setRejectOpen(false); }}
          >
            <div role="dialog" aria-modal="true" className="tw-w-full tw-max-w-md tw-rounded-2xl tw-bg-white tw-p-6 tw-shadow-2xl" onClick={e => e.stopPropagation()}>
              <h3 className="tw-flex tw-items-center tw-gap-2 tw-text-lg tw-font-bold tw-text-blue-gray-800 tw-mb-2">
                <XMarkIcon className="tw-h-5 tw-w-5 tw-text-red-600" />
                {t("reject", lang)}
              </h3>
              <p className="tw-mb-3 tw-text-sm tw-text-blue-gray-600">{t("rejectConfirm", lang)}</p>
              <label className="tw-mb-1 tw-block tw-text-sm tw-font-semibold tw-text-blue-gray-800">
                {t("rejectReason", lang)} <span className="tw-text-red-500">*</span>
              </label>
              <textarea
                rows={3}
                value={rejectRemark}
                autoFocus
                onChange={(e) => setRejectRemark(e.target.value)}
                className="tw-w-full tw-rounded-lg tw-border tw-border-blue-gray-200 tw-px-3 tw-py-2 tw-text-sm tw-text-blue-gray-800 focus:tw-border-blue-500 focus:tw-outline-none"
              />
              <div className="tw-flex tw-items-center tw-justify-end tw-gap-3 tw-mt-5">
                <Button
                  type="button"
                  variant="outlined"
                  disabled={acting}
                  onClick={() => setRejectOpen(false)}
                  className="tw-border-blue-gray-200 tw-text-blue-gray-700 hover:tw-border-blue-gray-300"
                >
                  {t("cancel", lang)}
                </Button>
                <Button
                  type="button"
                  color="red"
                  disabled={acting || !rejectRemark.trim()}
                  onClick={async () => { if (await rejectJob()) backToHub(); }}
                  className="tw-font-semibold disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
                >
                  {t(acting ? "rejecting" : "reject", lang)}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ══════════════ ลิงก์เก่าที่ชี้ไปเอกสารใบเดี่ยว (ก่อนรวมใบ) ══════════════
  // หน้า PM List ส่ง ?tab=<ชนิด>&view=form&edit_id=… มาโดยไม่มี job_id
  // เอกสารพวกนี้ไม่ได้ผูกกับใบแม่ ยังต้องเปิดฟอร์มของชนิดนั้นตรง ๆ ได้เหมือนเดิม
  if (!jobId && searchParams.get("view") === "form" && editId) {
    const legacySection = SLUG_TO_SECTION[searchParams.get("tab") ?? ""] ?? "charger";
    const LegacyForm = SECTION_FORMS[legacySection];
    return (
      <div className="tw-mt-4 sm:tw-mt-6 lg:tw-mt-8">
        <LegacyForm />
      </div>
    );
  }

  // ══════════════ หน้ารวม 2 ส่วนหลักของใบเดียว (hub) ══════════════
  if (isFormView) {
    const job = currentJob;
    if (loading) return <LoadingOverlay show text={t("loading", lang)} />;
    if (!job) {
      return (
        <div className="tw-mt-6">
          <Button variant="outlined" size="sm" onClick={backToList}>{t("back", lang)}</Button>
          <p className="tw-mt-4 tw-text-sm tw-text-gray-500">{t("noData", lang)}</p>
        </div>
      );
    }

    const waiting = job.status === "Wait for approve";
    const closeJobHint = job.ready_to_submit
      ? undefined
      : job.missing?.length
        ? `${t("closeJobMissing", lang)} ${job.missing.map((m) => pick(m, lang)).join(", ")}`
        : t("closeJobEmpty", lang);
    const completedGroups = SECTION_GROUPS.filter((group) => {
      const rows = job.sections.filter((item) => group.sectionIds.includes(item.section));
      const hasEverySection = group.sectionIds.every((sectionId) =>
        rows.some((item) => item.section === sectionId)
      );
      return hasEverySection && rows.length > 0 && rows.every((item) => !!item.report_id || !!item.na);
    }).length;
    // ปิดใบงาน — มีเฉพาะใบที่ยังทำอยู่ กดได้เมื่อส่งครบทุกส่วนในแผนแล้ว
    // ยังไม่ครบ: ปุ่มจาง ชี้ค้างเห็นว่าขาดส่วนไหน
    // วางทั้งแถบบนและท้ายการ์ดทั้ง 2 ใบ — ทุกปุ่มปิดทั้งใบพร้อมกัน (ไม่ได้ปิดแยกรายการ์ด)
    const closeJobButton = job.status === "draft" && (
      <span title={closeJobHint}>
        <Button
          size="sm"
          disabled={!job.ready_to_submit || acting}
          onClick={openCloseJob}
          className="tw-flex tw-items-center tw-gap-1.5 tw-bg-green-600 disabled:tw-pointer-events-none"
        >
          <CheckCircleIcon className="tw-h-4 tw-w-4" />
          {acting ? t("closingJob", lang) : t("closeJob", lang)}
        </Button>
      </span>
    );
    return (
      <div className="tw-mt-4 sm:tw-mt-6 lg:tw-mt-8 tw-mx-auto tw-max-w-5xl">
        <div className="tw-mb-4 tw-flex tw-items-center tw-justify-between tw-gap-3">
          <Button variant="outlined" size="sm" onClick={backToList} className="tw-flex tw-items-center tw-gap-2">
            <ArrowLeftIcon className="tw-h-4 tw-w-4" /> {t("back", lang)}
          </Button>
          <div className="tw-flex tw-flex-wrap tw-items-center tw-justify-end tw-gap-2">
          {closeJobButton}
          {/* PDF ทั้งใบ — โหลดได้เฉพาะใบที่อนุมัติแล้ว (Closed) เหมือนปุ่ม PDF ในหน้า PM List
              ยังไม่ปิด: ปุ่มจาง ชี้ค้างเห็นเหตุผล */}
          {toPmFlow({ status: job.status, reject_remark: job.reject_remark }) === "closed" ? (
            <a
              href={`${API_BASE}/stationpmjob/${encodeURIComponent(job.id)}/pdf?station_id=${encodeURIComponent(job.station_id)}&lang=${lang}`}
              target="_blank"
              rel="noreferrer"
              className="tw-inline-flex tw-items-center tw-gap-1.5 tw-rounded-lg tw-border tw-border-gray-300 tw-px-3 tw-py-2 tw-text-sm tw-font-semibold tw-text-gray-700 hover:tw-bg-gray-50"
            >
              <DocumentArrowDownIcon className="tw-h-4 tw-w-4" /> {t("downloadPdf", lang)}
            </a>
          ) : (
            <span
              title={t("pdfClosedOnly", lang)}
              aria-disabled="true"
              className="tw-inline-flex tw-cursor-not-allowed tw-items-center tw-gap-1.5 tw-rounded-lg tw-border tw-border-gray-300 tw-px-3 tw-py-2 tw-text-sm tw-font-semibold tw-text-gray-700 tw-opacity-50"
            >
              <DocumentArrowDownIcon className="tw-h-4 tw-w-4" /> {t("downloadPdf", lang)}
            </span>
          )}
          </div>
        </div>

        {/* หัวเอกสาร */}
        <Card className="tw-mb-5 tw-border tw-border-gray-200 tw-shadow-sm">
          <CardBody className="tw-p-5">
            <div className="tw-flex tw-items-start tw-justify-between tw-gap-3">
              <div className="tw-min-w-0 tw-flex-1">
                <Typography variant="h5" className="tw-text-gray-900">{t("jobTitle", lang)}</Typography>
                <Typography className="tw-mt-1 tw-text-sm tw-text-gray-500 tw-break-words">
                  {job.station_name || job.station_id}
                </Typography>
              </div>
              <div className="tw-shrink-0">
                <PmStatusBadge flow={toPmFlow({ status: job.status, reject_remark: job.reject_remark })} />
              </div>
            </div>

            {/* ช่องกว้างตามข้อความ ไม่ตัดบรรทัด — ที่ไม่พอทั้งช่องย้ายลงแถวใหม่แทน
                (เดิมเป็น grid กว้างคงที่ เลขที่/ชื่อเอกสารยาว ๆ เลยล้นไปทับช่องข้าง ๆ)
                จอแคบกว่าข้อความจริง ๆ ค่อยตัดท้ายเป็น … ชี้ค้างดูค่าเต็มได้
                ที่ว่างที่เหลือกระจายเท่า ๆ กันรอบทุกช่อง (space-evenly) — gap-x คือระยะห่างขั้นต่ำ */}
            <div className="tw-mt-4 tw-flex tw-flex-wrap tw-justify-evenly tw-gap-x-10 tw-gap-y-3 tw-text-sm">
              {[
                { label: t("docNo", lang), value: job.issue_id || "-" },
                { label: t("docName", lang), value: job.doc_name || "-" },
                { label: t("pmDate", lang), value: fmtDate(job.pm_date, lang) },
                { label: t("wonum", lang), value: job.wonum || "-" },
              ].map((f) => (
                <div key={f.label} className="tw-max-w-full tw-whitespace-nowrap">
                  <div className="tw-text-gray-500">{f.label}</div>
                  <div className="tw-truncate tw-font-semibold tw-text-gray-800" title={f.value}>{f.value}</div>
                </div>
              ))}
            </div>

            {job.reject_remark && (
              <div className="tw-mt-4 tw-rounded-lg tw-border tw-border-amber-200 tw-bg-amber-50 tw-px-4 tw-py-3 tw-text-sm tw-text-amber-800 [overflow-wrap:anywhere]">
                {t("rejected", lang)} {job.reject_remark}
              </div>
            )}
            {job.status === "Closed" && job.approved_by && (
              <div className="tw-mt-4 tw-flex tw-items-start tw-gap-2 tw-text-sm tw-text-green-700">
                <CheckCircleIcon className="tw-h-5 tw-w-5 tw-shrink-0" />
                <span className="tw-min-w-0 [overflow-wrap:anywhere]">{t("approved", lang)} {job.approved_by}</span>
              </div>
            )}
          </CardBody>
        </Card>

        {/* 2 ส่วนหลัก — Station รวม 4 แบบตรวจเดิม ส่วน Charger แตกเป็นใบย่อยรายตู้ */}
        <div className="tw-mb-2 tw-flex tw-flex-wrap tw-items-baseline tw-gap-x-3 tw-gap-y-1">
          <Typography variant="h6" className="tw-text-gray-800">{t("sectionsTitle", lang)}</Typography>
          <span className="tw-min-w-0 tw-text-xs tw-text-gray-500">{t("sectionsHint", lang)}</span>
          <span className="tw-ml-auto tw-shrink-0 tw-text-xs tw-font-semibold tw-text-gray-500">
            {completedGroups}/{SECTION_GROUPS.length}
          </span>
        </div>

        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-4">
          {SECTION_GROUPS.map((group, idx) => {
            const rows = job.sections.filter((x) => group.sectionIds.includes(x.section));
            const groupStatus = aggregateStatus(rows);
            const isCharger = group.id === CHARGER_SECTION;
            const doneCount = rows.filter((x) => !!x.report_id || !!x.na).length;
            return (
              <Card
                key={group.id}
                className="tw-h-full tw-border tw-border-gray-200 tw-shadow-sm"
              >
                {/* การ์ดสูงเท่ากันทั้งแถว (grid stretch) และดันปุ่มปิดใบงานลงล่างสุด
                    — ปุ่มของทั้ง 2 การ์ดจึงอยู่ระดับเดียวกัน แม้จำนวนปุ่มอุปกรณ์จะต่างกัน */}
                <CardBody className="tw-flex tw-h-full tw-flex-col tw-p-4">
                  <div className="tw-flex tw-flex-1 tw-items-start tw-gap-3">
                    <div className="tw-flex tw-h-8 tw-w-8 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-bg-gray-800 tw-text-sm tw-font-bold tw-text-white">
                      {idx + 1}
                    </div>
                    <div className="tw-min-w-0 tw-flex-1">
                      <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2">
                        <span className="tw-font-semibold tw-text-gray-900">
                          {pick(SECTION_TITLE[group.id], lang)}
                        </span>
                        <span className={`tw-whitespace-nowrap tw-rounded-full tw-border tw-px-2 tw-py-0.5 tw-text-[11px] tw-font-semibold ${sectionChipClass(groupStatus)}`}>
                          {sectionStatusLabel(groupStatus, lang, job.status !== "draft")}
                        </span>
                        {rows.length > 0 && (
                          <span className="tw-text-[11px] tw-font-semibold tw-text-gray-500">
                            {doneCount}/{rows.length} {t("chargersDone", lang)}
                          </span>
                        )}
                      </div>
                      <p className="tw-mt-1 tw-text-xs tw-text-gray-500">{pick(SECTION_GROUP_HINT[group.id], lang)}</p>

                      {/* Station — แสดงเฉพาะปุ่มของ Station/MDB/CCB/CB_BOX เรียงต่อกันลงมาทีละปุ่ม */}
                      {!isCharger && (
                        <div className="tw-mt-3 tw-grid tw-grid-cols-1 tw-gap-2">
                          {group.sectionIds.map((sectionId) => {
                            const state = job.sections.find((item) => item.section === sectionId);
                            if (!state) return null;
                            return (
                              <SectionFillButton
                                key={sectionId}
                                job={job}
                                state={state}
                                lang={lang}
                                onOpen={openSection}
                                onToggleNa={toggleNa}
                                busy={acting}
                              />
                            );
                          })}
                        </div>
                      )}

                      {/* ส่วนที่ผูกกับตู้ — ตู้ละ 1 ใบ แต่ยังเป็นส่วนเดียวกัน */}
                      {isCharger && (
                        rows.length === 0 ? (
                          <p className="tw-mt-3 tw-text-xs tw-text-gray-400">{t("noChargers", lang)}</p>
                        ) : (
                          <div className="tw-mt-3 tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-2">
                            {rows.map((c) => (
                              <SectionFillButton
                                key={c.sn}
                                job={job}
                                state={c}
                                lang={lang}
                                onOpen={openSection}
                                onToggleNa={toggleNa}
                                busy={acting}
                              />
                            ))}
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  {/* ml-11 = วงกลมเลข (w-8) + gap-3 — เส้นคั่นเริ่มตรงกับเนื้อหาด้านบน */}
                  {closeJobButton && (
                    <div className="tw-ml-11 tw-mt-4 tw-flex tw-justify-end tw-border-t tw-border-gray-100 tw-pt-3">
                      {closeJobButton}
                    </div>
                  )}
                </CardBody>
              </Card>
            );
          })}
        </div>

        {/* ปุ่มอนุมัติ/ตีกลับ — ทั้งใบพร้อมกัน (มีแค่ปุ่ม ไม่มีแถบข้อความ) */}
        {waiting && canApprove && (
          <div className="tw-mt-6 tw-flex tw-justify-end tw-gap-2">
            <Button size="sm" variant="outlined" disabled={acting} onClick={() => setRejectOpen(true)}>
              {t("reject", lang)}
            </Button>
            <Button size="sm" disabled={acting} onClick={approveJob} className="tw-bg-green-600">
              {t("approve", lang)}
            </Button>
          </div>
        )}

        {/* ปิดใบงาน — เวลาทำงานจริง + ช่างที่ลงเวลา Maximo (ใช้ส่ง IN09) */}
        <Dialog open={closeOpen} handler={() => { if (!acting) setCloseOpen(false); }} size="sm">
          <DialogHeader>{t("closeJob", lang)}</DialogHeader>
          <DialogBody className="tw-flex tw-max-h-[70vh] tw-flex-col tw-gap-4 tw-overflow-y-auto">
            <p className="tw-text-sm tw-text-gray-600">{t(isMaximoJob ? "closeJobHint" : "closeJobHintNoMaximo", lang)}</p>
            <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-3">
              <label className="tw-block">
                <span className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-gray-700">
                  {t("workStart", lang)} <span className="tw-text-red-500">*</span>
                </span>
                <input
                  type="datetime-local"
                  value={workStart}
                  onChange={(e) => setWorkStart(e.target.value)}
                  className="tw-w-full tw-rounded-lg tw-border tw-border-gray-300 tw-px-3 tw-py-2 tw-text-sm focus:tw-border-blue-500 focus:tw-outline-none"
                />
              </label>
              <label className="tw-block">
                <span className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-gray-700">
                  {t("workFinish", lang)} <span className="tw-text-red-500">*</span>
                </span>
                <input
                  type="datetime-local"
                  value={workFinish}
                  min={workStart || undefined}
                  onChange={(e) => setWorkFinish(e.target.value)}
                  className="tw-w-full tw-rounded-lg tw-border tw-border-gray-300 tw-px-3 tw-py-2 tw-text-sm focus:tw-border-blue-500 focus:tw-outline-none"
                />
              </label>
            </div>

            {!isMaximoJob ? (
            <div>
              <div className="tw-mb-1.5 tw-text-xs tw-font-semibold tw-text-gray-700">
                {t("impsLabor", lang)} <span className="tw-text-red-500">*</span>
              </div>
              {coworkers.length === 0 ? (
                <p className="tw-text-xs tw-text-orange-600">{t("impsLaborEmpty", lang)}</p>
              ) : (
                <div className="tw-max-h-56 tw-divide-y tw-divide-gray-100 tw-overflow-y-auto tw-rounded-lg tw-border tw-border-gray-200">
                  {coworkers.map((name) => (
                    <label key={name} className="tw-flex tw-cursor-pointer tw-items-center tw-gap-2.5 tw-px-3 tw-py-2 hover:tw-bg-gray-50">
                      <input
                        type="checkbox"
                        checked={impsLabor.includes(name)}
                        onChange={() => setImpsLabor((prev) =>
                          prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name])}
                        className="tw-h-4 tw-w-4 tw-shrink-0"
                      />
                      <span className="tw-min-w-0 tw-truncate tw-text-sm tw-text-gray-800">{name}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
            ) : (
            <div>
              <div className="tw-mb-1.5 tw-text-xs tw-font-semibold tw-text-gray-700">
                {t("maximoLabor", lang)} {laborOptions.length > 0 && <span className="tw-text-red-500">*</span>}
              </div>
              {laborOptions.length === 0 ? (
                <p className="tw-text-xs tw-text-orange-600">{t("maximoLaborEmpty", lang)}</p>
              ) : (
                <div className="tw-max-h-56 tw-divide-y tw-divide-gray-100 tw-overflow-y-auto tw-rounded-lg tw-border tw-border-gray-200">
                  {laborOptions.map((o) => (
                    <label key={o.laborcode} className="tw-flex tw-cursor-pointer tw-items-center tw-gap-2.5 tw-px-3 tw-py-2 hover:tw-bg-gray-50">
                      <input
                        type="checkbox"
                        checked={maximoLabor.includes(o.laborcode)}
                        onChange={() => setMaximoLabor((prev) =>
                          prev.includes(o.laborcode) ? prev.filter((c) => c !== o.laborcode) : [...prev, o.laborcode])}
                        className="tw-h-4 tw-w-4 tw-shrink-0"
                      />
                      <span className="tw-min-w-0 tw-truncate tw-text-sm tw-text-gray-800">{o.name || o.laborcode}</span>
                      <span className="tw-ml-auto tw-shrink-0 tw-text-xs tw-text-gray-400">{o.laborcode}</span>
                    </label>
                  ))}
                </div>
              )}
              {contractorPicked && (
                <input
                  type="text"
                  value={maximoContractor}
                  placeholder={t("contractorName", lang)}
                  onChange={(e) => setMaximoContractor(e.target.value)}
                  className="tw-mt-2 tw-w-full tw-rounded-lg tw-border tw-border-gray-300 tw-px-3 tw-py-2 tw-text-sm focus:tw-border-blue-500 focus:tw-outline-none"
                />
              )}
            </div>
            )}

            {closeError && (
              <div className="tw-rounded-lg tw-border tw-border-red-200 tw-bg-red-50 tw-px-3 tw-py-2 tw-text-sm tw-text-red-700">
                {closeError}
              </div>
            )}
          </DialogBody>
          <DialogFooter className="tw-gap-2">
            <Button variant="text" disabled={acting} onClick={() => setCloseOpen(false)}>{t("cancel", lang)}</Button>
            <Button className="tw-bg-green-600" disabled={acting} onClick={submitCloseJob}>
              {acting ? t("closingJob", lang) : t("confirmClose", lang)}
            </Button>
          </DialogFooter>
        </Dialog>

        {/* ยืนยัน N/A — pop-up แบบเดียวกับยืนยันยกเลิกการแก้ไขของแพลตฟอร์ม */}
        {naConfirm && (
          <div
            className="tw-fixed tw-inset-0 tw-z-[9999] tw-flex tw-items-center tw-justify-center tw-bg-black/50 tw-p-4"
            onClick={() => { if (!acting) setNaConfirm(null); }}
          >
            <div
              role="dialog"
              aria-modal="true"
              className="tw-w-full tw-max-w-md tw-rounded-2xl tw-bg-white tw-p-6 tw-shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="tw-mb-2 tw-flex tw-items-center tw-gap-2 tw-text-lg tw-font-bold tw-text-blue-gray-800">
                <span className="tw-rounded tw-bg-gray-200 tw-px-1.5 tw-py-0.5 tw-text-xs tw-font-bold tw-text-gray-700">
                  {t("na", lang)}
                </span>
                {t("naTitle", lang)}
              </h3>
              <p className="tw-mb-1 tw-text-sm tw-font-semibold tw-text-blue-gray-800">
                {pick(naConfirm.state.label, lang)}
                {naConfirm.state.sn && naConfirm.state.charger_no && (
                  <span className="tw-ml-2 tw-font-mono tw-text-xs tw-font-normal tw-text-blue-gray-400">{naConfirm.state.sn}</span>
                )}
              </p>
              <p className="tw-text-sm tw-text-blue-gray-600">{t("confirmNa", lang)}</p>
              {naError && (
                <div className="tw-mt-3 tw-rounded-lg tw-border tw-border-red-200 tw-bg-red-50 tw-px-3 tw-py-2 tw-text-sm tw-text-red-700">
                  {naError}
                </div>
              )}
              <div className="tw-mt-5 tw-flex tw-items-center tw-justify-end tw-gap-3">
                <Button
                  type="button"
                  variant="outlined"
                  disabled={acting}
                  onClick={() => setNaConfirm(null)}
                  className="tw-border-blue-gray-200 tw-text-blue-gray-700 hover:tw-border-blue-gray-300"
                >
                  {t("cancel", lang)}
                </Button>
                <Button
                  type="button"
                  disabled={acting}
                  onClick={() => { void saveNa(naConfirm.job, naConfirm.state, true); }}
                  className="tw-bg-gray-800 tw-text-white tw-font-semibold hover:tw-bg-gray-900 disabled:tw-cursor-not-allowed disabled:tw-opacity-50"
                >
                  {t(acting ? "savingNa" : "confirmNaButton", lang)}
                </Button>
              </div>
            </div>
          </div>
        )}

        <Dialog open={rejectOpen} handler={() => setRejectOpen(false)} size="sm">
          <DialogHeader>{t("reject", lang)}</DialogHeader>
          <DialogBody>
            <Input
              crossOrigin=""
              label={t("rejectReason", lang)}
              value={rejectRemark}
              onChange={(e) => setRejectRemark(e.target.value)}
            />
          </DialogBody>
          <DialogFooter className="tw-gap-2">
            <Button variant="text" onClick={() => setRejectOpen(false)}>{t("cancel", lang)}</Button>
            <Button color="red" disabled={!rejectRemark.trim() || acting} onClick={rejectJob}>
              {t("reject", lang)}
            </Button>
          </DialogFooter>
        </Dialog>
      </div>
    );
  }

  // ══════════════ ตารางใบ PM ของสถานี ══════════════
  const filtered = jobs.filter((j) => {
    const q = filtering.trim().toLowerCase();
    if (!q) return true;
    return [j.doc_name, j.issue_id, j.pm_date, j.wonum, j.status].some((v) =>
      String(v ?? "").toLowerCase().includes(q)
    );
  });

  return (
    <div className="tw-mt-4 sm:tw-mt-6 lg:tw-mt-8">
      <LoadingOverlay show={loading} text={t("loading", lang)} />
      <Card className="tw-border tw-border-gray-200 tw-shadow-sm">
        <CardHeader floated={false} shadow={false} className="tw-rounded-none tw-px-5 tw-pt-5">
          <div className="tw-flex tw-flex-wrap tw-items-start tw-justify-between tw-gap-3">
            <div>
              <Typography variant="h5" className="tw-text-gray-900">{t("pageTitle", lang)}</Typography>
              <Typography className="tw-mt-1 tw-text-sm tw-text-gray-500">{t("pageSubtitle", lang)}</Typography>
            </div>
            <div className="tw-flex tw-items-center tw-gap-2">
              <div className="tw-w-56">
                <Input
                  crossOrigin=""
                  label={t("search", lang)}
                  value={filtering}
                  onChange={(e) => setFiltering(e.target.value)}
                />
              </div>
              <Button
                size="sm"
                disabled={!stationId}
                onClick={() => { setNewDate(todayISO()); setNewOpen(true); }}
                className="tw-flex tw-items-center tw-gap-1.5 tw-bg-gray-900"
              >
                <PlusIcon className="tw-h-4 tw-w-4" /> {t("newDoc", lang)}
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardBody className="tw-px-5 tw-pb-5 tw-pt-4">
          {error && (
            <div className="tw-mb-3 tw-rounded-lg tw-border tw-border-red-200 tw-bg-red-50 tw-px-4 tw-py-3 tw-text-sm tw-text-red-700">
              {error}
            </div>
          )}
          {!stationId ? (
            <p className="tw-py-10 tw-text-center tw-text-sm tw-text-gray-500">{t("selectStationFirst", lang)}</p>
          ) : filtered.length === 0 && !loading ? (
            <p className="tw-py-10 tw-text-center tw-text-sm tw-text-gray-500">{t("noData", lang)}</p>
          ) : (
            <div className="tw-overflow-x-auto">
              <table className="tw-w-full tw-min-w-[760px] tw-table-auto tw-text-left">
                <thead>
                  <tr className="tw-border-b tw-border-gray-200 tw-bg-gray-50/60">
                    {[t("colNo", lang), t("colDocName", lang), t("colIssueId", lang), t("colPmDate", lang),
                      t("colSections", lang), t("colStatus", lang), t("colPdf", lang)].map((h) => (
                      <th key={h} className="tw-px-3 tw-py-2.5 tw-text-xs tw-font-semibold tw-text-gray-600">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((job, i) => (
                    <tr
                      key={job.id}
                      onClick={() => openJob(job)}
                      className="tw-cursor-pointer tw-border-b tw-border-gray-100 hover:tw-bg-blue-50/40"
                    >
                      <td className="tw-px-3 tw-py-3 tw-text-sm tw-text-gray-500">{i + 1}</td>
                      <td className="tw-px-3 tw-py-3 tw-text-sm tw-font-semibold tw-text-gray-800">{job.doc_name || "-"}</td>
                      <td className="tw-px-3 tw-py-3 tw-text-sm tw-text-gray-700">{job.issue_id || "-"}</td>
                      <td className="tw-px-3 tw-py-3 tw-text-sm tw-text-gray-700">{fmtDate(job.pm_date, lang)}</td>
                      <td className="tw-px-3 tw-py-3">
                        <div className="tw-flex tw-flex-wrap tw-gap-1">
                          {SECTION_GROUPS.map((group) => {
                            const rows = job.sections.filter((x) => group.sectionIds.includes(x.section));
                            const st = aggregateStatus(rows);
                            const filled = rows.filter((x) => !!x.report_id).length;
                            return (
                              <span
                                key={group.id}
                                title={sectionStatusLabel(st, lang, job.status !== "draft")}
                                className={`tw-rounded tw-border tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-font-semibold ${sectionChipClass(st)}`}
                              >
                                {pick(SECTION_TITLE[group.id], lang)}
                                {rows.length > 1 ? ` ${filled}/${rows.length}` : ""}
                              </span>
                            );
                          })}
                        </div>
                      </td>
                      <td className="tw-px-3 tw-py-3">
                        <PmStatusBadge flow={toPmFlow({ status: job.status, reject_remark: job.reject_remark })} />
                      </td>
                      <td className="tw-px-3 tw-py-3" onClick={(e) => e.stopPropagation()}>
                        {/* PDF ให้โหลดได้เฉพาะใบที่อนุมัติปิดแล้ว (Closed) */}
                        {toPmFlow({ status: job.status, reject_remark: job.reject_remark }) === "closed"
                          && job.sections.some((x) => !!x.report_id) ? (
                          <a
                            href={`${API_BASE}/stationpmjob/${encodeURIComponent(job.id)}/pdf?station_id=${encodeURIComponent(job.station_id)}&lang=${lang}`}
                            target="_blank"
                            rel="noreferrer"
                            className="tw-inline-flex tw-items-center tw-gap-1 tw-text-sm tw-text-blue-600 hover:tw-underline"
                          >
                            <DocumentArrowDownIcon className="tw-h-4 tw-w-4" /> PDF
                          </a>
                        ) : (
                          <span className="tw-text-xs tw-text-gray-400">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardBody>
      </Card>

      {/* เปิดใบใหม่ */}
      <Dialog open={newOpen} handler={() => setNewOpen(false)} size="xs">
        <DialogHeader>{t("dialogTitle", lang)}</DialogHeader>
        <DialogBody className="tw-flex tw-flex-col tw-gap-4">
          <Input
            crossOrigin=""
            type="date"
            label={t("pmDateLabel", lang)}
            value={newDate}
            onChange={(e) => setNewDate(e.target.value)}
          />
          <Input
            crossOrigin=""
            label={t("wonumLabel", lang)}
            value={newWonum}
            onChange={(e) => setNewWonum(e.target.value)}
          />
        </DialogBody>
        <DialogFooter className="tw-gap-2">
          <Button variant="text" onClick={() => setNewOpen(false)}>{t("cancel", lang)}</Button>
          <Button disabled={!newDate || acting} onClick={createJob} className="tw-bg-gray-900">
            {t("create", lang)}
          </Button>
        </DialogFooter>
      </Dialog>
    </div>
  );
}
