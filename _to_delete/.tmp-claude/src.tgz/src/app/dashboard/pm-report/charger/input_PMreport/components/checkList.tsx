"use client";
import React, { useCallback, useMemo, useRef, useState, useEffect } from "react";
import {
    Button,
    Input,
    Typography,
    Textarea,
    Tooltip,
} from "@material-tailwind/react";
import Image from "next/image";
import { draftKey, saveDraftLocal, loadDraftLocal, clearDraftLocal } from "../lib/draft";
import { useRouter, useSearchParams } from "next/navigation";
import { pmFormReturnRoute } from "@/app/dashboard/pm-report/lib/origin";
import { registerDraftDiscard } from "@/app/dashboard/pm-report/lib/discardDraft";
import { serverPhotosToForm, formKeyFromForward, measureAsText, mergeDraftPhotos, deleteRemovedServerPhotos, isServerPhoto, type ViewPhoto } from "@/app/dashboard/pm-report/lib/reviewData";
import { useJobDocIds } from "@/app/dashboard/pm-report/lib/useJobDocIds";
import { useDebouncedEffect } from "@/app/dashboard/pm-report/lib/useDebouncedEffect";
import { usePmCancelEdit, usePmReviewAction } from "@/app/dashboard/pm-report/lib/reviewAction";
import PmApprovalBar from "@/app/dashboard/pm-report/components/PmApprovalBar";
import { ArrowLeftIcon } from "@heroicons/react/24/solid";
import { putPhoto, getPhotoByDbKey, delPhoto, type PhotoRef } from "../lib/draftPhotos";
import { isFileReadable, isImageDecodable, resolveUsableFile, reportMissingDraftPhoto, reportPhotoStorageFailure } from "@/utils/upload-safety";
import { ensureViewableImage } from "@/utils/heic";
import { collectPending, unrecoverablePhotos, expectedCountByGroup, findShortfall, shortfallMessage, pendingMessage, unrecoverableMessage } from "@/utils/pm-photo-sync";
import { useLanguage, type Lang } from "@/utils/useLanguage";
import { apiFetch } from "@/utils/api";
import LoadingOverlay from "@/app/dashboard/components/Loadingoverlay";

// Station name for GPS fallback — module-level is safe here because:
// 1) "use client" component, only runs in browser
// 2) Only one ChargerPMForm mounts at a time
let _stationNameForGPS = "";

// ==================== GPS + ADDRESS CACHE ====================
// Pre-fetch GPS + ที่อยู่ตั้งแต่เปิดหน้า เพื่อไม่ให้รูปแรกโหลดนาน
let _cachedLocation: { text: string; timestamp: number } | null = null;
let _locationFetching = false;
const LOCATION_CACHE_MAX_AGE = 5 * 60 * 1000; // 5 นาที

async function prefetchLocation(): Promise<void> {
    if (_locationFetching) return;
    _locationFetching = true;
    try {
        const gps = await getCurrentGPS();
        if (gps) {
            const text = await reverseGeocode(gps.lat, gps.lng);
            _cachedLocation = { text, timestamp: Date.now() };
        }
    } catch { /* silent */ }
    finally {
        _locationFetching = false; // ✅ reset ทุกกรณี
    }
}

async function getCachedLocation(): Promise<string> {
    if (_cachedLocation && (Date.now() - _cachedLocation.timestamp) < LOCATION_CACHE_MAX_AGE) {
        void prefetchLocation();
        return _cachedLocation.text;
    }
    // Race: ถ้า GPS ไม่ตอบใน 2 วินาที ใช้ fallback ทันที
    await Promise.race([
        prefetchLocation(),
        new Promise<void>(resolve => setTimeout(resolve, 2000))
    ]);
    return _cachedLocation?.text || "ไม่สามารถระบุตำแหน่งได้";
}

// บีบรูปก่อนอัปโหลด — การันตีว่าผลลัพธ์เล็กกว่า targetBytes
// แก้คอมเมนต์ 2026-09-23: เพดานจริงของ nginx คือ 30M ไม่ใช่ ~1MB ตามที่เคยเขียนไว้
// (ตรวจแล้วที่ /etc/nginx/conf.d/imps-upload.conf — client_max_body_size 30M)
// targetBytes 900KB ยังคงไว้เพราะจงใจ: ช่างอัปจากมือถือผ่าน 4G ทีละ 10 รูป
// ไฟล์เล็กกว่า = อัปเร็วกว่าและเปลืองพื้นที่เซิร์ฟเวอร์น้อยกว่า ไม่ใช่ข้อจำกัดของ nginx
// ไฟล์ที่เล็กกว่าเป้าอยู่แล้วจะคืนค่าเดิมทันที (nginx จำกัดที่ "ขนาดไฟล์" ไม่ใช่ความละเอียด)
async function compressImage(
    file: File,
    maxWidth = 1600,
    quality = 0.8,
    targetBytes = 900 * 1024,
): Promise<File> {
    if (!file.type.startsWith("image/") || file.size <= targetBytes) return file;

    const img = await new Promise<HTMLImageElement | null>((resolve) => {
        const im = document.createElement("img");
        im.onload = () => resolve(im);
        im.onerror = () => resolve(null);
        im.src = URL.createObjectURL(file);
    });
    if (!img) return file;
    URL.revokeObjectURL(img.src);

    let { width, height } = img;
    if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
    }

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(img, 0, 0, width, height);

    const toBlob = (q: number) =>
        new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", q));

    // วนลดคุณภาพทีละขั้นจนกว่าไฟล์จะเล็กกว่าเป้า (หรือถึงคุณภาพต่ำสุดที่ยอมรับได้)
    let q = quality;
    let blob = await toBlob(q);
    while (blob && blob.size > targetBytes && q > 0.4) {
        q = Math.round((q - 0.1) * 10) / 10;
        blob = await toBlob(q);
    }

    if (!blob || blob.size >= file.size) return file; // toBlob ล้มเหลว หรือไม่เล็กลง → ใช้ไฟล์เดิม
    return new File([blob], ensureJpgFilename(file.name), { type: "image/jpeg" });
}

/** ไฟล์ใน state อาจใช้ไม่ได้แล้ว (iOS คืนหน่วยความจำ) → กู้จาก IndexedDB ที่เซฟไว้ตอนแนบ */
function resolveUploadFile(task: { file?: File; ref?: PhotoRef }): Promise<File> {
    const dbKey = task.ref?.dbKey;
    return resolveUsableFile(task.file, dbKey ? () => getPhotoByDbKey(dbKey) : undefined);
}


// ฟอร์มนี้เหลือแค่ Post-PM (ยกเลิก Pre-PM แล้ว)

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";
const LOGO_SRC = "/img/logo_egat.png";

// ==================== TRANSLATIONS ====================
const T = {
    // Page Header
    pageTitle: { th: "Preventive Maintenance Checklist - EV Charger", en: "Preventive Maintenance Checklist - EV Charger" },
    companyName: { th: "Electricity Generating Authority of Thailand (EGAT)", en: "Electricity Generating Authority of Thailand (EGAT)" },
    companyAddress: { th: "53 Moo 2 Charansanitwong Road, Bang Kruai, Nonthaburi 11130, Thailand", en: "53 Moo 2 Charansanitwong Road, Bang Kruai, Nonthaburi 11130, Thailand" },
    companyAddressShort: { th: "Bang Kruai, Nonthaburi 11130", en: "Bang Kruai, Nonthaburi 11130" },
    callCenter: { th: "Call Center Tel. 02-114-3350", en: "Call Center Tel. 02-114-3350" },

    // Form Labels
    docName: { th: "ชื่อเอกสาร", en: "Document Name" },
    issueId: { th: "Issue ID", en: "Issue ID" },
    location: { th: "สถานที่", en: "Location" },
    pmDate: { th: "วันที่ PM", en: "PM Date" },
    inspector: { th: "ผู้ตรวจสอบ", en: "Inspector" },
    brand: { th: "ยี่ห้อ", en: "Brand" },
    model: { th: "รุ่น", en: "Model" },
    power: { th: "กำลังไฟ", en: "Power" },
    serialNumber: { th: "Serial Number (SN)", en: "Serial Number (SN)" },
    chargerNo: { th: "Charger No.", en: "Charger No." },

    // Buttons
    save: { th: "บันทึก", en: "Save" },
    saving: { th: "กำลังบันทึก...", en: "Saving..." },
    attachPhoto: { th: "แนบรูป / ถ่ายรูป", en: "Attach / Take Photo" },
    takePhoto: { th: "ถ่ายรูป", en: "Take Photo" },
    selectFromGallery: { th: "เลือกจากคลัง", en: "Gallery" },
    na: { th: "N/A", en: "N/A" },
    pass: { th: "PASS", en: "PASS" },
    fail: { th: "FAIL", en: "FAIL" },
    backToList: { th: "กลับไปหน้า List", en: "Back to List" },
    workTime: { th: "เวลาทำงานจริง", en: "Actual work time" },
    workStart: { th: "เวลาเริ่มงาน", en: "Start time" },
    workFinish: { th: "เวลาเสร็จงาน", en: "Finish time" },
    workTimeHint: { th: "ใช้ส่งเวลาทำงานของช่างเข้า Maximo", en: "Sent to Maximo as actual labor time" },
    alertWorkTime: { th: "กรุณากรอกเวลาเริ่มงานและเวลาเสร็จงาน", en: "Please fill in the start and finish time" },
    alertWorkTimeOrder: { th: "เวลาเสร็จงานต้องไม่ก่อนเวลาเริ่มงาน", en: "Finish time must not be before the start time" },
    alertWorkTimeFuture: { th: "เวลาทำงานต้องไม่เป็นเวลาในอนาคต — Maximo ไม่รับเวลาที่ยังมาไม่ถึง", en: "Work time cannot be in the future — Maximo rejects labor times that have not happened yet" },

    // Photo Section
    maxPhotos: { th: "สูงสุด", en: "Max" },
    photos: { th: "รูป", en: "photos" },
    cameraSupported: { th: "รองรับการถ่ายจากกล้องบนมือถือ", en: "Camera supported on mobile" },
    noPhotos: { th: "ยังไม่มีรูปแนบ", en: "No photos attached" },

    // Count labels for sub-items
    cableCount: { th: "จำนวนสายอัดประจุ:", en: "Charging cables:" },
    connectorCount: { th: "จำนวนหัวจ่ายอัดประจุ:", en: "Connectors:" },
    emergencyStopCount: { th: "จำนวนปุ่มหยุดฉุกเฉิน:", en: "Emergency stops:" },
    qrCodeCount: { th: "จำนวน QR CODE:", en: "QR CODEs:" },
    warningSignCount: { th: "จำนวนป้ายเตือน:", en: "Warning signs:" },
    ventilationSignCount: { th: "จำนวนป้ายเตือนระบายอากาศ:", en: "Ventilation signs:" },
    cpVoltageCount: { th: "จำนวนสาย CP:", en: "CP cables:" },
    airFilterCount: { th: "จำนวนแผ่นกรอง:", en: "Air filters:" },
    chargingTestCount: { th: "จำนวนสายทดสอบ:", en: "Test cables:" },
    unit: { th: "ตัว", en: "units" },
    cable: { th: "เส้น", en: "cables" },
    piece: { th: "ชิ้น", en: "pieces" },
    connector: { th: "หัว", en: "connectors" },
    button: { th: "ปุ่ม", en: "buttons" },
    qrUnit: { th: "อัน", en: "pcs" },
    sign: { th: "แผ่น", en: "signs" },
    filter: { th: "แผ่น", en: "filters" },

    // Remarks
    remark: { th: "หมายเหตุ", en: "Remark" },
    testResult: { th: "ผลการทดสอบ", en: "Test Result" },
    comment: { th: "Comment", en: "Comment" },

    postPM: { th: "หลัง PM", en: "Post-PM" },

    // Summary
    summaryResult: { th: "สรุปผลการตรวจสอบ", en: "Inspection Summary" },
    summaryPass: { th: "Pass", en: "Pass" },
    summaryFail: { th: "Fail", en: "Fail" },
    summaryNA: { th: "N/A", en: "N/A" },

    // Validation Sections
    validationPhotoTitle: { th: "1) ตรวจสอบการแนบรูปภาพ (ทุกข้อ)", en: "1) Photo Attachments (all items)" },
    validationInputTitle: { th: "2) อินพุตข้อ 10 และ 16", en: "2) Input Item 10 and 16" },
    validationRemarkTitle: { th: "3) หมายเหตุ (ทุกข้อ)", en: "3) Remarks (all items)" },
    validationPFTitle: { th: "3) ระดับผลการตรวจ / N/A", en: "3) Inspection rating / N/A" },
    validationRemarkTitlePost: { th: "4) หมายเหตุ (ทุกข้อ)", en: "4) Remarks (all items)" },
    validationSummaryTitle: { th: "5) สรุปผลการตรวจสอบ", en: "5) Inspection Summary" },

    // Validation Messages
    allComplete: { th: "ครบเรียบร้อย ✅", en: "Complete ✅" },
    missingPhoto: { th: "ยังไม่ได้แนบรูปข้อ:", en: "Missing photos for:" },
    missingInput: { th: "ยังขาดข้อ:", en: "Missing:" },
    missingPF: { th: "ยังไม่ได้เลือกข้อ:", en: "Not selected:" },
    missingSummaryText: { th: "ยังไม่ได้กรอก Comment", en: "Comment not filled" },
    missingSummaryStatus: { th: "ยังไม่ได้เลือกระดับสรุปผล / N/A", en: "Summary rating / N/A not selected" },
    itemLabel: { th: "ข้อ", en: "Item" },

    // Validation Card (DCMasterValidation style)
    formStatus: { th: "สถานะการกรอกข้อมูล", en: "Form Completion Status" },
    allCompleteReady: { th: "กรอกข้อมูลครบถ้วนแล้ว พร้อมบันทึก ✓", en: "All fields completed. Ready to save ✓" },
    remaining: { th: "ยังขาดอีก {n} รายการ", en: "{n} items remaining" },
    cleaningCount: { th: "จำนวนรายการทำความสะอาด:", en: "Cleaning items:" },
    items: { th: "รายการ", en: "items" },

    // Alerts
    alertNoSN: { th: "ไม่พบ SN", en: "SN not found" },
    alertFillRequired: { th: "กรุณากรอกค่าให้ครบ (ข้อ 10 CP และ ข้อ 16)", en: "Please fill in all required fields (Item 10 CP and Item 16)" },
    alertSaveFailed: { th: "บันทึกไม่สำเร็จ:", en: "Save failed:" },
    alertCompleteAll: { th: "กรุณากรอกข้อมูลและแนบรูปให้ครบก่อนบันทึก", en: "Please complete all fields and attach photos before saving" },
    alertPhotoNotComplete: { th: "กรุณาแนบรูปให้ครบก่อน", en: "Please attach all photos" },

    // Dynamic Items
    addEmergencyStop: { th: "เพิ่ม", en: "Add" },
    addWarningSign: { th: "เพิ่ม", en: "Add" },
    replaceAirFilter: { th: "เปลี่ยนแผ่นกรองระบายอากาศ", en: "Replace air filter" },
    naNoValue: { th: "N/A (ไม่มีค่า)", en: "N/A (No value)" },
    removeNA: { th: "ลบ N/A", en: "Remove N/A" },

    // Misc UI
    loading: { th: "กำลังโหลดข้อมูล...", en: "Loading..." },
    logoAlt: { th: "โลโก้บริษัท", en: "Company logo" },
    photoPreviewAlt: { th: "ตัวอย่างรูป", en: "Photo preview" },
    removeItem: { th: "ลบรายการ", en: "Remove item" },
    uploadFailedItem: { th: "ข้อ", en: "Item" },
    maximoLabor: { th: "ช่างที่ลงเวลากับ Maximo", en: "Technicians for Maximo time log" },
    maximoLaborHint: {
        th: "เลือกคนที่จะลงเวลาทำงานเข้า Maximo (IN09) — ไม่เลือกจะใช้ช่างที่ผู้วางแผนมอบหมายแทน",
        en: "Who gets an actual-labor record in Maximo (IN09) — leave empty to fall back to the assigned technicians",
    },
    maximoLaborEmpty: { th: "ยังไม่มีรหัสช่างจาก Maximo", en: "No Maximo labor codes available" },
    maximoLaborNone: { th: "ช่างไม่ได้เลือกใครไว้", en: "No technician selected" },
    contractorName: { th: "ชื่อผู้รับเหมา", en: "Contractor name" },
    contractorPlaceholder: { th: "ระบุชื่อผู้รับเหมาที่มาทำงานจริง", en: "Name of the contractor who did the work" },
    contractorRequired: { th: "เลือกผู้รับเหมาแล้วต้องระบุชื่อด้วย", en: "Enter the contractor name" },
};

const t = (key: keyof typeof T, lang: Lang): string => T[key][lang];

// ==================== TYPES ====================
type StationPublic = {
    station_id: string;
    station_name: string;
    SN?: string;
    WO?: string;
    brand?: string;
    chargeBoxID?: string;
    model?: string;
    power?: string;
    status?: boolean;
    chargerNo?: string;
    numberOfCables?: number;
};

type Me = {
    id: string;
    username: string;
    email: string;
    role: string;
    company: string;
    tel: string;
};

type PhotoItem = {
    id: string;
    file?: File;
    preview?: string;
    remark?: string;
    uploading?: boolean;
    uploaded?: boolean;
    error?: string;
    ref?: PhotoRef;
    isNA?: boolean;
    createdAt?: string;
    location?: string;
};

type BilingualText = { th: string; en: string };

type Question = {
    no: number;
    key: string;
    label: BilingualText;
    kind: "simple" | "measure" | "group" | "power_source";
    hasPhoto?: boolean;
    tooltip?: BilingualText;
    items?: { key: string; label: BilingualText }[];
    // ข้อที่มีแค่รูป + หมายเหตุ ไม่มีปุ่มประเมินผล และไม่นับในการตรวจว่าเลือกผลครบ
    photoOnly?: boolean;
};

const UNITS = { voltage: ["V"] as const };
type UnitVoltage = (typeof UNITS.voltage)[number];
type MeasureRow<U extends string> = { value: string; unit: U };
type MeasureState<U extends string> = Record<string, MeasureRow<U>>;
type Rating = "VERY_GOOD" | "GOOD" | "FAIR" | "UNUSABLE";
type PF = Rating | "PASS" | "FAIL" | "NA" | "";

// ==================== CONSTANTS ====================
const VOLTAGE1_FIELDS = ["L1-L2", "L2-L3", "L3-L1", "L1-N", "L2-N", "L3-N", "L1-G", "L2-G", "L3-G", "N-G"] as const;

const LABELS: Record<string, string> = {
    "L1-L2": "L1-L2", "L2-L3": "L2-L3", "L3-L1": "L3-L1",
    "L1-N": "L1-N", "L2-N": "L2-N", "L3-N": "L3-N",
    "L1-G": "L1-G", "L2-G": "L2-G", "L3-G": "L3-G",
    "N-G": "N-G", CP: "CP",
};

const FIELD_GROUPS: Record<number, { keys: readonly string[]; unitType: "voltage"; note?: string } | undefined> = {
    16: { keys: VOLTAGE1_FIELDS, unitType: "voltage" },
};

// ==================== QUESTIONS (Bilingual) ====================
const QUESTIONS: Question[] = [
    // ข้อ 1-2 บันทึกสภาพก่อนลงมือ (รูป + หมายเหตุ) — คีย์ "pre_r1"/"pre_r2" คงไว้ตามที่เก็บในฐานข้อมูล
    // ไม่เกี่ยวกับขั้นตอน Pre-PM ที่ยกเลิกไปแล้ว
    { no: 101, key: "pre_r1", label: { th: "1) ตรวจสอบสภาพทั่วไป (ก่อนบำรุงรักษา)", en: "1) General condition (before maintenance)" }, kind: "simple", hasPhoto: true, photoOnly: true, tooltip: { th: "บันทึกสภาพเครื่องชาร์จก่อนเริ่มบำรุงรักษา", en: "Record the charger condition before maintenance" } },
    { no: 102, key: "pre_r2", label: { th: "2) อุปกรณ์ชำรุดเสียหาย (ก่อนบำรุงรักษา)", en: "2) Damaged equipment (before maintenance)" }, kind: "simple", hasPhoto: true, photoOnly: true, tooltip: { th: "บันทึกอุปกรณ์ที่ชำรุดเสียหายก่อนเริ่มบำรุงรักษา", en: "Record damaged equipment before maintenance" }, },
    { no: 103, key: "r3_power_source", label: { th: "3) ตรวจสอบสภาพแหล่งจ่ายไฟ MDB", en: "3) Inspect MDB power supply condition" }, kind: "power_source", hasPhoto: true, items: [
        { key: "r3_power_main_cb", label: { th: "3.1) Main CB", en: "3.1) Main CB" } },
        { key: "r3_power_cb", label: { th: "3.2) CB", en: "3.2) CB" } },
        { key: "r3_power_meter", label: { th: "3.3) Power Meter (Voltage)", en: "3.3) Power Meter (Voltage)" } },
        { key: "r3_power_transformer", label: { th: "3.4) Transformer", en: "3.4) Transformer" } },
    ], tooltip: { th: "ตรวจสอบสภาพอุปกรณ์แหล่งจ่ายไฟของเครื่องชาร์จ", en: "Inspect the charger's power supply equipment" } },
    { no: 1, key: "r1", label: { th: "1) ตรวจสอบสภาพทั่วไป", en: "1) Check general condition" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบความสมบูรณ์ของตู้, การยึดแน่นของน็อตยึดฐาน, รอยแตกร้าวและร่องรอยการกระแทก", en: "Check cabinet integrity, base bolt tightness, cracks and impact marks" } },
    { no: 2, key: "r2", label: { th: "2) ตรวจสอบดักซีล,ซิลิโคนกันซึม", en: "2) Check sealant and silicone" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบความยืดหยุ่นของขอบยางกันน้ำ, รอยต่อของเคเบิลแกลนด์และและสภาพซิลิโคนตามแนวตะเข็บตู้", en: "Check waterproof rubber flexibility, cable gland joints and silicone condition" } },
    { no: 3, key: "r3", label: { th: "3) ตรวจสอบสายอัดประจุ", en: "3) Check charging cables" }, kind: "group", hasPhoto: true, items: [{ label: { th: "3.1) สายที่ 1", en: "3.1) Cable 1" }, key: "r3_1" }], tooltip: { th: "ตรวจสอบความสมบูรณ์ของฉนวนหุ้มสาย, คอสายว่าไม่มีการบิดงอหรือปริแตกและตรวจสอบรอยไหม้", en: "Check cable insulation, bends or cracks, and burn marks" } },
    { no: 4, key: "r4", label: { th: "4) ตรวจสอบหัวจ่ายอัดประจุ", en: "4) Check charging connector" }, kind: "group", hasPhoto: true, items: [{ label: { th: "4.1) หัวจ่ายอัดประจุที่ 1", en: "4.1) Connector 1" }, key: "r4_1" }], tooltip: { th: "ตรวจสอบความสะอาดของขั้วสัมผัส (Pin), ตรวจสอบสปริงล็อกและรอยร้าวบริเวณด้ามจับ, ขันน็อตแน่นทุกจุดบริเวณหัวชาร์จทั้ง 2 หัว", en: "Check pin cleanliness, spring lock and handle cracks, tighten all bolts at both charging connector heads" } },
    { no: 5, key: "r5", label: { th: "5) ตรวจสอบปุ่มหยุดฉุกเฉิน", en: "5) Check emergency stop button" }, kind: "group", hasPhoto: true, items: [{ label: { th: "5.1) ปุ่มหยุดฉุกเฉินที่ 1", en: "5.1) Emergency stop 1" }, key: "r5_1" }], tooltip: { th: "ตรวจสอบกลไกการกดและการคลายล็อกและตรวจสอบหน้าสัมผัสทางไฟฟ้าว่าไม่มีคราบสกปรก", en: "Check press/release mechanism and electrical contacts" } },
    { no: 6, key: "r6", label: { th: "6) ตรวจสอบ QR CODE", en: "6) Check QR CODE" }, kind: "group", hasPhoto: true, items: [{ label: { th: "6.1) QR CODE ที่ 1", en: "6.1) QR CODE 1" }, key: "r6_1" }], tooltip: { th: "ตรวจสอบความคมชัดของ QR CODE และการยึดติดของสติ๊กเกอร์", en: "Check QR CODE clarity and sticker adhesion" } },
    { no: 7, key: "r7", label: { th: "7) ตรวจสอบป้ายเตือนระวังไฟฟ้าช็อก", en: "7) Check electric shock warning sign" }, kind: "group", hasPhoto: true, items: [{ label: { th: "7.1) ป้ายเตือนระวังไฟฟ้าช็อกที่ 1", en: "7.1) Warning sign 1" }, key: "r7_1" }], tooltip: { th: "ตรวจสอบการติดตั้งและความชัดเจนของป้ายเตือนอันตราย", en: "Check installation and clarity of warning signs" } },
    {
        no: 8, key: "r8", label: { th: "8) ตรวจสอบป้ายเตือนต้องการระบายอากาศ", en: "8) Check ventilation warning sign" }, kind: "group", hasPhoto: true,
        tooltip: { th: "ตรวจสอบระยะ Clearance รอบตู้ตามป้ายระบุ เพื่อไม่ให้มีสิ่งของวางกีดขวางทางลม", en: "Check clearance around cabinet per signage" },
        items: [
            { label: { th: "8.1) ป้ายเตือนต้องการระบายอากาศ (ด้านซ้าย)", en: "8.1) Ventilation warning sign (inlet)" }, key: "r8_1" },
            { label: { th: "8.2) ป้ายเตือนต้องการระบายอากาศ (ด้านขวา)", en: "8.2) Ventilation warning sign (outlet)" }, key: "r8_2" },
        ]
    },
    { no: 9, key: "r9", label: { th: "9) ตรวจสอบป้ายบ่งชี้ปุ่มฉุกเฉิน", en: "9) Check emergency button indicator sign" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบความสว่างหรือการสะท้อนแสงของป้ายบ่งชี้ตำแหน่งปุ่ม Emergency เพื่อให้มองเห็นได้ในสภาวะแสงน้อย", en: "Check sign visibility in low light conditions" } },
    { no: 10, key: "r10", label: { th: "10) ตรวจสอบแรงดันไฟฟ้าที่พิน CP", en: "10) Check CP pin voltage" }, kind: "group", hasPhoto: true, items: [{ label: { th: "10.1) แรงดันไฟฟ้าที่พิน CP สายที่ 1", en: "10.1) CP pin voltage cable 1" }, key: "r10_1" }], tooltip: { th: "วัดค่าแรงดันระหว่าง pin CP และ PE", en: "Measure voltage between CP and PE pins" } },
    {
        no: 11, key: "r11", label: { th: "11) ตรวจสอบแผ่นกรองอากาศ", en: "11) Check air filter" }, kind: "group", hasPhoto: true,
        tooltip: { th: "ตรวจสอบสภาพแผ่นกรองอากาศและทิศทางการไหลของอากาศ", en: "Check air filter condition and airflow direction" },
        items: [
            { label: { th: "11.1) แผ่นกรองอากาศ (ด้านซ้าย)", en: "11.1) Air filter (inlet)" }, key: "r11_1" },
            { label: { th: "11.2) แผ่นกรองอากาศ (ด้านขวา)", en: "11.2) Air filter (outlet)" }, key: "r11_2" },
            { label: { th: "11.3) แผ่นกรองอากาศ (ด้านหน้า)", en: "11.3) Air filter (front)" }, key: "r11_3" },
            { label: { th: "11.4) แผ่นกรองอากาศ (ด้านหลัง)", en: "11.4) Air filter (back)" }, key: "r11_4" },
            { label: { th: "11.5) แผ่นกรองอากาศ (ด้านล่าง)", en: "11.5) Air filter (bottom)" }, key: "r11_5" },
        ]
    },
    { no: 12, key: "r12", label: { th: "12) ตรวจสอบจุดต่อทางไฟฟ้า", en: "12) Check electrical connections" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบการขันแน่นของน็อตบริเวณจุดต่อสายและตรวจเช็ครอยไหม้", en: "Check bolt tightness at cable connection points and inspect for burn marks" } },
    { no: 13, key: "r13", label: { th: "13) ตรวจสอบคอนแทคเตอร์", en: "13) Check contactor" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบสภาพหน้าสัมผัส, การทำงานของคอยล์และเสียงผิดปกติขณะทำงาน", en: "Check contact condition, coil operation and abnormal sounds" } },
    { no: 14, key: "r14", label: { th: "14) ตรวจสอบอุปกรณ์ป้องกันไฟกระชาก", en: "14) Check surge protection device" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบหน้าต่างแสดงสถานะและตรวจสอบสายกราวด์ที่ต่อเข้ากับ Surge Protective Devices", en: "Check status window and ground wire to SPD" } },
    { no: 15, key: "r15", label: { th: "15) ตรวจสอบลำดับเฟส", en: "15) Check phase sequence" }, kind: "simple", hasPhoto: true, tooltip: { th: "ตรวจสอบทิศทางการเรียงเฟส", en: "Check phase sequence direction" } },
    { no: 16, key: "r16", label: { th: "16) วัดแรงดันไฟฟ้าด้านเข้า", en: "16) Measure input voltage" }, kind: "measure", hasPhoto: true, tooltip: { th: "วัดค่าแรงดันไฟฟ้าระหว่างเฟส และระหว่างเฟสกับนิวทรัล/กราวด์", en: "Measure phase-to-phase and phase-to-neutral/ground voltage" } },
    { no: 17, key: "r17", label: { th: "17) ทดสอบการอัดประจุ", en: "17) Charging test" }, kind: "group", hasPhoto: true, items: [{ label: { th: "17.1) ทดสอบการอัดประจุ สายที่ 1", en: "17.1) Charging test cable 1" }, key: "r17_1" }], tooltip: { th: "ตรวจสอบการทำงานร่วมกับ EV Simulator หรือรถจริง อย่างน้อย 1 นาที", en: "Test with EV Simulator or actual vehicle for at least 1 minute" } },

    // ===== ข้อ 18 - ทำความสะอาด =====
    {
        no: 18, key: "r18", label: { th: "18) ทำความสะอาด", en: "18) Cleaning" }, kind: "group", hasPhoto: true,
        tooltip: { th: "ทำความสะอาด Router, หน้าจอ, คราบสะสมบนหัวชาร์จและพื้นที่บริเวณฐานเครื่อง", en: "Clean Router, screen, connector buildup and base area" },
        items: [
            { label: { th: "18.1) Router - ทำความสะอาดหน้าสัมผัสซิม1และซิม2", en: "18.1) Router - Clean SIM1 and SIM2 contacts" }, key: "r18_1" },
            { label: { th: "18.2) Router - ทำความสะอาด port lan", en: "18.2) Router - Clean LAN port" }, key: "r18_2" },
            { label: { th: "18.3) ทำความสะอาดทั่วไป", en: "18.3) General cleaning" }, key: "r18_3" },
        ]
    },
];

// ==================== DYNAMIC LABEL GENERATORS ====================
const getDynamicLabel = {
    chargingCable: (idx: number, lang: Lang) => lang === "th" ? `3.${idx}) สายอัดประจุที่ ${idx}` : `3.${idx}) Charging cable ${idx}`,
    connector: (idx: number, lang: Lang) => lang === "th" ? `4.${idx}) หัวจ่ายอัดประจุที่ ${idx}` : `4.${idx}) Connector ${idx}`,
    emergencyStop: (idx: number, lang: Lang) => lang === "th" ? `5.${idx}) ปุ่มหยุดฉุกเฉินที่ ${idx}` : `5.${idx}) Emergency stop ${idx}`,
    qrCode: (idx: number, lang: Lang) => lang === "th" ? `6.${idx}) QR CODE ที่ ${idx}` : `6.${idx}) QR CODE ${idx}`,
    warningSign: (idx: number, lang: Lang) => lang === "th" ? `7.${idx}) ป้ายเตือนระวังไฟฟ้าช็อกที่ ${idx}` : `7.${idx}) Warning sign ${idx}`,
    ventilationSignInlet: (lang: Lang) => lang === "th" ? "8.1) ป้ายเตือนต้องการระบายอากาศ (ด้านซ้าย)" : "8.1) Ventilation warning sign (inlet)",
    ventilationSignOutlet: (lang: Lang) => lang === "th" ? "8.2) ป้ายเตือนต้องการระบายอากาศ (ด้านขวา)" : "8.2) Ventilation warning sign (outlet)",
    cpVoltage: (idx: number, lang: Lang) => lang === "th" ? `10.${idx}) แรงดันไฟฟ้าที่พิน CP สายที่ ${idx}` : `10.${idx}) CP pin voltage cable ${idx}`,
    airFilterLeft: (lang: Lang) => lang === "th" ? "11.1) แผ่นกรองอากาศ (ด้านซ้าย)" : "11.1) Air filter (inlet)",
    airFilterRight: (lang: Lang) => lang === "th" ? "11.2) แผ่นกรองอากาศ (ด้านขวา)" : "11.2) Air filter (outlet)",
    airFilterFront: (lang: Lang) => lang === "th" ? "11.3) แผ่นกรองอากาศ (ด้านหน้า)" : "11.3) Air filter (front)",
    airFilterBack: (lang: Lang) => lang === "th" ? "11.4) แผ่นกรองอากาศ (ด้านหลัง)" : "11.4) Air filter (back)",
    airFilterBottom: (lang: Lang) => lang === "th" ? "11.5) แผ่นกรองอากาศ (ด้านล่าง)" : "11.5) Air filter (bottom)",
    chargingTest: (idx: number, lang: Lang) => lang === "th" ? `17.${idx}) ทดสอบการอัดประจุ สายที่ ${idx}` : `17.${idx}) Charging test cable ${idx}`,
    cleaningSim: (lang: Lang) => lang === "th" ? "18.1) Router - ทำความสะอาดหน้าสัมผัสซิม1และซิม2" : "18.1) Router - Clean SIM1 and SIM2 contacts",
    cleaningLan: (lang: Lang) => lang === "th" ? "18.2) Router - ทำความสะอาด port lan" : "18.2) Router - Clean LAN port",
    cleaningGeneral: (lang: Lang) => lang === "th" ? "18.3) ทำความสะอาดทั่วไป" : "18.3) General cleaning",
};

function getQuestionLabel(q: Question, lang: Lang): string {
    if (q.no < 1 || q.no > 18) return q.label[lang];
    return q.label[lang].replace(/^(\d+)/, (number) => String(Number(number) + 3));
}

function getDisplayedItemLabel(label: string, qNo: number): string {
    if (qNo < 1 || qNo > 18) return label;
    return label.replace(/^(\d+)/, (number) => String(Number(number) + 3));
}

// ข้อ 1-3 เป็นหัวข้อที่เพิ่มด้านหน้าฟอร์ม ส่วนเลข no=1..18 และคีย์ r1..r18
// ยังคงเป็นเลขชุดเดิมที่บันทึกในฐานข้อมูล เพื่อให้ใบงานเก่ายังอ่านได้ถูกต้อง
function getDisplayedQuestionNo(qNo: number): number {
    if (qNo >= 101 && qNo <= 103) return qNo - 100;
    if (qNo >= 1 && qNo <= 18) return qNo + 3;
    return qNo;
}

function getDisplayedRowNo(key: string): string {
    const powerItemIndex = QUESTIONS.find(q => q.kind === "power_source")?.items?.findIndex(item => item.key === key) ?? -1;
    if (powerItemIndex >= 0) return `3.${powerItemIndex + 1}`;

    const match = key.match(/^r(\d+)(?:_(\d+))?$/);
    if (!match) return key;
    const mainNo = getDisplayedQuestionNo(Number(match[1]));
    return match[2] ? `${mainNo}.${match[2]}` : `${mainNo}`;
}

function compareDisplayedItemNos(a: string, b: string): number {
    const parse = (value: string) => {
        const [main = "0", sub = ""] = value.split(".");
        const subOrder = /^\d+$/.test(sub) ? Number(sub) : (sub.toLowerCase().charCodeAt(0) - 96 || 0);
        return [Number(main) || 0, subOrder] as const;
    };
    const [aMain, aSub] = parse(a);
    const [bMain, bSub] = parse(b);
    return aMain !== bMain ? aMain - bMain : aSub - bSub;
}

function createFixedItems(qNo: number, count: number, lang: Lang): { key: string; label: string }[] {
    const generators: Record<number, (idx: number, lang: Lang) => string> = {
        3: getDynamicLabel.chargingCable,
        4: getDynamicLabel.connector,
        6: getDynamicLabel.qrCode,
        10: getDynamicLabel.cpVoltage,
        17: getDynamicLabel.chargingTest,
    };
    const gen = generators[qNo];
    if (!gen) return [];
    return Array.from({ length: count }, (_, i) => ({
        key: `r${qNo}_${i + 1}`,
        label: gen(i + 1, lang)
    }));
}

function getFixedItemsQ8(lang: Lang): { key: string; label: string }[] {
    return [
        { key: "r8_1", label: getDynamicLabel.ventilationSignInlet(lang) },
        { key: "r8_2", label: getDynamicLabel.ventilationSignOutlet(lang) },
    ];
}

function getFixedItemsQ11(lang: Lang): { key: string; label: string }[] {
    return [
        { key: "r11_1", label: getDynamicLabel.airFilterLeft(lang) },
        { key: "r11_2", label: getDynamicLabel.airFilterRight(lang) },
        { key: "r11_3", label: getDynamicLabel.airFilterFront(lang) },
        { key: "r11_4", label: getDynamicLabel.airFilterBack(lang) },
        { key: "r11_5", label: getDynamicLabel.airFilterBottom(lang) },
    ];
}

function getFixedItemsQ18(lang: Lang): { key: string; label: string }[] {
    return [
        { key: "r18_1", label: getDynamicLabel.cleaningSim(lang) },
        { key: "r18_2", label: getDynamicLabel.cleaningLan(lang) },
        { key: "r18_3", label: getDynamicLabel.cleaningGeneral(lang) },
    ];
}

// ==================== API FUNCTIONS ====================
async function getChargerInfoBySN(sn: string): Promise<StationPublic> {
    const url = `${API_BASE}/charger/info?sn=${encodeURIComponent(sn)}`;
    const res = await apiFetch(url, { cache: "no-store" });
    if (res.status === 404) throw new Error("Charger not found");
    if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
    const json = await res.json();
    return json.station ?? json;  // ← ใช้ได้เลยเพราะ format เหมือนกัน
}

async function fetchReport(reportId: string, sn: string) {
    const url = `${API_BASE}/pmreport/get?sn=${sn}&report_id=${reportId}`;
    const res = await apiFetch(url);
    if (!res.ok) throw new Error(await res.text());
    return await res.json();
}

// ==================== UTIL HOOKS ====================
function initMeasureState<U extends string>(keys: readonly string[], defaultUnit: U): MeasureState<U> {
    return keys.reduce((acc, k) => {
        acc[k] = { value: "", unit: defaultUnit };
        return acc;
    }, {} as MeasureState<U>);
}

function useMeasure<U extends string>(keys: readonly string[], defaultUnit: U) {
    const [state, setState] = useState<MeasureState<U>>(() => initMeasureState(keys, defaultUnit));
    const patch = (key: string, patch: Partial<MeasureRow<U>>) =>
        setState((prev) => ({ ...prev, [key]: { ...prev[key], ...patch } }));
    const syncUnits = (newUnit: U) =>
        setState((prev) => {
            const next: MeasureState<U> = { ...prev };
            keys.forEach((k) => (next[k] = { ...prev[k], unit: newUnit }));
            return next;
        });
    return { state, setState, patch, syncUnits };
}


// ==================== UI COMPONENTS ====================
function PassFailRow({
    label, labelRight, value, onChange, remark, onRemarkChange, labels, aboveRemark, beforeRemark, belowRemark, inlineLeft, onlyNA = false, onClear, showPfButtons = true, lang, remarkId, pfButtonsId,
}: {
    label: string;
    labelRight?: React.ReactNode;
    value: PF;
    onChange: (v: Rating | "NA") => void;
    remark?: string;
    onRemarkChange?: (v: string) => void;
    labels?: Partial<Record<Exclude<PF, "">, React.ReactNode>>;
    aboveRemark?: React.ReactNode;
    beforeRemark?: React.ReactNode;
    belowRemark?: React.ReactNode;
    inlineLeft?: React.ReactNode;
    onlyNA?: boolean;
    onClear?: () => void;
    showPfButtons?: boolean;
    lang: Lang;
    remarkId?: string;
    pfButtonsId?: string;
}) {
    const text = {
        VERY_GOOD: labels?.VERY_GOOD ?? (lang === "th" ? "ดีมาก" : "Excellent"),
        GOOD: labels?.GOOD ?? (lang === "th" ? "ดี" : "Good"),
        FAIR: labels?.FAIR ?? (lang === "th" ? "พอใช้" : "Fair"),
        UNUSABLE: labels?.UNUSABLE ?? (lang === "th" ? "ใช้งานไม่ได้" : "Unusable"),
        NA: labels?.NA ?? t("na", lang),
    };

    const buttonGroup = onlyNA ? (
        <div id={pfButtonsId} className="tw-flex tw-gap-2 tw-ml-auto tw-transition-all tw-duration-300">
            <Button size="sm" color="blue-gray" variant={value === "NA" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]"
                onClick={() => value === "NA" && onClear ? onClear() : onChange("NA")}>
                {text.NA}
            </Button>
        </div>
    ) : (
        <div id={pfButtonsId} className="tw-flex tw-flex-wrap tw-gap-2 tw-ml-auto tw-transition-all tw-duration-300">
            <Button size="sm" color="green" variant={value === "VERY_GOOD" || value === "PASS" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("VERY_GOOD")}>{text.VERY_GOOD}</Button>
            <Button size="sm" color="light-green" variant={value === "GOOD" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("GOOD")}>{text.GOOD}</Button>
            <Button size="sm" color="amber" variant={value === "FAIR" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("FAIR")}>{text.FAIR}</Button>
            <Button size="sm" color="red" variant={value === "UNUSABLE" || value === "FAIL" ? "filled" : "outlined"} className="sm:tw-min-w-[112px]" onClick={() => onChange("UNUSABLE")}>{text.UNUSABLE}</Button>
            <Button size="sm" color="blue-gray" variant={value === "NA" ? "filled" : "outlined"} className="sm:tw-min-w-[84px]" onClick={() => onChange("NA")}>{text.NA}</Button>
        </div>
    );

    const buttonsRow = (
        <div className="tw-flex tw-items-center tw-gap-3 tw-w-full">
            {inlineLeft && <div className="tw-flex tw-items-center tw-gap-2">{inlineLeft}</div>}
            {buttonGroup}
        </div>
    );

    return (
        <div className="tw-space-y-3 tw-py-3">
            {labelRight ? (
                <div className="tw-flex tw-items-center tw-justify-between tw-gap-2">
                    <Typography className="tw-font-medium">{label}</Typography>
                    {labelRight}
                </div>
            ) : (
                <Typography className="tw-font-medium">{label}</Typography>
            )}
            {onRemarkChange ? (
                <div className="tw-w-full tw-min-w-0 tw-space-y-2">
                    {aboveRemark}
                    {showPfButtons && buttonsRow}
                    {beforeRemark}
                    <div id={remarkId} className="tw-transition-all tw-duration-300">
                        <Textarea label={t("remark", lang)} value={remark || ""} onChange={(e) => onRemarkChange(e.target.value)}
                            containerProps={{ className: "!tw-w-full !tw-min-w-0" }} className="!tw-w-full" />
                    </div>
                    {belowRemark}
                </div>
            ) : (
                showPfButtons && <div className="tw-flex tw-flex-col sm:tw-flex-row tw-gap-2 sm:tw-items-center sm:tw-justify-between">{buttonsRow}</div>
            )}
        </div>
    );
}

function SectionCard({ title, subtitle, children, tooltip, id }: {
    title?: string;
    subtitle?: string;
    children: React.ReactNode;
    tooltip?: string;
    id?: string;
}) {
    const qNumber = title?.match(/^(\d+)\)/)?.[1];

    return (
        <div id={id} className="tw-bg-white tw-rounded-xl tw-border tw-border-gray-200 tw-shadow-sm tw-overflow-hidden tw-transition-all tw-duration-300">
            {title && (
                <div className="tw-bg-gray-800 tw-px-3 sm:tw-px-4 tw-py-2.5 sm:tw-py-3">
                    <div className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-3">
                        {qNumber && (
                            <div className="tw-flex-shrink-0 tw-w-7 tw-h-7 sm:tw-w-8 sm:tw-h-8 tw-rounded-full tw-bg-white tw-text-gray-800 tw-flex tw-items-center tw-justify-center tw-font-bold tw-text-xs sm:tw-text-sm">
                                {qNumber}
                            </div>
                        )}
                        <Typography variant="h6" className="tw-text-white tw-text-sm sm:tw-text-base tw-font-semibold tw-flex-1">
                            {qNumber ? title.replace(/^\d+\)\s*/, '') : title}
                        </Typography>
                        {tooltip && (
                            <Tooltip content={tooltip} placement="bottom">
                                <svg className="tw-w-4 tw-h-4 sm:tw-w-5 sm:tw-h-5 tw-text-gray-400 tw-cursor-help tw-flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                                </svg>
                            </Tooltip>
                        )}
                    </div>
                    {subtitle && (
                        <Typography variant="small" className="!tw-text-gray-300 tw-text-xs sm:tw-text-sm tw-mt-1 tw-ml-9 sm:tw-ml-11">{subtitle}</Typography>
                    )}
                </div>
            )}
            <div className="tw-p-3 sm:tw-p-4 tw-space-y-3 sm:tw-space-y-4">{children}</div>
        </div>
    );
}

function Section({ title, ok, children, lang }: {
    title: React.ReactNode;
    ok: boolean;
    children?: React.ReactNode;
    lang: Lang;
}) {
    return (
        <div className={`tw-rounded-lg tw-p-2.5 sm:tw-p-3 ${ok ? "tw-bg-gray-100" : "tw-bg-gray-100"}`}>
            <div className="tw-flex tw-items-center tw-gap-2">
                {ok ? (
                    <svg className="tw-w-4 tw-h-4 tw-text-gray-700 tw-flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                ) : (
                    <svg className="tw-w-4 tw-h-4 tw-text-gray-500 tw-flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                )}
                <Typography className="tw-font-medium tw-text-xs sm:tw-text-sm tw-text-gray-800">{title}</Typography>
            </div>
            {ok ? (
                <Typography variant="small" className="!tw-text-green-600 tw-text-xs sm:tw-text-sm tw-ml-6">{t("allComplete", lang)}</Typography>
            ) : (
                <div className="tw-ml-6 tw-mt-1">{children}</div>
            )}
        </div>
    );
}

// ===== PMValidationCard - DCMasterValidation Style =====
interface ValidationError {
    section: string;
    sectionIcon: string;
    itemName: string;
    message: string;
    scrollId?: string;
}

function groupErrorsBySection(errors: ValidationError[]): Map<string, ValidationError[]> {
    const grouped = new Map<string, ValidationError[]>();
    errors.forEach((error) => {
        const key = `${error.sectionIcon} ${error.section}`;
        const existing = grouped.get(key) || [];
        existing.push(error);
        grouped.set(key, existing);
    });
    return grouped;
}

interface MissingInputItem {
    qNo: number;
    subNo?: number;
    label: string;
    fieldKey: string;
}

interface PMValidationCardProps {
    lang: Lang;
    // Photo validation
    allPhotosAttached: boolean;
    missingPhotoItems: string[];
    // Input validation
    allRequiredInputsFilled: boolean;
    missingInputsDetailed: MissingInputItem[];
    // PF validation (Post)
    allPFAnsweredPost: boolean;
    missingPFItemsPost: string[];
    // Summary validation (Post)
    isSummaryFilled: boolean;
    isSummaryCheckFilled: boolean;
}

function PMValidationCard({
    lang,
    allPhotosAttached,
    missingPhotoItems,
    allRequiredInputsFilled,
    missingInputsDetailed,
    allPFAnsweredPost,
    missingPFItemsPost,
    isSummaryFilled,
    isSummaryCheckFilled,
}: PMValidationCardProps) {
    const [isExpanded, setIsExpanded] = useState(false);

    // Helper function to get scrollId based on type and item number
    // item format: "3" for simple questions, "3.1" for sub-items
    const getPhotoScrollId = (item: string): string => {
        const parts = item.split('.');
        if (parts.length === 2) {
            // ข้อ 3.1-3.4 ใช้เลข storage 103 และ index 1-4
            if (parts[0] === "3" && /^\d+$/.test(parts[1]) && Number(parts[1]) <= 4) {
                return `pm-photo-103-${parts[1]}`;
            }
            // เลขที่แสดงของข้อเดิมเลื่อนไป 3 แต่ id ยังอิงเลข storage เดิม
            return `pm-photo-${Math.max(1, Number(parts[0]) - 3)}-${parts[1]}`;
        }
        const displayNo = Number(parts[0]);
        const storageNo = displayNo <= 3 ? displayNo + 100 : displayNo - 3;
        return `pm-photo-${storageNo}`;
    };

    const getInputScrollId = (item: string): string => {
        const parts = item.split('.');
        if (parts.length === 2) {
            return `pm-input-${parts[0]}-${parts[1]}`;
        }
        return `pm-input-${parts[0]}`;
    };

    const getQuestionScrollId = (item: string): string => {
        const mainNo = item.split('.')[0];
        return `pm-question-${mainNo}`;
    };

    const getPfButtonsScrollId = (item: string): string => {
        const parts = item.split('.');
        if (parts.length === 2) {
            if (parts[0] === "3" && /^\d+$/.test(parts[1]) && Number(parts[1]) <= 4) {
                return `pm-pf-103-${parts[1]}`;
            }
            return `pm-pf-${Math.max(1, Number(parts[0]) - 3)}-${parts[1]}`;
        }
        const displayNo = Number(parts[0]);
        const storageNo = displayNo <= 3 ? displayNo + 100 : displayNo - 3;
        return `pm-pf-${storageNo}`;
    };

    // Build validation errors
    const allErrors: ValidationError[] = useMemo(() => {
        const errors: ValidationError[] = [];

        // 1) Photo errors - link to specific photo section
        if (!allPhotosAttached) {
            missingPhotoItems.forEach((item) => {
                errors.push({
                    section: lang === "th" ? "รูปภาพ" : "Photos",
                    sectionIcon: "📷",
                    itemName: `${t("itemLabel", lang)} ${item}`,
                    message: t("missingPhoto", lang).replace(":", ""),
                    scrollId: getPhotoScrollId(item),
                });
            });
        }

        // 2) Input errors (Item 10 CP and Item 16) - link to specific input, one error per field
        if (!allRequiredInputsFilled) {
            missingInputsDetailed.forEach(({ qNo, subNo, label }) => {
                let scrollId: string;
                let itemDisplay: string;
                let message: string;

                if (qNo === 10 && subNo) {
                    // CP ยังคงเก็บเป็นข้อ 10 แต่แสดงเป็นข้อ 13
                    scrollId = `pm-input-10-${subNo}`;
                    itemDisplay = `${getDisplayedQuestionNo(qNo)}.${subNo}`;
                    message = lang === "th" ? `ยังไม่ได้กรอกค่า ${label}` : `${label} value not filled`;
                } else if (qNo === 16) {
                    // แรงดันด้านเข้ายังคงเก็บเป็นข้อ 16 แต่แสดงเป็นข้อ 19
                    scrollId = `pm-question-16`;
                    itemDisplay = `${getDisplayedQuestionNo(qNo)}`;
                    message = lang === "th" ? `ยังไม่ได้กรอกค่า ${label}` : `${label} value not filled`;
                } else {
                    scrollId = `pm-question-${qNo}`;
                    const displayNo = getDisplayedQuestionNo(qNo);
                    itemDisplay = subNo ? `${displayNo}.${subNo}` : `${displayNo}`;
                    message = lang === "th" ? `ยังไม่ได้กรอกค่า ${label}` : `${label} value not filled`;
                }

                errors.push({
                    section: lang === "th" ? "ค่าที่ต้องกรอก" : "Required Inputs",
                    sectionIcon: "📝",
                    itemName: `${t("itemLabel", lang)} ${itemDisplay}`,
                    message,
                    scrollId,
                });
            });
        }

        // 4) PF status errors - link to PF buttons directly
        if (!allPFAnsweredPost) {
            missingPFItemsPost.forEach((item) => {
                errors.push({
                    section: lang === "th" ? "ระดับผลการตรวจ / N/A" : "Inspection rating / N/A",
                    sectionIcon: "✅",
                    itemName: `${t("itemLabel", lang)} ${item}`,
                    message: lang === "th" ? "ยังไม่ได้เลือกสถานะ" : "Status not selected",
                    scrollId: getPfButtonsScrollId(item),
                });
            });
        }

        // 6) Summary errors
        if (!isSummaryFilled) {
            errors.push({
                section: lang === "th" ? "สรุปผลการตรวจสอบ" : "Inspection Summary",
                sectionIcon: "📋",
                itemName: "Comment",
                message: t("missingSummaryText", lang),
                scrollId: "pm-summary-section",
            });
        }
        if (!isSummaryCheckFilled) {
            errors.push({
                section: lang === "th" ? "สรุปผลการตรวจสอบ" : "Inspection Summary",
                sectionIcon: "📋",
                itemName: lang === "th" ? "สถานะสรุปผล" : "Summary Status",
                message: t("missingSummaryStatus", lang),
                scrollId: "pm-summary-section",
            });
        }

        return errors;
    }, [
        lang,
        allPhotosAttached, missingPhotoItems,
        allRequiredInputsFilled, missingInputsDetailed,
        allPFAnsweredPost, missingPFItemsPost,
        isSummaryFilled, isSummaryCheckFilled
    ]);

    const groupedErrors = useMemo(() => groupErrorsBySection(allErrors), [allErrors]);
    const isComplete = allErrors.length === 0;

    // Scroll to item and highlight
    const scrollToItem = (scrollId?: string) => {
        if (!scrollId) return;
        const element = document.getElementById(scrollId);
        if (element) {
            element.scrollIntoView({ behavior: "smooth", block: "center" });
            element.classList.add("tw-ring-2", "tw-ring-amber-400", "tw-bg-amber-50");
            setTimeout(() => {
                element.classList.remove("tw-ring-2", "tw-ring-amber-400", "tw-bg-amber-50");
            }, 2000);
        }
    };

    return (
        <div
            className={`tw-rounded-xl tw-border tw-shadow-sm tw-overflow-hidden ${isComplete ? "tw-border-green-200 tw-bg-green-50" : "tw-border-amber-200 tw-bg-amber-50"
                }`}
        >
            {/* Header */}
            <div
                className={`tw-px-4 tw-py-3 tw-cursor-pointer tw-flex tw-items-center tw-justify-between ${isComplete ? "tw-bg-green-100" : "tw-bg-amber-100"
                    }`}
                onClick={() => setIsExpanded(!isExpanded)}
            >
                <div className="tw-flex tw-items-center tw-gap-3">
                    {isComplete ? (
                        <div className="tw-w-10 tw-h-10 tw-rounded-full tw-bg-green-500 tw-flex tw-items-center tw-justify-center">
                            <svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                    ) : (
                        <div className="tw-w-10 tw-h-10 tw-rounded-full tw-bg-amber-500 tw-flex tw-items-center tw-justify-center">
                            <svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                />
                            </svg>
                        </div>
                    )}
                    <div>
                        <Typography className={`tw-font-bold tw-text-base ${isComplete ? "tw-text-green-800" : "tw-text-amber-800"}`}>
                            {t("formStatus", lang)}
                        </Typography>
                        <Typography variant="small" className={isComplete ? "tw-text-green-600" : "tw-text-amber-600"}>
                            {isComplete ? t("allCompleteReady", lang) : t("remaining", lang).replace("{n}", String(allErrors.length))}
                        </Typography>
                    </div>
                </div>

                <div className="tw-flex tw-items-center tw-gap-4">
                    {/* Section badges */}
                    {!isComplete && (
                        <div className="tw-hidden md:tw-flex tw-items-center tw-gap-2">
                            {Array.from(groupedErrors.keys()).map((sectionKey) => (
                                <span
                                    key={sectionKey}
                                    className="tw-text-xs tw-bg-amber-200 tw-text-amber-800 tw-px-2 tw-py-1 tw-rounded-full tw-font-medium"
                                >
                                    {sectionKey.split(" ")[0]} {groupedErrors.get(sectionKey)?.length}
                                </span>
                            ))}
                        </div>
                    )}

                    {/* Expand/Collapse */}
                    {!isComplete && (
                        <svg
                            className={`tw-w-6 tw-h-6 tw-text-amber-600 tw-transition-transform ${isExpanded ? "tw-rotate-180" : ""}`}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                    )}
                </div>
            </div>

            {/* Error List */}
            {isExpanded && !isComplete && (
                <div className="tw-px-4 tw-py-3 tw-max-h-80 tw-overflow-y-auto">
                    <div className="tw-space-y-4">
                        {Array.from(groupedErrors.entries()).map(([sectionKey, sectionErrors]) => (
                            <div key={sectionKey} className="tw-bg-white tw-rounded-lg tw-p-3 tw-border tw-border-amber-200">
                                <div className="tw-flex tw-items-center tw-justify-between tw-mb-2">
                                    <Typography className="tw-font-semibold tw-text-gray-800 tw-text-sm">
                                        {sectionKey}
                                    </Typography>
                                    <span className="tw-text-xs tw-bg-amber-100 tw-text-amber-700 tw-px-2 tw-py-0.5 tw-rounded-full">
                                        {sectionErrors.length} {t("items", lang)}
                                    </span>
                                </div>
                                <ul className="tw-space-y-1 tw-max-h-40 tw-overflow-y-auto">
                                    {sectionErrors.map((error, idx) => (
                                        <li
                                            key={idx}
                                            className="tw-flex tw-items-start tw-gap-2 tw-text-sm tw-text-amber-700 tw-cursor-pointer hover:tw-text-amber-900 hover:tw-bg-amber-50 tw-rounded tw-px-1 tw-py-0.5 tw-transition-colors"
                                            onClick={() => scrollToItem(error.scrollId)}
                                        >
                                            <span className="tw-text-amber-500 tw-mt-0.5">→</span>
                                            <span>
                                                <span className="tw-font-medium">{error.itemName}:</span>{" "}
                                                <span className="tw-underline tw-underline-offset-2">{error.message}</span>
                                            </span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

function InputWithUnit<U extends string>({
    label, value, unit, units, onValueChange, onUnitChange, readOnly, disabled, labelOnTop, required = false, isNA = false, onNAChange, lang
}: {
    label: string; value: string; unit: U; units: readonly U[];
    onValueChange: (v: string) => void; onUnitChange: (u: U) => void;
    readOnly?: boolean; disabled?: boolean; labelOnTop?: boolean; required?: boolean;
    isNA?: boolean; onNAChange?: (isNA: boolean) => void; lang: Lang;
}) {
    const [showError, setShowError] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = e.target.value;
        // Allow: empty, negative sign, digits, decimal point
        // Pattern: optional minus, digits, optional decimal with digits
        if (newValue === "" || newValue === "-" || /^-?\d*\.?\d*$/.test(newValue)) {
            onValueChange(newValue);
            setShowError(false);
        } else {
            // Show error briefly when invalid input is attempted
            setShowError(true);
            setTimeout(() => setShowError(false), 2000);
        }
    };

    if (isNA) {
        return (
            <div className="tw-space-y-1">
                <div className="tw-flex tw-items-center tw-gap-2 tw-h-10 tw-px-3 tw-py-2 tw-rounded-lg tw-border tw-border-blue-gray-200 tw-bg-amber-50">
                    <Typography variant="small" className="tw-text-amber-700 tw-font-medium">{t("naNoValue", lang)}</Typography>
                    {onNAChange && !readOnly && <Button size="sm" variant="text" onClick={() => onNAChange(false)} className="tw-ml-auto tw-text-xs">{t("removeNA", lang)}</Button>}
                </div>
            </div>
        );
    }

    return (
        <div className="tw-space-y-1">
            <div className="tw-flex tw-items-center tw-gap-2">
                <div className="tw-flex-1 tw-relative">
                    <input
                        type="text"
                        inputMode="text"
                        pattern="-?[0-9]*\.?[0-9]*"
                        value={value}
                        onChange={handleChange}
                        readOnly={readOnly}
                        disabled={disabled}
                        required={required}
                        placeholder=" "
                        className={`tw-peer tw-w-full tw-h-10 tw-px-3 tw-pt-4 tw-pb-1 tw-text-sm tw-border tw-rounded-lg tw-outline-none focus:tw-ring-1 ${showError ? "tw-border-red-500 focus:tw-border-red-500 focus:tw-ring-red-500" : "tw-border-gray-300 focus:tw-border-blue-500 focus:tw-ring-blue-500"} ${disabled ? "tw-bg-gray-100 tw-text-gray-500" : "tw-bg-white"}`}
                    />
                    <label className={`tw-absolute tw-left-3 tw-top-1 tw-text-[10px] tw-pointer-events-none ${showError ? "tw-text-red-500" : "tw-text-gray-500"}`}>
                        {label}{required && <span className="tw-text-red-500">*</span>}
                    </label>
                </div>
                <div className="tw-flex-shrink-0 tw-w-10 tw-h-10 tw-flex tw-items-center tw-justify-center tw-text-gray-600 tw-font-medium tw-text-sm tw-bg-gray-100 tw-rounded-lg tw-border tw-border-gray-200">
                    {unit}
                </div>
            </div>
            {showError && (
                <Typography variant="small" className="tw-text-red-500 tw-text-xs">
                    {lang === "th" ? "กรุณากรอกเฉพาะตัวเลข, จุดทศนิยม (.) หรือ (-)" : "Please enter only numbers, decimal point (.) or (-)"}
                </Typography>
            )}
            {onNAChange && !readOnly && !isNA && (
                <Button size="sm" variant="outlined" onClick={() => onNAChange(true)} className="tw-w-full tw-border-amber-500 tw-text-amber-700">{t("naNoValue", lang)}</Button>
            )}
        </div>
    );
}

// ==================== GET GPS LOCATION ====================
async function getCurrentGPS(): Promise<{ lat: number; lng: number } | null> {
    if (!navigator.geolocation) return null;
    if (window.isSecureContext === false) return null;

    // ลอง cached ก่อน (เร็วมาก ~0ms)
    const fast = await new Promise<{ lat: number; lng: number } | null>((resolve) => {
        const t = setTimeout(() => resolve(null), 2000);
        navigator.geolocation.getCurrentPosition(
            (pos) => { clearTimeout(t); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
            () => { clearTimeout(t); resolve(null); },
            { enableHighAccuracy: false, timeout: 1500, maximumAge: 300000 } // cache 5 นาที
        );
    });
    if (fast) return fast;

    // ถ้า cache ไม่มี ลอง high accuracy
    return new Promise((resolve) => {
        const t = setTimeout(() => resolve(null), 8000);
        navigator.geolocation.getCurrentPosition(
            (pos) => { clearTimeout(t); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
            () => { clearTimeout(t); resolve(null); },
            { enableHighAccuracy: true, timeout: 7000, maximumAge: 30000 }
        );
    });
}

// ==================== REVERSE GEOCODING ====================
const GOOGLE_MAPS_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY ?? "";

async function reverseGeocodeGoogle(lat: number, lng: number): Promise<string | null> {
    if (!GOOGLE_MAPS_KEY) return null;
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&language=th&result_type=street_address|route|premise|subpremise|establishment&key=${GOOGLE_MAPS_KEY}`;
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId);
        if (!res.ok) return null;
        const data = await res.json();
        if (data.status !== "OK" || !data.results?.length) return null;

        // ใช้ผลลัพธ์แรกที่ละเอียดที่สุด
        const best = data.results[0];
        const components = best.address_components || [];

        const get = (type: string) => components.find((c: any) => c.types?.includes(type))?.long_name || "";

        const streetNumber = get("street_number");
        const route = get("route");                          // ถนน/ซอย
        const sublocality2 = get("sublocality_level_2");     // ซอยย่อย
        const sublocality1 = get("sublocality_level_1");     // แขวง/ตำบล
        const locality = get("locality");                     // เขต/อำเภอ
        const adminArea2 = get("administrative_area_level_2"); // อำเภอ (บางที)
        const adminArea1 = get("administrative_area_level_1"); // จังหวัด
        const premise = get("premise");                       // ชื่ออาคาร/สถานที่

        const parts: string[] = [];

        // ชื่อสถานที่/อาคาร
        if (premise) parts.push(premise);

        // บ้านเลขที่ + ถนน
        if (streetNumber && route) parts.push(`${streetNumber} ${route}`);
        else if (route) parts.push(route);

        // ซอยย่อย
        if (sublocality2 && !parts.some(p => p.includes(sublocality2))) parts.push(sublocality2);

        // ตำบล/แขวง
        const sub = sublocality1;
        if (sub && !parts.some(p => p.includes(sub))) parts.push(sub);

        // อำเภอ/เขต
        const dist = locality || adminArea2;
        if (dist && !parts.some(p => p.includes(dist))) parts.push(dist);

        // จังหวัด
        if (adminArea1 && !parts.some(p => p.includes(adminArea1))) parts.push(adminArea1);

        if (parts.length > 0) {
            let result = parts.join(" ");
            if (result.length > 80) result = result.substring(0, 77) + "...";
            return result;
        }

        // fallback: ใช้ formatted_address จาก Google
        if (best.formatted_address) {
            const addr = best.formatted_address.replace(/\s*\d{5}\s*/, " ").replace(/ประเทศไทย/g, "").trim();
            return addr.length > 80 ? addr.substring(0, 77) + "..." : addr;
        }

        return null;
    } catch {
        return null;
    }
}

async function reverseGeocodeNominatim(lat: number, lng: number): Promise<string> {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=th&zoom=21&addressdetails=1`;
        const res = await fetch(url, {
            headers: { "User-Agent": "PM-Checklist-App/1.0" },
            signal: controller.signal,
        });
        clearTimeout(timeoutId);
        if (!res.ok) return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
        const data = await res.json();

        const addr = data.address || {};
        const poi = addr.amenity || addr.building || addr.shop || addr.tourism || addr.leisure || addr.office || addr.industrial || "";
        let roadPart = "";
        const houseNo = addr.house_number || "";
        const road = addr.road || addr.pedestrian || addr.footway || "";
        if (houseNo && road) roadPart = `${houseNo} ${road}`;
        else if (road) roadPart = road;

        const village = addr.village || addr.hamlet || addr.neighbourhood || addr.residential || addr.quarter || "";
        const subdistrict = addr.subdistrict || addr.suburb || "";
        const district = addr.district || addr.city_district || addr.county || "";
        const province = addr.province || addr.state || addr.city || addr.town || "";

        const rawParts = [poi, roadPart, village, subdistrict, district, province].filter(Boolean);
        const parts: string[] = [];
        for (const p of rawParts) {
            if (!parts.some(existing => existing.includes(p) || p.includes(existing))) parts.push(p);
        }

        if (parts.length > 0) {
            let result = parts.slice(0, 4).join(" ");
            if (result.length > 70) result = result.substring(0, 67) + "...";
            return result;
        }

        if (data.display_name) {
            const short = data.display_name.split(",").slice(0, 4).join(",").trim();
            return short.length > 70 ? short.substring(0, 67) + "..." : short;
        }

        return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
    } catch {
        return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
    }
}

async function reverseGeocode(lat: number, lng: number): Promise<string> {
    // ลอง Google ก่อน (ละเอียดกว่า)
    const google = await reverseGeocodeGoogle(lat, lng);
    if (google) return google;
    // fallback Nominatim
    return reverseGeocodeNominatim(lat, lng);
}

// ==================== ADD TIMESTAMP TO IMAGE ====================
// ⚡ FIX: แปลงชื่อไฟล์ให้นามสกุลตรงกับ content จริง (JPEG)
// เช่น "IMG_1234.HEIC" → "IMG_1234.jpg", "photo.PNG" → "photo.jpg"
// ⚡ FIX 422: ชื่อไฟล์จากกล้อง/แกลเลอรีบางเครื่องมี " หรือ newline ปนมา ทำให้ header
// Content-Disposition ของ multipart เพี้ยน → server parse body ไม่ออก ตอบ 422 โดยที่
// sn/group/files หายพร้อมกันทั้งหมด จึงเหลือไว้เฉพาะอักขระที่ปลอดภัยเสมอ
function ensureJpgFilename(name: string): string {
    const base = (name || "").replace(/\.[^.]*$/, "");
    const safe = base.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._-]+/, "").slice(0, 80);
    return safe ? `${safe}.jpg` : `image_${Date.now()}.jpg`;
}

async function addTimestampToImage(file: File, locationText: string): Promise<File> {
    return new Promise((resolve) => {
        const img = document.createElement("img");
        img.onload = () => {
            try {
                URL.revokeObjectURL(img.src);

                const canvas = document.createElement("canvas");
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext("2d");

                if (!ctx) {
                    console.error("Canvas context not available");
                    resolve(file);
                    return;
                }

                // วาดรูปภาพ
                ctx.drawImage(img, 0, 0);

                // สร้าง timestamp text
                const now = new Date();
                const timestamp = now.toLocaleString("th-TH", {
                    year: "numeric",
                    month: "2-digit",
                    day: "2-digit",
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                    hour12: false,
                });

                // คำนวณขนาด font ตามขนาดรูป
                const fontSize = Math.max(14, Math.floor(img.width * 0.022));
                const padding = Math.floor(fontSize * 0.5);
                const lineHeight = fontSize * 1.3;

                ctx.font = `bold ${fontSize}px Arial, sans-serif`;
                const timestampDisplay = timestamp;
                const locationDisplay = `📍 ${locationText}`;
                const timestampWidth = ctx.measureText(timestampDisplay).width;
                const locationWidth = ctx.measureText(locationDisplay).width;
                const totalHeight = lineHeight * 2;

                // ⚡ FIX: ใช้ความกว้างคงที่ + anchor มุมล่างซ้าย → ตำแหน่งไม่เพี้ยน
                const boxWidth = Math.max(
                    Math.floor(img.width * 0.6),
                    Math.max(timestampWidth, locationWidth) + padding * 2
                );
                const bgX = 10;
                const bgY = Math.max(0, img.height - totalHeight - padding * 2 - 10);
                ctx.fillStyle = "rgba(0, 0, 0, 0.65)";
                ctx.fillRect(bgX, bgY, boxWidth, totalHeight + padding * 2);

                ctx.fillStyle = "#FFFFFF";
                ctx.textBaseline = "top";
                ctx.fillText(timestampDisplay, bgX + padding, bgY + padding);
                let locText = locationDisplay;
                while (ctx.measureText(locText).width > boxWidth - padding * 2 && locText.length > 10) {
                    locText = locText.slice(0, -4) + "...";
                }
                ctx.fillText(locText, bgX + padding, bgY + padding + lineHeight);


                // แปลงกลับเป็น File
                canvas.toBlob((blob) => {
                    if (blob) {
                        // ⚡ FIX: ใช้ ensureJpgFilename เพื่อแก้นามสกุลให้ตรงกับ content (JPEG)
                        const newFile = new File([blob], ensureJpgFilename(file.name), { type: "image/jpeg" });
                        resolve(newFile);
                    } else {
                        console.error("Canvas toBlob failed");
                        resolve(file);
                    }
                }, "image/jpeg", 0.9);
            } catch (err) {
                console.error("Error in addTimestampToImage:", err);
                resolve(file);
            }
        };
        img.onerror = (err) => {
            console.error("Image load error:", err);
            resolve(file);
        };
        img.src = URL.createObjectURL(file);
    });
}

// ==================== PHOTO INPUT ====================
const MAX_PHOTOS_PER_ITEM = 10;
const MAX_PHOTOS_PER_GROUP = 20;

function getImageDimensions(file: File): Promise<{ width: number; height: number }> {
    return new Promise((resolve, reject) => {
        const img = new window.Image();
        img.onload = () => { resolve({ width: img.naturalWidth, height: img.naturalHeight }); URL.revokeObjectURL(img.src); };
        img.onerror = () => { reject(new Error("Cannot read image")); URL.revokeObjectURL(img.src); };
        img.src = URL.createObjectURL(file);
    });
}

function isMobileDevice(): boolean {
    if (typeof navigator === "undefined") return false;
    return /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
        || ("ontouchstart" in window && navigator.maxTouchPoints > 0);
}

/**
 * ข้อความโควตารูปของข้อย่อย
 *
 * เพดานจริงของแต่ละข้อย่อยลดลงเองเมื่อข้อย่อยอื่นแนบไปแล้ว (ต่อข้อย่อย 10 แต่รวมทั้งข้อ 20)
 * ถ้าเขียนแค่ "สูงสุด 10 รูป" ผู้ใช้จะงงว่าทำไมแนบได้ไม่ถึง จึงบอกจำนวนที่เหลือจริง
 * และถ้าเต็มแล้วต้องบอกด้วยว่าเต็มเพราะข้อย่อยนี้เอง หรือเพราะโควตารวมของข้อใหญ่
 */
function subItemQuotaLabel(itemCount: number, groupTotal: number, itemMax: number, groupMax: number, lang: Lang): string {
    const canAdd = Math.max(0, Math.min(itemMax - itemCount, groupMax - groupTotal));
    if (canAdd > 0) {
        return lang === "th"
            ? `แนบได้อีก ${canAdd} รูป (ข้อย่อยนี้ ${itemCount}/${itemMax})`
            : `${canAdd} more allowed (this sub-item ${itemCount}/${itemMax})`;
    }
    if (itemCount >= itemMax) {
        return lang === "th"
            ? `ข้อย่อยนี้ครบ ${itemMax} รูปแล้ว`
            : `This sub-item is full (${itemMax} photos)`;
    }
    return lang === "th"
        ? `ข้อนี้ครบ ${groupMax} รูปแล้ว (นับรวมทุกข้อย่อย)`
        : `This question is full (${groupMax} photos across all sub-items)`;
}

function PhotoMultiInput({
    photos, setPhotos, max = MAX_PHOTOS_PER_ITEM, draftKey, qNo, lang, id, hideMaxLabel = false, maxLabel,
}: {
    label?: string; photos: PhotoItem[]; setPhotos: React.Dispatch<React.SetStateAction<PhotoItem[]>>;
    max?: number; draftKey: string; qNo: number; lang: Lang; id?: string; hideMaxLabel?: boolean;
    maxLabel?: string;
}) {
    const cameraRef = useRef<HTMLInputElement>(null);
    const fileRef = useRef<HTMLInputElement>(null);
    const isMobile = useMemo(() => isMobileDevice(), []);
    const [landscapeWarning, setLandscapeWarning] = useState(false);

    const processFile = async (rawFile: File): Promise<PhotoItem | null> => {
        try {
            // กันไฟล์ว่าง (size=0) ตั้งแต่ต้นทาง — เป็นต้นเหตุของ error "Empty file (size=0)" ตอนอัปโหลด
            if (!rawFile || rawFile.size === 0) {
                console.warn("processFile: empty source file", rawFile?.name);
                return null;
            }
            // รูป HEIC จาก iPhone: เบราว์เซอร์นอกจาก Safari decode ไม่ได้ ทำให้ทั้งท่อพังเงียบ ๆ
            // — addTimestampToImage ไม่ประทับเวลา/พิกัด, compressImage ไม่บีบ, preview ขึ้นกรอบว่าง
            // แปลงเป็น JPEG ที่ server ก่อน (ล้มเหลวก็คืนไฟล์เดิม backend แปลงให้อีกชั้นตอนอัปโหลด)
            const file = await ensureViewableImage(rawFile);
            const locationText = await getCachedLocation();
            const stamped = await addTimestampToImage(file, locationText);
            // ถ้า encode แล้วได้ไฟล์ว่าง (เช่น canvas ล้มเหลวบางเครื่อง) ให้ fallback ไฟล์เดิม แล้วเช็กซ้ำ
            const fileWithTimestamp = (stamped && stamped.size > 0) ? stamped : file;
            if (fileWithTimestamp.size === 0) {
                console.warn("processFile: empty file after timestamp", file.name);
                return null;
            }
            // บีบรูปก่อนเก็บลง IndexedDB — ลดพื้นที่จัดเก็บ (กัน quota เต็มบนมือถือ) + ได้รูปที่พร้อมอัปโหลดเลย
            const compressed = await compressImage(fileWithTimestamp);
            const finalFile = (compressed && compressed.size > 0) ? compressed : fileWithTimestamp;

            // ⚡ ดักตั้งแต่ตอนแนบ: .size เชื่อไม่ได้ (iOS คืน backing store แต่ยังรายงาน size เดิม)
            // ต้องลองอ่านจริง ไม่งั้นรูปที่เสียจะรอไประเบิดตอนกดบันทึกเป็น 422 ที่อ่านไม่รู้เรื่อง
            if (!(await isFileReadable(finalFile))) {
                console.warn("processFile: ไฟล์อ่านไม่ได้ตั้งแต่ตอนแนบ", file.name);
                return null;
            }
            // หมายเหตุ: เคย return null ตรงนี้ถ้า decode ไม่ผ่าน แต่ทำให้แนบรูปไม่ได้เลย
            // เพราะ CSP img-src ไม่อนุญาต blob: การโหลดรูปเลยล้มเหลวทุกใบ
            // เหลือไว้เป็น log อย่างเดียว ห้ามใช้ block การแนบรูป
            if (!(await isImageDecodable(finalFile))) {
                console.warn("processFile: เบราว์เซอร์แสดงผลรูปนี้ไม่ได้", file.name, file.type);
            }

            const photoId = `${qNo}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${file.name}`;
            // putPhoto throw เมื่อเขียน IndexedDB ไม่ได้ (พื้นที่เต็ม / private mode)
            // ห้ามให้ตกไป catch ข้างล่าง เพราะรูปจะถูกทิ้งพร้อมข้อความ "ไฟล์เสียหาย" ที่บอกสาเหตุผิด
            // เก็บรูปไว้ใน memory ต่อ (อัปโหลดได้ปกติ) แล้วเตือนว่าห้ามรีเฟรชก่อนกดบันทึก
            let ref: PhotoRef | undefined;
            try {
                ref = await putPhoto(draftKey, photoId, finalFile);
            } catch (e) {
                console.error("putPhoto failed:", e);
                reportPhotoStorageFailure(lang);
            }

            const now = new Date().toLocaleString("th-TH", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
            });
            return { id: photoId, file: finalFile, preview: URL.createObjectURL(finalFile), remark: "", ref, createdAt: now, location: locationText };
        } catch (err) {
            console.error("processFile error:", err);
            return null;
        }
    };

    const handleFiles = async (list: FileList | null, fromCamera: boolean) => {
        if (!list || list.length === 0) return;
        const remain = Math.max(0, max - photos.length);

        if (remain === 0) {
            alert(lang === "th" ? `แนบรูปได้สูงสุด ${max} รูปต่อข้อ` : `Maximum ${max} photos per item`);
            return;
        }

        const files = Array.from(list).slice(0, remain);

        if (Array.from(list).length > remain) {
            alert(lang === "th"
                ? `เลือกได้อีก ${remain} รูป (ครบ ${max} รูปแล้ว)`
                : `Only ${remain} more photo(s) allowed (max ${max})`);
        }

        let hasLandscape = false;
        const validFiles: File[] = [];

        // ขั้นที่ 1 — กรองรูปแนวนอน (เฉพาะกล้อง)
        for (const f of files) {
            if (fromCamera) {
                try {
                    const dim = await getImageDimensions(f);
                    if (dim.width > dim.height) {
                        hasLandscape = true;
                        continue;
                    }
                } catch { }
            }
            validFiles.push(f);
        }

        // ขั้นที่ 2 — processFile ครั้งเดียว
        const results = await Promise.all(validFiles.map(f => processFile(f)));
        const accepted = results.filter(Boolean) as PhotoItem[];
        const rejected = validFiles.length - accepted.length;

        if (accepted.length > 0) {
            setPhotos((prev) => [...prev, ...accepted]);
        }

        // แจ้งเตือนถ้ามีรูปว่าง/เสียหายถูกข้าม — กันผู้ใช้เข้าใจผิดว่าแนบครบแล้ว
        if (rejected > 0) {
            alert(lang === "th"
                ? `มีรูปว่าง/เสียหาย ${rejected} รูป ใช้ไม่ได้ กรุณาถ่ายหรือเลือกใหม่อีกครั้ง`
                : `${rejected} photo(s) are empty/corrupted and were skipped. Please retake or reselect.`);
        }

        if (hasLandscape) setLandscapeWarning(true);

        if (cameraRef.current) cameraRef.current.value = "";
        if (fileRef.current) fileRef.current.value = "";
    };

    const handleRemove = async (id: string) => {
        await delPhoto(draftKey, id);
        setPhotos((prev) => {
            const target = prev.find((p) => p.id === id);
            if (target?.preview) URL.revokeObjectURL(target.preview);
            return prev.filter((p) => p.id !== id);
        });
    };

    return (
        <div id={id} className="tw-space-y-3 tw-transition-all tw-duration-300">
            {/* Landscape warning modal */}
            {landscapeWarning && (
                <div className="tw-fixed tw-inset-0 tw-z-[9999] tw-bg-black/70 tw-flex tw-items-center tw-justify-center tw-p-6" onClick={() => setLandscapeWarning(false)}>
                    <div className="tw-bg-white tw-rounded-2xl tw-p-6 tw-max-w-sm tw-text-center tw-shadow-xl" onClick={(e) => e.stopPropagation()}>
                        <svg className="tw-w-14 tw-h-14 tw-text-amber-500 tw-mx-auto tw-mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                        </svg>
                        <p className="tw-text-lg tw-font-bold tw-text-gray-800 tw-mb-2">
                            {lang === "th" ? "กรุณาถ่ายรูปแนวตั้ง" : "Please take portrait photos"}
                        </p>
                        <p className="tw-text-sm tw-text-gray-600 tw-mb-4">
                            {lang === "th"
                                ? "รูปที่ถ่ายเป็นแนวนอนจะไม่ถูกรับ กรุณาหมุนมือถือเป็นแนวตั้งแล้วถ่ายใหม่"
                                : "Landscape photos are not accepted. Please hold your phone upright and retake."}
                        </p>
                        <Button size="sm" color="amber" variant="filled" onClick={() => setLandscapeWarning(false)} className="tw-w-full">
                            {lang === "th" ? "รับทราบ" : "OK"}
                        </Button>
                    </div>
                </div>
            )}

            <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2">
                {isMobile ? (
                    <Button data-photo-add size="sm" color="blue" variant="outlined" onClick={() => cameraRef.current?.click()} className="tw-shrink-0 tw-flex tw-items-center tw-gap-1">
                        <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        {t("takePhoto", lang)}
                    </Button>
                ) : (
                    <Button data-photo-add size="sm" color="blue" variant="outlined" onClick={() => fileRef.current?.click()} className="tw-shrink-0 tw-flex tw-items-center tw-gap-1">
                        <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        {t("attachPhoto", lang)}
                    </Button>
                )}
            </div>

            {/* มือถือ: input เปิดกล้องตรง */}
            {isMobile && <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="tw-hidden"
                onChange={(e) => { void handleFiles(e.target.files, true); }} />}
            {/* PC: input เลือกไฟล์ */}
            {!isMobile && <input ref={fileRef} type="file" accept="image/*" multiple className="tw-hidden"
                onChange={(e) => { void handleFiles(e.target.files, false); }} />}

            {!hideMaxLabel && (
                <Typography variant="small" className="!tw-text-blue-gray-500 tw-flex tw-items-center">
                    {maxLabel ?? `${t("maxPhotos", lang)} ${max} ${t("photos", lang)}`}
                </Typography>
            )}
            {photos.length > 0 ? (
                <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-3 md:tw-grid-cols-4 tw-gap-3">
                    {photos.map((p) => (
                        <div key={p.id} className="tw-border tw-rounded-lg tw-overflow-hidden tw-bg-gray-100 tw-shadow-xs tw-flex tw-flex-col">
                            <div className="tw-relative tw-aspect-[4/3] tw-bg-gray-100">
                                {p.preview && <img src={p.preview} alt={t("photoPreviewAlt", lang)} className="tw-w-full tw-h-full tw-object-contain" />}
                                {/* Timestamp & Location overlay */}
                                {/* {(p.createdAt || p.location) && (
                                    <span className="tw-absolute tw-bottom-1 tw-right-1 tw-text-[8px] tw-leading-tight tw-bg-black/60 tw-text-white tw-px-1.5 tw-py-1 tw-rounded tw-pointer-events-none tw-text-right tw-max-w-[90%] tw-truncate">
                                        {p.createdAt && <span className="tw-block tw-font-mono">{p.createdAt}</span>}
                                        {p.location && <span className="tw-block tw-opacity-80 tw-truncate">📍 {p.location}</span>}
                                    </span>
                                )} */}
                                <button data-photo-remove onClick={() => { void handleRemove(p.id); }}
                                    className="tw-absolute tw-top-2 tw-right-2 tw-bg-red-500 tw-text-white tw-w-6 tw-h-6 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-shadow-md hover:tw-bg-red-600 tw-transition-colors">×</button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <Typography variant="small" className="!tw-text-blue-gray-500">{t("noPhotos", lang)}</Typography>
            )}
        </div>
    );
}

function DynamicItemsSection({
    qNo, items, addItem, removeItem, addButtonLabel, renderAdditionalFields, editable = true,
    photos, setPhotos, rows, setRows, draftKey, lang,
    showDustFilterCheckbox = false, dustFilterChanged, setDustFilterChanged,
    countLabel, count, countUnit,
}: {
    qNo: number;
    items: { key: string; label: string }[];
    addItem?: () => void;
    removeItem?: (idx: number) => void;
    addButtonLabel?: string;
    renderAdditionalFields?: (item: { key: string; label: string }, idx: number, isNA: boolean) => React.ReactNode;
    editable?: boolean;
    photos: Record<number | string, PhotoItem[]>;
    setPhotos: React.Dispatch<React.SetStateAction<Record<number | string, PhotoItem[]>>>;
    rows: Record<string, { pf: PF; remark: string }>;
    setRows: React.Dispatch<React.SetStateAction<Record<string, { pf: PF; remark: string }>>>;
    draftKey: string;
    lang: Lang;
    showDustFilterCheckbox?: boolean;
    dustFilterChanged?: Record<string, boolean>;
    setDustFilterChanged?: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
    countLabel?: string;
    count?: number;
    countUnit?: string;
}) {
    const makePhotoSetter = (photoKey: string): React.Dispatch<React.SetStateAction<PhotoItem[]>> => (action) => {
        setPhotos((prev) => {
            const current = prev[photoKey] || [];
            const next = typeof action === "function" ? action(current) : action;
            return { ...prev, [photoKey]: next };
        });
    };

    const totalPhotosInGroup = items.reduce((sum, _, idx) => sum + (photos[`${qNo}_${idx}`]?.length ?? 0), 0);
    // ITEM_MAX = ต่อข้อย่อย, GROUP_MAX = รวมทั้งข้อใหญ่
    // GROUP_MAX ต้องไม่เกิน PHOTO_MAX_PER_ROW ของ pdf_charger.py เพราะ PDF รวมรูปของ
    // ข้อย่อยทุกอัน (g7, g7_1, g7_2, ...) เข้าเป็นก้อนเดียวของข้อใหญ่แล้วตัดส่วนเกินทิ้งเงียบๆ
    // วัดแล้วหน้า A4 ใส่ได้ 5 บรรทัด x 4 รูป = 20 รูป
    const ITEM_MAX = MAX_PHOTOS_PER_ITEM;
    const GROUP_MAX = MAX_PHOTOS_PER_GROUP;
    const groupPhotoLabel = lang === "th"
        ? `รูปในข้อนี้ ${totalPhotosInGroup}/${GROUP_MAX} — ข้อย่อยละไม่เกิน ${ITEM_MAX} รูป`
        : `${totalPhotosInGroup}/${GROUP_MAX} photos in this question — max ${ITEM_MAX} per sub-item`;
    return (
        <div className="tw-space-y-0">
            {/* Count summary row */}
            {countLabel && count !== undefined && (
                <div className="tw-flex tw-items-center tw-justify-between tw-pb-3 tw-border-b tw-border-gray-200">
                    <div className="tw-flex tw-items-center tw-gap-2">
                        <Typography variant="small" className="tw-text-blue-gray-600">{countLabel}</Typography>
                        <Typography variant="small" className="tw-font-bold tw-text-blue-600">{count} {countUnit || t("unit", lang)}</Typography>
                    </div>
                    {/* แสดง groupPhotoLabel ถ้าไม่มี add button หรือแสดง add button */}
                    {editable && addItem && addButtonLabel && items.length < 66 ? (
                        <Button size="sm" color="gray" variant="outlined" onClick={addItem} className="tw-flex tw-items-center tw-gap-1">
                            <span className="tw-text-lg tw-leading-none">+</span>
                            <span className="tw-text-xs">{addButtonLabel}</span>
                        </Button>
                    ) : (
                        <Typography variant="small" className="!tw-text-blue-gray-400 tw-italic">{groupPhotoLabel}</Typography>
                    )}
                </div>
            )}
            <div className="tw-divide-y tw-divide-gray-200">
                {items.map((item, idx) => {
                    const subNo = idx + 1;
                    const photoId = `pm-photo-${qNo}-${subNo}`;
                    const remarkId = `pm-remark-${qNo}-${subNo}`;
                    const pfButtonsId = `pm-pf-${qNo}-${subNo}`;

                    const checkboxElement = showDustFilterCheckbox && dustFilterChanged !== undefined && setDustFilterChanged ? (
                        <label className="tw-flex tw-items-center tw-gap-2 tw-text-xs sm:tw-text-sm tw-text-gray-700 tw-py-2">
                            <input type="checkbox" className="tw-h-4 tw-w-4 tw-rounded tw-border-gray-300 tw-text-gray-700 focus:tw-ring-gray-500"
                                checked={dustFilterChanged[item.key] || false}
                                onChange={(e) => setDustFilterChanged(prev => ({ ...prev, [item.key]: e.target.checked }))} />
                            <span className="tw-leading-tight">{t("replaceAirFilter", lang)}</span>
                        </label>
                    ) : null;

                    return (
                        <div key={item.key} className="tw-py-4 first:tw-pt-2">
                            <PassFailRow
                                label={getDisplayedItemLabel(item.label, qNo)}
                                labelRight={editable && items.length > 1 && removeItem && (
                                    <button type="button" onClick={() => removeItem(idx)}
                                        className="tw-h-6 tw-w-6 tw-flex-shrink-0 tw-flex tw-items-center tw-justify-center tw-rounded tw-bg-red-50 tw-text-red-600 hover:tw-bg-red-100 hover:tw-text-red-700 tw-transition-all tw-duration-200"
                                        aria-label={t("removeItem", lang)}>
                                        <svg className="tw-w-3.5 tw-h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </button>
                                )}
                                value={rows[item.key]?.pf ?? ""}
                                onChange={(v) => setRows(prev => ({ ...prev, [item.key]: { ...(prev[item.key] ?? { remark: "" }), pf: v } }))}
                                remark={rows[item.key]?.remark ?? ""}
                                onRemarkChange={(v) => setRows(prev => ({ ...prev, [item.key]: { ...(prev[item.key] ?? { pf: "" }), remark: v } }))}
                                lang={lang}
                                pfButtonsId={pfButtonsId}
                                remarkId={remarkId}
                                aboveRemark={
                                    <>
                                        <div className="tw-pb-4 tw-border-b tw-border-gray-100">
                                            <PhotoMultiInput
                                                id={photoId}
                                                photos={photos[`${qNo}_${idx}`] || []}
                                                setPhotos={makePhotoSetter(`${qNo}_${idx}`)}
                                                max={Math.min(ITEM_MAX, Math.max(0, GROUP_MAX - (totalPhotosInGroup - (photos[`${qNo}_${idx}`]?.length ?? 0))))}
                                                draftKey={draftKey}
                                                qNo={qNo}
                                                lang={lang}
                                                maxLabel={subItemQuotaLabel(photos[`${qNo}_${idx}`]?.length ?? 0, totalPhotosInGroup, ITEM_MAX, GROUP_MAX, lang)}
                                            />
                                        </div>
                                        {checkboxElement && <div className="sm:tw-hidden tw-mb-3">{checkboxElement}</div>}
                                    </>
                                }
                                inlineLeft={checkboxElement && <div className="tw-hidden sm:tw-flex">{checkboxElement}</div>}
                                beforeRemark={
                                    renderAdditionalFields && (
                                        <div id={`pm-input-${qNo}-${subNo}`} className="tw-mb-3 tw-transition-all tw-duration-300">
                                            {renderAdditionalFields(item, idx, rows[item.key]?.pf === "NA")}
                                        </div>
                                    )
                                }
                            />
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

function PhotoRemarkSection({
    qKey, qNo, middleContent, photos, setPhotos, rows, setRows, draftKey, lang, showPfButtons = true
}: {
    qKey: string; qNo: number; middleContent?: React.ReactNode;
    photos: Record<number | string, PhotoItem[]>;
    setPhotos: React.Dispatch<React.SetStateAction<Record<number | string, PhotoItem[]>>>;
    rows: Record<string, { pf: PF; remark: string }>;
    setRows: React.Dispatch<React.SetStateAction<Record<string, { pf: PF; remark: string }>>>;
    draftKey: string; lang: Lang;
    // false = ข้อที่มีแค่รูป + หมายเหตุ (photoOnly)
    showPfButtons?: boolean;
}) {
    const makePhotoSetter = (no: number): React.Dispatch<React.SetStateAction<PhotoItem[]>> => (action) => {
        setPhotos((prev) => {
            const current = prev[no] || [];
            const next = typeof action === "function" ? (action as (x: PhotoItem[]) => PhotoItem[])(current) : action;
            return { ...prev, [no]: next };
        });
    };

    const photoId = `pm-photo-${qNo}`;
    const remarkId = `pm-remark-${qNo}`;
    const pfButtonsId = `pm-pf-${qNo}`;

    return (
        <div className="tw-py-2">
            <PassFailRow
                showPfButtons={showPfButtons}
                label={t("testResult", lang)}
                value={rows[qKey]?.pf ?? ""}
                onChange={(v) => setRows(prev => ({ ...prev, [qKey]: { ...(prev[qKey] ?? { remark: "" }), pf: v } }))}
                remark={rows[qKey]?.remark ?? ""}
                onRemarkChange={(v) => setRows(prev => ({ ...prev, [qKey]: { ...(prev[qKey] ?? { pf: "" }), remark: v } }))}
                lang={lang}
                pfButtonsId={pfButtonsId}
                aboveRemark={
                    <div className="tw-pt-2 tw-pb-4 tw-border-b tw-mb-4 tw-border-gray-100">
                        <PhotoMultiInput id={photoId} photos={photos[qNo] || []} setPhotos={makePhotoSetter(qNo)} max={MAX_PHOTOS_PER_ITEM} draftKey={draftKey} qNo={qNo} lang={lang} />
                    </div>
                }
                beforeRemark={middleContent && <div className="tw-mb-3">{middleContent}</div>}
                remarkId={remarkId}
            />
        </div>
    );
}

// ==================== MAIN COMPONENT ====================
export default function ChargerPMForm() {
    const { lang } = useLanguage();
    const [me, setMe] = useState<Me | null>(null);
    const router = useRouter();
    const [submitting, setSubmitting] = useState(false);
    const [pageLoading, setPageLoading] = useState(true);
    const [uploadProgress, setUploadProgress] = useState({
        show: false,
        total: 0,
        completed: 0,
        failed: 0,
    });
    const [docName, setDocName] = useState("");

    const searchParams = useSearchParams();
    const editId = searchParams.get("edit_id") ?? "";
    // เปิดจากใบ PM สถานี "ใบเดียว 5 ส่วน" → ส่วน Charger ของใบนั้น
    // มีค่า = ยืมเลขที่/ชื่อเอกสารของใบแม่ ไม่ออกเลขของตัวเอง
    const jobId = searchParams.get("job_id") ?? "";
    // เปิดจากใบ PM สถานี → หัวฟอร์มใช้เลขที่/ชื่อเอกสารของใบแม่ (ส่วนที่ยังไม่บันทึกไม่มีเลขในตัวเอง)
    const jobDocIds = useJobDocIds(jobId, searchParams.get("station_id"));

    const [photos, setPhotos] = useState<Record<string | number, PhotoItem[]>>({});
    // รูปเดิมของเอกสารที่โหลดมาใส่ฟอร์ม (หน้าดู / แก้ส่วนที่ส่งแล้ว) — ตอนบันทึกเทียบกับ photos
    // เพื่อรู้ว่าผู้ใช้กดลบรูปเดิมรูปไหนออก แล้วลบออกจากเอกสารจริง
    const serverPhotosRef = useRef<Record<string, ViewPhoto[]>>({});

    // ⚡ Fix: เก็บ report_id ที่ submit JSON สำเร็จแล้ว เพื่อไม่ให้ submit ซ้ำตอน retry upload
    const postReportIdRef = useRef<string | null>(null);

    const [cp, setCp] = useState<Record<string, { value: string; unit: UnitVoltage }>>({});
    const [summary, setSummary] = useState<string>("");
    const [sn, setSn] = useState<string | null>(null);
    const [summaryCheck, setSummaryCheck] = useState<PF>("");
    // เวลาทำงานจริงของช่าง (datetime-local) — ส่งเข้า Maximo ทาง IN09 ตอนปิดใบงาน

    const [workStart, setWorkStart] = useState<string>("");
    const [workFinish, setWorkFinish] = useState<string>("");
    // planner เปิดเอกสารที่ช่างส่งมาเพื่อตรวจก่อนอนุมัติ (?approve=1)
    const approveMode = searchParams.get("approve") === "1";
    // ช่างเปิดดูใบที่ตัวเองส่งไปแล้ว (?review=1) — เห็นหน้าเดียวกับ planner
    // แต่แก้อะไรไม่ได้ และไม่มีปุ่ม Reject/Approve
    const reviewMode = approveMode || searchParams.get("review") === "1";
    const reviewAction = usePmReviewAction();
    const cancelEditAction = usePmCancelEdit();

    // laborcode ฝั่ง Maximo ที่ช่างเลือกเอง — username ใน iMPS ใช้แทนกันไม่ได้
    const [laborOptions, setLaborOptions] = useState<{ laborcode: string; name: string; needs_name?: boolean }[]>([]);
    const [maximoLabor, setMaximoLabor] = useState<string[]>([]);
    const [maximoContractor, setMaximoContractor] = useState<string>("");

    useEffect(() => {
        let alive = true;
        (async () => {
            try {
                const res = await apiFetch(`${API_BASE}/cm-maximo/labor-codes`);
                if (!res.ok) return;
                const data = await res.json();
                if (alive && Array.isArray(data?.items)) setLaborOptions(data.items);
            } catch {
                // ดึงไม่ได้ = ไม่โชว์ตัวเลือก ไม่ต้องบล็อกการกรอกใบงาน
            }
        })();
        return () => { alive = false; };
    }, []);

    const toggleMaximoLabor = (code: string) =>
        setMaximoLabor(prev => prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]);

    // ติ๊กรหัสกลางของผู้รับเหมาไว้ = ต้องมีชื่อจริงกำกับ

    // รหัสที่ช่างเลือกไว้ต้องโชว์ได้เสมอ ถึงรายชื่อจาก Maximo จะโหลดไม่ขึ้น
    // (เน็ตหลุด / สิทธิ์ไม่ถึง) ไม่งั้นหน้าอนุมัติจะกลายเป็นว่าไม่ได้เลือกใครเลย
    const laborList = useMemo(() => {
        const have = new Set(laborOptions.map((o) => o.laborcode));
        const missing = maximoLabor.filter((c) => !have.has(c)).map((c) => ({ laborcode: c, name: c }));
        const all = missing.length ? [...laborOptions, ...missing] : laborOptions;
        // โหมดตรวจไม่ต้องเห็นรายชื่อทั้งกรม เอาเฉพาะคนที่ช่างเลือกลงใบงานนี้
        return reviewMode ? all.filter((o) => maximoLabor.includes(o.laborcode)) : all;
    }, [laborOptions, maximoLabor, reviewMode]);
    const contractorPicked = laborOptions.some((o) => o.needs_name && maximoLabor.includes(o.laborcode));
    const contractorMissing = contractorPicked && !maximoContractor.trim();

    // ใบที่มี edit_id ใช้ key เดิม (ไม่ให้ draft เก่าหาย)
    // ใบใหม่แยกตาม job_id กัน draft ของคนละงานบนตู้เดียวกันปนกัน
    const postKey = useMemo(
        () => editId
            ? `${draftKey(sn)}:${editId}:post`
            : `${draftKey(sn)}:${jobId ? `job-${jobId}` : "new"}:post`,
        [sn, editId, jobId],
    );
    // key ของ draft ที่กู้คืนเสร็จแล้ว — autosave ทำได้เฉพาะเมื่อ === postKey
    // ไม่งั้น state ว่างตอนเปิดหน้าจะเขียนทับ draft ที่เก็บไว้ก่อนได้กู้
    const [restoredKey, setRestoredKey] = useState<string | null>(null);
    const restoredKeyRef = useRef<string | null>(null);
    useEffect(() => { restoredKeyRef.current = restoredKey; }, [restoredKey]);
    const draftRestored = restoredKey === postKey;
    // ตั้งเป็น true หลังบันทึกสำเร็จและล้าง draft แล้ว
    const draftClearedRef = useRef(false);
    // ปุ่ม "ยกเลิกการแก้ไข" ที่หน้ารวมล้าง draft ของฟอร์มนี้ผ่านตัวนี้ (หน้ารวมไม่รู้สูตร key ของแต่ละฟอร์ม)
    useEffect(() => registerDraftDiscard(async () => {
        draftClearedRef.current = true; // กัน autosave ที่ค้างอยู่เขียนกลับมาตอนออกจากหน้า
        await clearDraftLocal(postKey);
    }), [postKey]);
    useEffect(() => { draftClearedRef.current = false; }, [postKey]);

    useEffect(() => {
        postReportIdRef.current = null;
    }, [editId]);


    // ⚡ Fix: ใช้ ref เก็บค่าล่าสุดของ photos เพื่อ cleanup ตอน unmount
    const photosRef = useRef(photos);
    useEffect(() => { photosRef.current = photos; }, [photos]);
    useEffect(() => {
        return () => {
            Object.values(photosRef.current).flat().forEach(p => {
                if (p.preview && p.preview.startsWith("blob:")) URL.revokeObjectURL(p.preview);
            });
        };
    }, []);


    useEffect(() => {
        if (typeof window === "undefined") return;
        const params = new URLSearchParams(window.location.search);
        if (params.has("draft_id")) {
            params.delete("draft_id");
            const url = `${window.location.pathname}?${params.toString()}`;
            window.history.replaceState({}, "", url);
        }
    }, []);


    const [inspector, setInspector] = useState<string>("");
    const [dustFilterChanged, setDustFilterChanged] = useState<Record<string, boolean>>({});
    const [postApiLoaded, setPostApiLoaded] = useState(false);

    const [job, setJob] = useState({
        issue_id: "", chargerNo: "", sn: "", model: "", power: "", brand: "", station_name: "", date: "", chargingCables: 1,
    });

    // Sync station name for GPS fallback
    useEffect(() => { if (job.station_name) _stationNameForGPS = job.station_name; }, [job.station_name]);
    // Pre-fetch GPS + ที่อยู่ตั้งแต่เปิดหน้า เพื่อให้รูปแรกไม่ต้องรอ
    useEffect(() => { void prefetchLocation(); }, []);

    const [rows, setRows] = useState<Record<string, { pf: PF; remark: string }>>(() => {
        const initial: Record<string, { pf: PF; remark: string }> = {};
        QUESTIONS.forEach((q) => {
            initial[q.key] = { pf: "", remark: "" };
            q.items?.forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
        });
        getFixedItemsQ8("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
        getFixedItemsQ11("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
        getFixedItemsQ18("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
        return initial;
    });

    const m16 = useMeasure<UnitVoltage>(VOLTAGE1_FIELDS, "V");

    const [q5Items, setQ5Items] = useState<{ key: string; label: string }[]>([{ key: "r5_1", label: getDynamicLabel.emergencyStop(1, lang) }]);
    const [q7Items, setQ7Items] = useState<{ key: string; label: string }[]>([{ key: "r7_1", label: getDynamicLabel.warningSign(1, lang) }]);

    useEffect(() => {
        setQ5Items(prev => prev.map((item, idx) => ({ ...item, label: getDynamicLabel.emergencyStop(idx + 1, lang) })));
        setQ7Items(prev => prev.map((item, idx) => ({ ...item, label: getDynamicLabel.warningSign(idx + 1, lang) })));
    }, [lang]);

    const addQ5Item = () => {
        if (q5Items.length < 66) {
            const newIndex = q5Items.length + 1;
            setQ5Items([...q5Items, { key: `r5_${newIndex}`, label: getDynamicLabel.emergencyStop(newIndex, lang) }]);
            setRows(prev => ({ ...prev, [`r5_${newIndex}`]: { pf: "", remark: "" } }));
        }
    };

    const removeItemPhotos = (
        prev: Record<string | number, PhotoItem[]>,
        qNo: number,
        index: number,
        totalOldCount: number
    ) => {
        const next = { ...prev };
        // Revoke blob ของ item ที่ถูกลบ
        const removedPhotos = next[`${qNo}_${index}`] || [];
        removedPhotos.forEach(p => {
            if (p.preview?.startsWith("blob:")) URL.revokeObjectURL(p.preview);
        });
        // เก็บ photos ของ surviving items ตาม old index
        const survivingOldIndices = Array.from(
            { length: totalOldCount }, (_, i) => i
        ).filter(i => i !== index);
        const survivingPhotos = survivingOldIndices.map(i => next[`${qNo}_${i}`] || []);
        // ลบ keys เก่าทั้งหมด
        for (let i = 0; i < totalOldCount; i++) {
            delete next[`${qNo}_${i}`];
        }
        // เขียน keys ใหม่
        survivingPhotos.forEach((photoList, idx) => {
            next[`${qNo}_${idx}`] = photoList;
        });
        return next;
    };

    const removeQ5Item = (index: number) => {
        if (q5Items.length > 1) {
            const oldItems = q5Items;
            const survivingItems = oldItems.filter((_, i) => i !== index);
            const newItems = survivingItems.map((_, idx) => ({
                key: `r5_${idx + 1}`,
                label: getDynamicLabel.emergencyStop(idx + 1, lang)
            }));
            setQ5Items(newItems);
            setRows(prev => {
                const next = { ...prev };
                const survivingData = survivingItems.map(
                    item => next[item.key] ?? { pf: "" as PF, remark: "" }
                );
                oldItems.forEach(item => { delete next[item.key]; });
                newItems.forEach((item, idx) => { next[item.key] = survivingData[idx]; });
                return next;
            });
            // ✅ ใช้ helper แทน — qNo=5 ชัดเจน ไม่ hardcode ผิด
            setPhotos(prev => removeItemPhotos(prev, 5, index, oldItems.length));
        }
    };

    const initQ5Items = (count: number) => {
        setQ5Items(Array.from({ length: count }, (_, idx) => ({ key: `r5_${idx + 1}`, label: getDynamicLabel.emergencyStop(idx + 1, lang) })));
    };

    const addQ7Item = () => {
        if (q7Items.length < 66) {
            const newIndex = q7Items.length + 1;
            setQ7Items([...q7Items, { key: `r7_${newIndex}`, label: getDynamicLabel.warningSign(newIndex, lang) }]);
            setRows(prev => ({ ...prev, [`r7_${newIndex}`]: { pf: "", remark: "" } }));
        }
    };
    const removeQ7Item = (index: number) => {
        if (q7Items.length > 1) {
            const oldItems = q7Items;
            const survivingItems = oldItems.filter((_, i) => i !== index);
            const newItems = survivingItems.map((_, idx) => ({
                key: `r7_${idx + 1}`,
                label: getDynamicLabel.warningSign(idx + 1, lang)
            }));
            setQ7Items(newItems);
            setRows(prev => {
                const next = { ...prev };
                const survivingData = survivingItems.map(
                    item => next[item.key] ?? { pf: "" as PF, remark: "" }
                );
                oldItems.forEach(item => { delete next[item.key]; });
                newItems.forEach((item, idx) => { next[item.key] = survivingData[idx]; });
                return next;
            });
            // ✅ ใช้ helper — qNo=7
            setPhotos(prev => removeItemPhotos(prev, 7, index, oldItems.length));
        }
    };
    const initQ7Items = (count: number) => {
        setQ7Items(Array.from({ length: count }, (_, idx) => ({ key: `r7_${idx + 1}`, label: getDynamicLabel.warningSign(idx + 1, lang) })));
    };

    const fixedItemsMap = useMemo(() => ({
        3: createFixedItems(3, job.chargingCables, lang),
        4: createFixedItems(4, job.chargingCables, lang),
        6: createFixedItems(6, job.chargingCables, lang),
        8: getFixedItemsQ8(lang),
        10: createFixedItems(10, job.chargingCables, lang),
        11: getFixedItemsQ11(lang),
        17: createFixedItems(17, job.chargingCables, lang),
        18: getFixedItemsQ18(lang),
    }), [job.chargingCables, lang]);

    useEffect(() => {
        setRows((prev) => {
            const next = { ...prev };
            let changed = false;
            [3, 4, 6, 10, 17].forEach((qNo) => {
                const items = fixedItemsMap[qNo as keyof typeof fixedItemsMap];
                if (items) {
                    items.forEach((item) => {
                        if (!next[item.key]) { next[item.key] = { pf: "", remark: "" }; changed = true; }
                    });
                }
            });
            getFixedItemsQ8(lang).forEach((item) => {
                if (!next[item.key]) { next[item.key] = { pf: "", remark: "" }; changed = true; }
            });
            getFixedItemsQ11(lang).forEach((item) => {
                if (!next[item.key]) { next[item.key] = { pf: "", remark: "" }; changed = true; }
            });
            getFixedItemsQ18(lang).forEach((item) => {
                if (!next[item.key]) { next[item.key] = { pf: "", remark: "" }; changed = true; }
            });
            return changed ? next : prev;
        });
    }, [fixedItemsMap, lang]);

    // Effects for loading data - abbreviated for file length
    useEffect(() => {
        if (!editId || !sn) return;
        setPostApiLoaded(false);
        // Reset ค่าที่กรอกไว้ เพื่อไม่ให้ค่าของใบก่อนหน้าติดมา
        m16.setState(initMeasureState(VOLTAGE1_FIELDS, "V"));
        setCp({});

        setRows(() => {
            const initial: Record<string, { pf: PF; remark: string }> = {};
            QUESTIONS.forEach((q) => {
                initial[q.key] = { pf: "", remark: "" };
                q.items?.forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
            });
            getFixedItemsQ8("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
            getFixedItemsQ11("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
            getFixedItemsQ18("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
            return initial;
        });

        (async () => {
            try {
                const data = await fetchReport(editId, sn);
                if (data.job) {
                    setJob(prev => ({ ...prev, ...data.job, station_name: data.job.station_name || prev.station_name, issue_id: data.issue_id ?? prev.issue_id, chargingCables: data.job.numberOfCables || data.job.chargingCables || prev.chargingCables || 1 }));
                }
                // เอกสารหลายใบเก็บ job.station_name เป็นค่าว่าง — เติมจากข้อมูลตู้ ไม่งั้นช่อง "สถานที่" ในหน้าดูว่าง
                if ((!data.job?.numberOfCables || !data.job?.station_name) && sn) {
                    getChargerInfoBySN(sn)
                        .then(st => {
                            setJob(prev => ({
                                ...prev,
                                station_name: prev.station_name || st.station_name || "",
                                ...(!data.job?.numberOfCables && st.numberOfCables ? { chargingCables: st.numberOfCables } : {}),
                            }));
                        })
                        .catch(() => { });
                }
                if (data.pm_date) setJob(prev => ({ ...prev, date: data.pm_date }));
                if (data.doc_name) setDocName(data.doc_name);
                if (data.inspector) setInspector(data.inspector);
                // สรุปผล/หมายเหตุเดิมอ่านจาก draft ในเครื่องอย่างเดียว คนที่ไม่ได้เป็นคนกรอก
                // (ผู้อนุมัติ) จึงเปิดมาเจอช่องว่าง ต้องดึงจากตัวเอกสารด้วย
                // ส่วนหนึ่งของใบ PM สถานี: เปิดแก้ส่วนที่ส่งแล้ว (เครื่องนี้ไม่มี draft) ก็ต้องได้ค่าเดิมจากเอกสาร
                if (reviewMode || jobId) {
                    // เวลาทำงาน/laborcode ก็เก็บอยู่ใน draft ของเครื่องช่างเหมือนกัน
                    // ผู้อนุมัติต้องอ่านจากตัวเอกสาร ไม่งั้นเห็นเป็นช่องว่าง
                    if (typeof data.work_start === "string") setWorkStart(data.work_start);
                    if (typeof data.work_finish === "string") setWorkFinish(data.work_finish);
                    if (Array.isArray(data.maximo_labor)) setMaximoLabor(data.maximo_labor);
                    if (typeof data.maximo_contractor === "string") setMaximoContractor(data.maximo_contractor);
                    if (typeof data.summary === "string") setSummary(data.summary);
                    if (data.summaryCheck) setSummaryCheck(data.summaryCheck as PF);
                    // หน้าดูใช้ฟอร์มเดียวกับตอนกรอก — รูป/ค่าที่วัดมาจากเอกสาร ไม่ใช่ draft ในเครื่อง
                    // กลุ่มรูปคือ "g" + photo key (ดูตอนอัปโหลด)
                    const fromServer = serverPhotosToForm(data.photos,
                        g => (g.startsWith("g") ? g.slice(1) : null), API_BASE);
                    serverPhotosRef.current = fromServer;
                    setPhotos(prev => ({ ...prev, ...fromServer }) as typeof prev);
                    if (data.measures?.m16) m16.setState(measureAsText(data.measures.m16));
                    if (data.measures?.cp) setCp(measureAsText(data.measures.cp));
                }
                if (data.rows) {
                    // จำนวนปุ่มหยุดฉุกเฉิน (ข้อ 5) / ป้ายเตือน (ข้อ 7) นับจากคำตอบที่บันทึกไว้
                    const q5Count = Object.keys(data.rows).filter(k => /^r5_\d+$/.test(k)).length;
                    const q7Count = Object.keys(data.rows).filter(k => /^r7_\d+$/.test(k)).length;
                    if (q5Count > 0) initQ5Items(q5Count);
                    if (q7Count > 0) initQ7Items(q7Count);
                    setRows((prev) => { const next = { ...prev }; Object.entries(data.rows).forEach(([k, v]) => { next[k] = v as { pf: PF; remark: string }; }); return next; });
                }
                setPostApiLoaded(true);
            } catch (err) { console.error("load report failed:", err); setPostApiLoaded(true); }
        })();
    }, [editId, sn]);

    useEffect(() => {
        if (postApiLoaded) setPageLoading(false);
    }, [postApiLoaded]);

    useEffect(() => {
        (async () => {
            try {
                const res = await apiFetch(`${API_BASE}/me`);
                if (!res.ok) return;
                const data: Me = await res.json();
                setMe(data);
                // หน้าดูข้อมูลต้องโชว์ผู้ตรวจที่บันทึกในเอกสาร ไม่ใช่คนที่เปิดดู
                if (!reviewMode) setInspector((prev) => prev || data.username || "");
            } catch (err) { console.error("fetch /me error:", err); }
        })();
    }, []);

    useEffect(() => {
        // อ่านจาก searchParams ของ next ไม่ใช่ window.location — สลับตู้ในส่วนที่ 5
        // ของใบ PM สถานีเป็นการเปลี่ยน query อย่างเดียว ไม่ได้ remount component
        const snParam = searchParams.get("sn") || localStorage.getItem("selected_sn");
        if (snParam) setSn(snParam);
        // ใบที่เปิดจาก edit_id ได้หัวเอกสารจากตัวเอกสารเองอยู่แล้ว
        // ใบใหม่ (ยังไม่มี edit_id) ต้องดึงข้อมูลตู้มาเติมหัวเอกสารเอง
        if (!snParam || editId) { setPageLoading(false); return; }
        getChargerInfoBySN(snParam)
            .then((st) => {
                setJob((prev) => ({
                    ...prev, chargerNo: st.chargerNo ?? prev.chargerNo, sn: st.SN ?? prev.sn,
                    model: st.model ?? prev.model, brand: st.brand ?? prev.brand,
                    power: st.power ?? prev.power, station_name: st.station_name ?? prev.station_name,
                    date: prev.date || new Date().toISOString().slice(0, 10),
                    chargingCables: st.numberOfCables || prev.chargingCables || 1,
                }));
                setPageLoading(false);
            })
            // .catch((err) => console.error("load charger info failed:", err));
            .catch((err) => { console.error("load charger info failed:", err); setPageLoading(false); });
    }, [editId, searchParams]);

    // === LOAD DRAFT ===
    useEffect(() => {
        // โหมดตรวจ/อนุมัติ = อ่านอย่างเดียว แสดงตามตัวเอกสาร ไม่ใช้/ไม่เขียน draft
        if (reviewMode) return;
        if (!sn) return;
        // ใบเดิม: รอข้อมูลจาก API ก่อน แล้วค่อยทับด้วย draft
        if (editId && !postApiLoaded) return;
        const key = postKey;
        const markRestored = () => { restoredKeyRef.current = key; setRestoredKey(key); };

        // ใบใหม่ที่สลับตู้ (เปลี่ยน query ไม่ remount) → ล้างค่าของตู้ก่อนหน้า
        // ไม่งั้นค่าที่ค้างจะถูก autosave ไปเป็น draft ของตู้ใหม่
        if (!editId && restoredKeyRef.current && restoredKeyRef.current !== key) {
            Object.values(photosRef.current).flat().forEach(p => {
                if (p.preview && p.preview.startsWith("blob:")) URL.revokeObjectURL(p.preview);
            });
            setPhotos({});
            setRows(() => {
                const initial: Record<string, { pf: PF; remark: string }> = {};
                QUESTIONS.forEach((q) => {
                    initial[q.key] = { pf: "", remark: "" };
                    q.items?.forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
                });
                getFixedItemsQ8("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
                getFixedItemsQ11("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
                getFixedItemsQ18("th").forEach((item) => { initial[item.key] = { pf: "", remark: "" }; });
                return initial;
            });
            setCp({});
            m16.setState(initMeasureState(VOLTAGE1_FIELDS, "V"));
            setSummary("");
            setSummaryCheck("");
            setWorkStart("");
            setWorkFinish("");
            setDustFilterChanged({});
            setMaximoLabor([]);
            setMaximoContractor("");
            initQ5Items(1);
            initQ7Items(1);
            postReportIdRef.current = null;
        }

        const draft = loadDraftLocal<any>(key);
        if (!draft) { markRestored(); return; }

        // โหลดข้อมูล rows (merge กับ data จาก API)
        if (draft.rows) {
            // จำนวนข้อ 5/7 ช่างเพิ่ม/ลบเองได้ → ใช้จำนวนที่บันทึกไว้ (ถ้ามี) ไม่งั้นนับจาก draft
            // แล้วตัดข้อย่อยที่ถูกลบไปแล้ว (ที่อาจค้างจาก API) ทิ้ง
            const countKeys = (re: RegExp) => Object.keys(draft.rows).filter(k => re.test(k)).length;
            const q5Count = typeof draft.q5Count === "number" && draft.q5Count > 0 ? draft.q5Count : countKeys(/^r5_\d+$/);
            const q7Count = typeof draft.q7Count === "number" && draft.q7Count > 0 ? draft.q7Count : countKeys(/^r7_\d+$/);
            if (q5Count > 0) initQ5Items(q5Count);
            if (q7Count > 0) initQ7Items(q7Count);
            setRows(prev => {
                const next = { ...prev, ...draft.rows };
                Object.keys(next).forEach((k) => {
                    const m = k.match(/^r([57])_(\d+)$/);
                    if (!m) return;
                    const count = m[1] === "5" ? q5Count : q7Count;
                    if (count > 0 && Number(m[2]) > count) delete next[k];
                });
                return next;
            });
        }

        // โหลด CP values
        if (draft.cp) {
            setCp(draft.cp);
        }

        // โหลด m16 (voltage measurements)
        if (draft.m16) {
            m16.setState(draft.m16);
        }

        // โหลด summary
        if (draft.summary) {
            setSummary(draft.summary);
        }

        // โหลดเวลาทำงาน + summaryCheck
        if (draft.workStart) setWorkStart(draft.workStart);
        if (draft.workFinish) setWorkFinish(draft.workFinish);
        if (draft.summaryCheck) {
            setSummaryCheck(draft.summaryCheck);
        }

        // โหลด dustFilterChanged
        if (draft.dustFilterChanged) {
            setDustFilterChanged(draft.dustFilterChanged);
        }

        // ช่างที่ลงเวลากับ Maximo
        if (Array.isArray(draft.maximoLabor)) setMaximoLabor(draft.maximoLabor);
        if (typeof draft.maximoContractor === "string") setMaximoContractor(draft.maximoContractor);

        // โหลด photos จาก IndexedDB ด้วย photoRefs
        // ต้องรอรูปโหลดเสร็จก่อนค่อยเปิด autosave ไม่งั้น photoRefs ว่างจะทับของเดิม
        if (draft.photoRefs && Object.keys(draft.photoRefs).length > 0) {
            let canceled = false;
            const cleanup = () => { canceled = true; };
            (async () => {
                const loadedPhotos: Record<string | number, PhotoItem[]> = {};
                for (const [photoKey, refs] of Object.entries(draft.photoRefs as Record<string, (PhotoRef | { isNA: true })[]>)) {
                    if (canceled) return;
                    if (!refs || refs.length === 0) continue;
                    const items: PhotoItem[] = [];
                    for (const ref of refs) {
                        if (canceled) return;
                        if ('isNA' in ref && ref.isNA) {
                            items.push({ id: `na-${photoKey}`, isNA: true });
                        } else if ('dbKey' in ref) {
                            const file = await getPhotoByDbKey(ref.dbKey);
                            if (!file || file.size === 0) {
                                console.warn("Photo missing/empty in IndexedDB:", ref.dbKey);
                                reportMissingDraftPhoto(lang);
                                continue;
                            }
                            if (file && !canceled) {
                                items.push({
                                    id: ref.id,
                                    file,
                                    preview: URL.createObjectURL(file),
                                    remark: ref.remark,
                                    ref: ref as PhotoRef,
                                    uploaded: (ref as any).uploaded === true,
                                });
                            }
                        }
                    }
                    if (items.length > 0) {
                        loadedPhotos[photoKey] = items;
                    }
                }
                if (!canceled) {
                    setPhotos(prev => mergeDraftPhotos(prev, loadedPhotos) as typeof prev);
                    markRestored();
                }
            })().catch((err) => {
                console.error("restore draft photos failed:", err);
                if (!canceled) markRestored();
            });
            return cleanup;
        }
        markRestored();
    }, [sn, postKey, editId, postApiLoaded, reviewMode]);

    // Validations
    const validPhotoKeysPost = useMemo(() => {
        const keys: { key: string | number; label: string }[] = [];
        // ข้อที่กด N/A ไม่ต้องแนบรูป
        const isNA = (k: string) => rows[k]?.pf === "NA";
        QUESTIONS.filter(q => q.hasPhoto).forEach((q) => {
            const displayNo = getDisplayedQuestionNo(q.no);
            if (q.kind === "power_source" && q.items) {
                q.items.forEach((item, idx) => {
                    if (isNA(item.key)) return;
                    keys.push({ key: `${q.no}_${idx}`, label: `${displayNo}.${idx + 1}` });
                });
            } else if (q.kind === "simple" || q.kind === "measure") {
                if (isNA(q.key)) return;
                keys.push({ key: q.no, label: `${displayNo}` });
            } else if (q.no === 5) {
                q5Items.forEach((item, idx) => { if (isNA(item.key)) return; keys.push({ key: `${q.no}_${idx}`, label: `${displayNo}.${idx + 1}` }); });
            } else if (q.no === 7) {
                q7Items.forEach((item, idx) => { if (isNA(item.key)) return; keys.push({ key: `${q.no}_${idx}`, label: `${displayNo}.${idx + 1}` }); });
            } else if ([3, 4, 6, 8, 10, 11, 17, 18].includes(q.no)) {
                const fixedItems = fixedItemsMap[q.no as keyof typeof fixedItemsMap];
                if (fixedItems) { fixedItems.forEach((item, idx) => { if (isNA(item.key)) return; keys.push({ key: `${q.no}_${idx}`, label: `${displayNo}.${idx + 1}` }); }); }
            }
        });
        return keys;
    }, [q5Items, q7Items, fixedItemsMap, rows]);

    const missingPhotoItemsPost = useMemo(() => validPhotoKeysPost.filter(({ key }) => (photos[key]?.length ?? 0) < 1).map(({ label }) => label).sort(compareDisplayedItemNos), [photos, validPhotoKeysPost]);

    const allPhotosAttachedPost = missingPhotoItemsPost.length === 0;

    const MEASURE_BY_NO: Record<number, ReturnType<typeof useMeasure<UnitVoltage>> | undefined> = { 16: m16 };

    // missingInputs now stores detailed info for each missing item
    // ค่าที่วัดได้ (แรงดัน / CP ฯลฯ) ไม่บังคับกรอกแล้ว — ช่างเว้นว่างได้ ส่วนรูป/ผลตรวจ/สรุปยังบังคับเหมือนเดิม
    const missingInputsDetailed: React.ComponentProps<typeof PMValidationCard>["missingInputsDetailed"] = [];

    const allRequiredInputsFilled = true;

    // Keep missingInputsTextLines for backward compatibility (used in button title)
    const missingInputsTextLines = useMemo(() => {
        const grouped: Record<number, string[]> = {};
        missingInputsDetailed.forEach(({ qNo, subNo, label }) => {
            if (!grouped[qNo]) grouped[qNo] = [];
            const displayLabel = subNo ? `${label} ${subNo}` : label;
            grouped[qNo].push(displayLabel);
        });
        return Object.entries(grouped).map(([no, arr]) => `${no}: ${arr.join(", ")}`);
    }, [missingInputsDetailed]);

    const PF_KEYS_POST = useMemo(() => {
        const keys: string[] = [];
        QUESTIONS.forEach((q) => {
            if (q.kind === "power_source" && q.items) { q.items.forEach((item) => keys.push(item.key)); return; }
            if (q.kind === "simple" || q.kind === "measure") { if (!q.photoOnly) keys.push(q.key); return; }
            if (q.no === 5) { q5Items.forEach((item) => keys.push(item.key)); }
            else if (q.no === 7) { q7Items.forEach((item) => keys.push(item.key)); }
            else if ([3, 4, 6, 8, 10, 11, 17, 18].includes(q.no)) {
                const fixedItems = fixedItemsMap[q.no as keyof typeof fixedItemsMap];
                if (fixedItems) { fixedItems.forEach((item) => keys.push(item.key)); }
            }
        });
        return keys;
    }, [q5Items, q7Items, fixedItemsMap]);

    const allPFAnsweredPost = useMemo(() => PF_KEYS_POST.every((k) => rows[k]?.pf !== ""), [rows, PF_KEYS_POST]);
    const missingPFItemsPost = useMemo(() => PF_KEYS_POST.filter((k) => !rows[k]?.pf).map(getDisplayedRowNo).sort(compareDisplayedItemNos), [rows, PF_KEYS_POST]);

    // ปุ่มย้อนกลับ: เปิดมาจากหน้า PM List ให้กลับไปหน้านั้นตรง ๆ
    // (router.back() ไม่แน่นอน เพราะประวัติของเบราว์เซอร์อาจไม่ได้มาจากหน้า List)
    const goBackToList = useCallback(() => {
        // กลับหน้าที่เปิดเข้ามา: หน้ารวมของใบ PM สถานี / PM List — นอกนั้นถอยประวัติ
        const back = pmFormReturnRoute(searchParams);
        if (back) router.push(back);
        else router.back();
    }, [router, searchParams]);

    const isSummaryFilled = summary.trim().length > 0;
    const isSummaryCheckFilled = summaryCheck !== "";
    const canFinalSave = allPhotosAttachedPost && allPFAnsweredPost && allRequiredInputsFilled && isSummaryFilled && isSummaryCheckFilled;

    const handleUnitChange = (no: number, _key: string, u: UnitVoltage) => {
        const m = MEASURE_BY_NO[no];
        if (!m) return;
        m.syncUnits(u);
    };

    const renderMeasureGrid = (no: number) => {
        const cfg = FIELD_GROUPS[no];
        const m = MEASURE_BY_NO[no];
        if (!cfg || !m) return null;
        return (
            <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-3 md:tw-grid-cols-5 tw-gap-3">
                {cfg.keys.map((k) => (
                    <InputWithUnit<UnitVoltage> key={`${no}-${k}`} label={(LABELS[k] ?? k) as string} value={m.state[k]?.value || ""} unit={(m.state[k]?.unit as UnitVoltage) || "V"} units={UNITS.voltage}
                        onValueChange={(v) => m.patch(k, { value: v })} onUnitChange={(u) => handleUnitChange(no, k, u)} lang={lang} />
                ))}
            </div>
        );
    };

    const renderQuestionBlock = (q: Question) => {
        const subtitle = FIELD_GROUPS[q.no]?.note;
        const fixedItems = fixedItemsMap[q.no as keyof typeof fixedItemsMap];
        const qTooltip = q.tooltip?.[lang];
        const sectionId = `pm-question-${q.no}`;

        if (q.kind === "power_source" && q.items) {
            return (
                <SectionCard key={q.key} id={sectionId} title={getQuestionLabel(q, lang)} subtitle={subtitle} tooltip={qTooltip}>
                    <div className="tw-divide-y tw-divide-gray-200">
                        {q.items.map((item, idx) => {
                            const photoKey = `${q.no}_${idx}`;
                            const subNo = idx + 1;
                            return (
                                <div key={item.key} className="tw-py-4 first:tw-pt-2">
                                    <PassFailRow
                                        label={item.label[lang]}
                                        value={rows[item.key]?.pf ?? ""}
                                        onChange={(v) => setRows(prev => ({ ...prev, [item.key]: { ...(prev[item.key] ?? { remark: "" }), pf: v } }))}
                                        remark={rows[item.key]?.remark ?? ""}
                                        onRemarkChange={(v) => setRows(prev => ({ ...prev, [item.key]: { ...(prev[item.key] ?? { pf: "" }), remark: v } }))}
                                        lang={lang}
                                        pfButtonsId={`pm-pf-${q.no}-${subNo}`}
                                        remarkId={`pm-remark-${q.no}-${subNo}`}
                                        aboveRemark={
                                            <div className="tw-pb-4 tw-border-b tw-border-gray-100">
                                                <PhotoMultiInput
                                                    id={`pm-photo-${q.no}-${subNo}`}
                                                    photos={photos[photoKey] || []}
                                                    setPhotos={(action) => setPhotos(prev => {
                                                        const current = prev[photoKey] || [];
                                                        const next = typeof action === "function" ? action(current) : action;
                                                        return { ...prev, [photoKey]: next };
                                                    })}
                                                    max={10}
                                                    draftKey={postKey}
                                                    qNo={q.no}
                                                    lang={lang}
                                                />
                                            </div>
                                        }
                                    />
                                </div>
                            );
                        })}
                    </div>
                </SectionCard>
            );
        }

        return (
            <SectionCard key={q.key} id={sectionId} title={getQuestionLabel(q, lang)} subtitle={subtitle} tooltip={qTooltip}>
                <div className="tw-space-y-4">
                    {q.hasPhoto && q.kind === "simple" && <PhotoRemarkSection qKey={q.key} qNo={q.no} showPfButtons={!q.photoOnly} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 16 && <PhotoRemarkSection qKey={q.key} qNo={q.no} middleContent={renderMeasureGrid(q.no)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 3 && fixedItems && <DynamicItemsSection qNo={3} items={fixedItems} editable={false} countLabel={t("cableCount", lang)} count={job.chargingCables} countUnit={t("cable", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 4 && fixedItems && <DynamicItemsSection qNo={4} items={fixedItems} editable={false} countLabel={t("connectorCount", lang)} count={job.chargingCables} countUnit={t("connector", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 5 && <DynamicItemsSection qNo={5} items={q5Items} addItem={addQ5Item} removeItem={removeQ5Item} addButtonLabel={t("addEmergencyStop", lang)} countLabel={t("emergencyStopCount", lang)} count={q5Items.length} countUnit={t("button", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 6 && fixedItems && <DynamicItemsSection qNo={6} items={fixedItems} editable={false} countLabel={t("qrCodeCount", lang)} count={job.chargingCables} countUnit={t("qrUnit", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 7 && <DynamicItemsSection qNo={7} items={q7Items} addItem={addQ7Item} removeItem={removeQ7Item} addButtonLabel={t("addWarningSign", lang)} countLabel={t("warningSignCount", lang)} count={q7Items.length} countUnit={t("sign", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 8 && fixedItems && <DynamicItemsSection qNo={8} items={fixedItems} editable={false} countLabel={t("ventilationSignCount", lang)} count={2} countUnit={t("sign", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 10 && fixedItems && (
                        <DynamicItemsSection qNo={10} items={fixedItems} editable={false} countLabel={t("cpVoltageCount", lang)} count={job.chargingCables} countUnit={t("cable", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang}
                            renderAdditionalFields={(item, idx, isNA) => (
                                <div className="tw-max-w-xs">
                                    <InputWithUnit<UnitVoltage> label="CP" value={cp[item.key]?.value ?? ""} unit={cp[item.key]?.unit ?? "V"} units={["V"] as const}
                                        onValueChange={(v) => setCp((s) => ({ ...s, [item.key]: { ...(s[item.key] ?? { unit: "V" }), value: v } }))}
                                        onUnitChange={(u) => setCp((s) => ({ ...s, [item.key]: { ...(s[item.key] ?? { value: "" }), unit: u } }))} disabled={isNA} lang={lang} />
                                </div>
                            )} />
                    )}
                    {q.no === 11 && fixedItems && <DynamicItemsSection qNo={11} items={fixedItems} editable={false} countLabel={t("airFilterCount", lang)} count={5} countUnit={t("filter", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} showDustFilterCheckbox dustFilterChanged={dustFilterChanged} setDustFilterChanged={setDustFilterChanged} />}
                    {q.no === 17 && fixedItems && <DynamicItemsSection qNo={17} items={fixedItems} editable={false} countLabel={t("chargingTestCount", lang)} count={job.chargingCables} countUnit={t("cable", lang)} photos={photos} setPhotos={setPhotos} rows={rows} setRows={setRows} draftKey={postKey} lang={lang} />}
                    {q.no === 18 && fixedItems && (
                        <DynamicItemsSection
                            qNo={18}
                            items={fixedItems}
                            editable={false}
                            countLabel={t("cleaningCount", lang)}
                            count={3}
                            countUnit={t("items", lang)}
                            photos={photos}
                            setPhotos={setPhotos}
                            rows={rows}
                            setRows={setRows}
                            draftKey={postKey}
                            lang={lang}
                        />
                    )}
                </div>
            </SectionCard>
        );
    };

    const photoRefs = useMemo(() => {
        const out: Record<string, (PhotoRef | { isNA: true })[]> = {};
        Object.entries(photos).forEach(([key, list]) => {
            out[key] = (list || [])
                .map(p => {
                    if (p.isNA) return { isNA: true } as const;
                    if (!p.ref) return null;
                    // ⚡ เก็บ uploaded ไปพร้อม ref
                    return { ...p.ref, uploaded: p.uploaded === true } as PhotoRef & { uploaded: boolean };
                })
                .filter(Boolean) as (PhotoRef | { isNA: true })[];
        });
        return out;
    }, [photos]);

    // autosave draft ทั้งใบใหม่และใบเดิม — ห้ามเซฟก่อนกู้ draft เสร็จ (draftRestored)
    // merge กับ draft เดิมเพื่อไม่ให้ pendingReportId ที่ได้ตอนบันทึกหาย
    useDebouncedEffect(() => {
        if (!sn || reviewMode || !draftRestored || draftClearedRef.current) return;
        saveDraftLocal(postKey, {
            ...loadDraftLocal(postKey),
            rows, cp, m16: m16.state, summary, summaryCheck, workStart, workFinish, dustFilterChanged, photoRefs,
            maximoLabor, maximoContractor, q5Count: q5Items.length, q7Count: q7Items.length,
        } as any);
    }, [postKey, sn, reviewMode, draftRestored, rows, cp, m16.state, summary, summaryCheck, workStart, workFinish, dustFilterChanged, photoRefs, maximoLabor, maximoContractor, q5Items.length, q7Items.length]);



    // ⚡ FIX 413: ส่งทีละรูป (sequential) แทนรวมทั้งกลุ่ม → ไม่เกิน nginx body limit
    async function uploadSinglePhoto(reportId: string, sn: string, group: string, file: File) {
        if (!file || file.size === 0) {
            throw new Error(`Empty file: ${file?.name ?? 'unknown'} (size=0)`);
        }
        const form = new FormData();
        form.append("sn", sn);
        form.append("group", group);
        form.append("side", "post");
        form.append("files", file, ensureJpgFilename(file.name));

        const url = `${API_BASE}/pmreport/${reportId}/post/photos`;

        // ✅ ใช้ apiFetch แทน fetch ตรง
        const res = await apiFetch(url, {
            method: "POST",
            body: form,
        });

        if (!res.ok) {
            const errText = await res.text().catch(() => "");
            throw new Error(`[${res.status}] ${group}: ${errText || res.statusText}`);
        }

        const resJson = await res.json().catch(() => null);
        // group_full = ข้อนี้มีรูปครบ 10 รูปฝั่ง server แล้ว → ถือว่าสำเร็จ ไม่ใช่ error (กัน retry วน + ขึ้น "อัปโหลดไม่สำเร็จ" ทั้งที่รูปครบ)
        if (resJson?.skipped === "group_full") return;
        if (!resJson || resJson.count === 0) {
            throw new Error(`[upload empty] group ${group}: backend saved 0 files`);
        }
    }


    // ⚡ Retry ระดับรูปเดียว — ไม่ re-upload รูปที่สำเร็จแล้ว
    async function uploadSinglePhotoWithRetry(reportId: string, sn: string, group: string, file: File, maxRetries = 3): Promise<void> {
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                await uploadSinglePhoto(reportId, sn, group, file);
                return;
            } catch (err: any) {
                console.warn(`[upload retry] ${group} file "${file.name}" attempt ${attempt}/${maxRetries} failed:`, err?.message);
                if (attempt === maxRetries) throw err;
                const delay = Math.min(1000 * Math.pow(2, attempt - 1), 8000);
                await new Promise(r => setTimeout(r, delay));
            }
        }
    }


    const onFinalSave = async () => {
        if (!sn) { alert(t("alertNoSN", lang)); return; }
        if (!allPhotosAttachedPost) { alert(t("alertPhotoNotComplete", lang)); return; }
        if (!allRequiredInputsFilled) { alert(t("alertFillRequired", lang)); return; }
        if (!isSummaryFilled || !isSummaryCheckFilled) { alert(t("alertCompleteAll", lang)); return; }
        // เวลาทำงานต้องครบ — backend ก็กันไว้อีกชั้น เพราะ IN09 ต้องใช้
        if (!jobId && (!workStart || !workFinish)) { alert(t("alertWorkTime", lang)); return; }
        if (!jobId && contractorMissing) { alert(t("contractorRequired", lang)); return; }
        if (!jobId && workFinish < workStart) { alert(t("alertWorkTimeOrder", lang)); return; }
        // Maximo ตีกลับ IN09 ด้วย BMXAA2641E ถ้าเวลาทำงานยังมาไม่ถึง
        // ปล่อยผ่านตรงนี้ = ปิดใบงานได้แต่ปิด WO ในระบบเขาไม่ได้ ต้องมาแก้ย้อนหลัง
        const nowLocal = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
            .toISOString().slice(0, 16);
        if (!jobId && (workStart > nowLocal || workFinish > nowLocal)) { alert(t("alertWorkTimeFuture", lang)); return; }
        if (submitting) return;
        setSubmitting(true);
        try {

            // ⚡ ตรวจสอบ report_id: ref > draft > submit ใหม่
            let report_id = postReportIdRef.current;
            if (!report_id) {
                const draft = loadDraftLocal(postKey);
                if (draft?.pendingReportId) {
                    report_id = draft.pendingReportId;
                    postReportIdRef.current = report_id;
                }
            }
            if (!report_id) {
                const payload = { sn: sn, ...(jobId ? { job_id: jobId } : {}), inspector, job: { station_name: job.station_name, date: job.date }, ...(job.date ? { pm_date: job.date } : {}), rows, measures: { m16: m16.state, cp }, summary, ...(summaryCheck ? { summaryCheck } : {}), ...(jobId ? {} : { work_start: workStart, work_finish: workFinish, maximo_labor: maximoLabor, maximo_contractor: contractorPicked ? maximoContractor.trim() : "" }), wonum: searchParams.get("wonum") ?? "", dust_filter: dustFilterChanged, side: "post" as const, report_id: editId };
                const submitRes = await apiFetch(`${API_BASE}/pmreport/submit`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
                if (!submitRes.ok) throw new Error(await submitRes.text());
                const jsonRes = await submitRes.json() as { report_id: string };
                report_id = jsonRes.report_id;
                postReportIdRef.current = report_id;
                // ⚡ บันทึก report_id ลง draft เผื่อ user refresh หน้า
                saveDraftLocal(postKey, { ...loadDraftLocal(postKey), pendingReportId: report_id, rows, cp, m16: m16.state, summary, summaryCheck, workStart, workFinish, dustFilterChanged, photoRefs });
            }

            const uploadedIdsPost = new Set<string>();

            const flushPostDraft = () => {
                const latestPhotoRefs: Record<string, any> = {};
                Object.entries(photosRef.current).forEach(([k, list]) => {
                    latestPhotoRefs[k] = (list || []).map(p => {
                        if (p.isNA) return { isNA: true };
                        if (!p.ref) return null;
                        return { ...p.ref, uploaded: p.uploaded === true || uploadedIdsPost.has(p.id) };
                    }).filter(Boolean);
                });
                saveDraftLocal(postKey, { ...loadDraftLocal(postKey), pendingReportId: report_id, rows, cp, m16: m16.state, summary, summaryCheck, workStart, workFinish, dustFilterChanged, photoRefs: latestPhotoRefs });
            };

            // แก้ส่วนที่ส่งแล้ว: รูปเดิมที่กดลบออก ลบออกจากเอกสารจริงก่อน แล้วค่อยอัปรูปใหม่
            if (jobId) {
                await deleteRemovedServerPhotos(apiFetch, {
                    jobId, stationId: searchParams.get("station_id") ?? "", section: "charger", sn, reportId: report_id,
                    original: serverPhotosRef.current, current: photosRef.current as any,
                });
                serverPhotosRef.current = {};
            }
            // ⚡ อัปโหลดหลายรอบ — รูปที่มาถึงหลังกดบันทึกต้องถูกจับเข้ารอบถัดไป ไม่ใช่ถูกข้ามแล้วโดนลบ
            const MAX_UPLOAD_PASSES = 3;
            for (let pass = 1; pass <= MAX_UPLOAD_PASSES; pass++) {
                if (unrecoverablePhotos(photosRef.current, uploadedIdsPost).length > 0) {
                    throw new Error(unrecoverableMessage(lang));
                }

                const allPostTasks = collectPending(photosRef.current, uploadedIdsPost);
                if (allPostTasks.length === 0) break;

                const totalPhotos = allPostTasks.length;
                setUploadProgress({ show: true, total: totalPhotos, completed: 0, failed: 0 });
                let completedCount = 0;
                let failedCount = 0;
                const failures: { group: string; error: string }[] = [];

                const CONCURRENCY = 3;
                const finalReportId = report_id!;

                const tasksByGroup = new Map<string, typeof allPostTasks>();
                for (const task of allPostTasks) {
                    if (!tasksByGroup.has(task.group)) tasksByGroup.set(task.group, []);
                    tasksByGroup.get(task.group)!.push(task);
                }

                const groupEntries = Array.from(tasksByGroup.entries());
                let groupIdx = 0;

                const runNextGroup = async (): Promise<void> => {
                    while (groupIdx < groupEntries.length) {
                        const myIdx = groupIdx++;
                        const [group, tasks] = groupEntries[myIdx];
                        for (const task of tasks) {
                            try {
                                const usable = await resolveUploadFile(task);
                                const compressed = await compressImage(usable);
                                await uploadSinglePhotoWithRetry(finalReportId, sn, `g${group}`, compressed);
                                uploadedIdsPost.add(task.photoId);
                                setPhotos(prev => ({
                                    ...prev,
                                    [group]: (prev[group] || []).map(p =>
                                        p.id === task.photoId ? { ...p, uploaded: true } : p
                                    ),
                                }));
                            } catch (err: any) {
                                failedCount++;
                                failures.push({ group, error: err?.message || "unknown" });
                            }
                            completedCount++;
                            setUploadProgress({ show: true, total: totalPhotos, completed: completedCount, failed: failedCount });
                        }
                    }
                };

                await Promise.all(Array.from({ length: CONCURRENCY }, () => runNextGroup()));

                setUploadProgress({ show: false, total: 0, completed: 0, failed: 0 });

                if (failures.length > 0) {
                    flushPostDraft();
                    const groupNums = failures.map(f => f.group).join(", ");
                    const details = failures.map(f => `${t("uploadFailedItem", lang)} ${f.group}: ${f.error}`).join("\n");
                    console.error("[Post-PM upload failures]", failures);
                    alert(
                        `${lang === "th" ? "อัปโหลดรูปไม่สำเร็จในข้อ" : "Photo upload failed for group"}: ${groupNums}\n\n${lang === "th" ? "รูปในเครื่องยังอยู่ครบ กดบันทึกอีกครั้งเพื่ออัปเฉพาะรูปที่ค้าง" : "Your photos are still saved on this device. Click save again to retry only the failed photos"}\n\n${details}`
                    );
                    return;
                }
            }

            // ยังมีรูปค้างหลังครบทุกรอบ → หยุดไว้ ห้ามลบ ห้าม finalize
            const stillPendingPost = collectPending(photosRef.current, uploadedIdsPost);
            if (stillPendingPost.length > 0) {
                flushPostDraft();
                alert(pendingMessage(stillPendingPost.length, lang));
                return;
            }

            // ⚡ ยืนยันจำนวนรูป Post-PM กับ server ก่อน finalize + ล้าง draft
            const expectedPost = expectedCountByGroup(photosRef.current, k => `g${k}`);
            if (Object.keys(expectedPost).length > 0) {
                const verifyRes = await apiFetch(`${API_BASE}/pmreport/get?sn=${encodeURIComponent(sn)}&report_id=${report_id}`);
                if (!verifyRes.ok) throw new Error(await verifyRes.text());
                const verifyDoc = await verifyRes.json() as { photos?: Record<string, unknown[]> };
                const shortfall = findShortfall(expectedPost, verifyDoc?.photos);
                if (shortfall.length > 0) {
                    console.error("[Post-PM verify] shortfall:", shortfall);
                    flushPostDraft();
                    alert(shortfallMessage(shortfall, lang));
                    return;
                }
            }

            const finalizeRes = await apiFetch(`${API_BASE}/pmreport/${report_id}/finalize`, { method: "POST", body: new URLSearchParams({ sn: sn }) });
            if (!finalizeRes.ok) throw new Error(await finalizeRes.text());
            postReportIdRef.current = null; // ⚡ สำเร็จแล้ว → reset
            const allPhotos = Object.values(photosRef.current).flat();
            Promise.all(allPhotos.map(p => delPhoto(postKey, p.id))).catch(() => { });
            draftClearedRef.current = true; // กัน autosave ที่ค้างอยู่เขียน draft กลับมาหลังล้าง
            clearDraftLocal(postKey);
            // กลับหน้าที่เปิดเข้ามา — ส่วนที่ 5 ของใบ PM สถานีกลับหน้ารวมของใบนั้น (ช่างมักกรอกตู้ถัดไปต่อ)
            // เปิดจาก PM List กลับ PM List — ไม่มีทั้งคู่ก็ไปตารางของตู้
            router.replace(pmFormReturnRoute(searchParams) ?? `/dashboard/pm-report?sn=${encodeURIComponent(sn)}`);
        } catch (err: any) { alert(`${t("alertSaveFailed", lang)} ${err?.message ?? err}`); } finally { setSubmitting(false); }
    };



    // กล่องหมายเหตุ + สรุปผลการตรวจสอบ — ประกาศครั้งเดียว วางได้สองที่
    // ตอนกรอกอยู่ในฟอร์มตามเดิม ตอนตรวจย้ายลงไปล่างสุดใต้ตารางผลการตรวจ
    const summaryBlock = (
                        <div id="pm-summary-section" className="tw-mt-6 sm:tw-mt-8 tw-space-y-3 tw-transition-all tw-duration-300">
                            <Typography variant="h6" className="tw-mb-1 tw-text-sm sm:tw-text-base">{t("comment", lang)}</Typography>

                                <>
                                    <Textarea
                                        label={t("comment", lang)}
                                        value={summary}
                                        onChange={(e) => setSummary(e.target.value)}
                                        rows={3}
                                        required
                                        autoComplete="off"
                                        containerProps={{ className: "!tw-min-w-0" }}
                                        className="!tw-w-full !tw-text-sm resize-none"
                                    />
                                    {/* Temporarily disabled: Maximo labor input is hidden on all pages. */}
                                    {false && <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-200">
                                        <PassFailRow
                                            label={t("summaryResult", lang)}
                                            value={summaryCheck}
                                            onChange={(v) => setSummaryCheck(v)}
                                            labels={{ PASS: t("summaryPass", lang), FAIL: t("summaryFail", lang), NA: t("summaryNA", lang) }}
                                            lang={lang}
                                        />
                                    </div>}

                                    {/* ใบที่เป็นส่วนหนึ่งของใบ PM สถานี: เวลาทำงาน/ช่างที่ลงเวลา Maximo กรอกครั้งเดียวตอนกด
                                        "ปิดใบงาน" ที่หน้ารวมของใบ — ไม่ต้องกรอกซ้ำทุกส่วน (ใบเดี่ยวรุ่นเก่ายังกรอกที่นี่) */}
                                    {!jobId && (<>
                                    {/* เวลาทำงานจริงของช่าง — ต้องกรอกก่อนส่งปิดใบงาน (ส่งเข้า Maximo IN09) */}
                                    <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-200">
                                        <div className="tw-mb-2">
                                            <Typography variant="h6" className="tw-text-sm sm:tw-text-base">
                                                {t("workTime", lang)} <span className="tw-text-red-500">*</span>
                                            </Typography>
                                            <Typography variant="small" className="tw-text-xs tw-font-normal tw-text-blue-gray-400">
                                                {t("workTimeHint", lang)}
                                            </Typography>
                                        </div>
                                        <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-3">
                                            <div>
                                                <label className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">
                                                    {t("workStart", lang)}
                                                </label>
                                                <input
                                                    type="datetime-local"
                                                    value={workStart}
                                                    onChange={(e) => setWorkStart(e.target.value)}
                                                    className="tw-w-full tw-rounded-lg tw-border tw-border-blue-gray-200 tw-bg-white tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none focus:tw-border-blue-500"
                                                />
                                            </div>
                                            <div>
                                                <label className="tw-mb-1.5 tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">
                                                    {t("workFinish", lang)}
                                                </label>
                                                {/* min กัน picker เลือกย้อนหลัง — ยังต้อง validate เพราะพิมพ์มือเลี่ยงได้ */}
                                                <input
                                                    type="datetime-local"
                                                    value={workFinish}
                                                    min={workStart || undefined}
                                                    onChange={(e) => setWorkFinish(e.target.value)}
                                                    className={`tw-w-full tw-rounded-lg tw-border tw-bg-white tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none ${workStart && workFinish && workFinish < workStart
                                                        ? "tw-border-red-400 focus:tw-border-red-500"
                                                        : "tw-border-blue-gray-200 focus:tw-border-blue-500"}`}
                                                />
                                                {workStart && workFinish && workFinish < workStart && (
                                                    <p className="tw-mt-1.5 tw-text-xs tw-text-red-600">{t("alertWorkTimeOrder", lang)}</p>
                                                )}
                                            </div>
                                        </div>
                                    </div>

                                    {/* ช่างที่จะลงเวลาเข้า Maximo — laborcode คนละชุดกับ username ใน iMPS
                                        จึงต้องให้เลือกเอง ไม่งั้น IN09 จะ unmapped ทั้งใบ (ล่างสุดของฟอร์ม) */}
                                    <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-200">
                                        <div className="tw-mb-2">
                                            <Typography variant="h6" className="tw-text-sm sm:tw-text-base">{t("maximoLabor", lang)}</Typography>
                                            <Typography variant="small" className="tw-text-xs tw-font-normal tw-text-blue-gray-400">{t("maximoLaborHint", lang)}</Typography>
                                        </div>
                                        {laborList.length === 0 ? (
                                            <p className="tw-text-xs tw-text-orange-600">
                                                {reviewMode ? t("maximoLaborNone", lang) : t("maximoLaborEmpty", lang)}
                                            </p>
                                        ) : (
                                            <div className="tw-rounded-lg tw-border tw-border-blue-gray-200 tw-bg-white tw-divide-y tw-divide-blue-gray-50 tw-max-h-56 tw-overflow-y-auto">
                                                {laborList.map((o) => (
                                                    <label key={o.laborcode} className="tw-flex tw-items-center tw-gap-2.5 tw-px-3 tw-py-2.5 tw-cursor-pointer hover:tw-bg-blue-gray-50/60 tw-transition-colors">
                                                        {!reviewMode && (<input type="checkbox" checked={maximoLabor.includes(o.laborcode)}
                                                            onChange={() => toggleMaximoLabor(o.laborcode)}
                                                            className="tw-h-4 tw-w-4 tw-shrink-0 tw-rounded tw-border-blue-gray-300 tw-text-blue-600 focus:tw-ring-blue-500 tw-cursor-pointer" />)}
                                                        <span className="tw-min-w-0 tw-truncate tw-text-sm tw-text-blue-gray-800">{o.name}</span>
                                                        <span className="tw-ml-auto tw-font-mono tw-text-xs tw-text-blue-gray-400">{o.laborcode}</span>
                                                    </label>
                                                ))}
                                            </div>
                                        )}
                                        {(contractorPicked || (reviewMode && !!maximoContractor.trim())) && (
                                            <div className="tw-mt-3 tw-space-y-1.5">
                                                <label className="tw-block tw-text-xs tw-font-semibold tw-text-blue-gray-700">
                                                    {t("contractorName", lang)} <span className="tw-text-red-500">*</span>
                                                </label>
                                                <input type="text" value={maximoContractor} onChange={(e) => setMaximoContractor(e.target.value)}
                                                    placeholder={t("contractorPlaceholder", lang)}
                                                    className={`tw-w-full tw-rounded-lg tw-border tw-px-3 tw-py-2.5 tw-text-sm tw-text-blue-gray-800 focus:tw-outline-none ${contractorMissing ? "tw-border-red-400 focus:tw-border-red-500" : "tw-border-blue-gray-200 focus:tw-border-blue-500"}`} />
                                                {contractorMissing && <p className="tw-text-xs tw-text-red-600">{t("contractorRequired", lang)}</p>}
                                            </div>
                                        )}
                                    </div>
                                    </>)}
                                </>
                        </div>
    );

    return (
        <section className="tw-pb-24">
            <LoadingOverlay show={pageLoading} text={t("loading", lang)} />
            {/* Upload Progress Overlay */}
            <LoadingOverlay
                show={uploadProgress.show}
                text={lang === "th"
                    ? `กำลังอัปโหลดรูป Post-PM... ${uploadProgress.completed}/${uploadProgress.total} รูป`
                    : `Uploading Post-PM photos... ${uploadProgress.completed}/${uploadProgress.total}`}
            />
            <div className="tw-mx-auto tw-max-w-6xl tw-flex tw-items-center tw-justify-between tw-mb-4">
                <Button variant="outlined" size="sm" onClick={goBackToList} title={t("backToList", lang)}>
                    <ArrowLeftIcon className="tw-w-4 tw-h-4 tw-stroke-blue-gray-900 tw-stroke-2" />
                </Button>
            </div>

            
            <form action="#" noValidate onSubmit={(e) => { e.preventDefault(); return false; }} onKeyDown={(e) => { if (e.key === "Enter") e.preventDefault(); }}>
                <div className="tw-mx-auto tw-max-w-6xl tw-bg-white tw-border tw-border-blue-gray-100 tw-rounded-xl tw-shadow-sm tw-p-6 md:tw-p-8 tw-print:tw-shadow-none tw-print:tw-border-0">
                {/* ดูอย่างเดียว: fieldset ปิดช่องกรอกทั้งหมด — แถวปุ่มบันทึก/แก้ไขอยู่นอก fieldset ปุ่มแก้ไขจะได้กดได้ */}
                <fieldset disabled={reviewMode} className="pm-readonly tw-m-0 tw-min-w-0 tw-border-0 tw-p-0">
                    <div className="tw-flex tw-flex-col tw-gap-4 md:tw-flex-row md:tw-items-start md:tw-justify-between md:tw-gap-6">
                        <div className="tw-flex tw-items-start tw-gap-3 md:tw-gap-4">
                            <div className="tw-relative tw-overflow-hidden tw-bg-white tw-rounded-md tw-shrink-0 tw-h-14 tw-w-[64px] sm:tw-h-16 sm:tw-w-[76px] md:tw-h-20 md:tw-w-[108px] lg:tw-h-24 lg:tw-w-[152px]">
                                <Image src={LOGO_SRC} alt={t("logoAlt", lang)} fill priority className="tw-object-contain tw-p-0" sizes="(min-width:1024px) 152px, (min-width:768px) 108px, (min-width:640px) 76px, 64px" />
                            </div>
                            <div className="tw-min-w-0">
                                <div className="tw-font-semibold tw-text-blue-gray-900 tw-text-sm sm:tw-text-base">{t("pageTitle", lang)}</div>
                                <div className="tw-text-xs sm:tw-text-sm tw-text-blue-gray-600">
                                    {t("companyName", lang)}<br />
                                    <span className="tw-hidden sm:tw-inline">{t("companyAddress", lang)}<br /></span>
                                    <span className="sm:tw-hidden">{t("companyAddressShort", lang)}<br /></span>
                                    {t("callCenter", lang)}
                                </div>
                            </div>
                        </div>
                        <div className="tw-text-left md:tw-text-right tw-text-sm tw-text-blue-gray-700 tw-border-t tw-border-blue-gray-100 tw-pt-3 md:tw-border-t-0 md:tw-pt-0 md:tw-shrink-0">
                            <div className="tw-font-semibold">{t("docName", lang)}</div>
                            <div className="tw-break-all">{jobDocIds?.doc_name || docName || "-"}</div>
                        </div>
                    </div>

                    <div className="tw-mt-8 tw-space-y-8">
                        <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-8 tw-gap-4">
                            <div className="lg:tw-col-span-2"><Input label={t("issueId", lang)} value={jobDocIds?.issue_id || job.issue_id || "-"} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-w-full !tw-bg-blue-gray-50" /></div>
                            <div className="sm:tw-col-span-2 lg:tw-col-span-2"><Input label={t("location", lang)} value={job.station_name} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                            <div className="lg:tw-col-span-2"><Input label={t("pmDate", lang)} type="text" value={job.date} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                            <div className="lg:tw-col-span-2"><Input label={t("inspector", lang)} value={inspector} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                            <div className="lg:tw-col-span-2"><Input label={t("brand", lang)} value={job.brand} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                            <div className="lg:tw-col-span-2"><Input label={t("model", lang)} value={job.model} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                            <div className="lg:tw-col-span-2"><Input label={t("power", lang)} value={job.power} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                            <div className="lg:tw-col-span-2"><Input label={t("serialNumber", lang)} value={job.sn} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                        </div>
                        <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-2 lg:tw-grid-cols-6 tw-gap-4">
                            <div className="sm:tw-col-span-2 lg:tw-col-span-3"><Input label={t("chargerNo", lang)} value={job.chargerNo} readOnly crossOrigin="" containerProps={{ className: "!tw-min-w-0" }} className="!tw-bg-blue-gray-50" /></div>
                        </div>
                    </div>

                    <div className="tw-mt-6 sm:tw-mt-8 tw-space-y-4 sm:tw-space-y-6">
                        {/* หน้าดูใช้ฟอร์มเดียวกับตอนกรอก — fieldset ล็อกไม่ให้แก้ */}
                        <fieldset disabled={reviewMode} className="pm-readonly tw-m-0 tw-min-w-0 tw-border-0 tw-p-0 tw-space-y-4 sm:tw-space-y-6">{QUESTIONS.map((q) => renderQuestionBlock(q))}</fieldset>
                    </div>

                    {summaryBlock}

                    <div className="tw-mt-6 sm:tw-mt-8 tw-flex tw-flex-col tw-gap-3">
                        {/* โหมดตรวจไม่ต้องมี ฟอร์มฝั่งช่างดักความครบถ้วนไว้ตั้งแต่ตอนกรอกแล้ว */}
                        {!reviewMode && (
                            <PMValidationCard
                                lang={lang}
                                allPhotosAttached={allPhotosAttachedPost}
                                missingPhotoItems={missingPhotoItemsPost}
                                allRequiredInputsFilled={allRequiredInputsFilled}
                                missingInputsDetailed={missingInputsDetailed}
                                allPFAnsweredPost={allPFAnsweredPost}
                                missingPFItemsPost={missingPFItemsPost}
                                isSummaryFilled={isSummaryFilled}
                                isSummaryCheckFilled={isSummaryCheckFilled}
                            />
                        )}
                    </div>
                </fieldset>
                    {/* หน้าดูข้อมูล: ปุ่มแก้ไข (ถ้ามีสิทธิ์) อยู่ตำแหน่งเดียวกับปุ่มบันทึกของหน้ากรอก */}
                    {(!reviewMode || reviewAction) && (
                        <div className="tw-mt-3 tw-flex tw-flex-col sm:tw-flex-row tw-justify-end tw-gap-2 sm:tw-gap-3">
                            {!reviewMode && cancelEditAction}
                            {reviewMode ? reviewAction : (
                                <Button type="button" onClick={onFinalSave} disabled={!canFinalSave || submitting}
                                    className="tw-text-sm tw-py-2.5 tw-bg-gray-800 hover:tw-bg-gray-900"
                                    title={!canFinalSave ? t("alertCompleteAll", lang) : undefined}>
                                    {submitting ? t("saving", lang) : t("save", lang)}
                                </Button>
                            )}
                        </div>
                    )}
                </div>
            </form>
            {/* ตรวจเสร็จแล้วกดต่อได้เลย ไม่ต้องเลื่อนกลับขึ้นไปข้างบน */}
            {approveMode && editId && (
                <div id="pm-approve-bottom" className="tw-mx-auto tw-max-w-6xl tw-mt-6 tw-flex tw-items-center tw-justify-end tw-gap-2 tw-border-t tw-border-blue-gray-100 tw-pt-5">
                    <PmApprovalBar
                        prefix="pmreport" reportId={editId}
                        scope={{ sn }}
                        apiBase={API_BASE}
                        onDone={(msg) => { alert(msg); goBackToList(); }}
                    />
                </div>
            )}
        </section>
    );
}
