"use client";
import LoadingOverlay from "../../components/Loadingoverlay";
import { ensureViewableImage, looksLikeImageFile } from "@/utils/heic";
import { useEffect, useState, useMemo, useRef } from "react";
import { apiFetch } from "@/utils/api";
import { WARRANTY_STATUS_OPTIONS, INVESTMENT_SCOPE_OPTIONS, MultiSelectDropdown } from "./stationOptions";
import {
    Dialog,
    DialogHeader,
    DialogBody,
    DialogFooter,
    Button,
    Input,
    Typography,
    Select,
    Option,
} from "@material-tailwind/react";

// ===== Types =====
export type ChargerForm = {
    id: string;
    chargerNo: number;
    brand: string;
    vendor: string;
    model: string;
    SN: string;
    WO: string;
    power: string;
    PLCFirmware: string;
    PIFirmware: string;
    RTFirmware: string;
    chargeBoxID: string;
    ocppUrl: string;
    commissioningDate: string;
    warrantyYears: number;
    numberOfCables: number;
    is_active: boolean;
    maximo_location: string;
    maximo_desc: string;
    chargerType: string;
    chargerImages: File[];
    deviceImages: File[];
};

export type StationForm = {
    station_id: string;
    station_name: string;
    owner: string;
    is_active: boolean;
    maximo_location: string;
    maximo_desc: string;
    warranty_status: string;
    investment_scope: string[];
    io_code: string;
    stationImages: File[];
    mdbImages: File[];
};

export type NewStationPayload = {
    station: Omit<StationForm, "stationImages" | "mdbImages">;
    chargers: Omit<ChargerForm, "id" | "chargerImages" | "deviceImages">[];
};

type Props = {
    open: boolean;
    onClose: () => void;
    onSubmit: (payload: NewStationPayload) => Promise<any>;
    loading?: boolean;
    onSubmitImages?: (
        stationId: string,
        images: { station: File[]; mdb: File[] },
        chargerImages: Array<{ chargerNo: number; chargerImages: File[]; deviceImages: File[] }>,
        createdChargers: Array<{ id: string; chargerNo: number }>
    ) => Promise<void> | void;
    currentUser: string;
    isAdmin: boolean;
    allOwners?: string[];
};

// ===== Helpers =====
const generateStationId = (stationName: string): string => {
    const nameSlug = stationName.trim().replace(/[^\u0E00-\u0E7FA-Za-z0-9\s]/g, "").replace(/\s+/g, "_");
    if (!nameSlug) return `STATION_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    return nameSlug;
};

const getTodayDate = (): string => new Date().toISOString().split("T")[0];

const generateId = (): string => {
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
    });
};

const createEmptyCharger = (chargerNo: number): ChargerForm => ({
    id: generateId(), chargerNo, brand: "", vendor: "", model: "", SN: "", WO: "", power: "",
    PLCFirmware: "", PIFirmware: "", RTFirmware: "", chargeBoxID: "", ocppUrl: "",
    commissioningDate: getTodayDate(), warrantyYears: 1, numberOfCables: 1, is_active: true,
    maximo_location: "", maximo_desc: "", chargerType: "DC", chargerImages: [], deviceImages: [],
});

type StationImageKind = "station" | "mdb";
type Lang = "th" | "en";

/* ─────────────────────────── Sub-components ─────────────────────────── */

/** Thumbnail gallery with remove-on-hover */
const ImageGallery = ({ previews, onRemove, emptyLabel }: {
    previews: string[];
    onRemove: (i: number) => void;
    emptyLabel: string;
}) => {
    if (!previews.length) {
        return (
            <div className="tw-flex tw-items-center tw-justify-center tw-h-14 sm:tw-h-[68px] tw-rounded-xl tw-border-2 tw-border-dashed tw-border-blue-gray-100">
                <span className="tw-text-[10px] sm:tw-text-[11px] tw-text-blue-gray-300 tw-select-none">{emptyLabel}</span>
            </div>
        );
    }
    return (
        <div className="tw-flex tw-flex-wrap tw-gap-1.5 sm:tw-gap-2">
            {previews.map((url, i) => (
                <div
                    key={i}
                    className="tw-group/img tw-relative tw-h-14 tw-w-14 sm:tw-h-[68px] sm:tw-w-[68px] tw-rounded-xl tw-overflow-hidden tw-ring-1 tw-ring-black/10 tw-shadow-sm hover:tw-shadow-md hover:tw-ring-blue-400/40 tw-transition-all tw-duration-200 hover:tw--translate-y-0.5"
                >
                    <img src={url} alt="" className="tw-h-full tw-w-full tw-object-cover" />
                    <div className="tw-absolute tw-inset-0 tw-bg-black/0 group-hover/img:tw-bg-black/25 tw-transition-colors" />
                    <button
                        type="button"
                        onClick={() => onRemove(i)}
                        className="tw-absolute tw-top-0.5 tw-right-0.5 sm:tw-top-1 sm:tw-right-1 tw-h-5 tw-w-5 tw-rounded-full tw-bg-red-500 tw-text-white tw-flex tw-items-center tw-justify-center sm:tw-opacity-0 group-hover/img:tw-opacity-100 tw-shadow-lg tw-transition-all tw-duration-150 hover:tw-bg-red-600 hover:tw-scale-110 tw-text-[10px] tw-leading-none"
                    >
                        ✕
                    </button>
                    <span className="tw-absolute tw-bottom-0 tw-inset-x-0 tw-text-center tw-text-[8px] tw-font-medium tw-text-white tw-bg-gradient-to-t tw-from-black/40 tw-to-transparent tw-pt-3 tw-pb-0.5 tw-opacity-0 group-hover/img:tw-opacity-100 tw-transition-opacity">
                        {i + 1}
                    </span>
                </div>
            ))}
        </div>
    );
};

/** Styled upload trigger */
const UploadBtn = ({ label, onChange }: {
    label: string;
    onChange: React.ChangeEventHandler<HTMLInputElement>;
}) => (
    <label className="tw-inline-flex tw-items-center tw-gap-1 sm:tw-gap-1.5 tw-px-2.5 sm:tw-px-3 tw-py-[5px] tw-rounded-lg tw-bg-white tw-border tw-border-blue-gray-200 tw-text-[10px] sm:tw-text-[11px] tw-font-semibold tw-text-blue-gray-600 tw-cursor-pointer hover:tw-border-blue-400 hover:tw-text-blue-600 hover:tw-bg-blue-50/50 tw-transition-all tw-duration-200 tw-shadow-sm hover:tw-shadow tw-select-none">
        <svg xmlns="http://www.w3.org/2000/svg" className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" /></svg>
        {label}
        <input type="file" accept="image/*" multiple onChange={onChange} className="tw-hidden" />
    </label>
);

/** Image upload zone (label + button + gallery) */
const ImageZone = ({ label, previews, onUpload, onRemove, emptyLabel, uploadLabel }: {
    label: string;
    previews: string[];
    onUpload: React.ChangeEventHandler<HTMLInputElement>;
    onRemove: (i: number) => void;
    emptyLabel: string;
    uploadLabel: string;
}) => (
    <div className="tw-space-y-1.5 sm:tw-space-y-2 tw-p-2.5 sm:tw-p-3 tw-rounded-xl tw-bg-blue-gray-50/40 tw-ring-1 tw-ring-blue-gray-100/60">
        <div className="tw-flex tw-items-center tw-justify-between tw-min-h-[28px]">
            <span className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-wider">{label}</span>
            <UploadBtn label={uploadLabel} onChange={onUpload} />
        </div>
        <ImageGallery previews={previews} onRemove={onRemove} emptyLabel={emptyLabel} />
    </div>
);

/** Section icon badge */
const SectionIcon = ({ emoji }: { emoji: string; }) => (
    <span className="tw-inline-flex tw-items-center tw-justify-center tw-h-7 tw-w-7 sm:tw-h-8 sm:tw-w-8 tw-rounded-xl tw-bg-gradient-to-br tw-shadow-lg tw-text-xs sm:tw-text-sm">
        {emoji}
    </span>
);

/** Spinner */
const Spinner = () => (
    <svg className="tw-animate-spin tw-h-4 tw-w-4" viewBox="0 0 24 24" fill="none">
        <circle className="tw-opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="tw-opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
);

/** Maximo location option from API */
export type MaximoLocation = { location: string; description: string };

/** แหล่งข้อมูลชื่อสถานี: "maximo" = เลือกจาก Maximo location, "name" = กรอกชื่อเอง */
type StationSource = "" | "maximo" | "name";

/** Maximo charger under a station (from /maximo/locations/{code}/chargers) */
export type MaximoCharger = { location: string; name: string; description: string; charger_type: string; power_kw: string };

/** ชื่อตู้ชาร์จ = segment ท้ายของ Maximo location เช่น "PTG0001-EV-BTL01GU201" → "BTL01GU201" */
const chargerShortName = (location: string): string =>
    location.includes("-EV-") ? location.split("-EV-").pop()! : "";

/**
 * Searchable Maximo-location dropdown.
 * Selecting an option fills both location + description (via onSelect).
 * Falls back to a plain text input when Maximo is unreachable/disabled (no options),
 * so the form still works offline.
 */
export const MaximoLocationSelect = ({
    label, value, onSelect, options, loading, disabled, searchPlaceholder, emptyLabel, loadingLabel = "Loading…",
}: {
    label: string;
    value: string;
    onSelect: (location: string, description: string) => void;
    options: MaximoLocation[];
    loading: boolean;
    disabled: boolean;
    searchPlaceholder: string;
    emptyLabel: string;
    loadingLabel?: string;
}) => {
    const [open, setOpen] = useState(false);
    const [query, setQuery] = useState("");
    const boxRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!open) return;
        const onDoc = (e: MouseEvent) => {
            if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
        };
        document.addEventListener("mousedown", onDoc);
        return () => document.removeEventListener("mousedown", onDoc);
    }, [open]);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        if (!q) return options;
        return options.filter(
            (o) => o.location.toLowerCase().includes(q) || (o.description || "").toLowerCase().includes(q)
        );
    }, [options, query]);

    return (
        <div ref={boxRef} className="tw-relative tw-w-full tw-min-w-[200px] tw-h-10">
            <button
                type="button"
                disabled={disabled}
                onClick={() => setOpen((v) => !v)}
                className="tw-peer tw-w-full tw-h-full tw-flex tw-items-center tw-justify-between tw-gap-2 tw-bg-transparent tw-text-left tw-text-blue-gray-700 tw-font-sans tw-font-normal tw-outline-none tw-border tw-border-blue-gray-200 focus:tw-border-2 focus:tw-border-gray-900 tw-rounded-[7px] tw-px-3 tw-py-2.5 tw-text-sm tw-cursor-pointer disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
            >
                <span className={`tw-truncate ${value ? "" : "tw-text-blue-gray-300"}`}>
                    {value || ""}
                </span>
                <svg xmlns="http://www.w3.org/2000/svg" className="tw-h-4 tw-w-4 tw-shrink-0 tw-text-blue-gray-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
            </button>
            <label className="tw-pointer-events-none tw-absolute tw-left-3 tw--top-1.5 tw-text-[11px] tw-text-blue-gray-400 tw-bg-white tw-px-1 tw-font-normal">
                {label}
            </label>

            {open && (
                <div className="tw-absolute tw-z-50 tw-mt-1 tw-w-full tw-rounded-lg tw-bg-white tw-shadow-xl tw-ring-1 tw-ring-black/10 tw-overflow-hidden">
                    <div className="tw-p-2 tw-border-b tw-border-blue-gray-50">
                        <input
                            autoFocus
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder={searchPlaceholder}
                            className="tw-w-full tw-text-sm tw-px-2.5 tw-py-1.5 tw-rounded-md tw-border tw-border-blue-gray-100 tw-outline-none focus:tw-border-gray-900"
                        />
                    </div>
                    <ul className="tw-max-h-56 tw-overflow-y-auto tw-py-1">
                        {loading ? (
                            <li className="tw-px-3 tw-py-3 tw-flex tw-items-center tw-gap-2 tw-text-sm tw-text-blue-gray-400"><Spinner />{loadingLabel}</li>
                        ) : filtered.length === 0 ? (
                            <li className="tw-px-3 tw-py-3 tw-text-sm tw-text-blue-gray-400">{emptyLabel}</li>
                        ) : (
                            filtered.map((o) => (
                                <li key={o.location}>
                                    <button
                                        type="button"
                                        onClick={() => { onSelect(o.location, o.description || ""); setOpen(false); setQuery(""); }}
                                        className={`tw-w-full tw-text-left tw-px-3 tw-py-2 tw-text-sm hover:tw-bg-blue-gray-50 tw-transition-colors ${value === o.location ? "tw-bg-blue-gray-50/70" : ""}`}
                                    >
                                        <span className="tw-font-medium tw-text-blue-gray-800">{o.location}</span>
                                        {o.description && <span className="tw-block tw-text-[11px] tw-text-blue-gray-400 tw-truncate">{o.description}</span>}
                                    </button>
                                </li>
                            ))
                        )}
                    </ul>
                </div>
            )}
        </div>
    );
};

/* ─────────────────────────── Main Component ─────────────────────────── */
export default function AddStationModal({
    open, onClose, onSubmit, loading, currentUser, isAdmin, allOwners = [], onSubmitImages,
}: Props) {
    const [lang, setLang] = useState<Lang>("en");

    useEffect(() => {
        const saved = localStorage.getItem("app_language") as Lang | null;
        if (saved === "th" || saved === "en") setLang(saved);
        const handler = (e: CustomEvent<{ lang: Lang }>) => setLang(e.detail.lang);
        window.addEventListener("language:change", handler as EventListener);
        return () => window.removeEventListener("language:change", handler as EventListener);
    }, []);

    /* ── translations ── */
    const t = useMemo(() => {
        const tr = {
            th: {
                addNewStation: "เพิ่มสถานีใหม่", subtitle: "กรอกข้อมูลสถานีและตู้ชาร์จ",
                stationInfo: "ข้อมูลสถานี", stationName: "ชื่อสถานี", owner: "เจ้าของ",
                status: "สถานะ", active: "เปิดใช้งาน", inactive: "ปิดใช้งาน",
                maximoLocation: "Location", maximoDesc: "Description",
                warrantyStatus: "การรับประกัน", investmentScope: "สัดส่วนการลงทุน", ioCode: "รหัสค่าใช้จ่าย (IO)",
                selectPlaceholder: "เลือก",
                stationImages: "รูปภาพสถานี", station: "สถานี", mdb: "MDB",
                chargers: "ตู้ชาร์จ", addCharger: "เพิ่มตู้ชาร์จ", chargerNo: "ตู้ชาร์จ #",
                chargerBoxId: "Charge Box ID", ocppUrl: "OCPP URL", ocppSection: "OCPP",
                chargerType: "ประเภท", chargerNoAuto: "ลำดับ (อัตโนมัติ)", auto: "อัตโนมัติ",
                brand: "ยี่ห้อ", vendor: "ผู้จำหน่าย (Vendor)", model: "รุ่น", serialNumber: "S/N",
                workOrder: "WO", power: "กำลังไฟ (kW)", plcFirmware: "PLC Firmware",
                piFirmware: "Pi Firmware", routerFirmware: "Router Firmware",
                commissioningDate: "วันเริ่มใช้งาน", warrantyYears: "รับประกัน (ปี)",
                numberOfCables: "จำนวนสาย", images: "รูปภาพ", charger: "ตู้ชาร์จ",
                device: "อุปกรณ์", chargerCount: "ตู้ชาร์จ", cancel: "ยกเลิก",
                createStation: "สร้างสถานี", saving: "กำลังบันทึก...",
                pleaseEnterStationName: "กรุณากรอกชื่อสถานี",
                pleaseFillChargerBoxId: "กรุณากรอก Charge Box ID ให้ครบ",
                atLeastOneCharger: "ต้องมีตู้ชาร์จอย่างน้อย 1 ตู้",
                selectImageOnly: "กรุณาเลือกไฟล์รูปภาพเท่านั้น",
                fileTooLarge: "ไฟล์ใหญ่เกินไป (สูงสุด 3MB)",
                upload: "เลือกรูป", noImages: "ยังไม่มีรูป", removeCharger: "ลบตู้ชาร์จนี้",
                duplicateSN: "SN ซ้ำกัน กรุณาตรวจสอบ",
                duplicateWO: "WO ซ้ำกัน กรุณาตรวจสอบ",
                duplicateChargeBoxID: "Charge Box ID ซ้ำกัน กรุณาตรวจสอบ",
                pleaseSelectOwner: "กรุณาเลือก Owner จาก Company Profile",
                maximoSearch: "ค้นหา location...",
                maximoEmpty: "ไม่พบ location",
                maximoLoading: "กำลังโหลด…",
                locationTitle: "Source",
                sourceName: "กรอกชื่อสถานี",
                selectSourceFirst: "เลือกแหล่งข้อมูลก่อน — Maximo หรือกรอกชื่อสถานี",
                pleaseSelectMaximo: "กรุณาเลือก Location",
                loadingChargers: "กำลังดึงข้อมูลตู้ชาร์จจาก Maximo...",
                noChargersFound: "ไม่พบตู้ชาร์จใน Maximo สำหรับ location นี้",
            },
            en: {
                addNewStation: "Add New Station", subtitle: "Fill in station and charger details",
                stationInfo: "Station Information", stationName: "Station Name", owner: "Owner",
                status: "Status", active: "Active", inactive: "Inactive",
                maximoLocation: "Location", maximoDesc: "Description",
                warrantyStatus: "Warranty", investmentScope: "Investment Scope", ioCode: "Expense Code (IO)",
                selectPlaceholder: "Select",
                stationImages: "Station Images", station: "Station", mdb: "MDB",
                chargers: "Chargers", addCharger: "Add Charger", chargerNo: "Charger #",
                chargerBoxId: "Charge Box ID", ocppUrl: "OCPP URL", ocppSection: "OCPP",
                chargerType: "Type", chargerNoAuto: "No. (Auto)", auto: "Auto",
                brand: "Brand", vendor: "Vendor", model: "Model", serialNumber: "S/N",
                workOrder: "WO", power: "Power (kW)", plcFirmware: "PLC Firmware",
                piFirmware: "Pi Firmware", routerFirmware: "Router Firmware",
                commissioningDate: "Commissioning Date", warrantyYears: "Warranty (Yrs)",
                numberOfCables: "Cables", images: "Images", charger: "Charger",
                device: "Device", chargerCount: "Charger(s)", cancel: "Cancel",
                createStation: "Create Station", saving: "Saving...",
                pleaseEnterStationName: "Please enter Station Name",
                pleaseFillChargerBoxId: "Please fill in Charge Box ID for all chargers",
                atLeastOneCharger: "At least 1 Charger is required",
                selectImageOnly: "Please select image files only",
                fileTooLarge: "File too large (max 3 MB)",
                upload: "Browse", noImages: "No images yet", removeCharger: "Remove this charger",
                duplicateSN: "Duplicate SN found, please check",
                duplicateWO: "Duplicate WO found, please check",
                duplicateChargeBoxID: "Duplicate Charge Box ID found, please check",
                pleaseSelectOwner: "Please select an Owner from Company Profile",
                maximoSearch: "Search location...",
                maximoEmpty: "No location found",
                maximoLoading: "Loading…",
                locationTitle: "Source",
                sourceName: "Enter name",
                selectSourceFirst: "Select a source first — Maximo or enter the name",
                pleaseSelectMaximo: "Please select a Location",
                loadingChargers: "Loading chargers from Maximo...",
                noChargersFound: "No chargers found in Maximo for this location",
            },
        };
        return tr[lang];
    }, [lang]);

    /* ── state ── */
    const [station, setStation] = useState<StationForm>({
        station_id: "", station_name: "", owner: "", is_active: true,
        maximo_location: "", maximo_desc: "", warranty_status: "", investment_scope: [], io_code: "",
        stationImages: [], mdbImages: [],
    });
    const [stationPreviews, setStationPreviews] = useState<Record<StationImageKind, string[]>>({ station: [], mdb: [] });
    const [chargerPreviews, setChargerPreviews] = useState<Record<string, { charger: string[]; device: string[] }>>({});
    // ตู้ชาร์จถูก auto-fill จาก Maximo หลังเลือก station location — เริ่มต้นว่างเสมอ
    const [chargers, setChargers] = useState<ChargerForm[]>([]);
    const [submitting, setSubmitting] = useState(false);

    /* ── Maximo locations (station dropdown) ── */
    // station = location ไม่มี -EV ต่อท้าย (เช่น HMP0002)
    const [stationLocations, setStationLocations] = useState<MaximoLocation[]>([]);
    // แหล่งข้อมูล (checkbox): "maximo" = เลือกจาก Maximo, "name" = กรอกชื่อสถานีเอง
    const [selectedSource, setSelectedSource] = useState<StationSource>("");
    const [maximoLoading, setMaximoLoading] = useState(false);
    // โหลดรายการตู้ชาร์จใต้ station ที่เลือก (auto-fill จาก Maximo)
    const [chargersLoading, setChargersLoading] = useState(false);
    const chargersFetchSeq = useRef(0);

    // โหลดรายการ location เมื่อผู้ใช้ติ๊กแหล่ง Maximo (lazy)
    useEffect(() => {
        if (!open || selectedSource !== "maximo" || stationLocations.length || maximoLoading) return;
        let cancelled = false;
        (async () => {
            setMaximoLoading(true);
            try {
                const res = await apiFetch(`/maximo/locations?level=station`);
                if (!cancelled && res.ok) {
                    const json = await res.json();
                    if (Array.isArray(json?.locations)) setStationLocations(json.locations);
                }
            } catch (e) {
                console.error("Failed to fetch Maximo locations:", e);
            } finally {
                if (!cancelled) setMaximoLoading(false);
            }
        })();
        return () => { cancelled = true; };
    }, [open, selectedSource]);

    /** ล้าง location + ตู้ชาร์จที่เลือกไว้ (ใช้ตอนเปลี่ยนแหล่งข้อมูล) */
    const clearSelectedLocation = () => {
        setStation((s) => ({ ...s, maximo_location: "", maximo_desc: "", station_name: "" }));
        Object.values(chargerPreviews).forEach((p) => { p.charger?.forEach((u) => URL.revokeObjectURL(u)); p.device?.forEach((u) => URL.revokeObjectURL(u)); });
        setChargerPreviews({});
        setChargers([]);
        chargersFetchSeq.current++; // ยกเลิกผล fetch ตู้ชาร์จที่ค้างอยู่
        setChargersLoading(false);
    };

    /** ติ๊กเลือกแหล่งข้อมูล (เลือกได้ทีละแหล่ง — ติ๊กซ้ำเพื่อยกเลิก) */
    const handleSourceToggle = (source: StationSource) => {
        const next = selectedSource === source ? "" : source;
        setSelectedSource(next);
        clearSelectedLocation();
    };

    /** เพิ่ม/ลบตู้ชาร์จเอง (เฉพาะโหมดกรอกชื่อเอง — โหมด Maximo auto-fill เท่านั้น) */
    const addManualCharger = () => setChargers((prev) => [...prev, createEmptyCharger(prev.length + 1)]);
    const removeManualCharger = (id: string) => {
        const p = chargerPreviews[id];
        p?.charger?.forEach((u) => URL.revokeObjectURL(u));
        p?.device?.forEach((u) => URL.revokeObjectURL(u));
        setChargerPreviews((prev) => { const { [id]: _removed, ...rest } = prev; return rest; });
        setChargers((prev) => prev.filter((c) => c.id !== id).map((c, i) => ({ ...c, chargerNo: i + 1 })));
    };

    const isFlexxfast = (brand: string) => brand.trim().toLowerCase() === "flexxfast";

    useEffect(() => {
        if (open && !isAdmin) {
            setStation((s) => ({ ...s, owner: currentUser || "" }));
        }
    }, [open, currentUser, isAdmin]);

    useEffect(() => {
        setStation((s) => ({ ...s, station_id: s.station_name.trim() ? generateStationId(s.station_name) : "" }));
    }, [station.station_name]);

    const onStationChange = (key: keyof StationForm, value: any) => setStation((s) => ({ ...s, [key]: value }));
    const onChargerChange = (id: string, key: keyof ChargerForm, value: any) =>
        setChargers((prev) => prev.map((c) => (c.id === id ? { ...c, [key]: value } : c)));

    /** เลือก Maximo station → ดึงตู้ชาร์จใต้ station นั้นจาก Maximo มา auto-fill (แทนที่ชุดเดิมทั้งหมด) */
    const handleMaximoStationSelect = async (loc: string, desc: string) => {
        setStation((s) => ({
            ...s,
            maximo_location: loc,
            maximo_desc: desc,
            // ใช้ description เป็นชื่อสถานี (fallback เป็นรหัส location ถ้า desc ว่าง)
            station_name: desc || loc,
        }));
        // ล้าง preview รูปของตู้ชาร์จชุดเดิมก่อนแทนที่
        Object.values(chargerPreviews).forEach((p) => { p.charger?.forEach((u) => URL.revokeObjectURL(u)); p.device?.forEach((u) => URL.revokeObjectURL(u)); });
        setChargerPreviews({});
        setChargers([]);
        const seq = ++chargersFetchSeq.current;
        setChargersLoading(true);
        try {
            const res = await apiFetch(`/maximo/locations/${encodeURIComponent(loc)}/chargers`);
            const json = res.ok ? await res.json() : null;
            if (seq !== chargersFetchSeq.current) return; // user เลือก station ใหม่กว่าแล้ว
            const list: MaximoCharger[] = Array.isArray(json?.chargers) ? json.chargers : [];
            setChargers(list.map((mc, i) => ({
                ...createEmptyCharger(i + 1),
                maximo_location: mc.location,
                maximo_desc: mc.description,
                chargerType: mc.charger_type === "AC" ? "AC" : "DC",
                power: mc.power_kw || "",
            })));
        } catch (e) {
            console.error("Failed to fetch Maximo chargers:", e);
        } finally {
            if (seq === chargersFetchSeq.current) setChargersLoading(false);
        }
    };

    /* ── file validation ── */
    const pickValid = (files: FileList | null): File[] =>
        Array.from(files || []).filter((f) => {
            if (!looksLikeImageFile(f)) { alert(t.selectImageOnly); return false; }
            if (f.size > 3 * 1024 * 1024) { alert(t.fileTooLarge); return false; }
            return true;
        });

    /* ── read EXIF orientation tag from JPEG bytes (1..8, 1 = normal) ── */
    const readExifOrientation = async (file: File): Promise<number> => {
        if (file.type !== "image/jpeg" && file.type !== "image/jpg") return 1;
        try {
            const buf = await file.slice(0, 256 * 1024).arrayBuffer();
            const view = new DataView(buf);
            if (view.byteLength < 4 || view.getUint16(0) !== 0xffd8) return 1;
            let offset = 2;
            while (offset < view.byteLength) {
                const marker = view.getUint16(offset);
                offset += 2;
                if (marker === 0xffe1) {
                    const size = view.getUint16(offset);
                    if (view.getUint32(offset + 2) !== 0x45786966) return 1; // "Exif"
                    const tiff = offset + 8;
                    const little = view.getUint16(tiff) === 0x4949;
                    const get16 = (o: number) => view.getUint16(o, little);
                    const get32 = (o: number) => view.getUint32(o, little);
                    if (get16(tiff + 2) !== 0x002a) return 1;
                    const ifd = tiff + get32(tiff + 4);
                    const tags = get16(ifd);
                    for (let i = 0; i < tags; i++) {
                        const entry = ifd + 2 + i * 12;
                        if (get16(entry) === 0x0112) return get16(entry + 8);
                    }
                    return 1;
                } else if ((marker & 0xff00) !== 0xff00) {
                    return 1;
                } else {
                    offset += view.getUint16(offset);
                }
            }
        } catch { /* ignore */ }
        return 1;
    };

    /* ── read raw JPEG dimensions from SOF marker (pre-EXIF rotation) ── */
    const readJpegDimensions = async (file: File): Promise<{ width: number; height: number } | null> => {
        if (!/jpe?g/i.test(file.type)) return null;
        try {
            const buf = await file.arrayBuffer();
            const view = new DataView(buf);
            if (view.byteLength < 4 || view.getUint16(0) !== 0xffd8) return null;
            let offset = 2;
            while (offset < view.byteLength) {
                if (view.getUint8(offset) !== 0xff) return null;
                const marker = view.getUint16(offset);
                offset += 2;
                const isSOF =
                    (marker >= 0xffc0 && marker <= 0xffc3) ||
                    (marker >= 0xffc5 && marker <= 0xffc7) ||
                    (marker >= 0xffc9 && marker <= 0xffcb) ||
                    (marker >= 0xffcd && marker <= 0xffcf);
                if (isSOF) {
                    const height = view.getUint16(offset + 3);
                    const width = view.getUint16(offset + 5);
                    return { width, height };
                }
                offset += view.getUint16(offset);
            }
        } catch { /* ignore */ }
        return null;
    };

    /* ── normalize EXIF orientation (rotate image upright) ── */
    const normalizeImageOrientation = async (rawFile: File): Promise<File> => {
    // HEIC จาก iPhone: canvas decode ไม่ออก → preview ขึ้นกรอบว่าง และ EXIF orientation
    // ด้านล่างก็ทำงานไม่ได้ แปลงเป็น JPEG ที่ server ก่อนทุกอย่าง
        const file = await ensureViewableImage(rawFile);
        if (!file.type.startsWith("image/") || file.type === "image/gif" || file.type === "image/svg+xml") {
            return file;
        }
        try {
            const orientation = await readExifOrientation(file);
            if (orientation === 1) return file;

            const rawDims = await readJpegDimensions(file);

            // ขอ bitmap แบบไม่หมุน แต่บางเบราว์เซอร์ก็ยังหมุนให้อยู่ดี → ต้องตรวจสอบจากขนาดจริง
            let bitmap: ImageBitmap;
            try {
                bitmap = await createImageBitmap(file, { imageOrientation: "none" } as any);
            } catch {
                bitmap = await createImageBitmap(file);
            }

            const swap = orientation >= 5 && orientation <= 8;
            // ถ้า bitmap.width/height สลับเทียบกับ raw → เบราว์เซอร์หมุนให้แล้ว วาดตรง ๆ
            const alreadyRotated = !!rawDims && swap &&
                bitmap.width === rawDims.height && bitmap.height === rawDims.width;

            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");
            if (!ctx) { bitmap.close?.(); return file; }

            if (alreadyRotated) {
                canvas.width = bitmap.width;
                canvas.height = bitmap.height;
                ctx.drawImage(bitmap, 0, 0);
            } else {
                const w = bitmap.width, h = bitmap.height;
                canvas.width = swap ? h : w;
                canvas.height = swap ? w : h;
                switch (orientation) {
                    case 2: ctx.transform(-1, 0, 0, 1, w, 0); break;
                    case 3: ctx.transform(-1, 0, 0, -1, w, h); break;
                    case 4: ctx.transform(1, 0, 0, -1, 0, h); break;
                    case 5: ctx.transform(0, 1, 1, 0, 0, 0); break;
                    case 6: ctx.transform(0, 1, -1, 0, h, 0); break;
                    case 7: ctx.transform(0, -1, -1, 0, h, w); break;
                    case 8: ctx.transform(0, -1, 1, 0, 0, w); break;
                }
                ctx.drawImage(bitmap, 0, 0);
            }
            bitmap.close?.();

            const outType = file.type === "image/png" ? "image/png" : "image/jpeg";
            const blob: Blob | null = await new Promise((resolve) =>
                canvas.toBlob(resolve, outType, 0.92)
            );
            if (!blob) return file;
            const newName = file.name.replace(/\.(jpe?g|png|webp|bmp)$/i, "") + (outType === "image/png" ? ".png" : ".jpg");
            return new File([blob], newName, { type: blob.type, lastModified: Date.now() });
        } catch {
            return file;
        }
    };

    /* ── station images ── */
    const handleStationImage = async (kind: StationImageKind, e: React.ChangeEvent<HTMLInputElement>) => {
        const valid = pickValid(e.target.files);
        e.target.value = "";
        if (!valid.length) return;
        const normalized = await Promise.all(valid.map(normalizeImageOrientation));
        const key = `${kind}Images` as keyof StationForm;
        setStation((s) => ({ ...s, [key]: [...(s[key] as File[]), ...normalized] }));
        setStationPreviews((p) => ({ ...p, [kind]: [...p[kind], ...normalized.map((f) => URL.createObjectURL(f))] }));
    };
    const removeStationImage = (kind: StationImageKind, idx: number) => {
        URL.revokeObjectURL(stationPreviews[kind][idx]);
        const key = `${kind}Images` as keyof StationForm;
        setStation((s) => ({ ...s, [key]: (s[key] as File[]).filter((_, i) => i !== idx) }));
        setStationPreviews((p) => ({ ...p, [kind]: p[kind].filter((_, i) => i !== idx) }));
    };

    /* ── charger images ── */
    const handleChargerImage = async (cid: string, kind: "charger" | "device", e: React.ChangeEvent<HTMLInputElement>) => {
        const valid = pickValid(e.target.files);
        e.target.value = "";
        if (!valid.length) return;
        const normalized = await Promise.all(valid.map(normalizeImageOrientation));
        const key = kind === "charger" ? "chargerImages" : "deviceImages";
        setChargers((prev) => prev.map((c) => (c.id === cid ? { ...c, [key]: [...c[key], ...normalized] } : c)));
        setChargerPreviews((p) => ({
            ...p,
            [cid]: {
                charger: p[cid]?.charger || [],
                device: p[cid]?.device || [],
                [kind]: [...(p[cid]?.[kind] || []), ...normalized.map((f) => URL.createObjectURL(f))],
            },
        }));
    };
    const removeChargerImage = (cid: string, kind: "charger" | "device", idx: number) => {
        const url = chargerPreviews[cid]?.[kind]?.[idx];
        if (url) URL.revokeObjectURL(url);
        const key = kind === "charger" ? "chargerImages" : "deviceImages";
        setChargers((prev) => prev.map((c) => (c.id === cid ? { ...c, [key]: c[key].filter((_, i) => i !== idx) } : c)));
        setChargerPreviews((p) => ({ ...p, [cid]: { ...p[cid], [kind]: (p[cid]?.[kind] || []).filter((_, i) => i !== idx) } }));
    };

    /* ── submit ── */
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (submitting) return;
        setSubmitting(true);
        if (selectedSource !== "name" && !station.maximo_location.trim()) { alert(t.pleaseSelectMaximo); setSubmitting(false); return; }
        if (!station.station_name.trim()) { alert(t.pleaseEnterStationName); setSubmitting(false); return; }
        if (isAdmin && !station.owner.trim()) { alert(t.pleaseSelectOwner); setSubmitting(false); return; }
        if (!chargers.length) { alert(t.atLeastOneCharger); setSubmitting(false); return; }
        if (chargers.some((c) => isFlexxfast(c.brand) && !c.chargeBoxID.trim())) { alert(t.pleaseFillChargerBoxId); setSubmitting(false); return; }

        const payload: NewStationPayload = {
            station: {
                station_id: station.station_id.trim(), station_name: station.station_name.trim(),
                owner: (station.owner || currentUser).trim(), is_active: station.is_active,
                maximo_location: station.maximo_location.trim(), maximo_desc: station.maximo_desc.trim(),
                warranty_status: station.warranty_status, investment_scope: station.investment_scope,
                io_code: station.io_code.trim(),
            },
            chargers: chargers.map((c) => ({
                chargerNo: c.chargerNo, brand: c.brand.trim(), vendor: c.vendor.trim(), model: c.model.trim(),
                SN: c.SN.trim(), WO: c.WO.trim(), power: c.power.trim(),
                PLCFirmware: c.PLCFirmware.trim(), PIFirmware: c.PIFirmware.trim(),
                RTFirmware: c.RTFirmware.trim(), chargeBoxID: c.chargeBoxID.trim(),
                ocppUrl: c.ocppUrl.trim(), commissioningDate: c.commissioningDate,
                warrantyYears: c.warrantyYears, numberOfCables: c.numberOfCables,
                is_active: c.is_active, maximo_location: c.maximo_location.trim(),
                maximo_desc: c.maximo_desc.trim(), chargerType: c.chargerType,
            })),
        };

        // ── ตรวจ duplicate SN ──
        const sns = chargers.map((c) => c.SN.trim()).filter(Boolean);
        if (new Set(sns).size !== sns.length) {
            alert(t.duplicateSN);
            setSubmitting(false);
            return;
        }

        // ── ตรวจ duplicate WO (เฉพาะที่กรอก) ──
        const wos = chargers.map((c) => c.WO.trim()).filter(Boolean);
        if (new Set(wos).size !== wos.length) {
            alert(t.duplicateWO);
            setSubmitting(false);
            return;
        }

        const cbids = chargers.map((c) => c.chargeBoxID.trim()).filter((v) => Boolean(v) && v !== "-");
        if (new Set(cbids).size !== cbids.length) {
            alert(t.duplicateChargeBoxID); setSubmitting(false); return;
        }

        try {
            const created = await onSubmit(payload);
            if (onSubmitImages && created?.chargers) {
                await onSubmitImages(
                    payload.station.station_id,
                    { station: station.stationImages, mdb: station.mdbImages },
                    chargers.map((c) => ({ chargerNo: c.chargerNo, chargerImages: c.chargerImages, deviceImages: c.deviceImages })),
                    created.chargers.map((c: any) => ({ id: c.id, chargerNo: c.chargerNo })),
                );
            }
            resetAndClose();
        } catch (err) { console.error(err); } finally { setSubmitting(false); }
    };

    const resetAndClose = () => {
        Object.values(stationPreviews).forEach((urls) => urls.forEach((u) => u && URL.revokeObjectURL(u)));
        Object.values(chargerPreviews).forEach((p) => { p.charger?.forEach((u) => URL.revokeObjectURL(u)); p.device?.forEach((u) => URL.revokeObjectURL(u)); });
        setStation({ station_id: "", station_name: "", owner: isAdmin ? "" : currentUser, is_active: true, maximo_location: "", maximo_desc: "", warranty_status: "", investment_scope: [], io_code: "", stationImages: [], mdbImages: [] });
        setStationPreviews({ station: [], mdb: [] });
        setChargerPreviews({});
        setChargers([]);
        setSelectedSource("");
        onClose();
    };

    /* ─────────────────────── Render ─────────────────────── */
    return (
        <>
            {loading && <LoadingOverlay show={loading} text={lang === "th" ? "กำลังโหลดข้อมูล..." : "Loading data..."} />}
            <Dialog
                open={open}
                handler={resetAndClose}
                size="lg"
                dismiss={{ outsidePress: !loading, escapeKey: !loading }}
                className="tw-flex tw-flex-col tw-max-h-[95vh] sm:tw-max-h-[90vh] tw-overflow-hidden !tw-rounded-xl sm:!tw-rounded-2xl !tw-m-2 sm:!tw-m-4"
            >
                {/* ══════ HEADER ══════ */}
                <DialogHeader className="tw-sticky tw-top-0 tw-z-10 tw-bg-gradient-to-r tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-6 tw-py-3.5 sm:tw-py-5 tw-border-0 tw-shadow-xl tw-shrink-0">
                    <div className="tw-flex tw-items-center tw-justify-between tw-w-full">
                        <div className="tw-flex tw-items-center tw-gap-2.5 sm:tw-gap-3.5">
                            <div>
                                <Typography variant="h5" className="!tw-text-white !tw-font-bold !tw-tracking-tight !tw-leading-tight !tw-text-base sm:!tw-text-lg">
                                    {t.addNewStation}
                                </Typography>
                            </div>
                        </div>
                        <button
                            type="button"
                            onClick={resetAndClose}
                            className="tw-p-1.5 sm:tw-p-2 tw-rounded-xl tw-bg-white/10 hover:tw-bg-white/20 tw-text-white/60 hover:tw-text-white tw-transition-all tw-duration-200"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="tw-h-5 tw-w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                        </button>
                    </div>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="tw-flex tw-flex-col tw-min-h-0">
                    <DialogBody className="tw-flex-1 tw-min-h-0 tw-overflow-y-auto tw-space-y-3 sm:tw-space-y-5 tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-5 tw-bg-gray-50/60">

                        {/* ══════ STATION INFO CARD ══════ */}
                        <section className="tw-rounded-xl sm:tw-rounded-2xl tw-bg-white tw-shadow-sm tw-ring-1 tw-ring-black/[.06] tw-overflow-hidden">
                            <div className="tw-px-3.5 sm:tw-px-5 tw-py-3 sm:tw-py-4 tw-border-b tw-border-gray-100 tw-flex tw-items-center tw-gap-2.5 sm:tw-gap-3">
                                <SectionIcon emoji="📍" />
                                <Typography variant="h6" className="!tw-text-gray-800 !tw-font-bold !tw-tracking-tight !tw-text-sm sm:!tw-text-base">{t.stationInfo}</Typography>
                            </div>
                            <div className="tw-p-3.5 sm:tw-p-5 tw-space-y-4 sm:tw-space-y-5">
                                {/* Source — ติ๊กเลือกแหล่งข้อมูล: Maximo (เลือกจากรายการ) หรือ Name (กรอกชื่อเอง) */}
                                <div className="tw-space-y-2">
                                    <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-wider">{t.locationTitle}</p>
                                    <div className="tw-flex tw-flex-wrap tw-gap-2">
                                        {([{ id: "maximo", label: "Maximo" }, { id: "name", label: t.sourceName }] as { id: StationSource; label: string }[]).map((s) => {
                                            const checked = selectedSource === s.id;
                                            return (
                                                <label
                                                    key={s.id}
                                                    className={`tw-inline-flex tw-items-center tw-gap-2 tw-px-3 tw-py-2 tw-rounded-xl tw-border tw-cursor-pointer tw-select-none tw-text-xs sm:tw-text-sm tw-font-semibold tw-transition-all tw-duration-150 ${checked
                                                        ? "tw-border-gray-900 tw-bg-gray-900 tw-text-white tw-shadow-md"
                                                        : "tw-border-blue-gray-200 tw-bg-white tw-text-blue-gray-600 hover:tw-border-gray-400 hover:tw-bg-gray-50"}`}
                                                >
                                                    <input
                                                        type="checkbox"
                                                        checked={checked}
                                                        onChange={() => handleSourceToggle(s.id)}
                                                        className="tw-h-3.5 tw-w-3.5 tw-rounded tw-accent-gray-900 tw-cursor-pointer"
                                                    />
                                                    {s.label}
                                                </label>
                                            );
                                        })}
                                    </div>
                                    {!selectedSource && (
                                        <p className="tw-text-[11px] tw-text-blue-gray-400">{t.selectSourceFirst}</p>
                                    )}
                                </div>

                                <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-3 sm:tw-gap-4">
                                    {selectedSource === "maximo" && (
                                    <MaximoLocationSelect
                                        label={t.maximoLocation}
                                        value={station.maximo_location}
                                        options={stationLocations}
                                        loading={maximoLoading}
                                        disabled={false}
                                        searchPlaceholder={t.maximoSearch}
                                        emptyLabel={t.maximoEmpty}
                                        loadingLabel={t.maximoLoading}
                                        onSelect={handleMaximoStationSelect}
                                    />
                                    )}
                                    {selectedSource === "maximo" && station.maximo_location?.trim() && (
                                        <Input label={t.maximoDesc} value={station.maximo_desc} readOnly disabled crossOrigin={undefined} />
                                    )}
                                    {selectedSource === "name" && (
                                        <Input label={t.stationName} required value={station.station_name} onChange={(e) => onStationChange("station_name", e.target.value)} crossOrigin={undefined} />
                                    )}
                                    {isAdmin ? (
                                        <div className="tw-relative tw-w-full tw-min-w-[200px] tw-h-10">
                                                <select
                                                    required
                                                    value={station.owner || ""}
                                                    onChange={(e) => onStationChange("owner", e.target.value)}
                                                    className="tw-peer tw-w-full tw-h-full tw-bg-transparent tw-text-blue-gray-700 tw-font-sans tw-font-normal tw-outline-none tw-border tw-border-blue-gray-200 focus:tw-border-2 focus:tw-border-gray-900 tw-rounded-[7px] tw-px-3 tw-py-2.5 tw-text-sm tw-appearance-none tw-cursor-pointer"
                                                >
                                                    <option value="" disabled>{t.pleaseSelectOwner}</option>
                                                    {allOwners.map((n) => (
                                                        <option key={n} value={n}>{n}</option>
                                                    ))}
                                                </select>
                                                <div className="tw-pointer-events-none tw-absolute tw-inset-y-0 tw-right-3 tw-flex tw-items-center">
                                                    <svg xmlns="http://www.w3.org/2000/svg" className="tw-h-4 tw-w-4 tw-text-blue-gray-400" viewBox="0 0 20 20" fill="currentColor">
                                                        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                                                    </svg>
                                                </div>
                                                <label className="tw-pointer-events-none tw-absolute tw-left-3 tw--top-1.5 tw-text-[11px] tw-text-blue-gray-400 tw-bg-white tw-px-1 tw-font-normal">
                                                    {t.owner}
                                                </label>
                                        </div>
                                    ) : (
                                        <Input label={t.owner} value={station.owner || currentUser || ""} readOnly disabled crossOrigin={undefined} />
                                    )}
                                    <Select label={t.status} value={String(station.is_active)} onChange={(v) => onStationChange("is_active", v === "true")}>
                                        <Option value="true">{t.active}</Option>
                                        <Option value="false">{t.inactive}</Option>
                                    </Select>
                                    <Select label={t.warrantyStatus} value={station.warranty_status} onChange={(v) => onStationChange("warranty_status", v ?? "")}>
                                        {WARRANTY_STATUS_OPTIONS.map((o) => (
                                            <Option key={o.value} value={o.value}>{o[lang]}</Option>
                                        ))}
                                    </Select>
                                    <MultiSelectDropdown
                                        label={t.investmentScope}
                                        options={INVESTMENT_SCOPE_OPTIONS}
                                        selected={station.investment_scope}
                                        onChange={(next) => onStationChange("investment_scope", next)}
                                        lang={lang}
                                        emptyLabel={t.selectPlaceholder}
                                    />
                                    <Input label={t.ioCode} value={station.io_code} onChange={(e) => onStationChange("io_code", e.target.value)} crossOrigin={undefined} />
                                </div>

                                {/* images */}
                                <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                                    <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">📷 {t.stationImages}</p>
                                    <div className="tw-grid tw-grid-cols-1 tw-gap-2.5 sm:tw-grid-cols-2 sm:tw-gap-3">
                                        <ImageZone label={t.station} previews={stationPreviews.station} onUpload={(e) => handleStationImage("station", e)} onRemove={(i) => removeStationImage("station", i)} emptyLabel={t.noImages} uploadLabel={t.upload} />
                                        <ImageZone label={t.mdb} previews={stationPreviews.mdb} onUpload={(e) => handleStationImage("mdb", e)} onRemove={(i) => removeStationImage("mdb", i)} emptyLabel={t.noImages} uploadLabel={t.upload} />
                                    </div>
                                </div>
                            </div>
                        </section>

                        {/* ══════ CHARGERS — โหมด Maximo: auto-fill หลังเลือก location / โหมดกรอกชื่อเอง: เพิ่มตู้เอง ══════ */}
                        {(station.maximo_location?.trim() || selectedSource === "name") && (
                        <section className="tw-space-y-3 sm:tw-space-y-4">
                            <div className="tw-flex tw-items-center tw-justify-between">
                                <div className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-3">
                                    <SectionIcon emoji="⚡" />
                                    <Typography variant="h6" className="!tw-text-gray-800 !tw-font-bold !tw-tracking-tight !tw-text-sm sm:!tw-text-base">
                                        {t.chargers} <span className="tw-text-blue-gray-400 tw-font-normal">({chargers.length})</span>
                                    </Typography>
                                </div>
                                {selectedSource === "name" && (
                                    <Button
                                        type="button"
                                        size="sm"
                                        onClick={addManualCharger}
                                        className="tw-rounded-xl tw-bg-gray-900 hover:tw-bg-black tw-normal-case tw-font-semibold tw-text-[11px] sm:tw-text-xs tw-px-3 sm:tw-px-4 tw-py-2"
                                    >
                                        + {t.addCharger}
                                    </Button>
                                )}
                            </div>

                            {chargersLoading && (
                                <div className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-5 tw-rounded-xl tw-bg-white tw-ring-1 tw-ring-black/[.06] tw-text-sm tw-text-blue-gray-400">
                                    <Spinner /> {t.loadingChargers}
                                </div>
                            )}
                            {!chargersLoading && chargers.length === 0 && selectedSource !== "name" && (
                                <div className="tw-px-4 tw-py-5 tw-rounded-xl tw-bg-amber-50/60 tw-ring-1 tw-ring-amber-200/70 tw-text-sm tw-text-amber-700">
                                    {t.noChargersFound}
                                </div>
                            )}

                            {chargers.map((charger, index) => (
                                <div key={charger.id} className="tw-rounded-xl sm:tw-rounded-2xl tw-bg-white tw-shadow-sm tw-ring-1 tw-ring-black/[.06] tw-overflow-hidden tw-transition-shadow tw-duration-300 hover:tw-shadow-md">
                                    {/* charger header bar */}
                                    <div className="tw-flex tw-items-center tw-justify-between tw-px-3.5 sm:tw-px-5 tw-py-2.5 sm:tw-py-3 tw-bg-gradient-to-r tw-from-amber-50 tw-to-orange-50/80 tw-border-b tw-border-amber-100/70">
                                        <div className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-2.5 tw-min-w-0">
                                            <span className="tw-inline-flex tw-items-center tw-justify-center tw-h-6 tw-w-6 sm:tw-h-7 sm:tw-w-7 tw-rounded-lg tw-bg-gradient-to-br tw-from-amber-400 tw-to-orange-500 tw-shadow tw-text-white tw-text-[10px] sm:tw-text-xs tw-font-bold tw-shrink-0">
                                                {index + 1}
                                            </span>
                                            <span className="tw-text-xs sm:tw-text-sm tw-font-bold tw-text-gray-700 tw-truncate">
                                                {chargerShortName(charger.maximo_location) || `${t.chargerNo}${index + 1}`}
                                            </span>
                                            {charger.brand && (
                                                <span className="tw-hidden sm:tw-inline tw-px-2 tw-py-0.5 tw-rounded-md tw-bg-white/90 tw-text-[10px] tw-font-semibold tw-text-blue-gray-500 tw-ring-1 tw-ring-black/5 tw-shadow-sm tw-truncate tw-max-w-[120px]">
                                                    {charger.brand}{charger.model ? ` ${charger.model}` : ""}
                                                </span>
                                            )}
                                        </div>
                                        {selectedSource === "name" && (
                                            <button
                                                type="button"
                                                onClick={() => removeManualCharger(charger.id)}
                                                title={t.removeCharger}
                                                className="tw-h-7 tw-w-7 tw-rounded-lg tw-flex tw-items-center tw-justify-center tw-text-red-400 hover:tw-text-white hover:tw-bg-red-500 tw-transition-colors tw-shrink-0"
                                            >
                                                ✕
                                            </button>
                                        )}
                                    </div>

                                    <div className="tw-p-3.5 sm:tw-p-5 tw-space-y-3 sm:tw-space-y-4">
                                        <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-2.5 sm:tw-gap-3">
                                            {/* auto-fill จาก Maximo — แก้ไขไม่ได้ (ซ่อนในโหมดกรอกชื่อเองเพราะไม่มีข้อมูล Maximo) */}
                                            {!!charger.maximo_location && (
                                                <>
                                                    <Input label={t.maximoLocation} value={charger.maximo_location} readOnly disabled className="!tw-bg-gray-50" crossOrigin={undefined} />
                                                    <Input label={t.maximoDesc} value={charger.maximo_desc} readOnly disabled className="!tw-bg-gray-50" crossOrigin={undefined} />
                                                </>
                                            )}
                                            <div className="tw-relative">
                                                <Input label={t.chargerNoAuto} type="number" value={charger.chargerNo} readOnly className="!tw-bg-gray-50" crossOrigin={undefined} />
                                                <span className="tw-absolute tw-right-3 tw-top-1/2 tw--translate-y-1/2 tw-text-[9px] tw-text-blue-gray-300 tw-font-medium">({t.auto})</span>
                                            </div>
                                            <Select label={t.chargerType} value={charger.chargerType} onChange={(v) => onChargerChange(charger.id, "chargerType", v ?? "DC")}>
                                                <Option value="DC">DC</Option>
                                                <Option value="AC">AC</Option>
                                            </Select>
                                             <Input label={t.brand} required value={charger.brand} onChange={(e) => onChargerChange(charger.id, "brand", e.target.value)} crossOrigin={undefined} />
                                             <Input label={t.vendor} value={charger.vendor} onChange={(e) => onChargerChange(charger.id, "vendor", e.target.value)} crossOrigin={undefined} />
                                             <Input label={t.model} required value={charger.model} onChange={(e) => onChargerChange(charger.id, "model", e.target.value)} crossOrigin={undefined} />
                                            <Input label={t.serialNumber} required value={charger.SN} onChange={(e) => onChargerChange(charger.id, "SN", e.target.value)} crossOrigin={undefined} />
                                            <Input label={t.power} required value={charger.power} onChange={(e) => onChargerChange(charger.id, "power", e.target.value)} crossOrigin={undefined} />
                                            {isFlexxfast(charger.brand) && (
                                                <>
                                                    <Input label={t.workOrder} value={charger.WO} onChange={(e) => onChargerChange(charger.id, "WO", e.target.value)} crossOrigin={undefined} />
                                                    <Input label={t.plcFirmware} required value={charger.PLCFirmware} onChange={(e) => onChargerChange(charger.id, "PLCFirmware", e.target.value)} crossOrigin={undefined} />
                                                    <Input label={t.piFirmware} required value={charger.PIFirmware} onChange={(e) => onChargerChange(charger.id, "PIFirmware", e.target.value)} crossOrigin={undefined} />
                                                    <Input label={t.routerFirmware} required value={charger.RTFirmware} onChange={(e) => onChargerChange(charger.id, "RTFirmware", e.target.value)} crossOrigin={undefined} />
                                                </>)}
                                            <Input
                                                label={t.commissioningDate}
                                                type="date"
                                                required
                                                value={charger.commissioningDate}
                                                onChange={(e) => onChargerChange(charger.id, "commissioningDate", e.target.value)}
                                                crossOrigin={undefined}
                                                containerProps={{ className: "!tw-min-w-0 tw-w-full" }}
                                                className="tw-w-full tw-min-w-0 tw-appearance-none"
                                            />
                                            <Input label={t.warrantyYears} type="number" min={1} max={10} required value={charger.warrantyYears} onChange={(e) => onChargerChange(charger.id, "warrantyYears", parseInt(e.target.value) || 1)} crossOrigin={undefined} />
                                            <Input label={t.numberOfCables} type="number" min={1} max={10} required value={charger.numberOfCables} onChange={(e) => onChargerChange(charger.id, "numberOfCables", parseInt(e.target.value) || 1)} crossOrigin={undefined} />
                                            <Select label={t.status} value={String(charger.is_active)} onChange={(v) => onChargerChange(charger.id, "is_active", v === "true")}>
                                                <Option value="true">{t.active}</Option>
                                                <Option value="false">{t.inactive}</Option>
                                            </Select>
                                        </div>

                                        {/* OCPP */}
                                        {/* {isFlexxfast(charger.brand) && ( */}
                                        <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                                            <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-purple-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">🔌 {t.ocppSection}</p>
                                            <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-2.5 sm:tw-gap-3">
                                                {/* Charge Box ID บังคับเฉพาะ Flexxfast — ให้ตรงกับ validation ตอน submit */}
                                                <Input label={t.chargerBoxId} required={isFlexxfast(charger.brand)} value={charger.chargeBoxID} onChange={(e) => onChargerChange(charger.id, "chargeBoxID", e.target.value)} crossOrigin={undefined} />
                                                <Input label={t.ocppUrl} value={charger.ocppUrl} onChange={(e) => onChargerChange(charger.id, "ocppUrl", e.target.value)} crossOrigin={undefined} />
                                            </div>
                                        </div>
                                        {/* )} */}

                                        {/* Charger images */}
                                        <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                                            <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">📷 {t.images}</p>
                                            <div className="tw-grid tw-grid-cols-1 tw-gap-2.5 sm:tw-grid-cols-2 sm:tw-gap-3">
                                                <ImageZone label={t.charger} previews={chargerPreviews[charger.id]?.charger || []} onUpload={(e) => handleChargerImage(charger.id, "charger", e)} onRemove={(i) => removeChargerImage(charger.id, "charger", i)} emptyLabel={t.noImages} uploadLabel={t.upload} />
                                                <ImageZone label={t.device} previews={chargerPreviews[charger.id]?.device || []} onUpload={(e) => handleChargerImage(charger.id, "device", e)} onRemove={(i) => removeChargerImage(charger.id, "device", i)} emptyLabel={t.noImages} uploadLabel={t.upload} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </section>
                        )}
                    </DialogBody>

                    {/* ══════ FOOTER ══════ */}
                    <DialogFooter className="tw-sticky tw-bottom-0 tw-z-10 tw-bg-white tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-4 tw-border-t tw-border-gray-200/80 tw-shrink-0">
                        <div className="tw-flex tw-w-full tw-flex-col sm:tw-flex-row tw-justify-between tw-items-center tw-gap-2.5 sm:tw-gap-0">
                            <span className="tw-inline-flex tw-items-center tw-gap-2 tw-px-3 sm:tw-px-3.5 tw-py-1.5 tw-rounded-full tw-bg-amber-50 tw-ring-1 tw-ring-amber-200/70">
                                <span className="tw-text-xs sm:tw-text-sm">⚡</span>
                                <span className="tw-text-[11px] sm:tw-text-xs tw-font-bold tw-text-amber-700">{chargers.length}</span>
                                <span className="tw-text-[11px] sm:tw-text-xs tw-text-amber-600/80">{t.chargerCount}</span>
                            </span>
                            <div className="tw-flex tw-gap-2 sm:tw-gap-2.5 tw-w-full sm:tw-w-auto">
                                <Button
                                    variant="outlined"
                                    onClick={resetAndClose}
                                    type="button"
                                    className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-border-gray-300 tw-text-gray-600 hover:tw-bg-gray-50 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-px-4 sm:tw-px-5 tw-py-2.5 sm:tw-py-2"
                                >
                                    {t.cancel}
                                </Button>
                                <Button
                                    type="submit"
                                    disabled={loading || submitting}
                                    className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-bg-gray-900 hover:tw-bg-black tw-shadow-lg tw-shadow-gray-900/20 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-tracking-wide tw-px-4 sm:tw-px-6 tw-py-2.5 sm:tw-py-2 disabled:tw-opacity-50 tw-transition-all tw-duration-200 hover:tw-shadow-xl"
                                >
                                    {loading || submitting
                                        ? <span className="tw-flex tw-items-center tw-justify-center tw-gap-2"><Spinner />{t.saving}</span>
                                        : t.createStation
                                    }
                                </Button>
                            </div>
                        </div>
                    </DialogFooter>
                </form>
            </Dialog>
        </>
    );
}
