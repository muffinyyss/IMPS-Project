"""PM Report routes for Chargers (SN-based)"""
from fastapi import APIRouter, HTTPException, Depends, Query, Request, UploadFile, File, Form, Path
from fastapi.responses import Response, JSONResponse, StreamingResponse
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from datetime import datetime, timedelta, timezone, date
from dateutil.relativedelta import relativedelta
from bson.objectid import ObjectId
from pymongo import ReturnDocument
from bson.errors import InvalidId
from bson.decimal128 import Decimal128
from zoneinfo import ZoneInfo
from typing import List, Dict, Any, Optional, Literal
import re, json, uuid, pathlib, secrets, os, asyncio
import zipfile

from config import (
    PMReportDB, PMUrlDB, charger_collection, station_collection,
    _validate_station_id, th_tz,
    MDBPMReportDB, MDBPMUrlDB, CCBPMReportDB, CCBPMUrlDB,
    CBBOXPMReportDB, CBBOXPMUrlDB, normalize_pm_date, _ensure_utc_iso,
)
from deps import UserClaims, get_current_user
from routers import pm_flow
from services import pm_maximo_out, pm_pdf
from uploads_access import assert_station_access, assert_sn_access
from routers.pm_helpers import (
    UPLOADS_ROOT,
    ALLOWED_EXTS,
    MAX_FILE_MB,
    _validate_sn,
    _safe_name,
    _ext,
    parse_iso_any_tz,
    get_pmreport_collection_for,
    get_pmurl_coll_upload,
    get_mdbpmreport_collection_for,
    get_mdbpmurl_coll_upload,
    get_ccbpmreport_collection_for,
    get_ccbpmurl_coll_upload,
    get_cbboxpmreport_collection_for,
    get_cbboxpmurl_coll_upload,
    get_stationpmreport_collection_for,
    get_stationpmurl_coll_upload,
    _get_collections_for_source,
    _latest_issue_id_anywhere,
    _next_issue_id,
    _next_issue_id_no_conflict,
    _latest_doc_name_from_pmreport,
    _latest_doc_name_anywhere,
    _next_year_seq,
    _resolve_issue_and_doc,
)

from PIL import Image
from image_convert import normalize_image_bytes, ImageConversionError
from io import BytesIO

import tempfile

# เดิมแต่ละ router มี resize_image_bytes ของตัวเอง (ซ้ำกัน 5 ที่) ซึ่ง `except: return data`
# กลืนเคส "เปิด HEIC ไม่ได้" ไปเงียบ ๆ ตอนนี้ย้ายไปรวมที่ image_convert.normalize_image_bytes
# ที่แปลงเป็น JPEG เสมอ และ raise เมื่อแปลงไม่ได้จริง ๆ
def resize_image_bytes(data: bytes, max_width: int = 1920, quality: int = 85) -> bytes:
    """คงชื่อเดิมไว้เผื่อมีโค้ดอื่นเรียก — ผลลัพธ์เป็น JPEG ที่เบราว์เซอร์เปิดได้เสมอ"""
    return normalize_image_bytes(data, max_width=max_width, quality=quality)[0]

router = APIRouter()

# ── Flow ใบงาน PM (charger) — ให้ตรงกับ CM ──
#   Maximo เปิดใบงาน → planner วางแผน (pm_maximo: planning_status)
#   → technician กรอก (draft) → กด finalize = "Wait for approve"
#   → planner/admin approve = "Closed" หรือ reject กลับไป "draft"
PM_STATUS_DRAFT = "draft"
PM_STATUS_WAIT_APPROVE = "Wait for approve"
PM_STATUS_CLOSED = "Closed"

# ด่านอนุมัติปิดงาน — ตั้งชื่อให้ตรงกับ CM เผื่ออนาคตมีด่านอนุมัติอื่นเพิ่ม
PM_STAGE_CLOSE_APPROVAL = "close_approval"

# ใบเก่าปิดด้วย "submitted" ก่อนมี flow อนุมัติ — นับเป็นปิดแล้วเวลาแสดงผล
PM_LEGACY_CLOSED_STATUS = "submitted"
PM_CLOSED_STATUSES = {PM_STATUS_CLOSED.lower(), PM_LEGACY_CLOSED_STATUS}

PM_APPROVE_ROLES: set[str] = {"admin", "planner"}


def _pm_status_or_conditions(status: str) -> list[dict]:
    """เงื่อนไข match status — รองรับหลายค่าคั่นด้วย , และเทียบแบบไม่สนตัวพิมพ์"""
    conds: list[dict] = []
    for w in (x.strip() for x in status.split(",")):
        if not w:
            continue
        conds.append({"status": {"$regex": f"^{re.escape(w)}$", "$options": "i"}})
        # "Closed" ต้องเห็นใบเก่าที่ยังเป็น submitted ด้วย
        if w.lower() == PM_STATUS_CLOSED.lower():
            conds.append({"status": PM_LEGACY_CLOSED_STATUS})
    return conds


def _assert_pm_approver(current: UserClaims) -> None:
    if (current.role or "").strip().lower() not in PM_APPROVE_ROLES:
        raise HTTPException(status_code=403, detail="Only planner or admin can approve")

async def _get_charger_by_sn(sn: str) -> dict:
    """Get charger document by SN, raise 404 if not found"""
    charger = charger_collection.find_one({"SN": sn})
    if not charger:
        raise HTTPException(status_code=404, detail=f"Charger with SN '{sn}' not found")
    return charger

def _compute_next_pm_date_str(pm_date_str: str | None) -> str | None:
    if not pm_date_str:
        return None
    try:
        d = datetime.fromisoformat(pm_date_str).date()
    except ValueError:
        return None
    next_d = d + relativedelta(months=+6)
    return next_d.isoformat()

async def _latest_pm_date_from_pmreport(sn: str) -> dict | None:
    _validate_sn(sn)
    coll = PMReportDB.get_collection(str(sn))

    pipeline = [
        {"$addFields": {
            "_ts": {
                "$ifNull": [
                    {
                        "$cond": [
                            {"$eq": [{"$type": "$timestamp"}, "string"]},
                            {"$dateFromString": {
                                "dateString": "$timestamp",
                                "timezone": "UTC",
                                "onError": None,
                                "onNull": None
                            }},
                            "$timestamp"
                        ]
                    },
                    {"$toDate": "$_id"}
                ]
            }
        }},
        {"$sort": {"_ts": -1, "_id": -1}},
        {"$limit": 1},
        {"$project": {"_id": 1, "pm_date": 1, "timestamp": 1}}
    ]

    cursor = coll.aggregate(pipeline)
    docs = await cursor.to_list(length=1)
    return docs[0] if docs else None

async def _pmreport_latest_core(sn: str, current: UserClaims):
    """Get latest PM report info for a charger by SN"""
    _validate_sn(sn)

    charger = await _get_charger_by_sn(sn)

    pi_fw  = charger.get("PIFirmware")
    plc_fw = charger.get("PLCFirmware")
    rt_fw  = charger.get("RTFirmware")
    station_id = charger.get("station_id")

    pm_latest = await _latest_pm_date_from_pmreport(sn)
    pm_date = pm_latest.get("pm_date") if pm_latest else None

    ts_raw = (pm_latest.get("timestamp") if pm_latest else None) or charger.get("createdAt")

    ts_dt = (parse_iso_any_tz(ts_raw) if isinstance(ts_raw, str)
             else (ts_raw if isinstance(ts_raw, datetime) else None))
    ts_utc = ts_dt.astimezone(ZoneInfo("UTC")).isoformat() if ts_dt else None
    ts_th  = ts_dt.astimezone(ZoneInfo("Asia/Bangkok")).isoformat() if ts_dt else None

    pm_next_date = _compute_next_pm_date_str(pm_date)

    return {
        "_id": str(charger["_id"]),
        "sn": sn,
        "station_id": station_id,
        "chargeBoxID": charger.get("chargeBoxID"),
        "pi_firmware": pi_fw,
        "plc_firmware": plc_fw,
        "rt_firmware": rt_fw,
        "pm_date": pm_date,
        "pm_next_date": pm_next_date,
        "timestamp": ts_raw,
        "timestamp_utc": ts_utc,
        "timestamp_th": ts_th,
        "source": "chargers + PMReportDB",
    }

def serialize_doc(doc):
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_doc(d) for d in doc]
    if isinstance(doc, dict):
        result = {}
        for k, v in doc.items():
            if isinstance(v, ObjectId):
                result[k] = str(v)
            elif isinstance(v, datetime):
                result[k] = v.isoformat()
            elif isinstance(v, Decimal128):
                result[k] = float(v.to_decimal())
            else:
                result[k] = serialize_doc(v)
        return result
    return doc

@router.get("/pmreport/get")
async def pmreport_get(sn: str, report_id: str, current: UserClaims = Depends(get_current_user)):
    coll = get_pmreport_collection_for(sn)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")
    doc = await coll.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")
    return serialize_doc(doc)


@router.get("/pmreport/list")
async def pmreport_list(
    sn: str = Query(...),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    status: str | None = Query(None, description="กรองตามสถานะ คั่นหลายค่าด้วย , เช่น 'draft,Wait for approve'"),
    current: UserClaims = Depends(get_current_user),
):
    """List PM reports for a charger by SN"""
    coll = get_pmreport_collection_for(sn)
    skip = (page - 1) * pageSize

    query: dict = {}
    if status and (conds := _pm_status_or_conditions(status)):
        query["$or"] = conds

    cursor = coll.find(query, {
        "_id": 1, "issue_id": 1, "doc_name": 1, "pm_date": 1, "inspector": 1, "wonum": 1,
        "side": 1, "has_photos": 1, "createdAt": 1,
        "status": 1, "stage": 1, "approved_by": 1, "approved_at": 1,
        "reject_remark": 1, "rejected_by": 1, "submittedAt": 1,
    }).sort(
        [("createdAt", -1), ("_id", -1)]
    ).skip(skip).limit(pageSize)
    items_raw = await cursor.to_list(length=pageSize)
    total = await coll.count_documents(query)

    pm_dates = [it.get("pm_date") for it in items_raw if it.get("pm_date")]
    urls_coll = get_pmurl_coll_upload(sn)
    url_by_day: dict[str, str] = {}

    if pm_dates:
        ucur = urls_coll.find({"pm_date": {"$in": pm_dates}}, {"pm_date": 1, "urls": 1})
        url_docs = await ucur.to_list(length=10_000)
        for u in url_docs:
            day = u.get("pm_date")
            first_url = (u.get("urls") or [None])[0]
            if day and first_url and day not in url_by_day:
                url_by_day[day] = first_url

    items = [{
        "id": str(it["_id"]),
        "issue_id": it.get("issue_id"),
        "doc_name": it.get("doc_name"),
        "pm_date": it.get("pm_date"),
        "inspector": it.get("inspector"),
        "side": it.get("side"),
        "createdAt": _ensure_utc_iso(it.get("createdAt")),
        "file_url": url_by_day.get(it.get("pm_date") or "", ""),
        "has_photos": True if it.get("has_photos") else None,
        # ใบเก่าไม่มี status เลย = ปิดไปแล้วก่อนมี flow อนุมัติ
        "status": it.get("status") or PM_LEGACY_CLOSED_STATUS,
        "stage": it.get("stage") or "",
        "wonum": it.get("wonum") or "",
        "approved_by": it.get("approved_by") or "",
        "approved_at": _ensure_utc_iso(it.get("approved_at")),
        "reject_remark": it.get("reject_remark") or "",
        "rejected_by": it.get("rejected_by") or "",
        "submittedAt": _ensure_utc_iso(it.get("submittedAt")),
    } for it in items_raw]

    pm_date_arr = [it.get("pm_date") for it in items_raw if it.get("pm_date")]
    return {"items": items, "pm_date": pm_date_arr, "page": page, "pageSize": pageSize, "total": total}


@router.get("/pmreport/latest/{sn:path}")
async def pmreport_latest_by_path(
    sn: str = Path(..., description="Charger Serial Number"),
    current: UserClaims = Depends(get_current_user),
):
    """Get latest PM info for a charger by SN (path param)"""
    return await _pmreport_latest_core(sn, current)

class PMMeasureRow(BaseModel):
    value: str = ""
    unit: str = "V"

class PMMeasures(BaseModel):
    m16: Dict[str, PMMeasureRow] = Field(default_factory=dict)
    cp: PMMeasureRow = PMMeasureRow()

class PMRowPF(BaseModel):
    pf: Optional[Literal["VERY_GOOD","GOOD","FAIR","UNUSABLE","PASS","FAIL","NA",""]] = ""
    remark: Optional[str] = ""

# ── ผูกกับใบ PM สถานี "ใบเดียว 5 ส่วน" ────────────────────────────
async def _job_link(station_id: str, job_id: str | None) -> dict:
    """ข้อมูลเลขที่เอกสารของใบแม่ — ไม่ได้ส่ง job_id มา = ใบเดี่ยวแบบเดิม คืน {}"""
    if not (job_id or "").strip() or not (station_id or "").strip():
        return {}
    from routers.pmreport_station_job import job_numbering
    return await job_numbering(station_id, job_id)


@router.get("/pmreport/preview-issueid")
async def pmreport_preview_issueid(
    sn: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Preview next issue_id without actually generating it"""
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    pm_type = "CG"
    latest = await _latest_issue_id_anywhere(sn, pm_type, d)

    yymm = f"{d.year % 100:02d}{d.month:02d}"
    prefix = f"PM-{pm_type}-{yymm}-"

    if not latest:
        next_issue = f"{prefix}01"
    else:
        m = re.search(r"(\d+)$", latest)
        cur = int(m.group(1)) if m else 0
        next_issue = f"{prefix}{cur+1:02d}"

    return {"issue_id": next_issue}

@router.get("/pmreport/latest-docname")
async def pmreport_latest_docname(
    sn: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Get latest doc_name for calculating next number at frontend"""
    latest = await _latest_doc_name_from_pmreport(sn, pm_date)
    return {
        "doc_name": latest.get("doc_name") if latest else None,
        "sn": sn,
        "pm_date": pm_date
    }

@router.get("/pmreport/preview-docname")
async def preview_docname(
    sn: str = Query(...),
    pm_date: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """Preview next doc_name without actually generating it"""
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")

    year = d.year
    latest = await _latest_doc_name_anywhere(sn, year)

    if not latest:
        next_doc = f"{sn}_1/{year}"
    else:
        m = re.search(r"_(\d+)/\d{4}$", latest)
        current_num = int(m.group(1)) if m else 0
        next_doc = f"{sn}_{current_num + 1}/{year}"

    return {"doc_name": next_doc}

class PMPostIn(BaseModel):
    report_id: str | None = None
    sn: str
    # ใบนี้เป็นส่วน Charger ของใบ PM สถานี "ใบเดียว 5 ส่วน" (stationPMJob) หรือไม่
    job_id: Optional[str] = None
    # เลขใบงาน Maximo — ปกติผูกไว้ตั้งแต่ Pre-PM รับตรงนี้ด้วยเผื่อใบเก่าที่ยังไม่มี
    wonum: Optional[str] = None
    # เวลาทำงานจริงของช่าง — ส่งเข้า Maximo ทาง IN09 ตอนปิดใบงาน
    # รูปแบบ datetime-local ของ input ("2026-08-18T09:30")
    work_start: Optional[str] = None
    work_finish: Optional[str] = None
    rows: dict
    measures: dict
    summary: str
    summaryCheck: str | None = None
    dust_filter: Dict[str, bool] | None = None
    side: Literal["post", "after"]
    # laborcode ฝั่ง Maximo ที่ช่างเลือกเอง (ใช้ส่งเวลาทำงาน IN09)
    maximo_labor: Optional[List[str]] = None
    maximo_contractor: Optional[str] = None
    # ── ข้อมูลหัวเอกสาร ────────────────────────────────────────────────
    # ฟอร์มกรอกรอบเดียวแล้ว (ไม่มีด่าน Pre-PM) /submit จึงเป็นตัวสร้างเอกสาร
    # เองเมื่อยังไม่มี report_id — ฟิลด์ชุดนี้เคยส่งมาที่ /pre/submit
    job: Optional[Dict[str, Any]] = None
    pm_date: Optional[str] = None
    issue_id: Optional[str] = None
    doc_name: Optional[str] = None
    inspector: Optional[str] = None

@router.post("/pmreport/submit")
async def pmreport_post_submit(
    body: PMPostIn,
    current: UserClaims = Depends(get_current_user)
):
    """Submit Post-PM report for a charger"""
    sn = body.sn.strip()
    coll = get_pmreport_collection_for(sn)
    db = coll.database
    url_coll = get_pmurl_coll_upload(sn)

    if body.report_id:
        try:
            oid = ObjectId(body.report_id)
        except InvalidId:
            raise HTTPException(status_code=400, detail="invalid report_id")

        existing = await coll.find_one({"_id": oid, "sn": sn})
        if not existing:
            raise HTTPException(status_code=404, detail="Report not found")

        # ปิดงานแล้วห้ามแก้ — ต้องให้ planner ตีกลับก่อนถึงจะกรอกใหม่ได้
        if str(existing.get("status") or "").strip().lower() in PM_CLOSED_STATUSES:
            raise HTTPException(status_code=409, detail="Report is already closed")

        update_fields = {
            "rows": body.rows,
            "measures": body.measures,
            "summary": body.summary,
            "summaryCheck": body.summaryCheck,
            "dust_filter": body.dust_filter,
            **pm_flow.post_submit_fields(body),
            **({"job_id": body.job_id} if body.job_id else {}),
            "side": "post",
            "timestamp_post": datetime.now(timezone.utc),
        }

        await coll.update_one({"_id": oid}, {"$set": update_fields})
        return {"ok": True, "report_id": body.report_id}

    charger = await _get_charger_by_sn(sn)

    # ผูกกับใบแม่แล้วต้องไม่ไปเขียนทับ draft ของใบอื่นของตู้เดียวกัน
    existing_draft = await coll.find_one(
        {"sn": sn, "job_id": body.job_id, "status": "draft"}
        if body.job_id else
        {"sn": sn, "side": "post", "status": "draft"},
        {"_id": 1},
        sort=[("timestamp", -1)],
    )

    update_fields = {
        "rows": body.rows,
        "measures": body.measures,
        "summary": body.summary,
        "summaryCheck": body.summaryCheck,
        "dust_filter": body.dust_filter,
        **pm_flow.post_submit_fields(body),
        **({"job_id": body.job_id} if body.job_id else {}),
        "side": "post",
        "timestamp_post": datetime.now(timezone.utc),
    }

    # หัวเอกสาร (เดิมบันทึกตอน Pre-PM) — ส่งมาเท่าไรเก็บเท่านั้น
    header: dict = {}
    if body.job is not None:
        header["job"] = {**body.job, "pm_type": str(body.job.get("pm_type") or "CG").upper()}
    if (body.pm_date or "").strip():
        header["pm_date"] = body.pm_date.strip()
    if body.inspector is not None:
        header["inspector"] = body.inspector

    if existing_draft:
        await coll.update_one({"_id": existing_draft["_id"]}, {"$set": {**update_fields, **header}})
        return {"ok": True, "report_id": str(existing_draft["_id"])}

    # ── ใบใหม่: จองเลข issue_id / doc_name ให้เลย ─────────────────────────
    pm_date = header.get("pm_date") or datetime.now(th_tz).strftime("%Y-%m-%d")
    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="pm_date must be YYYY-MM-DD")
    pm_type = str((header.get("job") or {}).get("pm_type") or "CG").upper()

    link = await _job_link(str(charger.get("station_id") or ""), body.job_id)
    if link:
        # ส่วน Charger ของใบ PM สถานีใบเดียว 5 ส่วน — ใช้เลขที่/ชื่อเอกสารของใบแม่
        issue_id, doc_name = link["issue_id"], link["doc_name"]
    else:
        issue_id, doc_name = await _resolve_issue_and_doc(
            coll, url_coll, db, sn, pm_type, d, body.issue_id, body.doc_name,
        )

    doc = {
        "sn": sn,
        "station_id": charger.get("station_id"),
        "chargeBoxID": charger.get("chargeBoxID"),
        "doc_name": doc_name,
        "issue_id": issue_id,
        "pm_date": pm_date,
        **update_fields,
        **header,
        **({"job_id": link["job_id"]} if link else {}),
        "photos": {},
        "status": "draft",
        "timestamp": datetime.now(timezone.utc),
    }
    res = await coll.insert_one(doc)
    return {
        "ok": True,
        "report_id": str(res.inserted_id),
        "issue_id": issue_id,
        "doc_name": doc_name,
    }


@router.post("/pmreport/{report_id}/post/photos")
async def pmreport_upload_post_photos(
    report_id: str,
    sn: str = Form(...),
    group: str = Form(...),
    files: list[UploadFile] = File(...),
    remark: str | None = Form(None),
    current: UserClaims = Depends(get_current_user),
):
    """Upload Post-PM photos for a charger report"""
    # ตรวจสิทธิ์สถานีก่อนแตะข้อมูล — เดิมเช็คแค่ว่า field ตรงกับ document
    # ซึ่งผู้เรียกคุมได้ทั้งคู่ จึงยิงข้ามสถานีได้
    assert_sn_access(current, sn)
    if not re.fullmatch(r"g\d+(_\d+)?", group):
        raise HTTPException(status_code=400, detail="Bad group key")

    coll = get_pmreport_collection_for(sn)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one({"_id": oid}, {"_id": 1, "sn": 1, f"photos.{group}": 1})
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")
    if doc.get("sn") != sn:
        raise HTTPException(status_code=400, detail="sn mismatch")

    MAX_PHOTOS_PER_GROUP = 10
    existing_count = len((doc.get("photos") or {}).get(group, []))
    remaining = MAX_PHOTOS_PER_GROUP - existing_count
    if remaining <= 0:
        return {"ok": True, "count": 0, "group": group, "files": [], "skipped": "group_full"}
    files = files[:remaining]

    dest_dir = pathlib.Path(UPLOADS_ROOT) / "pm" / sn / report_id / "post" / group
    dest_dir.mkdir(parents=True, exist_ok=True)

    saved = []
    for f in files:
        ext = _ext(f.filename or "")
        if ext not in ALLOWED_EXTS:
            raise HTTPException(status_code=400, detail=f"File type not allowed: {ext}")

        data = await f.read()
        if len(data) == 0:
            raise HTTPException(status_code=400, detail=f"Empty file: {f.filename}")
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"File too large (> {MAX_FILE_MB} MB)")

        # บังคับให้เป็น JPEG เสมอ — iPhone ส่ง HEIC มาซึ่ง Chrome/Edge/Firefox เปิดไม่ได้
        # ของเดิม (resize_image_bytes) เปิด HEIC ไม่ได้แล้วคืนไบต์เดิมเงียบ ๆ จึงได้ไฟล์
        # "ไบต์ HEIC ในชื่อ .jpg" ที่เปิดไม่ขึ้นทั้งบนเว็บและใน PDF
        try:
            data, out_ext = normalize_image_bytes(data, f.filename or "", max_width=1280, quality=75)
        except ImageConversionError as e:
            raise HTTPException(status_code=400, detail=str(e))

        out_ext = out_ext or "jpg"
        fname = _safe_name(f.filename or f"image_{secrets.token_hex(3)}.{out_ext}")
        fname = pathlib.Path(fname).stem + "." + out_ext
        path = dest_dir / fname
        with open(path, "wb") as out:
            out.write(data)

        url_path = f"/uploads/pm/{sn}/{report_id}/post/{group}/{fname}"
        saved.append({
            "filename": fname,
            "url": url_path,
            "remark": remark or "",
            "uploadedAt": datetime.now(timezone.utc)
        })

    await coll.update_one(
        {"_id": oid},
        {
            "$push": {f"photos.{group}": {"$each": saved}},
            "$set": {"has_photos": True},
        }
    )
    if not saved:
        raise HTTPException(status_code=400, detail="No files were saved")

    return {"ok": True, "count": len(saved), "group": group, "files": saved}


@router.post("/pmreport/{report_id}/finalize")
async def pmreport_finalize(report_id: str, sn: str = Form(...), current: UserClaims = Depends(get_current_user)):
    coll = get_pmreport_collection_for(sn)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one(
        {"_id": oid}, {"_id": 1, "status": 1, "work_start": 1, "work_finish": 1, "job_id": 1}
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")

    # เวลาทำงานเป็นข้อมูลที่ต้องส่งเข้า Maximo (IN09) — ขาดแล้วปิดงานไปก็ยิงไม่ได้
    # ใบลูกของใบ PM สถานี (มี job_id) กรอกครั้งเดียวตอนกด "ปิดใบงาน" ที่หน้ารวม
    if not doc.get("job_id") and (
        not str(doc.get("work_start") or "").strip() or not str(doc.get("work_finish") or "").strip()
    ):
        raise HTTPException(
            status_code=400,
            detail="กรุณากรอกเวลาเริ่มงานและเวลาเสร็จงานก่อนส่งปิดใบงาน",
        )

    # ปิดไปแล้วห้ามส่งซ้ำ — ไม่งั้นใบที่ planner อนุมัติแล้วจะเด้งกลับเข้าคิวรออนุมัติ
    if str(doc.get("status") or "").strip().lower() in PM_CLOSED_STATUSES:
        raise HTTPException(status_code=409, detail="Report is already closed")

    now = datetime.now(timezone.utc)
    res = await coll.update_one(
        {"_id": oid},
        {
            "$set": {
                # ช่างกรอกเสร็จ = เข้าคิวรอ planner อนุมัติ (ไม่ปิดงานเอง)
                "status": PM_STATUS_WAIT_APPROVE,
                "stage": PM_STAGE_CLOSE_APPROVAL,
                "submittedAt": now,
                "updatedAt": now,
            },
            # ส่งใหม่หลังโดนตีกลับ → ล้างเหตุผลเดิม ไม่ให้ค้างหลอกผู้อนุมัติ
            "$unset": {"reject_remark": "", "rejected_by": "", "rejected_at": ""},
        },
    )
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Report not found")

    for lang in ("th", "en"):
        cache_path = pathlib.Path(UPLOADS_ROOT) / "pdf_cache" / sn / f"{report_id}_{lang}.pdf"
        if cache_path.exists():
            cache_path.unlink()

    return {"ok": True}


@router.post("/pmreport/{report_id}/approve")
async def pmreport_approve(
    report_id: str,
    sn: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """planner/admin อนุมัติปิดใบงาน PM: "Wait for approve" → "Closed" """
    _assert_pm_approver(current)

    sn = sn.strip()
    coll = get_pmreport_collection_for(sn)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    now = datetime.now(timezone.utc)
    res = await coll.update_one(
        {
            "_id": oid,
            "sn": sn,
            "status": {"$regex": f"^{PM_STATUS_WAIT_APPROVE}$", "$options": "i"},
        },
        {
            "$set": {
                "status": PM_STATUS_CLOSED,
                "approved_by": current.username,
                "approved_at": now,
                "updatedAt": now,
            },
            "$unset": {"stage": "", "reject_remark": "", "rejected_by": "", "rejected_at": ""},
        },
    )
    if res.matched_count == 0:
        raise HTTPException(
            status_code=404,
            detail="Report not found or not in 'Wait for approve' status",
        )

    # ── ส่งต่อให้ Maximo (IN03 → IN09 → IN02 CLOSED) ──
    # อ่านใบงานหลังบันทึกเพื่อให้ข้อมูลที่ส่งไปตรงกับที่เก็บจริง
    fresh = await coll.find_one({"_id": oid}) or {}

    # ใบงานปิดแล้ว = เนื้อหานิ่ง สร้าง PDF เก็บไว้เลยตั้งแต่ตอนนี้
    # ลิงก์ที่ IN03 แนบเข้า Maximo จะได้เปิดปุ๊บได้ไฟล์ ไม่ใช่ให้คนกดเป็นคนรอเรนเดอร์
    pdf_result = await pm_pdf.ensure_report_pdf("charger", sn, report_id)

    # ใบงาน Maximo 1 ใบครอบหลายอุปกรณ์ — ปิดครบทุกตัวก่อนถึงจะยิงปิด WO
    progress = await pm_flow.wo_completion(fresh.get("wonum") or "")
    if not progress["complete"]:
        return {"ok": True, "status": PM_STATUS_CLOSED, "pdf": pdf_result,
                "maximo": {"skipped": "ยังกรอกไม่ครบทุกอุปกรณ์ในใบงาน"}, "progress": progress}

    maximo_result = await pm_maximo_out.safe_sync_closed(
        coll, oid, fresh, memo=f"closed by {current.username}", kind="charger"
    )

    return {"ok": True, "status": PM_STATUS_CLOSED, "pdf": pdf_result, "maximo": maximo_result, "progress": progress}


class PMRejectIn(BaseModel):
    remark: str = Field(..., min_length=1, description="เหตุผลที่ตีกลับ — ช่างต้องรู้ว่าต้องแก้อะไร")


@router.post("/pmreport/{report_id}/reject")
async def pmreport_reject(
    report_id: str,
    body: PMRejectIn,
    sn: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """planner/admin ตีกลับใบงาน PM ให้ช่างแก้: "Wait for approve" → "draft" """
    _assert_pm_approver(current)

    remark = body.remark.strip()
    if not remark:
        raise HTTPException(status_code=400, detail="remark is required")

    sn = sn.strip()
    coll = get_pmreport_collection_for(sn)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    now = datetime.now(timezone.utc)
    res = await coll.update_one(
        {
            "_id": oid,
            "sn": sn,
            "status": {"$regex": f"^{PM_STATUS_WAIT_APPROVE}$", "$options": "i"},
        },
        {
            "$set": {
                # กลับเป็น draft = ช่างคนเดิมเปิดฟอร์มแก้ต่อได้เหมือนเดิม
                "status": PM_STATUS_DRAFT,
                "reject_remark": remark,
                "rejected_by": current.username,
                "rejected_at": now,
                "updatedAt": now,
            },
            "$unset": {"stage": "", "submittedAt": ""},
        },
    )
    if res.matched_count == 0:
        raise HTTPException(
            status_code=404,
            detail="Report not found or not in 'Wait for approve' status",
        )

    return {"ok": True, "status": PM_STATUS_DRAFT}


def parse_report_date_to_utc(s: str) -> datetime:
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
        tz_th = ZoneInfo("Asia/Bangkok")
        dt_th = datetime.fromisoformat(s + "T00:00:00").replace(tzinfo=tz_th)
        return dt_th.astimezone(timezone.utc)
    if s.endswith("Z"):
        return datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(timezone.utc)
    if re.search(r"[+\-]\d{2}:\d{2}$", s):
        return datetime.fromisoformat(s).astimezone(timezone.utc)
    return datetime.fromisoformat(s + "+07:00").astimezone(timezone.utc)

@router.post("/pmurl/upload-files", status_code=201)
async def pmurl_upload_files(
    sn: str = Form(...),
    reportDate: str = Form(...),
    files: list[UploadFile] = File(...),
    issue_id: Optional[str] = Form(None),
    doc_name: Optional[str] = Form(None),
    inspector: Optional[str] = Form(None),
    current: UserClaims = Depends(get_current_user),
):
    """Upload PM PDF files for a charger"""
    # ตรวจสิทธิ์สถานีก่อนแตะข้อมูล — เดิมเช็คแค่ว่า field ตรงกับ document
    # ซึ่งผู้เรียกคุมได้ทั้งคู่ จึงยิงข้ามสถานีได้
    assert_sn_access(current, sn)
    charger = await _get_charger_by_sn(sn)
    station_id = charger.get("station_id")

    coll = get_pmurl_coll_upload(sn)
    pm_date = normalize_pm_date(reportDate)

    try:
        d = datetime.strptime(pm_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="reportDate/pm_date must be YYYY-MM-DD")

    pm_type = "CG"

    rep_coll = get_pmreport_collection_for(sn)
    final_issue_id: str | None = None
    client_issue = (issue_id or "").strip()

    if client_issue:
        yymm = f"{d.year % 100:02d}{d.month:02d}"
        prefix = f"PM-{pm_type}-{yymm}-"
        valid_fmt = client_issue.startswith(prefix)

        url_exists = await coll.find_one({"issue_id": client_issue})
        rep_exists = await rep_coll.find_one({"issue_id": client_issue})
        unique = not (url_exists or rep_exists)

        if valid_fmt and unique:
            final_issue_id = client_issue

    if not final_issue_id:
        final_issue_id = await _next_issue_id_no_conflict(
            coll.database, rep_coll, coll, sn, pm_type, d, pad=2
        )

    year_seq: int | None = None

    rep = await get_pmreport_collection_for(sn).find_one(
        {"issue_id": final_issue_id},
        {"year_seq": 1, "pm_date": 1},
    )
    if rep and rep.get("year_seq") is not None:
        year_seq = int(rep["year_seq"])

    if year_seq is None:
        year_seq = await _next_year_seq(coll.database, sn, pm_type, d)

    year = d.year
    final_doc_name: str | None = None

    if doc_name:
        candidate = doc_name.strip()
        ok_format = candidate.startswith(f"{sn}_")

        rep_exists = await rep_coll.find_one({"doc_name": candidate})
        url_exists = await coll.find_one({"doc_name": candidate})
        unique = not (rep_exists or url_exists)

        if ok_format and unique:
            final_doc_name = candidate

    if not final_doc_name:
        final_doc_name = f"{sn}_{year_seq}/{year}"

    doc_name = final_doc_name

    subdir = pm_date
    dest_dir = pathlib.Path(UPLOADS_ROOT) / "pmurl" / sn / subdir
    dest_dir.mkdir(parents=True, exist_ok=True)

    urls: list[str] = []
    metas: list[dict] = []
    total_size = 0

    for f in files:
        ext = (f.filename.rsplit(".", 1)[-1].lower() if f.filename and "." in f.filename else "")
        if ext != "pdf":
            raise HTTPException(status_code=400, detail=f"Only PDF allowed, got: {ext}")

        data = await f.read()
        if len(data) == 0:
            raise HTTPException(status_code=400, detail=f"Empty file: {f.filename}")
        if not data[:5].startswith(b"%PDF-"):
            raise HTTPException(status_code=400, detail=f"Invalid PDF file: {f.filename}")
        total_size += len(data)
        if len(data) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"File too large (> {MAX_FILE_MB} MB)")

        safe = _safe_name(f.filename or f"file_{secrets.token_hex(3)}.pdf")
        dest = dest_dir / safe
        with open(dest, "wb") as out:
            out.write(data)

        url = f"/uploads/pmurl/{sn}/{subdir}/{safe}"
        urls.append(url)
        metas.append({"name": f.filename, "size": len(data)})

    inspector_clean = (inspector or "").strip() or None

    now = datetime.now(timezone.utc)
    doc = {
        "sn": sn,
        "station_id": station_id,
        "chargeBoxID": charger.get("chargeBoxID"),
        "pm_date": pm_date,
        "issue_id": final_issue_id,
        "inspector": inspector_clean,
        "year": year,
        "year_seq": year_seq,
        "doc_name": doc_name,
        "urls": urls,
        "meta": {"files": metas},
        "source": "upload-files",
        "createdAt": now,
        "updatedAt": now,
    }
    res = await coll.insert_one(doc)

    return {
        "ok": True,
        "inserted_id": str(res.inserted_id),
        "count": len(urls),
        "urls": urls,
        "issue_id": final_issue_id,
        "year_seq": year_seq,
        "doc_name": doc_name,
        "inspector": inspector_clean,
    }


@router.get("/pmurl/list")
async def pmurl_list(
    sn: str = Query(...),
    page: int = Query(1, ge=1),
    pageSize: int = Query(20, ge=1, le=100),
    current: UserClaims = Depends(get_current_user),
):
    """List PM URL documents for a charger"""
    coll = get_pmurl_coll_upload(sn)
    skip = (page - 1) * pageSize

    cursor = coll.find(
        {},
        {"_id": 1, "issue_id": 1, "doc_name": 1, "inspector": 1, "pm_date": 1, "reportDate": 1, "urls": 1, "createdAt": 1}
    ).sort([("createdAt", -1), ("_id", -1)]).skip(skip).limit(pageSize)

    items_raw = await cursor.to_list(length=pageSize)
    total = await coll.count_documents({})

    def _pm_date_from(doc: dict) -> str | None:
        s = doc.get("pm_date")
        if isinstance(s, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}$", s):
            return s
        rd = doc.get("reportDate")
        if isinstance(rd, datetime):
            return rd.astimezone(th_tz).date().isoformat()
        if isinstance(rd, str):
            try:
                dt = datetime.fromisoformat(rd.replace("Z", "+00:00"))
            except Exception:
                try:
                    dt = datetime.fromisoformat(rd).replace(tzinfo=th_tz)
                except Exception:
                    return None
            return dt.astimezone(th_tz).date().isoformat()
        return None

    items = []
    pm_date_arr = []

    for it in items_raw:
        pm_date_str = _pm_date_from(it)
        if pm_date_str:
            pm_date_arr.append(pm_date_str)

        urls = it.get("urls") or []
        first_url = urls[0] if urls else ""

        items.append({
            "id": str(it["_id"]),
            "pm_date": pm_date_str,
            "inspector": it.get("inspector"),
            "doc_name": it.get("doc_name"),
            "issue_id": it.get("issue_id"),
            "createdAt": _ensure_utc_iso(it.get("createdAt")),
            "file_url": first_url,
            "urls": urls,
        })

    return {
        "items": items,
        "pm_date": [d for d in pm_date_arr if d],
        "page": page,
        "pageSize": pageSize,
        "total": total,
    }


@router.post("/pmreport/migrate/has-photos")
async def migrate_has_photos_endpoint(
    sn: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    """One-time migration: set has_photos=True for docs that have photos but missing the flag"""
    coll = get_pmreport_collection_for(sn)
    result = await coll.update_many(
        {
            "has_photos": {"$exists": False},
            "$or": [
                {"photos_pre": {"$ne": {}, "$exists": True}},
                {"photos": {"$ne": {}, "$exists": True}},
            ]
        },
        {"$set": {"has_photos": True}}
    )
    return {"ok": True, "modified": result.modified_count}



@router.get("/pmreport/{report_id}/photos/zip")
async def download_photos_zip(
    report_id: str,
    sn: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    coll = get_pmreport_collection_for(sn)
    try:
        oid = ObjectId(report_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad report_id")

    doc = await coll.find_one(
        {"_id": oid, "sn": sn},
        {"photos_pre": 1, "photos": 1, "has_photos": 1}
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Report not found")

    if not doc.get("has_photos"):
        raise HTTPException(status_code=404, detail="No photos found")

    # รวม photos_pre และ photos เข้าด้วยกัน
    all_photos: list[tuple[str, str]] = []  # (zip_path, disk_path)

    photos_pre: dict = doc.get("photos_pre") or {}
    for group, items in photos_pre.items():
        for item in (items or []):
            fname = item.get("filename", "")
            if not fname:
                continue
            disk_path = pathlib.Path(UPLOADS_ROOT) / "pm" / sn / report_id / "pre" / group / fname
            zip_path = f"pre/{group}/{fname}"
            all_photos.append((zip_path, str(disk_path)))

    photos_post: dict = doc.get("photos") or {}
    for group, items in photos_post.items():
        for item in (items or []):
            fname = item.get("filename", "")
            if not fname:
                continue
            disk_path = pathlib.Path(UPLOADS_ROOT) / "pm" / sn / report_id / "post" / group / fname
            zip_path = f"post/{group}/{fname}"
            all_photos.append((zip_path, str(disk_path)))

    if not all_photos:
        raise HTTPException(status_code=404, detail="No photos found")

    # สร้าง ZIP ใน memory
    zip_buffer = BytesIO()
    written = 0
    with zipfile.ZipFile(zip_buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for zip_path, disk_path in all_photos:
            p = pathlib.Path(disk_path)
            if p.exists():
                zf.write(p, arcname=zip_path)
                written += 1

    if written == 0:
        raise HTTPException(status_code=404, detail="Photo files not found on disk")

    zip_buffer.seek(0)
    
    zip_filename = f"photos_{sn}_{report_id}.zip"

    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{zip_filename}"'},
    )
