"""Station & Charger CRUD routes"""
from fastapi import APIRouter, HTTPException, Depends, Query, Request, Path, UploadFile, File, Form
from fastapi.responses import Response, JSONResponse
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from datetime import datetime, timezone
from bson.objectid import ObjectId
from bson.errors import InvalidId
from zoneinfo import ZoneInfo
from pymongo.errors import DuplicateKeyError, OperationFailure
from typing import List, Dict, Any, Optional
import asyncio, json, re, uuid, pathlib, secrets
from image_convert import normalize_image_bytes, ImageConversionError
from config import (
    users_collection, station_collection, charger_collection,
    charger_onoff, charger_onoff_sync, _validate_station_id, th_tz, settingDB, settingDB_sync,
    CBM_DB, ALL_STATIONS_ROLES,
)
from deps import UserClaims, get_current_user
from brand_scope import (
    brand_regex, assert_charger_in_scope, brand_scope_of, filter_chargers,
    station_brand_clause,
)
from routers.pm_helpers import (
    UPLOADS_ROOT,
)
from services.unified_migration import UNIFIED_NAMES, unified_sort

router = APIRouter()

@router.get("/stations/")
async def get_stations(q: str = ""):
    query = {"station_name": {"$regex": q, "$options": "i"}} if q else {}
    stations = station_collection.find(query, {"_id": 0, "station_name": 1})
    return [station["station_name"] for station in stations]


@router.get("/owner/stations/")
async def get_owner_stations(q: str = "", current: UserClaims = Depends(get_current_user)):
    user_obj_id = ObjectId(current.user_id)
    user = users_collection.find_one({"_id": user_obj_id}, {"station_id": 1})
    if not user or "station_id" not in user:
        return []
    station_ids = user["station_id"]
    query_filter = {"station_id": {"$in": station_ids}}
    if q:
        query_filter["station_name"] = {"$regex": q, "$options": "i"}
    stations = station_collection.find(query_filter, {"_id": 0, "station_name": 1, "station_id": 1})
    return [{"station_name": s["station_name"], "station_id": s["station_id"]} for s in stations]


@router.get("/selected/station/{station_id}")
async def get_station_detail(station_id: str, current: UserClaims = Depends(get_current_user)):
    station = station_collection.find_one({"station_id": station_id})
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")
    return jsonable_encoder(
        station,
        custom_encoder={ObjectId: str, datetime: lambda v: v.isoformat()}
    )


def parse_iso_utc(s: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


def to_object_id_or_400(s: str) -> ObjectId:
    try:
        return ObjectId(s)
    except Exception:
        raise HTTPException(status_code=400, detail="invalid user_id")


@router.get("/owners")
async def get_owners(current: UserClaims = Depends(get_current_user)):
    if current.role != "admin":
        raise HTTPException(status_code=403, detail="forbidden")
    cursor = users_collection.find({"role": "owner"}, {"_id": 1, "username": 1})
    owners = [{"user_id": str(u["_id"]), "username": u["username"]} for u in cursor]
    if not owners:
        raise HTTPException(status_code=404, detail="owners not found")
    return {"owners": owners}


@router.get("/maximo/locations")
async def get_maximo_locations(
    level: str = Query("charger", description="ระดับ location: 'station' (ไม่มี -EV ต่อท้าย) หรือ 'charger' (มี -EV)"),
    current: UserClaims = Depends(get_current_user),
):
    """
    ดึงรายการ Maximo location สำหรับ dropdown (location + description)

    - level=charger : location ที่มี -EV (เช่น HMP0002-EV-BTL01GU001) — ค่า default
    - level=station : station root ที่ไม่มี -EV ต่อท้าย (เช่น HMP0002)
                      derive จาก prefix ของ EV-family แล้ว query description กลับ
    """
    from services.maximo import (
        query_locations, query_locations_by_codes, MAXIMO_ENABLED,
    )

    if not MAXIMO_ENABLED:
        return {"enabled": False, "locations": []}

    # EV-family (ทุก location ที่มี -EV)
    ev_members = await query_locations("%-EV%")
    if ev_members is None:
        raise HTTPException(status_code=502, detail="Maximo query failed")

    if level == "station":
        # station code = ส่วนหน้าก่อน "-EV" (เช่น "HMP0002-EV-BTL01..." -> "HMP0002")
        codes = sorted({
            (m.get("location") or "").split("-EV")[0]
            for m in ev_members
            if "-EV" in (m.get("location") or "")
        } - {""})
        members = await query_locations_by_codes(codes)
        if members is None:
            raise HTTPException(status_code=502, detail="Maximo query failed")
    else:
        members = ev_members

    locations = [
        {"location": m.get("location", ""), "description": m.get("description", "")}
        for m in members
        if m.get("location")
    ]
    return {"enabled": True, "locations": locations}


# description ของตู้ชาร์จใน Maximo เช่น "DC Charger 150kW", "AC Charger 22kW 1"
MAXIMO_CHARGER_DESC_RE = re.compile(r"^(AC|DC)\s*Charger\s*([\d.]+)\s*kW", re.IGNORECASE)


def maximo_charger_name(location: str) -> str:
    """ชื่อตู้ชาร์จ = segment ท้ายของ Maximo location เช่น "PTG0001-EV-BTL01GU201" → "BTL01GU201" """
    loc = (location or "").strip()
    return loc.split("-EV-")[-1] if "-EV-" in loc else ""


@router.get("/maximo/locations/{station_code}/chargers")
async def get_maximo_station_chargers(
    station_code: str = Path(..., description="Maximo station code เช่น 'PTG0001' หรือ 'PTG0001-EV'"),
    current: UserClaims = Depends(get_current_user),
):
    """
    ดึงรายการตู้ชาร์จ (…-EV-BTLxxGUxxx) ใต้ station ที่เลือก สำหรับ auto-fill
    ฟอร์ม Add Station — พร้อม charger_type (AC/DC) และ power_kw ที่ parse จาก description
    """
    from services.maximo import query_charger_locations, MAXIMO_ENABLED

    if not MAXIMO_ENABLED:
        return {"enabled": False, "chargers": []}

    members = await query_charger_locations(station_code)
    if members is None:
        raise HTTPException(status_code=502, detail="Maximo query failed")

    chargers = []
    for m in members:
        desc = (m.get("description") or "").strip()
        match = MAXIMO_CHARGER_DESC_RE.match(desc)
        location = m.get("location", "")
        chargers.append({
            "location": location,
            "name": maximo_charger_name(location),  # เช่น BTL01GU201
            "description": desc,
            "charger_type": match.group(1).upper() if match else "",
            "power_kw": match.group(2) if match else "",
        })

    # เรียงตามหมายเลขตู้แบบ natural sort (BTL01GU101 → 1, BTL01GU102 → 2, ...)
    # เพื่อให้ chargerNo ในฟอร์ม Add Station ตรงกับหมายเลขตู้จริงเสมอ
    def charger_order(c: dict):
        return ([int(n) for n in re.findall(r"\d+", c["name"])], c["location"])

    chargers.sort(key=charger_order)
    return {"enabled": True, "chargers": chargers}


# ============================================================
# Lecture groupée des bases « 1 collection par SN »
# ============================================================
# edgeboxStatus et settingParameter gardent une collection par numéro de série.
# Lire le dernier document de N séries coûte N commandes Mongo — c'est ce qui
# reste le plus cher sur la page Stations, qui rejoue ces lectures toutes les 10 s.
# $unionWith (MongoDB 4.4+) permet de les lire en une seule commande par paquet.
#
# La version du serveur de production n'est pas vérifiable depuis le réseau de
# développement (port 27017 filtré) : plutôt que de la supposer, on tente
# l'agrégation et on retombe définitivement sur la lecture unitaire si le serveur
# refuse l'étage. Le résultat est identique dans les deux cas.

_UNION_CHUNK = 120           # collections par agrégation (limite serveur : 1000 étages)
_union_supported: Optional[bool] = None      # None = pas encore éprouvé

# Migration « 1 collection par SN » → « 1 collection + champ sn ».
# Tant qu'elle n'a pas eu lieu, ces collections n'existent pas et on lit comme avant.
# Dès qu'elles existent, une seule commande suffit pour toutes les séries, et le
# nombre de commandes cesse de croître avec le parc. La bascule est automatique :
# services/unified_migration.py, lancé au démarrage puis entretenu en tâche de fond.
_unified_ready: Dict[str, bool] = {}          # par base, éprouvé une fois par processus

# champs ajoutés par la copie, à ne jamais renvoyer au client
_UNIFIED_EXTRA = ("_id", "sn", "_src")


def _apply_projection(doc: dict, projection: Optional[dict]) -> dict:
    """Reproduit la projection Mongo côté Python, pour que les trois chemins de
    lecture renvoient exactement le même document."""
    out = {k: v for k, v in doc.items() if k not in _UNIFIED_EXTRA}
    if not projection:
        return out
    include = [k for k, v in projection.items() if k != "_id" and v]
    if include:
        return {k: out[k] for k in include if k in out}
    return out


async def _latest_from_unified(
    db, names: List[str], sort: Dict[str, int], projection: Optional[dict]
) -> Optional[Dict[str, dict]]:
    """Dernier document de chaque SN depuis la collection unifiée — une commande.

    Renvoie None quand la migration n'a pas (encore) eu lieu pour cette base :
    l'appelant retombe alors sur les collections par SN.
    """
    unified = UNIFIED_NAMES.get(db.name)
    if unified is None:
        return None

    ready = _unified_ready.get(db.name)
    if ready is False:
        return None
    if ready is None:
        try:
            found = await db.list_collection_names(filter={"name": unified})
        except Exception as e:
            print(f"[unified] {db.name}: impossible de vérifier {unified} ({e})")
            return None
        ready = bool(found)
        _unified_ready[db.name] = ready
        if not ready:
            return None

    try:
        cursor = db[unified].aggregate([
            {"$match": {"sn": {"$in": names}}},
            {"$sort": {"sn": 1, **unified_sort(sort)}},
            {"$group": {"_id": "$sn", "doc": {"$first": "$$ROOT"}}},
        ])
        out: Dict[str, dict] = {}
        async for row in cursor:
            doc = row.get("doc") or {}
            sn = doc.pop("sn", None)
            if sn is not None:
                out[sn] = _apply_projection(doc, projection)
        if not out:
            # Aucun document alors qu'on demandait des séries. Cas normal sur un parc
            # neuf, mais c'est aussi ce qu'on obtient si la collection unifiée a été
            # supprimée (une agrégation sur une collection absente ne lève rien, elle
            # renvoie du vide) ou si le pipeline a cessé de l'alimenter. Sans ce
            # garde-fou, tous les chargeurs passeraient « hors ligne » en silence.
            # On réexamine l'existence et on laisse l'appelant lire les collections
            # par SN pour cette requête.
            _unified_ready.pop(db.name, None)
            print(f"[unified] {db.name}.{unified} n'a rien renvoyé pour "
                  f"{len(names)} série(s) — lecture par SN pour cette requête")
            return None
        return out
    except Exception as e:
        # la collection existe mais la lecture échoue : ne pas condamner la requête
        print(f"[unified] {db.name}.{unified} illisible ({e}) — repli sur les collections par SN")
        return None



def _union_pipeline(names: List[str], sort: Dict[str, int], projection: Optional[dict]):
    """Agrégation qui renvoie le 1er document de chaque collection, étiqueté par __coll."""
    def leg(name: str):
        stages: List[Dict[str, Any]] = [{"$sort": sort}, {"$limit": 1}]
        if projection:
            stages.append({"$project": projection})
        stages.append({"$addFields": {"__coll": name}})
        return stages

    pipeline = leg(names[0])
    for name in names[1:]:
        pipeline.append({"$unionWith": {"coll": name, "pipeline": leg(name)}})
    return pipeline


async def _latest_by_collection(
    db,
    names,
    sort: Dict[str, int],
    projection: Optional[dict] = None,
) -> Dict[str, dict]:
    """{nom de collection: dernier document} — collections vides absentes du résultat.

    Équivalent strict de `find_one(sort=...)` sur chaque collection, mais en une
    commande par paquet de _UNION_CHUNK quand le serveur supporte $unionWith.
    """
    global _union_supported
    names = list(dict.fromkeys(names))       # dédoublonne en gardant l'ordre
    if not names:
        return {}

    # 1) collection unifiée : une commande, quel que soit le nombre de séries
    unified = await _latest_from_unified(db, names, sort, projection)
    if unified is not None:
        return unified

    # 2) et 3) collections par SN. On écarte d'abord celles qui n'existent pas :
    # le résultat est le même (pas de collection = pas de document) pour beaucoup
    # moins de travail. Si la question échoue, on interroge tout, comme avant.
    try:
        have = set(await db.list_collection_names())
        names = [n for n in names if n in have]
    except Exception as e:
        print(f"[union] {db.name}: list_collection_names indisponible ({e}) — on interroge tout")
    if not names:
        return {}

    if _union_supported is not False:
        try:
            out: Dict[str, dict] = {}
            for i in range(0, len(names), _UNION_CHUNK):
                chunk = names[i:i + _UNION_CHUNK]
                cursor = db[chunk[0]].aggregate(_union_pipeline(chunk, sort, projection))
                async for doc in cursor:
                    name = doc.pop("__coll", None)
                    if name is not None:
                        out[name] = doc
            _union_supported = True
            return out
        except OperationFailure as e:
            # serveur < 4.4, ou $unionWith interdit par la configuration
            _union_supported = False
            print(f"[union] $unionWith indisponible ({e}) — repli sur la lecture unitaire")
        except Exception as e:
            # panne ponctuelle : on sert la requête en cours par le repli sans
            # condamner le chemin rapide pour tout le processus
            print(f"[union] agrégation échouée ({e}) — repli sur la lecture unitaire")

    sem = asyncio.Semaphore(40)

    async def one(name: str):
        async with sem:
            try:
                return name, await db[name].find_one({}, projection, sort=list(sort.items()))
            except Exception as e:
                print(f"[union] lecture de {name} échouée: {e}")
                return name, None

    pairs = await asyncio.gather(*(one(n) for n in names))
    return {n: d for n, d in pairs if d is not None}


def _onoff_from_doc(doc: Optional[dict]) -> Dict[str, Any]:
    """Interprète un document edgeboxStatus — seule définition du statut on/off."""
    if not doc:
        return {"status": None, "statusAt": None}
    val = doc.get("status", None)
    ts = doc.get("timestamp", None)
    if isinstance(val, (int, bool)):
        status = bool(val)
    else:
        try:
            status = bool(int(val))
        except Exception:
            status = None
    status_at = parse_iso_utc(ts) if isinstance(ts, str) else None
    return {"status": status, "statusAt": status_at}


_ONOFF_SORT = {"timestamp": -1, "_id": -1}
_ONOFF_PROJECTION = {"_id": 0, "status": 1, "timestamp": 1}


async def latest_onoff(sn: str) -> Dict[str, Any]:
    try:
        coll = charger_onoff[sn]
        docs = await coll.find().sort([("timestamp", -1), ("_id", -1)]).limit(1).to_list(length=1)
        return _onoff_from_doc(docs[0] if docs else None)
    except Exception as e:
        print(f"[latest_onoff] Error for SN {sn}: {e}")
        return {"status": None, "statusAt": None}


@router.get("/charger-onoff/bulk")
async def station_onoff_bulk(current: UserClaims = Depends(get_current_user)):
    """
    สถานะ on/off ล่าสุดของตู้ทุกตัวที่ user มองเห็น ในคำขอเดียว
    (แทนการยิง /charger-onoff/{sn} ทีละตู้จากหน้า Stations — ช้ามากเมื่อมีหลายร้อยตู้)
    """
    match_query = station_match_query(current)
    if match_query is None:
        return {"statuses": {}}

    charger_query: Dict[str, Any] = {}
    if match_query:  # ไม่ใช่ admin — จำกัดเฉพาะสถานีที่มองเห็น
        station_ids = [
            s["station_id"]
            for s in station_collection.find(match_query, {"_id": 0, "station_id": 1})
        ]
        if not station_ids:
            return {"statuses": {}}
        charger_query = {"station_id": {"$in": station_ids}}

    sns = sorted({
        (c.get("SN") or "").strip()
        for c in charger_collection.find(charger_query, {"_id": 0, "SN": 1})
    } - {"", "-"})

    # _latest_by_collection choisit la source (collection unifiée, $unionWith, ou une
    # lecture par SN) et écarte lui-même les séries sans collection. Ne pas filtrer ici :
    # après migration les collections par SN n'existent plus, le filtre viderait la liste.
    docs = await _latest_by_collection(charger_onoff, sns, _ONOFF_SORT, _ONOFF_PROJECTION)

    # ต้องคง key ของทุก SN ไว้ ไม่ใช่เฉพาะที่ query — ฝั่งหน้าเว็บแยก "ไม่มีข้อมูล"
    # (undefined → ไม่แตะค่าเดิม) ออกจาก "รายงานว่าออฟไลน์" (status null → false)
    statuses = {sn: {"status": None, "statusAt": None} for sn in sns}
    for sn in sns:
        data = _onoff_from_doc(docs.get(sn))
        status_at = data["statusAt"]
        statuses[sn] = {
            "status": data["status"],
            "statusAt": status_at.astimezone(ZoneInfo("Asia/Bangkok")).isoformat() if status_at else None,
        }
    return {"statuses": statuses}


@router.get("/charger-onoff/{sn}")
async def station_onoff_latest(sn: str, current: UserClaims = Depends(get_current_user)):
    data = await latest_onoff(str(sn))
    status_at_iso = (
        data["statusAt"].astimezone(ZoneInfo("Asia/Bangkok")).isoformat()
        if data["statusAt"] else None
    )
    return {"sn": sn, "status": data["status"], "statusAt": status_at_iso}


def parse_iso_any_tz(s: str) -> datetime | None:
    if not isinstance(s, str):
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        try:
            return datetime.fromisoformat(s + "+00:00")
        except Exception:
            return None


# ============================================================
# Models
# ============================================================

class ChargerCreate(BaseModel):
    chargeBoxID: Optional[str] = ""
    chargerNo: Optional[int] = None
    brand: str
    manufacturer: Optional[str] = ""
    vendor: Optional[str] = ""
    model: str
    SN: str
    WO: Optional[str] = ""
    power: Optional[str] = ""
    PLCFirmware: Optional[str] = ""
    PIFirmware: Optional[str] = ""
    RTFirmware: Optional[str] = ""
    commissioningDate: Optional[str] = None
    warrantyYears: Optional[int] = 1
    numberOfCables: Optional[int] = 1
    is_active: Optional[bool] = True
    maximo_location: Optional[str] = ""
    maximo_desc: Optional[str] = ""
    ocppUrl: Optional[str] = ""
    chargerType: Optional[str] = "DC"

class ChargerUpdate(BaseModel):
    chargeBoxID: Optional[str] = None
    chargerNo: Optional[int] = None
    brand: Optional[str] = None
    manufacturer: Optional[str] = None
    vendor: Optional[str] = None
    model: Optional[str] = None
    SN: Optional[str] = None
    WO: Optional[str] = None
    power: Optional[str] = None
    PLCFirmware: Optional[str] = None
    PIFirmware: Optional[str] = None
    RTFirmware: Optional[str] = None
    commissioningDate: Optional[str] = None
    warrantyYears: Optional[int] = None
    numberOfCables: Optional[int] = None
    is_active: Optional[bool] = None
    maximo_location: Optional[str] = None
    maximo_desc: Optional[str] = None
    ocppUrl: Optional[str] = None
    chargerType: Optional[str] = None
    pipeline_config: Optional[Dict[str, Any]] = None

class ChargerOut(BaseModel):
    id: str
    station_id: str
    chargeBoxID: Optional[str] = ""
    chargerNo: Optional[int] = None
    charger_name: Optional[str] = ""
    brand: str
    manufacturer: Optional[str] = ""
    vendor: Optional[str] = ""
    model: str
    SN: str
    WO: Optional[str] = ""
    power: Optional[str] = ""
    PLCFirmware: Optional[str] = ""
    PIFirmware: Optional[str] = ""
    RTFirmware: Optional[str] = ""
    commissioningDate: Optional[str] = None
    warrantyYears: Optional[int] = 1
    numberOfCables: Optional[int] = 1
    is_active: Optional[bool] = True
    maximo_location: Optional[str] = ""
    maximo_desc: Optional[str] = ""
    ocppUrl: Optional[str] = ""
    chargerType: Optional[str] = ""
    pipeline_config: Optional[Dict[str, Any]] = None
    status: Optional[bool] = None
    images: Optional[dict] = None
    createdAt: Optional[datetime] = None
    createdBy: Optional[str] = None
    updatedAt: Optional[datetime] = None
    updatedBy: Optional[str] = None

# ── การรับประกัน / สัดส่วนการลงทุน (ระดับสถานี) ──
WARRANTY_STATUSES = {"in_warranty", "out_of_warranty"}
INVESTMENT_SCOPES = {"cb_box", "mdb", "structure", "charger", "ccb"}

def _clean_warranty_status(value: Optional[str]) -> str:
    v = (value or "").strip()
    if v and v not in WARRANTY_STATUSES:
        raise HTTPException(status_code=400, detail=f"Invalid warranty_status: {v}")
    return v

def _clean_investment_scope(values: Optional[List[str]]) -> List[str]:
    out = []
    for v in values or []:
        v = (v or "").strip()
        if not v:
            continue
        if v not in INVESTMENT_SCOPES:
            raise HTTPException(status_code=400, detail=f"Invalid investment_scope: {v}")
        if v not in out:
            out.append(v)
    return out

class StationCreate(BaseModel):
    station_id: str
    station_name: str
    user_id: Optional[str] = None
    owner: Optional[str] = None
    is_active: Optional[bool] = True
    maximo_location: Optional[str] = ""
    maximo_desc: Optional[str] = ""
    warranty_status: Optional[str] = ""
    investment_scope: Optional[List[str]] = []
    io_code: Optional[str] = ""

class StationUpdate(BaseModel):
    station_name: Optional[str] = None
    is_active: Optional[bool] = None
    user_id: Optional[str] = None
    username: Optional[str] = None
    maximo_location: Optional[str] = None
    maximo_desc: Optional[str] = None
    warranty_status: Optional[str] = None
    investment_scope: Optional[List[str]] = None
    io_code: Optional[str] = None

class StationOut(BaseModel):
    id: str
    station_id: str
    station_name: str
    user_id: str
    username: Optional[str] = None
    is_active: bool
    maximo_location: Optional[str] = ""
    maximo_desc: Optional[str] = ""
    warranty_status: Optional[str] = ""
    investment_scope: Optional[List[str]] = []
    io_code: Optional[str] = ""
    status: Optional[bool] = None
    stationImage: Optional[str] = None
    stationImages: Optional[list] = []
    images: Optional[dict] = {} 
    chargers: List[ChargerOut] = []
    createdAt: Optional[datetime] = None
    createdBy: Optional[str] = None
    updatedAt: Optional[datetime] = None
    updatedBy: Optional[str] = None

    class Config:
        json_encoders = {
            datetime: lambda v: v.astimezone(ZoneInfo("Asia/Bangkok")).isoformat()
        }

class StationWithChargersCreate(BaseModel):
    station: StationCreate
    chargers: List[ChargerCreate]

class StationWithChargersOut(BaseModel):
    station: StationOut
    chargers: List[ChargerOut]

def _assert_sn_wo_unique(sn: str, wo: str, charge_box_id: str = "", exclude_id: ObjectId = None):
    sn = (sn or "").strip()
    wo = (wo or "").strip()
    charge_box_id = (charge_box_id or "").strip()
    extra = {"_id": {"$ne": exclude_id}} if exclude_id else {}

    if sn and charger_collection.find_one({"SN": sn, **extra}):
        raise HTTPException(status_code=409, detail=f"SN '{sn}' already exists")
    if wo and charger_collection.find_one({"WO": wo, **extra}):
        raise HTTPException(status_code=409, detail=f"WO '{wo}' already exists")
    if charge_box_id and charge_box_id != "-" and charger_collection.find_one({"chargeBoxID": charge_box_id, **extra}):
        raise HTTPException(status_code=409, detail=f"Charge Box ID '{charge_box_id}' already exists")


class MonitorFieldConfig(BaseModel):
    key: str
    label: str
    unit: Optional[str] = None

class MonitorConfigUpdate(BaseModel):
    fields: List[MonitorFieldConfig]

class MonitorValueItem(BaseModel):
    key: str
    label: str
    value: Any = None
    unit: Optional[str] = None

class MonitorDataOut(BaseModel):
    values: List[MonitorValueItem]
    lastUpdated: Optional[str] = None


# ============================================================
# Normalize images
# ============================================================

def _normalize_images(images: Any) -> dict:
    if not isinstance(images, dict):
        return {}
    result = {}
    for key, val in images.items():
        if isinstance(val, list):
            result[key] = val
        elif isinstance(val, str) and val:
            result[key] = [val]
        else:
            result[key] = []
    return result


# ============================================================
# Helper Functions
# ============================================================

def to_object_id(s: str) -> ObjectId:
    try:
        return ObjectId(s)
    except (InvalidId, Exception):
        raise HTTPException(status_code=400, detail="Invalid ID format")


def get_username_by_user_id(user_id: ObjectId) -> Optional[str]:
    user = users_collection.find_one({"_id": user_id}, {"username": 1})
    return user.get("username") if user else None


def get_actor_id(current: UserClaims) -> str:
    return current.user_id


def get_charger_status(station_id: str, chargeBoxID: str) -> bool:
    try:
        coll = charger_onoff_sync[str(station_id)]
        doc = coll.find_one(
            {"chargeBoxID": chargeBoxID},
            sort=[("timestamp", -1), ("_id", -1)]
        )
        if not doc:
            return False
        val = doc.get("status", 0)
        return bool(int(val)) if not isinstance(val, bool) else val
    except Exception as e:
        print(f"[get_charger_status] {station_id}/{chargeBoxID}: {e}")
        return False


def ensure_status_indexes() -> int:
    """index (timestamp desc, _id desc) sur chaque collection de edgeboxStatus / settingParameter

    Ces deux bases gardent 1 collection par SN et le pipeline y écrit en continu.
    Les lectures sont toutes des find_one(sort=[("timestamp", -1), ("_id", -1)]) :
    sans index Mongo trie la collection entière en mémoire à chaque appel, donc le
    coût grandit avec le nombre de documents. Mesuré en local sur une collection :
    1,25 ms à 1 000 documents, 3,21 ms à 10 000, 9,45 ms à 50 000 — contre ~0,3 ms
    constant avec l'index. /station-availability/bulk fait ~200 de ces lectures
    toutes les 10 s, l'écart devient le coût dominant à mesure que les données
    s'accumulent. Appelé au démarrage, comme ensure_cm_indexes().
    """
    created = 0
    for db_sync in (charger_onoff_sync, settingDB_sync):
        try:
            names = db_sync.list_collection_names()
        except Exception:
            continue
        unified = UNIFIED_NAMES.get(db_sync.name)
        for name in names:
            if name.startswith("_") or name.startswith("system."):
                continue
            # la collection unifiée est indexée par (sn, timestamp, _id) — posé par
            # scripts/migrate_per_sn_collections.py ; l'index par SN n'y servirait à rien
            if name == unified:
                continue
            try:
                db_sync.get_collection(name).create_index(
                    [("timestamp", -1), ("_id", -1)],
                    name="timestamp_-1__id_-1", background=True,
                )
                created += 1
            except Exception:
                pass  # l'index n'est qu'un accélérateur — l'app doit démarrer même s'il échoue
    return created


def get_station_status(station_id: str) -> bool:
    try:
        coll = charger_onoff_sync[str(station_id)]
        doc = coll.find_one(sort=[("timestamp", -1), ("_id", -1)])
        if not doc:
            return False
        val = doc.get("status", 0)
        return bool(int(val)) if not isinstance(val, bool) else val
    except Exception as e:
        print(f"[get_station_status] {station_id}: {e}")
        return False


def get_next_charger_no(station_id: str) -> int:
    max_charger = charger_collection.find_one(
        {"station_id": station_id},
        sort=[("chargerNo", -1)]
    )
    if max_charger and max_charger.get("chargerNo"):
        return max_charger["chargerNo"] + 1
    return 1


def format_charger(
    doc: dict,
    include_status: bool = True,
    status_collections: Optional[set] = None,
) -> ChargerOut:
    """status_collections : ชื่อ collection ที่มีจริงใน edgeboxStatus (ผู้เรียกถามมาแล้ว)

    ถ้าไม่มี collection ของคีย์นั้น ก็ไม่มีเอกสาร = False อยู่แล้ว จึงข้าม query ได้
    /all-stations/ เรียกฟังก์ชันนี้ 1 ครั้งต่อตู้ (692 ตู้ = 692 คำสั่ง)
    """
    charger_id = str(doc["_id"])
    station_id = doc.get("station_id", "")
    status = None
    if include_status:
        if status_collections is not None and station_id not in status_collections:
            status = False
        else:
            status = get_charger_status(station_id, doc.get("chargeBoxID", ""))

    normalized = _normalize_images(doc.get("images", {}))

    return ChargerOut(
        id=charger_id,
        station_id=station_id,
        chargeBoxID=doc.get("chargeBoxID", ""),
        chargerNo=doc.get("chargerNo"),
        charger_name=doc.get("charger_name", ""),
        brand=doc.get("brand", ""),
        manufacturer=doc.get("manufacturer", ""),
        vendor=doc.get("vendor", ""),
        model=doc.get("model", ""),
        SN=doc.get("SN", ""),
        WO=doc.get("WO", ""),
        power=doc.get("power", ""),
        PLCFirmware=doc.get("PLCFirmware", ""),
        PIFirmware=doc.get("PIFirmware", ""),
        RTFirmware=doc.get("RTFirmware", ""),
        commissioningDate=doc.get("commissioningDate"),
        warrantyYears=doc.get("warrantyYears", 1),
        numberOfCables=doc.get("numberOfCables", 1),
        is_active=doc.get("is_active", True),
        maximo_location=doc.get("maximo_location", ""),
        maximo_desc=doc.get("maximo_desc", ""),
        ocppUrl=doc.get("ocppUrl", ""),
        chargerType=doc.get("chargerType", ""),
        pipeline_config=doc.get("pipeline_config"),
        status=status,
        images=normalized,
        createdAt=doc.get("createdAt"),
        createdBy=doc.get("createdBy"),
        updatedAt=doc.get("updatedAt"),
        updatedBy=doc.get("updatedBy"),
    )

def format_station_with_chargers(
    station_doc: dict,
    charger_docs: List[dict],
    username_by_id: Optional[Dict[str, str]] = None,
    status_by_station: Optional[Dict[str, bool]] = None,
    status_collections: Optional[set] = None,
) -> StationOut:
    """username_by_id / status_by_station : ตารางที่ผู้เรียกเตรียมมาแล้ว

    /all-stations/ เรียกฟังก์ชันนี้ 1 ครั้งต่อสถานี ถ้าปล่อยให้แต่ละครั้งไป query เอง
    จะกลายเป็น 2 คำสั่งต่อสถานี (355 สถานี = 710 คำสั่ง) ผู้เรียกที่ทำสถานีเดียว
    ไม่ต้องส่งอะไรมา — พฤติกรรมเหมือนเดิมทุกประการ
    """
    station_id = station_doc.get("station_id", "")
    user_id = station_doc.get("user_id")
    user_id_str = str(user_id) if user_id else ""

    username = station_doc.get("username")  # fallback ก่อน
    if user_id:
        if username_by_id is not None:
            db_username = username_by_id.get(user_id_str)
        else:
            db_username = get_username_by_user_id(user_id if isinstance(user_id, ObjectId) else to_object_id(user_id))
        if db_username:
            username = db_username  
            
    status = (
        status_by_station.get(station_id, False)
        if status_by_station is not None
        else get_station_status(station_id)
    )
    chargers = [format_charger(c, status_collections=status_collections) for c in charger_docs]

    normalized = _normalize_images(station_doc.get("images", {}))
    station_image_list = normalized.get("station", [])

    return StationOut(
        id=str(station_doc["_id"]),
        station_id=station_id,
        station_name=station_doc.get("station_name", ""),
        user_id=user_id_str,
        username=username,
        is_active=bool(station_doc.get("is_active", False)),
        maximo_location=station_doc.get("maximo_location", ""),
        maximo_desc=station_doc.get("maximo_desc", ""),
        warranty_status=station_doc.get("warranty_status", ""),
        investment_scope=station_doc.get("investment_scope", []) or [],
        io_code=station_doc.get("io_code", ""),
        status=status,
        stationImage=station_image_list[0] if station_image_list else None,
        stationImages=station_image_list,
        images=normalized,
        chargers=chargers,
        createdAt=station_doc.get("createdAt"),
        createdBy=station_doc.get("createdBy"),
        updatedAt=station_doc.get("updatedAt"),
        updatedBy=station_doc.get("updatedBy"),
    )


# ============================================================
# Image Upload Helpers
# ============================================================

# iPhone อัปรูปมาเป็น image/heic (บางเครื่องส่ง application/octet-stream มาแทน)
# เดิมด่านนี้เด้ง 415 ทำให้อัปรูปสถานี/ตู้ชาร์จจาก iPhone ไม่ได้เลย
# รับเข้ามาก่อน แล้วให้ normalize_image_bytes เป็นคนตัดสินว่า decode ได้จริงไหม
ALLOWED_IMAGE_TYPES = {
    "image/jpeg", "image/jpg", "image/png", "image/webp",
    "image/heic", "image/heif", "image/heic-sequence", "image/heif-sequence",
    "image/avif", "image/gif", "image/bmp", "image/tiff",
    "application/octet-stream", "",
}
MAX_IMAGE_BYTES = 3 * 1024 * 1024
MAX_IMAGES_PER_KIND = 5


def _ensure_dir(p: pathlib.Path):
    p.mkdir(parents=True, exist_ok=True)


MAX_WIDTH = 1280
MAX_HEIGHT = 1280
JPEG_QUALITY = 85

async def save_image(folder: str, item_id: str, kind: str, upload: UploadFile) -> str:
    if upload.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status_code=415, detail=f"Unsupported file type: {upload.content_type}")

    data = await upload.read()
    if len(data) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="File too large (> 3MB)")

    # แปลงเป็น JPEG เสมอ (รวมถึง HEIC จาก iPhone) — ของเดิมแยก save_format ตาม
    # content_type ซึ่งเชื่อไม่ได้ และไม่รองรับ HEIC อยู่แล้ว
    try:
        data, out_ext = normalize_image_bytes(
            data, upload.filename or "",
            max_width=MAX_WIDTH, max_height=MAX_HEIGHT, quality=JPEG_QUALITY,
        )
    except ImageConversionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid image: {e}")

    if out_ext not in ("jpg", "jpeg", "png", "webp", "gif"):
        raise HTTPException(status_code=415, detail="Unsupported file type")
    ext = f".{out_ext}"

    subdir = pathlib.Path(UPLOADS_ROOT) / folder / item_id
    _ensure_dir(subdir)

    fname = f"{kind}-{uuid.uuid4().hex}{ext}"
    dest = subdir / fname

    with open(dest, "wb") as f:
        f.write(data)

    return f"/uploads/{folder}/{item_id}/{fname}"


async def save_multiple_images(folder: str, item_id: str, kind: str, uploads: List[UploadFile]) -> List[str]:
    urls = []
    for upload in uploads:
        if upload.filename:
            url = await save_image(folder, item_id, kind, upload)
            urls.append(url)
    return urls


# ---------------------------------------------------------
# GET /all-stations/
# ---------------------------------------------------------

def to_object_id_safe(s: str):
    try:
        return ObjectId(s)
    except:
        return s

def _station_role_query(current: UserClaims) -> Optional[Dict[str, Any]]:
    """match query ตาม role ล้วน ๆ (ยังไม่คิดเรื่องยี่ห้อ) — คืน None ถ้ามองไม่เห็นสถานีเลย"""
    # ไม่จำกัดตาม station_id; company/brand scope จะถูกประกอบเพิ่มใน station_match_query
    if current.role in ALL_STATIONS_ROLES:
        return {}
    return {
        "$or": [
            {"user_id": current.user_id},
            {"user_id": to_object_id_safe(current.user_id)}
        ]
    }


def station_match_query(current: UserClaims) -> Optional[Dict[str, Any]]:
    """
    match query ของ stations ตาม role + ยี่ห้อที่บริษัทดูแล — คืน None ถ้า user มองไม่เห็นสถานีเลย

    เป็นจุดร่วมของทั้งระบบ: /all-stations/, availability และ uploads_access ใช้ตัวนี้ตัวเดียว
    ยี่ห้อจึงถูกบังคับพร้อมกันทุกทาง ไม่ต้องไล่แก้ทีละ endpoint
    """
    base = _station_role_query(current)
    if base is None:
        return None
    brand_clause = station_brand_clause(current)
    if brand_clause is None:
        return base
    if not base:
        return brand_clause
    # ต้องใช้ $and — ทั้งสองฝั่งอาจมีคีย์ station_id การ merge ตรง ๆ จะทับกัน
    return {"$and": [base, brand_clause]}


def load_station_scope(
    current: UserClaims,
    station_id: Optional[str] = None,
    station_fields: tuple = ("station_id",),
    charger_fields: tuple = ("SN", "station_id"),
) -> tuple:
    """(สถานี, ตู้) ที่ผู้เรียกเห็นได้ — sync PyMongo ให้เรียกผ่าน executor

    endpoint ที่รวมข้อมูลทุกสถานีในคำขอเดียว (/pm-reports/*, /test-reports/all-stations)
    ต้องเริ่มจากชุดนี้แทน station_collection.find({}) — เดิม PM ใช้ find({}) ทุกบัญชีที่
    ล็อกอินได้จึงเห็นเอกสาร PM ของทั้ง 355 สถานี ไม่ว่าจะเป็นเจ้าของหรือไม่
    สถานีที่ปนยี่ห้อยังเห็นได้ แต่ตู้ยี่ห้อที่ไม่ได้ดูแลถูกกรองออก (กติกา brand_scope)
    """
    access = station_match_query(current)
    if access is None:
        return [], []
    clauses = [access] if access else []
    if station_id:
        clauses.append({"station_id": station_id})
    query = {"$and": clauses} if clauses else {}

    stations = list(station_collection.find(query, {"_id": 0, **{f: 1 for f in station_fields}}))
    station_ids = [s["station_id"] for s in stations if s.get("station_id")]
    if not station_ids:
        return stations, []
    projection = {"_id": 0, "brand": 1, **{f: 1 for f in charger_fields}}
    chargers = list(charger_collection.find({"station_id": {"$in": station_ids}}, projection))
    return stations, filter_chargers(chargers, brand_scope_of(current))


# ============================================================
# Vue « liste » de /all-stations/
# ============================================================
# Les pages Stations et PM affichent les 355 stations d'un seul tenant : la
# recherche et le tri portent sur la totalité, on ne peut donc pas paginer côté
# serveur sans changer ce que l'utilisateur peut faire. Mais ces deux pages font
# passer la réponse par un mapCharger/mapStation qui jette déjà une partie des
# champs — tout ce que ce mapping ne garde pas traverse le réseau pour rien.
#
# ?view=list renvoie les mêmes stations, dans le même ordre, sans ces champs-là.
# Le plus lourd est pipeline_config (la configuration MQTT du pipeline, portée
# par chaque tour) : il est aussi écarté côté Mongo, ce qui évite de le décoder.
# Sans le paramètre la réponse est inchangée — /notifications et
# PipelineConfigModal consomment la réponse complète.

_LIST_DROP_STATION = ("createdAt", "createdBy", "updatedAt", "updatedBy", "stationImages")
_LIST_DROP_CHARGER = ("createdAt", "createdBy", "updatedAt", "updatedBy",
                      "charger_name", "pipeline_config")
_LIST_IMAGE_KEYS_STATION = ("station", "mdb")
_LIST_IMAGE_KEYS_CHARGER = ("charger", "device")


def _keep_images(images: Optional[dict], keys) -> dict:
    imgs = images or {}
    return {k: imgs[k] for k in keys if k in imgs}


def _thin_for_list(station: dict) -> dict:
    """Réduit une station sérialisée à ce que les pages liste affichent."""
    out = {k: v for k, v in station.items() if k not in _LIST_DROP_STATION}
    out["images"] = _keep_images(out.get("images"), _LIST_IMAGE_KEYS_STATION)
    out["chargers"] = [
        {
            **{k: v for k, v in charger.items() if k not in _LIST_DROP_CHARGER},
            "images": _keep_images(charger.get("images"), _LIST_IMAGE_KEYS_CHARGER),
        }
        for charger in out.get("chargers") or []
    ]
    return out


@router.get("/all-stations/")
def get_all_stations(
    current: UserClaims = Depends(get_current_user),
    view: str = Query("", description="list = seulement les champs affichés par les pages liste"),
):
    lean = view == "list"
    match_query = station_match_query(current)
    if match_query is None:
        return {"stations": []}

    stations_list = list(station_collection.find(match_query))

    # ดึง chargers ทั้งหมดในคำสั่งเดียว (แทนการ query ทีละสถานี — ช้ามากเมื่อมีหลายร้อยสถานี)
    station_ids = [s.get("station_id") for s in stations_list if s.get("station_id")]
    chargers_by_station: Dict[str, list] = {}
    if station_ids:
        chargers_cursor = charger_collection.find(
            {"station_id": {"$in": station_ids}},
            {"pipeline_config": 0} if lean else None,
        ).sort("chargerNo", 1)
        # สถานีที่ปนยี่ห้อ: เห็นสถานีได้ แต่เหลือเฉพาะตู้ที่บริษัทตัวเองดูแล
        scope = brand_scope_of(current)
        for charger_doc in filter_chargers(chargers_cursor, scope):
            chargers_by_station.setdefault(charger_doc.get("station_id"), []).append(charger_doc)

    # ── ชื่อเจ้าของทุกสถานีในคำสั่งเดียว (เดิม find_one ต่อสถานี) ──
    owner_oids = []
    for s_doc in stations_list:
        oid = s_doc.get("user_id")
        if not oid:
            continue
        oid = oid if isinstance(oid, ObjectId) else to_object_id(oid)
        if oid:
            owner_oids.append(oid)
    username_by_id: Dict[str, str] = {}
    if owner_oids:
        for u in users_collection.find({"_id": {"$in": list(set(owner_oids))}}, {"username": 1}):
            username_by_id[str(u["_id"])] = u.get("username") or ""

    # ── สถานะสถานี: edgeboxStatus มี 1 collection ต่อคีย์ ──
    # ถามชื่อที่มีจริงครั้งเดียว แทนการยิง find_one ไปยังคีย์ที่ไม่มี collection อยู่เลย
    # (ผลลัพธ์เท่าเดิม: ไม่มี collection / ไม่มีเอกสาร = False)
    try:
        existing_status = set(charger_onoff_sync.list_collection_names())
    except Exception:
        existing_status = None
    status_by_station: Dict[str, bool] = {
        sid: (get_station_status(sid)
              if existing_status is None or sid in existing_status
              else False)
        for sid in station_ids
    }

    result = []
    for station_doc in stations_list:
        charger_docs = chargers_by_station.get(station_doc.get("station_id"), [])
        station_out = format_station_with_chargers(
            station_doc, charger_docs, username_by_id, status_by_station, existing_status
        )
        payload = station_out.dict()
        result.append(_thin_for_list(payload) if lean else payload)

    return {"stations": result}


# ---------------------------------------------------------
# POST /add_stations/
# ---------------------------------------------------------
@router.post("/add_stations/", status_code=201)
def create_station_with_chargers(
    body: StationWithChargersCreate,
    current: UserClaims = Depends(get_current_user),
):
    station_data = body.station
    chargers_data = body.chargers

    sns = [c.SN.strip() for c in chargers_data if c.SN and c.SN.strip()]
    wos = [c.WO.strip() for c in chargers_data if c.WO and c.WO.strip()]
    cbids = [c.chargeBoxID.strip() for c in chargers_data if c.chargeBoxID and c.chargeBoxID.strip() and c.chargeBoxID.strip() != "-"]
    if len(sns) != len(set(sns)):
        raise HTTPException(status_code=409, detail="Duplicate SN within submitted chargers")
    if len(wos) != len(set(wos)):
        raise HTTPException(status_code=409, detail="Duplicate WO within submitted chargers")
    if len(cbids) != len(set(cbids)):
        raise HTTPException(status_code=409, detail="Duplicate Charge Box ID within submitted chargers")

    for c in chargers_data:
        _assert_sn_wo_unique(c.SN, c.WO or "", c.chargeBoxID or "")

    station_id = station_data.station_id.strip()
    if not station_id:
        raise HTTPException(status_code=400, detail="station_id is required")

    if station_collection.find_one({"station_id": station_id}):
        raise HTTPException(status_code=409, detail="station_id already exists")

    owner_oid = None
    owner_username = None
    if station_data.user_id:
        owner_oid = to_object_id(station_data.user_id)
        u = users_collection.find_one({"_id": owner_oid}, {"username": 1})
        owner_username = u.get("username") if u else None
    elif station_data.owner:
        owner_name = station_data.owner.strip()
        user = users_collection.find_one({"username": owner_name}, {"_id": 1, "username": 1})
        if user:
            owner_oid = user["_id"]
            owner_username = user.get("username", owner_name)
        else:
            # owner ใหม่ที่ยังไม่มีในระบบ → เก็บชื่อไว้ตรงๆ ไม่ผูก user_id
            owner_username = owner_name

    now = datetime.now(timezone.utc)
    actor = get_actor_id(current)

    station_doc = {
        "station_id": station_id,
        "station_name": station_data.station_name.strip(),
        "user_id": owner_oid,
        "username": owner_username,
        "is_active": station_data.is_active if station_data.is_active is not None else True,
        "maximo_location": station_data.maximo_location.strip() if station_data.maximo_location else "",
        "maximo_desc": station_data.maximo_desc.strip() if station_data.maximo_desc else "",
        "warranty_status": _clean_warranty_status(station_data.warranty_status),
        "investment_scope": _clean_investment_scope(station_data.investment_scope),
        "io_code": station_data.io_code.strip() if station_data.io_code else "",
        "images": {},
        "createdAt": now,
        "createdBy": actor,
    }

    try:
        station_result = station_collection.insert_one(station_doc)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="station_id already exists")

    created_chargers = []
    for idx, charger in enumerate(chargers_data):
        charger_no = charger.chargerNo if charger.chargerNo else idx + 1
        charger_doc = {
            "station_id": station_id,
            "chargeBoxID": charger.chargeBoxID.strip() if charger.chargeBoxID else "",
            "chargerNo": charger_no,
            # ชื่อตู้ชาร์จ = segment ท้ายของ maximo_location (เช่น BTL01GU201) — ไม่ใช่ทั้ง chain
            "charger_name": maximo_charger_name(charger.maximo_location),
            "brand": charger.brand.strip(),
            "manufacturer": charger.manufacturer.strip() if charger.manufacturer else "",
            "vendor": charger.vendor.strip() if charger.vendor else "",
            "model": charger.model.strip(),
            "SN": charger.SN.strip(),
            "WO": charger.WO.strip() if charger.WO else "",
            "power": charger.power.strip() if charger.power else "",
            "PLCFirmware": charger.PLCFirmware.strip() if charger.PLCFirmware else "",
            "PIFirmware": charger.PIFirmware.strip() if charger.PIFirmware else "",
            "RTFirmware": charger.RTFirmware.strip() if charger.RTFirmware else "",
            "commissioningDate": charger.commissioningDate,
            "warrantyYears": charger.warrantyYears if charger.warrantyYears else 1,
            "numberOfCables": charger.numberOfCables if charger.numberOfCables else 1,
            "is_active": charger.is_active if charger.is_active is not None else True,
            "maximo_location": charger.maximo_location.strip() if charger.maximo_location else "",
            "maximo_desc": charger.maximo_desc.strip() if charger.maximo_desc else "",
            "ocppUrl": charger.ocppUrl.strip() if charger.ocppUrl else "",
            "chargerType": charger.chargerType if charger.chargerType else "DC",
            "images": {},
            "createdAt": now,
            "createdBy": actor,
        }
        charger_result = charger_collection.insert_one(charger_doc)
        charger_doc["_id"] = charger_result.inserted_id
        created_chargers.append(charger_doc)

    station_doc["_id"] = station_result.inserted_id
    station_out = format_station_with_chargers(station_doc, created_chargers)

    return {
        "id": str(station_result.inserted_id),
        "station": station_out.dict(),
        "chargers": [format_charger(c, include_status=False).dict() for c in created_chargers],
    }


# ---------------------------------------------------------
# PATCH /update_stations/{id}
# ---------------------------------------------------------
@router.patch("/update_stations/{id}")
def update_station(
    id: str,
    body: StationUpdate,
    current: UserClaims = Depends(get_current_user),
):
    oid = to_object_id(id)
    station = station_collection.find_one({"_id": oid})
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")

    update_data = {}
    unset_data = {}
    if body.station_name is not None:
        update_data["station_name"] = body.station_name.strip()
    if body.is_active is not None:
        update_data["is_active"] = body.is_active
    if body.maximo_location is not None:
        update_data["maximo_location"] = body.maximo_location.strip()
    if body.maximo_desc is not None:
        update_data["maximo_desc"] = body.maximo_desc.strip()
    if body.warranty_status is not None:
        update_data["warranty_status"] = _clean_warranty_status(body.warranty_status)
    if body.investment_scope is not None:
        update_data["investment_scope"] = _clean_investment_scope(body.investment_scope)
    if body.io_code is not None:
        update_data["io_code"] = body.io_code.strip()

    if body.user_id is not None:
        new_user_oid = to_object_id(body.user_id)
        update_data["user_id"] = new_user_oid
        user = users_collection.find_one({"_id": new_user_oid})
        if user:
            update_data["username"] = user.get("username", "")
        else:
            raise HTTPException(status_code=400, detail="User not found")
    elif body.username is not None:
        username_stripped = body.username.strip()
        user = users_collection.find_one(
            {"username": username_stripped},
            {"_id": 1, "username": 1}
        )
        if user:
            # พบ user ในระบบ → ผูก user_id ด้วย
            update_data["user_id"] = user["_id"]
            update_data["username"] = user.get("username", username_stripped)
        else:
            # ไม่พบ user → บันทึกชื่อไว้ตรงๆ โดยไม่ผูก user_id
            update_data["username"] = username_stripped
            unset_data["user_id"] = ""

    if not update_data and not unset_data:
        raise HTTPException(status_code=400, detail="No fields to update")

    update_data["updatedAt"] = datetime.now(timezone.utc)
    update_data["updatedBy"] = get_actor_id(current)

    update_ops = {"$set": update_data}
    if unset_data:
        update_ops["$unset"] = unset_data
    station_collection.update_one({"_id": oid}, update_ops)

    updated = station_collection.find_one({"_id": oid})
    chargers = list(charger_collection.find({"station_id": updated["station_id"]}).sort("chargerNo", 1))

    return format_station_with_chargers(updated, chargers).dict()


# ---------------------------------------------------------
# DELETE /delete_stations/{id}
# ---------------------------------------------------------
@router.delete("/delete_stations/{id}", status_code=204)
def delete_station(id: str, current: UserClaims = Depends(get_current_user)):
    # ลบถาวรทั้งสถานีพร้อมตู้ทุกตู้ — ปุ่มลบแสดงให้ admin เท่านั้น แต่เดิม backend ไม่ตรวจ role เลย
    # บัญชีไหนที่ล็อกอินได้ก็ลบได้ (_id ของสถานีมากับ /all-stations/ อยู่แล้ว)
    if current.role != "admin":
        raise HTTPException(status_code=403, detail="Only admin can delete stations")
    oid = to_object_id(id)
    station = station_collection.find_one({"_id": oid})
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")

    station_id = station["station_id"]
    charger_collection.delete_many({"station_id": station_id})
    station_collection.delete_one({"_id": oid})
    return Response(status_code=204)


# ---------------------------------------------------------
# POST /add_charger/{station_id}
# ---------------------------------------------------------
@router.post("/add_charger/{station_id}", status_code=201)
def add_charger_to_station(
    station_id: str,
    body: ChargerCreate,
    current: UserClaims = Depends(get_current_user),
):
    station = station_collection.find_one({"station_id": station_id})
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")

    charger_no = body.chargerNo if body.chargerNo else get_next_charger_no(station_id)

    now = datetime.now(timezone.utc)
    actor = get_actor_id(current)

    _assert_sn_wo_unique(body.SN, body.WO or "", body.chargeBoxID or "")

    charger_doc = {
        "station_id": station_id,
        "chargeBoxID": body.chargeBoxID.strip() if body.chargeBoxID else "",
        "chargerNo": charger_no,
        "brand": body.brand.strip(),
        "manufacturer": body.manufacturer.strip() if body.manufacturer else "",
        "vendor": body.vendor.strip() if body.vendor else "",
        "model": body.model.strip(),
        "SN": body.SN.strip(),
        "WO": body.WO.strip() if body.WO else "",
        "power": body.power.strip() if body.power else "",
        "PLCFirmware": body.PLCFirmware.strip() if body.PLCFirmware else "",
        "PIFirmware": body.PIFirmware.strip() if body.PIFirmware else "",
        "RTFirmware": body.RTFirmware.strip() if body.RTFirmware else "",
        "commissioningDate": body.commissioningDate,
        "warrantyYears": body.warrantyYears if body.warrantyYears else 1,
        "numberOfCables": body.numberOfCables if body.numberOfCables else 1,
        "is_active": body.is_active if body.is_active is not None else True,
        "maximo_location": body.maximo_location.strip() if body.maximo_location else "",
        "maximo_desc": body.maximo_desc.strip() if body.maximo_desc else "",
        "ocppUrl": body.ocppUrl.strip() if body.ocppUrl else "",
        "chargerType": body.chargerType if body.chargerType else "DC",
        "images": {},
        "createdAt": now,
        "createdBy": actor,
    }

    result = charger_collection.insert_one(charger_doc)
    charger_doc["_id"] = result.inserted_id
    return format_charger(charger_doc, include_status=False).dict()

def _assert_pipeline_unique(pc: dict, exclude_id: ObjectId = None):
    """กัน MQTT topics และ meter collection ซ้ำกับตู้อื่น"""
    if not isinstance(pc, dict):
        return
    extra = {"_id": {"$ne": exclude_id}} if exclude_id else {}

    topics = (pc.get("topics") or {})
    for tkey, tval in topics.items():
        if not tval or not str(tval).strip():
            continue
        dup = charger_collection.find_one(
            {f"pipeline_config.topics.{tkey}": str(tval).strip(), **extra},
            {"SN": 1},
        )
        if dup:
            raise HTTPException(
                status_code=409,
                detail=f"Topic '{tval}' ({tkey}) ซ้ำกับตู้ SN {dup.get('SN', '-')}",
            )

    meter = ((pc.get("collections") or {}).get("meter") or "").strip()
    if meter:
        dup = charger_collection.find_one(
            {"pipeline_config.collections.meter": meter, **extra},
            {"SN": 1},
        )
        if dup:
            raise HTTPException(
                status_code=409,
                detail=f"Meter collection '{meter}' ซ้ำกับตู้ SN {dup.get('SN', '-')}",
            )
        
# ---------------------------------------------------------
# PATCH /update_charger/{id}
# ---------------------------------------------------------
@router.patch("/update_charger/{id}")
def update_charger(
    id: str,
    body: ChargerUpdate,
    current: UserClaims = Depends(get_current_user),
):
    oid = to_object_id(id)
    charger = charger_collection.find_one({"_id": oid})

    if not charger:
        raise HTTPException(status_code=404, detail="Charger not found")

    _assert_sn_wo_unique(
        body.SN or charger.get("SN", ""),
        body.WO or charger.get("WO", ""),
        body.chargeBoxID or charger.get("chargeBoxID", ""),
        exclude_id=oid,
    )

    update_data = {}
    for field in ["chargeBoxID", "brand", "manufacturer", "vendor", "model", "SN", "WO", "power", "PLCFirmware",
                  "PIFirmware", "RTFirmware", "commissioningDate", "maximo_location",
                  "maximo_desc", "ocppUrl", "chargerType"]:
        value = getattr(body, field, None)
        if value is not None:
            update_data[field] = value.strip() if isinstance(value, str) else value

    for field in ["chargerNo", "warrantyYears", "numberOfCables"]:
        value = getattr(body, field, None)
        if value is not None:
            update_data[field] = value

    if body.is_active is not None:
        update_data["is_active"] = body.is_active

    if body.pipeline_config is not None:        
        _assert_pipeline_unique(body.pipeline_config, exclude_id=oid)  
        update_data["pipeline_config"] = body.pipeline_config

    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")

    update_data["updatedAt"] = datetime.now(timezone.utc)
    update_data["updatedBy"] = get_actor_id(current)

    charger_collection.update_one({"_id": oid}, {"$set": update_data})

    updated = charger_collection.find_one({"_id": oid})
    return format_charger(updated).dict()


# ---------------------------------------------------------
# DELETE /delete_charger/{id}
# ---------------------------------------------------------
@router.delete("/delete_charger/{id}", status_code=204)
def delete_charger(id: str, current: UserClaims = Depends(get_current_user)):
    # เหตุผลเดียวกับ delete_station — ปุ่มลบตู้แสดงให้ admin เท่านั้น
    if current.role != "admin":
        raise HTTPException(status_code=403, detail="Only admin can delete chargers")
    oid = to_object_id(id)
    charger = charger_collection.find_one({"_id": oid})
    if not charger:
        raise HTTPException(status_code=404, detail="Charger not found")
    charger_collection.delete_one({"_id": oid})
    return Response(status_code=204)


# ============================================================
# ✅ Image Upload — Station (รองรับทั้ง station และ mdb)
# ============================================================

@router.post("/stations/{station_id}/upload-image")
async def upload_station_image(
    station_id: str,
    station: List[UploadFile] = File([]),
    mdb: List[UploadFile] = File([]),       # ✅ เพิ่ม mdb
    current: UserClaims = Depends(get_current_user),
):
    doc = station_collection.find_one({"station_id": station_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Station not found")

    images = _normalize_images(doc.get("images", {}))
    any_updated = False

    # ✅ วน loop ทั้ง station และ mdb เหมือน charger upload
    for kind, uploads in {"station": station, "mdb": mdb}.items():
        valid = [f for f in uploads if f.filename]
        if not valid:
            continue

        existing = images.get(kind, [])
        if len(existing) + len(valid) > MAX_IMAGES_PER_KIND:
            raise HTTPException(
                status_code=400,
                detail=f"สูงสุด {MAX_IMAGES_PER_KIND} รูป {kind} (ตอนนี้มี {len(existing)} รูป)"
            )

        new_urls = await save_multiple_images("stations", station_id, kind, valid)
        existing.extend(new_urls)
        images[kind] = existing
        any_updated = True

    if not any_updated:
        return {"updated": False, "images": _normalize_images(doc.get("images", {}))}

    station_collection.update_one(
        {"_id": doc["_id"]},
        {"$set": {
            "images": images,
            "updatedAt": datetime.now(timezone.utc),
            "updatedBy": get_actor_id(current),
        }}
    )

    return {"updated": True, "images": images}


@router.post("/chargers/{charger_id}/upload-images")
async def upload_charger_images(
    charger_id: str,
    mdb: List[UploadFile] = File([]),
    charger: List[UploadFile] = File([]),
    device: List[UploadFile] = File([]),
    current: UserClaims = Depends(get_current_user),
):
    oid = to_object_id(charger_id)
    doc = charger_collection.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Charger not found")

    images = _normalize_images(doc.get("images", {}))
    any_updated = False

    for kind, uploads in {"mdb": mdb, "charger": charger, "device": device}.items():
        valid = [u for u in uploads if u.filename]
        if not valid:
            continue

        existing = images.get(kind, [])
        if len(existing) + len(valid) > MAX_IMAGES_PER_KIND:
            raise HTTPException(
                status_code=400,
                detail=f"สูงสุด {MAX_IMAGES_PER_KIND} รูป {kind} (ตอนนี้มี {len(existing)} รูป)"
            )

        new_urls = await save_multiple_images("chargers", charger_id, kind, valid)
        existing.extend(new_urls)
        images[kind] = existing
        any_updated = True

    if not any_updated:
        return {"updated": False, "images": images}

    charger_collection.update_one(
        {"_id": oid},
        {"$set": {
            "images": images,
            "updatedAt": datetime.now(timezone.utc),
            "updatedBy": get_actor_id(current),
        }}
    )

    return {"updated": True, "images": images}


class DeleteImageRequest(BaseModel):
    kind: str
    url: str


@router.delete("/stations/{station_id}/delete-image")
def delete_station_image(
    station_id: str,
    body: DeleteImageRequest,
    current: UserClaims = Depends(get_current_user),
):
    doc = station_collection.find_one({"station_id": station_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Station not found")

    images = _normalize_images(doc.get("images", {}))
    kind_list = images.get(body.kind, [])

    if body.url not in kind_list:
        raise HTTPException(status_code=404, detail="Image not found")

    kind_list.remove(body.url)
    images[body.kind] = kind_list

    station_collection.update_one(
        {"_id": doc["_id"]},
        {"$set": {
            "images": images,
            "updatedAt": datetime.now(timezone.utc),
            "updatedBy": get_actor_id(current),
        }}
    )

    try:
        file_path = pathlib.Path(UPLOADS_ROOT).parent / body.url.lstrip("/")
        if file_path.exists():
            file_path.unlink()
    except Exception:
        pass

    return {"deleted": True, "images": images}


class DeleteImagesRequest(BaseModel):
    charger: List[str] = []
    device: List[str] = []

@router.delete("/chargers/{charger_id}/delete-images")
def delete_charger_images_batch(
    charger_id: str,
    body: DeleteImagesRequest,
    current: UserClaims = Depends(get_current_user),
):
    oid = to_object_id(charger_id)
    doc = charger_collection.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Charger not found")

    images = _normalize_images(doc.get("images", {}))

    for kind, urls_to_delete in {"charger": body.charger, "device": body.device}.items():
        if not urls_to_delete:
            continue
        images[kind] = [u for u in images.get(kind, []) if u not in urls_to_delete]
        for url in urls_to_delete:
            try:
                file_path = pathlib.Path(UPLOADS_ROOT).parent / url.lstrip("/")
                if file_path.exists():
                    file_path.unlink()
            except Exception:
                pass

    charger_collection.update_one(
        {"_id": oid},
        {"$set": {
            "images": images,
            "updatedAt": datetime.now(timezone.utc),
            "updatedBy": get_actor_id(current),
        }}
    )
    return {"deleted": True, "images": images}


# ---------------------------------------------------------
# GET /station/{station_id}
# ---------------------------------------------------------
@router.get("/station/{station_id}")
def get_station(station_id: str, current: UserClaims = Depends(get_current_user)):
    station = station_collection.find_one({"station_id": station_id})
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")
    chargers = list(charger_collection.find({"station_id": station_id}).sort("chargerNo", 1))
    chargers = filter_chargers(chargers, brand_scope_of(current))
    return format_station_with_chargers(station, chargers).dict()

# ---------------------------------------------------------
# GET /charger/info?sn=...&station_id=...
# ---------------------------------------------------------
@router.get("/charger/info")
def get_charger_info(
    sn: Optional[str] = Query(None),
    station_id: Optional[str] = Query(None),
    current: UserClaims = Depends(get_current_user),
):
    if not sn and not station_id:
        raise HTTPException(status_code=400, detail="sn or station_id required")

    query = {}
    scope = brand_scope_of(current)
    if sn:
        query["SN"] = sn
    elif station_id:
        query["station_id"] = station_id
        # ค้นด้วย station_id ได้ตู้ตัวไหนก็ได้ในสถานี — สถานีที่ปนยี่ห้อต้องคัดตั้งแต่ query
        # ไม่งั้นจะสุ่มได้ตู้ยี่ห้ออื่นแล้ว 403 ทั้งที่ตู้ที่ตัวเองดูแลก็มีอยู่
        if scope:
            query["brand"] = brand_regex(scope)

    doc = charger_collection.find_one(query)
    if not doc:
        raise HTTPException(status_code=404, detail="Charger not found")
    assert_charger_in_scope(current, doc)

    # ดึง station_name
    station_name = "-"
    sid = doc.get("station_id", "")
    if sid:
        station_doc = station_collection.find_one({"station_id": sid})
        if station_doc:
            station_name = station_doc.get("station_name", "-")

    normalized = _normalize_images(doc.get("images", {}))

    return {
        "station": {
            "station_id":        doc.get("station_id", "-"),
            "station_name":      station_name,
            "SN":                doc.get("SN", "-"),
            "WO":                doc.get("WO", "-"),
            "brand":             doc.get("brand", "-"),
            "manufacturer":      doc.get("manufacturer", "-"),
            "vendor":            doc.get("vendor", "-"),
            "model":             doc.get("model", "-"),
            "power":             doc.get("power", "-"),
            "chargeBoxID":       doc.get("chargeBoxID", "-"),
            "ocppUrl":           doc.get("ocppUrl", ""),
            "PLCFirmware":       doc.get("PLCFirmware", "-"),
            "PIFirmware":        doc.get("PIFirmware", "-"),
            "RTFirmware":        doc.get("RTFirmware", "-"),
            "chargerNo":         doc.get("chargerNo"),
            "numberOfCables":    doc.get("numberOfCables"),
            "commissioningDate": doc.get("commissioningDate"),
            "warrantyYears":     doc.get("warrantyYears"),
            "images":            normalized,
        }
    }

# ---------------------------------------------------------
# GET /chargers?SN=...  ← เพิ่มตรงนี้
# ---------------------------------------------------------
@router.get("/chargers")
def get_charger_by_sn(
    SN: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    doc = charger_collection.find_one({"SN": SN})
    if not doc:
        raise HTTPException(status_code=404, detail="Charger not found")
    assert_charger_in_scope(current, doc)

    hw = (doc.get("pipeline_config") or {}).get("hardware") or doc.get("hardware") or {}

    return {
        "SN": SN,
        "hardware": {
            "powerModuleCount": hw.get("powerModuleCount", 0),
            "dcContractorCount": hw.get("dcContractorCount", 0),
            "dcFanCount": hw.get("dcFanCount", 0),
            "fanType": hw.get("fanType", "FIXED"),
            "energyMeterType": hw.get("energyMeterType", ""),
        }
    }


# ---------------------------------------------------------
# GET /chargers/{station_id}
# ---------------------------------------------------------
@router.get("/chargers/{station_id}")
def get_chargers_by_station(station_id: str, current: UserClaims = Depends(get_current_user)):
    chargers = list(charger_collection.find({"station_id": station_id}).sort("chargerNo", 1))
    chargers = filter_chargers(chargers, brand_scope_of(current))
    return {"chargers": [format_charger(c).dict() for c in chargers]}


class AvailabilityOut(BaseModel):
    station_id: str
    total: int
    available: int

_HEADS_SORT = {"_id": -1}
_HEADS_PROJECTION = {"_id": 0}


def _heads_from_doc(doc: Optional[dict]) -> Optional[Dict[str, int]]:
    """Compte total/available depuis un document settingParameter — définition unique."""
    if not doc:
        return None

    total = 0
    available = 0
    n = 1
    while f"icp{n}" in doc:
        total += 1
        try:
            icp = int(doc.get(f"icp{n}", 0))
            usl = int(doc.get(f"usl{n}", 1))
        except (ValueError, TypeError):
            n += 1
            continue
        if icp == 1 and usl == 0:
            available += 1
        n += 1
    return {"total": total, "available": available}


async def charger_heads(sn: str) -> Optional[Dict[str, int]]:
    """นับหัวชาร์จ total/available จากเอกสาร settingParameter ล่าสุดของ SN นั้น"""
    try:
        doc = await settingDB[sn].find_one({}, _HEADS_PROJECTION, sort=[("_id", -1)])
    except Exception as e:
        print(f"[availability] Error for SN {sn}: {e}")
        return None
    return _heads_from_doc(doc)


@router.get("/station-availability/bulk")
async def get_station_availability_bulk(current: UserClaims = Depends(get_current_user)):
    """
    Availability (หัวชาร์จว่าง/ทั้งหมด) ของทุกสถานีที่ user มองเห็น ในคำขอเดียว
    — หน้า Stations ใช้แทนการยิง /station-availability/{station_id} ทีละสถานี
    """
    match_query = station_match_query(current)
    if match_query is None:
        return {"stations": {}}

    station_ids = [
        s["station_id"]
        for s in station_collection.find(match_query, {"_id": 0, "station_id": 1})
    ]
    if not station_ids:
        return {"stations": {}}

    charger_query: Dict[str, Any] = {"station_id": {"$in": station_ids}}
    # สถานีที่ปนยี่ห้อ — นับเฉพาะหัวชาร์จของตู้ที่บริษัทตัวเองดูแล
    scope = brand_scope_of(current)
    if scope:
        charger_query["brand"] = brand_regex(scope)

    pairs = [
        (c["station_id"], c["SN"].strip())
        for c in charger_collection.find(
            charger_query, {"_id": 0, "station_id": 1, "SN": 1}
        )
        if c.get("SN") and c["SN"].strip() and c["SN"].strip() != "-"
    ]

    # même remarque que pour /charger-onoff/bulk : la source et le filtrage des séries
    # sans collection sont décidés dans _latest_by_collection.
    docs = await _latest_by_collection(
        settingDB, [sn for _, sn in pairs], _HEADS_SORT, _HEADS_PROJECTION
    )
    results = [_heads_from_doc(docs.get(sn)) for _, sn in pairs]

    stations: Dict[str, Dict[str, Any]] = {
        sid: {"station_id": sid, "total": 0, "available": 0, "chargers": []}
        for sid in station_ids
    }
    for (sid, sn), heads in zip(pairs, results):
        if not heads:
            continue
        st = stations[sid]
        st["total"] += heads["total"]
        st["available"] += heads["available"]
        st["chargers"].append({"sn": sn, "total": heads["total"], "available": heads["available"]})

    return {"stations": stations}


@router.get("/station-availability/{station_id}")
async def get_station_availability(
    station_id: str,
    current: UserClaims = Depends(get_current_user),
):
    station = station_collection.find_one({"station_id": station_id})
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")

    charger_query: Dict[str, Any] = {"station_id": station_id}
    scope = brand_scope_of(current)
    if scope:
        charger_query["brand"] = brand_regex(scope)
    chargers = list(charger_collection.find(charger_query, {"SN": 1}))

    total = 0
    available = 0
    per_charger = []

    for charger in chargers:
        sn = charger.get("SN", "")
        if not sn or sn == "-":
            continue
        heads = await charger_heads(sn)
        if not heads:
            continue
        total += heads["total"]
        available += heads["available"]
        per_charger.append({"sn": sn, "total": heads["total"], "available": heads["available"]})

    return {
        "station_id": station_id,
        "total": total,
        "available": available,
        "chargers": per_charger,
    }


_CBM_SKIP_KEYS = {"_id", "timestamp", "ts", "sn", "SN", "station_id", "createdAt", "updatedAt"}


def _safe_value(v: Any) -> Any:
    if v is None:
        return None
    if hasattr(v, "to_decimal"):
        return float(v.to_decimal())
    if isinstance(v, ObjectId):
        return str(v)
    if isinstance(v, datetime):
        return v.astimezone(ZoneInfo("Asia/Bangkok")).isoformat()
    return v


@router.get("/charger/{charger_id}/monitor")
async def get_monitor_values(charger_id: str, current: UserClaims = Depends(get_current_user)):
    oid = to_object_id(charger_id)
    charger = charger_collection.find_one({"_id": oid})
    if not charger:
        raise HTTPException(status_code=404, detail="Charger not found")

    sn = charger.get("SN", "")
    if not sn or sn == "-":
        return MonitorDataOut(values=[], lastUpdated=None).dict()

    try:
        coll = CBM_DB[sn]
        doc = await coll.find_one({}, sort=[("_id", -1)])
    except Exception as e:
        print(f"[monitor] Error reading CBM_DB[{sn}]: {e}")
        return MonitorDataOut(values=[], lastUpdated=None).dict()

    if not doc:
        return MonitorDataOut(values=[], lastUpdated=None).dict()

    monitor_config = charger.get("monitorConfig")

    if not monitor_config:
        station_doc = station_collection.find_one(
            {"station_id": charger.get("station_id", "")},
            {"monitorConfig": 1},
        )
        if station_doc:
            monitor_config = station_doc.get("monitorConfig")

    if monitor_config and isinstance(monitor_config, list) and len(monitor_config) > 0:
        values = []
        for f in monitor_config:
            values.append(MonitorValueItem(
                key=f["key"],
                label=f["label"],
                value=_safe_value(doc.get(f["key"])),
                unit=f.get("unit"),
            ))
    else:
        values = []
        for k, v in doc.items():
            if k in _CBM_SKIP_KEYS:
                continue
            values.append(MonitorValueItem(key=k, label=k, value=_safe_value(v), unit=None))

    last_updated = None
    ts = doc.get("timestamp") or doc.get("ts")
    if isinstance(ts, datetime):
        last_updated = ts.astimezone(ZoneInfo("Asia/Bangkok")).isoformat()
    elif isinstance(ts, str):
        last_updated = ts
    elif doc.get("_id") and isinstance(doc["_id"], ObjectId):
        last_updated = doc["_id"].generation_time.astimezone(ZoneInfo("Asia/Bangkok")).isoformat()

    return MonitorDataOut(values=values, lastUpdated=last_updated).dict()


@router.get("/charger/{charger_id}/monitor/available-fields")
async def get_available_monitor_fields(charger_id: str, current: UserClaims = Depends(get_current_user)):
    oid = to_object_id(charger_id)
    charger = charger_collection.find_one({"_id": oid})
    if not charger:
        raise HTTPException(status_code=404, detail="Charger not found")

    sn = charger.get("SN", "")
    if not sn or sn == "-":
        return {"charger_id": charger_id, "sn": sn, "fields": []}

    try:
        coll = CBM_DB[sn]
        doc = await coll.find_one({}, sort=[("_id", -1)])
    except Exception as e:
        print(f"[available-fields] Error reading CBM_DB[{sn}]: {e}")
        return {"charger_id": charger_id, "sn": sn, "fields": []}

    if not doc:
        return {"charger_id": charger_id, "sn": sn, "fields": []}

    fields = []
    for k, v in doc.items():
        if k in _CBM_SKIP_KEYS:
            continue
        fields.append({"key": k, "label": k, "sample_value": _safe_value(v)})

    return {"charger_id": charger_id, "sn": sn, "fields": fields}


@router.get("/charger/{charger_id}/monitor/config")
def get_monitor_config(charger_id: str, current: UserClaims = Depends(get_current_user)):
    oid = to_object_id(charger_id)
    charger = charger_collection.find_one({"_id": oid})
    if not charger:
        raise HTTPException(status_code=404, detail="Charger not found")

    config = charger.get("monitorConfig")
    source = "charger"

    if not config:
        station_doc = station_collection.find_one(
            {"station_id": charger.get("station_id", "")},
            {"monitorConfig": 1},
        )
        config = station_doc.get("monitorConfig") if station_doc else None
        source = "station" if config else None

    return {"charger_id": charger_id, "fields": config or [], "source": source}


@router.put("/charger/{charger_id}/monitor/config")
def set_monitor_config(charger_id: str, body: MonitorConfigUpdate, current: UserClaims = Depends(get_current_user)):
    oid = to_object_id(charger_id)
    charger = charger_collection.find_one({"_id": oid})
    if not charger:
        raise HTTPException(status_code=404, detail="Charger not found")

    fields_data = [f.dict() for f in body.fields]

    charger_collection.update_one(
        {"_id": oid},
        {"$set": {
            "monitorConfig": fields_data,
            "updatedAt": datetime.now(timezone.utc),
            "updatedBy": get_actor_id(current),
        }},
    )

    return {"charger_id": charger_id, "fields": fields_data, "updated": True}


@router.put("/station/{station_id}/monitor/config")
def set_station_monitor_config(station_id: str, body: MonitorConfigUpdate, current: UserClaims = Depends(get_current_user)):
    station = station_collection.find_one({"station_id": station_id})
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")

    fields_data = [f.dict() for f in body.fields]

    station_collection.update_one(
        {"station_id": station_id},
        {"$set": {
            "monitorConfig": fields_data,
            "updatedAt": datetime.now(timezone.utc),
            "updatedBy": get_actor_id(current),
        }},
    )

    return {"station_id": station_id, "fields": fields_data, "updated": True}
