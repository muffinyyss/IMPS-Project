"""User & Auth routes: login, register, me, refresh, logout, CRUD"""
from fastapi import APIRouter, HTTPException, Depends, Query, Request
from fastapi.responses import Response, JSONResponse
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field, EmailStr
from datetime import datetime, timedelta, timezone
from bson.objectid import ObjectId
from pymongo.errors import DuplicateKeyError
from jose import jwt, ExpiredSignatureError, JWTError
from typing import List, Optional, Union
import bcrypt, uuid, json, secrets
from typing import Literal
from urllib.parse import quote

from config import (
    SECRET_KEY, ALGORITHM, ACCESS_COOKIE_NAME, FRONTEND_BASE_URL,
    ACCESS_TOKEN_EXPIRE_MINUTES_TECHNICIAN, ACCESS_TOKEN_EXPIRE_MINUTES_DEFAULT,
    SESSION_IDLE_MINUTES_TECHNICIAN, SESSION_IDLE_MINUTES_DEFAULT,
    REFRESH_TOKEN_EXPIRE_DAYS, STAFF_ROLES,
    users_collection, station_collection, charger_collection,
    create_access_token, canonical_role,
    SUPER_ADMIN_ROLE, SUPER_ADMIN_USERNAME, SWITCHABLE_ROLES,
)
from deps import UserClaims, get_current_user
from brand_scope import assert_charger_in_scope, brand_regex, brand_scope_of
from session_cookies import (
    REFRESH_COOKIE_NAME, as_utc, clear_session_cookies, set_session_cookies,
)

router = APIRouter()

def to_object_id_or_400(s: str) -> ObjectId:
    try:
        return ObjectId(s)
    except Exception:
        raise HTTPException(status_code=400, detail=f"Invalid ObjectId: {s}")

def normalize_email(s: str | None) -> str:
    """อีเมลไม่แยกตัวพิมพ์ใหญ่/เล็ก — ต้อง normalize ทั้งตอนเขียนและตอนค้นให้ตรงกัน
    (เดิม add_users .lower() ฝั่งเดียว แต่ login ค้นแบบ exact → user ที่พิมพ์ตัวใหญ่ login ไม่ได้)"""
    return (s or "").strip().lower()

class LoginRequest(BaseModel):
    email: str
    password: str

class AiPackage(BaseModel):
    enabled: bool = False
    # expires_at: Optional[datetime] = None

# class UserUpdate(BaseModel):
#     username: str | None = None
#     email: EmailStr | None = None
#     tel: str | None = None
#     company: str | None = None
#     role: str | None = None
#     is_active: bool | None = None
#     password: str | None = None
#     station_id: Optional[List[str]] = None

@router.post("/login/")
def login(body: LoginRequest, request: Request, response: Response):
    user = users_collection.find_one(
        {"email": normalize_email(body.email)},
        {"_id": 1, "email": 1, "username": 1, "password": 1, "role": 1, "company": 1, "station_id": 1, "ai_package": 1},
    )
    # เช็ครหัสผ่านแบบกันพัง: ถ้า hash ใน DB เสีย/ว่าง/เป็น None/ไม่ใช่ bcrypt (เช่นถูก seed มาเป็น plaintext)
    # bcrypt.checkpw จะโยน ValueError/TypeError → เดิมกลายเป็น 500 (หน้า HTML จาก nginx) ทำให้ frontend res.json() พัง
    stored_pw = user.get("password") if user else None
    try:
        password_ok = (
            bool(user)
            and isinstance(stored_pw, str)
            and bcrypt.checkpw(body.password.encode("utf-8"), stored_pw.encode("utf-8"))
        )
    except (ValueError, TypeError):
        password_ok = False
    if not password_ok:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    # station_id อาจถูกเก็บเป็น ObjectId/ชนิดอื่น → บังคับเป็น string ก่อนใส่ลง JWT และ response
    # (ObjectId ทำให้ jwt.encode และการ serialize response โยน TypeError → 500 เฉพาะ user ที่มีสถานี เช่น technician)
    raw_station_ids = user.get("station_id", [])
    if not isinstance(raw_station_ids, list):
        raw_station_ids = [raw_station_ids]
    station_ids = [str(x) for x in raw_station_ids if x is not None and str(x).strip() != ""]

    # 👇 สร้าง session id + ตีตราเวลา
    now = datetime.now(timezone.utc)
    sid = str(uuid.uuid4())
    
    # กำหนด token expire time ตามบทบาท
    # user เก่าที่ยังเป็น "engineer" ใน DB → normalize เป็น "planner" ก่อนอบลง JWT
    user_role = canonical_role(user.get("role", "user")) or "user"
    if user_role in STAFF_ROLES:
        token_expire_minutes = ACCESS_TOKEN_EXPIRE_MINUTES_TECHNICIAN  # 24 ชั่วโมง
    else:
        token_expire_minutes = ACCESS_TOKEN_EXPIRE_MINUTES_DEFAULT  # 15 นาที

    # ไม่แนบ station_ids ลง JWT: เป็นข้อมูล legacy และอาจทำให้ token/คุกกี้ใหญ่จน
    # response header เกิน proxy_buffer_size ของ nginx → 502 (หน้า HTML) → frontend login พัง
    # สิทธิ์สถานีใช้กฎกลางตาม role ไม่ได้อิงรายการนี้
    jwt_token = create_access_token({
        "sub": user["email"],
        "user_id": str(user["_id"]),
        "username": user.get("username"),
        "role": user_role,
        "company": user.get("company"),
        "sid": sid,  # ⬅️ แนบ session id ไว้ใน access token
    }, expires_delta=timedelta(minutes=token_expire_minutes))

    refresh_token = create_access_token({"sub": user["email"]}, expires_delta=timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS))

    # ✅ ผูก session ใน DB (เก็บ lastActiveAt ไว้เช็ค idle)
    users_collection.update_one(
        {"_id": user["_id"]},
        {"$set": {
            "refreshTokens": [{
                "sid": sid,
                "token": refresh_token,
                "createdAt": now,
                "lastActiveAt": now,
                "expiresAt": now + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS),
            }]
        }}
    )

    # token อยู่ในคุกกี้ HttpOnly เท่านั้น — body มีแค่โปรไฟล์ (ไม่ใช่ความลับ) ให้ frontend แสดงเมนูตาม role
    set_session_cookies(
        response, request,
        jwt_token, int(timedelta(minutes=token_expire_minutes).total_seconds()),
        refresh_token, int(timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS).total_seconds()),
    )

    return {
        "message": "ok",
        "user": {
            "user_id": str(user["_id"]),
            "username": user.get("username"),
            "email": user["email"],
            "role": user_role,
            "company": user.get("company"),
            "station_id": station_ids,
            "ai_package": user.get("ai_package", {"enabled": False}),
        }
    }

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    email: EmailStr
    token: str
    new_password: str = Field(min_length=8)

RESET_TOKEN_EXPIRE_MINUTES = 30

@router.post("/forgot-password/")
async def forgot_password(body: ForgotPasswordRequest):
    """ส่งอีเมลลิงก์ reset password (ตอบแบบ generic เสมอ — ไม่เปิดเผยว่ามี email ในระบบหรือไม่)"""
    user = users_collection.find_one({"email": normalize_email(body.email)}, {"_id": 1, "email": 1, "username": 1})
    if user:
        token = secrets.token_urlsafe(32)
        users_collection.update_one(
            {"_id": user["_id"]},
            {"$set": {"passwordReset": {
                "token": token,
                "expiresAt": datetime.now(timezone.utc) + timedelta(minutes=RESET_TOKEN_EXPIRE_MINUTES),
            }}}
        )
        reset_link = f"{FRONTEND_BASE_URL}/auth/reset/new-password?token={token}&email={quote(user['email'])}"
        display_name = user.get("username") or user["email"]
        email_body = (
            f"Hello {display_name},\n\n"
            f"We received a request to reset your iMPS password.\n"
            f"Click the link below to choose a new password (valid for {RESET_TOKEN_EXPIRE_MINUTES} minutes):\n\n"
            f"{reset_link}\n\n"
            f"If you did not request this, you can safely ignore this email.\n\n"
            f"— iMPS Platform"
        )
        # import ภายในฟังก์ชัน กัน import วนถ้า notifications ต้อง import users ในอนาคต
        from routers.notifications import send_email_smtp
        sent = await send_email_smtp([user["email"]], "iMPS — Reset your password", email_body)
        if not sent:
            raise HTTPException(status_code=502, detail="Failed to send reset email. Please try again later.")
    return {"message": "If this email is registered, a reset link has been sent."}

@router.post("/reset-password/")
def reset_password(body: ResetPasswordRequest):
    """ตั้งรหัสผ่านใหม่จาก token ที่ส่งไปทางอีเมล (token ใช้ได้ครั้งเดียว)"""
    user = users_collection.find_one({"email": normalize_email(body.email)}, {"_id": 1, "passwordReset": 1})
    pr = (user or {}).get("passwordReset") or {}
    stored_token = pr.get("token") or ""
    expires_at = pr.get("expiresAt")
    if expires_at is not None and expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)  # pymongo คืน naive UTC
    token_valid = (
        user is not None
        and stored_token
        and secrets.compare_digest(stored_token, body.token)
        and expires_at is not None
        and expires_at > datetime.now(timezone.utc)
    )
    if not token_valid:
        raise HTTPException(status_code=400, detail="Invalid or expired reset link")

    hashed = bcrypt.hashpw(body.new_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    users_collection.update_one(
        {"_id": user["_id"]},
        # ล้าง refreshTokens ด้วย → บังคับ login ใหม่ทุก session เดิม
        {"$set": {"password": hashed, "refreshTokens": []}, "$unset": {"passwordReset": ""}},
    )
    return {"message": "Password reset successful"}

@router.get("/me/ai-package")
def get_ai_package(current: UserClaims = Depends(get_current_user)):
    if current.role == "admin":
        return {"has_access": True, "role": "admin"}

    user = users_collection.find_one(
        {"_id": ObjectId(current.user_id)},
        {"ai_package": 1}
    )
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    pkg = user.get("ai_package", {})
    enabled = pkg.get("enabled", False)
    # expires_at = pkg.get("expires_at")

    # is_expired = False
    # if expires_at:
    #     expiry = expires_at if isinstance(expires_at, datetime) else datetime.fromisoformat(str(expires_at))
    #     if expiry.tzinfo is None:
    #         expiry = expiry.replace(tzinfo=timezone.utc)
    #     is_expired = datetime.now(timezone.utc) > expiry

    has_access = enabled

    return {
        "has_access": has_access,
        "enabled": enabled,
        "role": current.role,
    }

@router.get("/me")
def me(current: UserClaims = Depends(get_current_user)):
    if not current.user_id:
        raise HTTPException(status_code=401, detail="Missing uid in token")

    u = users_collection.find_one(
        {"_id": ObjectId(current.user_id)},
        {"_id": 1, "username": 1, "email": 1, "role": 1, "company": 1, "tel": 1,"station_id":1},
    )
    if not u:
        raise HTTPException(status_code=404, detail="User not found")

    return {
        "id": str(u["_id"]),
        "username": u.get("username") or "",
        "email": u.get("email") or "",
        # role สำหรับตรวจสิทธิ์ — super_admin ถูก normalize เป็น admin เพื่อให้ frontend ได้สิทธิ์เหมือน admin ทุกจุด
        "role": current.role or (u.get("role") or ""),
        "effective_role": current.effective_role or (u.get("role") or ""),
        "is_super_admin": current.is_super_admin,
        # role จริงใน DB (ตัวจริง) — ใช้เช็คว่าเป็น super admin ตัวจริงไหม (โชว์ dropdown)
        "true_role": canonical_role(u.get("role")) or "",
        "company": u.get("company") or "",
        "tel": u.get("tel") or "",
        "station_id": u.get("station_id") or [],
    }


class SwitchRoleIn(BaseModel):
    role: str


@router.post("/users/switch-role")
def switch_role(body: SwitchRoleIn, request: Request, response: Response, current: UserClaims = Depends(get_current_user)):
    """
    Super admin (thatsawan) สลับ role ที่กำลังสวม (impersonate) โดยไม่ต้อง login ใหม่ — ออก JWT cookie ใหม่
    gate ด้วย role จริงใน DB == super_admin (ไม่ใช่ JWT) → ใช้ได้แม้กำลัง impersonate role อื่นอยู่ก็สลับกลับได้
    """
    target = (body.role or "").strip()
    if target not in SWITCHABLE_ROLES:
        raise HTTPException(status_code=400, detail="Invalid role")

    if not current.user_id:
        raise HTTPException(status_code=401, detail="Missing uid in token")
    try:
        u = users_collection.find_one({"_id": ObjectId(current.user_id)}, {"role": 1, "username": 1, "email": 1, "company": 1, "station_id": 1, "ai_package": 1})
    except Exception:
        raise HTTPException(status_code=400, detail="Bad user id")
    # ตรวจ role จริงใน DB — เฉพาะ super admin ตัวจริงเท่านั้นที่สลับ role ได้
    if not u or (u.get("role") or "") != SUPER_ADMIN_ROLE:
        raise HTTPException(status_code=403, detail="Only super admin can switch role")

    # สร้าง session ใหม่ครบชุดเหมือน /login (access + refresh + DB session ใหม่) — กัน session ไม่ sync
    # (ถ้าออกแค่ access ใหม่ แต่ refresh_token/sid เดิม → apiFetch วน refresh แล้ว role เด้งกลับ/หลุด login)
    email = u.get("email") or current.sub
    now = datetime.now(timezone.utc)
    sid = str(uuid.uuid4())
    expires_min = ACCESS_TOKEN_EXPIRE_MINUTES_TECHNICIAN
    new_token = create_access_token({
        "sub": email,
        "user_id": current.user_id,
        "username": u.get("username") or current.username,
        "role": target,
        "company": u.get("company"),
        "sid": sid,
    }, expires_delta=timedelta(minutes=expires_min))
    refresh_token = create_access_token({"sub": email}, expires_delta=timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS))

    # แทนที่ session เดิมด้วย session ใหม่ (ผูก sid ใหม่) — ให้ /refresh ทำงานได้ต่อ
    users_collection.update_one(
        {"_id": u["_id"]},
        {"$set": {"refreshTokens": [{
            "sid": sid,
            "token": refresh_token,
            "createdAt": now,
            "lastActiveAt": now,
            "expiresAt": now + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS),
        }]}},
    )

    set_session_cookies(
        response, request,
        new_token, int(timedelta(minutes=expires_min).total_seconds()),
        refresh_token, int(timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS).total_seconds()),
    )
    # ส่ง user กลับเหมือน /login ให้ frontend อัปเดตโปรไฟล์แบบเดียวกันเป๊ะ (token อยู่ในคุกกี้แล้ว)
    return {
        "ok": True,
        "role": target,
        "user": {
            "user_id": str(u["_id"]),
            "username": u.get("username") or current.username,
            "email": email,
            "role": target,
            "company": u.get("company"),
            "station_id": [str(x) for x in (u.get("station_id") or []) if x is not None],
            "ai_package": u.get("ai_package", {"enabled": False}),
        },
    }


@router.get("/my-stations/detail")
def my_stations_detail(current: UserClaims = Depends(get_current_user)):
    """
    สถานีที่ user เห็นได้ (ใช้เติม dropdown เลือกสถานีบนแถบบน)

    ใช้ station_match_query ตัวเดียวกับหน้า EV Station และ /uploads — เดิมที่นี่เขียนกติกา
    role ซ้ำอีกชุด พอเพิ่มการกรองตามยี่ห้อ (EDS = FlexxFast) สองชุดจะเพี้ยนออกจากกันทันที
    """
    from routers.stations import station_match_query

    match_query = station_match_query(current)
    if match_query is None:
        return {"stations": []}

    proj = {"_id": 0, "station_id": 1, "station_name": 1}
    return {"stations": list(station_collection.find(match_query, proj))}

@router.get("/station/info")
def station_info(
    station_id: str = Query(...),
    current: UserClaims = Depends(get_current_user),   # ดึง claims จาก JWT
):
    # ดึงข้อมูลจากคอลเลกชัน stations
    doc = station_collection.find_one(
        {"station_id": station_id},
        # เลือก field ที่อยากคืน (ตัด _id ออกเพื่อลด serialize ปัญหา ObjectId)
        {
            "_id": 0, 
            "station_id": 1, 
            "station_name": 1, 
            "SN": 1, 
            "WO": 1,
            "brand":1, 
            "PLCFirmware": 1, 
            "PIFirmware": 1, 
            "RTFirmware": 1, 
            "chargeBoxID": 1, 
            "commit_date" :1,
            "warranty_year": 1,
            "model": 1, 
            "status": 1, 
            "module1_isActive":1, 
            "module2_isActive":1, 
            "module3_isActive":1, 
            "module4_isActive":1, 
            "module5_isActive":1, 
            "module6_isActive":1, 
            "module7_isActive":1,
            "chargerNo":1,
            "chargingCables":1
        }
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Station not found")

    return {"station": doc}

@router.get("/charger/info")
def charger_info(
    station_id: str = Query(None),
    sn: str = Query(None),
    current: UserClaims = Depends(get_current_user),
):
    query = {}
    scope = brand_scope_of(current)
    if sn:
        query = {"SN": sn}
    elif station_id:
        query["station_id"] = station_id
        # ค้นด้วย station_id ได้ตู้ตัวไหนก็ได้ในสถานี — สถานีที่ปนยี่ห้อต้องคัดตั้งแต่ query
        # ไม่งั้นจะสุ่มได้ตู้ยี่ห้ออื่นแล้ว 403 ทั้งที่ตู้ที่ตัวเองดูแลก็มีอยู่
        if scope:
            query["brand"] = brand_regex(scope)
    else:
        raise HTTPException(status_code=400, detail="station_id or sn required")

    doc = charger_collection.find_one(query, {"_id": 0})

    if not doc:
        raise HTTPException(status_code=404, detail="Charger not found")
    assert_charger_in_scope(current, doc)

    station = station_collection.find_one(
        {"station_id": doc.get("station_id")},
        {"_id": 0, "station_name": 1}
    )
    
    doc["station_name"] = station.get("station_name", "-") if station else "-"

    return {"station": doc}

# @router.get("/station/info/public")
# def station_info_public(
#     station_id: str = Query(...)
# ):
#     doc = station_collection.find_one(
#         {"station_id": station_id},
#         {"_id": 0, "station_id": 1, "station_name": 1, "SN": 1, "WO": 1,"chargeBoxID": 1,
#          "model": 1,"power":1, "status": 1,"brand":1,"chargerNo":1,"chargingCables":1}
#     )
#     if not doc:
#         raise HTTPException(status_code=404, detail="Station not found")
#     return {"station": doc}

@router.get("/station/info/public")
def station_info_public(
    station_id: Optional[str] = Query(None),
    sn: Optional[str] = Query(None),
):
    """
    Get charger/station info by station_id OR sn
    """
    if not station_id and not sn:
        raise HTTPException(status_code=400, detail="Either station_id or sn is required")

    doc = None

    # ถ้ามี sn ให้ค้นหาจาก charger collection ก่อน
    if sn:
        # ค้นหา charger จาก SN
        charger_doc = charger_collection.find_one(
            {"SN": sn},
            {
                "_id": 0,
                "SN": 1,
                "chargeBoxID": 1,
                "station_id": 1,
                "brand": 1,
                "manufacturer": 1,
                "model": 1,
                "power": 1,
                "chargerNo": 1,
                "PIFirmware":1,
                "numberOfCables": 1,
                "is_active": 1,
                
            }
        )
        if not charger_doc:
            raise HTTPException(status_code=404, detail=f"Charger with SN '{sn}' not found")

        # ดึง station_id จาก charger
        station_id = charger_doc.get("station_id")

        # ดึงข้อมูล station เพื่อเอา station_name
        station_doc = None
        if station_id:
            station_doc = station_collection.find_one(
                {"station_id": station_id},
                {"_id": 0, "station_name": 1, "warranty_status": 1, "investment_scope": 1, "io_code": 1}
            )

        # สร้าง response โดยรวมข้อมูลจาก charger + station
        doc = {
            "station_id": station_id,
            "station_name": station_doc.get("station_name", "") if station_doc else "",
            "warranty_status": (station_doc.get("warranty_status", "") if station_doc else ""),
            "investment_scope": (station_doc.get("investment_scope", []) if station_doc else []) or [],
            "io_code": (station_doc.get("io_code", "") if station_doc else ""),
            "SN": charger_doc.get("SN"),
            "chargeBoxID": charger_doc.get("chargeBoxID"),
            "brand": charger_doc.get("brand"),
            "manufacturer": charger_doc.get("manufacturer"),
            "model": charger_doc.get("model"),
            "power": charger_doc.get("power"),
            "chargerNo": charger_doc.get("chargerNo"),
            "PIFirmware": charger_doc.get("PIFirmware"),
            "chargingCables": charger_doc.get("numberOfCables", 1),
            "status": charger_doc.get("is_active", True),
        }

    else:
        # ค้นหาจาก station_id (logic เดิม)
        doc = station_collection.find_one(
            {"station_id": station_id},
            {
                "_id": 0,
                "station_id": 1,
                "station_name": 1,
                "SN": 1,
                "WO": 1,
                "chargeBoxID": 1,
                "model": 1,
                "power": 1,
                "status": 1,
                "brand": 1,
                "chargerNo": 1,
                "PIFirmware":1,
                "chargingCables": 1,
                "warranty_status": 1,
                "investment_scope": 1,
                "io_code": 1,
            }
        )
        if not doc:
            raise HTTPException(status_code=404, detail="Station not found")

    return {"station": doc}

@router.get("/get_history")
def get_history(
    station_id: str = Query(...),
    start: str = Query(...),
    end: str = Query(...),
    current: UserClaims = Depends(get_current_user),
):
    # ใช้กฎกลางเดียวกับหน้า EV Station เพื่อให้ technician เข้าดูทุกสถานีได้จริง
    from routers.stations import station_match_query

    match_query = station_match_query(current)
    allowed = match_query is not None and station_collection.count_documents(
        {"$and": [match_query, {"station_id": station_id}]}, limit=1
    ) > 0
    if not allowed:
        raise HTTPException(status_code=403, detail="Forbidden station_id")

class RefreshIn(BaseModel):
    # เดิม frontend ส่ง refresh token จาก localStorage มาใน body — รับไว้ช่วงเปลี่ยนผ่าน
    # (tab ที่เปิดค้างก่อน deploy) แล้วย้ายเข้าคุกกี้ให้เลย ปกติ token มากับคุกกี้เท่านั้น
    refresh_token: Optional[str] = None


def _refresh_denied(request: Request, detail: str) -> JSONResponse:
    """401 พร้อมล้างคุกกี้ — กัน middleware ของ Next ปล่อยผ่านด้วย refresh token ที่ใช้ไม่ได้แล้ว"""
    resp = JSONResponse(status_code=401, content={"detail": detail})
    clear_session_cookies(resp, request)
    return resp


@router.post("/refresh")
def refresh(request: Request, response: Response, body: Optional[RefreshIn] = None):
    token = request.cookies.get(REFRESH_COOKIE_NAME) or (body.refresh_token if body else None)
    if not token:
        return _refresh_denied(request, "refresh_token_missing")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except ExpiredSignatureError:
        return _refresh_denied(request, "refresh_token_expired")
    except JWTError:
        return _refresh_denied(request, "Invalid token")

    email = payload.get("sub")
    if not email:
        return _refresh_denied(request, "Invalid token")

    user = users_collection.find_one({"email": email})
    if not user:
        return _refresh_denied(request, "User not found")

    entry = next((t for t in user.get("refreshTokens", []) if t.get("token") == token), None)
    if not entry:
        return _refresh_denied(request, "Invalid refresh token")

    # PyMongo คืน datetime แบบ naive — เดิมเทียบกับ now (aware) ตรง ๆ แล้วโยน TypeError
    # ทำให้ /refresh ตอบ 500 ทุกครั้งและผู้ใช้หลุดไปหน้า login เมื่อ access token หมดอายุ
    now = datetime.now(timezone.utc)
    expires_at = as_utc(entry.get("expiresAt"))
    if expires_at and now > expires_at:
        return _refresh_denied(request, "refresh_token_expired")

    # กำหนด idle timeout ตามบทบาท
    user_role = user.get("role", "user")
    if user_role in STAFF_ROLES:
        idle_timeout = SESSION_IDLE_MINUTES_TECHNICIAN  # None = ไม่มี idle timeout
    else:
        idle_timeout = SESSION_IDLE_MINUTES_DEFAULT  # 15 นาที

    # ตรวจสอบ idle timeout
    idle_at = as_utc(entry.get("lastActiveAt"))
    if idle_timeout is not None and idle_at and (now - idle_at) > timedelta(minutes=idle_timeout):
        return _refresh_denied(request, "session_idle_timeout")

    # กำหนด token expire time ตามบทบาท
    if user_role in STAFF_ROLES:
        token_expire_minutes = ACCESS_TOKEN_EXPIRE_MINUTES_TECHNICIAN  # 24 ชั่วโมง
    else:
        token_expire_minutes = ACCESS_TOKEN_EXPIRE_MINUTES_DEFAULT  # 15 นาที

    # สร้าง access ใหม่ (คง sid เดิม) — ไม่แนบ station_ids ลง token เช่นเดียวกับตอน login
    # (กัน token/คุกกี้ใหญ่เกิน proxy_buffer_size; สิทธิ์สถานีใช้กฎกลางตาม role)
    new_access = create_access_token({
        "sub": user["email"],
        "user_id": str(user["_id"]),
        "username": user.get("username"),
        "role": user_role,
        "company": user.get("company"),
        "sid": entry.get("sid"),
    }, expires_delta=timedelta(minutes=token_expire_minutes))

    # อัปเดต lastActiveAt
    users_collection.update_one(
        {"_id": user["_id"], "refreshTokens.token": token},
        {"$set": {"refreshTokens.$.lastActiveAt": now}}
    )

    # refresh token ตัวเดิมถูกตั้งกลับด้วยอายุที่เหลือ — ถ้ามาจาก body (ช่วงเปลี่ยนผ่าน) ก็ย้ายเข้าคุกกี้ในจังหวะนี้
    refresh_left = int((expires_at - now).total_seconds()) if expires_at else int(
        timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS).total_seconds())
    set_session_cookies(
        response, request,
        new_access, int(timedelta(minutes=token_expire_minutes).total_seconds()),
        token, refresh_left,
    )
    return {"ok": True}


@router.post("/logout")
def logout(request: Request):
    """เพิกถอน session ใน DB แล้วล้างคุกกี้ — เรียกซ้ำหรือเรียกตอนไม่มี session ก็ตอบ 200

    เดิม frontend แค่ลบ localStorage แต่คุกกี้ HttpOnly ยังอยู่ต่ออีก 24 ชม.
    "ออกจากระบบ" แล้วจึงยังเรียก API ได้ด้วยคุกกี้นั้น
    """
    token = request.cookies.get(REFRESH_COOKIE_NAME)
    if token:
        users_collection.update_one(
            {"refreshTokens.token": token},
            {"$pull": {"refreshTokens": {"token": token}}},
        )
    resp = JSONResponse({"msg": "Logged out successfully"})
    clear_session_cookies(resp, request)
    return resp


@router.get("/username")
async def users():
    # ✅ ดึงมาเฉพาะ role = "owner"
    cursor = users_collection.find({"role": "owner"})
    usernames = [u["username"] for u in cursor]

    if not usernames:
        raise HTTPException(status_code=404, detail="owners not found")

    return {"username": usernames}


# ผู้ที่วางแผนงาน CM ได้ (เลือกช่างในขั้น Planning) — planner ตาม flow, admin/owner คุมภาพรวม
ASSIGNER_ROLES: set[str] = {"admin", "owner", "planner"}

@router.get("/users/by-role")
def users_by_role(
    role: str = Query(..., description="role to filter by, e.g. technician"),
    current: UserClaims = Depends(get_current_user),
):
    """รายชื่อ user ตาม role — ใช้เติม dropdown เลือกช่างในขั้น Planning ของ CM"""
    if (current.role or "").lower() not in ASSIGNER_ROLES:
        raise HTTPException(status_code=403, detail="forbidden")

    query = {"role": role.strip().lower()}

    # Planner วางแผนได้เฉพาะช่างในบริษัทเดียวกัน
    # อ่าน company ล่าสุดจาก DB เพื่อไม่ให้ JWT ที่เก่ากว่าข้อมูล profile ทำให้เห็นข้ามบริษัท
    if (current.role or "").lower() == "planner":
        company = (current.company or "").strip()
        if current.user_id:
            try:
                planner_user = users_collection.find_one(
                    {"_id": ObjectId(current.user_id)},
                    {"company": 1},
                )
                company = (planner_user or {}).get("company") or company
            except Exception:
                # ใช้ company จาก claims ต่อได้ กรณี user_id ใน token ไม่ใช่ ObjectId
                pass

        # Planner ที่ไม่มี company จะไม่เห็น technician ใด ๆ
        if not company:
            return {"users": []}
        query["company"] = company

    cursor = users_collection.find(
        query,
        {"_id": 1, "username": 1, "email": 1, "company": 1},
    ).sort("username", 1)
    return {
        "users": [
            {
                "id": str(u["_id"]),
                "username": u.get("username", ""),
                "email": u.get("email", ""),
                "company": u.get("company") or "",
            }
            for u in cursor
        ]
    }

class register(BaseModel):
    username: str
    email: EmailStr
    password: str
    tel: str
    company: str
    role: Literal["admin", "owner"]

@router.post("/insert_users/")
async def create_users(users: register, current: UserClaims = Depends(get_current_user)):
    # ปิด public signup: เฉพาะ admin เท่านั้นที่สร้างผู้ใช้ได้ (super_admin ถูก normalize เป็น admin จึงผ่านด้วย)
    if current.role != "admin":
        raise HTTPException(status_code=403, detail="forbidden")

    email = normalize_email(users.email)

    # ✅ เช็ค email ซ้ำ
    if users_collection.find_one({"email": email}):
        raise HTTPException(status_code=400, detail="อีเมลนี้ถูกใช้งานแล้ว")

    # hash password
    hashed_pw = bcrypt.hashpw(users.password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    
    now = datetime.now(timezone.utc)

    users_collection.insert_one(
    {
        "username" : users.username,
        "email":email,
        "password":hashed_pw,
        "tel":users.tel,
        "refreshTokens": [],
        "role": users.role,
        "company":users.company,
        "createdAt": now,
        "updatedAt": now,
    })
    return {"username": users.username, "email": email}


@router.get("/all-users/")
def all_users(current: UserClaims = Depends(get_current_user)):
    # อนุญาตเฉพาะ admin (super_admin ผ่านด้วยเพราะ normalize เป็น admin)
    if current.role != "admin":
        raise HTTPException(status_code=403, detail="forbidden")

    cursor = users_collection.find({}, {"password": 0, "refreshTokens": 0})
    docs = list(cursor)
    for d in docs:
        if "_id" in d:
            d["_id"] = str(d["_id"])
        # user เก่าที่ยังเป็น "engineer" ใน DB → แสดงเป็น "planner" ให้ตรงกับ dropdown
        if d.get("role"):
            d["role"] = canonical_role(d["role"])
    return {"users": docs}

class addUsers(BaseModel):
    username:str
    email:str
    password:str
    tel:str
    company_name:str
    station_id:Optional[Union[str, int, List[Union[str, int]]]] = None
    role: Literal["admin", "owner", "technician", "cs", "planner"]
    ai_package: Optional[AiPackage] = None

class UserOut(BaseModel):
    id: str
    username: str
    email: EmailStr
    role: str
    company: str
    station_id: List[str] = Field(default_factory=list)
    tel: str

@router.post("/add_users/", response_model=UserOut, status_code=201)
def insert_users(body: addUsers, current: UserClaims = Depends(get_current_user)):
    if current.role != "admin":
        raise HTTPException(status_code=403, detail="forbidden")

    email = normalize_email(body.email)
    hashed = bcrypt.hashpw(body.password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    station_ids: List[str] = []
    if body.station_id is not None and body.station_id != "":
        if isinstance(body.station_id, list):
            station_ids = [str(x) for x in body.station_id if str(x).strip() != ""]
        else:
            station_ids = [str(body.station_id)]

    doc = {
        "username": body.username.strip(),
        "email": email,
        "password": hashed,
        "role": body.role,
        "company": (body.company_name or "").strip() or None,
        "tel": (body.tel or "").strip() or None,
        "station_id": station_ids,
        "refreshTokens": [],
        "createdAt": datetime.now(timezone.utc),
        "ai_package": body.ai_package.model_dump() if body.ai_package else {"enabled": False},
    }

    try:
        res = users_collection.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Email already exists")

    return {
        "id": str(res.inserted_id),
        "username": doc["username"],
        "email": doc["email"],
        "role": doc["role"],
        "company": doc.get("company"),
        "station_id": doc["station_id"],
        "tel": doc.get("tel"),
        "createdAt": doc["createdAt"],
    }

@router.delete("/delete_users/{user_id}", status_code=204)
def delete_user(user_id: str, current: UserClaims = Depends(get_current_user)):
    # (ทางเลือก) บังคับสิทธิ์เฉพาะ admin/owner
    if current.role not in ("admin", "owner"):
        raise HTTPException(status_code=403, detail="Forbidden")

    try:
        oid = ObjectId(user_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid user id")

    res = users_collection.delete_one({"_id": oid})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")

    # 204 No Content
    return Response(status_code=204)

class UserUpdate(BaseModel):
    username: str | None = None
    email: EmailStr | None = None
    tel : str | None = None      # ใช้ "phone" ให้สอดคล้องเอกสารที่คุณมี
    company: str | None = None
    role: Literal["admin", "owner", "technician", "cs", "planner"] | None = None  # admin เท่านั้นที่แก้ได้
    is_active: bool | None = None # admin เท่านั้นที่แก้ได้
    password: str | None = None   # จะถูกแฮชเสมอถ้ามีค่า
    station_id: Optional[List[str]] = None  # สำหรับ technician
    ai_package: Optional[AiPackage] = None

def hash_password(raw: str) -> str:
    return bcrypt.hashpw(raw.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

# ฟิลด์ที่อนุญาต
ALLOW_FIELDS_ADMIN_USER = {"username","email","password","role","company","tel","is_active","station_id","ai_package"}  
ALLOW_FIELDS_SELF_USER  = {"username", "email", "tel", "company", "password"}


@router.patch("/user_update/{id}", response_model=UserOut)
def update_user(id: str, body: UserUpdate, current: UserClaims = Depends(get_current_user)):
    oid = to_object_id_or_400(id)

    doc = users_collection.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="user not found")

    # ── Permission: admin ทำได้ทั้งหมด, owner ได้เฉพาะของตัวเอง, อื่น ๆ ห้าม
    # if current.role == "admin":
    #     pass  # ผ่าน
    # elif current.role == "owner":
    #     if current.user_id != str(oid):
    #         raise HTTPException(status_code=403, detail="forbidden")
    # else:
    #     # กันบทบาทอื่น ๆ (เช่น user) ไม่ให้เข้ามาอัปเดต
    #     raise HTTPException(status_code=403, detail="forbidden")

    # ── เตรียม incoming fields
    incoming = {
        k: (v.strip() if isinstance(v, str) else v)
        for k, v in body.model_dump(exclude_none=True).items()
    }
    if not incoming:
        raise HTTPException(status_code=400, detail="no fields to update")

    # ── จำกัดฟิลด์ตามบทบาท
    # แนะนำให้ประกาศสองชุดนี้ไว้ด้านบนไฟล์หรือไฟล์ settings:
    ALLOW_FIELDS_ADMIN_USER = {"username","email","password","role","company","tel","is_active","station_id","ai_package"}
    ALLOW_FIELDS_SELF_OWNER = {"username", "email", "password", "tel"}   # ปรับตามที่อยากให้แก้เองได้
    if current.role == "admin":
        allowed = ALLOW_FIELDS_ADMIN_USER
    else:  # owner
        allowed = ALLOW_FIELDS_SELF_OWNER

    payload = {k: v for k, v in incoming.items() if k in allowed}
    if not payload:
        # raise HTTPException(status_code=400, detailฟแ="no permitted fields to update")
        raise HTTPException(status_code=400, detail="no permitted fields to update")

    # ── normalize email ให้ตรงกับตอนสร้าง user (ไม่งั้นแก้อีเมลเป็นตัวใหญ่แล้ว login ไม่ได้)
    if "email" in payload:
        payload["email"] = normalize_email(payload["email"])

    # ── แฮชรหัสผ่านถ้ามี
    if "password" in payload:
        payload["password"] = hash_password(payload["password"])

    # ── validate station_id (ต้องเป็น list of strings)
    if "station_id" in payload:
        if payload["station_id"] is None:
            payload["station_id"] = []
        elif not isinstance(payload["station_id"], list):
            raise HTTPException(status_code=400, detail="station_id must be a list of strings")
        else:
            # ตรวจสอบว่าทั้งหมดเป็น string
            if not all(isinstance(s, str) for s in payload["station_id"]):
                raise HTTPException(status_code=400, detail="station_id must contain only strings")

    # ── validate is_active (admin เท่านั้นที่เข้ามาถึงบรรทัดนี้ได้อยู่แล้ว)
    if "is_active" in payload and not isinstance(payload["is_active"], bool):
        raise HTTPException(status_code=400, detail="is_active must be boolean")

    now = datetime.now(timezone.utc)

    if "ai_package" in payload and hasattr(payload["ai_package"], "model_dump"):
        payload["ai_package"] = payload["ai_package"].model_dump()
    payload["updatedAt"] = now

    try:
        users_collection.update_one({"_id": oid}, {"$set": payload})
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="duplicate email or username")

    newdoc = users_collection.find_one({"_id": oid}) or {}
    created_at = newdoc.get("createdAt") or now
    if "createdAt" not in newdoc:
        users_collection.update_one({"_id": oid}, {"$set": {"createdAt": created_at}})

    return {
        "id": str(newdoc["_id"]),
        "username": newdoc.get("username", ""),
        "email": newdoc.get("email", ""),
        "role": newdoc.get("role", ""),
        "company": (newdoc.get("company") or ""),
        "station_id": list(newdoc.get("station_id") or []),
        "tel": (newdoc.get("tel") or ""),
        "createdAt": created_at,
        "updatedAt": newdoc.get("updatedAt", now),
    }

