"use client";

import { useState, useEffect } from "react";
import {
    Dialog,
    DialogHeader,
    DialogBody,
    DialogFooter,
    Button,
    Input,
    Typography,
    Select,
    Option,
    Switch,
} from "@material-tailwind/react";
import LoadingOverlay from "@/app/dashboard/components/Loadingoverlay";
import { apiFetch } from "@/utils/api";
import { UserRole } from "@/utils/roles";
import useLanguage, { type Lang } from "@/utils/useLanguage";

const T = {
    saving: { th: "กำลังบันทึก...", en: "Saving..." },
    addNewUser: { th: "เพิ่มผู้ใช้ใหม่", en: "Add New User" },
    roleOwner: { th: "เจ้าของ", en: "Owner" },
    roleAdmin: { th: "ผู้ดูแลระบบ", en: "Admin" },
    roleTechnician: { th: "ช่างเทคนิค", en: "Technician" },
    roleCS: { th: "CS", en: "CS" },
    rolePlanner: { th: "ผู้วางแผน", en: "Planner" },
} as const;

const t = (k: keyof typeof T, lang: Lang) => T[k][lang];

const ALL_ROLES: UserRole[] = ["owner", "admin", "technician", "cs", "planner"];
const ROLE_LABEL: Record<UserRole, keyof typeof T> = {
    owner: "roleOwner",
    admin: "roleAdmin",
    technician: "roleTechnician",
    cs: "roleCS",
    planner: "rolePlanner",
};

export type NewUserPayload = {
    username: string;
    password: string;
    email: string;
    role: UserRole;
    company_name?: string;
    payment: "y" | "n";
    tel: string;
    station_id?: string | string[];
    ai_package?: { enabled: boolean };
};

type FormState = Omit<NewUserPayload, "station_id"> & {
    station_id?: string;
};

type Station = {
    station_id: string;
    station_name: string;
};


type Props = {
    open: boolean;
    onClose: () => void;
    onSubmit: (payload: NewUserPayload) => Promise<void> | void;
    loading?: boolean;
    /** จำกัด role ที่เลือกได้ (planner = technician / cs / planner) — ไม่ส่ง = ทุก role */
    allowedRoles?: UserRole[];
    /** มีค่า = ช่อง Company เป็น dropdown จากลิสต์นี้ (planner: บริษัทตัวเอง + outsource ของตัวเอง) */
    companyOptions?: string[];
};

export default function AddUserModal({ open, onClose, onSubmit, loading, allowedRoles, companyOptions }: Props) {
    const { lang } = useLanguage();
    const roles = allowedRoles?.length ? ALL_ROLES.filter((r) => allowedRoles.includes(r)) : ALL_ROLES;
    const defaultRole = roles[0];
    const [form, setForm] = useState<NewUserPayload>({
        username: "",
        password: "",
        email: "",
        role: defaultRole,
        company_name: "",
        payment: "y",
        tel: "",
        station_id: undefined,
        ai_package: { enabled: false },
    });
    const [stations, setStations] = useState<Station[]>([]);
    const [loadingStations, setLoadingStations] = useState(false);
    const [stationSearchValue, setStationSearchValue] = useState("");
    const [showStationDropdown, setShowStationDropdown] = useState(false);
    const [selectedStations, setSelectedStations] = useState<Station[]>([]);

    const onChange = (k: keyof NewUserPayload, v: any) =>
        setForm((s) => ({ ...s, [k]: v }));

    // role / company ที่เลือกได้รู้ทีหลัง (หลังเช็ค session) — ตอนเปิดฟอร์มดึงค่าให้อยู่ในตัวเลือกเสมอ
    useEffect(() => {
        if (!open) return;
        setForm((s) => ({
            ...s,
            role: roles.includes(s.role) ? s.role : defaultRole,
            company_name:
                companyOptions && !companyOptions.includes(s.company_name ?? "")
                    ? companyOptions[0] ?? ""
                    : s.company_name,
        }));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, allowedRoles, companyOptions]);

    // โหลด stations เมื่อ modal เปิด
    useEffect(() => {
        if (!open) return;

        const fetchStations = async () => {
            try {
                setLoadingStations(true);
                const res = await apiFetch("/my-stations/detail");
                if (!res.ok) return;
                const data = await res.json();
                setStations(data?.stations || (Array.isArray(data) ? data : []));
            } catch (error) {
                console.error("Error fetching stations:", error);
            } finally {
                setLoadingStations(false);
            }
        };

        fetchStations();
    }, [open]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        const payload: NewUserPayload = {
            ...form,
            username: form.username.trim(),
            email: form.email.trim(),
            company_name: form.company_name?.trim() || undefined,
            tel: form.tel.trim(),
            ...(form.role === "technician" && selectedStations.length > 0
                ? { station_id: selectedStations.map(s => s.station_id) }
                : {}),
        };
        try {
            await onSubmit(payload);
            resetAndClose();
        } catch (error) {
            console.error(error);
        }
    };

    const resetAndClose = () => {
        setForm({
            username: "",
            password: "",
            email: "",
            role: defaultRole,
            tel: "",
            company_name: "",
            payment: "y",
            station_id: undefined,
            ai_package: { enabled: false },
        });
        setStationSearchValue("");
        setShowStationDropdown(false);
        setSelectedStations([]);
        onClose();
    };

    return (
        <Dialog open={open} handler={resetAndClose} size="md" className="tw-relative tw-space-y-5 tw-px-8 tw-py-4">
            {/* Loading Overlay — ครอบทับ modal ตอน saving */}
            <LoadingOverlay show={!!loading} text={t("saving", lang)} />

            <DialogHeader className="tw-flex tw-items-center tw-justify-between">
                <Typography variant="h5" color="blue-gray">{t("addNewUser", lang)}</Typography>
                <Button variant="text" onClick={resetAndClose} disabled={loading}>✕</Button>
            </DialogHeader>

            <form onSubmit={handleSubmit}>
                <DialogBody className="tw-space-y-6 tw-px-6 tw-py-4">

                    <div className="tw-flex tw-flex-col tw-gap-4">
                        <Input
                            label="Username"
                            required
                            value={form.username}
                            onChange={(e) => onChange("username", e.target.value)}
                            crossOrigin={undefined}
                        />
                        <Input
                            label="Email"
                            type="email"
                            required
                            value={form.email}
                            onChange={(e) => onChange("email", e.target.value)}
                            crossOrigin={undefined}
                        />
                        <Input
                            label="Password"
                            type="password"
                            required
                            value={form.password}
                            onChange={(e) => onChange("password", e.target.value)}
                            crossOrigin={undefined}
                        />
                        <Input
                            label="Tel"
                            required
                            value={form.tel}
                            onChange={(e) => onChange("tel", e.target.value)}
                            crossOrigin={undefined}
                        />
                        {companyOptions ? (
                            <div className="tw-relative tw-h-10 tw-w-full">
                                <select
                                    required
                                    value={form.company_name ?? ""}
                                    onChange={(e) => onChange("company_name", e.target.value)}
                                    className="tw-h-full tw-w-full tw-cursor-pointer tw-appearance-none tw-rounded-[7px] tw-border tw-border-blue-gray-200 tw-bg-transparent tw-px-3 tw-py-2.5 tw-font-sans tw-text-sm tw-font-normal tw-text-blue-gray-700 tw-outline-none focus:tw-border-2 focus:tw-border-gray-900"
                                >
                                    {companyOptions.map((c) => (
                                        <option key={c} value={c}>{c}</option>
                                    ))}
                                </select>
                                <label className="tw-pointer-events-none tw-absolute tw-left-3 tw--top-1.5 tw-bg-white tw-px-1 tw-text-[11px] tw-font-normal tw-text-blue-gray-400">
                                    Company *
                                </label>
                            </div>
                        ) : (
                            <Input
                                label="Company"
                                required
                                value={form.company_name}
                                onChange={(e) => onChange("company_name", e.target.value)}
                                crossOrigin={undefined}
                            />
                        )}
                        <div>
                            <div className="tw-flex tw-items-center tw-gap-1">
                                <Select
                                    value={form.role}
                                    onChange={(v) => {
                                        onChange("role", String(v ?? form.role) as UserRole);
                                        if (v !== "technician") {
                                            setForm((s) => ({ ...s, station_id: undefined }));
                                        }
                                    }}
                                    label="Role"
                                >
                                    {roles.map((r) => (
                                        <Option key={r} value={r}>{t(ROLE_LABEL[r], lang)}</Option>
                                    ))}

                                </Select>

                            </div>
                        </div>
                        {form.role === "owner" && (
                            <div className="tw-border tw-border-blue-gray-100 tw-rounded-xl tw-p-4 tw-space-y-3">
                                <Typography variant="small" className="!tw-font-semibold tw-text-blue-gray-700">
                                    AI Package
                                </Typography>
                                <div className="tw-flex tw-items-center tw-justify-between">
                                    <Typography variant="small" color="blue-gray">Enable AI Modules</Typography>
                                    <Switch
                                        checked={form.ai_package?.enabled ?? false}
                                        onChange={() => setForm(s => ({
                                            ...s,
                                            ai_package: { enabled: !(s.ai_package?.enabled ?? false) }
                                        }))}
                                        crossOrigin={undefined}
                                    />
                                </div>
                            </div>
                        )}

                        {/* station assignment เป็นข้อมูลประกอบแบบ optional; สิทธิ์จริงอิง role/company/brand */}
                        {form.role === "technician" && (
                            <div className="tw-relative">
                                <div className="tw-flex tw-items-center tw-gap-1">
                                    <Input
                                        label="Assigned Stations (optional)"
                                        placeholder="Type to search..."
                                        value={stationSearchValue}
                                        onChange={(e) => {
                                            setStationSearchValue(e.target.value);
                                            setShowStationDropdown(true);
                                        }}
                                        onFocus={() => setShowStationDropdown(true)}
                                        disabled={loadingStations || stations.length === 0}
                                        crossOrigin={undefined}
                                    />
                                </div>

                                {/* Dropdown suggestions */}
                                {showStationDropdown && (
                                    <div className="tw-absolute tw-top-full tw-left-0 tw-right-0 tw-z-10 tw-mt-1 tw-max-h-48 tw-overflow-y-auto tw-bg-white tw-border tw-border-gray-300 tw-rounded-lg tw-shadow-lg">
                                        {stations
                                            .filter((station) =>
                                                !selectedStations.find(s => s.station_id === station.station_id) &&
                                                (station.station_name
                                                    .toLowerCase()
                                                    .includes(stationSearchValue.toLowerCase()) ||
                                                    station.station_id
                                                        .toLowerCase()
                                                        .includes(stationSearchValue.toLowerCase()))
                                            )
                                            .map((station) => (
                                                <div
                                                    key={station.station_id}
                                                    onClick={() => {
                                                        setSelectedStations([...selectedStations, station]);
                                                        setStationSearchValue("");
                                                        setShowStationDropdown(false);
                                                    }}
                                                    className="tw-px-4 tw-py-2 tw-cursor-pointer hover:tw-bg-blue-50 tw-border-b tw-border-gray-100 last:tw-border-b-0"
                                                >
                                                    <Typography variant="small" className="tw-font-medium">
                                                        {station.station_name}
                                                    </Typography>
                                                    <Typography variant="small" color="gray">
                                                        {station.station_id}
                                                    </Typography>
                                                </div>
                                            ))}

                                        {stationSearchValue && stations.filter((station) =>
                                            !selectedStations.find(s => s.station_id === station.station_id) &&
                                            (station.station_name
                                                .toLowerCase()
                                                .includes(stationSearchValue.toLowerCase()) ||
                                                station.station_id
                                                    .toLowerCase()
                                                    .includes(stationSearchValue.toLowerCase()))
                                        ).length === 0 && (
                                                <div className="tw-px-4 tw-py-3 tw-text-center tw-text-gray-500">
                                                    No stations found
                                                </div>
                                            )}
                                    </div>
                                )}

                                {loadingStations && (
                                    <Typography variant="small" color="gray" className="tw-mt-1">
                                        Loading stations...
                                    </Typography>
                                )}
                                {!loadingStations && stations.length === 0 && (
                                    <Typography variant="small" color="red" className="tw-mt-1">
                                        No stations available
                                    </Typography>
                                )}

                                {/* Selected Stations Tags */}
                                {selectedStations.length > 0 && (
                                    <div className="tw-mt-3">
                                        <Typography variant="small" className="tw-font-semibold tw-mb-2">
                                            Selected Stations ({selectedStations.length}):
                                        </Typography>
                                        <div className="tw-flex tw-flex-wrap tw-gap-2">
                                            {selectedStations.map((station) => (
                                                <div
                                                    key={station.station_id}
                                                    className="tw-flex tw-items-center tw-gap-2 tw-bg-blue-100 tw-text-blue-700 tw-px-3 tw-py-1 tw-rounded-full tw-text-sm"
                                                >
                                                    <span>{station.station_name}</span>
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            setSelectedStations(
                                                                selectedStations.filter(s => s.station_id !== station.station_id)
                                                            );
                                                        }}
                                                        className="tw-font-bold tw-cursor-pointer hover:tw-text-blue-900"
                                                    >
                                                        ×
                                                    </button>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </DialogBody>

                <DialogFooter className="tw-gap-2">
                    <Button variant="outlined" onClick={resetAndClose} type="button" disabled={loading}>Cancel</Button>
                    <Button type="submit" className="tw-bg-blue-600" disabled={loading}>
                        {loading ? "Saving..." : "Create User"}
                    </Button>
                </DialogFooter>
            </form>
        </Dialog>
    );
}
