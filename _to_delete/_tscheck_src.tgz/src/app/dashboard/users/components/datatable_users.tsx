"use client";

import ConfirmDialog from "@/app/dashboard/stations/components/ConfirmDialog";
import LoadingOverlay from "@/app/dashboard/components/Loadingoverlay";

import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  getCoreRowModel,
  getPaginationRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
  flexRender,
  type Row,
} from "@tanstack/react-table";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Typography,
  CardFooter,
  Input,
  Alert,
  Dialog,
  DialogHeader,
  DialogBody,
  DialogFooter,
  Select,
  Option,
  Switch,
} from "@material-tailwind/react";
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronUpDownIcon,
  PencilSquareIcon,
  TrashIcon,
} from "@heroicons/react/24/solid";

// components
import AddUser, { NewUserPayload } from "@/app/dashboard/users/components/adduser";
import { apiFetch, getSessionProfile } from "@/utils/api";
import type { UserRole } from "@/utils/roles";
import useLanguage, { type Lang } from "@/utils/useLanguage";
import TableSkeletonRows from "@/components/TableSkeletonRows";

/* -------------------- Translations -------------------- */
const T = {
  checkingSession: { th: "กำลังตรวจสอบเซสชัน…", en: "Checking session…" },
  loadingData: { th: "กำลังโหลดข้อมูล...", en: "Loading data..." },
  loading: { th: "กำลังโหลด...", en: "Loading..." },
  pageTitle: { th: "จัดการผู้ใช้และสิทธิ์", en: "Users & Roles Management" },
  pageSubtitle: {
    th: "จัดการผู้ใช้: เพิ่ม แก้ไข หรือลบผู้ใช้ออกจากระบบ",
    en: "Manage Users: Add, Edit, or Remove users from the system.",
  },
  addUser: { th: "เพิ่มผู้ใช้", en: "ADD USER" },
  entriesPerPage: { th: "รายการต่อหน้า", en: "entries per page" },
  search: { th: "ค้นหา", en: "Search" },
  colNo: { th: "ลำดับ", en: "No." },
  colUsername: { th: "ชื่อผู้ใช้", en: "username" },
  colEmail: { th: "อีเมล", en: "email" },
  colTel: { th: "เบอร์โทร", en: "tel" },
  colCompany: { th: "บริษัท", en: "company" },
  colRole: { th: "สิทธิ์", en: "role" },
  colActions: { th: "จัดการ", en: "actions" },
  editUser: { th: "แก้ไขผู้ใช้", en: "Edit user" },
  deleteUser: { th: "ลบผู้ใช้", en: "Delete user" },
  noUsersFound: { th: "ไม่พบผู้ใช้", en: "No users found" },
  usersSuffix: { th: "ผู้ใช้", en: "Users" },
  page: { th: "หน้า", en: "Page" },
  of: { th: "จาก", en: "of" },
  editUserTitle: { th: "แก้ไขผู้ใช้", en: "Edit User" },
  username: { th: "ชื่อผู้ใช้", en: "Username" },
  email: { th: "อีเมล", en: "Email" },
  company: { th: "บริษัท", en: "Company" },
  tel: { th: "เบอร์โทร", en: "tel" },
  role: { th: "สิทธิ์", en: "Role" },
  aiPackage: { th: "แพ็กเกจ AI", en: "AI Package" },
  enableAiModules: { th: "เปิดใช้งานโมดูล AI", en: "Enable AI Modules" },
  selectStation: { th: "เลือกสถานี", en: "Select Station" },
  typeToSearch: { th: "พิมพ์เพื่อค้นหา...", en: "Type to search..." },
  noStationsFound: { th: "ไม่พบสถานี", en: "No stations found" },
  loadingStations: { th: "กำลังโหลดสถานี...", en: "Loading stations..." },
  noStationsAvailable: { th: "ไม่มีสถานีให้เลือก", en: "No stations available" },
  selectedStations: { th: "สถานีที่เลือก", en: "Selected Stations" },
  cancel: { th: "ยกเลิก", en: "Cancel" },
  saving: { th: "กำลังบันทึก...", en: "Saving..." },
  saveChanges: { th: "บันทึกการเปลี่ยนแปลง", en: "Save Changes" },
  deleteTitle: { th: "ลบผู้ใช้?", en: "Delete user?" },
  delete: { th: "ลบ", en: "Delete" },
  emailAlreadyUsed: { th: "อีเมลนี้ถูกใช้แล้ว", en: "This email is already in use" },
  createUserFailed: { th: "สร้างผู้ใช้ไม่สำเร็จ", en: "Failed to create user" },
  createSuccess: { th: "สร้างผู้ใช้สำเร็จ", en: "Create success" },
  updateSuccess: { th: "อัปเดตสำเร็จ", en: "Update success" },
  updateFailed: { th: "อัปเดตไม่สำเร็จ", en: "Update failed" },
  deleteSuccess: { th: "ลบสำเร็จ", en: "Delete success" },
  deleteUserFailed: { th: "ลบผู้ใช้ไม่สำเร็จ", en: "Failed to delete user" },
  userNotFound: { th: "ไม่พบผู้ใช้นี้", en: "User not found" },
  networkError: { th: "เกิดข้อผิดพลาดของเครือข่าย/เซิร์ฟเวอร์", en: "Network/Server error" },
  forbidden: { th: "ไม่มีสิทธิ์ทำรายการนี้", en: "You don't have permission for this action" },
  plannerNoCompany: {
    th: "บัญชีของคุณยังไม่ได้ระบุบริษัท จึงเพิ่มผู้ใช้ไม่ได้ — กรุณาติดต่อ admin",
    en: "Your account has no company set, so you can't add users — please contact an admin",
  },
} as const;

// role ที่ planner เพิ่ม/แก้ได้ — ต้องตรงกับ PLANNER_MANAGED_ROLES ใน backend/routers/users.py
const PLANNER_ROLES: UserRole[] = ["technician", "cs", "planner"];
const EDIT_ROLE_OPTIONS: { value: UserRole; label: string }[] = [
  { value: "admin", label: "admin" },
  { value: "owner", label: "owner" },
  { value: "technician", label: "Technician" },
  { value: "cs", label: "CS" },
  { value: "planner", label: "Planner" },
];

const t = (k: keyof typeof T, lang: Lang) => T[k][lang];

/* -------------------- Types -------------------- */
type UserRow = {
  id?: string;
  username?: string;
  email?: string;
  role?: string;
  company?: string;
  tel?: string;
  station_id?: string[];
  ai_package?: { enabled: boolean; expires_at?: string };
};

export type UserUpdatePayload = {
  username?: string;
  email?: string;
  role?: string;
  company?: string;
  tel?: string;
};



/* -------------------- Component -------------------- */
export default function SearchDataTables() {
  const { lang } = useLanguage();
  const router = useRouter();

  /* --- Auth state --- */
  const [authChecked, setAuthChecked] = useState(false);
  const [meRole, setMeRole] = useState<string>("user");
  const [meId, setMeId] = useState<string>("");
  const isAdmin = meRole === "admin";
  // planner: เห็น/เพิ่ม/แก้ได้เฉพาะ technician / cs / planner ของบริษัทตัวเอง + outsource ของตัวเอง (ลบไม่ได้)
  const isPlanner = meRole === "planner";
  const [companyOptions, setCompanyOptions] = useState<string[] | null>(null);

  // ตรวจ session + ตั้ง meRole + ปักธง authChecked (และ redirect ถ้าไม่ผ่าน)
  // JWT อยู่ในคุกกี้ HttpOnly: อายุ token ตรวจที่ middleware + backend ส่วน role มากับโปรไฟล์
  useEffect(() => {
    const profile = getSessionProfile();
    if (!profile) {
      const next = encodeURIComponent(window.location.pathname);
      router.replace(`/auth/signin/basic?next=${next}`);
      return;
    }
    if (profile.role) setMeRole(profile.role);
    setMeId(String(profile.user_id ?? ""));
    setAuthChecked(true);
  }, [router]);

  // ตัวเลือกช่อง Company ของ planner (บริษัทตัวเอง + outsource) — admin พิมพ์เองได้อิสระ
  useEffect(() => {
    if (!authChecked || !isPlanner) return;
    let alive = true;
    (async () => {
      try {
        const res = await apiFetch(`/users/manageable-companies`);
        const json = res.ok ? await res.json() : {};
        if (alive) setCompanyOptions(Array.isArray(json?.companies) ? json.companies : []);
      } catch {
        if (alive) setCompanyOptions([]);
      }
    })();
    return () => { alive = false; };
  }, [authChecked, isPlanner]);

  /* --- Table/UI states --- */
  const [data, setData] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const [sorting, setSorting] = useState<any>([]);
  const [filtering, setFiltering] = useState("");
  const [openAdd, setOpenAdd] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ type: "success" | "error"; msg: string } | null>(null);

  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    loading: boolean;
  }>({ open: false, title: "", message: "", onConfirm: () => { }, loading: false });

  const closeConfirm = () => setConfirmDialog(prev => ({ ...prev, open: false, loading: false }));

  const [openEdit, setOpenEdit] = useState(false);
  const [editingRow, setEditingRow] = useState<UserRow | null>(null);
  const [roleValue, setRoleValue] = useState<string>("user");
  const [availableStations, setAvailableStations] = useState<any[]>([]);
  const [loadingStations, setLoadingStations] = useState(false);
  const [stationSearchValue, setStationSearchValue] = useState("");
  const [showStationDropdown, setShowStationDropdown] = useState(false);
  const [selectedStations, setSelectedStations] = useState<any[]>([]);
  const [aiPackage, setAiPackage] = useState<{ enabled: boolean; expires_at: string }>({
    enabled: false,
    expires_at: "",
  });

  const stationBoxRef = useRef<HTMLDivElement>(null);

  // ปิด dropdown เมื่อคลิกนอกกล่อง
  useEffect(() => {
    if (!showStationDropdown) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (stationBoxRef.current && !stationBoxRef.current.contains(e.target as Node)) {
        setShowStationDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showStationDropdown]);

  // ดึงข้อมูลผู้ใช้หลัง auth ผ่านเท่านั้น
  useEffect(() => {
    if (!authChecked) return;
    (async () => {
      try {
        const res = await apiFetch(`/all-users/`);
        if (res.status === 401 || res.status === 403) {
          const next = encodeURIComponent(window.location.pathname);
          router.replace(`/auth/signin/basic?next=${next}`);
          return;
        }
        if (!res.ok) {
          setErr(`Fetch failed: ${res.status}`);
          setData([]);
          return;
        }
        const json = await res.json();
        const list = Array.isArray(json?.users) ? (json.users as any[]) : [];
        const rows: UserRow[] = list.map((u) => ({
          id: u.id || u._id || undefined,
          username: u.username ?? "-",
          email: u.email ?? "-",
          role: u.role ?? "-",
          company: u.company ?? "-",
          station_id: u.station_id ?? [],
          tel: u.tel ?? "-",
          ai_package: u.ai_package ?? undefined,
        }));
        setData(rows);
      } catch {
        setErr(t("networkError", lang));
        setData([]);
      } finally {
        setLoading(false);
      }
    })();
  }, [authChecked, router]);

  // ตั้งค่า default role ตอนเปิด dialog แก้ไข
  useEffect(() => {
    if (openEdit && editingRow) {
      setRoleValue(editingRow.role ?? "user");
      // ตั้งค่า selected stations จากข้อมูล editing row
      if (editingRow.station_id && editingRow.station_id.length > 0) {
        setSelectedStations(
          editingRow.station_id.map((id: string) => ({
            station_id: id,
            station_name: id, // จะถูก update เมื่อโหลด stations
          }))
        );

      } else {
        setSelectedStations([]);
      }

      const pkg = (editingRow as any)?.ai_package;
      setAiPackage({
        enabled: pkg?.enabled ?? false,
        expires_at: pkg?.expires_at ? pkg.expires_at.split("T")[0] : "",
      });
    }
  }, [openEdit, editingRow]);

  // ดึงข้อมูล stations เมื่อเปิด edit dialog
  useEffect(() => {
    if (!openEdit) return;
    (async () => {
      try {
        setLoadingStations(true);
        const res = await apiFetch(`/my-stations/detail`);
        if (res.ok) {
          const json = await res.json();
          const stations = json?.stations || (Array.isArray(json) ? json : []);
          setAvailableStations(stations);
        }
      } catch (e) {
        console.error("Failed to fetch stations", e);
      } finally {
        setLoadingStations(false);
      }
    })();
  }, [openEdit, editingRow]);

  // อัปเดต station names เมื่อ availableStations เปลี่ยน
  useEffect(() => {
    if (selectedStations.length > 0 && availableStations.length > 0) {
      const updated = selectedStations.map((selected: any) => {
        const found = availableStations.find((s: any) => s.station_id === selected.station_id);
        return found ? found : selected;
      });
      setSelectedStations(updated);
    }
  }, [availableStations]);

  const plannerNoCompany = isPlanner && companyOptions !== null && companyOptions.length === 0;
  const editingSelf = !!editingRow?.id && editingRow.id === meId;
  // company เดิมที่ไม่อยู่ในลิสต์ (เช่นพิมพ์ต่างตัวพิมพ์) ต้องไม่หายจาก dropdown
  const editCompanyChoices = (() => {
    const opts = companyOptions ?? [];
    const cur = (editingRow?.company ?? "").trim();
    return cur && cur !== "-" && !opts.includes(cur) ? [cur, ...opts] : opts;
  })();

  /* -------------------- Handlers -------------------- */
  const handleEdit = (row: UserRow) => {
    setEditingRow(row);
    setOpenEdit(true);
  };

  const handleCreateUser = async (payload: NewUserPayload) => {
    try {
      setSaving(true);
      const res = await apiFetch(`/add_users/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.status === 401) {
        const next = encodeURIComponent(window.location.pathname);
        router.replace(`/auth/signin/basic?next=${next}`);
        return;
      }
      if (res.status === 403) throw new Error(t("forbidden", lang));
      if (res.status === 409) throw new Error(t("emailAlreadyUsed", lang));
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || `Create failed: ${res.status}`);
      }

      const created = await res.json();
      setData((prev) => [
        {
          id: created.id,
          username: created.username,
          email: created.email,
          role: created.role,
          company: created.company ?? "-",
          station_id: created.station_id ?? [],
          tel: created.tel ?? "-",
        },
        ...prev,
      ]);

      setOpenAdd(false);
      setNotice({ type: "success", msg: t("createSuccess", lang) });
      setTimeout(() => setNotice(null), 3000);
    } catch (e: any) {
      console.error(e);
      setNotice({ type: "error", msg: e.message || t("createUserFailed", lang) });
      setTimeout(() => setNotice(null), 3500);
    } finally {
      setSaving(false);
    }
  };

  async function handleUpdateUser(id: string, payload: Partial<UserRow> & { password?: string }) {
    const body: any = {};
    if (payload.username !== undefined) body.username = payload.username?.trim();
    if (payload.email !== undefined) body.email = payload.email?.trim();
    if (payload.company !== undefined) body.company = (payload.company || "").trim();
    if (payload.role !== undefined) body.role = payload.role;
    if (payload.tel !== undefined) body.tel = payload.tel?.trim();
    if ((payload as any).station_id !== undefined) body.station_id = (payload as any).station_id;
    if ((payload as any).password) body.password = String((payload as any).password);
    if ((payload as any).ai_package !== undefined) body.ai_package = (payload as any).ai_package;

    const res = await apiFetch(`/user_update/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (res.status === 401) {
      const next = encodeURIComponent(window.location.pathname);
      router.replace(`/auth/signin/basic?next=${next}`);
      return;
    }
    if (res.status === 403) throw new Error(t("forbidden", lang));

    const raw = await res.text();
    if (!res.ok) throw new Error(raw || `Update failed: ${res.status}`);

    let updated: any = {};
    try { updated = raw ? JSON.parse(raw) : {}; } catch { }

    setData(prev =>
      prev.map(u =>
        u.id === id
          ? {
            ...u,
            username: updated.username ?? u.username,
            email: updated.email ?? u.email,
            company: updated.company ?? u.company,
            role: updated.role ?? u.role,
            tel: updated.tel ?? u.tel,
            station_id: updated.station_id ?? u.station_id,
          }
          : u
      )
    );

    setOpenEdit(false);
    setNotice({ type: "success", msg: t("updateSuccess", lang) });
    setTimeout(() => setNotice(null), 2500);
  }

  // const handleDelete = async (row: UserRow) => {
  //   if (!row.id) return alert("ไม่พบ id ของผู้ใช้");
  //   if (!confirm(`ต้องการลบผู้ใช้ "${row.username}" ใช่หรือไม่?`)) return;

  //   try {
  //     const res = await apiFetch(`/delete_users/${row.id}`, { method: "DELETE" });

  //     if (res.status === 401 || res.status === 403) {
  //       const next = encodeURIComponent(window.location.pathname);
  //       router.replace(`/auth/signin/basic?next=${next}`);
  //       return;
  //     }
  //     if (res.status === 404) throw new Error("ไม่พบผู้ใช้นี้");
  //     if (!res.ok) {
  //       const text = await res.text();
  //       throw new Error(text || `Delete failed: ${res.status}`);
  //     }

  //     setData((prev) => prev.filter((u) => u.id !== row.id));
  //     setNotice({ type: "success", msg: "Delete success" });
  //     setTimeout(() => setNotice(null), 2500);
  //   } catch (e: any) {
  //     console.error(e);
  //     setNotice({ type: "error", msg: e.message || "ลบผู้ใช้ไม่สำเร็จ" });
  //     setTimeout(() => setNotice(null), 3500);
  //   }
  // };

  const handleDelete = (row: UserRow) => {
    if (!row.id) return;
    setConfirmDialog({
      open: true,
      title: t("deleteTitle", lang),
      message:
        lang === "th"
          ? `คุณต้องการลบผู้ใช้ "${row.username}" ใช่หรือไม่?`
          : `Are you sure you want to delete the user "${row.username}"?`,
      loading: false,
      onConfirm: async () => {
        try {
          setConfirmDialog(prev => ({ ...prev, loading: true }));
          const res = await apiFetch(`/delete_users/${row.id}`, { method: "DELETE" });

          if (res.status === 401) {
            const next = encodeURIComponent(window.location.pathname);
            router.replace(`/auth/signin/basic?next=${next}`);
            return;
          }
          if (res.status === 403) throw new Error(t("forbidden", lang));
          if (res.status === 404) throw new Error(t("userNotFound", lang));
          if (!res.ok) {
            const text = await res.text();
            throw new Error(text || `Delete failed: ${res.status}`);
          }

          setData((prev) => prev.filter((u) => u.id !== row.id));
          closeConfirm();
          setNotice({ type: "success", msg: t("deleteSuccess", lang) });
          setTimeout(() => setNotice(null), 2500);
        } catch (e: any) {
          console.error(e);
          closeConfirm();
          setNotice({ type: "error", msg: e.message || t("deleteUserFailed", lang) });
          setTimeout(() => setNotice(null), 3500);
        }
      },
    });
  };

  /* -------------------- Table -------------------- */
  const columns: any[] = [
    {
      accessorFn: (_row: UserRow, index: number) => index + 1,
      id: "no",
      header: () => t("colNo", lang),
      enableSorting: true,
      sortingFn: "basic",
      sortDescFirst: true,
      cell: (info: any) => {
        const isSortingByNo = info.table.getState().sorting?.[0]?.id === "no";
        let num: number;
        if (isSortingByNo) {
          num = Number(info.getValue());
        } else {
          const pageRows = info.table.getRowModel().rows as Row<UserRow>[];
          const indexInPage = pageRows.findIndex((r) => r.id === info.row.id);
          const { pageIndex, pageSize } = info.table.getState().pagination;
          num = pageIndex * pageSize + indexInPage + 1;
        }
        return <span className="tw-block tw-w-full">{num}</span>;
      },
    },
    { accessorFn: (r: UserRow) => r.username ?? "-", id: "username", header: () => t("colUsername", lang), cell: (i: any) => i.getValue() },
    { accessorFn: (r: UserRow) => r.email ?? "-", id: "email", header: () => t("colEmail", lang), cell: (i: any) => i.getValue() },
    { accessorFn: (r: UserRow) => r.tel ?? "-", id: "tel", header: () => t("colTel", lang), cell: (i: any) => i.getValue() },
    // { accessorFn: (r: UserRow) => r.company ?? "-",  id: "company",  header: () => "company",  cell: (i: any) => i.getValue() },
    {
      accessorFn: (r: UserRow) => r.company ?? "-",
      id: "company",
      header: () => t("colCompany", lang),
      cell: (i: any) => {
        const company = (i.getValue() as string) || "-";
        if (company === "-" || !company.trim()) {
          return <span className="tw-text-blue-gray-300 tw-text-xs tw-italic">—</span>;
        }
        const palette = [
          "tw-bg-blue-50 tw-text-blue-700 tw-ring-1 tw-ring-blue-200",
          "tw-bg-emerald-50 tw-text-emerald-700 tw-ring-1 tw-ring-emerald-200",
          "tw-bg-violet-50 tw-text-violet-700 tw-ring-1 tw-ring-violet-200",
          "tw-bg-rose-50 tw-text-rose-700 tw-ring-1 tw-ring-rose-200",
          "tw-bg-amber-50 tw-text-amber-700 tw-ring-1 tw-ring-amber-200",
          "tw-bg-cyan-50 tw-text-cyan-700 tw-ring-1 tw-ring-cyan-200",
          "tw-bg-pink-50 tw-text-pink-700 tw-ring-1 tw-ring-pink-200",
          "tw-bg-teal-50 tw-text-teal-700 tw-ring-1 tw-ring-teal-200",
          "tw-bg-indigo-50 tw-text-indigo-700 tw-ring-1 tw-ring-indigo-200",
          "tw-bg-orange-50 tw-text-orange-700 tw-ring-1 tw-ring-orange-200",
        ];
        // hash ชื่อ company ให้ได้สีคงที่ต่อชื่อเดียวกัน
        let hash = 0;
        for (let i = 0; i < company.length; i++) {
          hash = company.charCodeAt(i) + ((hash << 5) - hash);
        }
        const cls = palette[Math.abs(hash) % palette.length];
        return (
          <span className={`tw-inline-flex tw-items-center tw-gap-1.5 tw-px-2.5 tw-py-1 tw-rounded-md tw-text-xs tw-font-semibold ${cls}`}>
            🏢 {company}
          </span>
        );
      },
    },
    {
      accessorFn: (r: UserRow) => r.role ?? "-",
      id: "role",
      header: () => t("colRole", lang),
      cell: (i: any) => {
        const role = i.getValue() as string;
        const colorMap: Record<string, string> = {
          admin: "tw-bg-purple-50 tw-text-purple-700 tw-ring-1 tw-ring-purple-200",
          owner: "tw-bg-blue-50 tw-text-blue-700 tw-ring-1 tw-ring-blue-200",
          technician: "tw-bg-amber-50 tw-text-amber-700 tw-ring-1 tw-ring-amber-200",
          cs: "tw-bg-teal-50 tw-text-teal-700 tw-ring-1 tw-ring-teal-200",
          planner: "tw-bg-cyan-50 tw-text-cyan-700 tw-ring-1 tw-ring-cyan-200",
        };
        const cls = colorMap[role] || "tw-bg-gray-50 tw-text-gray-600 tw-ring-1 tw-ring-gray-200";
        return (
          <span className={`tw-inline-flex tw-items-center tw-gap-1.5 tw-px-2.5 tw-py-1 tw-rounded-md tw-text-xs tw-font-semibold ${cls}`}>
            {role}
          </span>
        );
      },
    },
    {
      id: "actions",
      header: () => t("colActions", lang),
      enableSorting: false,
      size: 80,
      cell: ({ row }: { row: Row<UserRow> }) => (
        <span className="tw-inline-flex tw-items-center tw-gap-1.5">
          <button
            title={t("editUser", lang)}
            onClick={() => handleEdit(row.original)}
            className="tw-group/btn tw-rounded-lg tw-p-2 tw-bg-blue-50 tw-ring-1 tw-ring-blue-200/60 hover:tw-bg-blue-600 hover:tw-ring-blue-600 tw-transition-all tw-duration-200 tw-shadow-sm hover:tw-shadow-md"
          >
            <PencilSquareIcon className="tw-h-4 tw-w-4 tw-text-blue-600 group-hover/btn:tw-text-white tw-transition-colors" />
          </button>
          {isAdmin && (
            <button
              title={t("deleteUser", lang)}
              onClick={() => handleDelete(row.original)}
              className="tw-group/btn tw-rounded-lg tw-p-2 tw-bg-red-50 tw-ring-1 tw-ring-red-200/60 hover:tw-bg-red-600 hover:tw-ring-red-600 tw-transition-all tw-duration-200 tw-shadow-sm hover:tw-shadow-md"
            >
              <TrashIcon className="tw-h-4 tw-w-4 tw-text-red-500 group-hover/btn:tw-text-white tw-transition-colors" />
            </button>
          )}
        </span>
      ),
    },
  ];

  const table = useReactTable({
    data,
    columns,
    state: { globalFilter: filtering, sorting },
    onSortingChange: setSorting as any,
    onGlobalFilterChange: setFiltering,
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  });

  /* -------------------- Guard while checking auth -------------------- */
  if (!authChecked) {
    return <div className="tw-p-4">{t("checkingSession", lang)}</div>;
  }

  /* -------------------- JSX -------------------- */
  return (
    <>

      <LoadingOverlay show={loading} text={t("loadingData", lang)} />

      <Card className="tw-border tw-border-blue-gray-100 tw-shadow-sm tw-mt-8 tw-scroll-mt-4">
        {notice && (
          <div className="tw-px-4 tw-pt-4">
            <Alert color={notice.type === "success" ? "green" : "red"} onClose={() => setNotice(null)}>
              {notice.msg}
            </Alert>
          </div>
        )}

        <CardHeader
          floated={false}
          shadow={false}
          className="tw-flex tw-flex-col md:tw-flex-row tw-items-start md:tw-items-center tw-gap-3 tw-!px-4 sm:tw-!px-6 tw-!py-5 tw-bg-gradient-to-r tw-from-white tw-to-blue-gray-50/30 tw-rounded-t-xl tw-mb-6"
        >
          <div className="tw-ml-3">
            <Typography color="blue-gray" variant="h5" className="tw-text-base sm:tw-text-lg md:tw-text-xl">
              {t("pageTitle", lang)}
            </Typography>
            <Typography variant="small" className="!tw-text-blue-gray-500 !tw-font-normal tw-mt-1 tw-text-xs sm:tw-text-sm">
              {t("pageSubtitle", lang)}
            </Typography>
          </div>

          <div className="tw-w-full md:tw-w-auto md:tw-ml-auto md:tw-flex md:tw-justify-end">
            <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2 sm:tw-gap-3 tw-justify-end tw-w-full md:tw-w-auto md:tw-mt-6">
              {plannerNoCompany && (
                <Typography variant="small" className="!tw-text-red-500 tw-text-xs">
                  {t("plannerNoCompany", lang)}
                </Typography>
              )}
              <Button
                onClick={() => setOpenAdd(true)}
                disabled={isPlanner && !companyOptions?.length}
                size="sm"
                className="tw-flex tw-items-center tw-gap-2 tw-px-4 sm:tw-px-5 tw-py-2.5 tw-rounded-xl tw-bg-gray-900 hover:tw-bg-black tw-text-white tw-font-semibold tw-text-xs sm:tw-text-sm tw-shadow-lg tw-flex-shrink-0 tw-normal-case tw-tracking-wide"
              >
                <span className="tw-text-base tw-leading-none">+</span> {t("addUser", lang)}
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardBody className="tw-flex tw-items-center tw-justify-between tw-gap-3 tw-px-3 md:tw-px-4">
          {/* ซ้าย: page size */}
          <div className="tw-flex tw-items-center tw-gap-3 tw-flex-none">
            <select
              value={table.getState().pagination.pageSize}
              onChange={(e) => table.setPageSize(Number(e.target.value))}
              className="tw-border tw-p-2 tw-border-blue-gray-100 tw-rounded-lg tw-w-[72px]"
            >
              {[5, 10, 15, 20, 25].map((pageSize) => (
                <option key={pageSize} value={pageSize}>
                  {pageSize}
                </option>
              ))}
            </select>


            <Typography variant="small" className="!tw-text-blue-gray-500 !tw-font-normal tw-hidden sm:tw-inline">
              {t("entriesPerPage", lang)}
            </Typography>
          </div>

          {/* ขวา: Search */}
          <div className="tw-ml-auto tw-min-w-0 tw-flex-1 md:tw-flex-none md:tw-w-64">
            <Input
              variant="outlined"
              value={filtering}
              onChange={(e) => setFiltering(e.target.value)}
              label={t("search", lang)}
              crossOrigin={undefined}
              containerProps={{ className: "tw-min-w-0" }}
              className="tw-w-full"
            />
          </div>
        </CardBody>

        <CardFooter className="tw-p-0 tw-overflow-scroll">
          {/* เดิมซ่อนทั้งตาราง (รวมหัวตาราง) ระหว่างโหลด แล้วค่อยโผล่มาทั้งก้อน
              ทำให้หน้าขยับทั้งบล็อก — ตอนนี้คงตารางไว้ แล้วใส่โครงร่างใน tbody แทน */}
          {err ? (
            <div className="tw-p-4 tw-text-red-600">{err}</div>
          ) : (
            <table className="tw-table-auto tw-text-left tw-w-full tw-min-w-max">
              <thead className="tw-bg-gradient-to-r tw-from-gray-900 tw-to-gray-800">
                {table.getHeaderGroups().map((headerGroup) => (
                  <tr key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <th
                        key={header.id}
                        onClick={header.column.getToggleSortingHandler()}
                        className="tw-p-4 tw-uppercase !tw-text-blue-gray-500 !tw-font-medium"
                      >
                        <Typography
                          color="blue-gray"
                          className="tw-flex tw-items-center tw-justify-between tw-gap-2 tw-text-[11px] !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white"
                        >
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          <ChevronUpDownIcon strokeWidth={2} className="tw-h-4 tw-w-4 tw-text-white/60" />
                        </Typography>
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>
              <tbody>
                {loading ? (
                  <TableSkeletonRows rows={table.getState().pagination.pageSize} cols={columns.length} />
                ) : table.getRowModel().rows.length ? (
                  table.getRowModel().rows.map((row) => (
                    <tr key={row.id} className="odd:tw-bg-white even:tw-bg-blue-gray-50/30 hover:tw-bg-blue-50/40 hover:tw-shadow-[inset_3px_0_0_0_#2196F3] tw-transition-colors">
                      {row.getVisibleCells().map((cell) => (
                        <td key={cell.id} className="!tw-border-y !tw-border-x-0">
                          <Typography as="div" variant="small" className="!tw-font-normal !tw-text-blue-gray-500 tw-py-4 tw-px-4">
                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                          </Typography>
                        </td>
                      ))}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td className="tw-px-4 tw-py-6 tw-text-center" colSpan={columns.length}>
                      {t("noUsersFound", lang)}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </CardFooter>

        <div className="tw-flex tw-items-center tw-justify-between tw-px-6 tw-py-4 tw-border-t tw-border-blue-gray-100">
          <Typography variant="small" className="!tw-text-blue-gray-400">
            {data.length} {t("usersSuffix", lang)}
          </Typography>
          <div className="tw-flex tw-items-center tw-gap-4">
            <span className="tw-text-sm tw-text-blue-gray-600">
              {t("page", lang)} <strong>{table.getState().pagination.pageIndex + 1}</strong> {t("of", lang)} <strong>{table.getPageCount()}</strong>
            </span>
            <div className="tw-flex tw-items-center tw-gap-1">
              <Button variant="outlined" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} className="disabled:tw-opacity-30 tw-py-1.5 tw-px-2 tw-rounded-lg tw-border-blue-gray-200">
                <ChevronLeftIcon className="tw-w-4 tw-h-4 tw-stroke-blue-gray-600 tw-stroke-2" />
              </Button>
              <Button variant="outlined" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} className="disabled:tw-opacity-30 tw-py-1.5 tw-px-2 tw-rounded-lg tw-border-blue-gray-200">
                <ChevronRightIcon className="tw-w-4 tw-h-4 tw-stroke-blue-gray-600 tw-stroke-2" />
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Dialog: Add */}
      <AddUser
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        onSubmit={handleCreateUser}
        loading={saving}
        allowedRoles={isPlanner ? PLANNER_ROLES : undefined}
        companyOptions={isPlanner ? companyOptions ?? [] : undefined}
      />

      {/* Dialog: Edit */}
      <Dialog
        open={openEdit}
        handler={() => {
          setOpenEdit(false);
          setStationSearchValue("");
          setShowStationDropdown(false);
          setSelectedStations([]);
        }}
        size="md"
        className="tw-flex tw-flex-col tw-max-h-[90vh] tw-px-8 tw-py-4"
      >
        <DialogHeader className="tw-flex tw-items-center tw-justify-between tw-flex-shrink-0">
          <Typography variant="h5" color="blue-gray">
            {t("editUserTitle", lang)}
          </Typography>
          <Button variant="text" onClick={() => setOpenEdit(false)}>
            ✕
          </Button>
        </DialogHeader>

        <form className="tw-flex tw-flex-col tw-flex-1 tw-min-h-0"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!editingRow?.id) return;

            const form = e.currentTarget as HTMLFormElement & {
              username: HTMLInputElement;
              email: HTMLInputElement;
              company: HTMLInputElement;
              tel: HTMLInputElement;
              password?: HTMLInputElement;
            };

            const payload: any = {
              username: form.username?.value?.trim(),
              email: form.email?.value?.trim(),
              company: form.company?.value?.trim(),
              tel: form.tel?.value?.trim(),
            };

            // planner แก้ profile ตัวเองได้แค่ข้อมูลส่วนตัว — role / company ของตัวเองให้ admin เปลี่ยน
            if (isAdmin || (isPlanner && !editingSelf)) payload.role = roleValue;
            if (isPlanner && editingSelf) delete payload.company;
            // Always send station_id (empty array if technician with no stations, or if not technician)
            if (roleValue === "technician") {
              payload.station_id = selectedStations.map((s) => s.station_id);
            } else {
              payload.station_id = [];
            }

            const newPw = form.password?.value?.trim();
            if (newPw) payload.password = newPw;

            try {
              if (isAdmin && roleValue === "owner") {
                payload.ai_package = {
                  enabled: aiPackage.enabled,
                  // expires_at: aiPackage.expires_at
                  //   ? new Date(aiPackage.expires_at).toISOString()
                  //   : null,
                };
              }
              await handleUpdateUser(editingRow.id!, payload);
            } catch (err: any) {
              setNotice({ type: "error", msg: err?.message || t("updateFailed", lang) });
              setTimeout(() => setNotice(null), 3500);
            }
          }}
        >
          <DialogBody className="tw-space-y-6 tw-px-6 tw-py-4 tw-overflow-y-auto tw-flex-1 tw-min-h-0">
            <div className="tw-flex tw-flex-col tw-gap-4">
              <Input name="username" label={t("username", lang)} defaultValue={editingRow?.username ?? ""} required crossOrigin={undefined} />
              <Input name="email" label={t("email", lang)} type="email" defaultValue={editingRow?.email ?? ""} required crossOrigin={undefined} />
              {isPlanner && !editingSelf ? (
                <div className="tw-relative tw-h-10 tw-w-full">
                  <select
                    name="company"
                    required
                    defaultValue={editingRow?.company ?? ""}
                    className="tw-h-full tw-w-full tw-cursor-pointer tw-appearance-none tw-rounded-[7px] tw-border tw-border-blue-gray-200 tw-bg-transparent tw-px-3 tw-py-2.5 tw-font-sans tw-text-sm tw-font-normal tw-text-blue-gray-700 tw-outline-none focus:tw-border-2 focus:tw-border-gray-900"
                  >
                    {editCompanyChoices.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  <label className="tw-pointer-events-none tw-absolute tw-left-3 tw--top-1.5 tw-bg-white tw-px-1 tw-text-[11px] tw-font-normal tw-text-blue-gray-400">
                    {t("company", lang)} *
                  </label>
                </div>
              ) : (
                <Input
                  name="company"
                  label={t("company", lang)}
                  defaultValue={editingRow?.company ?? ""}
                  disabled={isPlanner && editingSelf}
                  crossOrigin={undefined}
                />
              )}
              <Input name="tel" label={t("tel", lang)} defaultValue={editingRow?.tel ?? ""} crossOrigin={undefined} />
              {/* <Input name="password" label="New Password (optional)" type="password" /> */}

              {(isAdmin || (isPlanner && !editingSelf)) && (
                <Select label={t("role", lang)} value={roleValue} onChange={(v) => {
                  setRoleValue(v ?? "user");
                  // รีเซ็ต stations เมื่อเปลี่ยน role
                  if (v !== "technician") {
                    setSelectedStations([]);
                  }
                }}>
                  {EDIT_ROLE_OPTIONS
                    .filter((o) => !isPlanner || PLANNER_ROLES.includes(o.value))
                    .map((o) => (
                      <Option key={o.value} value={o.value}>{o.label}</Option>
                    ))}
                </Select>



              )}

              {isAdmin && roleValue === "owner" && (
                <div className="tw-border tw-border-blue-gray-100 tw-rounded-xl tw-p-4 tw-space-y-3">
                  <Typography variant="small" className="!tw-font-semibold tw-text-blue-gray-700">
                    {t("aiPackage", lang)}
                  </Typography>
                  <div className="tw-flex tw-items-center tw-justify-between">
                    <Typography variant="small" color="blue-gray">{t("enableAiModules", lang)}</Typography>
                    <Switch
                      checked={aiPackage.enabled}
                      onChange={() => setAiPackage(p => ({ ...p, enabled: !p.enabled }))}
                      crossOrigin={undefined}
                    />
                  </div>
                  {/* <Input
                    label="Expires At"
                    type="date"
                    value={aiPackage.expires_at}
                    onChange={(e) => setAiPackage(p => ({ ...p, expires_at: e.target.value }))}
                    crossOrigin={undefined}
                  /> */}
                </div>
              )}


              {roleValue === "technician" && (
                <div ref={stationBoxRef}>
                  {/* Input + Dropdown (ครอบเฉพาะ input ให้ dropdown absolute เทียบกับ input อย่างเดียว) */}
                  <div className="tw-relative">
                    <Input
                      label={t("selectStation", lang)}
                      placeholder={t("typeToSearch", lang)}
                      value={stationSearchValue}
                      onChange={(e) => {
                        setStationSearchValue(e.target.value);
                        setShowStationDropdown(true);
                      }}
                      onFocus={() => setShowStationDropdown(true)}
                      disabled={loadingStations || availableStations.length === 0}
                      crossOrigin={undefined}
                    />

                    {showStationDropdown && (
                      <div className="tw-absolute tw-top-full tw-left-0 tw-right-0 tw-z-50 tw-mt-1 tw-max-h-48 tw-overflow-y-auto tw-bg-white tw-border tw-border-gray-300 tw-rounded-lg tw-shadow-lg">
                        {(() => {
                          const filtered = availableStations.filter((station) => {
                            if (!station) return false;
                            const name = (station.station_name || "").toLowerCase();
                            const id = (station.station_id || "").toLowerCase();
                            const search = stationSearchValue.toLowerCase();
                            return (
                              !selectedStations.find((s) => s.station_id === station.station_id) &&
                              (name.includes(search) || id.includes(search))
                            );
                          });

                          if (filtered.length === 0) {
                            return (
                              <div className="tw-px-4 tw-py-3 tw-text-center tw-text-gray-500">
                                {t("noStationsFound", lang)}
                              </div>
                            );
                          }

                          return filtered.map((station) => (
                            <div
                              key={station.station_id}
                              onClick={() => {
                                setSelectedStations([...selectedStations, station]);
                                setStationSearchValue("");
                                setShowStationDropdown(false);
                              }}
                              className="tw-px-4 tw-py-2 tw-cursor-pointer hover:tw-bg-blue-50 tw-border-b tw-border-gray-100 last:tw-border-b-0"
                            >
                              <Typography variant="small" className="tw-font-medium">
                                {station.station_name}
                              </Typography>
                              <Typography variant="small" color="gray">
                                {station.station_id}
                              </Typography>
                            </div>
                          ));
                        })()}
                      </div>
                    )}
                  </div>

                  {loadingStations && (
                    <Typography variant="small" color="gray" className="tw-mt-1">
                      {t("loadingStations", lang)}
                    </Typography>
                  )}
                  {!loadingStations && availableStations.length === 0 && (
                    <Typography variant="small" color="red" className="tw-mt-1">
                      {t("noStationsAvailable", lang)}
                    </Typography>
                  )}

                  {/* Selected Stations Tags — กลับมาอยู่ใต้ Input เหมือนเดิม */}
                  {selectedStations.length > 0 && (
                    <div className="tw-mt-3">
                      <Typography variant="small" className="tw-font-semibold tw-mb-2">
                        {t("selectedStations", lang)} ({selectedStations.length}):
                      </Typography>
                      <div className="tw-flex tw-flex-wrap tw-gap-2 tw-max-h-40 tw-overflow-y-auto tw-p-2 tw-border tw-border-blue-gray-100 tw-rounded-lg tw-bg-blue-gray-50/30">
                        {selectedStations.map((station) => (
                          <div
                            key={station.station_id}
                            className="tw-flex tw-items-center tw-gap-2 tw-bg-blue-100 tw-text-blue-700 tw-px-3 tw-py-1 tw-rounded-full tw-text-sm"
                          >
                            <span>{station.station_name}</span>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedStations(
                                  selectedStations.filter((s) => s.station_id !== station.station_id)
                                );
                              }}
                              className="tw-font-bold tw-cursor-pointer hover:tw-text-blue-900"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </DialogBody>

          <DialogFooter className="tw-gap-2 tw-flex-shrink-0 tw-border-t tw-border-blue-gray-50 tw-pt-4">
            <Button variant="outlined" type="button" onClick={() => setOpenEdit(false)}>
              {t("cancel", lang)}
            </Button>
            <Button type="submit" className="tw-bg-gradient-to-b tw-from-neutral-800 tw-to-neutral-900 hover:tw-to-black" disabled={saving}>
              {saving ? t("saving", lang) : t("saveChanges", lang)}
            </Button>
          </DialogFooter>
        </form>

      </Dialog>
      <ConfirmDialog              // ← ✅ อยู่ข้างนอก เป็น sibling ของ Dialog
        open={confirmDialog.open}
        onClose={closeConfirm}
        onConfirm={confirmDialog.onConfirm}
        title={confirmDialog.title}
        message={confirmDialog.message}
        confirmLabel={t("delete", lang)}
        cancelLabel={t("cancel", lang)}
        variant="danger"
        loading={confirmDialog.loading}
      />
    </>
  );
}
