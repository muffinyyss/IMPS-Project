"use client";
import ConfirmDialog from "./ConfirmDialog";
import { ensureViewableImage, looksLikeImageFile } from "@/utils/heic";
import LoadingOverlay from "../../components/Loadingoverlay";
import React, { useEffect, useState, useMemo, useCallback, useRef, Fragment } from "react";
import {
  getCoreRowModel, getPaginationRowModel, getFilteredRowModel, getSortedRowModel, getExpandedRowModel,
  useReactTable, flexRender, type Row, type ExpandedState,
} from "@tanstack/react-table";
import {
  Button, Card, CardBody, CardHeader, Typography, CardFooter, Input, Alert,
  Dialog, DialogHeader, DialogBody, DialogFooter, Select, Option, Chip, Tooltip,
} from "@material-tailwind/react";
import {
  ChevronLeftIcon, ChevronRightIcon, ChevronUpDownIcon, ChevronDownIcon,
  ChevronRightIcon as ChevronRightIconSolid, PencilSquareIcon, TrashIcon,
  BoltIcon, CpuChipIcon, PhotoIcon,
} from "@heroicons/react/24/solid";
import { useRouter } from "next/navigation";
import AddStation, { type NewStationPayload, MaximoLocationSelect, type MaximoLocation } from "@/app/dashboard/stations/components/addstations";
import { WARRANTY_STATUS_OPTIONS, INVESTMENT_SCOPE_OPTIONS, MultiSelectDropdown, VendorSelect, LatLngInput, parseLatLng, toLatLngText, type LatLngText } from "@/app/dashboard/stations/components/stationOptions";
import { apiFetch, getSessionProfile } from "@/utils/api";
import { isStaffRole, staffChargerPath } from "@/utils/roles";
import { startVisiblePoll } from "@/utils/visible-poll";
import TableSkeletonRows from "@/components/TableSkeletonRows";

// const API_BASE = "http://localhost:8000";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "";

const imgUrl = (url: string) =>
  url.startsWith("http") ? url : `${API_BASE}${url}`;

// ===== Types =====
type ChargerData = {
  id?: string;
  charger_id?: string;
  station_id?: string;
  chargeBoxID: string;
  chargerNo: number;
  brand: string;
  vendor: string;
  model: string;
  SN: string;
  WO: string;
  power: string;
  PLCFirmware: string;
  PIFirmware: string;
  RTFirmware: string;
  commissioningDate: string;
  warrantyYears: number;
  numberOfCables: number;
  is_active: boolean;
  maximo_location: string;
  maximo_desc: string;
  ocppUrl: string;
  chargerType: string;
  status?: boolean;
  chargerImages?: string[];
  deviceImages?: string[];
};

type StationRow = {
  id?: string; station_id: string; station_name: string; owner: string;
  user_id: string; username: string; is_active: boolean;
  maximo_location: string; maximo_desc: string;
  warranty_status?: string; investment_scope?: string[]; io_code?: string;
  latitude?: number | null; longitude?: number | null;
  stationImage?: string;
  mdbImages?: string[];   // ✅ เพิ่ม mdb images
  chargers: ChargerData[];
};

export type StationUpdatePayload = {
  station_id?: string; station_name?: string; username?: string;
  is_active?: boolean; user_id?: string; maximo_location?: string; maximo_desc?: string;
  warranty_status?: string; investment_scope?: string[]; io_code?: string;
  latitude?: number | null; longitude?: number | null;
};

export type ChargerUpdatePayload = {
  chargeBoxID?: string; chargerNo?: number; brand?: string; vendor?: string; model?: string;
  SN?: string; WO?: string; power?: string;
  PLCFirmware?: string; PIFirmware?: string; RTFirmware?: string;
  commissioningDate?: string; warrantyYears?: number; numberOfCables?: number;
  is_active?: boolean; maximo_location?: string; maximo_desc?: string; ocppUrl?: string;
  chargerType?: string;
};

type CompanyOwner = { id: string; name: string };
type Lang = "th" | "en";
function getTodayDate(): string { return new Date().toISOString().split("T")[0]; }

// ─── Read EXIF orientation tag from JPEG bytes (1..8, 1 = normal) ───
async function readExifOrientation(file: File): Promise<number> {
  if (file.type !== "image/jpeg" && file.type !== "image/jpg") return 1;
  try {
    const buf = await file.slice(0, 256 * 1024).arrayBuffer();
    const view = new DataView(buf);
    if (view.byteLength < 4 || view.getUint16(0) !== 0xffd8) return 1;
    let offset = 2;
    while (offset < view.byteLength) {
      const marker = view.getUint16(offset);
      offset += 2;
      if (marker === 0xffe1) {
        if (view.getUint32(offset + 2) !== 0x45786966) return 1;
        const tiff = offset + 8;
        const little = view.getUint16(tiff) === 0x4949;
        const get16 = (o: number) => view.getUint16(o, little);
        const get32 = (o: number) => view.getUint32(o, little);
        if (get16(tiff + 2) !== 0x002a) return 1;
        const ifd = tiff + get32(tiff + 4);
        const tags = get16(ifd);
        for (let i = 0; i < tags; i++) {
          const entry = ifd + 2 + i * 12;
          if (get16(entry) === 0x0112) return get16(entry + 8);
        }
        return 1;
      } else if ((marker & 0xff00) !== 0xff00) {
        return 1;
      } else {
        offset += view.getUint16(offset);
      }
    }
  } catch { /* ignore */ }
  return 1;
}

// ─── Read raw JPEG dimensions from SOF marker (pre-EXIF rotation) ───
async function readJpegDimensions(file: File): Promise<{ width: number; height: number } | null> {
  if (!/jpe?g/i.test(file.type)) return null;
  try {
    const buf = await file.arrayBuffer();
    const view = new DataView(buf);
    if (view.byteLength < 4 || view.getUint16(0) !== 0xffd8) return null;
    let offset = 2;
    while (offset < view.byteLength) {
      if (view.getUint8(offset) !== 0xff) return null;
      const marker = view.getUint16(offset);
      offset += 2;
      const isSOF =
        (marker >= 0xffc0 && marker <= 0xffc3) ||
        (marker >= 0xffc5 && marker <= 0xffc7) ||
        (marker >= 0xffc9 && marker <= 0xffcb) ||
        (marker >= 0xffcd && marker <= 0xffcf);
      if (isSOF) {
        const height = view.getUint16(offset + 3);
        const width = view.getUint16(offset + 5);
        return { width, height };
      }
      offset += view.getUint16(offset);
    }
  } catch { /* ignore */ }
  return null;
}

// ─── Normalize EXIF orientation: returns a new File with pixels rotated upright ───
async function normalizeImageOrientation(rawFile: File): Promise<File> {
  // HEIC จาก iPhone: canvas decode ไม่ออก → preview ขึ้นกรอบว่าง และ EXIF orientation
  // ด้านล่างก็ทำงานไม่ได้ แปลงเป็น JPEG ที่ server ก่อนทุกอย่าง
  const file = await ensureViewableImage(rawFile);
  if (!file.type.startsWith("image/") || file.type === "image/gif" || file.type === "image/svg+xml") return file;
  try {
    const orientation = await readExifOrientation(file);
    if (orientation === 1) return file;

    const rawDims = await readJpegDimensions(file);

    let bitmap: ImageBitmap;
    try {
      bitmap = await createImageBitmap(file, { imageOrientation: "none" } as any);
    } catch {
      bitmap = await createImageBitmap(file);
    }

    const swap = orientation >= 5 && orientation <= 8;
    // ถ้า bitmap.width/height ถูกสลับเทียบกับ raw → เบราว์เซอร์ auto-rotate ให้แล้ว วาดตรง ๆ ห้ามหมุนซ้ำ
    const alreadyRotated = !!rawDims && swap &&
      bitmap.width === rawDims.height && bitmap.height === rawDims.width;

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) { bitmap.close?.(); return file; }

    if (alreadyRotated) {
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      ctx.drawImage(bitmap, 0, 0);
    } else {
      const w = bitmap.width, h = bitmap.height;
      canvas.width = swap ? h : w;
      canvas.height = swap ? w : h;
      switch (orientation) {
        case 2: ctx.transform(-1, 0, 0, 1, w, 0); break;
        case 3: ctx.transform(-1, 0, 0, -1, w, h); break;
        case 4: ctx.transform(1, 0, 0, -1, 0, h); break;
        case 5: ctx.transform(0, 1, 1, 0, 0, 0); break;
        case 6: ctx.transform(0, 1, -1, 0, h, 0); break;
        case 7: ctx.transform(0, -1, -1, 0, h, w); break;
        case 8: ctx.transform(0, -1, 1, 0, 0, w); break;
        default: break;
      }
      ctx.drawImage(bitmap, 0, 0);
    }
    bitmap.close?.();

    const outType = file.type === "image/png" ? "image/png" : "image/jpeg";
    const blob: Blob | null = await new Promise((resolve) => canvas.toBlob(resolve, outType, 0.92));
    if (!blob) return file;
    const newName = file.name.replace(/\.(jpe?g|png|webp|bmp)$/i, "") + (outType === "image/png" ? ".png" : ".jpg");
    return new File([blob], newName, { type: blob.type, lastModified: Date.now() });
  } catch {
    return file;
  }
}

/* ─────────────────────── Shared Sub-components ─────────────────────── */

const SectionIcon = ({ emoji }: { emoji: string }) => (
  <span className="tw-inline-flex tw-items-center tw-justify-center tw-h-7 tw-w-7 sm:tw-h-8 sm:tw-w-8 tw-rounded-xl tw-bg-gradient-to-br tw-shadow-lg tw-text-xs sm:tw-text-sm">
    {emoji}
  </span>
);

const ImageGallery = ({ previews, onRemove, emptyLabel }: {
  previews: string[];
  onRemove: (i: number) => void;
  emptyLabel: string;
}) => {
  if (!previews.length) {
    return (
      <div className="tw-flex tw-items-center tw-justify-center tw-h-14 sm:tw-h-[68px] tw-rounded-xl tw-border-2 tw-border-dashed tw-border-blue-gray-100">
        <span className="tw-text-[10px] sm:tw-text-[11px] tw-text-blue-gray-300 tw-select-none">{emptyLabel}</span>
      </div>
    );
  }
  return (
    <div className="tw-flex tw-flex-wrap tw-gap-1.5 sm:tw-gap-2">
      {previews.map((url, i) => (
        <div key={i} className="tw-group/img tw-relative tw-h-14 tw-w-14 sm:tw-h-[68px] sm:tw-w-[68px] tw-rounded-xl tw-overflow-hidden tw-ring-1 tw-ring-black/10 tw-shadow-sm hover:tw-shadow-md hover:tw-ring-blue-400/40 tw-transition-all tw-duration-200 hover:tw--translate-y-0.5">
          <img src={url} alt="" className="tw-h-full tw-w-full tw-object-cover" />
          <div className="tw-absolute tw-inset-0 tw-bg-black/0 group-hover/img:tw-bg-black/25 tw-transition-colors" />
          <button type="button" onClick={() => onRemove(i)} className="tw-absolute tw-top-0.5 tw-right-0.5 sm:tw-top-1 sm:tw-right-1 tw-h-5 tw-w-5 tw-rounded-full tw-bg-red-500 tw-text-white tw-flex tw-items-center tw-justify-center sm:tw-opacity-0 group-hover/img:tw-opacity-100 tw-shadow-lg tw-transition-all tw-duration-150 hover:tw-bg-red-600 hover:tw-scale-110 tw-text-[10px] tw-leading-none">✕</button>
          <span className="tw-absolute tw-bottom-0 tw-inset-x-0 tw-text-center tw-text-[8px] tw-font-medium tw-text-white tw-bg-gradient-to-t tw-from-black/40 tw-to-transparent tw-pt-3 tw-pb-0.5 tw-opacity-0 group-hover/img:tw-opacity-100 tw-transition-opacity">{i + 1}</span>
        </div>
      ))}
    </div>
  );
};

const UploadBtn = ({ label, onChange }: { label: string; onChange: React.ChangeEventHandler<HTMLInputElement>; }) => (
  <label className="tw-inline-flex tw-items-center tw-gap-1 sm:tw-gap-1.5 tw-px-2.5 sm:tw-px-3 tw-py-[5px] tw-rounded-lg tw-bg-white tw-border tw-border-blue-gray-200 tw-text-[10px] sm:tw-text-[11px] tw-font-semibold tw-text-blue-gray-600 tw-cursor-pointer hover:tw-border-blue-400 hover:tw-text-blue-600 hover:tw-bg-blue-50/50 tw-transition-all tw-duration-200 tw-shadow-sm hover:tw-shadow tw-select-none">
    <svg xmlns="http://www.w3.org/2000/svg" className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" /></svg>
    {label}
    <input type="file" accept="image/*" multiple onChange={onChange} className="tw-hidden" />
  </label>
);

const ImageZone = ({ label, previews, onUpload, onRemove, emptyLabel, uploadLabel, existingImages, apiBase, onRemoveExisting, currentLabel = "Current" }: {
  label: string; previews: string[]; onUpload: React.ChangeEventHandler<HTMLInputElement>;
  onRemove: (i: number) => void; emptyLabel: string; uploadLabel: string;
  existingImages?: string[]; apiBase?: string; onRemoveExisting?: (i: number) => void;
  currentLabel?: string;
}) => (
  <div className="tw-space-y-1.5 sm:tw-space-y-2 tw-p-2.5 sm:tw-p-3 tw-rounded-xl tw-bg-blue-gray-50/40 tw-ring-1 tw-ring-blue-gray-100/60">
    <div className="tw-flex tw-items-center tw-justify-between tw-min-h-[28px]">
      <span className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-wider">{label}</span>
      <UploadBtn label={uploadLabel} onChange={onUpload} />
    </div>
    {existingImages && existingImages.length > 0 && (
      <div className="tw-flex tw-flex-wrap tw-gap-1.5 sm:tw-gap-2">
        {existingImages.map((url, i) => (
          <div key={`existing-${i}`} className="tw-group/img tw-relative tw-h-14 tw-w-14 sm:tw-h-[68px] sm:tw-w-[68px] tw-rounded-xl tw-overflow-hidden tw-ring-1 tw-ring-black/10 tw-shadow-sm hover:tw-shadow-md hover:tw-ring-blue-400/40 tw-transition-all tw-duration-200 hover:tw--translate-y-0.5">
            <a href={url.startsWith("http") ? url : `${apiBase}${url}`} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="tw-block tw-h-full tw-w-full">
              <img src={url.startsWith("http") ? url : `${apiBase}${url}`} alt={`${label} ${i + 1}`} className="tw-h-full tw-w-full tw-object-cover" />
            </a>
            <div className="tw-absolute tw-inset-0 tw-bg-black/0 group-hover/img:tw-bg-black/25 tw-transition-colors tw-pointer-events-none" />
            {onRemoveExisting && (
              <button type="button" onClick={(e) => { e.preventDefault(); e.stopPropagation(); onRemoveExisting(i); }} className="tw-absolute tw-top-0.5 tw-right-0.5 sm:tw-top-1 sm:tw-right-1 tw-h-5 tw-w-5 tw-rounded-full tw-bg-red-500 tw-text-white tw-flex tw-items-center tw-justify-center sm:tw-opacity-0 group-hover/img:tw-opacity-100 tw-shadow-lg tw-transition-all tw-duration-150 hover:tw-bg-red-600 hover:tw-scale-110 tw-text-[10px] tw-leading-none tw-z-10">✕</button>
            )}
            <span className="tw-absolute tw-bottom-0 tw-inset-x-0 tw-text-center tw-text-[7px] tw-font-medium tw-text-white tw-bg-gradient-to-t tw-from-black/50 tw-to-transparent tw-pt-3 tw-pb-0.5 tw-pointer-events-none">{currentLabel} {i + 1}</span>
          </div>
        ))}
      </div>
    )}
    <ImageGallery previews={previews} onRemove={onRemove} emptyLabel={existingImages && existingImages.length > 0 ? "" : emptyLabel} />
  </div>
);

const Spinner = () => (
  <svg className="tw-animate-spin tw-h-4 tw-w-4" viewBox="0 0 24 24" fill="none">
    <circle className="tw-opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
    <path className="tw-opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
  </svg>
);

const SkeletonPulse = ({ className = "" }: { className?: string }) => (
  <div className={`tw-animate-pulse tw-rounded-lg tw-bg-white/10 ${className}`} />
);

const StatCardSkeleton = () => (
  <div className="tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-gradient-to-br tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-5 tw-py-3.5 sm:tw-py-4 tw-ring-1 tw-ring-white/10 tw-shadow-lg">
    <div className="tw-flex tw-items-center tw-gap-2 tw-mb-3">
      <SkeletonPulse className="tw-h-8 tw-w-8 !tw-rounded-xl" />
      <SkeletonPulse className="tw-h-3 tw-w-16" />
    </div>
    <SkeletonPulse className="tw-h-8 tw-w-12" />
  </div>
);

// สีของการ์ดตู้ชาร์จ 3 สถานะ — เทา (ยังไม่ได้ตั้งค่า) ต้องแยกจากแดง (ออฟไลน์)
// ตู้ที่ยังไม่ตั้งค่าไม่เคยส่งสถานะเข้ามา จะทาสีแดงว่าออฟไลน์ไม่ได้ เพราะยังไม่รู้ว่าออฟไลน์จริงไหม
const CHARGER_TONES = {
  green: { bar: "tw-bg-gradient-to-r tw-from-green-400 tw-to-emerald-500", iconBox: "tw-bg-green-50 tw-ring-1 tw-ring-green-200", icon: "tw-text-green-600", chip: "tw-bg-green-100 tw-text-green-700", dot: "tw-bg-green-500 tw-animate-pulse" },
  red: { bar: "tw-bg-gradient-to-r tw-from-red-400 tw-to-rose-500", iconBox: "tw-bg-red-50 tw-ring-1 tw-ring-red-200", icon: "tw-text-red-500", chip: "tw-bg-red-100 tw-text-red-600", dot: "tw-bg-red-400" },
  gray: { bar: "tw-bg-gradient-to-r tw-from-gray-300 tw-to-gray-400", iconBox: "tw-bg-gray-50 tw-ring-1 tw-ring-gray-200", icon: "tw-text-gray-400", chip: "tw-bg-gray-100 tw-text-gray-500", dot: "tw-bg-gray-300" },
} as const;

export function SearchDataTables() {
  const router = useRouter();
  const [me, setMe] = useState<{ user_id: string; username: string; role: string } | null>(null);
  const [owners, setOwners] = useState<CompanyOwner[]>([]);
  const [selectedOwnerName, setSelectedOwnerName] = useState<string>("");
  const [technicians, setTechnicians] = useState<Map<string, string[]>>(new Map());
  const [data, setData] = useState<StationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [sorting, setSorting] = useState<any>([{ id: "station_name", desc: false }]);
  const [filtering, setFiltering] = useState("");
  const [expanded, setExpanded] = useState<ExpandedState>({});
  const [openAdd, setOpenAdd] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ type: "success" | "error"; msg: string } | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{ open: boolean; title: string; message: string; onConfirm: () => void; loading: boolean; }>({ open: false, title: "", message: "", onConfirm: () => { }, loading: false });
  const [deletedExistingMdbIdxs, setDeletedExistingMdbIdxs] = useState<Set<number>>(new Set());
  const closeConfirm = () => setConfirmDialog(prev => ({ ...prev, open: false, loading: false }));
  const [availability, setAvailability] = useState<Map<string, { total: number; available: number }>>(new Map());
  const [chargerAvailability, setChargerAvailability] = useState<Map<string, { total: number; available: number }>>(new Map());
  // availability ยิงสำเร็จแล้วหรือยัง — ถ้ายังไม่สำเร็จห้ามเหมาว่าทุกตู้ "ยังไม่ได้ตั้งค่า"
  // ไม่งั้นตอน endpoint ล่ม การ์ด offline จะกลายเป็น 0 แล้วเทไปกองที่ not configured หมด
  const [availabilityReady, setAvailabilityReady] = useState(false);

  const [openEditStation, setOpenEditStation] = useState(false);
  const [editingStation, setEditingStation] = useState<StationRow | null>(null);
  const [editStationForm, setEditStationForm] = useState<{ station_name: string; is_active: boolean; maximo_location: string; maximo_desc: string; warranty_status: string; investment_scope: string[]; io_code: string; coords: LatLngText }>({ station_name: "", is_active: true, maximo_location: "", maximo_desc: "", warranty_status: "", investment_scope: [], io_code: "", coords: { lat: "", lng: "" } });

  const isFlexxfast = (brand: string) => brand.trim().toLowerCase() === "flexxfast";
  const [openEditCharger, setOpenEditCharger] = useState(false);
  const [editingCharger, setEditingCharger] = useState<{ stationId: string; charger: ChargerData } | null>(null);
  const [editChargerForm, setEditChargerForm] = useState({
    chargeBoxID: "", chargerNo: 1, brand: "", vendor: "", model: "", SN: "", WO: "", power: "",
    PLCFirmware: "", PIFirmware: "", RTFirmware: "", commissioningDate: "",
    warrantyYears: 1, numberOfCables: 1, is_active: true, maximo_location: "", maximo_desc: "", ocppUrl: "", chargerType: "DC",
  });

  const [openAddCharger, setOpenAddCharger] = useState(false);
  const [addingChargerStationId, setAddingChargerStationId] = useState<string>("");
  const [addChargerForm, setAddChargerForm] = useState({
    chargeBoxID: "", chargerNo: 1, brand: "", vendor: "", model: "", SN: "", WO: "", power: "",
    PLCFirmware: "", PIFirmware: "", RTFirmware: "", commissioningDate: getTodayDate(),
    warrantyYears: 1, numberOfCables: 1, is_active: true, maximo_location: "", maximo_desc: "", ocppUrl: "", chargerType: "DC",
  });

  const [addChargerImages, setAddChargerImages] = useState<File[]>([]);
  const [addDeviceImages, setAddDeviceImages] = useState<File[]>([]);
  const [addChargerPreviews, setAddChargerPreviews] = useState<string[]>([]);
  const [addDevicePreviews, setAddDevicePreviews] = useState<string[]>([]);

  // ── Maximo locations (สำหรับ dropdown ใน edit/add) ──
  const [stationLocations, setStationLocations] = useState<MaximoLocation[]>([]);
  const [chargerLocations, setChargerLocations] = useState<MaximoLocation[]>([]);
  const [maximoLoading, setMaximoLoading] = useState(false);

  useEffect(() => {
    const needed = openEditStation || openEditCharger || openAddCharger;
    if (!needed || stationLocations.length || chargerLocations.length || maximoLoading) return;
    let cancelled = false;
    (async () => {
      setMaximoLoading(true);
      try {
        const [stRes, chRes] = await Promise.all([
          apiFetch(`/maximo/locations?level=station`),
          apiFetch(`/maximo/locations?level=charger`),
        ]);
        if (!cancelled && stRes.ok) {
          const json = await stRes.json();
          if (Array.isArray(json?.locations)) setStationLocations(json.locations);
        }
        if (!cancelled && chRes.ok) {
          const json = await chRes.json();
          if (Array.isArray(json?.locations)) setChargerLocations(json.locations);
        }
      } catch (e) {
        console.error("Failed to fetch Maximo locations:", e);
      } finally {
        if (!cancelled) setMaximoLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [openEditStation, openEditCharger, openAddCharger]);

  // maximo_location ของสถานีแม่ (ใช้กรอง charger ให้อยู่ใต้สถานีเดียวกัน)
  const editChargerStationMaximo = useMemo(
    () => (data.find(s => s.station_id === editingCharger?.stationId)?.maximo_location ?? "").trim(),
    [data, editingCharger?.stationId]
  );
  const editChargerOptions = useMemo(() => {
    if (!editChargerStationMaximo) return [];
    const prefix = `${editChargerStationMaximo}-`;
    return chargerLocations.filter(o => o.location.startsWith(prefix) && /-EV$/i.test(o.location));
  }, [chargerLocations, editChargerStationMaximo]);

  const addChargerStationMaximo = useMemo(
    () => (data.find(s => s.station_id === addingChargerStationId)?.maximo_location ?? "").trim(),
    [data, addingChargerStationId]
  );
  const addChargerOptions = useMemo(() => {
    if (!addChargerStationMaximo) return [];
    const prefix = `${addChargerStationMaximo}-`;
    return chargerLocations.filter(o => o.location.startsWith(prefix) && /-EV$/i.test(o.location));
  }, [chargerLocations, addChargerStationMaximo]);

  const addChargerImageInputRef = useRef<HTMLInputElement | null>(null);
  const addDeviceImageInputRef = useRef<HTMLInputElement | null>(null);

  // ===== Edit Station Images =====
  const [editStationImages, setEditStationImages] = useState<File[]>([]);
  const [editStationPreviews, setEditStationPreviews] = useState<string[]>([]);
  const [editMdbImages, setEditMdbImages] = useState<File[]>([]);       // ✅ MDB
  const [editMdbPreviews, setEditMdbPreviews] = useState<string[]>([]); // ✅ MDB

  const [deleteCurrentImage, setDeleteCurrentImage] = useState(false);
  const stationImageInputRef = useRef<HTMLInputElement | null>(null);

  const [editChargerImages, setEditChargerImages] = useState<File[]>([]);
  const [editDeviceImages, setEditDeviceImages] = useState<File[]>([]);
  const [editChargerPreviews, setEditChargerPreviews] = useState<string[]>([]);
  const [editDevicePreviews, setEditDevicePreviews] = useState<string[]>([]);

  const [deleteChargerImage, setDeleteChargerImage] = useState(false);
  const [deleteDeviceImage, setDeleteDeviceImage] = useState(false);
  const [deletedExistingChargerIdxs, setDeletedExistingChargerIdxs] = useState<Set<number>>(new Set());
  const [deletedExistingDeviceIdxs, setDeletedExistingDeviceIdxs] = useState<Set<number>>(new Set());
  const chargerImageInputRef = useRef<HTMLInputElement | null>(null);
  const deviceImageInputRef = useRef<HTMLInputElement | null>(null);
  const [statusFilter, setStatusFilter] = useState<"all" | "online" | "offline" | "notConfigured">("all");

  const [lang, setLang] = useState<Lang>("en");
  useEffect(() => {
    const savedLang = localStorage.getItem("app_language") as Lang | null;
    if (savedLang === "th" || savedLang === "en") setLang(savedLang);
    const handleLangChange = (e: CustomEvent<{ lang: Lang }>) => { setLang(e.detail.lang); };
    window.addEventListener("language:change", handleLangChange as EventListener);
    return () => { window.removeEventListener("language:change", handleLangChange as EventListener); };
  }, []);

  const t = useMemo(() => {
    const translations = {
      th: {
        stationManagement: "จัดการสถานี", stationManagementDesc: "จัดการสถานีและตู้ชาร์จ คลิกที่แถวเพื่อดูตู้ชาร์จ คลิกที่การ์ดตู้ชาร์จเพื่อดูรายละเอียด",
        addStation: "เพิ่มสถานี", add: "เพิ่ม", entriesPerPage: "รายการต่อหน้า", search: "ค้นหา (ชื่อสถานี / SN)", images: "รูปภาพ",
        stationName: "ชื่อสถานี", chargers: "ตู้ชาร์จ", owner: "เจ้าของ", technician: "ช่างเทคนิค",
        active: "เปิดใช้งาน", inactive: "ปิดใช้งาน", actions: "จัดการ", online: "ออนไลน์", offline: "ออฟไลน์",
        maximoLocation: "Maximo Location", maximoDescription: "Maximo Description", ocppUrl: "OCPP URL", ocppSection: "🔌 OCPP",
        warrantyStatus: "การรับประกัน", investmentScope: "สัดส่วนการลงทุน", selectPlaceholder: "เลือก", ioCode: "รหัสค่าใช้จ่าย (IO)", coordsInvalid: "พิกัดไม่ถูกต้อง — กรอกทั้งละติจูดและลองจิจูด (เช่น 13.7563 และ 100.5018)",
        maximoSearch: "ค้นหา location...", maximoEmpty: "ไม่พบ location",
        chargerBoxId: "รหัสตู้ชาร์จ (Charge Box ID)", chargerType: "ประเภทตู้ชาร์จ",
        brand: "ยี่ห้อ", vendor: "ผู้จำหน่าย (Vendor)", model: "รุ่น", serialNumber: "S/N", workOrder: "W/O", power: "กำลังไฟ",
        cables: "สายชาร์จ", warranty: "รับประกัน", year: "ปี", firmware: "เฟิร์มแวร์",
        addCharger: "+ เพิ่มตู้ชาร์จ", noChargersYet: "ยังไม่มีตู้ชาร์จ", addFirstCharger: "+ เพิ่มตู้ชาร์จแรก",
        editStation: "แก้ไขสถานี", editCharger: "แก้ไขตู้ชาร์จ", addChargerTitle: "เพิ่มตู้ชาร์จ",
        station: "สถานี", cancel: "ยกเลิก", save: "บันทึก", saving: "กำลังบันทึก...",
        create: "สร้างตู้ชาร์จ", creating: "กำลังสร้าง...",
        chargerNo: "ตู้ที่", auto: "อัตโนมัติ", plcFirmware: "เฟิร์มแวร์ PLC", piFirmware: "เฟิร์มแวร์ Raspberry Pi",
        routerFirmware: "เฟิร์มแวร์ Router", commissioningDate: "วันที่เริ่มใช้งาน",
        warrantyYears: "ระยะรับประกัน (ปี)", numberOfCables: "จำนวนสายชาร์จ", status: "สถานะ",
        stationImage: "รูปสถานี", chargerImage: "รูปตู้ชาร์จ", deviceImage: "รูปอุปกรณ์", mdbImage: "MDB",
        currentImage: "รูปปัจจุบัน", newImage: "รูปใหม่", uploadImage: "อัปโหลดรูป", replaceImage: "เปลี่ยนรูปใหม่",
        willBeDeleted: "จะถูกลบ", undo: "เลิกทำ", noImageUploaded: "ยังไม่มีรูป", clickToRemove: "คลิก × เพื่อลบ",
        page: "หน้า", of: "จาก", loading: "กำลังโหลด...", noStationsFound: "ไม่พบสถานี",
        editStationTooltip: "แก้ไขสถานี", deleteStationTooltip: "ลบสถานี",
        updateSuccess: "อัปเดตสำเร็จ", createSuccess: "สร้างสำเร็จ", deleteSuccess: "ลบสำเร็จ",
        chargerDeleted: "ลบตู้ชาร์จแล้ว", chargerCreated: "สร้างตู้ชาร์จสำเร็จ",
        chargerUpdated: "อัปเดตตู้ชาร์จสำเร็จ", stationUpdated: "อัปเดตสถานีสำเร็จ",
        available: "พร้อมใช้งาน", availableOf: "หัว", notConfigured: "ยังไม่ได้ตั้งค่า",
        stationInfo: "ข้อมูลสถานี", chargerInfo: "ข้อมูลตู้ชาร์จ",
        upload: "เลือกรูป", noImages: "ยังไม่มีรูป",
        stationImages: "รูปภาพสถานี", chargerImages: "รูปภาพ",
        duplicateChargeBoxID: "Charge Box ID ซ้ำกัน กรุณาตรวจสอบ",
        imageOnly: "กรุณาเลือกเฉพาะไฟล์รูปภาพ", fileTooLarge: "มีขนาดใหญ่เกินไป (สูงสุด 3MB)",
        noEditPermission: "คุณไม่มีสิทธิ์แก้ไขสถานีนี้",
        updateFailed: "อัปเดตไม่สำเร็จ",
        deleteStationFailed: "ลบสถานีไม่สำเร็จ", deleteChargerFailed: "ลบตู้ชาร์จไม่สำเร็จ",
        createChargerFailed: "สร้างตู้ชาร์จไม่สำเร็จ", createStationFailed: "สร้างสถานีไม่สำเร็จ",
        fetchFailed: "โหลดข้อมูลไม่สำเร็จ", networkError: "เครือข่าย/เซิร์ฟเวอร์ผิดพลาด",
        currentImageBadge: "ปัจจุบัน", deviceImageBadge: "อุปกรณ์",
      },
      en: {
        stationManagement: "Station Management", stationManagementDesc: "Manage Stations and Chargers. Click on a row to view chargers, click on a charger card to view details.",
        addStation: "ADD STATION", add: "ADD", entriesPerPage: "entries per page", search: "Search (name / SN)", images: "Images",
        stationName: "Station Name", chargers: "Chargers", owner: "Owner", technician: "Technician",
        active: "Active", inactive: "Inactive", actions: "Actions", online: "online", offline: "offline",
        maximoLocation: "Maximo Location", maximoDescription: "Maximo Description", ocppUrl: "OCPP URL", ocppSection: "🔌 OCPP",
        warrantyStatus: "Warranty", investmentScope: "Investment Scope", selectPlaceholder: "Select", ioCode: "Expense Code (IO)", coordsInvalid: "Invalid coordinates — fill both latitude and longitude (e.g. 13.7563 and 100.5018)",
        maximoSearch: "Search location...", maximoEmpty: "No location found",
        chargerBoxId: "Charge Box ID", chargerType: "Charger Type",
        brand: "Brand", vendor: "Vendor", model: "Model", serialNumber: "S/N", workOrder: "W/O", power: "Power",
        cables: "Cables", warranty: "Warranty", year: "y", firmware: "Firmware",
        addCharger: "+ Add Charger", noChargersYet: "No chargers yet", addFirstCharger: "+ Add First Charger",
        editStation: "Edit Station", editCharger: "Edit Charger", addChargerTitle: "Add Charger",
        station: "Station", cancel: "Cancel", save: "Save Changes", saving: "Saving...",
        create: "Create Charger", creating: "Creating...",
        chargerNo: "Charger No.", auto: "Auto", plcFirmware: "PLC Firmware", piFirmware: "Raspberry Pi Firmware",
        routerFirmware: "Router Firmware", commissioningDate: "Commissioning Date",
        warrantyYears: "Warranty (Years)", numberOfCables: "Number of Cables", status: "Status",
        stationImage: "Station Image", chargerImage: "Charger Image", deviceImage: "Device Image", mdbImage: "MDB",
        currentImage: "Current image", newImage: "New", uploadImage: "Upload Image", replaceImage: "Replace with new image",
        willBeDeleted: "Will be deleted", undo: "Undo", noImageUploaded: "No image uploaded", clickToRemove: "click × to remove",
        page: "Page", of: "of", loading: "Loading...", noStationsFound: "No stations found",
        editStationTooltip: "Edit Station", deleteStationTooltip: "Delete Station",
        updateSuccess: "Updated successfully", createSuccess: "Created successfully", deleteSuccess: "Deleted successfully",
        chargerDeleted: "Charger deleted", chargerCreated: "Charger created successfully",
        chargerUpdated: "Charger updated successfully", stationUpdated: "Station updated successfully",
        available: "Available", availableOf: "heads", notConfigured: "Not configured",
        stationInfo: "Station Information", chargerInfo: "Charger Information",
        upload: "Browse", noImages: "No images yet",
        stationImages: "Station Images", chargerImages: "Images",
        duplicateChargeBoxID: "Duplicate Charge Box ID found, please check",
        imageOnly: "Please select image files only", fileTooLarge: "is too large (max 3MB)",
        noEditPermission: "You don't have permission to edit this station",
        updateFailed: "Update failed",
        deleteStationFailed: "Failed to delete station", deleteChargerFailed: "Failed to delete charger",
        createChargerFailed: "Failed to create charger", createStationFailed: "Failed to create station",
        fetchFailed: "Fetch failed", networkError: "Network/Server error",
        currentImageBadge: "Current", deviceImageBadge: "Device",
      },
    };
    return translations[lang];
  }, [lang]);

  const formatDate = (dateStr: string) => {
    if (!dateStr || dateStr === "-") return "-";
    try {
      const date = new Date(dateStr);
      if (lang === "th") {
        const thaiMonths = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
        return `${date.getDate()} ${thaiMonths[date.getMonth()]} ${date.getFullYear() + 543}`;
      }
      return date.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
    } catch { return dateStr; }
  };

  // ===== Image handlers =====
  const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

  const pickChargerImage: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const files = Array.from(e.target.files || []);
    const valid = files.filter(f => { if (!looksLikeImageFile(f)) { alert(t.imageOnly); return false; } if (f.size > MAX_IMAGE_BYTES) { alert(`${f.name} ${t.fileTooLarge}`); return false; } return true; });
    e.target.value = "";
    if (!valid.length) return;
    const normalized = await Promise.all(valid.map(normalizeImageOrientation));
    setEditChargerImages(prev => [...prev, ...normalized]);
    setEditChargerPreviews(prev => [...prev, ...normalized.map(f => URL.createObjectURL(f))]);
  };

  const pickDeviceImage: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const files = Array.from(e.target.files || []);
    const valid = files.filter(f => { if (!looksLikeImageFile(f)) { alert(t.imageOnly); return false; } if (f.size > MAX_IMAGE_BYTES) { alert(`${f.name} ${t.fileTooLarge}`); return false; } return true; });
    e.target.value = "";
    if (!valid.length) return;
    const normalized = await Promise.all(valid.map(normalizeImageOrientation));
    setEditDeviceImages(prev => [...prev, ...normalized]);
    setEditDevicePreviews(prev => [...prev, ...normalized.map(f => URL.createObjectURL(f))]);
  };

  const removeEditChargerImage = (idx: number) => { URL.revokeObjectURL(editChargerPreviews[idx]); setEditChargerImages(prev => prev.filter((_, i) => i !== idx)); setEditChargerPreviews(prev => prev.filter((_, i) => i !== idx)); };
  const removeEditDeviceImage = (idx: number) => { URL.revokeObjectURL(editDevicePreviews[idx]); setEditDeviceImages(prev => prev.filter((_, i) => i !== idx)); setEditDevicePreviews(prev => prev.filter((_, i) => i !== idx)); };
  const resetEditChargerImages = () => { editChargerPreviews.forEach(u => URL.revokeObjectURL(u)); editDevicePreviews.forEach(u => URL.revokeObjectURL(u)); setEditChargerImages([]); setEditDeviceImages([]); setEditChargerPreviews([]); setEditDevicePreviews([]); setDeleteChargerImage(false); setDeleteDeviceImage(false); setDeletedExistingChargerIdxs(new Set()); setDeletedExistingDeviceIdxs(new Set()); };

  const pickStationImage: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const files = Array.from(e.target.files || []);
    const valid = files.filter(f => { if (!looksLikeImageFile(f)) { alert(t.imageOnly); return false; } if (f.size > MAX_IMAGE_BYTES) { alert(`${f.name} ${t.fileTooLarge}`); return false; } return true; });
    e.target.value = "";
    if (!valid.length) return;
    const normalized = await Promise.all(valid.map(normalizeImageOrientation));
    setEditStationImages(prev => [...prev, ...normalized]);
    setEditStationPreviews(prev => [...prev, ...normalized.map(f => URL.createObjectURL(f))]);
  };

  // ✅ MDB image handler
  const pickMdbImage: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const files = Array.from(e.target.files || []);
    const valid = files.filter(f => { if (!looksLikeImageFile(f)) { alert(t.imageOnly); return false; } if (f.size > MAX_IMAGE_BYTES) { alert(`${f.name} ${t.fileTooLarge}`); return false; } return true; });
    e.target.value = "";
    if (!valid.length) return;
    const normalized = await Promise.all(valid.map(normalizeImageOrientation));
    setEditMdbImages(prev => [...prev, ...normalized]);
    setEditMdbPreviews(prev => [...prev, ...normalized.map(f => URL.createObjectURL(f))]);
  };

  const removeEditStationImage = (idx: number) => { URL.revokeObjectURL(editStationPreviews[idx]); setEditStationImages(prev => prev.filter((_, i) => i !== idx)); setEditStationPreviews(prev => prev.filter((_, i) => i !== idx)); };
  const removeEditMdbImage = (idx: number) => { URL.revokeObjectURL(editMdbPreviews[idx]); setEditMdbImages(prev => prev.filter((_, i) => i !== idx)); setEditMdbPreviews(prev => prev.filter((_, i) => i !== idx)); }; // ✅

  // ✅ resetEditImages ล้าง MDB ด้วย
  const resetEditImages = () => {
    editStationPreviews.forEach(u => URL.revokeObjectURL(u));
    editMdbPreviews.forEach(u => URL.revokeObjectURL(u));
    setEditStationImages([]); setEditStationPreviews([]);
    setEditMdbImages([]); setEditMdbPreviews([]);
    setDeletedExistingMdbIdxs(new Set());
    setDeleteCurrentImage(false);
  };

  const pickAddChargerImage: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const files = Array.from(e.target.files || []);
    const valid = files.filter(f => { if (!looksLikeImageFile(f)) { alert(t.imageOnly); return false; } if (f.size > MAX_IMAGE_BYTES) { alert(`${f.name} ${t.fileTooLarge}`); return false; } return true; });
    e.target.value = "";
    if (!valid.length) return;
    const normalized = await Promise.all(valid.map(normalizeImageOrientation));
    setAddChargerImages(prev => [...prev, ...normalized]);
    setAddChargerPreviews(prev => [...prev, ...normalized.map(f => URL.createObjectURL(f))]);
  };

  const pickAddDeviceImage: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const files = Array.from(e.target.files || []);
    const valid = files.filter(f => { if (!looksLikeImageFile(f)) { alert(t.imageOnly); return false; } if (f.size > MAX_IMAGE_BYTES) { alert(`${f.name} ${t.fileTooLarge}`); return false; } return true; });
    e.target.value = "";
    if (!valid.length) return;
    const normalized = await Promise.all(valid.map(normalizeImageOrientation));
    setAddDeviceImages(prev => [...prev, ...normalized]);
    setAddDevicePreviews(prev => [...prev, ...normalized.map(f => URL.createObjectURL(f))]);
  };

  const removeAddChargerImage = (idx: number) => { URL.revokeObjectURL(addChargerPreviews[idx]); setAddChargerImages(prev => prev.filter((_, i) => i !== idx)); setAddChargerPreviews(prev => prev.filter((_, i) => i !== idx)); };
  const removeAddDeviceImage = (idx: number) => { URL.revokeObjectURL(addDevicePreviews[idx]); setAddDeviceImages(prev => prev.filter((_, i) => i !== idx)); setAddDevicePreviews(prev => prev.filter((_, i) => i !== idx)); };
  const resetAddChargerImages = () => { addChargerPreviews.forEach(u => URL.revokeObjectURL(u)); addDevicePreviews.forEach(u => URL.revokeObjectURL(u)); setAddChargerImages([]); setAddDeviceImages([]); setAddChargerPreviews([]); setAddDevicePreviews([]); };

  useEffect(() => { localStorage.removeItem("selected_sn"); localStorage.removeItem("selected_charger_no"); window.dispatchEvent(new CustomEvent("charger:deselected")); }, []);

  useEffect(() => {
    if (data.length === 0) return;
    let stopped = false;
    const poll = async () => { if (stopped) return; try { await fetchAvailability(); } catch (e: any) { if (e?.status === 401 || e?.message?.includes("401")) { stopped = true; return; } console.error("[availability poll] error:", e); } };
    const stop = startVisiblePoll(poll, 10000);
    return () => { stopped = true; stop(); };
  }, [data]);

  useEffect(() => {
    if (openEditStation && editingStation) {
      setEditStationForm({ station_name: editingStation.station_name ?? "", is_active: !!editingStation.is_active, maximo_location: editingStation.maximo_location ?? "", maximo_desc: editingStation.maximo_desc ?? "", warranty_status: editingStation.warranty_status ?? "", investment_scope: editingStation.investment_scope ?? [], io_code: editingStation.io_code ?? "", coords: toLatLngText(editingStation.latitude, editingStation.longitude) });
      const ownerName = editingStation.username?.trim() ?? "";
      const ownerProfile = owners.find(o => o.name.trim().toLowerCase() === ownerName.toLowerCase());
      setSelectedOwnerName(ownerProfile?.name ?? "");

      resetEditImages();
    }
  }, [openEditStation, editingStation, owners]);

  useEffect(() => {
    if (openEditCharger && editingCharger) {
      const c = editingCharger.charger;
      setEditChargerForm({ chargeBoxID: c.chargeBoxID ?? "", chargerNo: c.chargerNo ?? 1, brand: c.brand ?? "", vendor: c.vendor ?? "", model: c.model ?? "", SN: c.SN ?? "", WO: c.WO ?? "", power: c.power ?? "", PLCFirmware: c.PLCFirmware ?? "", PIFirmware: c.PIFirmware ?? "", RTFirmware: c.RTFirmware ?? "", commissioningDate: c.commissioningDate ?? "", warrantyYears: c.warrantyYears ?? 1, numberOfCables: c.numberOfCables ?? 1, is_active: c.is_active ?? true, maximo_location: c.maximo_location ?? "", maximo_desc: c.maximo_desc ?? "", ocppUrl: c.ocppUrl ?? "", chargerType: c.chargerType ?? "DC" });
      resetEditChargerImages();
    }
  }, [openEditCharger, editingCharger]);

  useEffect(() => {
    (async () => {
      if (me?.role !== "admin" && me?.role !== "super_admin") return;
      try {
        const res = await apiFetch(`/companies/?type=owner`);
        if (!res.ok) return;
        const json = await res.json();
        setOwners(Array.isArray(json.companies) ? json.companies : []);
      } catch (error) {
        console.error("Failed to fetch owner profiles:", error);
      }
    })();
  }, [me?.role]);
  useEffect(() => { (async () => { try { const res = await apiFetch(`/all-users/`); if (!res.ok) return; const json = await res.json(); const users = Array.isArray(json?.users) ? json.users : []; const technicianMap = new Map<string, string[]>(); users.forEach((user: any) => { if (user.role === "technician" && user.station_id && Array.isArray(user.station_id)) { user.station_id.forEach((stationId: string) => { if (!technicianMap.has(stationId)) technicianMap.set(stationId, []); technicianMap.get(stationId)!.push(user.username); }); } }); setTechnicians(technicianMap); } catch (e) { console.error("Failed to fetch technicians:", e); } })(); }, []);

  // สถานะ on/off ของตู้ทุกตัวในคำขอเดียว (แทนการยิง /charger-onoff/{sn} ทีละตู้)
  const fetchChargerStatusesBulk = async (): Promise<Record<string, { status: boolean | null }> | null> => {
    try {
      const res = await apiFetch(`/charger-onoff/bulk`);
      if (!res.ok) return null;
      const json = await res.json();
      return json?.statuses ?? null;
    } catch (e) { console.error("Failed to fetch charger statuses:", e); return null; }
  };

  const applyChargerStatuses = (stations: StationRow[], statuses: Record<string, { status: boolean | null }>): StationRow[] =>
    stations.map((station) => station.chargers.length === 0 ? station : ({
      ...station,
      chargers: station.chargers.map((charger) => {
        const d = charger.SN && charger.SN !== "-" ? statuses[charger.SN] : undefined;
        return d ? { ...charger, status: !!d.status } : charger;
      }),
    }));

  // availability ของทุกสถานีในคำขอเดียว (แทนการยิง /station-availability/{id} ทีละสถานี)
  const fetchAvailability = async () => {
    try {
      const res = await apiFetch(`/station-availability/bulk`);
      if (!res.ok) return;
      const json = await res.json();
      const avMap = new Map<string, { total: number; available: number }>();
      const cMap = new Map<string, { total: number; available: number }>();
      Object.values(json?.stations ?? {}).forEach((data: any) => {
        avMap.set(data.station_id, { total: data.total, available: data.available });
        if (Array.isArray(data.chargers)) { data.chargers.forEach((c: any) => { cMap.set(c.sn, { total: c.total, available: c.available }); }); }
      });
      setAvailability(avMap);
      setChargerAvailability(cMap);
      setAvailabilityReady(true);
    } catch (e) { console.error("Failed to fetch availability:", e); }
  };

  const mapCharger = (c: any, index: number): ChargerData => {
    const imgs = c.images || {};

    const norm = (v: any): string[] => Array.isArray(v) ? v : (typeof v === "string" && v ? [v] : []);

    return {
      id: c.id, charger_id: c.charger_id, station_id: c.station_id,
      chargeBoxID: c.chargeBoxID ?? "-", chargerNo: c.chargerNo ?? (index + 1),
      brand: c.brand ?? "-", vendor: c.vendor ?? "", model: c.model ?? "-", SN: c.SN ?? "-", WO: c.WO ?? "-",
      power: c.power ?? "-", PLCFirmware: c.PLCFirmware ?? "-", PIFirmware: c.PIFirmware ?? "-",
      RTFirmware: c.RTFirmware ?? "-", commissioningDate: c.commissioningDate ?? "-",
      warrantyYears: c.warrantyYears ?? 1, numberOfCables: c.numberOfCables ?? 1,
      is_active: c.is_active ?? true, maximo_location: c.maximo_location ?? "", maximo_desc: c.maximo_desc ?? "",
      ocppUrl: c.ocppUrl ?? "", chargerType: c.chargerType ?? "", status: c.status,
      chargerImages: norm(imgs.charger), deviceImages: norm(imgs.device),
    };
  };

  // ✅ mapStation เพิ่ม mdbImages
  const mapStation = (s: any): StationRow => {
    const norm = (v: any): string[] => Array.isArray(v) ? v : (typeof v === "string" && v ? [v] : []);
    const imgs = s.images ?? {};
    return {
      id: s.id, station_id: s.station_id ?? "-", station_name: s.station_name ?? "-",
      owner: s.owner ?? "", user_id: s.user_id ?? "", username: s.username ?? "",
      is_active: !!s.is_active, maximo_location: s.maximo_location ?? "", maximo_desc: s.maximo_desc ?? "",
      warranty_status: s.warranty_status ?? "", investment_scope: Array.isArray(s.investment_scope) ? s.investment_scope : [], io_code: s.io_code ?? "",
      latitude: s.latitude ?? null, longitude: s.longitude ?? null,
      stationImage: s.stationImage ?? (norm(imgs.station)[0] ?? ""),
      mdbImages: norm(imgs.mdb),
      chargers: Array.isArray(s.chargers) ? s.chargers.map(mapCharger) : [],
    };
  };

  const refetchStations = async () => { try { const statusesPromise = fetchChargerStatusesBulk(); const availabilityPromise = fetchAvailability(); const res = await apiFetch(`/all-stations/?view=list`); if (!res.ok) return; const json = await res.json(); const list = Array.isArray(json?.stations) ? json.stations : []; const rows = list.map(mapStation); const statuses = await statusesPromise; setData(statuses ? applyChargerStatuses(rows, statuses) : rows); await availabilityPromise; } catch (e) { console.error("Failed to refetch stations:", e); } };

  useEffect(() => {
    (async () => {
      try {
        const claims = getSessionProfile();
        if (claims) setMe({ user_id: claims.user_id ?? "-", username: claims.username ?? "-", role: claims.role ?? "user" });
        // ยิง 3 คำขอพร้อมกัน — statuses/availability ไม่ต้องรอ all-stations
        const statusesPromise = fetchChargerStatusesBulk();
        const availabilityPromise = fetchAvailability();
        const res = await apiFetch(`/all-stations/?view=list`);
        if (!res.ok) { setErr(`${t.fetchFailed}: ${res.status}`); setData([]); return; }
        const json = await res.json();
        const list = Array.isArray(json?.stations) ? json.stations : [];
        const rows = list.map(mapStation);
        setData(rows);
        const statuses = await statusesPromise;
        if (statuses) setData(applyChargerStatuses(rows, statuses));
        await availabilityPromise;
      } catch (e) { console.error(e); setErr(t.networkError); setData([]); } finally { setLoading(false); }
    })();
  }, []);

  // super_admin is normalized as admin by the backend and must have the same
  // station-management permissions in the UI as admin.
  const isAdmin = me?.role === "admin" || me?.role === "super_admin";

  // "ตั้งค่าแล้ว" = มีหัวชาร์จรายงานเข้ามาใน settingParameter (total > 0)
  // ตู้ที่ยังไม่ตั้งค่าจะไม่เคยส่งสถานะเข้ามา ค่า status จึงเป็น false ตลอด — ถ้าไม่กันไว้
  // ตู้พวกนี้จะถูกนับเป็น offline ด้วย ทำให้การ์ด offline กับ not configured ทับกัน
  const isChargerConfigured = useCallback((c: ChargerData) => {
    // availability ยังไม่มา → ถือว่าตั้งค่าแล้ว เพื่อให้ online/offline ยังทำงานตามเดิม
    if (!availabilityReady) return true;
    const av = chargerAvailability.get((c.SN || "").trim());
    return !!av && av.total > 0;
  }, [availabilityReady, chargerAvailability]);

  // สามกลุ่มนี้ไม่ทับกันแล้ว: online + offline + notConfigured = จำนวนตู้ทั้งหมด
  const chargerCounts = useMemo(() => {
    let total = 0, online = 0, offline = 0, notConfigured = 0;
    data.forEach((s) => s.chargers.forEach((c) => {
      total++;
      if (!isChargerConfigured(c)) notConfigured++;
      else if (c.status) online++;
      else offline++;
    }));
    return { total, online, offline, notConfigured };
  }, [data, isChargerConfigured]);

  const filteredDataByStatus = useMemo(() => {
    if (statusFilter === "all") return data;
    return data.filter((station) => {
      if (statusFilter === "notConfigured") {
        // สถานีที่ยังไม่มีตู้เลยก็คือยังไม่ได้ตั้งค่า ถ้าไม่นับจะหาไม่เจอจากตัวกรองไหนเลย
        if (station.chargers.length === 0) return true;
        return station.chargers.some((c) => !isChargerConfigured(c));
      }
      if (statusFilter === "online") return station.chargers.some((c) => isChargerConfigured(c) && c.status);
      if (statusFilter === "offline") return station.chargers.some((c) => isChargerConfigured(c) && !c.status);
      return true;
    });
  }, [data, statusFilter, isChargerConfigured]);

  const handleEditStation = (station: StationRow, e: React.MouseEvent) => { e.stopPropagation(); if (!isAdmin && station.user_id !== me?.user_id) { alert(t.noEditPermission); return; } setEditingStation(station); setOpenEditStation(true); };
  const handleEditCharger = (stationId: string, charger: ChargerData, e: React.MouseEvent) => { e.stopPropagation(); setEditingCharger({ stationId, charger }); setOpenEditCharger(true); };

  const handleChargerCardClick = (charger: ChargerData, stationId: string) => {
    const sn = charger.SN && charger.SN !== "-" ? charger.SN : "";
    const station = data.find(s => s.station_id === stationId);
    const stationName = station?.station_name || stationId;
    localStorage.removeItem("selected_sn"); localStorage.removeItem("selected_station_id"); localStorage.removeItem("selected_station_name"); localStorage.removeItem("selected_charger_no"); localStorage.removeItem("selected_chargerType");
    if (sn) localStorage.setItem("selected_sn", sn); if (stationId) localStorage.setItem("selected_station_id", stationId);
    localStorage.setItem("selected_station_name", stationName);
    if (charger.chargerType) localStorage.setItem("selected_chargerType", charger.chargerType);
    if (charger.chargerNo) localStorage.setItem("selected_charger_no", String(charger.chargerNo));
    const params = new URLSearchParams(); if (sn) params.set("sn", sn); if (stationId) params.set("station_id", stationId);
    const qs = params.toString();
    if (isStaffRole(me?.role)) { router.push(`${staffChargerPath(me?.role)}${qs ? `?${qs}` : ""}`); } else { router.push(`/dashboard/chargers${qs ? `?${qs}` : ""}`); }
  };

  // ✅ handleUpdateStation เพิ่มการ upload MDB
  const handleUpdateStation = async () => {
    if (!editingStation?.id) return;
    const coords = parseLatLng(editStationForm.coords);
    if (!coords) { setNotice({ type: "error", msg: t.coordsInvalid }); setTimeout(() => setNotice(null), 3500); return; }
    try {
      setSaving(true);
      const payload: StationUpdatePayload = {
        station_name: editStationForm.station_name.trim(), is_active: editStationForm.is_active, maximo_location: editStationForm.maximo_location.trim(), maximo_desc: editStationForm.maximo_desc.trim(), warranty_status: editStationForm.warranty_status, investment_scope: editStationForm.investment_scope, io_code: editStationForm.io_code.trim(), latitude: coords.latitude, longitude: coords.longitude, ...(isAdmin && selectedOwnerName
          ? { username: selectedOwnerName }
          : {})
      };
      const res = await apiFetch(`/update_stations/${editingStation.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) { const errBody = await res.json().catch(() => ({})); throw new Error(errBody?.detail || `Update failed: ${res.status}`); }
      const updated = await res.json();

      // ลบรูป station เดิม
      if (deleteCurrentImage && editingStation.stationImage) {
        await apiFetch(`/stations/${editingStation.station_id}/delete-image`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: "station", url: editingStation.stationImage }) });
      }
      // ลบรูป MDB เดิมที่ถูก mark
      const mdbImgsToDelete = (editingStation?.mdbImages || [])
        .filter((_, i) => deletedExistingMdbIdxs.has(i));

      for (const url of mdbImgsToDelete) {
        await apiFetch(`/stations/${editingStation.station_id}/delete-image`, {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind: "mdb", url }),
        });
      }
      // อัปโหลดรูปใหม่ (station + mdb รวมกันใน 1 request)
      if (editStationImages.length || editMdbImages.length) {
        const fd = new FormData();
        editStationImages.forEach(f => fd.append("station", f));
        editMdbImages.forEach(f => fd.append("mdb", f));  // ✅ MDB
        await apiFetch(`/stations/${editingStation.station_id}/upload-image`, { method: "POST", body: fd });
      }

      setData(prev => prev.map(s => s.id === editingStation.id ? {
        ...s,
        station_name: updated.station_name ?? editStationForm.station_name,
        is_active: updated.is_active ?? editStationForm.is_active,
        maximo_location: updated.maximo_location ?? editStationForm.maximo_location,
        maximo_desc: updated.maximo_desc ?? editStationForm.maximo_desc,
        warranty_status: updated.warranty_status ?? editStationForm.warranty_status,
        investment_scope: updated.investment_scope ?? editStationForm.investment_scope,
        io_code: updated.io_code ?? editStationForm.io_code,
        latitude: updated.latitude ?? null, longitude: updated.longitude ?? null,
        user_id: updated.user_id ?? s.user_id,
        username: updated.username ?? s.username,
        stationImage: editStationImages.length ? s.stationImage : (deleteCurrentImage ? "" : s.stationImage),
      } : s));

      // refetch เพื่ออัปเดต mdbImages
      await refetchStations();

      setOpenEditStation(false);
      setNotice({ type: "success", msg: t.stationUpdated });
      setTimeout(() => setNotice(null), 2500);
    } catch (e: any) { console.error(e); setNotice({ type: "error", msg: e?.message || t.updateFailed }); setTimeout(() => setNotice(null), 3500); } finally { setSaving(false); }
  };

  const handleUpdateCharger = async () => {
    if (!editingCharger?.charger.id) return;
    try {
      setSaving(true);
      const currentExpanded = table.getState().expanded;
      const payload: ChargerUpdatePayload = { chargeBoxID: editChargerForm.chargeBoxID.trim(), chargerNo: editChargerForm.chargerNo, brand: editChargerForm.brand.trim(), vendor: editChargerForm.vendor.trim(), model: editChargerForm.model.trim(), SN: editChargerForm.SN.trim(), WO: editChargerForm.WO.trim(), power: editChargerForm.power.trim(), PLCFirmware: editChargerForm.PLCFirmware.trim(), PIFirmware: editChargerForm.PIFirmware.trim(), RTFirmware: editChargerForm.RTFirmware.trim(), commissioningDate: editChargerForm.commissioningDate, warrantyYears: editChargerForm.warrantyYears, numberOfCables: editChargerForm.numberOfCables, is_active: editChargerForm.is_active, maximo_location: editChargerForm.maximo_location.trim(), maximo_desc: editChargerForm.maximo_desc.trim(), ocppUrl: editChargerForm.ocppUrl.trim(), chargerType: editChargerForm.chargerType };
      const res = await apiFetch(`/update_charger/${editingCharger.charger.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) { const errBody = await res.json().catch(() => ({})); throw new Error(errBody?.detail || `Update failed: ${res.status}`); }
      const chargerImgsToDelete = (editingCharger.charger.chargerImages || []).filter((_, i) => deletedExistingChargerIdxs.has(i));
      const deviceImgsToDelete = (editingCharger.charger.deviceImages || []).filter((_, i) => deletedExistingDeviceIdxs.has(i));
      if (chargerImgsToDelete.length || deviceImgsToDelete.length) { await apiFetch(`/chargers/${editingCharger.charger.id}/delete-images`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ charger: chargerImgsToDelete, device: deviceImgsToDelete }) }); }
      if (editChargerImages.length || editDeviceImages.length) { const fd = new FormData(); editChargerImages.forEach(f => fd.append("charger", f)); editDeviceImages.forEach(f => fd.append("device", f)); await apiFetch(`/chargers/${editingCharger.charger.id}/upload-images`, { method: "POST", body: fd }); }
      await refetchStations();
      setExpanded(currentExpanded);
      setOpenEditCharger(false); setNotice({ type: "success", msg: t.chargerUpdated }); setTimeout(() => setNotice(null), 2500);
    } catch (e: any) { console.error(e); setNotice({ type: "error", msg: e?.message || t.updateFailed }); setTimeout(() => setNotice(null), 3500); } finally { setSaving(false); }
  };

  const handleDeleteStation = (station: StationRow, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!station.id) return;
    setConfirmDialog({
      open: true,
      title: lang === "th" ? "ลบสถานี?" : "Delete Station?",
      message: lang === "th" ? `คุณต้องการลบสถานี "${station.station_name}" และตู้ชาร์จทั้งหมดใช่หรือไม่?` : `Are you sure you want to delete "${station.station_name}" and all its chargers?`,
      loading: false,
      onConfirm: async () => {
        try {
          setConfirmDialog(prev => ({ ...prev, loading: true }));
          const res = await apiFetch(`/delete_stations/${station.id}`, { method: "DELETE" });
          if (!res.ok) throw new Error(`Delete failed: ${res.status}`);
          setData(prev => prev.filter(s => s.id !== station.id));
          closeConfirm(); setNotice({ type: "success", msg: t.deleteSuccess }); setTimeout(() => setNotice(null), 2500);
        } catch (e: any) { console.error(e); closeConfirm(); setNotice({ type: "error", msg: e.message || t.deleteStationFailed }); setTimeout(() => setNotice(null), 3500); }
      },
    });
  };

  const handleDeleteCharger = (stationId: string, charger: ChargerData, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!charger.id) return;
    setConfirmDialog({
      open: true,
      title: lang === "th" ? "ลบตู้ชาร์จ?" : "Delete Charger?",
      message: lang === "th" ? `คุณต้องการลบตู้ชาร์จ "${charger.chargeBoxID}" ใช่หรือไม่?` : `Are you sure you want to delete charger "${charger.chargeBoxID}"?`,
      loading: false,
      onConfirm: async () => {
        try {
          setConfirmDialog(prev => ({ ...prev, loading: true }));
          const res = await apiFetch(`/delete_charger/${charger.id}`, { method: "DELETE" });
          if (!res.ok) throw new Error(`Delete failed: ${res.status}`);
          setData(prev => prev.map(st => { if (st.station_id !== stationId) return st; return { ...st, chargers: st.chargers.filter(c => c.id !== charger.id) }; }));
          closeConfirm(); setNotice({ type: "success", msg: t.chargerDeleted }); setTimeout(() => setNotice(null), 2500);
        } catch (e: any) { console.error(e); closeConfirm(); setNotice({ type: "error", msg: e.message || t.deleteChargerFailed }); setTimeout(() => setNotice(null), 3500); }
      },
    });
  };

  const handleOpenAddCharger = (stationId: string) => {
    const station = data.find(s => s.station_id === stationId);
    const nextChargerNo = station ? station.chargers.length + 1 : 1;
    setAddingChargerStationId(stationId);
    setAddChargerForm({ chargeBoxID: "", chargerNo: nextChargerNo, brand: "", vendor: "", model: "", SN: "", WO: "", power: "", PLCFirmware: "", PIFirmware: "", RTFirmware: "", commissioningDate: getTodayDate(), warrantyYears: 1, numberOfCables: 1, is_active: true, maximo_location: "", maximo_desc: "", ocppUrl: "", chargerType: "DC" });
    resetAddChargerImages(); setOpenAddCharger(true);
  };

  const handleCreateCharger = async () => {
    if (!addingChargerStationId) return;
    try {
      setSaving(true);
      const payload = { chargeBoxID: addChargerForm.chargeBoxID.trim(), chargerNo: addChargerForm.chargerNo, brand: addChargerForm.brand.trim(), vendor: addChargerForm.vendor.trim(), model: addChargerForm.model.trim(), SN: addChargerForm.SN.trim(), WO: addChargerForm.WO.trim(), power: addChargerForm.power.trim(), PLCFirmware: addChargerForm.PLCFirmware.trim(), PIFirmware: addChargerForm.PIFirmware.trim(), RTFirmware: addChargerForm.RTFirmware.trim(), commissioningDate: addChargerForm.commissioningDate, warrantyYears: addChargerForm.warrantyYears, numberOfCables: addChargerForm.numberOfCables, is_active: addChargerForm.is_active, maximo_location: addChargerForm.maximo_location.trim(), maximo_desc: addChargerForm.maximo_desc.trim(), ocppUrl: addChargerForm.ocppUrl.trim(), chargerType: addChargerForm.chargerType };
      const res = await apiFetch(`/add_charger/${addingChargerStationId}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) { const errBody = await res.json().catch(() => ({})); throw new Error(errBody?.detail || `Create failed: ${res.status}`); }
      const created = await res.json();
      if (created.id && (addChargerImages.length || addDeviceImages.length)) { const fd = new FormData(); addChargerImages.forEach(f => fd.append("charger", f)); addDeviceImages.forEach(f => fd.append("device", f)); await apiFetch(`/chargers/${created.id}/upload-images`, { method: "POST", body: fd }); }
      const currentExpanded = table.getState().expanded;
      await refetchStations();
      setExpanded(currentExpanded);
      resetAddChargerImages(); setOpenAddCharger(false); setNotice({ type: "success", msg: t.chargerCreated }); setTimeout(() => setNotice(null), 2500);
    } catch (e: any) { console.error(e); setNotice({ type: "error", msg: e?.message || t.createChargerFailed }); setTimeout(() => setNotice(null), 3500); } finally { setSaving(false); }
  };

  const handleCreateStation = async (payload: NewStationPayload) => {
    try {
      setSaving(true);
      const res = await apiFetch(`/add_stations/`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) { const errBody = await res.json().catch(() => ({})); throw new Error(errBody?.detail || `Create failed: ${res.status}`); }
      const created = await res.json();
      const newStation: StationRow = { id: created.id || created.station?.id, station_id: created.station?.station_id ?? payload.station?.station_id, station_name: created.station?.station_name ?? payload.station?.station_name ?? "", owner: created.station?.owner ?? "", user_id: created.station?.user_id ?? me?.user_id ?? "", username: created.station?.username ?? me?.username ?? "", is_active: created.station?.is_active ?? true, maximo_location: created.station?.maximo_location ?? (payload.station as any)?.maximo_location ?? "", maximo_desc: created.station?.maximo_desc ?? (payload.station as any)?.maximo_desc ?? "", warranty_status: created.station?.warranty_status ?? (payload.station as any)?.warranty_status ?? "", investment_scope: created.station?.investment_scope ?? (payload.station as any)?.investment_scope ?? [], io_code: created.station?.io_code ?? (payload.station as any)?.io_code ?? "", latitude: created.station?.latitude ?? null, longitude: created.station?.longitude ?? null, stationImage: "", mdbImages: [], chargers: Array.isArray(created.chargers) ? created.chargers.map(mapCharger) : [] };
      setData(prev => [newStation, ...prev]); setOpenAdd(false); setNotice({ type: "success", msg: t.createSuccess }); setTimeout(() => setNotice(null), 3000);
      return created;
    } catch (e: any) { console.error(e); alert(e?.message || t.createStationFailed); throw e; } finally { setSaving(false); }
  };

  useEffect(() => { const lock = openAdd || openEditStation || openEditCharger || openAddCharger; if (lock) { const scrollY = window.scrollY; document.body.style.position = "fixed"; document.body.style.top = `-${scrollY}px`; document.body.style.left = "0"; document.body.style.right = "0"; document.body.style.width = "100%"; document.body.style.overflow = "hidden"; } else { const top = document.body.style.top; document.body.style.position = ""; document.body.style.top = ""; document.body.style.left = ""; document.body.style.right = ""; document.body.style.width = ""; document.body.style.overflow = ""; if (top) { const y = parseInt(top || "0") * -1; window.scrollTo(0, y); } } }, [openAdd, openEditStation, openEditCharger, openAddCharger]);

  const handleSubmitImages = async (stationId: string, stationImages: { station: File[]; mdb: File[] }, chargerImages: Array<{ chargerNo: number; chargerImages: File[]; deviceImages: File[] }>, createdChargers: Array<{ id: string; chargerNo: number }>) => {
    try {
      if (stationImages.station.length || stationImages.mdb.length) {
        const fd = new FormData();
        stationImages.station.forEach(f => fd.append("station", f));
        stationImages.mdb.forEach(f => fd.append("mdb", f));
        await apiFetch(`/stations/${stationId}/upload-image`, { method: "POST", body: fd });
      }
      for (const ci of chargerImages) { const cc = createdChargers.find(c => c.chargerNo === ci.chargerNo); if (!cc?.id) continue; if (ci.chargerImages.length || ci.deviceImages.length) { const fd = new FormData(); ci.chargerImages.forEach(f => fd.append("charger", f)); ci.deviceImages.forEach(f => fd.append("device", f)); await apiFetch(`/chargers/${cc.id}/upload-images`, { method: "POST", body: fd }); } }
      await refetchStations();
    } catch (e) { console.error("[Images] Upload failed:", e); }
  };

  // ===== Columns =====
  const columns = useMemo(() => {
    const baseColumns = [
      { id: "expander", header: () => null, size: 50, cell: ({ row }: { row: Row<StationRow> }) => { const hasChargers = row.original.chargers.length > 0; const canEdit = isAdmin || row.original.user_id === me?.user_id; if (!(hasChargers || canEdit)) return null; return (<span className="tw-p-1.5 tw-rounded-lg">{row.getIsExpanded() ? <ChevronDownIcon className="tw-h-5 tw-w-5 tw-text-blue-600" /> : <ChevronRightIconSolid className="tw-h-5 tw-w-5 tw-text-blue-gray-500" />}</span>); } },
      { id: "station_name", header: () => t.stationName, accessorFn: (row: StationRow) => row.station_name, cell: (info: any) => (<span className="tw-font-semibold tw-text-blue-gray-800">{info.getValue()}</span>) },
      { id: "charger_count", header: () => t.chargers, size: 100, cell: ({ row }: { row: Row<StationRow> }) => { const count = row.original.chargers.length; const onlineCount = row.original.chargers.filter(c => c.status).length; return (<div className="tw-flex tw-items-center tw-gap-2"><span className="tw-inline-flex tw-items-center tw-gap-1.5 tw-px-2.5 tw-py-1 tw-rounded-lg tw-bg-gradient-to-r tw-from-amber-400 tw-to-orange-400 tw-shadow-sm"><BoltIcon className="tw-h-3.5 tw-w-3.5 tw-text-white" /><span className="tw-text-xs tw-font-bold tw-text-white">{count}</span></span>{count > 0 && (<span className="tw-text-[10px] tw-text-blue-gray-400"><span className="tw-text-green-600 tw-font-semibold">{onlineCount}</span><span className="tw-mx-0.5">/</span><span>{count} {t.online}</span></span>)}</div>); } },
      { id: "available", header: () => t.available, size: 120, cell: ({ row }: { row: Row<StationRow> }) => { const chargers = row.original.chargers; const av = availability.get(row.original.station_id); if (!av || av.total === 0) return (<span className="tw-inline-flex tw-items-center tw-gap-1.5 tw-px-2.5 tw-py-1 tw-rounded-full tw-border tw-text-xs tw-font-medium tw-bg-gray-50 tw-border-gray-200 tw-text-gray-500"><span className="tw-h-2 tw-w-2 tw-rounded-full tw-bg-gray-300" />{t.notConfigured}</span>); const isOffline = chargers.length > 0 && chargers.filter(c => c.status).length === 0; if (isOffline) return (<div className="tw-flex tw-flex-col tw-items-start tw-gap-0.5"><span className="tw-inline-flex tw-items-center tw-gap-1.5 tw-px-2.5 tw-py-1 tw-rounded-full tw-border tw-text-xs tw-font-semibold tw-bg-red-50 tw-border-red-200 tw-text-red-600"><span className="tw-h-2 tw-w-2 tw-rounded-full tw-bg-red-500" />0/{av.total} {t.availableOf}</span></div>); return (<div className="tw-flex tw-flex-col tw-items-start tw-gap-0.5"><span className="tw-inline-flex tw-items-center tw-gap-1.5 tw-px-2.5 tw-py-1 tw-rounded-full tw-border tw-text-xs tw-font-semibold tw-bg-green-50 tw-border-green-200 tw-text-green-700"><span className="tw-h-2 tw-w-2 tw-rounded-full tw-bg-green-500" />{av.available}/{av.total} {t.availableOf}</span></div>); } },
      { id: "username", header: () => t.owner, accessorFn: (row: StationRow) => row.username ?? "-", cell: (info: any) => (<span className="tw-text-blue-gray-600">{info.getValue()}</span>) },
      { id: "is_active", header: () => t.status, size: 100, cell: ({ row }: { row: Row<StationRow> }) => { const on = !!row.original.is_active; return (<span className={`tw-inline-flex tw-items-center tw-gap-1.5 tw-px-2.5 tw-py-1 tw-rounded-md tw-text-xs tw-font-semibold tw-transition-colors ${on ? "tw-bg-green-50 tw-text-green-700 tw-ring-1 tw-ring-green-200" : "tw-bg-red-50 tw-text-red-600 tw-ring-1 tw-ring-red-200"}`}><span className={`tw-h-1.5 tw-w-1.5 tw-rounded-full ${on ? "tw-bg-green-500 tw-animate-pulse" : "tw-bg-red-400"}`} />{on ? t.active : t.inactive}</span>); } },
    ];
    if (!isStaffRole(me?.role)) {
      baseColumns.push({ id: "actions", header: () => t.actions, size: 100, enableSorting: false, cell: ({ row }: { row: Row<StationRow> }) => { const canEdit = isAdmin || row.original.user_id === me?.user_id; return (<span className="tw-inline-flex tw-items-center tw-gap-1.5" onClick={(e) => e.stopPropagation()}>{canEdit && (<Tooltip content={t.editStationTooltip}><button onClick={(e) => handleEditStation(row.original, e)} className="tw-group/btn tw-rounded-lg tw-p-2 tw-bg-blue-50 tw-ring-1 tw-ring-blue-200/60 hover:tw-bg-blue-600 hover:tw-ring-blue-600 tw-transition-all tw-duration-200 tw-shadow-sm hover:tw-shadow-md"><PencilSquareIcon className="tw-h-4 tw-w-4 tw-text-blue-600 group-hover/btn:tw-text-white tw-transition-colors" /></button></Tooltip>)}{isAdmin && (<Tooltip content={t.deleteStationTooltip}><button onClick={(e) => handleDeleteStation(row.original, e)} className="tw-group/btn tw-rounded-lg tw-p-2 tw-bg-red-50 tw-ring-1 tw-ring-red-200/60 hover:tw-bg-red-600 hover:tw-ring-red-600 tw-transition-all tw-duration-200 tw-shadow-sm hover:tw-shadow-md"><TrashIcon className="tw-h-4 tw-w-4 tw-text-red-500 group-hover/btn:tw-text-white tw-transition-colors" /></button></Tooltip>)}</span>); } } as any);
    }
    return baseColumns;
  }, [me, technicians, isAdmin, t, availability]);

  // ค้นหา: ชื่อสถานี / station_id / เจ้าของ + SN และ Charge Box ID ของตู้ชาร์จในสถานีนั้น
  const chargerMatches = useCallback((row: StationRow, q: string) =>
    row.chargers.some((c) => [c.SN, c.chargeBoxID].some((v) => String(v ?? "").toLowerCase().includes(q))), []);

  const stationMatches = useCallback((row: StationRow, keyword: string) => {
    const q = keyword.trim().toLowerCase();
    if (!q) return true;
    if ([row.station_name, row.station_id, row.username].some((v) => String(v ?? "").toLowerCase().includes(q))) return true;
    return chargerMatches(row, q);
  }, [chargerMatches]);

  // ค้น SN แล้วเจอแต่แถวสถานี ยังไม่เห็นตู้ → กางแถวที่ตู้ตรงกับคำค้นให้เลย
  const autoExpandedRef = useRef<string[]>([]);
  useEffect(() => {
    const q = filtering.trim().toLowerCase();
    const hit = q ? filteredDataByStatus.filter((s) => chargerMatches(s, q)).map((s) => s.station_id) : [];
    const prevAuto = autoExpandedRef.current;
    if (prevAuto.length === hit.length && prevAuto.every((id, i) => id === hit[i])) return;
    autoExpandedRef.current = hit;
    setExpanded((prev) => {
      const next: Record<string, boolean> = typeof prev === "boolean" ? {} : { ...prev };
      prevAuto.forEach((id) => { delete next[id]; });
      hit.forEach((id) => { next[id] = true; });
      return next;
    });
  }, [filtering, filteredDataByStatus, chargerMatches]);

  const table = useReactTable({
    data: filteredDataByStatus, columns,
    getRowId: (row) => row.station_id,
    state: { globalFilter: filtering, sorting, expanded },
    // เช็คทีเดียวต่อแถว (คอลัมน์อื่นข้าม) แล้วให้ stationMatches ตัดสินทั้งแถว
    getColumnCanGlobalFilter: (column) => column.id === "station_name",
    globalFilterFn: (row, _columnId, value) => stationMatches(row.original as StationRow, String(value ?? "")),
    onSortingChange: setSorting, onGlobalFilterChange: setFiltering, onExpandedChange: setExpanded,
    getRowCanExpand: (row) => row.original.chargers.length > 0 || isAdmin || row.original.user_id === me?.user_id,
    getSortedRowModel: getSortedRowModel(), getFilteredRowModel: getFilteredRowModel(),
    getCoreRowModel: getCoreRowModel(), getPaginationRowModel: getPaginationRowModel(), getExpandedRowModel: getExpandedRowModel(),
  });

  const formatPower = (power: string | number | undefined | null) => { if (!power) return "-"; const text = String(power).trim(); return /\bkw\b/i.test(text) ? text : `${text} kW`; };

  const ChargerCard = ({ charger, stationId, canEdit, index }: { charger: ChargerData; stationId: string; canEdit: boolean; index: number }) => {
    const configured = isChargerConfigured(charger);
    const isOnline = configured && !!charger.status;
    const tone = CHARGER_TONES[!configured ? "gray" : isOnline ? "green" : "red"];
    const av = chargerAvailability.get((charger.SN || "").trim());
    return (
      <div onClick={() => handleChargerCardClick(charger, stationId)} className="tw-group tw-relative tw-overflow-hidden tw-rounded-xl tw-border tw-border-blue-gray-100 tw-bg-white tw-shadow-sm hover:tw-shadow-lg tw-transition-all tw-duration-300 tw-cursor-pointer hover:tw-border-blue-300 hover:tw--translate-y-0.5" style={{ animationDelay: `${index * 50}ms` }}>
        <div className={`tw-h-1 tw-w-full ${tone.bar}`} />
        <div className="tw-p-3 sm:tw-p-4">
          <div className="tw-flex tw-items-start tw-justify-between tw-gap-2 tw-mb-3">
            <div className="tw-flex tw-items-center tw-gap-2 tw-min-w-0 tw-flex-1">
              <div className={`tw-p-2 tw-rounded-lg tw-flex-shrink-0 ${tone.iconBox}`}>
                <BoltIcon className={`tw-h-4 tw-w-4 ${tone.icon}`} />
              </div>
              <div className="tw-min-w-0 tw-flex-1">
                <h4 className="tw-font-bold tw-text-xs tw-text-blue-gray-800 tw-truncate" title={charger.chargeBoxID}>{charger.chargeBoxID || "-"}</h4>
                <div className="tw-flex tw-items-center tw-gap-1 tw-mt-1 tw-flex-wrap">
                  <span className="tw-px-1.5 tw-py-0.5 tw-rounded-md tw-bg-blue-gray-800 tw-text-[8px] tw-font-bold tw-text-white">#{charger.chargerNo}</span>
                  {charger.chargerType && (<span className="tw-px-1.5 tw-py-0.5 tw-rounded-md tw-bg-purple-100 tw-text-[8px] tw-font-bold tw-text-purple-700">{charger.chargerType}</span>)}
                  <span className={`tw-flex tw-items-center tw-gap-0.5 tw-px-1.5 tw-py-0.5 tw-rounded-md tw-text-[8px] tw-font-bold ${tone.chip}`}>
                    <span className={`tw-h-1.5 tw-w-1.5 tw-rounded-full ${tone.dot}`} />{!configured ? t.notConfigured : isOnline ? t.online : t.offline}
                  </span>
                </div>
              </div>
            </div>
            <div className="tw-flex tw-items-center tw-gap-0.5 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity">
              {canEdit && (<button onClick={(e) => handleEditCharger(stationId, charger, e)} className="tw-p-1.5 tw-rounded-lg tw-text-blue-gray-400 hover:tw-text-blue-600 hover:tw-bg-blue-50 tw-transition-colors"><PencilSquareIcon className="tw-h-3.5 tw-w-3.5" /></button>)}
              {isAdmin && (<button onClick={(e) => handleDeleteCharger(stationId, charger, e)} className="tw-p-1.5 tw-rounded-lg tw-text-blue-gray-400 hover:tw-text-red-500 hover:tw-bg-red-50 tw-transition-colors"><TrashIcon className="tw-h-3.5 tw-w-3.5" /></button>)}
            </div>
          </div>
          <div className="tw-grid tw-grid-cols-2 tw-gap-x-3 tw-gap-y-1 tw-text-[10px] tw-mb-3">
            {[[t.brand, charger.brand], [t.vendor, charger.vendor], [t.model, charger.model], [t.serialNumber, charger.SN, true], [t.power, formatPower(charger.power)], [t.cables, charger.numberOfCables || "-"], [t.warranty, `${charger.warrantyYears || "-"}${t.year}`]].map(([label, value, mono], i) => (
              <div key={i} className="tw-truncate"><span className="tw-text-blue-gray-400">{label as string}: </span><span className={`tw-text-blue-gray-700 tw-font-medium ${mono ? "tw-font-mono" : ""}`}>{(value as string) || "-"}</span></div>
            ))}
          </div>
          {((charger.chargerImages?.length ?? 0) > 0 || (charger.deviceImages?.length ?? 0) > 0) && (
            <div className="tw-flex tw-items-center tw-gap-2 tw-mb-3 tw-overflow-x-auto">
              {charger.chargerImages?.map((url, i) => (<a key={`c-${i}`} href={imgUrl(url)} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="tw-flex-shrink-0"><div className="tw-relative tw-group/img"><img src={imgUrl(url)} alt={`${t.chargers} ${i + 1}`} className="tw-h-14 tw-w-14 tw-object-cover tw-rounded-lg tw-border-2 tw-border-blue-gray-100 group-hover/img:tw-border-blue-400 tw-transition-colors" /><span className="tw-absolute tw-bottom-0 tw-inset-x-0 tw-bg-black/60 tw-text-white tw-text-[7px] tw-text-center tw-py-0.5 tw-rounded-b-md">{t.chargers} {charger.chargerImages!.length > 1 ? i + 1 : ""}</span></div></a>))}
              {charger.deviceImages?.map((url, i) => (<a key={`d-${i}`} href={imgUrl(url)} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="tw-flex-shrink-0"><div className="tw-relative tw-group/img"><img src={imgUrl(url)} alt={`${t.deviceImageBadge} ${i + 1}`} className="tw-h-14 tw-w-14 tw-object-cover tw-rounded-lg tw-border-2 tw-border-blue-gray-100 group-hover/img:tw-border-blue-400 tw-transition-colors" /><span className="tw-absolute tw-bottom-0 tw-inset-x-0 tw-bg-black/60 tw-text-white tw-text-[7px] tw-text-center tw-py-0.5 tw-rounded-b-md">{t.deviceImageBadge} {charger.deviceImages!.length > 1 ? i + 1 : ""}</span></div></a>))}
            </div>
          )}
          <div className="tw-flex tw-items-center tw-gap-2 tw-mb-3">
            <div className="tw-flex-1 tw-px-2 tw-py-1 tw-rounded-lg tw-bg-blue-50/80 tw-border tw-border-blue-100"><span className="tw-text-[10px] tw-text-blue-700 tw-font-medium">📅 {formatDate(charger.commissioningDate)}</span></div>
            {/* ป้ายหัวชาร์จว่าง — ตู้ที่ยังไม่ได้ตั้งค่าไม่ต้องแสดง เพราะป้ายสถานะด้านบนบอกไปแล้ว */}
            {av && av.total > 0 && (<div className="tw-px-2 tw-py-1 tw-rounded-lg tw-border tw-text-[10px] tw-font-bold tw-flex tw-items-center tw-gap-1 tw-bg-green-50 tw-border-green-200 tw-text-green-700"><span className="tw-h-1.5 tw-w-1.5 tw-rounded-full tw-bg-green-500" />🔌 {av.available}/{av.total}</div>)}
          </div>
          <div className="tw-rounded-lg tw-bg-gradient-to-b tw-from-gray-50 tw-to-gray-100/50 tw-p-2 tw-ring-1 tw-ring-gray-200/60">
            <div className="tw-flex tw-items-center tw-gap-1 tw-mb-1.5"><CpuChipIcon className="tw-h-3 tw-w-3 tw-text-blue-gray-400" /><span className="tw-text-[8px] tw-font-bold tw-uppercase tw-text-blue-gray-500 tw-tracking-wider">{t.firmware}</span></div>
            <div className="tw-grid tw-grid-cols-3 tw-gap-1">
              {[["PLC", charger.PLCFirmware], ["Pi", charger.PIFirmware], ["RT", charger.RTFirmware]].map(([label, val]) => (<div key={label} className="tw-text-center tw-rounded-md tw-px-1 tw-py-1 tw-bg-white tw-ring-1 tw-ring-gray-200/60"><div className="tw-text-[7px] tw-text-blue-gray-400 tw-font-medium">{label}</div><div className="tw-text-[9px] tw-font-mono tw-text-blue-gray-700 tw-truncate">{val || "-"}</div></div>))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const ChargersExpandedSection = ({ chargers, stationId, canEdit }: { chargers: ChargerData[]; stationId: string; canEdit: boolean }) => {
    // นับแบบเดียวกับการ์ดสรุปด้านบน — ตู้ที่ยังไม่ได้ตั้งค่าแยกออกมา ไม่รวมกับออฟไลน์
    const configuredChargers = chargers.filter(isChargerConfigured);
    const onlineCount = configuredChargers.filter(c => c.status).length;
    const offlineCount = configuredChargers.length - onlineCount;
    const notConfiguredCount = chargers.length - configuredChargers.length;
    return (
      <tr><td colSpan={columns.length} className="tw-p-0"><div className="tw-bg-gray-50/50 tw-border-t tw-border-blue-gray-100">
        <div className="tw-px-3 sm:tw-px-6 tw-py-2 sm:tw-py-3 tw-border-b tw-border-blue-gray-100 tw-bg-white"><div className="tw-flex tw-items-center tw-justify-between tw-flex-wrap tw-gap-2"><div className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-3 tw-flex-wrap"><span className="tw-inline-flex tw-items-center tw-gap-1 sm:tw-gap-1.5 tw-px-2 sm:tw-px-2.5 tw-py-0.5 sm:tw-py-1 tw-rounded-full tw-bg-gradient-to-r tw-from-amber-50 tw-to-yellow-50 tw-border tw-border-amber-200"><BoltIcon className="tw-h-3 tw-w-3 sm:tw-h-4 sm:tw-w-4 tw-text-amber-500" /><span className="tw-text-xs sm:tw-text-sm tw-font-semibold tw-text-amber-700">{t.chargers} ({chargers.length})</span></span><span className="tw-text-xs sm:tw-text-sm tw-text-green-600">• {onlineCount} {t.online}</span>{offlineCount > 0 && (<span className="tw-text-xs sm:tw-text-sm tw-text-red-500">• {offlineCount} {t.offline}</span>)}{notConfiguredCount > 0 && (<span className="tw-text-xs sm:tw-text-sm tw-text-gray-400">• {notConfiguredCount} {t.notConfigured}</span>)}</div>{canEdit && (<Button size="sm" onClick={() => handleOpenAddCharger(stationId)} className="tw-bg-gradient-to-b tw-from-neutral-800 tw-to-neutral-900 hover:tw-to-black tw-flex tw-items-center tw-gap-1 tw-shadow-sm tw-text-xs sm:tw-text-sm tw-px-2 sm:tw-px-3 tw-py-1.5 sm:tw-py-2"><BoltIcon className="tw-h-3 tw-w-3 sm:tw-h-4 sm:tw-w-4" /><span className="tw-hidden sm:tw-inline">{t.addCharger}</span><span className="tw-inline sm:tw-hidden">+ {t.add}</span></Button>)}</div></div>
        <div className="tw-p-2 sm:tw-p-4">{chargers.length > 0 ? (<div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 md:tw-grid-cols-2 lg:tw-grid-cols-3 xl:tw-grid-cols-4 tw-gap-2 sm:tw-gap-4 lg:tw-gap-5">{chargers.map((charger, index) => (<ChargerCard key={charger.id || charger.chargeBoxID} charger={charger} stationId={stationId} canEdit={canEdit} index={index} />))}</div>) : (<div className="tw-text-center tw-py-6 sm:tw-py-8 tw-text-blue-gray-400"><BoltIcon className="tw-h-8 tw-w-8 sm:tw-h-12 sm:tw-w-12 tw-mx-auto tw-mb-2 tw-opacity-30" /><p className="tw-text-xs sm:tw-text-sm">{t.noChargersYet}</p>{canEdit && (<Button size="sm" onClick={() => handleOpenAddCharger(stationId)} className="tw-mt-2 sm:tw-mt-3 tw-bg-gradient-to-b tw-from-neutral-800 tw-to-neutral-900 hover:tw-to-black tw-text-xs">{t.addFirstCharger}</Button>)}</div>)}</div>
      </div></td></tr>
    );
  };

  // ===== Main Return =====
  return (
    <>
      <LoadingOverlay show={loading} text={lang === "th" ? "กำลังโหลดข้อมูล..." : "Loading data..."} />
      <div className="tw-mt-4 tw-mb-4">
        {statusFilter !== "all" && (
          <div className="tw-mb-3 tw-flex tw-items-center tw-gap-2">
            <span className="tw-text-sm tw-text-blue-gray-600">{lang === "th" ? `ตัวกรอง: ${statusFilter === "online" ? "ออนไลน์" : statusFilter === "offline" ? "ออฟไลน์" : "ยังไม่ได้ตั้งค่า"}` : `Filter: ${statusFilter === "online" ? "Online" : statusFilter === "offline" ? "Offline" : "Not configured"}`}</span>
            <button type="button" onClick={() => setStatusFilter("all")} className="tw-text-sm tw-text-blue-600 hover:tw-underline">{lang === "th" ? "ล้างตัวกรอง" : "Clear"}</button>
          </div>
        )}
        <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-3 lg:tw-grid-cols-5 tw-gap-2.5 sm:tw-gap-3">
          {loading ? (<>{Array.from({ length: 5 }).map((_, i) => <StatCardSkeleton key={i} />)}</>) : (
            <>
              <div className="tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-gradient-to-br tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-5 tw-py-3.5 sm:tw-py-4 tw-ring-1 tw-ring-white/10 tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-300 hover:tw--translate-y-0.5">
                <div className="tw-absolute tw-inset-0 tw-opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
                <div className="tw-relative tw-z-10"><div className="tw-flex tw-items-center tw-gap-2 tw-mb-2"><div className="tw-h-8 tw-w-8 tw-rounded-xl tw-bg-blue-500/20 tw-flex tw-items-center tw-justify-center tw-ring-1 tw-ring-blue-400/20"><span className="tw-text-base">📍</span></div><span className="tw-text-[10px] sm:tw-text-[11px] tw-font-semibold tw-text-white/40 tw-uppercase tw-tracking-wider">{lang === "th" ? "สถานี" : "Stations"}</span></div><div className="tw-text-2xl sm:tw-text-3xl tw-font-black tw-text-white tw-tabular-nums tw-tracking-tight tw-leading-none">{data.length}</div></div>
              </div>
              <div className="tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-gradient-to-br tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-5 tw-py-3.5 sm:tw-py-4 tw-ring-1 tw-ring-white/10 tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-300 hover:tw--translate-y-0.5">
                <div className="tw-absolute tw-inset-0 tw-opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
                <div className="tw-relative tw-z-10"><div className="tw-flex tw-items-center tw-gap-2 tw-mb-2"><div className="tw-h-8 tw-w-8 tw-rounded-xl tw-bg-amber-500/20 tw-flex tw-items-center tw-justify-center tw-ring-1 tw-ring-amber-400/20"><BoltIcon className="tw-h-4 tw-w-4 tw-text-amber-400" /></div><span className="tw-text-[10px] sm:tw-text-[11px] tw-font-semibold tw-text-white/40 tw-uppercase tw-tracking-wider">{lang === "th" ? "ตู้ชาร์จ" : "Chargers"}</span></div><div className="tw-text-2xl sm:tw-text-3xl tw-font-black tw-text-white tw-tabular-nums tw-tracking-tight tw-leading-none">{chargerCounts.total}</div></div>
              </div>
              <div onClick={() => setStatusFilter((prev) => (prev === "online" ? "all" : "online"))} className={`tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-gradient-to-br tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-5 tw-py-3.5 sm:tw-py-4 tw-ring-1 tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-300 hover:tw--translate-y-0.5 tw-cursor-pointer ${statusFilter === "online" ? "tw-ring-green-400 tw-scale-[1.02]" : "tw-ring-white/10"}`}>
                <div className="tw-absolute tw-inset-0 tw-opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
                <div className="tw-relative tw-z-10"><div className="tw-flex tw-items-center tw-gap-2 tw-mb-2"><div className="tw-h-8 tw-w-8 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-ring-1" style={{ background: 'rgba(16,185,129,0.15)', borderColor: 'rgba(16,185,129,0.25)' }}><span className="tw-relative tw-flex tw-h-2.5 tw-w-2.5"><span className="tw-animate-ping tw-absolute tw-inline-flex tw-h-full tw-w-full tw-rounded-full tw-opacity-75" style={{ background: '#34d399' }} /><span className="tw-relative tw-inline-flex tw-rounded-full tw-h-2.5 tw-w-2.5" style={{ background: '#34d399' }} /></span></div><span className="tw-text-[10px] sm:tw-text-[11px] tw-font-semibold tw-uppercase tw-tracking-wider" style={{ color: 'rgba(255,255,255,0.4)' }}>{lang === "th" ? "ออนไลน์" : "Online"}</span></div><div className="tw-text-2xl sm:tw-text-3xl tw-font-black tw-tabular-nums tw-tracking-tight tw-leading-none" style={{ color: '#34d399' }}>{chargerCounts.online}</div></div>
              </div>
              <div onClick={() => setStatusFilter((prev) => (prev === "offline" ? "all" : "offline"))} className={`tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-gradient-to-br tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-5 tw-py-3.5 sm:tw-py-4 tw-ring-1 tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-300 hover:tw--translate-y-0.5 tw-cursor-pointer ${statusFilter === "offline" ? "tw-ring-red-400 tw-scale-[1.02]" : "tw-ring-white/10"}`}>
                <div className="tw-absolute tw-inset-0 tw-opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
                <div className="tw-relative tw-z-10"><div className="tw-flex tw-items-center tw-gap-2 tw-mb-2"><div className="tw-h-8 tw-w-8 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-ring-1" style={{ background: 'rgba(239,68,68,0.15)', borderColor: 'rgba(239,68,68,0.25)' }}><span className="tw-h-2.5 tw-w-2.5 tw-rounded-full" style={{ background: '#f87171' }} /></div><span className="tw-text-[10px] sm:tw-text-[11px] tw-font-semibold tw-uppercase tw-tracking-wider" style={{ color: 'rgba(255,255,255,0.4)' }}>{lang === "th" ? "ออฟไลน์" : "Offline"}</span></div><div className="tw-text-2xl sm:tw-text-3xl tw-font-black tw-tabular-nums tw-tracking-tight tw-leading-none" style={{ color: '#f87171' }}>{chargerCounts.offline}</div></div>
              </div>
              <div onClick={() => setStatusFilter((prev) => (prev === "notConfigured" ? "all" : "notConfigured"))} className={`tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-gradient-to-br tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-5 tw-py-3.5 sm:tw-py-4 tw-ring-1 tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-300 hover:tw--translate-y-0.5 tw-cursor-pointer ${statusFilter === "notConfigured" ? "tw-ring-gray-300 tw-scale-[1.02]" : "tw-ring-white/10"}`}>
                <div className="tw-absolute tw-inset-0 tw-opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
                <div className="tw-relative tw-z-10"><div className="tw-flex tw-items-center tw-gap-2 tw-mb-2"><div className="tw-h-8 tw-w-8 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-ring-1" style={{ background: 'rgba(148,163,184,0.15)', borderColor: 'rgba(148,163,184,0.25)' }}><span className="tw-h-2.5 tw-w-2.5 tw-rounded-full" style={{ background: '#94a3b8' }} /></div><span className="tw-text-[10px] sm:tw-text-[11px] tw-font-semibold tw-uppercase tw-tracking-wider" style={{ color: 'rgba(255,255,255,0.4)' }}>{lang === "th" ? "ยังไม่ได้ตั้งค่า" : "Not Configured"}</span></div><div className="tw-text-2xl sm:tw-text-3xl tw-font-black tw-tabular-nums tw-tracking-tight tw-leading-none" style={{ color: '#94a3b8' }}>{chargerCounts.notConfigured}</div></div>
              </div>
            </>
          )}
        </div>
      </div>

      <Card className="tw-border tw-border-blue-gray-100 tw-shadow-sm tw-mt-4">
        {notice && (<div className="tw-px-4 tw-pt-4"><Alert color={notice.type === "success" ? "green" : "red"} onClose={() => setNotice(null)}>{notice.msg}</Alert></div>)}
        <CardHeader floated={false} shadow={false} className="tw-!px-4 sm:tw-!px-6 tw-!py-5 tw-bg-gradient-to-r tw-from-white tw-to-blue-gray-50/30 tw-rounded-t-xl">
          <div className="tw-flex tw-items-start tw-justify-between tw-gap-3">
            <div className="tw-min-w-0 tw-flex-1"><Typography color="blue-gray" variant="h5" className="tw-text-lg sm:tw-text-xl">{t.stationManagement}</Typography><Typography variant="small" className="!tw-text-blue-gray-500 !tw-font-normal tw-mt-1 tw-text-xs sm:tw-text-sm">{t.stationManagementDesc}</Typography></div>
            {(isAdmin || me?.role === "owner") && (<Button onClick={() => setOpenAdd(true)} size="sm" className="tw-flex tw-items-center tw-gap-2 tw-px-4 sm:tw-px-5 tw-py-2.5 tw-rounded-xl tw-bg-gray-900 hover:tw-bg-black tw-text-white tw-font-semibold tw-text-xs sm:tw-text-sm tw-shadow-lg tw-flex-shrink-0 tw-normal-case tw-tracking-wide"><span className="tw-text-base tw-leading-none">+</span><span className="tw-hidden sm:tw-inline">{t.addStation}</span><span className="tw-inline sm:tw-hidden">{t.add}</span></Button>)}
          </div>
        </CardHeader>
        <CardBody className="tw-flex tw-items-center tw-justify-between tw-gap-3 tw-px-4">
          <div className="tw-flex tw-items-center tw-gap-3 tw-flex-none"><select value={table.getState().pagination.pageSize} onChange={(e) => table.setPageSize(Number(e.target.value))} className="tw-border tw-p-2 tw-border-blue-gray-100 tw-rounded-lg tw-w-[72px]">{[5, 10, 15, 20, 25].map((ps) => (<option key={ps} value={ps}>{ps}</option>))}</select><Typography variant="small" className="!tw-text-blue-gray-500 !tw-font-normal tw-hidden sm:tw-inline">{t.entriesPerPage}</Typography></div>
          <div className="tw-ml-auto tw-min-w-0 tw-flex-1 md:tw-flex-none md:tw-w-64"><Input variant="outlined" value={filtering} onChange={(e) => setFiltering(e.target.value)} label={t.search} crossOrigin={undefined} /></div>
        </CardBody>
        <CardFooter className="tw-p-0">
          {loading ? (
            <div className="tw-overflow-x-auto tw-w-full">
              <table className="tw-w-full tw-border-separate tw-border-spacing-0 tw-min-w-[900px]">
                <thead className="tw-bg-gradient-to-r tw-from-gray-900 tw-to-gray-800"><tr>{["", "Station", "Chargers", "Available", "Owner", "Status", ""].map((h, i) => (<th key={i} className="tw-px-3 tw-py-3"><div className="tw-h-3 tw-rounded tw-bg-white/20 tw-animate-pulse" style={{ width: h ? `${h.length * 8}px` : 32 }} /></th>))}</tr></thead>
                <tbody><TableSkeletonRows rows={table.getState().pagination.pageSize} cols={7} /></tbody>
              </table>
            </div>
          ) : err ? (<div className="tw-p-4 tw-text-red-600">{err}</div>) : (
            <div className="tw-overflow-x-auto tw-w-full"><table className="tw-w-full tw-border-separate tw-border-spacing-0 tw-min-w-[900px]">
              <thead className="tw-bg-gradient-to-r tw-from-gray-900 tw-to-gray-800">{table.getHeaderGroups().map((hg) => (<tr key={hg.id}>{hg.headers.map((h) => (<th key={h.id} onClick={h.column.getCanSort() ? h.column.getToggleSortingHandler() : undefined} className="tw-px-3 tw-py-3 tw-uppercase !tw-text-blue-gray-500 !tw-font-medium tw-text-left tw-whitespace-nowrap"><Typography color="blue-gray" className={`tw-flex tw-items-center tw-gap-2 tw-text-[10px] !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white ${h.column.getCanSort() ? "tw-cursor-pointer" : ""}`}>{flexRender(h.column.columnDef.header, h.getContext())}{h.column.getCanSort() && <ChevronUpDownIcon strokeWidth={2} className="tw-h-4 tw-w-4 tw-text-white/60" />}</Typography></th>))}</tr>))}</thead>
              <tbody>{table.getRowModel().rows.length ? (table.getRowModel().rows.map((row) => { const hasChargers = row.original.chargers.length > 0; const canEdit = isAdmin || row.original.user_id === me?.user_id; const canExpand = hasChargers || canEdit; return (<Fragment key={row.id}><tr onClick={() => canExpand && row.toggleExpanded()} className={`tw-transition-colors ${canExpand ? "tw-cursor-pointer" : ""} ${row.getIsExpanded() ? "tw-bg-blue-50/60 tw-shadow-sm" : "odd:tw-bg-white even:tw-bg-blue-gray-50/30 hover:tw-bg-blue-50/40 hover:tw-shadow-[inset_3px_0_0_0_#2196F3]"}`}>{row.getVisibleCells().map((cell) => (<td key={cell.id} className="!tw-border-y !tw-border-x-0 tw-px-3 tw-py-3"><Typography as="div" variant="small" className="!tw-font-normal !tw-text-blue-gray-600">{flexRender(cell.column.columnDef.cell, cell.getContext())}</Typography></td>))}</tr>{row.getIsExpanded() && (<ChargersExpandedSection chargers={row.original.chargers} stationId={row.original.station_id} canEdit={canEdit} />)}</Fragment>); })) : (<tr><td className="tw-px-4 tw-py-6 tw-text-center" colSpan={columns.length}>{t.noStationsFound}</td></tr>)}</tbody>
            </table></div>
          )}
        </CardFooter>
        <div className="tw-flex tw-items-center tw-justify-between tw-px-6 tw-py-4 tw-border-t tw-border-blue-gray-100">
          <Typography variant="small" className="!tw-text-blue-gray-400">{filteredDataByStatus.length} {t.stationName}</Typography>
          <div className="tw-flex tw-items-center tw-gap-4">
            <span className="tw-text-sm tw-text-blue-gray-600">{t.page} <strong>{table.getState().pagination.pageIndex + 1}</strong> {t.of} <strong>{table.getPageCount()}</strong></span>
            <div className="tw-flex tw-items-center tw-gap-1">
              <Button variant="outlined" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} className="disabled:tw-opacity-30 tw-py-1.5 tw-px-2 tw-rounded-lg tw-border-blue-gray-200"><ChevronLeftIcon className="tw-w-4 tw-h-4 tw-stroke-blue-gray-600 tw-stroke-2" /></Button>
              <Button variant="outlined" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} className="disabled:tw-opacity-30 tw-py-1.5 tw-px-2 tw-rounded-lg tw-border-blue-gray-200"><ChevronRightIcon className="tw-w-4 tw-h-4 tw-stroke-blue-gray-600 tw-stroke-2" /></Button>
            </div>
          </div>
        </div>
      </Card>

      <AddStation open={openAdd} onClose={() => setOpenAdd(false)} onSubmit={handleCreateStation} onSubmitImages={handleSubmitImages} loading={saving} currentUser={me?.username ?? ""} isAdmin={isAdmin} allOwners={owners.map(owner => owner.name)} />

      {/* ========== Edit Station Modal ========== */}
      <Dialog open={openEditStation} handler={() => setOpenEditStation(false)} size="lg" dismiss={{ outsidePress: !saving, escapeKey: !saving }} className="tw-flex tw-flex-col tw-max-h-[95vh] sm:tw-max-h-[90vh] tw-overflow-hidden !tw-rounded-xl sm:!tw-rounded-2xl !tw-m-2 sm:!tw-m-4">
        <DialogHeader className="tw-sticky tw-top-0 tw-z-10 tw-bg-gradient-to-r tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-6 tw-py-3.5 sm:tw-py-5 tw-border-0 tw-shadow-xl tw-shrink-0">
          <div className="tw-flex tw-items-center tw-justify-between tw-w-full">
            <Typography variant="h5" className="!tw-text-white !tw-font-bold !tw-tracking-tight !tw-leading-tight !tw-text-base sm:!tw-text-lg">{t.editStation}</Typography>
            <button type="button" onClick={() => setOpenEditStation(false)} className="tw-p-1.5 sm:tw-p-2 tw-rounded-xl tw-bg-white/10 hover:tw-bg-white/20 tw-text-white/60 hover:tw-text-white tw-transition-all tw-duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" className="tw-h-5 tw-w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
            </button>
          </div>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); handleUpdateStation(); }} className="tw-flex tw-flex-col tw-min-h-0">
          <DialogBody className="tw-flex-1 tw-min-h-0 tw-overflow-y-auto tw-space-y-3 sm:tw-space-y-5 tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-5 tw-bg-gray-50/60">
            <section className="tw-rounded-xl sm:tw-rounded-2xl tw-bg-white tw-shadow-sm tw-ring-1 tw-ring-black/[.06] tw-overflow-hidden">
              <div className="tw-px-3.5 sm:tw-px-5 tw-py-3 sm:tw-py-4 tw-border-b tw-border-gray-100 tw-flex tw-items-center tw-gap-2.5 sm:tw-gap-3">
                <SectionIcon emoji="📍" />
                <Typography variant="h6" className="!tw-text-gray-800 !tw-font-bold !tw-tracking-tight !tw-text-sm sm:!tw-text-base">{t.stationInfo}</Typography>
              </div>
              <div className="tw-p-3.5 sm:tw-p-5 tw-space-y-4 sm:tw-space-y-5">
                <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-3 sm:tw-gap-4">
                  <MaximoLocationSelect
                    label={t.maximoLocation}
                    value={editStationForm.maximo_location}
                    options={stationLocations}
                    loading={maximoLoading}
                    disabled={false}
                    searchPlaceholder={t.maximoSearch}
                    emptyLabel={t.maximoEmpty}
                    onSelect={(loc, desc) => setEditStationForm(s => ({ ...s, maximo_location: loc, maximo_desc: desc, station_name: desc || loc }))}
                  />
                  {editStationForm.maximo_location?.trim() && (
                    <Input label={t.maximoDescription} value={editStationForm.maximo_desc} readOnly disabled crossOrigin={undefined} />
                  )}
                  {isAdmin && (
                    <Input
                      label="Station ID"
                      value={editingStation?.station_id ?? "-"}
                      readOnly
                      disabled
                      className="!tw-bg-gray-50"
                      crossOrigin={undefined}
                    />
                  )}
                  {!editStationForm.maximo_location?.trim() && (
                    <Input label={t.stationName} required value={editStationForm.station_name} onChange={(e) => setEditStationForm(s => ({ ...s, station_name: e.target.value }))} crossOrigin={undefined} />
                  )}
                  {isAdmin ? (
                    <div className="tw-relative tw-w-full tw-min-w-[200px] tw-h-10">
                        <select
                          required
                          value={selectedOwnerName}
                          onChange={(e) => setSelectedOwnerName(e.target.value)}
                          className="tw-peer tw-w-full tw-h-full tw-bg-transparent tw-text-blue-gray-700 tw-font-sans tw-font-normal tw-outline-none tw-border tw-border-blue-gray-200 focus:tw-border-2 focus:tw-border-gray-900 tw-rounded-[7px] tw-px-3 tw-py-2.5 tw-text-sm tw-appearance-none tw-cursor-pointer"
                        >
                          <option value="" disabled>{lang === "th" ? "เลือก Owner จาก Company Profile" : "Select Owner from Company Profile"}</option>
                          {owners.length > 0
                            ? owners.map(o => <option key={o.id} value={o.name}>{o.name}</option>)
                            : <option value="" disabled>{t.loading}</option>
                          }
                        </select>
                        <div className="tw-pointer-events-none tw-absolute tw-inset-y-0 tw-right-3 tw-flex tw-items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="tw-h-4 tw-w-4 tw-text-blue-gray-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <label className="tw-pointer-events-none tw-absolute tw-left-3 tw--top-1.5 tw-text-[11px] tw-text-blue-gray-400 tw-bg-white tw-px-1 tw-font-normal">
                          {t.owner}
                        </label>
                    </div>
                  ) : (
                    <Input label={t.owner} value={editingStation?.username ?? "-"} readOnly disabled crossOrigin={undefined} />
                  )}
                  <Select label={t.status} value={String(editStationForm.is_active)} onChange={(v) => setEditStationForm(s => ({ ...s, is_active: v === "true" }))}>
                    <Option value="true">{t.active}</Option>
                    <Option value="false">{t.inactive}</Option>
                  </Select>
                  <Select label={t.warrantyStatus} value={editStationForm.warranty_status} onChange={(v) => setEditStationForm(s => ({ ...s, warranty_status: v ?? "" }))}>
                    {WARRANTY_STATUS_OPTIONS.map((o) => (
                      <Option key={o.value} value={o.value}>{o[lang]}</Option>
                    ))}
                  </Select>
                  <MultiSelectDropdown
                    label={t.investmentScope}
                    options={INVESTMENT_SCOPE_OPTIONS}
                    selected={editStationForm.investment_scope}
                    onChange={(next) => setEditStationForm(s => ({ ...s, investment_scope: next }))}
                    lang={lang}
                    emptyLabel={t.selectPlaceholder}
                  />
                  <Input label={t.ioCode} value={editStationForm.io_code} onChange={(e) => setEditStationForm(s => ({ ...s, io_code: e.target.value }))} crossOrigin={undefined} />
                  <LatLngInput value={editStationForm.coords} onChange={(v) => setEditStationForm(s => ({ ...s, coords: v }))} lang={lang} />
                </div>

                {/* ✅ Station Images — grid-cols-2 เหมือน AddStation */}
                <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                  <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">📷 {t.stationImages}</p>
                  <div className="tw-grid tw-grid-cols-1 tw-gap-2.5 sm:tw-grid-cols-2 sm:tw-gap-3">
                    {/* Station Image */}
                    <div className="tw-space-y-2">
                      <ImageZone
                        label={t.stationImage}
                        previews={editStationPreviews}
                        onUpload={pickStationImage}
                        onRemove={removeEditStationImage}
                        emptyLabel={t.noImages}
                        uploadLabel={t.upload}
                        currentLabel={t.currentImageBadge}
                        existingImages={editingStation?.stationImage && !deleteCurrentImage ? [editingStation.stationImage] : undefined}
                        apiBase={API_BASE}
                        onRemoveExisting={() => setDeleteCurrentImage(true)}
                      />
                      {deleteCurrentImage && editingStation?.stationImage && (
                        <div className="tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-2 tw-rounded-lg tw-bg-red-50 tw-ring-1 tw-ring-red-200/60">
                          <TrashIcon className="tw-h-4 tw-w-4 tw-text-red-500" />
                          <span className="tw-text-[11px] tw-text-red-600 tw-font-medium">{t.willBeDeleted}</span>
                          <button type="button" onClick={() => setDeleteCurrentImage(false)} className="tw-ml-auto tw-text-[11px] tw-text-blue-600 tw-font-semibold hover:tw-underline">{t.undo}</button>
                        </div>
                      )}
                    </div>
                    {/* ✅ MDB Image Zone */}
                    <ImageZone
                      label={t.mdbImage}
                      previews={editMdbPreviews}
                      onUpload={pickMdbImage}
                      onRemove={removeEditMdbImage}
                      emptyLabel={t.noImages}
                      uploadLabel={t.upload}
                      currentLabel={t.currentImageBadge}
                      existingImages={editingStation?.mdbImages?.filter((_, i) => !deletedExistingMdbIdxs.has(i))}
                      apiBase={API_BASE}
                      onRemoveExisting={(filteredIdx) => {        // ← เพิ่ม
                        const remaining = (editingStation?.mdbImages || [])
                          .map((url, i) => ({ url, i }))
                          .filter(({ i }) => !deletedExistingMdbIdxs.has(i));
                        if (remaining[filteredIdx]) {
                          setDeletedExistingMdbIdxs(prev => {
                            const next = new Set(Array.from(prev));
                            next.add(remaining[filteredIdx].i);
                            return next;
                          });
                        }
                      }}
                    />
                  </div>
                </div>
              </div>
            </section>
          </DialogBody>

          <DialogFooter className="tw-sticky tw-bottom-0 tw-z-10 tw-bg-white tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-4 tw-border-t tw-border-gray-200/80 tw-shrink-0">
            <div className="tw-flex tw-w-full tw-flex-col sm:tw-flex-row tw-justify-end tw-items-center tw-gap-2.5 sm:tw-gap-0">
              <div className="tw-flex tw-gap-2 sm:tw-gap-2.5 tw-w-full sm:tw-w-auto">
                <Button variant="outlined" type="button" onClick={() => setOpenEditStation(false)} className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-border-gray-300 tw-text-gray-600 hover:tw-bg-gray-50 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-px-4 sm:tw-px-5 tw-py-2.5 sm:tw-py-2">{t.cancel}</Button>
                <Button type="submit" disabled={saving} className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-bg-gray-900 hover:tw-bg-black tw-shadow-lg tw-shadow-gray-900/20 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-tracking-wide tw-px-4 sm:tw-px-6 tw-py-2.5 sm:tw-py-2 disabled:tw-opacity-50 tw-transition-all tw-duration-200 hover:tw-shadow-xl">{saving ? <span className="tw-flex tw-items-center tw-justify-center tw-gap-2"><Spinner />{t.saving}</span> : t.save}</Button>
              </div>
            </div>
          </DialogFooter>
        </form>
      </Dialog>

      {/* ========== Edit Charger Modal ========== */}
      <Dialog open={openEditCharger} handler={() => setOpenEditCharger(false)} size="lg" dismiss={{ outsidePress: !saving, escapeKey: !saving }} className="tw-flex tw-flex-col tw-max-h-[95vh] sm:tw-max-h-[90vh] tw-overflow-hidden !tw-rounded-xl sm:!tw-rounded-2xl !tw-m-2 sm:!tw-m-4">
        <DialogHeader className="tw-sticky tw-top-0 tw-z-10 tw-bg-gradient-to-r tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-6 tw-py-3.5 sm:tw-py-5 tw-border-0 tw-shadow-xl tw-shrink-0">
          <div className="tw-flex tw-items-center tw-justify-between tw-w-full">
            <Typography variant="h5" className="!tw-text-white !tw-font-bold !tw-tracking-tight !tw-leading-tight !tw-text-base sm:!tw-text-lg">{t.editCharger}</Typography>
            <button type="button" onClick={() => setOpenEditCharger(false)} className="tw-p-1.5 sm:tw-p-2 tw-rounded-xl tw-bg-white/10 hover:tw-bg-white/20 tw-text-white/60 hover:tw-text-white tw-transition-all tw-duration-200"><svg xmlns="http://www.w3.org/2000/svg" className="tw-h-5 tw-w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg></button>
          </div>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); handleUpdateCharger(); }} className="tw-flex tw-flex-col tw-min-h-0">
          <DialogBody className="tw-flex-1 tw-min-h-0 tw-overflow-y-auto tw-space-y-3 sm:tw-space-y-5 tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-5 tw-bg-gray-50/60">
            <section className="tw-rounded-xl sm:tw-rounded-2xl tw-bg-white tw-shadow-sm tw-ring-1 tw-ring-black/[.06] tw-overflow-hidden">
              <div className="tw-flex tw-items-center tw-justify-between tw-px-3.5 sm:tw-px-5 tw-py-2.5 sm:tw-py-3 tw-bg-gradient-to-r tw-from-amber-50 tw-to-orange-50/80 tw-border-b tw-border-amber-100/70">
                <div className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-2.5 tw-min-w-0">
                  <span className="tw-inline-flex tw-items-center tw-justify-center tw-h-6 tw-w-6 sm:tw-h-7 sm:tw-w-7 tw-rounded-lg tw-bg-gradient-to-br tw-from-amber-400 tw-to-orange-500 tw-shadow tw-text-white tw-text-[10px] sm:tw-text-xs tw-font-bold tw-shrink-0">{editChargerForm.chargerNo}</span>
                  <span className="tw-text-xs sm:tw-text-sm tw-font-bold tw-text-gray-700 tw-truncate">{t.chargerNo} {editChargerForm.chargerNo}</span>
                  {editChargerForm.brand && (<span className="tw-hidden sm:tw-inline tw-px-2 tw-py-0.5 tw-rounded-md tw-bg-white/90 tw-text-[10px] tw-font-semibold tw-text-blue-gray-500 tw-ring-1 tw-ring-black/5 tw-shadow-sm tw-truncate tw-max-w-[120px]">{editChargerForm.brand}{editChargerForm.model ? ` ${editChargerForm.model}` : ""}</span>)}
                </div>
              </div>
              <div className="tw-p-3.5 sm:tw-p-5 tw-space-y-3 sm:tw-space-y-4">
                <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-2.5 sm:tw-gap-3">
                  {editChargerStationMaximo && (
                    <MaximoLocationSelect
                      label={t.maximoLocation}
                      value={editChargerForm.maximo_location}
                      options={editChargerOptions}
                      loading={maximoLoading}
                      disabled={false}
                      searchPlaceholder={t.maximoSearch}
                      emptyLabel={t.maximoEmpty}
                      onSelect={(loc, desc) => setEditChargerForm(s => ({ ...s, maximo_location: loc, maximo_desc: desc }))}
                    />
                  )}
                  {editChargerStationMaximo && editChargerForm.maximo_location?.trim() && (
                    <Input label={t.maximoDescription} value={editChargerForm.maximo_desc} readOnly disabled crossOrigin={undefined} />
                  )}
                  <div className="tw-relative"><Input label={`${t.chargerNo} (${t.auto})`} type="number" value={editChargerForm.chargerNo} readOnly className="!tw-bg-gray-50" crossOrigin={undefined} /><span className="tw-absolute tw-right-3 tw-top-1/2 tw--translate-y-1/2 tw-text-[9px] tw-text-blue-gray-300 tw-font-medium">({t.auto})</span></div>
                  <Select label={t.chargerType} value={editChargerForm.chargerType} onChange={(v) => setEditChargerForm(s => ({ ...s, chargerType: v ?? "DC" }))}><Option value="DC">DC</Option><Option value="AC">AC</Option><Option value="DC & AC">DC & AC</Option></Select>
                   <Input label={t.brand} required value={editChargerForm.brand} onChange={(e) => setEditChargerForm(s => ({ ...s, brand: e.target.value }))} crossOrigin={undefined} />
                   <VendorSelect label={t.vendor} value={editChargerForm.vendor} onChange={(v) => setEditChargerForm(s => ({ ...s, vendor: v }))} lang={lang} />
                   <Input label={t.model} required value={editChargerForm.model} onChange={(e) => setEditChargerForm(s => ({ ...s, model: e.target.value }))} crossOrigin={undefined} />
                  <Input label={t.serialNumber} required value={editChargerForm.SN} onChange={(e) => setEditChargerForm(s => ({ ...s, SN: e.target.value }))} crossOrigin={undefined} />
                  <Input label={`${t.power} (kW)`} required value={editChargerForm.power} onChange={(e) => setEditChargerForm(s => ({ ...s, power: e.target.value }))} crossOrigin={undefined} />
                  {isFlexxfast(editChargerForm.brand) && (<>
                    <Input label={t.workOrder} value={editChargerForm.WO} onChange={(e) => setEditChargerForm(s => ({ ...s, WO: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.plcFirmware} required value={editChargerForm.PLCFirmware} onChange={(e) => setEditChargerForm(s => ({ ...s, PLCFirmware: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.piFirmware} required value={editChargerForm.PIFirmware} onChange={(e) => setEditChargerForm(s => ({ ...s, PIFirmware: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.routerFirmware} required value={editChargerForm.RTFirmware} onChange={(e) => setEditChargerForm(s => ({ ...s, RTFirmware: e.target.value }))} crossOrigin={undefined} />
                  </>)}
                  <Input label={t.commissioningDate} type="date" value={editChargerForm.commissioningDate} onChange={(e) => setEditChargerForm(s => ({ ...s, commissioningDate: e.target.value }))} crossOrigin={undefined} />
                  <Input label={t.warrantyYears} type="number" min={1} max={10} value={editChargerForm.warrantyYears} onChange={(e) => setEditChargerForm(s => ({ ...s, warrantyYears: parseInt(e.target.value) || 1 }))} crossOrigin={undefined} />
                  <Input label={t.numberOfCables} type="number" min={1} max={10} value={editChargerForm.numberOfCables} onChange={(e) => setEditChargerForm(s => ({ ...s, numberOfCables: parseInt(e.target.value) || 1 }))} crossOrigin={undefined} />
                  <Select label={t.status} value={String(editChargerForm.is_active)} onChange={(v) => setEditChargerForm(s => ({ ...s, is_active: v === "true" }))}><Option value="true">{t.active}</Option><Option value="false">{t.inactive}</Option></Select>
                </div>
                {isFlexxfast(editChargerForm.brand) && (
                  <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                    <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-purple-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">{t.ocppSection}</p>
                    <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-2.5 sm:tw-gap-3">
                      <Input label={t.chargerBoxId} required value={editChargerForm.chargeBoxID} onChange={(e) => setEditChargerForm(s => ({ ...s, chargeBoxID: e.target.value }))} crossOrigin={undefined} />
                      <Input label={t.ocppUrl} value={editChargerForm.ocppUrl} onChange={(e) => setEditChargerForm(s => ({ ...s, ocppUrl: e.target.value }))} crossOrigin={undefined} />
                    </div>
                  </div>
                )}
                <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                  <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">📷 {t.chargerImages}</p>
                  <div className="tw-grid tw-grid-cols-1 tw-gap-2.5 sm:tw-grid-cols-2 sm:tw-gap-3">
                    <div className="tw-space-y-2">
                      <ImageZone label={t.chargerImage} previews={editChargerPreviews} onUpload={pickChargerImage} onRemove={removeEditChargerImage} emptyLabel={t.noImages} uploadLabel={t.upload} currentLabel={t.currentImageBadge} existingImages={editingCharger?.charger.chargerImages?.filter((_, i) => !deletedExistingChargerIdxs.has(i))} apiBase={API_BASE} onRemoveExisting={(filteredIdx) => { const remaining = (editingCharger?.charger.chargerImages || []).map((url, i) => ({ url, i })).filter(({ i }) => !deletedExistingChargerIdxs.has(i)); if (remaining[filteredIdx]) { setDeletedExistingChargerIdxs(prev => { const next = new Set(Array.from(prev)); next.add(remaining[filteredIdx].i); return next; }); } }} />
                      {deletedExistingChargerIdxs.size > 0 && (<div className="tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-2 tw-rounded-lg tw-bg-red-50 tw-ring-1 tw-ring-red-200/60"><TrashIcon className="tw-h-4 tw-w-4 tw-text-red-500" /><span className="tw-text-[11px] tw-text-red-600 tw-font-medium">{deletedExistingChargerIdxs.size} {t.willBeDeleted}</span><button type="button" onClick={() => setDeletedExistingChargerIdxs(new Set())} className="tw-ml-auto tw-text-[11px] tw-text-blue-600 tw-font-semibold hover:tw-underline">{t.undo}</button></div>)}
                    </div>
                    <div className="tw-space-y-2">
                      <ImageZone label={t.deviceImage} previews={editDevicePreviews} onUpload={pickDeviceImage} onRemove={removeEditDeviceImage} emptyLabel={t.noImages} uploadLabel={t.upload} currentLabel={t.currentImageBadge} existingImages={editingCharger?.charger.deviceImages?.filter((_, i) => !deletedExistingDeviceIdxs.has(i))} apiBase={API_BASE} onRemoveExisting={(filteredIdx) => { const remaining = (editingCharger?.charger.deviceImages || []).map((url, i) => ({ url, i })).filter(({ i }) => !deletedExistingDeviceIdxs.has(i)); if (remaining[filteredIdx]) { setDeletedExistingDeviceIdxs(prev => { const next = new Set(Array.from(prev)); next.add(remaining[filteredIdx].i); return next; }); } }} />
                      {deletedExistingDeviceIdxs.size > 0 && (<div className="tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-2 tw-rounded-lg tw-bg-red-50 tw-ring-1 tw-ring-red-200/60"><TrashIcon className="tw-h-4 tw-w-4 tw-text-red-500" /><span className="tw-text-[11px] tw-text-red-600 tw-font-medium">{deletedExistingDeviceIdxs.size} {t.willBeDeleted}</span><button type="button" onClick={() => setDeletedExistingDeviceIdxs(new Set())} className="tw-ml-auto tw-text-[11px] tw-text-blue-600 tw-font-semibold hover:tw-underline">{t.undo}</button></div>)}
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </DialogBody>
          <DialogFooter className="tw-sticky tw-bottom-0 tw-z-10 tw-bg-white tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-4 tw-border-t tw-border-gray-200/80 tw-shrink-0">
            <div className="tw-flex tw-w-full tw-flex-col sm:tw-flex-row tw-justify-end tw-items-center tw-gap-2.5 sm:tw-gap-0">
              <div className="tw-flex tw-gap-2 sm:tw-gap-2.5 tw-w-full sm:tw-w-auto">
                <Button variant="outlined" type="button" onClick={() => setOpenEditCharger(false)} className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-border-gray-300 tw-text-gray-600 hover:tw-bg-gray-50 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-px-4 sm:tw-px-5 tw-py-2.5 sm:tw-py-2">{t.cancel}</Button>
                <Button type="submit" disabled={saving} className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-bg-gray-900 hover:tw-bg-black tw-shadow-lg tw-shadow-gray-900/20 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-tracking-wide tw-px-4 sm:tw-px-6 tw-py-2.5 sm:tw-py-2 disabled:tw-opacity-50 tw-transition-all tw-duration-200 hover:tw-shadow-xl">{saving ? <span className="tw-flex tw-items-center tw-justify-center tw-gap-2"><Spinner />{t.saving}</span> : t.save}</Button>
              </div>
            </div>
          </DialogFooter>
        </form>
      </Dialog>

      {/* ========== Add Charger Modal ========== */}
      <Dialog open={openAddCharger} handler={() => { resetAddChargerImages(); setOpenAddCharger(false); }} size="lg" dismiss={{ outsidePress: !saving, escapeKey: !saving }} className="tw-flex tw-flex-col tw-max-h-[95vh] sm:tw-max-h-[90vh] tw-overflow-hidden !tw-rounded-xl sm:!tw-rounded-2xl !tw-m-2 sm:!tw-m-4">
        <DialogHeader className="tw-sticky tw-top-0 tw-z-10 tw-bg-gradient-to-r tw-from-gray-900 tw-via-gray-800 tw-to-gray-900 tw-px-4 sm:tw-px-6 tw-py-3.5 sm:tw-py-5 tw-border-0 tw-shadow-xl tw-shrink-0">
          <div className="tw-flex tw-items-center tw-justify-between tw-w-full">
            <div><Typography variant="h5" className="!tw-text-white !tw-font-bold !tw-tracking-tight !tw-leading-tight !tw-text-base sm:!tw-text-lg">{t.addChargerTitle}</Typography><Typography variant="small" className="!tw-text-white/50 !tw-text-xs">{t.station}: {addingChargerStationId}</Typography></div>
            <button type="button" onClick={() => { resetAddChargerImages(); setOpenAddCharger(false); }} className="tw-p-1.5 sm:tw-p-2 tw-rounded-xl tw-bg-white/10 hover:tw-bg-white/20 tw-text-white/60 hover:tw-text-white tw-transition-all tw-duration-200"><svg xmlns="http://www.w3.org/2000/svg" className="tw-h-5 tw-w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg></button>
          </div>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); handleCreateCharger(); }} className="tw-flex tw-flex-col tw-min-h-0">
          <DialogBody className="tw-flex-1 tw-min-h-0 tw-overflow-y-auto tw-space-y-3 sm:tw-space-y-5 tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-5 tw-bg-gray-50/60">
            <section className="tw-rounded-xl sm:tw-rounded-2xl tw-bg-white tw-shadow-sm tw-ring-1 tw-ring-black/[.06] tw-overflow-hidden">
              <div className="tw-flex tw-items-center tw-justify-between tw-px-3.5 sm:tw-px-5 tw-py-2.5 sm:tw-py-3 tw-bg-gradient-to-r tw-from-amber-50 tw-to-orange-50/80 tw-border-b tw-border-amber-100/70">
                <div className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-2.5 tw-min-w-0">
                  <span className="tw-inline-flex tw-items-center tw-justify-center tw-h-6 tw-w-6 sm:tw-h-7 sm:tw-w-7 tw-rounded-lg tw-bg-gradient-to-br tw-from-amber-400 tw-to-orange-500 tw-shadow tw-text-white tw-text-[10px] sm:tw-text-xs tw-font-bold tw-shrink-0">{addChargerForm.chargerNo}</span>
                  <span className="tw-text-xs sm:tw-text-sm tw-font-bold tw-text-gray-700 tw-truncate">{t.chargerNo} {addChargerForm.chargerNo}</span>
                </div>
              </div>
              <div className="tw-p-3.5 sm:tw-p-5 tw-space-y-3 sm:tw-space-y-4">
                <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-2.5 sm:tw-gap-3">
                  {addChargerStationMaximo && (
                    <MaximoLocationSelect
                      label={t.maximoLocation}
                      value={addChargerForm.maximo_location}
                      options={addChargerOptions}
                      loading={maximoLoading}
                      disabled={false}
                      searchPlaceholder={t.maximoSearch}
                      emptyLabel={t.maximoEmpty}
                      onSelect={(loc, desc) => setAddChargerForm(s => ({ ...s, maximo_location: loc, maximo_desc: desc }))}
                    />
                  )}
                  {addChargerStationMaximo && addChargerForm.maximo_location?.trim() && (
                    <Input label={t.maximoDescription} value={addChargerForm.maximo_desc} readOnly disabled crossOrigin={undefined} />
                  )}
                  <div className="tw-relative"><Input label={`${t.chargerNo} (${t.auto})`} type="number" value={addChargerForm.chargerNo} readOnly className="!tw-bg-gray-50 !tw-cursor-not-allowed" crossOrigin={undefined} /><span className="tw-absolute tw-right-3 tw-top-1/2 tw--translate-y-1/2 tw-text-[9px] tw-text-blue-gray-300 tw-font-medium">({t.auto})</span></div>
                  <Select label={t.chargerType} value={addChargerForm.chargerType} onChange={(v) => setAddChargerForm(s => ({ ...s, chargerType: v ?? "DC" }))}><Option value="DC">DC</Option><Option value="AC">AC</Option></Select>
                   <Input label={t.brand} required value={addChargerForm.brand} onChange={(e) => setAddChargerForm(s => ({ ...s, brand: e.target.value }))} crossOrigin={undefined} />
                   <VendorSelect label={t.vendor} value={addChargerForm.vendor} onChange={(v) => setAddChargerForm(s => ({ ...s, vendor: v }))} lang={lang} />
                   <Input label={t.model} required value={addChargerForm.model} onChange={(e) => setAddChargerForm(s => ({ ...s, model: e.target.value }))} crossOrigin={undefined} />
                  <Input label={t.serialNumber} required value={addChargerForm.SN} onChange={(e) => setAddChargerForm(s => ({ ...s, SN: e.target.value }))} crossOrigin={undefined} />
                  <Input label={`${t.power} (kW)`} required value={addChargerForm.power} onChange={(e) => setAddChargerForm(s => ({ ...s, power: e.target.value }))} crossOrigin={undefined} />
                  {isFlexxfast(addChargerForm.brand) && (<>
                    <Input label={t.workOrder} value={addChargerForm.WO} onChange={(e) => setAddChargerForm(s => ({ ...s, WO: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.plcFirmware} required value={addChargerForm.PLCFirmware} onChange={(e) => setAddChargerForm(s => ({ ...s, PLCFirmware: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.piFirmware} required value={addChargerForm.PIFirmware} onChange={(e) => setAddChargerForm(s => ({ ...s, PIFirmware: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.routerFirmware} required value={addChargerForm.RTFirmware} onChange={(e) => setAddChargerForm(s => ({ ...s, RTFirmware: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.chargerBoxId} required value={addChargerForm.chargeBoxID} onChange={(e) => setAddChargerForm(s => ({ ...s, chargeBoxID: e.target.value }))} crossOrigin={undefined} />
                    <Input label={t.ocppUrl} value={addChargerForm.ocppUrl} onChange={(e) => setAddChargerForm(s => ({ ...s, ocppUrl: e.target.value }))} crossOrigin={undefined} />
                  </>)}
                  <Input label={t.commissioningDate} type="date" required value={addChargerForm.commissioningDate} onChange={(e) => setAddChargerForm(s => ({ ...s, commissioningDate: e.target.value }))} crossOrigin={undefined} />
                  <Input label={t.warrantyYears} type="number" min={1} max={10} required value={addChargerForm.warrantyYears} onChange={(e) => setAddChargerForm(s => ({ ...s, warrantyYears: parseInt(e.target.value) || 1 }))} crossOrigin={undefined} />
                  <Input label={t.numberOfCables} type="number" min={1} max={10} required value={addChargerForm.numberOfCables} onChange={(e) => setAddChargerForm(s => ({ ...s, numberOfCables: parseInt(e.target.value) || 1 }))} crossOrigin={undefined} />
                  <Select label={t.status} value={String(addChargerForm.is_active)} onChange={(v) => setAddChargerForm(s => ({ ...s, is_active: v === "true" }))}><Option value="true">{t.active}</Option><Option value="false">{t.inactive}</Option></Select>
                </div>
                {isFlexxfast(addChargerForm.brand) && (
                  <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                    <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-purple-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">{t.ocppSection}</p>
                    <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-2.5 sm:tw-gap-3">
                      <Input label={t.chargerBoxId} required value={addChargerForm.chargeBoxID} onChange={(e) => setAddChargerForm(s => ({ ...s, chargeBoxID: e.target.value }))} crossOrigin={undefined} />
                      <Input label={t.ocppUrl} value={addChargerForm.ocppUrl} onChange={(e) => setAddChargerForm(s => ({ ...s, ocppUrl: e.target.value }))} crossOrigin={undefined} />
                    </div>
                  </div>
                )}
                <div className="tw-pt-3 sm:tw-pt-4 tw-border-t tw-border-gray-100">
                  <p className="tw-text-[10px] sm:tw-text-[11px] tw-font-bold tw-text-blue-gray-500 tw-uppercase tw-tracking-widest tw-mb-2.5 sm:tw-mb-3">📷 {t.chargerImages}</p>
                  <div className="tw-grid tw-grid-cols-1 tw-gap-2.5 sm:tw-grid-cols-2 sm:tw-gap-3">
                    <ImageZone label={t.chargerImage} previews={addChargerPreviews} onUpload={pickAddChargerImage} onRemove={removeAddChargerImage} emptyLabel={t.noImages} uploadLabel={t.upload} />
                    <ImageZone label={t.deviceImage} previews={addDevicePreviews} onUpload={pickAddDeviceImage} onRemove={removeAddDeviceImage} emptyLabel={t.noImages} uploadLabel={t.upload} />
                  </div>
                </div>
              </div>
            </section>
          </DialogBody>
          <DialogFooter className="tw-sticky tw-bottom-0 tw-z-10 tw-bg-white tw-px-3 sm:tw-px-6 tw-py-3 sm:tw-py-4 tw-border-t tw-border-gray-200/80 tw-shrink-0">
            <div className="tw-flex tw-w-full tw-flex-col sm:tw-flex-row tw-justify-end tw-items-center tw-gap-2.5 sm:tw-gap-0">
              <div className="tw-flex tw-gap-2 sm:tw-gap-2.5 tw-w-full sm:tw-w-auto">
                <Button variant="outlined" type="button" onClick={() => { resetAddChargerImages(); setOpenAddCharger(false); }} className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-border-gray-300 tw-text-gray-600 hover:tw-bg-gray-50 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-px-4 sm:tw-px-5 tw-py-2.5 sm:tw-py-2">{t.cancel}</Button>
                <Button type="submit" disabled={saving} className="tw-flex-1 sm:tw-flex-none tw-rounded-xl tw-bg-gray-900 hover:tw-bg-black tw-shadow-lg tw-shadow-gray-900/20 tw-normal-case tw-font-semibold tw-text-xs sm:tw-text-sm tw-tracking-wide tw-px-4 sm:tw-px-6 tw-py-2.5 sm:tw-py-2 disabled:tw-opacity-50 tw-transition-all tw-duration-200 hover:tw-shadow-xl">{saving ? <span className="tw-flex tw-items-center tw-justify-center tw-gap-2"><Spinner />{t.creating}</span> : t.create}</Button>
              </div>
            </div>
          </DialogFooter>
        </form>
      </Dialog>

      <ConfirmDialog
        open={confirmDialog.open} onClose={closeConfirm} onConfirm={confirmDialog.onConfirm}
        title={confirmDialog.title} message={confirmDialog.message}
        confirmLabel={lang === "th" ? "ลบ" : "Delete"} cancelLabel={lang === "th" ? "ยกเลิก" : "Cancel"}
        variant="danger" loading={confirmDialog.loading}
      />
    </>
  );
}

export default SearchDataTables;
