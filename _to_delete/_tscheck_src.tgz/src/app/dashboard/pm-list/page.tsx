"use client";

/**
 * PM List — ตารางใบงาน PM รวมทุกสถานี (มาแทนหน้า "PM report (All)" เดิม)
 *
 * ใช้แพทเทิร์นเดียวกับ /dashboard/cm-list ทั้งหมด:
 *   header + ตัวกรอง ปี/เดือน/สัปดาห์ → toolbar สถานี/ชนิด/สถานะ/แถวต่อหน้า
 *   → ช่องค้นหา → ตารางคอลัมน์เรียงได้ทุกคอลัมน์ → คลิกแถวเปิดเอกสาร → PDF
 *
 * ข้อมูล 2 ชุดรวมกันเป็นตารางเดียว (เหมือน CM ที่ใบงานทุกด่านอยู่ตารางเดียว):
 *   GET /pm-reports/all-stations — เอกสาร PM ที่ช่างกรอกแล้ว
 *   GET /maximo/pm/open          — ใบงาน Maximo ที่ยังไม่ได้ assign = สถานะ Open
 * ใบงานที่มีเอกสารแล้วจะไม่โชว์ซ้ำ (dedup ด้วย wonum)
 */

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@material-tailwind/react";
import { DocumentArrowDownIcon, PlusIcon, TrashIcon } from "@heroicons/react/24/outline";
import { apiFetch } from "@/utils/api";
import useLanguage from "@/utils/useLanguage";
import { PM_LIST_ROUTE, PM_ORIGIN_LIST } from "@/app/dashboard/pm-report/lib/origin";
import { PM_PLANNING_ROLES, allAssignees, myVendorPlan, pendingVendorPlans, type VendorPlan } from "@/app/dashboard/pm-report/components/planning";
import { PM_APPROVE_ROLES } from "@/app/dashboard/pm-report/components/flow";
import { COMPANY_FILTER_OPTIONS, matchesCompanyFilter } from "@/utils/pm-dashboard";
import { csvDate, csvFilename, downloadCsv, toCsv } from "@/utils/csv";
import CsvExportButton from "@/components/CsvExportButton";
import { partyLine, type PartySummary } from "@/app/dashboard/pm-report/lib/partyStatus";

const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 500;
const LIMIT_PER_SOURCE = 200;
const WO_LIMIT = 1000;
const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";

type PMRow = {
  id: string;
  document_name: string;
  issue_id: string;
  wonum?: string;
  pm_type: string;          // CHARGER | MDB | CCB | CB-BOX | STATION
  pm_date: string;
  status: string;
  technician: string;
  sn: string;
  chargeBoxID: string;
  station_id: string;
  station_name?: string;
  /** บริษัทเจ้าของสถานี (backend เติมให้จาก iMPS.stations) */
  company?: string;
  /** ยี่ห้อของตู้ — EDS ดูแลตู้ FlexxFast โดยไม่ขึ้นกับ company ของสถานี */
  charger_brand?: string;
  side: string;
  created_at: string;
  /** เวลาที่เปิดใบงาน — ใบงาน = receivedAt, เอกสาร = receivedAt ของใบงานต้นทาง (ไม่มีก็ใช้ created_at) */
  opened_at?: string;
  file_url: string;
  /** แถวใบงาน Maximo ที่ยังไม่มีเอกสาร PM — ด่าน Open ของ flow */
  kind?: "report" | "wo";
  planning_status?: string;
  assignees?: string[];
  /** false = เลข wonum นี้ไม่มีอยู่จริงใน Maximo · null = เช็คไม่ได้ */
  exists_in_maximo?: boolean | null;
  /** เอกสารที่เป็นส่วนหนึ่งของใบ PM สถานี (ใบรวม 5 ส่วน) — id ของใบแม่ */
  job_id?: string;
  /** แถวที่ยุบจากหลายส่วนของใบเดียวกัน — ชนิดอุปกรณ์ทุกส่วนที่กรอกแล้ว (ใช้กรองตามชนิด) */
  pm_types?: string[];
  /** ที่มาของใบงาน: ใบงานจาก Maximo หรือเปิดเองใน iMPS (ไม่มีเลข WO ก็นับเป็นเปิดเอง) */
  wo_origin?: WoOrigin;
  /** vendor ที่ planner ต้นทางส่งต่อให้วางแผนอีกรอบ (ยืมจากใบงานผ่าน wonum) */
  vendor_plans?: VendorPlan[];
  /** เหตุผลที่ planner ตีกลับ — มีค่า + status เป็น draft = Reject (รอช่างแก้แล้วส่งใหม่) */
  reject_remark?: string;
  /** vendor ที่ส่งงานตู้ชาร์จแล้ว รอ planner ของ vendor อนุมัติก่อนถึง planner ต้นทาง (เช่น ["EDS"]) */
  vendor_review?: string[];
  /** อนุมัติปิดแล้ว แต่ส่งปิดงานเข้า Maximo ยังไม่ผ่าน (ระบบลองส่งใหม่เองเป็นระยะ) */
  maximo_pending?: boolean;
  /** ใบงานส่งต่อมาให้บริษัทของคนที่ดูอยู่ และยังไม่ได้วางแผน — สำหรับคนนี้ใบนี้ยังเป็น Open */
  vendor_pending_for_me?: boolean;
  /** สรุปรายฝ่ายของใบ PM สถานี — บรรทัดรอง "รอใคร" ใต้สถานะหลัก (backend: party_summaries) */
  parties?: PartySummary[];
  /** ใบนี้รอคนที่ login ทำต่อ (กรอก / แก้ / ส่งงาน / อนุมัติ) — backend คิดให้ (waiting_on_user) */
  waiting_on_me?: boolean;
  /** บริษัทของ planner ต้นทางของใบงาน (แถวใบงานที่ยังไม่มีเอกสาร) — ใช้กับตัวกรอง "รอฉัน" */
  planner_company?: string;
};

type WoOrigin = "maximo" | "manual";

/** origin ของใบงานที่เปิดเองจากหน้า "เพิ่มใบงาน" — ตรงกับ MANUAL_WO_ORIGIN ใน backend/routers/pm_maximo.py */
const MANUAL_WO_ORIGIN = "imps-manual";

function originOf(r: PMRow): WoOrigin {
  if (r.wo_origin) return r.wo_origin;
  return r.wonum ? "maximo" : "manual";
}

// ลำดับส่วนในใบ PM สถานี — แถวที่ยุบแล้วใช้ส่วนแรกตามลำดับนี้เป็นตัวแทน
const JOB_TYPE_ORDER = ["STATION", "MDB", "CCB", "CB-BOX", "CHARGER"];

/**
 * ใบ PM สถานี 1 ใบ = 1 แถว
 * backend ส่งเอกสารมาทีละส่วน (Station/MDB/CCB/CB_BOX/ตู้ละใบ) ถ้าไม่ยุบ ใบเดียวจะขึ้นหลายแถว
 * ทั้งที่สถานะ/เลขใบงาน/การกดเปิดเหมือนกันหมด (กดแล้วไปหน้ารวมของใบเดียวกัน)
 * เอกสารใบเดี่ยวแบบเก่า (ไม่มี job_id) ยังแสดงแถวละใบเหมือนเดิม
 */
function collapseJobRows(rows: PMRow[]): PMRow[] {
  const out: PMRow[] = [];
  const byJob = new Map<string, PMRow[]>();
  for (const r of rows) {
    if (!r.job_id) { out.push(r); continue; }
    const key = `${r.station_id}::${r.job_id}`;
    const list = byJob.get(key);
    if (list) list.push(r);
    else byJob.set(key, [r]);
  }
  for (const list of byJob.values()) {
    const rank = (r: PMRow) => {
      const i = JOB_TYPE_ORDER.indexOf(r.pm_type);
      return i < 0 ? JOB_TYPE_ORDER.length : i;
    };
    const head = [...list].sort((a, b) => rank(a) - rank(b))[0];
    const inspectors = Array.from(new Set(
      list.map((r) => String(r.technician || "").trim()).filter((x) => x && x !== "-")
    ));
    out.push({
      ...head,
      pm_types: Array.from(new Set(list.map((r) => r.pm_type))),
      technician: inspectors.join(", "),
      wonum: list.find((r) => r.wonum)?.wonum || head.wonum,
      // PDF ของใบนี้คือ PDF ทั้งใบ ไม่ใช่ของส่วนใดส่วนหนึ่ง
      file_url: `/stationpmjob/${encodeURIComponent(head.job_id || "")}/pdf?station_id=${encodeURIComponent(head.station_id)}`,
    });
  }
  return out;
}

// ชนิดเอกสารใบเดี่ยว → prefix ของ DELETE /<prefix>/{id} (backend/routers/pm_all_stations.py)
const DELETE_PREFIX: Record<string, string> = {
  CHARGER: "pmreport", MDB: "mdbpmreport", CCB: "ccbpmreport", "CB-BOX": "cbboxpmreport", STATION: "stationpmreport",
};

/**
 * URL ลบของแถวนี้ (super admin เท่านั้น — backend เช็คซ้ำ)
 *   ใบ PM สถานี (มี job_id) → ลบทั้งใบ: ทุกส่วน + ใบแม่ + ใบงานต้นทาง
 *   แถวใบงานที่ยังไม่มีเอกสาร → ลบใบงาน (และใบ PM ที่เปิดค้างไว้แต่ยังไม่ได้กรอก)
 *   เอกสารใบเดี่ยวแบบเก่า → ลบเอกสารใบนั้น
 */
/** ลิงก์ PDF ตามภาษาที่เลือกบนหน้าเว็บ (ป้าย/หัวตารางใน PDF เปลี่ยนตาม) — ลิงก์ภายนอกหรือที่มี lang แล้วไม่แตะ */
function pdfUrlOf(fileUrl: string, lang: string): string {
  if (fileUrl.startsWith("http")) return fileUrl;
  const url = `${API_BASE}${fileUrl}`;
  if (/[?&]lang=/.test(url)) return url;
  return `${url}${url.includes("?") ? "&" : "?"}lang=${encodeURIComponent(lang)}`;
}

function deleteUrlOf(r: PMRow): string {
  if (r.kind === "wo") return `/maximo/pm/${encodeURIComponent(r.wonum || r.id)}`;
  if (r.job_id) {
    return `/stationpmjob/${encodeURIComponent(r.job_id)}?station_id=${encodeURIComponent(r.station_id)}`;
  }
  const prefix = DELETE_PREFIX[r.pm_type] ?? "pmreport";
  const key = r.pm_type === "CHARGER" ? r.sn : r.station_id;
  return `/${prefix}/${encodeURIComponent(r.id)}${key && key !== "-" ? `?key=${encodeURIComponent(key)}` : ""}`;
}

/** แถวนี้มีอุปกรณ์ชนิดนี้ไหม — แถวที่ยุบแล้วมีได้หลายชนิด */
function hasPmType(r: PMRow, type: string): boolean {
  return r.pm_types ? r.pm_types.includes(type) : r.pm_type === type;
}

/** ด่านของงาน — ชื่อเดียวกับที่ใช้ในหน้า PM report */
type PmStage = "open" | "in_progress" | "rejected" | "wait_approve" | "closed";

/** ใบเก่าไม่มี status / เป็น "submitted" = ปิดไปแล้วก่อนมี flow อนุมัติ */
function stageOf(row: PMRow): PmStage {
  // ใบงาน Maximo: assign แล้ว = In Progress เหมือนในตารางของแต่ละ tab
  if (row.kind === "wo") {
    // vendor (เช่น EDS) ยังไม่ได้วางแผนส่งทีม = ยังไม่เริ่มงานจริง ทุกบริษัทเห็นเป็น Open
    if (row.vendor_pending_for_me || pendingVendorPlans(row).length > 0) return "open";
    return String(row.planning_status ?? "pending").trim().toLowerCase() === "planned"
      ? "in_progress"
      : "open";
  }
  const s = String(row.status ?? "").trim().toLowerCase();
  if (s === "wait for approve") return "wait_approve";
  // โดนตีกลับ (ทั้งใบ หรือบางฟอร์ม) และยังไม่ได้ส่งกลับมา — แยกจาก In Progress ให้เห็นชัด
  if (s === "draft") return String(row.reject_remark ?? "").trim() ? "rejected" : "in_progress";
  return "closed";
}

const STAGE_STYLE: Record<PmStage, { bg: string; text: string }> = {
  open: { bg: "#fee2e2", text: "#dc2626" },
  in_progress: { bg: "#fff7ed", text: "#ea580c" },
  rejected: { bg: "#fef9c3", text: "#a16207" },
  wait_approve: { bg: "#f3e8ff", text: "#7e22ce" },
  closed: { bg: "#dcfce7", text: "#15803d" },
};

const PM_TYPES = ["CHARGER", "MDB", "CCB", "CB-BOX", "STATION"] as const;

// ชนิดเอกสาร → tab ของหน้า /dashboard/pm-report
const TYPE_TO_TAB: Record<string, string> = {
  CHARGER: "charger",
  MDB: "mdb",
  CCB: "ccb",
  "CB-BOX": "cb-box",
  STATION: "station",
};

// "opened" = ค่าเริ่มต้นของหน้า (ไม่มีหัวคอลัมน์ให้กด)
type SortKey = "station" | "wo" | "technician" | "date" | "status" | "opened";

/** เวลาเป็นมิลลิวินาที — ค่าจาก Mongo ที่ไม่มี timezone เป็น UTC จึงเติม Z ก่อน parse */
function toTs(v?: string): number | "" {
  const s = String(v || "").trim();
  if (!s || s === "-") return "";
  const hasTz = /(Z|[+-]\d{2}:?\d{2})$/i.test(s);
  const t = Date.parse(hasTz || !s.includes("T") ? s : `${s}Z`);
  return Number.isFinite(t) ? t : "";
}
type SortDir = "asc" | "desc";

const STAGE_RANK: Record<PmStage, number> = { open: 0, in_progress: 1, rejected: 2, wait_approve: 3, closed: 4 };

/** pm_type ของใบงาน Maximo (CG/MB/CC/CB/ST) → ป้ายชนิดที่ตารางใช้ */
const WO_PM_TYPE_LABEL: Record<string, string> = {
  CG: "CHARGER", MB: "MDB", CC: "CCB", CB: "CB-BOX", ST: "STATION",
};

function yearOf(dateStr: string): number | null {
  const y = Number(String(dateStr || "").slice(0, 4));
  return Number.isFinite(y) && y > 1900 ? y : null;
}
function monthOf(dateStr: string): number | null {
  const m = Number(String(dateStr || "").slice(5, 7));
  return Number.isFinite(m) && m >= 1 && m <= 12 ? m - 1 : null;
}
function weekOf(dateStr: string): number | null {
  const d = Number(String(dateStr || "").slice(8, 10));
  return Number.isFinite(d) && d >= 1 ? Math.floor((d - 1) / 7) + 1 : null;
}
function weeksInMonth(year: number, month: number): number {
  return Math.ceil(new Date(year, month + 1, 0).getDate() / 7);
}

export default function PMListPage() {
  const [rows, setRows] = useState<PMRow[]>([]);
  const [me, setMe] = useState<{ username: string; role: string } | null>(null);
  const [userCompany, setUserCompany] = useState("");
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [yearSel, setYearSel] = useState<number | "all">("all");
  const [monthSel, setMonthSel] = useState<number | "all">("all");
  const [weekSel, setWeekSel] = useState<number | "all">("all");
  const [stationFilter, setStationFilter] = useState("All");
  // null = ทุกบริษัท (ค่าเริ่มต้น เหมือนหน้า PM Dashboard — ไม่ซ่อนงานของใครตั้งแต่เปิดหน้า)
  const [companyFilter, setCompanyFilter] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<string | null>(null);
  const [stageFilter, setStageFilter] = useState<PmStage | null>(null);
  // แท็บที่มาของใบงาน — null = ทั้งหมด
  const [originFilter, setOriginFilter] = useState<WoOrigin | null>(null);
  // ตัวกรอง "รอฉัน" — ใบที่ติดอยู่ที่คนที่ login (ดู isWaitingOnMe)
  const [mineOnly, setMineOnly] = useState(false);
  // แถวที่กำลังจะลบ — รอยืนยันใน pop-up (super admin เท่านั้น)
  const [deleteTarget, setDeleteTarget] = useState<PMRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  // ค่าเริ่มต้น: ใบงานที่เปิดล่าสุดอยู่บนสุด
  const [sortKey, setSortKey] = useState<SortKey>("opened");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const router = useRouter();
  const { lang } = useLanguage();

  // เลขใบงานที่เพิ่งเปิดจากหน้า "เพิ่มใบงาน" — โชว์แถบยืนยันแล้วล้าง query ทิ้ง
  // (อ่านจาก window แทน useSearchParams เพื่อไม่ต้องห่อหน้านี้ด้วย Suspense)
  const [createdWonum, setCreatedWonum] = useState("");
  useEffect(() => {
    const wonum = new URLSearchParams(window.location.search).get("created");
    if (!wonum) return;
    setCreatedWonum(wonum);
    window.history.replaceState(null, "", PM_LIST_ROUTE);
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await apiFetch("/me");
        if (!res.ok) return;
        const u = await res.json();
        if (alive) {
          const company = String(u?.company ?? "");
          const superAdmin = !!u?.is_super_admin;
          setMe({ username: u?.username ?? "", role: String(u?.role ?? "").trim().toLowerCase() });
          setUserCompany(company);
          setIsSuperAdmin(superAdmin);
        }
      } catch (err) {
        console.error("fetch /me error:", err);
      }
    })();
    return () => { alive = false; };
  }, []);

  // เข้ามาหน้ารวมทุกสถานี = ไม่ได้เจาะจงตู้ไหน — ล้างตัวที่เลือกค้างไว้
  useEffect(() => {
    localStorage.removeItem("selected_sn");
    localStorage.removeItem("selected_charger_no");
    window.dispatchEvent(new CustomEvent("charger:deselected"));
  }, []);

  useEffect(() => {
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const [repRes, woRes] = await Promise.allSettled([
          apiFetch(`/pm-reports/all-stations?limit_per_source=${LIMIT_PER_SOURCE}`),
          apiFetch(`/maximo/pm/open?only_open=true&limit=${WO_LIMIT}`),
        ]);

        if (repRes.status === "rejected") throw repRes.reason;
        const json = await repRes.value.json();
        if (!repRes.value.ok) throw new Error(json?.detail || `HTTP ${repRes.value.status}`);
        const reports: PMRow[] = collapseJobRows(
          (Array.isArray(json?.reports) ? json.reports : [])
            .map((r: PMRow) => ({ ...r, kind: "report" as const }))
        );

        // ใบงาน Maximo — ถ้าโหลดไม่ได้ก็ยังโชว์เอกสารได้ ไม่ต้องล้มทั้งหน้า
        let woRows: PMRow[] = [];
        if (woRes.status === "fulfilled" && woRes.value.ok) {
          const wj = await woRes.value.json().catch(() => ({}));
          const items: any[] = Array.isArray(wj?.items) ? wj.items : [];
          // ใบที่มีเอกสารแล้วไม่ต้องโชว์ซ้ำ — งาน 1 ใบ = 1 แถวที่ไล่สถานะไปเรื่อย ๆ
          const withReport = new Set(
            reports.map((r) => String(r.wonum || "").trim()).filter(Boolean)
          );
          // เอกสาร PM ไม่ได้เก็บ assignees ไว้เอง — ยืมจากใบงานต้นทางผ่าน wonum
          // เพื่อให้กรองงานของช่างได้ทั้งแถว WO และแถวเอกสาร
          const assigneesByWonum = new Map<string, string[]>();
          const vendorPlansByWonum = new Map<string, VendorPlan[]>();
          // เวลาเปิดใบงาน — ให้แถวเอกสารเรียงตามเวลาที่ใบงานต้นทางถูกเปิด
          const openedByWonum = new Map<string, string>();
          for (const w of items) {
            const wn = String(w?.wonum || "").trim();
            // ช่างของ planner ต้นทาง + ช่างที่ vendor มอบหมายเพิ่ม — ช่างของ vendor กรองงานตัวเองได้ด้วย
            if (wn) assigneesByWonum.set(wn, allAssignees(w));
            if (wn && w?.receivedAt) openedByWonum.set(wn, String(w.receivedAt));
            if (wn && Array.isArray(w?.vendor_plans) && w.vendor_plans.length) vendorPlansByWonum.set(wn, w.vendor_plans);
          }
          for (const r of reports) {
            const wn = String(r.wonum || "").trim();
            if (wn && assigneesByWonum.has(wn)) r.assignees = assigneesByWonum.get(wn);
            if (wn && vendorPlansByWonum.has(wn)) r.vendor_plans = vendorPlansByWonum.get(wn);
            if (wn && openedByWonum.has(wn)) r.opened_at = openedByWonum.get(wn);
          }
          woRows = items
            .filter((w) => !withReport.has(String(w?.wonum || "").trim()))
            .map((w) => ({
              kind: "wo" as const,
              id: String(w?.wonum || ""),
              wonum: String(w?.wonum || ""),
              issue_id: String(w?.wonum || ""),
              document_name: String(w?.description || ""),
              pm_type: WO_PM_TYPE_LABEL[String(w?.pm_type || "").toUpperCase()] ?? "CHARGER",
              pm_date: String(w?.pm_date || ""),
              status: "Open",
              planning_status: String(w?.planning_status || "pending"),
              // ผู้ตรวจสอบ = คนที่กรอกเอกสารจริง ใบงานที่ยังไม่มีเอกสารจึงเว้นว่าง
              // (ช่างที่ถูกมอบหมายยังอยู่ใน assignees ใช้กรองงานของช่างได้เหมือนเดิม)
              technician: "",
              assignees: allAssignees(w),
              vendor_plans: Array.isArray(w?.vendor_plans) ? w.vendor_plans : [],
              sn: String(w?.sn || ""),
              chargeBoxID: "",
              station_id: String(w?.station_id || ""),
              station_name: String(w?.station_name || w?.station_id || w?.location || ""),
              company: String(w?.company || ""),
              charger_brand: String(w?.charger_brand || ""),
              side: "",
              created_at: String(w?.receivedAt || ""),
              opened_at: String(w?.receivedAt || ""),
              file_url: "",
              exists_in_maximo: w?.exists_in_maximo ?? null,
              planner_company: String(w?.planner_company || ""),
              wo_origin: String(w?.origin || "").trim().toLowerCase() === MANUAL_WO_ORIGIN ? "manual" as const : "maximo" as const,
            }));
        }

        setRows([...woRows, ...reports]);
      } catch (e) {
        setError(e instanceof Error ? e.message : "โหลดข้อมูลไม่สำเร็จ");
        setRows([]);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const t = useMemo(() => ({
    th: {
      pageTitle: "PM List",
      subtitle: (n: number) => `ข้อมูลจาก iMPS · ${n} รายการทั้งหมด`,
      yearLabel: "ปี", monthLabel: "เดือน", weekLabel: "สัปดาห์",
      allYears: "ทุกปี", allMonths: "ทุกเดือน", allWeeks: "ทุกสัปดาห์",
      weekOption: (n: number) => `สัปดาห์ที่ ${n}`,
      monthsLong: ["มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"],
      stationFilterLabel: "กรองตามสถานี",
      companyFilterLabel: "บริษัท",
      allCompanies: "ทุกบริษัท",
      typeFilterLabel: "ชนิดอุปกรณ์",
      csvDocument: "ชื่อเอกสาร",
      allTypes: "ทุกชนิด",
      statusFilterLabel: "กรองตามสถานะ",
      rowsPerPage: "แถวต่อหน้า",
      tableCount: (n: number, q?: string) => `${n} รายการ${q ? ` · "${q}"` : ""}`,
      searchPlaceholder: "ค้นหา station, WO, ชื่อเอกสาร, ช่าง, SN…",
      clearFilters: "ล้างตัวกรอง",
      originLabel: "ที่มาของใบงาน",
      originMaximo: "ใบงาน Maximo",
      originManual: "ใบงานที่เปิดเอง",
      deleteTitle: "ลบใบงาน PM",
      deleteAction: "ลบ",
      deleting: "กำลังลบ…",
      cancel: "ยกเลิก",
      deleteJobBody: "ลบทั้งใบ — เอกสารทุกส่วน (Station / MDB / CCB / CB_BOX / ตู้ชาร์จ) และใบงานต้นทาง จะถูกลบถาวร กู้คืนไม่ได้",
      deleteWoBody: "ลบใบงานนี้ออกจาก iMPS ถาวร กู้คืนไม่ได้ — ใบงานจาก Maximo จะกลับมาอีกถ้า Maximo ยังส่งมาตอน sync",
      deleteReportBody: "ลบเอกสาร PM ใบนี้ถาวร กู้คืนไม่ได้",
      addWorkOrder: "เพิ่มใบงาน",
      created: (wonum: string) => `เปิดใบงาน ${wonum} เรียบร้อยแล้ว`,
      pagination: (from: number, to: number, total: number) => `แสดง ${from}–${to} จาก ${total} รายการ`,
      loading: "กำลังโหลด",
      errorPrefix: "โหลดข้อมูลไม่สำเร็จ",
      noResults: (q?: string) => (q ? `ไม่พบรายการที่ตรงกับ "${q}"` : "ไม่มีรายการ"),
      openReportTitle: "เปิดเอกสาร PM",
      openPlanTitle: "เปิดหน้าวางแผน",
      notInMaximo: "เลขใบงานนี้ไม่มีอยู่จริงใน Maximo — วางแผนแล้วส่งสถานะกลับไม่ได้",
      noWonum: "เอกสารนี้ไม่ได้ผูกกับใบงาน Maximo",
      sortAsc: "เรียงจากน้อยไปมาก", sortDesc: "เรียงจากมากไปน้อย",
      headers: {
        station: "สถานี", wo: "WO",
        technician: "ผู้ตรวจสอบ", date: "PM Plan", status: "สถานะ",
      },
      stage: { open: "Open", in_progress: "In Progress", rejected: "Reject", wait_approve: "Wait for approve", closed: "Closed" },
      vendorWait: "รอ planner {p} อนุมัติ",
      mineOnly: "รอฉัน",
      mineOnlyTitle: "ใบที่รอคุณทำต่อ — วางแผน / เริ่ม PM / กรอก / แก้ฟอร์มที่ตีกลับ / ส่งงาน / อนุมัติ",
      maximoPending: "ยังไม่ปิดใน Maximo",
      maximoPendingTitle: "ส่งปิดงานเข้า Maximo ไม่ผ่าน ระบบกำลังลองส่งใหม่ — เปิดใบ PM เพื่อดูสถานะหรือกดส่งใหม่",
    },
    en: {
      pageTitle: "PM List",
      subtitle: (n: number) => `From iMPS · ${n} records`,
      yearLabel: "Year", monthLabel: "Month", weekLabel: "Week",
      allYears: "All years", allMonths: "All months", allWeeks: "All weeks",
      weekOption: (n: number) => `Week ${n}`,
      monthsLong: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      stationFilterLabel: "Station",
      companyFilterLabel: "Company",
      allCompanies: "All companies",
      typeFilterLabel: "Equipment type",
      csvDocument: "Document",
      allTypes: "All types",
      statusFilterLabel: "Status",
      rowsPerPage: "Rows per page",
      tableCount: (n: number, q?: string) => `${n} record(s)${q ? ` · "${q}"` : ""}`,
      searchPlaceholder: "Search station, WO, document, technician, SN…",
      clearFilters: "Clear filters",
      originLabel: "Work order source",
      originMaximo: "Maximo work orders",
      originManual: "Created in iMPS",
      deleteTitle: "Delete PM work order",
      deleteAction: "Delete",
      deleting: "Deleting…",
      cancel: "Cancel",
      deleteJobBody: "Deletes the whole document — every section (Station / MDB / CCB / CB_BOX / chargers) and its work order. This cannot be undone.",
      deleteWoBody: "Deletes this work order from iMPS permanently. A Maximo work order comes back if Maximo still sends it on sync.",
      deleteReportBody: "Deletes this PM report permanently. This cannot be undone.",
      addWorkOrder: "Add work order",
      created: (wonum: string) => `Work order ${wonum} created`,
      pagination: (from: number, to: number, total: number) => `Showing ${from}–${to} of ${total}`,
      loading: "Loading",
      errorPrefix: "Failed to load",
      noResults: (q?: string) => (q ? `No records match "${q}"` : "No records"),
      openReportTitle: "Open PM report",
      openPlanTitle: "Open planning page",
      notInMaximo: "This work order does not exist in Maximo — status updates will fail",
      noWonum: "This document is not linked to a Maximo work order",
      sortAsc: "Sort ascending", sortDesc: "Sort descending",
      headers: {
        station: "Station", wo: "WO",
        technician: "Inspector", date: "PM Plan", status: "Status",
      },
      stage: { open: "Open", in_progress: "In Progress", rejected: "Reject", wait_approve: "Wait for approve", closed: "Closed" },
      vendorWait: "Waiting for {p} planner approval",
      mineOnly: "Waiting on me",
      mineOnlyTitle: "Documents waiting on you — plan / start PM / fill in / fix rejected forms / submit / approve",
      maximoPending: "Not closed in Maximo",
      maximoPendingTitle: "Closing in Maximo failed and is being retried — open the PM document to see the status or resend",
    },
  }[lang]), [lang]);

  const stageLabel = t.stage as Record<PmStage, string>;

  const openReport = useCallback(async (r: PMRow) => {
    if (!r.id) return;
    const tab = TYPE_TO_TAB[r.pm_type] ?? "charger";

    // หน้า PM report อ่านตู้/สถานีที่เลือกจาก localStorage — ตั้งให้ตรงกับแถวที่กด
    localStorage.removeItem("selected_sn");
    localStorage.removeItem("selected_charger_no");
    if (r.station_id) localStorage.setItem("selected_station_id", r.station_id);
    if (r.station_name || r.station_id) {
      localStorage.setItem("selected_station_name", r.station_name || r.station_id);
    }

    // ใบงานที่ planner ต้นทางส่งต่อมาให้บริษัทเราวางแผนอีกรอบ และเรายังไม่ได้วางแผน
    // → หน้าวางแผนของใบงานเสมอ (แม้ช่างต้นทางจะเริ่ม PM ไปแล้วก็ตาม) planner ของเราต้องวางแผนก่อน
    if (r.vendor_pending_for_me && r.wonum && PM_PLANNING_ROLES.includes(me?.role ?? "")) {
      window.dispatchEvent(new CustomEvent("station:selected"));
      const params = new URLSearchParams({
        tab, view: "form", wonum: r.wonum, from: PM_ORIGIN_LIST, planning: "1",
        ...(r.station_id ? { station_id: r.station_id } : {}),
      });
      router.push(`/dashboard/pm-report?${params.toString()}`);
      return;
    }

    // ใบที่เป็นส่วนหนึ่งของใบ PM สถานี → เข้าหน้ารวม 5 ส่วนของใบนั้นเลย
    //   แถวเอกสาร: ใบลูกรู้ job_id ของใบแม่อยู่แล้ว — ทุกสถานะ เพราะสถานะที่โชว์คือของทั้งใบ
    //              และอนุมัติ/ตีกลับทำทั้งใบที่หน้ารวม ไม่ใช่รายส่วน
    //   แถวใบงาน : In Progress แต่ยังไม่มีส่วนไหนถูกกรอก ต้องถามหาใบจาก wonum
    //              ไม่เจอ = ช่างยังไม่กด "เริ่ม PM" ไปหน้าใบงานตามเดิม
    //   ช่าง (ไม่ใช่ผู้วางแผน) ที่ฝ่ายตัวเองยังไม่กด "เริ่ม PM" — เช่น ช่าง EGAT เปิดใบไปก่อน ช่าง EDS ยังไม่เริ่ม
    //              → หน้าใบงานที่มีปุ่ม "เริ่ม PM" เหมือนช่างฝ่ายแรก (กดแล้ว backend หยิบใบเดิม + จดเวลาเริ่มของฝ่าย)
    //   planner ของ vendor (เช่น EDS) ที่วางแผนแล้ว แต่ช่างของบริษัทตัวเองยังไม่เริ่ม → หน้าวางแผนเหมือนกัน
    //              ให้ยังกด "แก้ไขแผนของบริษัทคุณ" ได้ (เหมือน planner ต้นทางก่อนช่างเริ่ม PM)
    const isTech = !PM_PLANNING_ROLES.includes(me?.role ?? "");
    const isVendorPlanner = !isTech && myVendorPlan(r, userCompany)?.status === "planned";
    const toPlanFirst = isTech || isVendorPlanner;
    if (r.station_id && (r.kind === "report" ? !!r.job_id : stageOf(r) === "in_progress")) {
      let jobId = r.kind === "report" ? (r.job_id || "") : "";
      let myStarted = true;
      const wonum = String(r.wonum || "").trim();
      const draft = r.kind === "wo" || ["in_progress", "rejected"].includes(stageOf(r));
      if (wonum && (!jobId || (toPlanFirst && draft))) {
        try {
          const res = await apiFetch(
            `/stationpmjob/by-wonum?station_id=${encodeURIComponent(r.station_id)}&wonum=${encodeURIComponent(wonum)}`
          );
          if (res.ok) {
            const j = await res.json();
            jobId = jobId || String(j?.id || "");
            if (j?.id && j?.my_started === false) myStarted = false;
          }
        } catch { /* หาไม่ได้ก็เปิดหน้าใบงานตามเดิม */ }
      }
      if (jobId && toPlanFirst && !myStarted) {
        window.dispatchEvent(new CustomEvent(tab === "charger" && r.sn && r.sn !== "-" ? "charger:selected" : "station:selected"));
        if (tab === "charger" && r.sn && r.sn !== "-") localStorage.setItem("selected_sn", r.sn);
        const params = new URLSearchParams({
          tab, view: "form", wonum, from: PM_ORIGIN_LIST, planning: "1", station_id: r.station_id,
        });
        if (tab === "charger" && r.sn && r.sn !== "-") params.set("sn", r.sn);
        router.push(`/dashboard/pm-report?${params.toString()}`);
        return;
      }
      if (jobId) {
        window.dispatchEvent(new CustomEvent("station:selected"));
        const params = new URLSearchParams({
          view: "form", job_id: jobId, station_id: r.station_id, from: PM_ORIGIN_LIST,
        });
        router.push(`/dashboard/pm-report?${params.toString()}`);
        return;
      }
    }
    if (tab === "charger" && r.sn && r.sn !== "-") {
      localStorage.setItem("selected_sn", r.sn);
      window.dispatchEvent(new CustomEvent("charger:selected"));
    } else {
      window.dispatchEvent(new CustomEvent("station:selected"));
    }

    // แถวใบงาน Maximo ยังไม่มีเอกสาร → เข้าหน้าวางแผนเหมือนกันทุก role
    // ผู้วางแผน assign ใบที่ยังไม่วางแผน (วางแผนแล้วแก้ไม่ได้) ส่วนช่างเห็นแผนแบบอ่านอย่างเดียว + ปุ่ม "เริ่ม PM" ท้ายหน้า
    // from= ให้ปุ่มย้อนกลับในฟอร์มรู้ว่าต้องพากลับมาหน้านี้ ไม่ใช่ตาราง tab
    // สิทธิ์อนุมัติแคบกว่าสิทธิ์วางแผน (owner วางแผนได้ แต่อนุมัติไม่ได้)
    // ใช้ชุดเดียวกับที่ backend เช็ค ไม่งั้นโชว์ปุ่มแล้วกดไปโดน 403
    const canApprove = PM_APPROVE_ROLES.includes(me?.role ?? "");
    const params = r.kind === "wo"
      ? new URLSearchParams({
          tab, view: "form", wonum: r.wonum || r.id, from: PM_ORIGIN_LIST, planning: "1",
        })
      // ใบที่รออนุมัติหรือปิดไปแล้ว → เปิดหน้าตรวจหน้าเดียวกันทุก role
      //   ผู้อนุมัติ + ยังรออนุมัติ → approve=1 มีปุ่มอนุมัติ/ตีกลับ
      //   นอกนั้น (รวมใบที่ปิดแล้ว)  → review=1 ดูอย่างเดียว มีแค่ปุ่มย้อนกลับ
      : new URLSearchParams({
          tab, view: "form", edit_id: r.id, from: PM_ORIGIN_LIST,
          ...(["wait_approve", "closed"].includes(stageOf(r))
            ? { [canApprove && stageOf(r) === "wait_approve" ? "approve" : "review"]: "1" }
            : {}),
        });
    if (tab === "charger" && r.sn && r.sn !== "-") params.set("sn", r.sn);
    else if (r.station_id) params.set("station_id", r.station_id);
    router.push(`/dashboard/pm-report?${params.toString()}`);
  }, [router, me, userCompany]);

  const confirmDelete = async () => {
    const r = deleteTarget;
    if (!r || deleting) return;
    setDeleting(true);
    setDeleteError("");
    try {
      const res = await apiFetch(deleteUrlOf(r), { method: "DELETE" });
      const json = await res.json().catch(() => ({} as any));
      if (!res.ok) throw new Error(json?.detail || `HTTP ${res.status}`);
      // เอาออกจากตารางเลย ไม่ต้องโหลดทั้งหน้าใหม่ — ใบ PM สถานีลบใบงานต้นทางไปด้วย
      const wonum = String(r.wonum || "").trim();
      setRows((prev) => prev.filter((x) => {
        if (x === r) return false;
        if (r.job_id && x.job_id === r.job_id && x.station_id === r.station_id) return false;
        if ((r.kind === "wo" || r.job_id) && wonum && x.kind === "wo" && String(x.wonum || "").trim() === wonum) return false;
        return true;
      }));
      setDeleteTarget(null);
    } catch (e) {
      setDeleteError(e instanceof Error ? e.message : String(e));
    } finally {
      setDeleting(false);
    }
  };

  const clearAll = () => {
    setMineOnly(false);
    setTypeFilter(null);
    setStageFilter(null);
    setOriginFilter(null);
    setStationFilter("All");
    setCompanyFilter(null);
    setSearch("");
    setPage(0);
  };
  const activeFilterCount =
    (mineOnly ? 1 : 0) + (typeFilter ? 1 : 0) + (stageFilter ? 1 : 0) + (originFilter ? 1 : 0) + (stationFilter !== "All" ? 1 : 0) + (companyFilter ? 1 : 0);

  // ช่างเห็นเฉพาะงานที่ planner มอบหมายให้ตัวเอง — role อื่นเห็นทุกใบ
  const scopedRows = useMemo(() => {
    if (!me || me.role !== "technician") return rows;
    const uname = me.username.trim().toLowerCase();
    if (!uname) return [];
    const isMine = (v?: string) => String(v ?? "").trim().toLowerCase() === uname;
    return rows.filter((r) =>
      (r.assignees ?? []).some(isMine) || isMine(r.technician)
    );
  }, [rows, me]);

  const isEgatCompany = userCompany.trim().toLowerCase() === "egat";
  // EGAT ดูแลทุกบริษัท + super admin — คนบริษัทอื่นเห็นเฉพาะงานของตัวเองอยู่แล้ว ไม่ต้องมีดรอปดาวน์
  const canSeeAllCompanies = isSuperAdmin || isEgatCompany;

  // เกณฑ์เดียวกับ PM Dashboard: EDS = ใบของตู้ FlexxFast, บริษัทอื่นเทียบ company ของสถานี
  // บริษัทอื่น (เช่น vendor EDS) เห็นใบงานเฉพาะ: ใบที่ planner ต้นทางส่งต่อให้บริษัทตัวเอง
  // + ใบงานของสถานี/ตู้ที่บริษัทดูแลอยู่แล้ว (เกณฑ์เดียวกับตัวกรองบริษัท)
  // แถวเอกสารถูกจำกัดตามสถานีที่เห็นได้ที่ backend อยู่แล้ว ไม่ต้องกรองซ้ำ
  const companyRows = useMemo(() => {
    const withHandoff = scopedRows.map((r) => {
      const mine = myVendorPlan(r, userCompany);
      const pending = !!mine && mine.status !== "planned";
      return pending === !!r.vendor_pending_for_me ? r : { ...r, vendor_pending_for_me: pending };
    });
    if (canSeeAllCompanies) return withHandoff.filter((r) => matchesCompanyFilter(r, companyFilter));
    if (!userCompany.trim()) return withHandoff;
    return withHandoff.filter((r) =>
      r.kind !== "wo" || !!myVendorPlan(r, userCompany) || matchesCompanyFilter(r, userCompany)
    );
  }, [scopedRows, companyFilter, canSeeAllCompanies, userCompany]);

  const stations = useMemo(() => {
    const names = Array.from(new Set(companyRows.map((r) => r.station_name || r.station_id))).filter(Boolean);
    return ["All", ...names.sort()];
  }, [companyRows]);

  const years = useMemo(() => {
    const set = new Set<number>();
    for (const r of companyRows) {
      const y = yearOf(r.pm_date);
      if (y) set.add(y);
    }
    return Array.from(set).sort((a, b) => b - a);
  }, [companyRows]);

  const weekCount = useMemo(
    () => (yearSel !== "all" && monthSel !== "all" ? weeksInMonth(yearSel, monthSel) : 0),
    [yearSel, monthSel]
  );

  const periodRows = useMemo(() => {
    return companyRows.filter((r) => {
      if (stationFilter !== "All" && (r.station_name || r.station_id) !== stationFilter) return false;
      if (yearSel !== "all" && yearOf(r.pm_date) !== yearSel) return false;
      if (monthSel !== "all" && monthOf(r.pm_date) !== monthSel) return false;
      if (weekSel !== "all" && weekOf(r.pm_date) !== weekSel) return false;
      return true;
    });
  }, [companyRows, stationFilter, yearSel, monthSel, weekSel]);

  /**
   * ใบนี้รอคนที่ login ทำต่อไหม (ตัวกรอง "รอฉัน")
   *   แถวเอกสาร: backend คิดให้แล้ว (waiting_on_me) — ตามฝ่ายของผู้ใช้ / planner ที่ต้องอนุมัติ
   *   แถวใบงาน (ยังไม่มีเอกสาร): Open → planner ที่ต้องวางแผน (ต้นทาง หรือ vendor ที่ได้ใบส่งต่อ)
   *                             In Progress → ช่างที่ได้รับมอบ (ยังไม่กดเริ่ม PM)
   */
  const isWaitingOnMe = useCallback((r: PMRow): boolean => {
    if (r.kind !== "wo") return !!r.waiting_on_me;
    const role = me?.role ?? "";
    const stage = stageOf(r);
    if (stage === "open") {
      if (!PM_PLANNING_ROLES.includes(role)) return false;
      if (r.vendor_pending_for_me) return true;
      if (pendingVendorPlans(r).length > 0) return false;   // รอ vendor รายอื่นวางแผน
      if (role === "admin" || isSuperAdmin) return true;
      const origin = String(r.planner_company ?? "").trim().toLowerCase();
      return !origin || origin === userCompany.trim().toLowerCase();
    }
    // ช่างเห็นเฉพาะใบที่ได้รับมอบอยู่แล้ว (scopedRows)
    return stage === "in_progress" && role === "technician";
  }, [me, isSuperAdmin, userCompany]);

  const applySearch = useCallback((list: PMRow[]) => {
    const q = search.trim().toLowerCase();
    if (!q) return list;
    return list.filter((r) =>
      [r.station_name, r.station_id, r.wonum, r.issue_id, r.document_name, r.technician, r.sn, r.chargeBoxID, r.pm_type, ...(r.pm_types ?? [])]
        .some((v) => String(v ?? "").toLowerCase().includes(q))
    );
  }, [search]);

  const searchFiltered = useMemo(() => {
    let list = periodRows;
    if (mineOnly) list = list.filter(isWaitingOnMe);
    if (originFilter) list = list.filter((r) => originOf(r) === originFilter);
    if (typeFilter) list = list.filter((r) => hasPmType(r, typeFilter));
    if (stageFilter) list = list.filter((r) => stageOf(r) === stageFilter);
    return applySearch(list);
  }, [periodRows, mineOnly, isWaitingOnMe, originFilter, typeFilter, stageFilter, applySearch]);

  // ตัวนับบนปุ่ม "รอฉัน" — ตามตัวกรองอื่นทั้งหมด
  const mineCount = useMemo(() => {
    let base = periodRows.filter(isWaitingOnMe);
    if (originFilter) base = base.filter((r) => originOf(r) === originFilter);
    if (typeFilter) base = base.filter((r) => hasPmType(r, typeFilter));
    if (stageFilter) base = base.filter((r) => stageOf(r) === stageFilter);
    return applySearch(base).length;
  }, [periodRows, isWaitingOnMe, originFilter, typeFilter, stageFilter, applySearch]);

  // ตัวนับบนปุ่มสถานะ — ไม่ขึ้นกับตัวกรองสถานะที่เลือกอยู่ (เหมือน CM List)
  const stageCounts = useMemo(() => {
    let base = periodRows;
    if (mineOnly) base = base.filter(isWaitingOnMe);
    if (originFilter) base = base.filter((r) => originOf(r) === originFilter);
    if (typeFilter) base = base.filter((r) => hasPmType(r, typeFilter));
    base = applySearch(base);
    const counts: Record<PmStage, number> = { open: 0, in_progress: 0, rejected: 0, wait_approve: 0, closed: 0 };
    for (const r of base) counts[stageOf(r)]++;
    return counts;
  }, [periodRows, mineOnly, isWaitingOnMe, originFilter, typeFilter, applySearch]);

  // ตัวนับบนแท็บที่มา — ไม่ขึ้นกับแท็บที่เลือกอยู่ แต่ตามตัวกรองอื่นทั้งหมด
  const originCounts = useMemo(() => {
    let base = periodRows;
    if (mineOnly) base = base.filter(isWaitingOnMe);
    if (typeFilter) base = base.filter((r) => hasPmType(r, typeFilter));
    if (stageFilter) base = base.filter((r) => stageOf(r) === stageFilter);
    base = applySearch(base);
    const counts: Record<WoOrigin, number> = { maximo: 0, manual: 0 };
    for (const r of base) counts[originOf(r)]++;
    return counts;
  }, [periodRows, mineOnly, isWaitingOnMe, typeFilter, stageFilter, applySearch]);

  const sortValue = useCallback((r: PMRow, key: SortKey): string | number => {
    switch (key) {
      case "station": return (r.station_name || r.station_id || "").toLowerCase();
      case "wo": return (r.wonum || "").toLowerCase();
      case "technician": return (r.technician || "").toLowerCase();
      case "date": return r.pm_date || "";
      case "status": return STAGE_RANK[stageOf(r)];
      // ใบงานที่ปิดไปแล้ว (ไม่อยู่ในรายการใบงานเปิด) ใช้เวลาสร้างเอกสารแทน
      case "opened": return toTs(r.opened_at) || toTs(r.created_at);
      default: return "";
    }
  }, []);

  const sortedRows = useMemo(() => {
    const dir = sortDir === "asc" ? 1 : -1;
    return [...searchFiltered].sort((a, b) => {
      const va = sortValue(a, sortKey);
      const vb = sortValue(b, sortKey);
      // ค่าว่างอยู่ล่างสุดเสมอไม่ว่าจะเรียงทางไหน
      const emptyA = va === "" || va === "-";
      const emptyB = vb === "" || vb === "-";
      if (emptyA !== emptyB) return emptyA ? 1 : -1;
      if (typeof va === "number" && typeof vb === "number") return (va - vb) * dir;
      return String(va).localeCompare(String(vb)) * dir;
    });
  }, [searchFiltered, sortKey, sortDir, sortValue]);

  const tableRows = useMemo(
    () => sortedRows.slice(page * pageSize, (page + 1) * pageSize),
    [sortedRows, page, pageSize]
  );

  useEffect(() => { setPage(0); }, [searchFiltered.length, sortKey, sortDir]);

  const commitPageSize = (raw: string) => {
    const n = parseInt(raw, 10);
    if (!Number.isFinite(n) || n < 1) return;
    setPageSize(Math.min(n, MAX_PAGE_SIZE));
    setPage(0);
  };

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      // วันที่เริ่มจากล่าสุด ข้อความเริ่ม A→Z
      setSortDir(key === "date" ? "desc" : "asc");
    }
  };

  const columns: { key: SortKey; label: string }[] = [
    { key: "station", label: t.headers.station },
    { key: "wo", label: t.headers.wo },
    { key: "date", label: t.headers.date },
    { key: "status", label: t.headers.status },
  ];

  // Toutes les lignes filtrées + triées (pas seulement la page affichée)
  const exportCsv = () => {
    const csv = toCsv(sortedRows, [
      { header: "#", value: (_r, i) => i + 1 },
      { header: t.headers.station, value: (r) => r.station_name || r.station_id },
      { header: t.headers.wo, value: (r) => r.wonum },
      { header: t.originLabel, value: (r) => (originOf(r) === "manual" ? t.originManual : t.originMaximo) },
      { header: t.typeFilterLabel, value: (r) => r.pm_type },
      { header: t.csvDocument, value: (r) => (r.document_name === "-" ? "" : r.document_name) },
      { header: "SN", value: (r) => (r.sn === "-" ? "" : r.sn) },
      { header: t.companyFilterLabel, value: (r) => r.company },
      { header: "Brand", value: (r) => r.charger_brand },
      { header: t.headers.technician, value: (r) => (r.technician === "-" ? "" : r.technician) },
      { header: t.headers.date, value: (r) => csvDate(r.pm_date) },
      { header: t.headers.status, value: (r) => stageLabel[stageOf(r)] },
      { header: "PDF", value: (r) => (stageOf(r) === "closed" && r.file_url ? pdfUrlOf(r.file_url, lang) : "") },
    ]);
    downloadCsv(csvFilename("pm-list"), csv);
  };

  const totalPages = Math.ceil(sortedRows.length / pageSize);
  const from = page * pageSize + 1;
  const to = Math.min((page + 1) * pageSize, sortedRows.length);

  if (loading) {
    return (
      <div role="status" aria-label={t.loading} className="tw-flex tw-min-h-64 tw-items-center tw-justify-center">
        <div aria-hidden="true" className="tw-h-10 tw-w-10 tw-animate-spin tw-rounded-full tw-border-4 tw-border-blue-500 tw-border-t-transparent" />
      </div>
    );
  }

  return (
    <main className="tw-min-h-screen tw-bg-gray-50/60 tw-p-6">
      {createdWonum && (
        <div className="tw-mb-4 tw-flex tw-items-center tw-gap-3 tw-rounded-xl tw-border tw-border-green-200 tw-bg-green-50 tw-px-4 tw-py-3 tw-text-sm tw-text-green-800">
          <span className="tw-text-base">✅</span>
          <span>{t.created(createdWonum)}</span>
          <button
            type="button"
            onClick={() => setCreatedWonum("")}
            aria-label="close"
            className="tw-ml-auto tw-text-xs tw-font-semibold tw-text-green-700 tw-underline hover:tw-text-green-900"
          >
            ✕
          </button>
        </div>
      )}
      {error && (
        <div className="tw-mb-4 tw-flex tw-items-center tw-gap-3 tw-rounded-xl tw-border tw-border-red-200 tw-bg-red-50 tw-px-4 tw-py-3 tw-text-sm tw-text-red-700">
          <span className="tw-text-base">⚠️</span>
          <span>{`${t.errorPrefix}: `}<strong>{error}</strong></span>
        </div>
      )}

      {/* ── Header ── */}
      <div className="tw-mb-4 tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-start sm:tw-justify-between">
        <div>
          <h1 className="tw-text-2xl tw-font-bold tw-text-gray-800">{t.pageTitle}</h1>
          <p className="tw-mt-0.5 tw-text-sm tw-text-gray-500">
            {t.subtitle(scopedRows.length)}
            <span className="tw-ml-2 tw-font-semibold tw-text-blue-600">
              {t.tableCount(searchFiltered.length, search || undefined)}
            </span>
          </p>
        </div>
        <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-3">
          <div className="tw-flex tw-items-center tw-gap-1.5">
            <label htmlFor="year-select" className="tw-text-xs tw-font-medium tw-text-gray-500">{t.yearLabel}</label>
            <select
              id="year-select" value={String(yearSel)}
              onChange={(e) => { setYearSel(e.target.value === "all" ? "all" : Number(e.target.value)); setWeekSel("all"); setPage(0); }}
              className="tw-rounded-lg tw-border tw-border-gray-200 tw-bg-white tw-px-2.5 tw-py-1.5 tw-text-sm tw-text-gray-700 tw-shadow-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-400"
            >
              <option value="all">{t.allYears}</option>
              {years.map((y) => <option key={y} value={String(y)}>{y}</option>)}
            </select>
          </div>
          <div className="tw-flex tw-items-center tw-gap-1.5">
            <label htmlFor="month-select" className="tw-text-xs tw-font-medium tw-text-gray-500">{t.monthLabel}</label>
            <select
              id="month-select" value={String(monthSel)}
              onChange={(e) => { setMonthSel(e.target.value === "all" ? "all" : Number(e.target.value)); setWeekSel("all"); setPage(0); }}
              className="tw-rounded-lg tw-border tw-border-gray-200 tw-bg-white tw-px-2.5 tw-py-1.5 tw-text-sm tw-text-gray-700 tw-shadow-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-400"
            >
              <option value="all">{t.allMonths}</option>
              {t.monthsLong.map((m, i) => <option key={m} value={String(i)}>{m}</option>)}
            </select>
          </div>
          <div className="tw-flex tw-items-center tw-gap-1.5">
            <label htmlFor="week-select" className="tw-text-xs tw-font-medium tw-text-gray-500">{t.weekLabel}</label>
            <select
              id="week-select" value={String(weekSel)} disabled={weekCount === 0}
              onChange={(e) => { setWeekSel(e.target.value === "all" ? "all" : Number(e.target.value)); setPage(0); }}
              className="tw-rounded-lg tw-border tw-border-gray-200 tw-bg-white tw-px-2.5 tw-py-1.5 tw-text-sm tw-text-gray-700 tw-shadow-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-400 disabled:tw-cursor-not-allowed disabled:tw-bg-gray-50 disabled:tw-text-gray-400"
            >
              <option value="all">{t.allWeeks}</option>
              {Array.from({ length: weekCount }, (_, i) => <option key={i} value={String(i + 1)}>{t.weekOption(i + 1)}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* ── Toolbar ── */}
      <div className="tw-mb-3 tw-flex tw-flex-wrap tw-items-center tw-gap-3">
        <div className="tw-flex tw-items-center tw-gap-1.5">
          <label htmlFor="station-filter" className="tw-text-xs tw-font-medium tw-text-gray-500">{t.stationFilterLabel}</label>
          <select
            id="station-filter" value={stationFilter}
            onChange={(e) => { setStationFilter(e.target.value); setPage(0); }}
            className="tw-max-w-[220px] tw-rounded-lg tw-border tw-border-gray-200 tw-bg-white tw-px-3 tw-py-1.5 tw-text-sm tw-text-gray-700 tw-shadow-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-400"
          >
            {stations.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>

        {canSeeAllCompanies && (
          <div className="tw-flex tw-items-center tw-gap-1.5">
            <label htmlFor="company-filter" className="tw-text-xs tw-font-medium tw-text-gray-500">{t.companyFilterLabel}</label>
            <select
              id="company-filter" value={companyFilter ?? "all"}
              onChange={(e) => { setCompanyFilter(e.target.value === "all" ? null : e.target.value); setStationFilter("All"); setPage(0); }}
              className="tw-rounded-lg tw-border tw-border-gray-200 tw-bg-white tw-px-3 tw-py-1.5 tw-text-sm tw-text-gray-700 tw-shadow-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-400"
            >
              <option value="all">{t.allCompanies}</option>
              {COMPANY_FILTER_OPTIONS.map((company) => (
                <option key={company} value={company}>{company}</option>
              ))}
            </select>
          </div>
        )}

        <div className="tw-flex tw-items-center tw-gap-1.5">
          <label htmlFor="type-filter" className="tw-text-xs tw-font-medium tw-text-gray-500">{t.typeFilterLabel}</label>
          <select
            id="type-filter" value={typeFilter ?? "all"}
            onChange={(e) => { setTypeFilter(e.target.value === "all" ? null : e.target.value); setPage(0); }}
            className="tw-rounded-lg tw-border tw-border-gray-200 tw-bg-white tw-px-3 tw-py-1.5 tw-text-sm tw-text-gray-700 tw-shadow-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-400"
          >
            <option value="all">{t.allTypes}</option>
            {PM_TYPES.map((ty) => <option key={ty} value={ty}>{ty}</option>)}
          </select>
        </div>

        {/* ที่มาของใบงาน — กดซ้ำเพื่อยกเลิก (เหมือนปุ่มสถานะข้าง ๆ) */}
        <div className="tw-flex tw-items-center tw-gap-1.5" role="group" aria-label={t.originLabel}>
          {([
            { key: "maximo" as const, label: t.originMaximo },
            { key: "manual" as const, label: t.originManual },
          ]).map(({ key, label }) => {
            const isActive = originFilter === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => { setOriginFilter(isActive ? null : key); setPage(0); }}
                aria-pressed={isActive}
                className={`tw-whitespace-nowrap tw-rounded-full tw-px-3 tw-py-1 tw-text-xs tw-font-semibold tw-transition-all ${isActive ? "tw-bg-gray-800 tw-text-white tw-shadow-sm" : "tw-bg-gray-100 tw-text-gray-700 hover:tw-brightness-95"}`}
              >
                {`${label} (${originCounts[key]})`}
              </button>
            );
          })}
        </div>

        {/* รอฉัน — ใบที่ติดอยู่ที่คนที่ login (กดซ้ำเพื่อยกเลิก) */}
        <button
          type="button"
          onClick={() => { setMineOnly((v) => !v); setPage(0); }}
          aria-pressed={mineOnly}
          title={t.mineOnlyTitle}
          className={`tw-whitespace-nowrap tw-rounded-full tw-px-3 tw-py-1 tw-text-xs tw-font-semibold tw-transition-all ${mineOnly ? "tw-bg-blue-600 tw-text-white tw-shadow-sm" : "tw-bg-blue-50 tw-text-blue-700 hover:tw-brightness-95"}`}
        >
          {`${t.mineOnly} (${mineCount})`}
        </button>

        <div className="tw-flex tw-items-center tw-gap-1.5" role="group" aria-label={t.statusFilterLabel}>
          {(["open", "in_progress", "rejected", "wait_approve", "closed"] as const).map((key) => {
            const isActive = stageFilter === key;
            const { bg, text } = STAGE_STYLE[key];
            return (
              <button
                key={key}
                type="button"
                onClick={() => { setStageFilter(isActive ? null : key); setPage(0); }}
                aria-pressed={isActive}
                className={`tw-rounded-full tw-px-3 tw-py-1 tw-text-xs tw-font-semibold tw-transition-all ${isActive ? "tw-shadow-sm" : "hover:tw-brightness-95"}`}
                style={isActive ? { background: text, color: "#fff" } : { background: bg, color: text }}
              >
                {`${stageLabel[key]} (${stageCounts[key]})`}
              </button>
            );
          })}
        </div>

        <div className="tw-flex tw-items-center tw-gap-1.5">
          <label htmlFor="rows-per-page" className="tw-text-xs tw-font-medium tw-text-gray-500">{t.rowsPerPage}</label>
          <input
            id="rows-per-page" type="number" min={1} max={MAX_PAGE_SIZE} value={pageSize}
            onChange={(e) => commitPageSize(e.target.value)}
            list="rows-per-page-presets"
            className="tw-w-20 tw-rounded-lg tw-border tw-border-gray-200 tw-bg-white tw-px-2.5 tw-py-1.5 tw-text-sm tw-text-gray-700 tw-shadow-sm focus:tw-border-blue-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-100"
          />
          <datalist id="rows-per-page-presets">
            {[10, 15, 25, 50, 100].map((n) => <option key={n} value={n} />)}
          </datalist>
        </div>

        {activeFilterCount > 0 && (
          <button onClick={clearAll} className="tw-text-xs tw-font-semibold tw-text-red-500 hover:tw-text-red-700 tw-underline">
            {t.clearFilters}
          </button>
        )}

        <CsvExportButton onClick={exportCsv} count={sortedRows.length} lang={lang} />

        <div className="tw-ml-auto tw-flex tw-items-center tw-gap-2">
          {/* เปิดใบงานเองได้เฉพาะ role ที่วางแผน PM ได้ — ชุดเดียวกับที่ backend เช็ค */}
          {PM_PLANNING_ROLES.includes(me?.role ?? "") && (
            <button
              type="button"
              onClick={() => router.push(`${PM_LIST_ROUTE}/create`)}
              className="tw-inline-flex tw-h-9 tw-items-center tw-justify-center tw-gap-1.5 tw-rounded-lg tw-bg-gray-900 tw-px-3.5 tw-text-sm tw-font-semibold tw-text-white tw-shadow-sm tw-transition-colors hover:tw-bg-black focus:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-gray-500"
            >
              <PlusIcon aria-hidden="true" className="tw-h-4 tw-w-4" />
              <span>{t.addWorkOrder}</span>
            </button>
          )}
        </div>
      </div>

      {/* ── Search ── */}
      <div className="tw-mb-3 tw-relative">
        <span className="tw-absolute tw-left-3 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400 tw-text-sm">🔍</span>
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t.searchPlaceholder}
          className="tw-w-full tw-rounded-xl tw-border tw-border-gray-200 tw-bg-white tw-py-2.5 tw-pl-9 tw-pr-4 tw-text-sm tw-text-gray-700 tw-shadow-sm tw-transition-all focus:tw-border-blue-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-100"
        />
        {search && (
          <button
            onClick={() => { setSearch(""); setPage(0); }}
            aria-label="clear search"
            className="tw-absolute tw-right-3 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400 hover:tw-text-gray-600 tw-text-lg tw-leading-none"
          >
            <span aria-hidden="true">×</span>
          </button>
        )}
      </div>

      <Card className="tw-overflow-hidden tw-border tw-border-blue-gray-100 tw-shadow-sm">
        <div className="tw-overflow-x-auto">
          <table className="tw-w-full tw-min-w-[1000px] tw-table-auto tw-text-left tw-text-sm">
            <thead>
              <tr className="tw-bg-gray-50 tw-text-xs tw-font-semibold tw-uppercase tw-tracking-wide tw-text-gray-500">
                <th className="tw-px-4 tw-py-3 tw-whitespace-nowrap">#</th>
                {columns.map((c) => {
                  const active = sortKey === c.key;
                  return (
                    <th
                      key={c.key}
                      className="tw-px-4 tw-py-3 tw-whitespace-nowrap"
                      aria-sort={active ? (sortDir === "asc" ? "ascending" : "descending") : "none"}
                    >
                      <button
                        type="button"
                        onClick={() => toggleSort(c.key)}
                        title={active && sortDir === "asc" ? t.sortDesc : t.sortAsc}
                        className={`tw-inline-flex tw-items-center tw-gap-1 tw-uppercase tw-transition-colors ${active ? "tw-text-blue-600" : "hover:tw-text-gray-700"}`}
                      >
                        {c.label}
                        <span aria-hidden="true" className={`tw-text-[10px] tw-leading-none ${active ? "tw-opacity-100" : "tw-opacity-30"}`}>
                          {active ? (sortDir === "asc" ? "▲" : "▼") : "↕"}
                        </span>
                      </button>
                    </th>
                  );
                })}
                <th className="tw-px-4 tw-py-3 tw-whitespace-nowrap">PDF</th>
                {isSuperAdmin && <th className="tw-px-4 tw-py-3" aria-label={t.deleteTitle} />}
              </tr>
            </thead>
            <tbody>
              {tableRows.length === 0 ? (
                <tr>
                  <td colSpan={columns.length + (isSuperAdmin ? 3 : 2)} className="tw-p-8 tw-text-center tw-text-gray-400">
                    {t.noResults(search || undefined)}
                  </td>
                </tr>
              ) : tableRows.map((r, i) => {
                const stage = stageOf(r);
                const style = STAGE_STYLE[stage];
                // PDF ให้โหลดได้เฉพาะใบที่อนุมัติปิดแล้ว (Closed)
                const pdfHref = stage === "closed" && r.file_url ? pdfUrlOf(r.file_url, lang) : "";
                return (
                  <tr
                    key={`${r.id}-${r.pm_type}-${i}`}
                    onClick={() => { void openReport(r); }}
                    title={`${r.kind === "wo" ? t.openPlanTitle : t.openReportTitle} · ${r.station_name || r.station_id}`}
                    className="tw-cursor-pointer tw-border-t tw-border-gray-100 hover:tw-bg-blue-50/30"
                  >
                    <td className="tw-px-4 tw-py-3 tw-text-gray-400">{page * pageSize + i + 1}</td>
                    <td className="tw-px-4 tw-py-3 tw-font-medium tw-text-gray-800">{r.station_name || r.station_id}</td>
                    {/* คอลัมน์นี้คือเลขใบงานฝั่ง Maximo เท่านั้น
                        เดิมถ้าไม่มีจะถอยไปโชว์ issue_id ของ iMPS ซึ่งคนละเลขกัน
                        อ่านแล้วนึกว่าเป็น WO ทั้งที่ใบนั้นไม่ได้ผูกกับ Maximo เลย */}
                    <td className="tw-px-4 tw-py-3 tw-text-gray-600">
                      <span className="tw-inline-flex tw-items-center tw-gap-1.5">
                        {r.wonum ? (
                          <span className="tw-font-mono">{r.wonum}</span>
                        ) : (
                          <span className="tw-text-gray-300" title={t.noWonum}>—</span>
                        )}
                        {/* เลขที่ Maximo ไม่รู้จัก — วางแผนไปก็ส่งสถานะกลับไม่ได้ */}
                        {r.exists_in_maximo === false && (
                          <span
                            title={t.notInMaximo}
                            className="tw-rounded tw-bg-red-100 tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-font-semibold tw-text-red-700"
                          >
                            !
                          </span>
                        )}
                      </span>
                    </td>
                    <td className="tw-px-4 tw-py-3 tw-whitespace-nowrap tw-text-gray-500">
                      {r.pm_date && r.pm_date !== "-"
                        ? new Date(r.pm_date).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })
                        : "-"}
                    </td>
                    <td className="tw-px-4 tw-py-3">
                      <button
                        onClick={(e) => { e.stopPropagation(); setStageFilter(stageFilter === stage ? null : stage); setPage(0); }}
                        title={stage === "rejected" ? r.reject_remark : undefined}
                        className="tw-whitespace-nowrap tw-rounded-full tw-px-2.5 tw-py-0.5 tw-text-xs tw-font-medium tw-transition-all hover:tw-opacity-80"
                        style={{ background: style.bg, color: style.text, outline: stageFilter === stage ? `2px solid ${style.text}` : "none" }}
                      >
                        {/* ป้ายหลักเป็นชุดสถานะคงที่ (ตรงกับ Maximo) — รอใครอยู่ไปอยู่บรรทัดรองข้างล่าง */}
                        {stageLabel[stage]}
                      </button>
                      {stage === "closed" && r.maximo_pending && (
                        <span
                          title={t.maximoPendingTitle}
                          className="tw-ml-1.5 tw-whitespace-nowrap tw-rounded-full tw-bg-red-100 tw-px-2 tw-py-0.5 tw-text-[10px] tw-font-semibold tw-text-red-700"
                        >
                          {t.maximoPending}
                        </span>
                      )}
                      {/* บรรทัดรอง: ใบหลายฝ่าย — ส่งแล้วกี่ฝ่าย / ติดอยู่ที่ใคร */}
                      {(() => {
                        if (stage !== "in_progress" && stage !== "rejected") return null;
                        const line = partyLine(r.parties, lang);
                        // backend รุ่นก่อน (ไม่มี parties[].state) — ใช้ vendor_review เดิม
                        const text = line?.text
                          ?? (r.vendor_review?.length ? t.vendorWait.replace("{p}", r.vendor_review.join(", ")) : "");
                        if (!text) return null;
                        return (
                          <div
                            title={text}
                            className={`tw-mt-1 tw-max-w-[280px] tw-text-[11px] tw-leading-snug ${line?.tone === "red" ? "tw-font-semibold tw-text-red-600" : "tw-text-amber-700"}`}
                          >
                            {text}
                          </div>
                        );
                      })()}
                    </td>
                    <td className="tw-px-4 tw-py-3 tw-text-center">
                      {pdfHref ? (
                        <a
                          href={pdfHref}
                          target="_blank" rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="tw-inline-flex tw-items-center tw-justify-center tw-rounded-lg tw-p-1.5 tw-text-red-600 hover:tw-bg-red-50 hover:tw-text-red-800"
                          title="PDF" aria-label="PDF"
                        >
                          <DocumentArrowDownIcon className="tw-h-5 tw-w-5" />
                        </a>
                      ) : (
                        <span className="tw-text-gray-300">-</span>
                      )}
                    </td>
                    {isSuperAdmin && (
                      <td className="tw-px-2 tw-py-3 tw-text-center">
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setDeleteError(""); setDeleteTarget(r); }}
                          title={t.deleteTitle}
                          aria-label={`${t.deleteTitle} · ${r.station_name || r.station_id} ${r.wonum || ""}`}
                          className="tw-inline-flex tw-items-center tw-justify-center tw-rounded-lg tw-p-1.5 tw-text-gray-400 hover:tw-bg-red-50 hover:tw-text-red-600"
                        >
                          <TrashIcon className="tw-h-5 tw-w-5" />
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="tw-flex tw-flex-col tw-items-center tw-gap-3 tw-border-t tw-border-gray-100 tw-px-4 tw-py-4 sm:tw-flex-row sm:tw-justify-between">
            <p className="tw-text-xs tw-text-gray-500">{t.pagination(from, to, sortedRows.length)}</p>
            <div className="tw-flex tw-items-center tw-gap-1">
              <button
                onClick={() => setPage(page - 1)} disabled={page === 0}
                className="tw-flex tw-h-8 tw-w-8 tw-items-center tw-justify-center tw-rounded-lg tw-border tw-border-gray-200 tw-text-sm tw-text-gray-600 hover:tw-bg-gray-50 disabled:tw-cursor-not-allowed disabled:tw-opacity-40"
              >‹</button>
              <span className="tw-px-2 tw-text-xs tw-text-gray-500">{`${page + 1} / ${totalPages}`}</span>
              <button
                onClick={() => setPage(page + 1)} disabled={page >= totalPages - 1}
                className="tw-flex tw-h-8 tw-w-8 tw-items-center tw-justify-center tw-rounded-lg tw-border tw-border-gray-200 tw-text-sm tw-text-gray-600 hover:tw-bg-gray-50 disabled:tw-cursor-not-allowed disabled:tw-opacity-40"
              >›</button>
            </div>
          </div>
        )}
      </Card>
      {/* ยืนยันลบ — pop-up แบบเดียวกับแพลตฟอร์ม (overlay + กล่อง max-w-md) */}
      {deleteTarget && (
        <div
          className="tw-fixed tw-inset-0 tw-z-[9999] tw-flex tw-items-center tw-justify-center tw-bg-black/50 tw-p-4"
          onClick={() => { if (!deleting) setDeleteTarget(null); }}
        >
          <div role="dialog" aria-modal="true" className="tw-w-full tw-max-w-md tw-rounded-2xl tw-bg-white tw-p-6 tw-shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="tw-mb-2 tw-flex tw-items-center tw-gap-2 tw-text-lg tw-font-bold tw-text-blue-gray-800">
              <TrashIcon className="tw-h-5 tw-w-5 tw-text-red-600" />
              {t.deleteTitle}
            </h3>
            <p className="tw-mb-1 tw-text-sm tw-font-semibold tw-text-blue-gray-800">
              {deleteTarget.station_name || deleteTarget.station_id}
              {deleteTarget.wonum && <span className="tw-ml-2 tw-font-mono tw-font-normal tw-text-blue-gray-500">{deleteTarget.wonum}</span>}
            </p>
            <p className="tw-text-sm tw-text-blue-gray-600">
              {deleteTarget.kind === "wo" ? t.deleteWoBody : deleteTarget.job_id ? t.deleteJobBody : t.deleteReportBody}
            </p>
            {deleteError && (
              <div className="tw-mt-3 tw-rounded-lg tw-border tw-border-red-200 tw-bg-red-50 tw-px-3 tw-py-2 tw-text-sm tw-text-red-700">
                {deleteError}
              </div>
            )}
            <div className="tw-mt-5 tw-flex tw-items-center tw-justify-end tw-gap-3">
              <button
                type="button"
                disabled={deleting}
                onClick={() => setDeleteTarget(null)}
                className="tw-rounded-lg tw-border tw-border-blue-gray-200 tw-px-4 tw-py-2 tw-text-sm tw-font-semibold tw-text-blue-gray-700 hover:tw-border-blue-gray-300 disabled:tw-opacity-50"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                disabled={deleting}
                onClick={() => { void confirmDelete(); }}
                className="tw-rounded-lg tw-bg-red-600 tw-px-4 tw-py-2 tw-text-sm tw-font-semibold tw-text-white hover:tw-bg-red-700 disabled:tw-cursor-not-allowed disabled:tw-opacity-50"
              >
                {deleting ? t.deleting : t.deleteAction}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
