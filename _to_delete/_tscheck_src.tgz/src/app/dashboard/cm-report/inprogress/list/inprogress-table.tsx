"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import CMInProgressForm from "@/app/dashboard/cm-report/inprogress/input_CMreport/components/checkList";
import CMOpenForm from "@/app/dashboard/cm-report/open/input_CMreport/components/checkList";
import {
  getCoreRowModel,
  getPaginationRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
  flexRender,
  type ColumnDef,
  type CellContext,
  type SortingState,
} from "@tanstack/react-table";
import {
  Button, Card, CardBody, CardHeader, Typography, CardFooter, Input,
} from "@material-tailwind/react";
import { ArrowUpTrayIcon, DocumentArrowDownIcon, TrashIcon } from "@heroicons/react/24/outline";
import { ChevronLeftIcon, ChevronRightIcon, ChevronUpDownIcon } from "@heroicons/react/24/solid";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Dialog, DialogHeader, DialogBody, DialogFooter } from "@material-tailwind/react";
import { useLanguage, type Lang } from "@/utils/useLanguage";
import { failureCodeLabel } from "@/app/dashboard/cm-report/lib/failureCode";
import { repairResultLabel } from "@/app/dashboard/cm-report/lib/repairResult";
import TableSkeletonRows, { TableBodySpacer } from "@/components/TableSkeletonRows";

// ==================== TRANSLATIONS ====================
const T = {
  deleteTitle: { th: "ยืนยันการลบใบงาน", en: "Confirm delete" },
  deleteWarn: { th: "การลบไม่สามารถย้อนกลับได้", en: "This action cannot be undone." },
  deleteConfirm: { th: "ลบใบงาน", en: "Delete" },
  deleteCancel: { th: "ยกเลิก", en: "Cancel" },
  deleting: { th: "กำลังลบ...", en: "Deleting..." },
  deleteFailedMsg: { th: "ลบไม่สำเร็จ: ", en: "Delete failed: " },
  // Page Header
  pageTitle: { th: "Corrective Maintenance Report", en: "Corrective Maintenance Report" },
  pageSubtitle: { th: "ค้นหาและดาวน์โหลดเอกสาร CM Report", en: "Search and download CM Report documents" },

  // Table Headers
  colNo: { th: "ลำดับ", en: "No." },
  colDocName: { th: "ชื่อเอกสาร", en: "Document Name" },
  colIssueId: { th: "รหัสเอกสาร", en: "Issue ID" },
  colSr: { th: "เลขที่ SR", en: "SR No." },
  colWo: { th: "เลขที่ WO", en: "WO No." },
  colFoundDate: { th: "วัน/เวลาที่แจ้ง", en: "Found Date/Time" },
  colReportedBy: { th: "ผู้แจ้งปัญหา", en: "Reported By" },
  colLocation: { th: "ตำแหน่งที่พบ", en: "Faulty Equipment" },
  colChargerNo: { th: "หมายเลขตู้", en: "Charger No." },
  colChargerSn: { th: "S/N ตู้", en: "Charger S/N" },
  colProblemDetails: { th: "ปัญหาที่พบ", en: "Problem Details" },
  colStatus: { th: "สถานะ", en: "Status" },
  colRepairResult: { th: "ผลการซ่อม", en: "Repair Result" },
  colInspector: { th: "ผู้เข้าแก้ไข", en: "Repairer" },

  // Pagination
  entriesPerPage: { th: "รายการต่อหน้า", en: "entries per page" },
  page: { th: "หน้า", en: "Page" },
  of: { th: "จาก", en: "of" },

  // Search
  search: { th: "ค้นหา", en: "Search" },

  // Loading / Empty States
  loading: { th: "กำลังโหลด...", en: "Loading..." },
  noData: { th: "ไม่มีข้อมูล", en: "No data" },
  selectStationFirst: { th: "กรุณาเลือกสถานีจากแถบด้านบนก่อน", en: "Please select a station from the top bar first" },
  noFile: { th: "ไม่มีไฟล์", en: "No file" },

  // Dialog
  dialogTitle: { th: "เลือกวันที่รายงาน", en: "Select Report Date" },
  dateLabel: { th: "วันที่", en: "Date" },
  statusLabel: { th: "สถานะ", en: "Status" },
  filesSelected: { th: "ไฟล์ที่เลือก:", en: "Selected files:" },
  filesUnit: { th: "ไฟล์", en: "file(s)" },

  // Alerts
  alertSelectStation: { th: "กรุณาเลือกสถานีก่อน", en: "Please select a station first" },
  alertPdfOnly: { th: "รองรับเฉพาะไฟล์ PDF เท่านั้น", en: "Only PDF files are supported" },
  alertInvalidDate: { th: "รูปแบบวันที่ไม่ถูกต้อง", en: "Invalid date format" },
  alertUploadFailed: { th: "อัพโหลดไม่สำเร็จ:", en: "Upload failed:" },
  alertUploadSuccess: { th: "อัพโหลดสำเร็จ", en: "Upload successful" },
  alertUploadError: { th: "เกิดข้อผิดพลาดระหว่างอัพโหลด", en: "An error occurred during upload" },
};

const t = (key: keyof typeof T, lang: Lang): string => T[key][lang];

// หมายเลขตู้/SN แยกเป็นคอลัมน์ของตัวเองแล้ว ตำแหน่งที่พบจึงเหลือแค่ชื่อ failure class
const chargerField = (v?: unknown) => String(v ?? "").trim();

type TData = {
  id?: string;
  doc_name?: string;
  issue_id?: string;
  cm_date: string;
  found_time?: string;
  position: string;
  office: string;
  reported_by?: string;
  repair_result?: string;
  location?: string;
  charger_no?: string;
  charger_sn?: string;
  problem_details?: string;
  status: string;
  inspector?: string;
  assignees?: string[];
  // Temporarily disabled: Maximo time must not hide In Progress rows.
  // maximo_time_logged?: boolean;
  source?: "cm" | "url"; // cm = ใบงานจากฟอร์ม (กดอนุมัติได้), url = ไฟล์ PDF ที่อัปโหลด
};

type Props = {
  token?: string;
  apiBase?: string;
};

const BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";

// ใบที่รออะไหล่/รอสภาพหน้างานและยังไม่มีช่าง จึงต้องกลับไปวางแผนใหม่
// ส่วน WO - wait for scheduled มีแผน/ช่างแล้ว ให้ planner เปิดฟอร์มกรอกผลซ่อมเหมือน technician
const PLANNING_WAIT_RESULTS: string[] = [];
const WAITING_ON_REPLAN_RESULTS = [
  "WO - wait for material", "WO - wait for spare part",
  "WO - wait for site condition", "WO - wait for site access",
];
const hasAssignedTechnician = (assignees?: string[]) =>
  Array.isArray(assignees) && assignees.some((assignee) => !!assignee?.trim());
const isPlanningWait = (v?: string, assignees?: string[]) => {
  const result = (v || "").trim();
  if (PLANNING_WAIT_RESULTS.includes(result)) return true;
  return WAITING_ON_REPLAN_RESULTS.includes(result) && !hasAssignedTechnician(assignees);
};

// Sub-tabs ของหน้า In Progress (มุมขวา) — filter ตาม repair_result ยกเว้น tab approve ที่ใช้ status "Wait for approve"
// legacy = ค่า repair_result เดิมก่อนเปลี่ยนชื่อ (รองรับข้อมูลเก่า)
const WO_SUBTABS = [
  { id: "all", th: "ทั้งหมด", en: "All", legacy: [] as string[] },
  { id: "scheduled", th: "WO - wait for scheduled", en: "WO - wait for scheduled", legacy: ["WO - wait for manpower"] },
  { id: "spare", th: "WO - wait for material", en: "WO - wait for material", legacy: ["WO - wait for spare part"] },
  { id: "site", th: "WO - wait for site condition", en: "WO - wait for site condition", legacy: ["WO - wait for site access"] },
  { id: "approve", th: "WO - wait for approve", en: "WO - wait for approve", legacy: [] as string[] },
] as const;

export default function CMInProgressReportPage({ token, apiBase = BASE }: Props) {
  const { lang } = useLanguage();
  // true au depart : le squelette doit occuper la hauteur finale des le premier
  // rendu, sinon le tableau grandit de 0 a N lignes quand les donnees arrivent.
  const [loading, setLoading] = useState(true);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [data, setData] = useState<TData[]>([]);
  const [filtering, setFiltering] = useState("");
  const [woSubTab, setWoSubTab] = useState<string>("all"); // sub-tab มุมขวา
  const [currentUsername, setCurrentUsername] = useState("");
  const [currentRole, setCurrentRole] = useState("");
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  // role ที่มีหน้าที่วางแผน — ใช้เลือกว่าจะเปิดฟอร์มวางแผนหรือฟอร์มกรอกผลซ่อม
  const canPlanRole = ["admin", "owner", "planner"].includes(currentRole.trim().toLowerCase());
  const canDelete = isSuperAdmin; // ลบถาวรได้เฉพาะ super admin (ซ่อนตอน impersonate role อื่น)
  const [deleteTarget, setDeleteTarget] = useState<TData | null>(null);
  const [deleting, setDeleting] = useState(false);
  // planner (หรือ admin) ยกเลิกใบงานที่ยังไม่ปิด → Cancelled
  // หน้า In Progress list ไม่มีปุ่มยกเลิกด้านนอกแล้ว (จัดการยกเลิก/ตีกลับตั้งแต่ด่าน SR/วางแผน)
  // planner/admin และ technician ที่ได้รับมอบหมาย ยกเลิก WO จากหน้า In Progress ได้
  // Cancellation is handled from the In Progress form; the list has no Cancel column.
  const canCancel = false;

  const todayStr = useMemo(() => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }, []);

  const searchParams = useSearchParams();
  const [stationId, setStationId] = useState<string | null>(null);
  const [sn, setSn] = useState<string | null>(null);

  useEffect(() => {
    const sidFromUrl = searchParams.get("station_id");
    if (sidFromUrl) {
      setStationId(sidFromUrl);
      localStorage.setItem("selected_station_id", sidFromUrl);
      return;
    }
    const sidLocal = localStorage.getItem("selected_station_id");
    setStationId(sidLocal);
  }, [searchParams]);

  // ตู้ที่เลือกไว้ — มีค่า = เข้ามาจากการ์ดตู้ชาร์จ, ไม่มี = มุมมองระดับสถานี
  useEffect(() => {
    const snFromUrl = searchParams.get("sn");
    if (snFromUrl) {
      setSn(snFromUrl);
      localStorage.setItem("selected_sn", snFromUrl);
      return;
    }
    setSn(localStorage.getItem("selected_sn"));
  }, [searchParams]);

  // หน้า WO แสดงทั้งงานที่กำลังซ่อมและงานที่รออนุมัติ (backend รองรับหลายค่า คั่นด้วย ,)
  const statusFromTab = "in progress,wait for approve,wo - wait for approve";

  const router = useRouter();
  const pathname = usePathname();
  const editId = searchParams.get("edit_id") ?? "";
  const mode: "list" | "form" =
    (searchParams.get("view") === "form" || !!editId) ? "form" : "list";

  const setView = (view: "list" | "form", { replace = false } = {}) => {
    const params = new URLSearchParams(searchParams.toString());
    if (view === "form") {
      params.set("view", "form");
    } else {
      params.delete("view");
      params.delete("edit_id");
      params.delete("planning");
    }
    router[replace ? "replace" : "push"](`${pathname}?${params.toString()}`, { scroll: false });
  };

  const useHttpOnlyCookie = true;
  function makeHeaders(): Record<string, string> {
    const h: Record<string, string> = { "Content-Type": "application/json" };
    if (!useHttpOnlyCookie) {
    }
    return h;
  }
  const fetchOpts: RequestInit = {
    headers: makeHeaders(),
    ...(useHttpOnlyCookie ? { credentials: "include" as const } : {}),
  };

  // Date formatting with language support
  function formatDate(iso?: string, currentLang: Lang = lang) {
    if (!iso) return "-";

    const d = /^\d{4}-\d{2}-\d{2}$/.test(iso)
      ? new Date(iso + "T00:00:00Z")
      : new Date(iso);

    if (isNaN(d.getTime())) return "-";

    return d.toLocaleDateString(
      currentLang === "en" ? "en-GB" : "th-TH-u-ca-gregory",
      {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        timeZone: "UTC",
      }
    );
  }

  function toISODateOnly(s?: string) {
    if (!s) return "";
    try {
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
      const d = new Date(s);
      if (isNaN(d.getTime())) return "";
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      return `${yyyy}-${mm}-${dd}`;
    } catch {
      return "";
    }
  }

  function resolveFileHref(v: any, apiBase: string) {
    if (!v) return "";
    if (typeof v === "object") {
      const c = v.url ?? v.href ?? v.link ?? "";
      return resolveFileHref(c, apiBase);
    }
    const s = String(v).trim();
    if (!s) return "";
    try { return new URL(s).toString(); } catch { }
    if (s.startsWith("/")) return `${apiBase}${s}`;
    if (/^[a-f0-9]{24}$/i.test(s)) return `${apiBase}/files/${s}`;
    return `${apiBase}/${s}`;
  }

  function getStatusText(it: any) {
    return String(it?.status ?? it?.job?.status ?? "").trim();
  }

  const fetchRows = async () => {
    if (!stationId) { setData([]); setLoading(false); return; }
    setLoading(true);

    try {
      const makeURL = (path: string) => {
        const u = new URL(`${apiBase}${path}`);
        u.searchParams.set("station_id", stationId);
        u.searchParams.set("page", "1");
        u.searchParams.set("pageSize", "50");
        u.searchParams.set("status", statusFromTab);
        // เข้ามาจากการ์ดตู้ชาร์จ → เห็นเฉพาะใบของตู้นั้น, ระดับสถานี → เห็นทุกใบ
        if (sn) u.searchParams.set("sn", sn);
        return u.toString();
      };

      const [cmRes, urlRes] = await Promise.allSettled([
        fetch(makeURL("/cmreport/list"), fetchOpts),
        fetch(makeURL("/cmurl/list"), fetchOpts),
      ]);

      let cmItems: any[] = [];
      let urlItems: any[] = [];

      if (cmRes.status === "fulfilled" && cmRes.value.ok) {
        const j = await cmRes.value.json();
        if (Array.isArray(j?.items)) cmItems = j.items;
      }
      if (urlRes.status === "fulfilled" && urlRes.value.ok) {
        const j = await urlRes.value.json();
        if (Array.isArray(j?.items)) urlItems = j.items;
      }

      // แท็บ In Progress = กำลังซ่อม + รออนุมัติปิดงาน
      // "wait for approve" ต้องเป็นด่านปิดงาน (stage != cs_approval) เท่านั้น — ด่าน cs ไปอยู่แท็บ Open
      const filterByStatus = (it: any) => {
        const rawStatuses = [it?.status, it?.job?.status]
          .filter((value) => value != null)
          .map((value) => String(value).trim().toLowerCase());
        const s = rawStatuses[0] || "";
        const stage = String(it?.stage ?? "").trim().toLowerCase();
        const repairResult = String(it?.repair_result ?? it?.job?.repair_result ?? "").trim().toLowerCase();
        if (rawStatuses.includes("wo - wait for approve") || repairResult === "wo - wait for approve") return true;
        if (rawStatuses.includes("in progress")) return true;
        if (rawStatuses.includes("wait for approve")) return stage !== "cs_approval";
        return false;
      };

      // Temporarily disabled: keep rows visible even after Maximo time is logged.
      cmItems = cmItems.filter(filterByStatus);
      // Re-enable when needed:
      // cmItems = cmItems.filter((it) => filterByStatus(it) && !it.maximo_time_logged);
      urlItems = urlItems.filter(filterByStatus);

      const cmRows: TData[] = cmItems.map((it: any) => {
        const isoDay = toISODateOnly(it.cm_date ?? it.createdAt ?? "");
        const rawUploaded =
          it.file_url
          ?? (Array.isArray(it.urls) ? (it.urls[0]?.url ?? it.urls[0]) : it.url)
          ?? it.file
          ?? it.path;

        const uploadedUrl = resolveFileHref(rawUploaded, apiBase);

        function extractId(x: any): string {
          if (!x) return "";
          const raw = (x._id !== undefined ? x._id : x.id) ?? "";
          if (raw && typeof raw === "object") {
            return raw.$oid || raw.oid || raw.$id || "";
          }
          const s = String(raw || "");
          return /^[a-fA-F0-9]{24}$/.test(s) ? s : "";
        }

        const id = extractId(it);
        const generatedUrl = id ? `${apiBase}/pdf/${encodeURIComponent(id)}/file` : "";
        const fileUrl = uploadedUrl || generatedUrl;

        return {
          id,
          doc_name: it.doc_name || "",
          issue_id: it.issue_id || "",
          cm_date: isoDay,
          found_time: it.found_time || "",
          position: isoDay,
          office: fileUrl,
          reported_by: it.reported_by || "",
          inspector: it.inspector || "",
          repair_result: it.repair_result || "",
          assignees: Array.isArray(it.assignees)
            ? it.assignees
            : (Array.isArray(it.job?.assignees) ? it.job.assignees : []),
          // คอลัมน์ "ตำแหน่งที่พบ" โชว์ตู้ที่ใบงานอ้างถึง ("Charger 1 (SN)") — ใบระดับสถานี
          // หรือใบเก่าที่ไม่ผูกตู้ ไม่มี label ให้ใช้ จึงถอยไปใช้ชื่อ failure class ของ Maximo
          location: it.faulty_equipment_label || failureCodeLabel(it.faulty_equipment) || "-",
          charger_no: chargerField(it.charger_no),
          charger_sn: chargerField(it.charger_sn),
          problem_details: it.problem_details || "",
          status: getStatusText(it) || "-",
          source: "cm" as const,
        };
      });

      const urlRows: TData[] = urlItems.map((it: any) => {
        const isoDay = toISODateOnly(it.cm_date ?? it.reportDate ?? it.createdAt ?? "");
        const raw =
          it.file_url
          ?? (Array.isArray(it.urls) ? (it.urls[0]?.url ?? it.urls[0]) : it.url)
          ?? it.file
          ?? it.path;

        return {
          id: it.id || it._id || "",
          doc_name: it.doc_name || "",
          issue_id: it.issue_id || "",
          cm_date: isoDay,
          found_time: it.found_time || "",
          position: isoDay,
          office: resolveFileHref(raw, apiBase),
          reported_by: it.reported_by || "",
          inspector: it.inspector || "",
          assignees: Array.isArray(it.assignees)
            ? it.assignees
            : (Array.isArray(it.job?.assignees) ? it.job.assignees : []),
          location: it.faulty_equipment_label || failureCodeLabel(it.faulty_equipment) || "-",
          charger_no: chargerField(it.charger_no),
          charger_sn: chargerField(it.charger_sn),
          problem_details: it.problem_details || "",
          status: getStatusText(it) || "-",
          repair_result: it.repair_result || it.job?.repair_result || "",
          source: "url" as const,
        };
      });

      const allRows = [...cmRows, ...urlRows].sort((a, b) => {
        const da = (a.position ?? "") as string;
        const db = (b.position ?? "") as string;
        return da < db ? 1 : da > db ? -1 : 0;
      });

      if (!allRows.length) { setData([]); return; }

      setData(allRows);
    } catch (err) {
      console.error("fetch both lists error:", err);
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  // ดึงบัญชีผู้ใช้ปัจจุบัน (ใช้ตัดสินสิทธิ์ลบใบงาน / อนุมัติปิดใบงาน)
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await fetch(`${apiBase}/me`, fetchOpts);
        if (res.ok) {
          const d = await res.json();
          if (alive) {
            setCurrentUsername(d?.username ?? "");
            setCurrentRole(d?.role ?? "");
            setIsSuperAdmin(!!d?.is_super_admin);
          }
        }
      } catch { /* noop */ }
    })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiBase]);

  // ลบใบงาน (เฉพาะบัญชี thatsawan)
  // เปิด dialog ยืนยันแทน window.confirm ให้เหมือนปุ่มอื่นในระบบ
  const handleDelete = (row: TData) => {
    if (!canDelete) return;
    if (!row.id || !stationId) return;
    setDeleteTarget(row);
  };

  const confirmDelete = async () => {
    const row = deleteTarget;
    if (!row?.id || !stationId) return;
    setDeleting(true);
    try {
      const url = `${apiBase}/cmreport/${encodeURIComponent(row.id)}?station_id=${encodeURIComponent(stationId)}`;
      const res = await fetch(url, { method: "DELETE", ...fetchOpts });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j?.detail || `HTTP ${res.status}`);
      }
      await fetchRows();
      setDeleteTarget(null);
    } catch (err: any) {
      alert(t("deleteFailedMsg", lang) + (err?.message ?? err));
    } finally {
      setDeleting(false);
    }
  };

  const handleCancel = async (row: TData) => {
    if (!canCancel) return;
    if (!row.id || !stationId) return;
    const label = row.doc_name || row.issue_id || row.id;
    const remark = window.prompt(
      lang === "th"
        ? `ยกเลิกใบงาน "${label}" — ระบุเหตุผล (ถ้ามี):`
        : `Cancel work order "${label}" — reason (optional):`,
      ""
    );
    if (remark === null) return; // กด cancel ใน prompt = ไม่ทำอะไร
    try {
      const url = `${apiBase}/cmreport/${encodeURIComponent(row.id)}/cancel?station_id=${encodeURIComponent(stationId)}`;
      const res = await fetch(url, {
        method: "POST",
        ...fetchOpts,
        headers: { ...(fetchOpts as any).headers, "Content-Type": "application/json" },
        body: JSON.stringify({ remark: remark || "" }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j?.detail || `HTTP ${res.status}`);
      }
      await fetchRows();
    } catch (err: any) {
      alert((lang === "th" ? "ยกเลิกไม่สำเร็จ: " : "Cancel failed: ") + (err?.message ?? err));
    }
  };

  // ✅ Auto-refresh: refetch เมื่อกลับจาก form → list
  useEffect(() => {
    if (mode !== "list") return;
    let alive = true;
    (async () => { await fetchRows(); })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiBase, stationId, sn, mode]);

  const columns: ColumnDef<TData, unknown>[] = useMemo(() => [
    {
      id: "no",
      header: () => t("colNo", lang),
      enableSorting: false,
      size: 60,
      minSize: 50,
      maxSize: 80,
      cell: (info: CellContext<TData, unknown>) => {
        const { pageIndex, pageSize } = info.table.getState().pagination;
        return pageIndex * pageSize + info.row.index + 1;
      },
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.doc_name || "—",
      id: "doc_name",
      header: () => t("colDocName", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 150,
      minSize: 100,
      maxSize: 200,
      meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      // เลข SR ต้นเรื่อง — อิงลำดับเดียวกับ issue_id (CM-001 → SR001)
      accessorFn: (row) => {
        const m = String(row.issue_id || "").match(/(\d+)/);
        return m ? `SR${m[1].padStart(3, "0")}` : "—";
      },
      id: "sr_no",
      header: () => t("colSr", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 120,
      minSize: 90,
      maxSize: 160,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      // In Progress = ใบสั่งงาน (WO) — แสดงเลข WO### อิงลำดับเดียวกับ issue_id (CM-001 → WO001)
      accessorFn: (row) => {
        const m = String(row.issue_id || "").match(/(\d+)/);
        return m ? `WO${m[1].padStart(3, "0")}` : "—";
      },
      id: "wo_no",
      header: () => t("colWo", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 140,
      minSize: 100,
      maxSize: 180,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.charger_no || "-",
      id: "charger_no",
      header: () => t("colChargerNo", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 100,
      minSize: 70,
      maxSize: 130,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.charger_sn || "-",
      id: "charger_sn",
      header: () => t("colChargerSn", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 150,
      minSize: 100,
      maxSize: 220,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.cm_date,
      id: "found_date",
      header: () => t("colFoundDate", lang),
      cell: (info: CellContext<TData, unknown>) => {
        const time = info.row.original.found_time || "";
        return (
          <span className="tw-whitespace-nowrap">
            {formatDate(info.getValue() as string, lang)}{time ? ` ${time}` : ""}
          </span>
        );
      },
      size: 140,
      minSize: 110,
      maxSize: 180,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.reported_by || "-",
      id: "reported_by",
      header: () => t("colReportedBy", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 120,
      minSize: 80,
      maxSize: 160,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.location || "-",
      id: "location",
      header: () => t("colLocation", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 150,
      minSize: 100,
      maxSize: 200,
      meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      accessorFn: (row) => row.problem_details || "-",
      id: "problem_details",
      header: () => t("colProblemDetails", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span
          className="tw-block tw-truncate tw-max-w-[200px]"
          title={info.getValue() as string}
        >
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 200,
      minSize: 120,
      maxSize: 300,
      meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      accessorFn: (row) => row.repair_result || "-",
      id: "repair_result",
      header: () => t("colRepairResult", lang),
      cell: (info: CellContext<TData, unknown>) => {
        // ค่าใน DB เป็นภาษาอังกฤษเสมอ — แปลเฉพาะตอนแสดง (title ยังเป็นค่าดิบไว้ตรวจสอบ)
        const raw = String(info.getValue() ?? "");
        return (
          <span className="tw-block tw-truncate" title={raw}>
            {repairResultLabel(raw, lang) || "-"}
          </span>
        );
      },
      size: 150,
      minSize: 100,
      maxSize: 220,
      meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      accessorFn: (row) => row.status ?? "-",
      id: "status",
      header: () => t("colStatus", lang),
      cell: (info: CellContext<TData, unknown>) => {
        const s = String(info.getValue() ?? "-");
        const sl = s.toLowerCase();
        const color =
          sl === "open" ? "tw-bg-green-100 tw-text-green-800" :
            sl === "complete" || sl === "closed" || sl === "close" ? "tw-bg-gray-200 tw-text-gray-800" :
              sl === "wait for approve" ? "tw-bg-purple-100 tw-text-purple-800" :
                sl === "in progress" || sl === "ongoing" ? "tw-bg-amber-100 tw-text-amber-800" :
                  "tw-bg-blue-gray-100 tw-text-blue-gray-800";
        return (
          <span className={`tw-inline-block tw-whitespace-nowrap tw-px-2 sm:tw-px-2.5 tw-py-0.5 sm:tw-py-1 tw-rounded-full tw-text-[10px] sm:tw-text-xs tw-font-medium ${color}`}>
            {s}
          </span>
        );
      },
      size: 100,
      minSize: 80,
      maxSize: 140,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.inspector || "-",
      id: "inspector",
      header: () => t("colInspector", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 120,
      minSize: 80,
      maxSize: 160,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    // ปุ่มอนุมัติย้ายไปอยู่ในฟอร์มแล้ว (เปิดใบงานเพื่ออ่านรายละเอียดก่อนอนุมัติ) — ไม่มีคอลัมน์อนุมัติในตาราง
    ...(canCancel ? [{
      id: "cancel",
      header: () => (lang === "th" ? "ยกเลิก" : "Cancel"),
      enableSorting: false,
      size: 90,
      minSize: 80,
      maxSize: 120,
      cell: (info: CellContext<TData, unknown>) => {
        const s = String(info.row.original.status ?? "").toLowerCase();
        if (s === "closed" || s === "cancelled") return <span className="tw-text-blue-gray-300">—</span>;
        return (
          <button
            type="button"
            onClick={(e) => {
              // ปุ่มในแถว: กันไม่ให้ event ลามไปโดน onClick ของ <tr> ที่เปิดฟอร์ม
              e.stopPropagation();
              handleCancel(info.row.original);
            }}
            title={lang === "th" ? "ยกเลิกใบงาน" : "Cancel work order"}
            className="tw-inline-flex tw-items-center tw-justify-center tw-px-2.5 tw-h-8 tw-rounded-lg tw-text-xs tw-font-medium tw-text-red-600 tw-border tw-border-red-500 hover:tw-text-white hover:tw-bg-red-500 tw-transition-all"
          >
            {lang === "th" ? "ยกเลิก" : "Cancel"}
          </button>
        );
      },
      meta: { headerAlign: "center", cellAlign: "center" },
    } as ColumnDef<TData, unknown>] : []),
    ...(canDelete ? [{
      id: "actions",
      header: () => (lang === "th" ? "ลบ" : "Delete"),
      enableSorting: false,
      size: 70,
      minSize: 60,
      maxSize: 90,
      cell: (info: CellContext<TData, unknown>) => (
        <button
          type="button"
          onClick={(e) => {
            // แถวมี onClick เปิดฟอร์ม — ต้องหยุด event ไม่ให้ลามขึ้นไป ไม่งั้นกดลบแล้วเด้งเข้าฟอร์ม
            e.stopPropagation();
            handleDelete(info.row.original);
          }}
          title={lang === "th" ? "ลบใบงาน" : "Delete work order"}
          className="tw-inline-flex tw-items-center tw-justify-center tw-w-8 tw-h-8 tw-rounded-lg tw-text-red-500 hover:tw-text-white hover:tw-bg-red-500 tw-transition-all"
        >
          <TrashIcon className="tw-w-4 tw-h-4" />
        </button>
      ),
      meta: { headerAlign: "center", cellAlign: "center" },
    } as ColumnDef<TData, unknown>] : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
  ], [lang, canDelete, canCancel, stationId]);

  // กรองตาม sub-tab WO ที่มุมขวา — label ของแต่ละ tab = ค่า repair_result
  // ยกเว้น tab "approve" = คิวรออนุมัติจริง (status Wait for approve หรือใบเก่าที่ mark repair_result ไว้)
  const filteredData = useMemo(() => {
    if (woSubTab === "all") return data;
    if (woSubTab === "approve") {
      return data.filter(
        (r) =>
          r.status.trim().toLowerCase() === "wait for approve" ||
          (r.repair_result ?? "") === "WO - wait for approve"
      );
    }
    const sub = WO_SUBTABS.find((s) => s.id === woSubTab);
    // match ค่าใหม่ + ค่าเก่าที่เปลี่ยนชื่อแล้ว (backward-compat)
    const targets = [sub?.en ?? "", ...(sub?.legacy ?? [])].filter(Boolean);
    return data.filter((r) => targets.includes(r.repair_result ?? ""));
  }, [data, woSubTab]);

  const table = useReactTable({
    data: filteredData,
    columns,
    state: { globalFilter: filtering, sorting },
    onSortingChange: setSorting,
    onGlobalFilterChange: setFiltering,
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    columnResizeMode: "onChange",
  });

  // เปลี่ยน sub-tab แล้วกลับไปหน้าแรกของตาราง
  useEffect(() => {
    table.setPageIndex(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [woSubTab]);


  const goList = () => {
    const params = new URLSearchParams(searchParams.toString());
    params.delete("view");
    params.delete("edit_id");
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  function goEdit(row: TData) {
    if (!row?.id) return;
    const params = new URLSearchParams(searchParams.toString());
    params.set("view", "form");
    params.set("edit_id", row.id);
    // ใบที่รออะไหล่/รอหน้างานและยังไม่มีช่าง: planner/admin/owner ไปหน้าวางแผน
    // WO - wait for scheduled ข้ามการวางแผนซ้ำและเปิดฟอร์มกรอกผลซ่อมเหมือน technician
    if (isPlanningWait(row.repair_result, row.assignees) && canPlanRole) params.set("planning", "1");
    else params.delete("planning");
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  }

  // Handle row click
  const handleRowClick = (row: TData) => {
    if (row?.id) {
      goEdit(row);
    }
  };

  const showPlanningForm = searchParams.get("planning") === "1";

  if (mode === "form") {
    return (
      <div className="tw-mt-4 sm:tw-mt-6 lg:tw-mt-8">
        {showPlanningForm ? <CMOpenForm /> : <CMInProgressForm />}
      </div>
    );
  }

  return (
    <>
      {/* Main Card */}
      <Card className="tw-border tw-border-blue-gray-100 tw-shadow-sm tw-mt-4 sm:tw-mt-6 lg:tw-mt-8 tw-mx-2 sm:tw-mx-4 lg:tw-mx-0 tw-rounded-xl lg:tw-rounded-2xl tw-overflow-hidden">

        {/* Card Header */}
        {/* <CardHeader floated={false} shadow={false} className="tw-p-3 sm:tw-p-4 lg:tw-p-6 tw-rounded-none tw-m-0"> */}
        <CardHeader floated={false} shadow={false} className="tw-p-3 sm:tw-p-4 lg:tw-p-6 tw-rounded-none tw-m-0 tw-bg-gradient-to-r tw-from-white tw-to-blue-gray-50/30">
          <div className="tw-flex tw-flex-col sm:tw-flex-row sm:tw-items-center sm:tw-justify-between tw-gap-3 sm:tw-gap-4">
            {/* Title Section */}
            <div className="tw-min-w-0 tw-flex-1">
              <Typography
                variant="h5"
                color="blue-gray"
                className="tw-text-sm sm:tw-text-base lg:tw-text-lg tw-leading-tight tw-font-semibold"
              >
                {t("pageTitle", lang)}
              </Typography>
              <Typography
                variant="small"
                className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-leading-relaxed tw-font-normal tw-text-blue-gray-400 tw-mt-0.5"
              >
                {t("pageSubtitle", lang)}
              </Typography>
            </div>

            {/* Sub-tabs (มุมขวา) — UI only */}
            <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-1.5 tw-flex-shrink-0 sm:tw-justify-end">
              {WO_SUBTABS.map((st) => {
                const active = woSubTab === st.id;
                return (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setWoSubTab(st.id)}
                    className={`tw-rounded-lg tw-px-3 tw-py-1.5 tw-text-[11px] sm:tw-text-xs tw-font-medium tw-whitespace-nowrap tw-transition-all tw-border ${active
                      ? "tw-bg-gray-900 tw-text-white tw-border-gray-900 tw-shadow-sm"
                      : "tw-bg-white tw-text-blue-gray-600 tw-border-blue-gray-200 hover:tw-bg-blue-gray-50 hover:tw-text-blue-gray-800"
                      }`}
                  >
                    {/* "ทั้งหมด" ไม่ใช่ค่า repair_result เลยแปลเองในตาราง ที่เหลือใช้ป้ายชุดเดียวกับฟอร์ม */}
                    {st.id === "all"
                      ? (lang === "en" ? st.en : st.th)
                      : repairResultLabel(st.en, lang)}
                  </button>
                );
              })}
            </div>

          </div>
        </CardHeader>

        {/* Card Body - Search & Entries per page */}
        <CardBody className="tw-px-3 sm:tw-px-4 lg:tw-px-6 tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-border-t tw-border-blue-gray-50">
          <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-stretch sm:tw-items-center tw-gap-2.5 sm:tw-gap-3 lg:tw-gap-4">

            {/* Entries per page */}
            <div className="tw-flex tw-items-center tw-gap-1.5 sm:tw-gap-2 tw-flex-shrink-0">
              <select
                value={table.getState().pagination.pageSize}
                onChange={(e) => table.setPageSize(Number(e.target.value))}
                className="tw-border tw-border-blue-gray-200 tw-py-1.5 sm:tw-py-2 tw-px-2 sm:tw-px-3 tw-rounded-lg tw-text-xs sm:tw-text-sm tw-w-14 sm:tw-w-16 lg:tw-w-20 tw-bg-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-500 focus:tw-border-transparent tw-cursor-pointer"
              >
                {[5, 10, 15, 20, 25, 50].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
              <Typography
                variant="small"
                className="tw-text-blue-gray-500 tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-whitespace-nowrap"
              >
                {t("entriesPerPage", lang)}
              </Typography>
            </div>

            {/* Spacer */}
            <div className="tw-flex-1 tw-hidden sm:tw-block" />

            {/* Search */}
            <div className="tw-w-full sm:tw-w-48 lg:tw-w-64">
              <Input
                value={filtering}
                onChange={(e) => setFiltering(e.target.value)}
                label={t("search", lang)}
                crossOrigin={undefined}
              />
            </div>
          </div>
        </CardBody>

        {/* Table Content */}
        <CardFooter className="tw-p-0">
          <div className="tw-relative tw-w-full tw-overflow-x-auto tw-overflow-y-hidden tw-scroll-smooth tw--webkit-overflow-scrolling-touch">
            <table className="tw-w-full tw-text-left tw-min-w-[600px]">
              {/* Table Header */}
              {/* <thead className="tw-bg-gray-50/80 tw-sticky tw-top-0 tw-backdrop-blur-sm"> */}
              <thead className="tw-bg-gradient-to-r tw-from-gray-900 tw-to-gray-800 tw-sticky tw-top-0">
                {table.getHeaderGroups().map((hg) => (
                  <tr key={hg.id}>
                    {hg.headers.map((header) => {
                      const canSort = header.column.getCanSort();
                      const align = (header.column.columnDef as any).meta?.headerAlign ?? "left";
                      return (
                        <th
                          key={header.id}
                          onClick={canSort ? header.column.getToggleSortingHandler() : undefined}
                          // className={`tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4 tw-uppercase !tw-text-blue-gray-500 !tw-font-semibold tw-whitespace-nowrap tw-border-b tw-border-blue-gray-100
                          //   ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}
                          //   ${canSort ? "tw-cursor-pointer hover:tw-bg-gray-100 tw-transition-colors tw-select-none" : ""}`}
                          className={`tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4 tw-uppercase !tw-font-semibold tw-whitespace-nowrap tw-border-b tw-border-gray-700
                            ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}
                            ${canSort ? "tw-cursor-pointer hover:tw-bg-gray-700 tw-transition-colors tw-select-none" : ""}`}
                        >
                          {canSort ? (
                            <Typography
                              color="blue-gray"
                              // className={`tw-flex tw-items-center tw-gap-0.5 sm:tw-gap-1 tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-60
                              className={`tw-flex tw-items-center tw-gap-0.5 sm:tw-gap-1 tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white
                                ${align === "center" ? "tw-justify-center" : align === "right" ? "tw-justify-end" : "tw-justify-start"}`}
                            >
                              {flexRender(header.column.columnDef.header, header.getContext())}
                              {/* <ChevronUpDownIcon strokeWidth={2} className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5 lg:tw-h-4 lg:tw-w-4 tw-flex-shrink-0" /> */}
                              <ChevronUpDownIcon strokeWidth={2} className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5 lg:tw-h-4 lg:tw-w-4 tw-flex-shrink-0 tw-text-white/60" />
                            </Typography>
                          ) : (
                            <Typography
                              color="blue-gray"
                              // className={`tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-60
                              className={`tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white
                                ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}`}
                            >
                              {flexRender(header.column.columnDef.header, header.getContext())}
                            </Typography>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                ))}
              </thead>

              {/* Table Body */}
              <tbody className="tw-divide-y tw-divide-blue-gray-50">
                {loading ? (
                      /* โครงร่างสูงเท่าหน้าจริง — กัน layout shift ตอนข้อมูลมาถึง */
                      <TableSkeletonRows rows={table.getState().pagination.pageSize} cols={columns.length} rowHeight="var(--table-row-h)" />
                ) : table.getRowModel().rows.length ? (
                  table.getRowModel().rows.map((row, index) => (
                    <tr
                      key={row.id}
                      onClick={() => handleRowClick(row.original)}
                      // className={`tw-transition-colors hover:tw-bg-blue-50/50 tw-cursor-pointer ${index % 2 === 0 ? 'tw-bg-white' : 'tw-bg-gray-50/30'}`}
                      className={`tw-transition-colors hover:tw-bg-blue-50/40 hover:tw-shadow-[inset_3px_0_0_0_#2196F3] tw-cursor-pointer ${index % 2 === 0 ? 'tw-bg-white' : 'tw-bg-blue-gray-50/30'}`}
                    >
                      {row.getVisibleCells().map((cell) => {
                        const align = (cell.column.columnDef as any).meta?.cellAlign ?? "left";
                        return (
                          <td
                            key={cell.id}
                            className={`tw-align-middle tw-border-0 tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4
                              ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}`}
                          >
                            <Typography
                              variant="small"
                              className="!tw-font-normal !tw-text-blue-gray-700 tw-text-[11px] sm:tw-text-xs lg:tw-text-sm"
                            >
                              {flexRender(cell.column.columnDef.cell, cell.getContext())}
                            </Typography>
                          </td>
                        );
                      })}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={columns.length} className="tw-text-center tw-py-10 sm:tw-py-12 lg:tw-py-16">
                      <div className="tw-flex tw-flex-col tw-items-center tw-gap-2 sm:tw-gap-3">
                        <div className="tw-w-10 tw-h-10 sm:tw-w-12 sm:tw-h-12 lg:tw-w-16 lg:tw-h-16 tw-rounded-full tw-bg-blue-gray-50 tw-flex tw-items-center tw-justify-center">
                          <DocumentArrowDownIcon className="tw-w-5 tw-h-5 sm:tw-w-6 sm:tw-h-6 lg:tw-w-8 lg:tw-h-8 tw-text-blue-gray-300" />
                        </div>
                        <span className="tw-text-blue-gray-400 tw-text-xs sm:tw-text-sm tw-font-medium">
                          {!stationId ? t("selectStationFirst", lang) : t("noData", lang)}
                        </span>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {/* complète la page jusqu'à pageSize lignes : le pied de tableau ne bouge plus */}
            <TableBodySpacer
              pageSize={table.getState().pagination.pageSize}
              shown={loading ? table.getState().pagination.pageSize : table.getRowModel().rows.length}
            />
          </div>
        </CardFooter>

        {/* Pagination */}
        {/* <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-center tw-justify-between tw-gap-2 sm:tw-gap-3 tw-p-2.5 sm:tw-p-3 lg:tw-p-4 tw-border-t tw-border-blue-gray-50 tw-bg-gray-50/30"> */}
        <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-center tw-justify-between tw-gap-2 sm:tw-gap-3 tw-p-2.5 sm:tw-p-3 lg:tw-p-4 tw-border-t tw-border-blue-gray-100">
          <Typography variant="small" className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-text-blue-gray-600 tw-order-2 sm:tw-order-1">
            {t("page", lang)} <strong className="tw-text-blue-gray-800">{table.getState().pagination.pageIndex + 1}</strong> {t("of", lang)} <strong className="tw-text-blue-gray-800">{table.getPageCount() || 1}</strong>
          </Typography>
          <div className="tw-flex tw-gap-1.5 sm:tw-gap-2 tw-order-1 sm:tw-order-2">
            <Button
              size="sm"
              variant="outlined"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
              className="tw-p-1.5 sm:tw-p-2 tw-min-w-0 tw-rounded-lg disabled:tw-opacity-40 disabled:tw-cursor-not-allowed tw-border-blue-gray-200 hover:tw-bg-blue-gray-50 tw-transition-colors"
            >
              <ChevronLeftIcon className="tw-h-3.5 tw-w-3.5 sm:tw-h-4 sm:tw-w-4 lg:tw-h-5 lg:tw-w-5" />
            </Button>
            <Button
              size="sm"
              variant="outlined"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
              className="tw-p-1.5 sm:tw-p-2 tw-min-w-0 tw-rounded-lg disabled:tw-opacity-40 disabled:tw-cursor-not-allowed tw-border-blue-gray-200 hover:tw-bg-blue-gray-50 tw-transition-colors"
            >
              <ChevronRightIcon className="tw-h-3.5 tw-w-3.5 sm:tw-h-4 sm:tw-w-4 lg:tw-h-5 lg:tw-w-5" />
            </Button>
          </div>
        </div>
      </Card>

      {/* ยืนยันการลบใบงาน — ใช้ Dialog เหมือนปุ่มอื่น แทน window.confirm ของเบราว์เซอร์ */}
      <Dialog
        open={!!deleteTarget}
        handler={() => { if (!deleting) setDeleteTarget(null); }}
        size="xs"
        className="tw-mx-4 tw-max-w-[calc(100vw-2rem)] sm:tw-max-w-sm tw-rounded-xl sm:tw-rounded-2xl"
      >
        <DialogHeader className="tw-flex tw-items-center tw-gap-3 tw-text-base sm:tw-text-lg tw-font-semibold tw-px-4 sm:tw-px-6 tw-pt-5 sm:tw-pt-6 tw-pb-2">
          <span className="tw-w-10 tw-h-10 tw-rounded-full tw-bg-red-100 tw-flex tw-items-center tw-justify-center tw-shrink-0">
            <TrashIcon className="tw-w-5 tw-h-5 tw-text-red-600" />
          </span>
          {t("deleteTitle", lang)}
        </DialogHeader>
        <DialogBody className="tw-px-4 sm:tw-px-6 tw-py-3">
          <p className="tw-text-sm tw-text-blue-gray-800 tw-break-all">
            {deleteTarget?.doc_name || deleteTarget?.issue_id || deleteTarget?.id || "-"}
          </p>
          <p className="tw-mt-2 tw-text-sm tw-text-red-600">{t("deleteWarn", lang)}</p>
        </DialogBody>
        <DialogFooter className="tw-gap-2 sm:tw-gap-3 tw-px-4 sm:tw-px-6 tw-pb-5 sm:tw-pb-6 tw-pt-2">
          <Button
            variant="text"
            size="sm"
            disabled={deleting}
            onClick={() => setDeleteTarget(null)}
            className="tw-text-xs sm:tw-text-sm tw-px-4 sm:tw-px-5 tw-py-2 sm:tw-py-2.5 tw-font-medium tw-text-blue-gray-600 hover:tw-bg-blue-gray-50 tw-transition-colors tw-rounded-lg"
          >
            {t("deleteCancel", lang)}
          </Button>
          <Button
            size="sm"
            disabled={deleting}
            onClick={() => { void confirmDelete(); }}
            className="tw-bg-red-600 hover:tw-bg-red-700 tw-text-xs sm:tw-text-sm tw-px-5 sm:tw-px-6 tw-py-2 sm:tw-py-2.5 tw-font-medium tw-rounded-lg tw-shadow-md tw-transition-all disabled:tw-opacity-60"
          >
            {deleting ? t("deleting", lang) : t("deleteConfirm", lang)}
          </Button>
        </DialogFooter>
      </Dialog>

    </>
  );
}
