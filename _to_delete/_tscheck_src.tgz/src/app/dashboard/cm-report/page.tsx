// CM
"use client";

import dynamic from "next/dynamic";
import React, { useEffect, useState } from "react";

import { Tabs, TabsHeader, TabsBody, Tab, TabPanel } from "@material-tailwind/react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { apiFetch } from "@/utils/api";

// Les tableaux ci-dessous vivent dans des onglets et un seul est rendu a la fois,
// mais un import statique les embarque tous dans le bundle de la page. next/dynamic
// les decoupe : seul l'onglet ouvert est telecharge. Pas de `ssr: false` — le rendu
// serveur est conserve, donc le squelette du tableau reste dans le HTML servi.
const OpenTables = dynamic(() => import("@/app/dashboard/cm-report/open/list/open-table"));
const InProgressTables = dynamic(() => import("@/app/dashboard/cm-report/inprogress/list/inprogress-table"));
const ClosedTables = dynamic(() => import("@/app/dashboard/cm-report/closed/list/closed-table"));

type TabId = "Open" | "In Progress" | "Closed" | "Cancelled";
type TabSlug = "open" | "in-progress" | "closed" | "cancelled";

const TABS: { id: TabId; label: string; slug: TabSlug }[] = [
  { id: "Open", label: "Open", slug: "open" },
  { id: "In Progress", label: "In Progress", slug: "in-progress" },
  { id: "Closed", label: "Closed", slug: "closed" },
  { id: "Cancelled", label: "Cancelled", slug: "cancelled" },
];

// แท็บที่ช่างใช้ได้ — ช่างเปิดใบงานเองได้ จึงต้องเห็นแท็บ Open ด้วย (ปุ่ม + เพิ่ม กับใบของ
// ตัวเองที่ยังรออนุมัติอยู่ในแท็บนี้) ฝั่ง backend จำกัดให้เห็นเฉพาะใบที่ตัวเองเปิด/ถูก assign อยู่แล้ว
const TECHNICIAN_TABS: TabId[] = ["Open", "In Progress", "Closed"];

function slugToTab(slug: string | null): TabId {
  switch (slug) {
    case "in-progress": return "In Progress";
    case "closed": return "Closed";
    case "cancelled": return "Cancelled";
    case "open":
    default: return "Open";
  }
}

function tabToSlug(tab: TabId): TabSlug {
  return TABS.find(t => t.id === tab)!.slug;
}

export default function DataTablesPage() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [currentRole, setCurrentRole] = useState("");

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await apiFetch("/me", { credentials: "include" });
        if (res.ok && alive) {
          const data = await res.json();
          setCurrentRole(data.role || "");
        }
      } catch {
        // Keep the default tabs when the role cannot be loaded.
      }
    })();
    return () => { alive = false; };
  }, []);

  const isTechnician = currentRole.trim().toLowerCase() === "technician";
  const visibleTabs = isTechnician
    ? TABS.filter((tab) => TECHNICIAN_TABS.includes(tab.id))
    : TABS;

  // ใช้ state แทน useMemo เพื่อให้ sync กับ URL ได้ทันที
  const [active, setActive] = useState<TabId>(() => slugToTab(searchParams.get("tab")));

  // 🔄 Sync active tab กับ URL params
  useEffect(() => {
    const tabFromUrl = searchParams.get("tab");
    const newActive = slugToTab(tabFromUrl);
    if (newActive !== active) {
      setActive(newActive);
    }
  }, [searchParams]);

  // Technician ใช้ได้เฉพาะแท็บใน TECHNICIAN_TABS — แท็บอื่น (Cancelled) เด้งกลับ In Progress
  useEffect(() => {
    if (!isTechnician) return;
    const requestedTab = slugToTab(searchParams.get("tab"));
    if (TECHNICIAN_TABS.includes(requestedTab)) return;

    setActive("In Progress");
    const params = new URLSearchParams(searchParams.toString());
    params.set("tab", "in-progress");
    params.delete("stage");
    router.replace(`${pathname}?${params.toString()}`, { scroll: false });
  }, [isTechnician, pathname, router, searchParams]);

  // 🔒 อยู่โหมดฟอร์มเมื่อ ?view=form
  const isFormView = searchParams.get("view") === "form";

  const editId = searchParams.get("edit_id") ?? "";
  const mode: "list" | "form" =
    searchParams.get("view") === "form" || !!editId ? "form" : "list";

  const goToForm = (id?: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("view", "form");
    if (id) params.set("edit_id", id);
    // เก็บ tab ปัจจุบัน
    if (!params.get("tab")) {
      params.set("tab", tabToSlug(active));
    }
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  useEffect(() => {
    if (!searchParams.get("tab")) {
      const params = new URLSearchParams(searchParams.toString());
      params.set("tab", tabToSlug(active));
      params.delete("stage");
      router.replace(`${pathname}?${params.toString()}`, { scroll: false });
    }
  }, [pathname, router, searchParams, active]);

  const go = (next: TabId) => {
    setActive(next); // อัพเดท state ทันที
    const params = new URLSearchParams(searchParams.toString());
    params.set("tab", tabToSlug(next));
    params.delete("stage"); // กันของเก่าค้าง
    params.delete("view");  // ออกจาก form mode
    params.delete("edit_id");
    params.delete("from");  // สลับแท็บเอง = ไม่ได้อยู่ในเส้นทางที่มาจาก dashboard แล้ว
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  // return (
  //   <Tabs id="data-tabs" value={active} key={active} className="tw-w-full">
  //     <div className="tw-w-full tw-flex tw-justify-start tw-overflow-x-auto tw-scrollbar-hide">
  //       <TabsHeader
  //         className={`tw-bg-gray-100 tw-rounded-xl tw-p-1 tw-border tw-border-gray-200 tw-overflow-visible tw-w-fit tw-gap-1 tw-m-0
  //           ${isFormView ? "tw-pointer-events-none tw-opacity-60" : ""}
  //         `}
  //         // indicatorProps={{ className: "tw-h-full tw-rounded-lg tw-bg-white tw-shadow tw-ring-1 tw-ring-gray-200" }}
  //         indicatorProps={{ className: "!tw-h-full !tw-rounded-lg !tw-bg-gray-900 !tw-shadow-md" }}
  //       >
  //         {TABS.map((t) => (
  //           <Tab
  //             key={t.id}
  //             value={t.id}
  //             onClick={() => go(t.id)}
  //             className="
  //               tw-rounded-lg tw-px-5 tw-py-2
  //               tw-text-sm md:tw-text-base tw-font-medium
  //               tw-flex tw-flex-nowrap tw-items-center tw-justify-center tw-gap-2
  //               tw-whitespace-nowrap tw-leading-none
  //               tw-text-gray-600 data-[hover=true]:tw-text-gray-900 aria-selected:tw-text-white
  //               tw-min-w-[140px] md:tw-min-w-[160px]
  //             "
  //           >
  //             <span>{t.label}</span>
  //           </Tab>
  //         ))}
  //       </TabsHeader>
  //     </div>

  //     <TabsBody
  //       animate={{ initial: { y: 6, opacity: 0 }, mount: { y: 0, opacity: 1 }, unmount: { y: 6, opacity: 0 } }}
  //       className="tw-pt-3"
  //     >
  //       <TabPanel value="Open" className="tw-p-0">
  //         <div className="tw-space-y-5"><OpenTables /></div>
  //       </TabPanel>

  //       <TabPanel value="In Progress" className="tw-p-0">
  //         <div className="tw-space-y-5"><InProgressTables /></div>
  //       </TabPanel>

  //       <TabPanel value="Closed" className="tw-p-0">
  //         <div className="tw-space-y-5"><ClosedTables /></div>
  //       </TabPanel>
  //     </TabsBody>
  //   </Tabs>
  // );

  const TAB_ICONS: Record<TabId, string> = {
    "Open": "🔴",
    "In Progress": "🟡",
    "Closed": "🟢",
    "Cancelled": "⚫",
  };

  return (
    <div className="tw-w-full">
      {/* Custom Tabs */}
      <div className={`tw-w-full tw-flex tw-justify-start tw-overflow-x-auto tw-scrollbar-hide ${isFormView ? "tw-pointer-events-none tw-opacity-60" : ""}`}>
        <div className="tw-inline-flex tw-items-center tw-gap-1 tw-p-1 tw-bg-gray-100 tw-rounded-xl tw-border tw-border-gray-200">
          {visibleTabs.map((tab) => {
            const isActive = active === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => go(tab.id)}
                className={`
                  tw-relative tw-flex tw-items-center tw-justify-center tw-gap-2
                  tw-rounded-lg tw-px-5 tw-py-2.5
                  tw-text-sm md:tw-text-base tw-font-semibold
                  tw-whitespace-nowrap tw-leading-none
                  tw-min-w-[130px] md:tw-min-w-[150px]
                  tw-transition-all tw-duration-300 tw-ease-out
                  focus:tw-outline-none
                  ${isActive
                    ? "tw-bg-gray-900 tw-text-white tw-shadow-lg tw-shadow-gray-900/25 tw-scale-[1.02]"
                    : "tw-bg-transparent tw-text-gray-500 hover:tw-text-gray-800 hover:tw-bg-white/60"
                  }
                `}
              >
                <span>{tab.label}</span>
                
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="tw-pt-4">
        {active === "Open" && (
          <div className="tw-space-y-5 tw-animate-[fadeIn_0.3s_ease-out]"><OpenTables /></div>
        )}
        {active === "In Progress" && (
          <div className="tw-space-y-5 tw-animate-[fadeIn_0.3s_ease-out]"><InProgressTables /></div>
        )}
        {active === "Closed" && (
          <div className="tw-space-y-5 tw-animate-[fadeIn_0.3s_ease-out]"><ClosedTables /></div>
        )}
        {active === "Cancelled" && (
          <div className="tw-space-y-5 tw-animate-[fadeIn_0.3s_ease-out]"><ClosedTables /></div>
        )}
      </div>
    </div>
  );
}
