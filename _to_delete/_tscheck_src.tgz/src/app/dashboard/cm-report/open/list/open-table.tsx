"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import CMOpenForm from "@/app/dashboard/cm-report/open/input_CMreport/components/checkList";
import CMInProgressForm from "@/app/dashboard/cm-report/inprogress/input_CMreport/components/checkList";
import {
  getCoreRowModel,
  getPaginationRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
  flexRender,
  type ColumnDef,
  type CellContext,
  type SortingState,
} from "@tanstack/react-table";
import {
  Button, Card, CardBody, CardHeader, Typography, CardFooter, Input,
} from "@material-tailwind/react";
import { ArrowUpTrayIcon, DocumentArrowDownIcon } from "@heroicons/react/24/outline";
import { ChevronLeftIcon, ChevronRightIcon, ChevronUpDownIcon } from "@heroicons/react/24/solid";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useLanguage, type Lang } from "@/utils/useLanguage";
import { apiFetch } from "@/utils/api";
import LoadingOverlay from "@/app/dashboard/components/Loadingoverlay";
import { failureCodeLabel } from "@/app/dashboard/cm-report/lib/failureCode";
import { brandScopeOf, canOpenCmAtStation } from "@/utils/brandScope";
import { COMPANY_FILTER_OPTIONS } from "@/utils/cm-dashboard";
import TableSkeletonRows, { TableBodySpacer } from "@/components/TableSkeletonRows";

// ==================== TRANSLATIONS ====================
const T = {
  // Page Header
  pageTitle: { th: "Corrective Maintenance Report", en: "Corrective Maintenance Report" },
  pageSubtitle: { th: "ค้นหาและดาวน์โหลดเอกสาร CM Report", en: "Search and download CM Report documents" },

  // Buttons
  upload: { th: "อัพโหลด", en: "Upload" },
  add: { th: "+ เพิ่ม", en: "+ Add" },
  companyModalTitle: { th: "เปิดใบงานนี้ให้บริษัทไหน", en: "Open this work order for which company?" },
  companyModalHint: { th: "เลือกบริษัทที่รับผิดชอบใบงานนี้ — ใช้แยกงานในหน้า CM List และ Dashboard", en: "Pick the company responsible for this work order — used to split work in CM List and Dashboard." },
  companyConfirm: { th: "เปิดใบงาน", en: "Open work order" },
  cancel: { th: "ยกเลิก", en: "Cancel" },
  uploadBtn: { th: "อัพโหลด", en: "Upload" },

  // Table Headers
  colNo: { th: "ลำดับ", en: "No." },
  colDocName: { th: "ชื่อเอกสาร", en: "Document Name" },
  colIssueId: { th: "รหัสเอกสาร", en: "Issue ID" },
  colSr: { th: "เลขที่ SR/WO", en: "SR/WO No." },
  colCmDate: { th: "วัน/เวลาที่แจ้ง", en: "Found Date/Time" },
  colReportedBy: { th: "ผู้แจ้งปัญหา", en: "Reported By" },
  colLocation: { th: "ตำแหน่งที่พบ", en: "Faulty Equipment" },
  colChargerNo: { th: "หมายเลขตู้", en: "Charger No." },
  colChargerSn: { th: "S/N ตู้", en: "Charger S/N" },
  colProblemDetails: { th: "ปัญหาที่พบ", en: "Problem Details" },
  colStatus: { th: "สถานะ", en: "Status" },

  // Pagination
  entriesPerPage: { th: "รายการต่อหน้า", en: "entries per page" },
  page: { th: "หน้า", en: "Page" },
  of: { th: "จาก", en: "of" },

  // Search
  search: { th: "ค้นหา", en: "Search" },

  // Loading / Empty States
  loading: { th: "กำลังโหลด...", en: "Loading..." },
  noData: { th: "ไม่มีข้อมูล", en: "No data" },
  selectStationFirst: { th: "กรุณาเลือกสถานีจากแถบด้านบนก่อน", en: "Please select a station from the top bar first" },
  brandBlocked: {
    th: "บริษัทของคุณดูแลเฉพาะตู้บางยี่ห้อ — สถานีนี้ไม่ใช่ยี่ห้อดังกล่าว จึงเปิดใบงานไม่ได้",
    en: "Your company only maintains certain charger brands — this station is a different brand, so you cannot open a work order",
  },
  noFile: { th: "ไม่มีไฟล์", en: "No file" },

  // Dialog
  // dialogTitle: { th: "เลือกวันที่รายงาน", en: "Select Report Date" },
  // dateLabel: { th: "วันที่", en: "Date" },
  // statusLabel: { th: "สถานะ", en: "Status" },
  // filesSelected: { th: "ไฟล์ที่เลือก:", en: "Selected files:" },
  // filesUnit: { th: "ไฟล์", en: "file(s)" },

  // Dialog
  dialogTitle: { th: "อัปโหลดไฟล์ CM", en: "Upload CM File" },
  docNameLabel: { th: "ชื่อเอกสาร", en: "Document Name" },
  issueIdLabel: { th: "Issue ID", en: "Issue ID" },
  inspectorLabel: { th: "ผู้ตรวจสอบ", en: "Inspector" },
  dateLabel: { th: "วันที่ CM", en: "CM Date" },
  statusLabel: { th: "สถานะ", en: "Status" },
  filesSelected: { th: "ไฟล์ที่เลือก:", en: "Selected files:" },
  filesUnit: { th: "ไฟล์", en: "file(s)" },

  // Alerts
  alertSelectStation: { th: "กรุณาเลือกสถานีก่อน", en: "Please select a station first" },
  alertPdfOnly: { th: "รองรับเฉพาะไฟล์ PDF เท่านั้น", en: "Only PDF files are supported" },
  alertInvalidDate: { th: "รูปแบบวันที่ไม่ถูกต้อง", en: "Invalid date format" },
  alertUploadFailed: { th: "อัพโหลดไม่สำเร็จ:", en: "Upload failed:" },
  alertUploadSuccess: { th: "อัพโหลดสำเร็จ", en: "Upload successful" },
  alertUploadError: { th: "เกิดข้อผิดพลาดระหว่างอัพโหลด", en: "An error occurred during upload" },

  // Tooltips
  uploadPdf: { th: "อัพโหลด PDF", en: "Upload PDF" },
};

const t = (key: keyof typeof T, lang: Lang): string => T[key][lang];

// หมายเลขตู้/SN แยกเป็นคอลัมน์ของตัวเองแล้ว ตำแหน่งที่พบจึงเหลือแค่ชื่อ failure class
const chargerField = (v?: unknown) => String(v ?? "").trim();

// ใบที่ถูกตีกลับยังคงสถานะจริงเป็น "Wait for approve" (ด่าน cs) เพื่อให้ backend flow เดิมทำงานได้
// แต่ในตารางต้องโชว์ "Reject" ให้ cs รู้ว่าต้องแก้ไข ไม่ใช่รออนุมัติ (เคลียร์เมื่อ cs บันทึกกลับ)
const isRejectedSr = (row: { status?: string; stage?: string; reject_remark?: string }) => {
  const sl = String(row.status ?? "").trim().toLowerCase();
  const stageLower = String(row.stage ?? "").trim().toLowerCase();
  // ด่าน cs เท่านั้น — reject ด่านปิดงาน (close_approval) ดันสถานะเป็น In Progress อยู่แล้ว
  const isCsStage = sl === "open" || (sl === "wait for approve" && stageLower !== "close_approval");
  return isCsStage && !!String(row.reject_remark ?? "").trim();
};

const displayStatus = (row: { status?: string; stage?: string; reject_remark?: string }) =>
  isRejectedSr(row) ? "Reject" : (String(row.status ?? "").trim() || "-");

type TData = {
  id?: string;
  doc_name?: string;
  issue_id?: string;
  cm_date: string;
  position: string;
  office: string;
  reported_by?: string;
  location?: string;
  charger_no?: string;
  charger_sn?: string;
  problem_details?: string;
  status: string;
  stage?: string;
  found_time?: string;
  reject_remark?: string;
  repair_result?: string;
  assignees?: string[];
};

type Props = {
  token?: string;
  apiBase?: string;
};



const BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";

type Me = {
  id: string;
  username: string;
  email: string;
  role: string;
  company: string;
  tel: string;
};

function nextDocNameFor(stationId: string, dateISO: string, latestFromDb?: string) {
  const d = new Date(dateISO || new Date().toISOString().slice(0, 10));
  const year = d.getFullYear();
  const prefix = `${stationId}_`;
  const suffix = `/${year}`;
  const s = String(latestFromDb || "").trim();
  if (!s || !s.startsWith(prefix) || !s.endsWith(suffix)) return `${prefix}1${suffix}`;
  const inside = s.slice(prefix.length, s.length - suffix.length);
  const cur = parseInt(inside, 10);
  return `${prefix}${isNaN(cur) ? 1 : cur + 1}${suffix}`;
}

export default function CMReportPage({ token, apiBase = BASE }: Props) {
  const { lang } = useLanguage();
  const [userRole, setUserRole] = useState<string>("");
  const isTechnician = userRole.toLowerCase() === "technician";
  // true au depart : le squelette doit occuper la hauteur finale des le premier
  // rendu, sinon le tableau grandit de 0 a N lignes quand les donnees arrivent.
  const [loading, setLoading] = useState(true);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [data, setData] = useState<TData[]>([]);
  const [filtering, setFiltering] = useState("");
  const [username, setUsername] = useState<string>("");
  const [pageLoading, setPageLoading] = useState(true);
  const [issueId, setIssueId] = useState<string>("");
  const [sn, setSn] = useState<string | null>(null);
  const [docName, setDocName] = useState<string>("");
  const [me, setMe] = useState<Me | null>(null);
  const [inspector, setInspector] = useState<string>("");
  const [toast, setToast] = useState<{ show: boolean; type: "success" | "error" | "warning" | "info"; message: string }>({ show: false, type: "info", message: "" });


  const showToast = (type: "success" | "error" | "warning" | "info", message: string, duration = 4000) => {
    setToast({ show: true, type, message });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), duration);
  };

  const todayStr = useMemo(() => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }, []);

  const searchParams = useSearchParams();
  const [stationId, setStationId] = useState<string | null>(null);



  useEffect(() => {
    const snFromUrl = searchParams.get("sn");
    if (snFromUrl) {
      setSn(snFromUrl);
      localStorage.setItem("selected_sn", snFromUrl);
      return;
    }
    const snLocal = localStorage.getItem("selected_sn");
    setSn(snLocal);
  }, [searchParams]);

  useEffect(() => {
    const useHttpOnlyCookie = true;
    (async () => {
      try {
        const headers: Record<string, string> = {};

        const res = await apiFetch(`${apiBase}/me`, {
          method: "GET",
          headers,
          credentials: "include",
        });

        if (!res.ok) {
          console.warn("/me failed:", res.status);
          return;
        }

        const data: Me = await res.json();
        setMe(data);

        setInspector((prev) => prev || data.username || "");
      } catch (err) {
        console.error("fetch /me error:", err);
      }
    })();
  }, [apiBase]);


  useEffect(() => {
    const sidFromUrl = searchParams.get("station_id");
    if (sidFromUrl) {
      setStationId(sidFromUrl);
      localStorage.setItem("selected_station_id", sidFromUrl);
      return;
    }
    const sidLocal = localStorage.getItem("selected_station_id");
    setStationId(sidLocal);
  }, [searchParams]);

  // Fetch current user role from /me
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await apiFetch(`${apiBase}/me`);
        if (res.ok) {
          const user = await res.json();
          if (alive) {
            setUserRole(user.role ?? "");
            setUsername(user.username ?? "");
          }
        }
      } catch (err) {
        console.error("fetch /me error:", err);
      }
    })();
    return () => { alive = false; };
  }, [apiBase]);

  // ── ยี่ห้อตู้ของสถานีที่เลือก — ใช้ตัดสินว่าเปิดใบงานที่นี่ได้ไหม (EDS ดูแลเฉพาะ FlexxFast)
  //    เช็คตั้งแต่ตอนกดปุ่ม + เพิ่ม จะได้ไม่ปล่อยให้เข้าฟอร์มไปแล้วเจอทางตันตอนกดบันทึก
  const [chargers, setChargers] = useState<{ brand?: string }[]>([]);
  const [loadingChargers, setLoadingChargers] = useState(false);

  useEffect(() => {
    if (!stationId) { setChargers([]); return; }
    let alive = true;
    setLoadingChargers(true);
    (async () => {
      try {
        const res = await apiFetch(`${apiBase}/chargers/${encodeURIComponent(stationId)}`, { credentials: "include" });
        if (res.ok) {
          const data = await res.json();
          if (alive) setChargers(data.chargers || []);
        }
      } catch {
        if (alive) setChargers([]);
      } finally {
        if (alive) setLoadingChargers(false);
      }
    })();
    return () => { alive = false; };
  }, [apiBase, stationId]);

  const brandScope = useMemo(() => brandScopeOf(userRole, me?.company ?? ""), [userRole, me?.company]);
  // รอโหลดรายการตู้ให้เสร็จก่อนค่อยตัดสิน ไม่งั้นปุ่มจะกระพริบเป็น disabled ทุกครั้งที่เปลี่ยนสถานี
  const brandBlocked = !!brandScope && !loadingChargers && !canOpenCmAtStation(chargers, brandScope);
  const canAdd = !!stationId && !brandBlocked;

  const statusFromTab = (searchParams.get("status") ?? searchParams.get("tab") ?? "open").toLowerCase();
  const statusLabel = statusFromTab
    .split(/[-_ ]+/)
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : ""))
    .join(" ");

  const router = useRouter();
  const pathname = usePathname();
  const editId = searchParams.get("edit_id") ?? "";
  const mode: "list" | "form" =
    (searchParams.get("view") === "form" || !!editId) ? "form" : "list";

  const setView = (view: "list" | "form", { replace = false } = {}) => {
    const params = new URLSearchParams(searchParams.toString());
    if (view === "form") {
      params.set("view", "form");
    } else {
      params.delete("view");
      params.delete("edit_id");
    }
    router[replace ? "replace" : "push"](`${pathname}?${params.toString()}`, { scroll: false });
  };



  // Date formatting with language support
  function formatDate(iso?: string, currentLang: Lang = lang) {
    if (!iso) return "-";

    const d = /^\d{4}-\d{2}-\d{2}$/.test(iso)
      ? new Date(iso + "T00:00:00Z")
      : new Date(iso);

    if (isNaN(d.getTime())) return "-";

    return d.toLocaleDateString(
      currentLang === "en" ? "en-GB" : "th-TH-u-ca-gregory",
      {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        timeZone: "UTC",
      }
    );
  }

  function toISODateOnly(s?: string) {
    if (!s) return "";
    try {
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
      const d = new Date(s);
      if (isNaN(d.getTime())) return "";
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      return `${yyyy}-${mm}-${dd}`;
    } catch {
      return "";
    }
  }

  function resolveFileHref(v: any, apiBase: string) {
    if (!v) return "";
    if (typeof v === "object") {
      const c = v.url ?? v.href ?? v.link ?? "";
      return resolveFileHref(c, apiBase);
    }
    const s = String(v).trim();
    if (!s) return "";
    try { return new URL(s).toString(); } catch { }
    if (s.startsWith("/")) return `${apiBase}${s}`;
    if (/^[a-f0-9]{24}$/i.test(s)) return `${apiBase}/files/${s}`;
    return `${apiBase}/${s}`;
  }

  function getStatusText(it: any) {
    return String(it?.status ?? it?.job?.status ?? "").trim();
  }

  const fetchRows = async () => {
    if (!stationId) { setData([]); setLoading(false); setPageLoading(false); return; }
    setLoading(true);

    try {
      // แท็บ Open รวม: ใบเปิดใหม่รอ head cs อนุมัติ (Wait for approve/cs_approval),
      // ใบเก่า/auto ที่เป็น Open, และใบที่รอ planner วางแผน (Wait for schedule)
      const requestStatus = "open,wait for approve,wait for schedule,wo - wait for approve";
      const makeURL = (path: string) => {
        const u = new URL(`${apiBase}${path}`);
        u.searchParams.set("station_id", stationId);
        u.searchParams.set("page", "1");
        u.searchParams.set("pageSize", "50");
        u.searchParams.set("status", requestStatus);
        // เข้ามาจากการ์ดตู้ชาร์จ → เห็นเฉพาะใบของตู้นั้น, ระดับสถานี → เห็นทุกใบ
        if (sn) u.searchParams.set("sn", sn);
        return u.toString();
      };

      const [cmRes, urlRes] = await Promise.allSettled([
        apiFetch(makeURL("/cmreport/list")),
        apiFetch(makeURL("/cmurl/list")),
      ]);

      let cmItems: any[] = [];
      let urlItems: any[] = [];

      if (cmRes.status === "fulfilled" && cmRes.value.ok) {
        const j = await cmRes.value.json();
        if (Array.isArray(j?.items)) cmItems = j.items;
      }
      if (urlRes.status === "fulfilled" && urlRes.value.ok) {
        const j = await urlRes.value.json();
        if (Array.isArray(j?.items)) urlItems = j.items;
      }

      // แท็บ Open = ด่านก่อนเริ่มซ่อม: รอ head cs อนุมัติ + รอ planner วางแผน
      // "wait for approve" ต้องเป็น stage cs_approval เท่านั้น (ด่านปิดงานไปอยู่แท็บ In Progress)
      const isOpen = (it: any) => {
        const rawStatuses = [it?.status, it?.job?.status]
          .filter((value) => value != null)
          .map((value) => String(value).trim().toLowerCase());
        const hasStatus = rawStatuses.length > 0 || it?.repair_result != null || it?.job?.repair_result != null;
        if (!hasStatus) return true;
        const s = rawStatuses[0] || "";
        const stage = String(it?.stage ?? "").trim().toLowerCase();
        const repairResult = String(it?.repair_result ?? it?.job?.repair_result ?? "").trim().toLowerCase();
        if (rawStatuses.includes("wo - wait for approve") || repairResult === "wo - wait for approve") return false;
        if (rawStatuses.includes("wait for approve")) return stage === "cs_approval";
        if (rawStatuses.includes("open") || s === "open") return true;
        if (rawStatuses.includes("wait for schedule")) return true;
        return false;
      };

      cmItems = cmItems.filter(isOpen);
      urlItems = urlItems.filter(isOpen);

      const cmRows: TData[] = cmItems.map((it: any) => {
        // "วันที่แจ้ง" มาจาก found_date (วันที่ผู้แจ้งระบุ) ก่อน แล้วค่อย fallback
        const isoDay = toISODateOnly(it.cm_date ?? it.found_date ?? it.createdAt ?? "");
        const rawUploaded =
          it.file_url
          ?? (Array.isArray(it.urls) ? (it.urls[0]?.url ?? it.urls[0]) : it.url)
          ?? it.file
          ?? it.path;

        const uploadedUrl = resolveFileHref(rawUploaded, apiBase);

        function extractId(x: any): string {
          if (!x) return "";
          const raw = (x._id !== undefined ? x._id : x.id) ?? "";
          if (raw && typeof raw === "object") {
            return raw.$oid || raw.oid || raw.$id || "";
          }
          const s = String(raw || "");
          return /^[a-fA-F0-9]{24}$/.test(s) ? s : "";
        }

        const id = extractId(it);
        const generatedUrl = id ? `${apiBase}/pdf/${encodeURIComponent(id)}/file` : "";
        const fileUrl = uploadedUrl || generatedUrl;

        return {
          id,
          doc_name: it.doc_name || "",
          issue_id: it.issue_id || "",
          cm_date: isoDay,
          position: isoDay,
          office: fileUrl,
          reported_by: it.reported_by || it.technician || "",
          // คอลัมน์ "ตำแหน่งที่พบ" โชว์ตู้ที่ใบงานอ้างถึง ("Charger 1 (SN)") — ใบระดับสถานี
          // หรือใบเก่าที่ไม่ผูกตู้ ไม่มี label ให้ใช้ จึงถอยไปใช้ชื่อ failure class ของ Maximo
          location: it.faulty_equipment_label || failureCodeLabel(it.faulty_equipment) || "-",
          charger_no: chargerField(it.charger_no),
          charger_sn: chargerField(it.charger_sn),
          problem_details: it.problem_details || "",
          status: getStatusText(it) || "-",
          stage: it.stage || "",
          repair_result: it.repair_result || it.job?.repair_result || "",
          assignees: Array.isArray(it.assignees)
            ? it.assignees
            : (Array.isArray(it.job?.assignees) ? it.job.assignees : []),
          found_time: it.found_time || "",
          reject_remark: it.reject_remark || "",
        };
      });

      const urlRows: TData[] = urlItems.map((it: any) => {
        const isoDay = toISODateOnly(it.cm_date ?? it.reportDate ?? it.createdAt ?? "");
        const raw =
          it.file_url
          ?? (Array.isArray(it.urls) ? (it.urls[0]?.url ?? it.urls[0]) : it.url)
          ?? it.file
          ?? it.path;

        return {
          id: it.id || it._id || "",
          doc_name: it.doc_name || "",
          issue_id: it.issue_id || "",
          cm_date: isoDay,
          position: isoDay,
          office: resolveFileHref(raw, apiBase),
          reported_by: it.reported_by || it.technician || "",
          location: it.faulty_equipment_label || failureCodeLabel(it.faulty_equipment) || "-",
          charger_no: chargerField(it.charger_no),
          charger_sn: chargerField(it.charger_sn),
          problem_details: it.problem_details || "",
          status: getStatusText(it) || "-",
          stage: it.stage || "",
          repair_result: it.repair_result || it.job?.repair_result || "",
        };
      });

      const allRows = [...cmRows, ...urlRows].sort((a, b) => {
        const da = (a.position ?? "") as string;
        const db = (b.position ?? "") as string;
        return da < db ? 1 : da > db ? -1 : 0;
      });

      if (!allRows.length) { setData([]); return; }

      setData(allRows);
    } catch (err) {
      console.error("fetch both lists error:", err);
      setData([]);
    } finally {
      setLoading(false);
      setPageLoading(false);
    }
  };

  // ==================== FIX: เพิ่ม mode และ statusFromTab เป็น dependency ====================
  useEffect(() => {
    // ไม่ fetch ถ้าอยู่ใน form mode
    if (mode !== "list") return;

    let alive = true;
    (async () => { await fetchRows(); })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiBase, stationId, sn, mode, statusFromTab]);




  const columns: ColumnDef<TData, unknown>[] = useMemo(() => [
    {
      id: "no",
      header: () => t("colNo", lang),
      enableSorting: false,
      size: 60,
      minSize: 50,
      maxSize: 80,
      cell: (info: CellContext<TData, unknown>) => {
        const { pageIndex, pageSize } = info.table.getState().pagination;
        return pageIndex * pageSize + info.row.index + 1;
      },
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.doc_name || "—",
      id: "doc_name",
      header: () => t("colDocName", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 150,
      minSize: 100,
      maxSize: 200,
      meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      // เลขงาน: ก่อนอนุมัติ = SR, หลังอนุมัติ (Wait for schedule) = WO — อิงลำดับเดียวกับ issue_id
      accessorFn: (row) => {
        const m = String(row.issue_id || "").match(/(\d+)/);
        if (!m) return "—";
        const isWo = String(row.status || "").trim().toLowerCase() === "wait for schedule";
        return `${isWo ? "WO" : "SR"}${m[1].padStart(3, "0")}`;
      },
      id: "sr_no",
      header: () => t("colSr", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 140,
      minSize: 100,
      maxSize: 180,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.charger_no || "-",
      id: "charger_no",
      header: () => t("colChargerNo", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 100,
      minSize: 70,
      maxSize: 130,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.charger_sn || "-",
      id: "charger_sn",
      header: () => t("colChargerSn", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 150,
      minSize: 100,
      maxSize: 220,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.cm_date,
      id: "cm_date",
      header: () => t("colCmDate", lang),
      cell: (info: CellContext<TData, unknown>) => {
        const time = info.row.original.found_time || "";
        return (
          <span className="tw-whitespace-nowrap">
            {formatDate(info.getValue() as string, lang)}{time ? ` ${time}` : ""}
          </span>
        );
      },
      size: 140,
      minSize: 110,
      maxSize: 180,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.reported_by || "-",
      id: "reported_by",
      header: () => t("colReportedBy", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 120,
      minSize: 80,
      maxSize: 160,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    {
      accessorFn: (row) => row.location || "-",
      id: "location",
      header: () => t("colLocation", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span className="tw-block tw-truncate" title={info.getValue() as string}>
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 150,
      minSize: 100,
      maxSize: 200,
      meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      accessorFn: (row) => row.problem_details || "-",
      id: "problem_details",
      header: () => t("colProblemDetails", lang),
      cell: (info: CellContext<TData, unknown>) => (
        <span
          className="tw-block tw-truncate tw-max-w-[200px]"
          title={info.getValue() as string}
        >
          {info.getValue() as React.ReactNode}
        </span>
      ),
      size: 200,
      minSize: 120,
      maxSize: 300,
      meta: { headerAlign: "center", cellAlign: "left" },
    },
    {
      accessorFn: (row) => displayStatus(row),
      id: "status",
      header: () => t("colStatus", lang),
      cell: (info: CellContext<TData, unknown>) => {
        const s = String(info.getValue() ?? "-");
        const sl = s.toLowerCase();
        const color =
          sl === "reject" ? "tw-bg-red-100 tw-text-red-800" :
            sl === "open" ? "tw-bg-green-100 tw-text-green-800" :
              sl === "wait for approve" ? "tw-bg-purple-100 tw-text-purple-800" :
                sl === "wait for schedule" ? "tw-bg-indigo-100 tw-text-indigo-800" :
                  sl === "complete" || sl === "closed" || sl === "close" ? "tw-bg-gray-200 tw-text-gray-800" :
                    sl === "in progress" || sl === "ongoing" ? "tw-bg-amber-100 tw-text-amber-800" :
                      "tw-bg-blue-gray-100 tw-text-blue-gray-800";
        return (
          <span className={`tw-inline-block tw-px-2 sm:tw-px-2.5 tw-py-0.5 sm:tw-py-1 tw-rounded-full tw-text-[10px] sm:tw-text-xs tw-font-medium ${color}`}>
            {s}
          </span>
        );
      },
      size: 100,
      minSize: 80,
      maxSize: 140,
      meta: { headerAlign: "center", cellAlign: "center" },
    },
    // ปุ่มอนุมัติ (cs-approve) ย้ายไปอยู่ในฟอร์มแล้ว — head cs เปิดใบงานเพื่อดูรายละเอียดก่อนอนุมัติ
    // eslint-disable-next-line react-hooks/exhaustive-deps
  ], [lang, stationId]);

  function sameUser(a?: string, b?: string) {
    return String(a ?? "").trim().toLowerCase() === String(b ?? "").trim().toLowerCase();
  }

  const visibleData = useMemo(() => {
    // planner เป็นผู้อนุมัติ SR → เห็นทั้ง Wait for approve (รออนุมัติ) และ Wait for schedule (วางแผน)
    // ซ่อนเฉพาะใบที่ตีกลับไปหา CS แล้ว (Wait for approve + reject_remark) — ยังไม่ใช่คิว จนกว่า CS จะแก้แล้วบันทึกกลับ
    return data;
  }, [data]);

  const table = useReactTable({
    data: visibleData,
    columns,
    state: { globalFilter: filtering, sorting },
    onSortingChange: setSorting,
    onGlobalFilterChange: setFiltering,
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    columnResizeMode: "onChange",
  });

  // Upload
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const [dateOpen, setDateOpen] = useState(false);
  const [reportDate, setReportDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);

  useEffect(() => {
    if (!dateOpen || !stationId || !reportDate) return;
    let canceled = false;
    (async () => {
      try {
        const res = await apiFetch(
          `${apiBase}/cmreport/preview-docname?station_id=${encodeURIComponent(stationId)}&found_date=${encodeURIComponent(reportDate)}`,
          { credentials: "include" }
        );
        if (res.ok) {
          const data = await res.json();
          if (!canceled) {
            setIssueId(data.issue_id || "");
            setDocName(data.doc_name || "");
          }
        } else if (!canceled) {
          setIssueId("");
          setDocName(nextDocNameFor(stationId, reportDate));
        }
      } catch {
        if (!canceled) {
          setIssueId("");
          setDocName(nextDocNameFor(stationId, reportDate));
        }
      }
    })();
    return () => { canceled = true; };
  }, [dateOpen, stationId, reportDate]);

  const handlePdfChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.currentTarget.value = "";
    if (!files.length) return;

    const pdfs = files.filter(
      (f) => f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf")
    );
    if (!pdfs.length) {
      showToast("error", t("alertPdfOnly", lang));
      return;
    }

    const validPdfs: File[] = [];
    for (const f of pdfs) {
      const header = await f.slice(0, 5).text();
      if (header.startsWith("%PDF-")) {
        validPdfs.push(f);
      }
    }
    if (validPdfs.length === 0) {
      showToast("error", lang === "th"
        ? "ไฟล์ที่เลือกไม่ใช่ PDF จริง กรุณาเลือกไฟล์ PDF ที่ถูกต้อง"
        : "Selected files are not valid PDFs");
      return;
    }
    if (validPdfs.length < pdfs.length) {
      showToast("warning", lang === "th"
        ? `มี ${pdfs.length - validPdfs.length} ไฟล์ไม่ใช่ PDF จริง — อัปโหลดเฉพาะ ${validPdfs.length} ไฟล์ที่ถูกต้อง`
        : `${pdfs.length - validPdfs.length} invalid file(s) skipped — uploading ${validPdfs.length} valid file(s)`);
    }

    setPendingFiles(validPdfs);
    setDateOpen(true);
  };

  async function uploadPdfs() {
    try {
      if (!stationId) { showToast("warning", t("alertSelectStation", lang)); return; }
      if (!pendingFiles.length) { setDateOpen(false); return; }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(reportDate)) { showToast("error", t("alertInvalidDate", lang)); return; }
      const fd = new FormData();

      fd.append("station_id", stationId);
      fd.append("reportDate", reportDate);
      fd.append("status", statusFromTab);
      fd.append("issue_id", issueId);
      fd.append("doc_name", docName || "");
      fd.append("inspector", inspector || "");
      pendingFiles.forEach((f) => fd.append("files", f));

      const res = await apiFetch(`${apiBase}/cmurl/upload-files`, {
        method: "POST", body: fd
      });

      if (!res.ok) {
        const txt = await res.text();
        showToast("error", `${t("alertUploadFailed", lang)} ${txt}`);
        return;
      }
      await res.json();
      showToast("success", t("alertUploadSuccess", lang));
      setPendingFiles([]);
      setDateOpen(false);
      await fetchRows();
    } catch (err) {
      console.error(err);
      showToast("error", t("alertUploadError", lang));
    }
  }

  // ── เลือกบริษัทก่อนเปิดใบงานใหม่ — ค่าที่เลือกส่งต่อไปที่ฟอร์มผ่าน query แล้วบันทึกลงใบงาน
  // ใช้ลิสต์เดียวกับดรอปดาวน์กรองบริษัทใน CM List / CM Dashboard เพื่อไม่ให้สองที่หลุดกัน
  const COMPANY_CHOICES = COMPANY_FILTER_OPTIONS;
  const [companyModalOpen, setCompanyModalOpen] = useState(false);
  const [companyChoice, setCompanyChoice] = useState<string>(COMPANY_CHOICES[0]);
  const pickedCompany = companyChoice;

  const goAdd = () => {
    setCompanyChoice(COMPANY_CHOICES[0]);
    setCompanyModalOpen(true);
  };

  const confirmCompanyAndAdd = () => {
    if (!pickedCompany) return;
    const params = new URLSearchParams(searchParams.toString());
    params.set("view", "form");
    params.delete("edit_id");
    params.set("company", pickedCompany);
    setCompanyModalOpen(false);
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  const goList = () => {
    const params = new URLSearchParams(searchParams.toString());
    params.delete("view");
    params.delete("edit_id");
    params.delete("self_close");
    params.delete("company");
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  };

  function goEdit(row: TData) {
    if (!row?.id) return;
    const params = new URLSearchParams(searchParams.toString());
    params.set("view", "form");
    params.set("edit_id", row.id);
    params.delete("self_close");
    // WO - wait for scheduled มีแผน/ช่างแล้ว ให้เปิดฟอร์มกรอกผลซ่อมเหมือน technician
    // แม้ข้อมูลเก่าจะยังค้างอยู่ใน status Wait for schedule
    if (
      row.status.trim().toLowerCase() === "wait for schedule" &&
      ["wo - wait for scheduled", "wo - wait for manpower"].includes(
        row.repair_result?.trim().toLowerCase() ?? "",
      )
    ) {
      params.set("tab", "in-progress");
    }
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  }

  // Handle row click
  const handleRowClick = (row: TData) => {
    if (row?.id) {
      goEdit(row);
    }
  };

  if (mode === "form") {
    const plannerSelfClose = searchParams.get("self_close") === "1";
    return (
      <div className="tw-mt-4 sm:tw-mt-6 lg:tw-mt-8">
        {plannerSelfClose ? <CMInProgressForm /> : <CMOpenForm />}
      </div>
    );
  }

  return (
    <>
      <LoadingOverlay show={pageLoading} text={lang === "th" ? "กำลังโหลดข้อมูล..." : "Loading data..."} />
      {toast.show && (
        <div className="tw-fixed tw-top-4 tw-left-1/2 tw--translate-x-1/2 tw-z-[9999] tw-max-w-md tw-w-[calc(100%-2rem)]">
          <div className={`tw-flex tw-items-start tw-gap-3 tw-px-4 tw-py-3 tw-rounded-xl tw-shadow-2xl tw-border ${toast.type === "success" ? "tw-bg-green-50 tw-border-green-200" :
            toast.type === "error" ? "tw-bg-red-50 tw-border-red-200" :
              toast.type === "warning" ? "tw-bg-amber-50 tw-border-amber-200" :
                "tw-bg-blue-50 tw-border-blue-200"}`}>
            <div className={`tw-flex-shrink-0 tw-w-8 tw-h-8 tw-rounded-full tw-flex tw-items-center tw-justify-center ${toast.type === "success" ? "tw-bg-green-500" : toast.type === "error" ? "tw-bg-red-500" :
              toast.type === "warning" ? "tw-bg-amber-500" : "tw-bg-blue-500"}`}>
              {toast.type === "success" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" /></svg>}
              {toast.type === "error" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>}
              {toast.type === "warning" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01" /></svg>}
              {toast.type === "info" && <svg className="tw-w-4 tw-h-4 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 16h-1v-4h-1m1-4h.01" /></svg>}
            </div>
            <p className={`tw-text-sm tw-font-medium tw-flex-1 tw-pt-1 ${toast.type === "success" ? "tw-text-green-800" : toast.type === "error" ? "tw-text-red-800" :
              toast.type === "warning" ? "tw-text-amber-800" : "tw-text-blue-800"}`}>{toast.message}</p>
            <button onClick={() => setToast(prev => ({ ...prev, show: false }))}
              className="tw-flex-shrink-0 tw-p-1 tw-rounded-full tw-text-gray-400 hover:tw-text-gray-600 hover:tw-bg-gray-100 tw-transition-colors">
              <svg className="tw-w-4 tw-h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        </div>
      )}
      {/* Main Card */}
      <Card className="tw-border tw-border-blue-gray-100 tw-shadow-sm tw-mt-4 sm:tw-mt-6 lg:tw-mt-8 tw-mx-2 sm:tw-mx-4 lg:tw-mx-0 tw-rounded-xl lg:tw-rounded-2xl tw-overflow-hidden">

        {/* Card Header */}
        {/* <CardHeader floated={false} shadow={false} className="tw-p-3 sm:tw-p-4 lg:tw-p-6 tw-rounded-none tw-m-0"> */}
        <CardHeader floated={false} shadow={false} className="tw-p-3 sm:tw-p-4 lg:tw-p-6 tw-rounded-none tw-m-0 tw-bg-gradient-to-r tw-from-white tw-to-blue-gray-50/30">
          <div className="tw-flex tw-flex-col sm:tw-flex-row sm:tw-items-center sm:tw-justify-between tw-gap-3 sm:tw-gap-4">
            {/* Title Section */}
            <div className="tw-min-w-0 tw-flex-1">
              <Typography
                variant="h5"
                color="blue-gray"
                className="tw-text-sm sm:tw-text-base lg:tw-text-lg tw-leading-tight tw-font-semibold"
              >
                {t("pageTitle", lang)}
              </Typography>
              <Typography
                variant="small"
                className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-leading-relaxed tw-font-normal tw-text-blue-gray-400 tw-mt-0.5"
              >
                {t("pageSubtitle", lang)}
              </Typography>
            </div>

            {/* Buttons Section */}
            {!isTechnician && (
              <div className="tw-flex tw-items-center tw-gap-2 tw-flex-shrink-0">
                <input
                  ref={pdfInputRef}
                  type="file"
                  accept="application/pdf,.pdf"
                  multiple
                  className="tw-hidden"
                  onChange={handlePdfChange}
                />
                <Button
                  size="sm"
                  onClick={goAdd}
                  disabled={!canAdd}
                  className={`
                  tw-h-7 sm:tw-h-8 lg:tw-h-9 tw-rounded-xl tw-px-3 sm:tw-px-4 lg:tw-px-5
                  tw-flex tw-items-center tw-justify-center tw-font-semibold tw-tracking-wide
                  ${!canAdd
                      ? "tw-bg-gray-300 tw-text-white tw-cursor-not-allowed"
                      : "tw-bg-gray-900 hover:tw-bg-black tw-text-white"}
                  tw-shadow-lg tw-transition-all
                `}
                  title={!stationId ? t("selectStationFirst", lang) : brandBlocked ? t("brandBlocked", lang) : ""}
                >
                  <span className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm">{t("add", lang)}</span>
                </Button>
              </div>
            )}
          </div>
        </CardHeader>

        {/* Card Body - Search & Entries per page */}
        <CardBody className="tw-px-3 sm:tw-px-4 lg:tw-px-6 tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-border-t tw-border-blue-gray-50">
          <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-stretch sm:tw-items-center tw-gap-2.5 sm:tw-gap-3 lg:tw-gap-4">

            {/* Entries per page */}
            <div className="tw-flex tw-items-center tw-gap-1.5 sm:tw-gap-2 tw-flex-shrink-0">
              <select
                value={table.getState().pagination.pageSize}
                onChange={(e) => table.setPageSize(Number(e.target.value))}
                className="tw-border tw-border-blue-gray-200 tw-py-1.5 sm:tw-py-2 tw-px-2 sm:tw-px-3 tw-rounded-lg tw-text-xs sm:tw-text-sm tw-w-14 sm:tw-w-16 lg:tw-w-20 tw-bg-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-blue-500 focus:tw-border-transparent tw-cursor-pointer"
              >
                {[5, 10, 15, 20, 25, 50].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
              <Typography
                variant="small"
                className="tw-text-blue-gray-500 tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-whitespace-nowrap"
              >
                {t("entriesPerPage", lang)}
              </Typography>
            </div>

            {/* Spacer */}
            <div className="tw-flex-1 tw-hidden sm:tw-block" />

            {/* Search */}
            <div className="tw-w-full sm:tw-w-48 lg:tw-w-64">
              <Input
                value={filtering}
                onChange={(e) => setFiltering(e.target.value)}
                label={t("search", lang)}
                crossOrigin={undefined}
              />
            </div>
          </div>
        </CardBody>

        {/* Table Content */}
        <CardFooter className="tw-p-0">
          <div className="tw-relative tw-w-full tw-overflow-x-auto tw-overflow-y-hidden tw-scroll-smooth tw--webkit-overflow-scrolling-touch">
            <table className="tw-w-full tw-text-left tw-min-w-[600px]">
              {/* Table Header */}
              {/* <thead className="tw-bg-gray-50/80 tw-sticky tw-top-0 tw-backdrop-blur-sm"> */}
              <thead className="tw-bg-gradient-to-r tw-from-gray-900 tw-to-gray-800 tw-sticky tw-top-0">
                {table.getHeaderGroups().map((hg) => (
                  <tr key={hg.id}>
                    {hg.headers.map((header) => {
                      const canSort = header.column.getCanSort();
                      const align = (header.column.columnDef as any).meta?.headerAlign ?? "left";
                      return (
                        <th
                          key={header.id}
                          onClick={canSort ? header.column.getToggleSortingHandler() : undefined}
                          // className={`tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4 tw-uppercase !tw-text-blue-gray-500 !tw-font-semibold tw-whitespace-nowrap tw-border-b tw-border-blue-gray-100
                          className={`tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4 tw-uppercase !tw-font-semibold tw-whitespace-nowrap tw-border-b tw-border-gray-700
                            ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}
                            ${canSort ? "tw-cursor-pointer hover:tw-bg-gray-700 tw-transition-colors tw-select-none" : ""}`}
                        >
                          {canSort ? (
                            <Typography
                              color="blue-gray"
                              // className={`tw-flex tw-items-center tw-gap-0.5 sm:tw-gap-1 tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-60
                              className={`tw-flex tw-items-center tw-gap-0.5 sm:tw-gap-1 tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white
                                ${align === "center" ? "tw-justify-center" : align === "right" ? "tw-justify-end" : "tw-justify-start"}`}
                            >
                              {flexRender(header.column.columnDef.header, header.getContext())}
                              {/* <ChevronUpDownIcon strokeWidth={2} className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5 lg:tw-h-4 lg:tw-w-4 tw-flex-shrink-0" />
                               */}
                              <ChevronUpDownIcon strokeWidth={2} className="tw-h-3 tw-w-3 sm:tw-h-3.5 sm:tw-w-3.5 lg:tw-h-4 lg:tw-w-4 tw-flex-shrink-0 tw-text-white/60" />
                            </Typography>
                          ) : (
                            <Typography
                              color="blue-gray"
                              // className={`tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-60
                              className={`tw-text-[9px] sm:tw-text-[10px] lg:tw-text-xs !tw-font-bold tw-leading-none tw-opacity-80 tw-tracking-wider !tw-text-white
                                ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}`}
                            >
                              {flexRender(header.column.columnDef.header, header.getContext())}
                            </Typography>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                ))}
              </thead>

              {/* Table Body */}
              <tbody className="tw-divide-y tw-divide-blue-gray-50">
                {loading ? (
                      /* โครงร่างสูงเท่าหน้าจริง — กัน layout shift ตอนข้อมูลมาถึง */
                      <TableSkeletonRows rows={table.getState().pagination.pageSize} cols={columns.length} rowHeight="var(--table-row-h)" />
                ) : table.getRowModel().rows.length ? (
                  table.getRowModel().rows.map((row, index) => (
                    <tr
                      key={row.id}
                      onClick={() => handleRowClick(row.original)}
                      // className={`tw-transition-colors hover:tw-bg-blue-50/50 tw-cursor-pointer ${index % 2 === 0 ? 'tw-bg-white' : 'tw-bg-gray-50/30'}`}
                      className={`tw-transition-colors hover:tw-bg-blue-50/40 hover:tw-shadow-[inset_3px_0_0_0_#2196F3] tw-cursor-pointer ${index % 2 === 0 ? 'tw-bg-white' : 'tw-bg-blue-gray-50/30'}`}
                    >
                      {row.getVisibleCells().map((cell) => {
                        const align = (cell.column.columnDef as any).meta?.cellAlign ?? "left";
                        return (
                          <td
                            key={cell.id}
                            className={`tw-align-middle tw-border-0 tw-py-2.5 sm:tw-py-3 lg:tw-py-4 tw-px-2 sm:tw-px-3 lg:tw-px-4
                              ${align === "center" ? "tw-text-center" : align === "right" ? "tw-text-right" : "tw-text-left"}`}
                          >
                            <Typography
                              variant="small"
                              className="!tw-font-normal !tw-text-blue-gray-700 tw-text-[11px] sm:tw-text-xs lg:tw-text-sm"
                            >
                              {flexRender(cell.column.columnDef.cell, cell.getContext())}
                            </Typography>
                          </td>
                        );
                      })}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={columns.length} className="tw-text-center tw-py-10 sm:tw-py-12 lg:tw-py-16">
                      <div className="tw-flex tw-flex-col tw-items-center tw-gap-2 sm:tw-gap-3">
                        <div className="tw-w-10 tw-h-10 sm:tw-w-12 sm:tw-h-12 lg:tw-w-16 lg:tw-h-16 tw-rounded-full tw-bg-blue-gray-50 tw-flex tw-items-center tw-justify-center">
                          <DocumentArrowDownIcon className="tw-w-5 tw-h-5 sm:tw-w-6 sm:tw-h-6 lg:tw-w-8 lg:tw-h-8 tw-text-blue-gray-300" />
                        </div>
                        <span className="tw-text-blue-gray-400 tw-text-xs sm:tw-text-sm tw-font-medium">
                          {!stationId ? t("selectStationFirst", lang) : t("noData", lang)}
                        </span>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {/* complète la page jusqu'à pageSize lignes : le pied de tableau ne bouge plus */}
            <TableBodySpacer
              pageSize={table.getState().pagination.pageSize}
              shown={loading ? table.getState().pagination.pageSize : table.getRowModel().rows.length}
            />
          </div>
        </CardFooter>

        {/* Pagination */}
        {/* <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-center tw-justify-between tw-gap-2 sm:tw-gap-3 tw-p-2.5 sm:tw-p-3 lg:tw-p-4 tw-border-t tw-border-blue-gray-50 tw-bg-gray-50/30"> */}
        <div className="tw-flex tw-flex-col sm:tw-flex-row tw-items-center tw-justify-between tw-gap-2 sm:tw-gap-3 tw-p-2.5 sm:tw-p-3 lg:tw-p-4 tw-border-t tw-border-blue-gray-100">
          <Typography variant="small" className="tw-text-[11px] sm:tw-text-xs lg:tw-text-sm tw-text-blue-gray-600 tw-order-2 sm:tw-order-1">
            {t("page", lang)} <strong className="tw-text-blue-gray-800">{table.getState().pagination.pageIndex + 1}</strong> {t("of", lang)} <strong className="tw-text-blue-gray-800">{table.getPageCount() || 1}</strong>
          </Typography>
          <div className="tw-flex tw-gap-1.5 sm:tw-gap-2 tw-order-1 sm:tw-order-2">
            <Button
              size="sm"
              variant="outlined"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
              className="tw-p-1.5 sm:tw-p-2 tw-min-w-0 tw-rounded-lg disabled:tw-opacity-40 disabled:tw-cursor-not-allowed tw-border-blue-gray-200 hover:tw-bg-blue-gray-50 tw-transition-colors"
            >
              <ChevronLeftIcon className="tw-h-3.5 tw-w-3.5 sm:tw-h-4 sm:tw-w-4 lg:tw-h-5 lg:tw-w-5" />
            </Button>
            <Button
              size="sm"
              variant="outlined"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
              className="tw-p-1.5 sm:tw-p-2 tw-min-w-0 tw-rounded-lg disabled:tw-opacity-40 disabled:tw-cursor-not-allowed tw-border-blue-gray-200 hover:tw-bg-blue-gray-50 tw-transition-colors"
            >
              <ChevronRightIcon className="tw-h-3.5 tw-w-3.5 sm:tw-h-4 sm:tw-w-4 lg:tw-h-5 lg:tw-w-5" />
            </Button>
          </div>
        </div>
      </Card>

      {/* เลือกบริษัทก่อนเข้าฟอร์มเปิดใบงานใหม่ */}
      {companyModalOpen && (
        <div
          className="tw-fixed tw-inset-0 tw-z-[100] tw-flex tw-items-center tw-justify-center tw-bg-black/40 tw-p-4"
          onClick={() => setCompanyModalOpen(false)}
        >
          <div className="tw-w-full tw-max-w-md tw-rounded-2xl tw-bg-white tw-p-6 tw-shadow-xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="tw-text-lg tw-font-bold tw-text-blue-gray-800">{t("companyModalTitle", lang)}</h3>
            <p className="tw-mt-1 tw-text-sm tw-text-blue-gray-500">{t("companyModalHint", lang)}</p>

            <div className="tw-mt-4 tw-flex tw-flex-col tw-gap-2">
              {COMPANY_CHOICES.map((c) => (
                <label
                  key={c}
                  className={`tw-flex tw-cursor-pointer tw-items-center tw-gap-3 tw-rounded-xl tw-border tw-px-4 tw-py-3 tw-transition-colors ${companyChoice === c ? "tw-border-gray-900 tw-bg-gray-50" : "tw-border-blue-gray-100 hover:tw-border-blue-gray-300"}`}
                >
                  <input
                    type="radio"
                    name="cm-company"
                    className="tw-h-4 tw-w-4 tw-cursor-pointer tw-accent-gray-900"
                    checked={companyChoice === c}
                    onChange={() => setCompanyChoice(c)}
                  />
                  <span className="tw-text-sm tw-font-semibold tw-text-blue-gray-800">{c}</span>
                </label>
              ))}
            </div>

            <div className="tw-flex tw-items-center tw-justify-end tw-gap-3 tw-pt-5">
              <Button variant="outlined" onClick={() => setCompanyModalOpen(false)} className="tw-border-blue-gray-200 tw-text-blue-gray-700">
                {t("cancel", lang)}
              </Button>
              <Button
                onClick={confirmCompanyAndAdd}
                disabled={!pickedCompany}
                className="tw-bg-gray-900 hover:tw-bg-black tw-text-white disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
              >
                {t("companyConfirm", lang)}
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
