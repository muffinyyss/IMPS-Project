"use client";

import React, { useEffect, useMemo, useState, useRef } from "react";
import { PlayIcon, StopIcon, ArrowPathIcon, CheckIcon } from "@heroicons/react/24/solid";
import { useSearchParams } from "next/navigation";

import Card from "./chargerSetting-card";
import BarProgress from "./BarProgress"; // ← เปลี่ยนจาก CircleProgress
import useLanguage, { type Lang } from "@/utils/useLanguage";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "http://localhost:8000";

const T = {
    loading: { th: "กำลังโหลด...", en: "Loading..." },
    saveFailed: { th: "บันทึกการตั้งค่าไม่สำเร็จ", en: "Failed to save settings" },
    badInitData: { th: "ผิดรูปแบบข้อมูล init", en: "Invalid init data format" },
    sseDisconnected: {
        th: "SSE หลุดการเชื่อมต่อ (กำลังพยายามเชื่อมใหม่อัตโนมัติ)",
        en: "SSE disconnected (reconnecting automatically)",
    },
    editingCurrent: { th: "กำลังแก้ Current (Power ถูกล็อก)", en: "Editing Current (Power locked)" },
    editingPower: { th: "กำลังแก้ Power (Current ถูกล็อก)", en: "Editing Power (Current locked)" },
    lockedWhilePower: { th: "ล็อกชั่วคราว (กำลังแก้ Power)", en: "Temporarily locked (editing Power)" },
    lockedWhileCurrent: { th: "ล็อกชั่วคราว (กำลังแก้ Current)", en: "Temporarily locked (editing Current)" },
    readyToEdit: { th: "พร้อมแก้ไข", en: "Ready to edit" },
    resetCurrent: { th: "รีเซ็ต Current", en: "Reset Current" },
    resetPower: { th: "รีเซ็ต Power", en: "Reset Power" },
    sending: { th: "กำลังส่ง...", en: "send..." },
    submit: { th: "ยืนยัน", en: "submit" },
    confirmStart: {
        th: "คุณต้องการเริ่มชาร์จหัว1จริงหรือไม่?\n\nกด OK เพื่อยืนยัน หรือ Cancel เพื่อยกเลิก",
        en: "Do you really want to start charging on Head 1?\n\nPress OK to confirm or Cancel to abort.",
    },
    confirmStop: {
        th: "คุณต้องการหยุดชาร์จหัว1จริงหรือไม่?\n\nกด OK เพื่อยืนยัน หรือ Cancel เพื่อยกเลิก",
        en: "Do you really want to stop charging on Head 1?\n\nPress OK to confirm or Cancel to abort.",
    },
    chargerHead: { th: "หัวชาร์จ 1", en: "Charger Head 1" },
    vehicleCharging: { th: "รถกำลังชาร์จ", en: "Vehicle is charging" },
    vehicleIdle: { th: "รถยังไม่ได้ชาร์จ", en: "Vehicle is idle" },
    stopCharging: { th: "หยุดชาร์จ", en: "Stop Charging" },
    tryAgain: { th: "ลองใหม่อีกครั้ง", en: "Try Again" },
    startCharging: { th: "เริ่มชาร์จ", en: "Start Charging" },
    stAvailable: { th: "พร้อมใช้งาน", en: "Avaliable" },
    stPreparing: { th: "กำลังเตรียม", en: "Preparing" },
    stCableCheck: { th: "ตรวจสอบสายชาร์จ", en: "Cable Check" },
    stPreCharge: { th: "เตรียมจ่ายไฟ", en: "Precharge" },
    stCharging: { th: "กำลังชาร์จ..", en: "Charging.." },
    stFinishing: { th: "กำลังสิ้นสุด…", en: "Finishing…" },
    stFaulted: { th: "ขัดข้อง", en: "Faulted" },
} as const;

const t = (k: keyof typeof T, lang: Lang) => T[k][lang];

function LimitRow({
    label, unit, value, onChange, min = 0, max = 200, disabled = false,
}: {
    label: string; unit: string; value: number;
    onChange: (v: number) => void; min?: number; max?: number;
    disabled?: boolean;
}) {
    const span = Math.max(1, max - min);
    const percent = Math.max(0, Math.min(100, ((value - min) * 100) / span));
    const fillColor = "#ca3333ff";
    const trackColor = "#E5EDF2";
    const onBlockAttempt = () => { if (disabled) console.log(`[LimitRow] "${label}" blocked: slider is disabled.`); };

    return (
        <div className="tw-space-y-2">
            <div className="tw-flex tw-items-end tw-justify-between">
                <span className="tw-text-sm tw-text-blue-gray-700">{label}</span>
                <span className={`tw-text-sm tw-font-semibold tw-text-blue-gray-900 ${disabled ? "tw-opacity-60" : ""}`}>{value} {unit}</span>
            </div>
            <input
                type="range" min={min} max={max} step={1} value={value} disabled={disabled}
                onChange={(e) => { if (!disabled) { const v = Number(e.target.value); console.log(`[LimitRow] "${label}" changed →`, v, unit); onChange(v); } }}
                onMouseDown={onBlockAttempt} onTouchStart={onBlockAttempt}
                style={{ background: `linear-gradient(to right, ${fillColor} 0%, ${fillColor} ${percent}%, ${trackColor} ${percent}%, ${trackColor} 100%)`, cursor: disabled ? "not-allowed" : "pointer" }}
                className={["tw-w-full tw-appearance-none tw-h-2 tw-rounded-full", "tw-bg-transparent", disabled ? "tw-opacity-60" : ""].join(" ")}
            />
        </div>
    );
}

type ChargeState = "available" | "preparing" | "cableCheck" | "preCharge" | "charging" | "finishing" | "faulted";
type PLCSetting = { SN: string; dynamic_max_current1: number; dynamic_max_power1: number; cp_status1: "start" | "stop"; };

const STATE_META: Record<ChargeState, { labelKey: keyof typeof T; className: string }> = {
    available: { labelKey: "stAvailable", className: "tw-text-blue-gray-600" },
    preparing: { labelKey: "stPreparing", className: "tw-text-blue-600" },
    cableCheck: { labelKey: "stCableCheck", className: "tw-text-amber-600" },
    preCharge: { labelKey: "stPreCharge", className: "tw-text-amber-600" },
    charging: { labelKey: "stCharging", className: "tw-text-green-600" },
    finishing: { labelKey: "stFinishing", className: "tw-text-amber-600" },
    faulted: { labelKey: "stFaulted", className: "tw-text-red-600" },
};

function StateText({ status, lang }: { status: ChargeState; lang: Lang }) {
    const meta = STATE_META[status];
    return <p className={`tw-text-sm tw-font-semibold tw-text-center ${meta.className}`} aria-live="polite">{t(meta.labelKey, lang)}</p>;
}

function PrimaryCTA({ status, busy, onStart, onStop, lang }: { status: ChargeState; busy?: boolean; onStart: () => void; onStop: () => void; lang: Lang; }) {
    const isCharging = status === "charging";
    const isPreparing = status === "preparing";
    const isFinishing = status === "finishing";
    const isFaulted = status === "faulted";
    const isAvailable = status === "available";
    const isDisabled = !!busy || isFinishing || isAvailable || !(isCharging || isPreparing || isFaulted);
    const label = isCharging ? t("stopCharging", lang) : isFaulted ? t("tryAgain", lang) : t("startCharging", lang);
    const Icon = busy ? ArrowPathIcon : isCharging ? StopIcon : PlayIcon;
    const color = isCharging || isFaulted ? "tw-bg-red-500 hover:tw-bg-red-600 focus-visible:tw-ring-red-300" : isFinishing ? "tw-bg-green-500" : "tw-bg-green-500 hover:tw-bg-green-600 focus-visible:tw-ring-green-300";
    const base = "tw-inline-flex tw-items-center tw-justify-center tw-gap-2 tw-rounded-lg tw-h-10 tw-px-4 tw-text-xs tw-font-semibold tw-text-white tw-shadow-sm focus-visible:tw-ring-2 tw-transition tw-w-full";
    return (
        <button type="button" disabled={isDisabled} onClick={isCharging ? onStop : onStart} className={`${base} ${color} ${isDisabled ? "tw-opacity-60 tw-cursor-not-allowed" : ""}`} title={label} aria-label={label}>
            <Icon className={`tw-w-5 tw-h-5 ${busy ? "tw-animate-spin" : ""}`} />
            <span>{label}</span>
        </button>
    );
}

const toNum = (v: any): number | null => { if (v === null || v === undefined) return null; const n = typeof v === "number" ? v : Number(v); return Number.isFinite(n) ? n : null; };

const statusFromCP = (cp: any): ChargeState => {
    const c = String(cp ?? "");
    switch (c) {
        case "1": return "available";
        case "2": return "preparing";
        case "3": return "cableCheck";
        case "4": return "preCharge";
        case "7": return "charging";
        case "6": return "finishing";
        case "5": return "faulted";
        default: return "available";
    }
};

function HeadRow({ title, status, busy, soc, onStart, onStop, lang }: { title: string; status: ChargeState; busy?: boolean; soc?: number | null; onStart: () => void; onStop: () => void; lang: Lang; }) {
    const charging = status === "charging";
    const socVal = soc ?? 0;
    return (
        <div className={`tw-overflow-hidden tw-rounded-xl tw-border tw-bg-white tw-shadow-sm ${charging ? "tw-border-green-200" : "tw-border-blue-gray-100"}`}>
            <div className="tw-p-4 md:tw-p-5 tw-space-y-4">
                <div className="tw-font-semibold tw-text-blue-gray-900">{title}</div>

                {/* BarProgress แทน CircleProgress */}
                <BarProgress value={socVal} label="SoC" />

                <StateText status={status} lang={lang} />
                <div className="tw-pt-1">
                    <PrimaryCTA status={status} busy={!!busy} onStart={onStart} onStop={onStop} lang={lang} />
                    <p className="tw-mt-2 tw-text-center tw-text-xs tw-text-blue-gray-500">{charging ? t("vehicleCharging", lang) : t("vehicleIdle", lang)}</p>
                </div>
            </div>
        </div>
    );
}

type SettingDoc = { _id: string; timestamp?: string; CP_status1?: string | number; SOC1?: string | number | null; dynamic_max_current1?: string | number; dynamic_max_power1?: string | number; present_current1?: string | number; present_power1?: string | number; [key: string]: any; };

export default function Head1() {
    const { lang } = useLanguage();
    const searchParams = useSearchParams();
    const [SN, setSN] = useState<string | null>(null);
    const initSavedRef = useRef(false);
    const [data, setData] = useState<SettingDoc | null>(null);
    const [err, setErr] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [maxCurrentH1, setMaxCurrentH1] = useState(0);
    const [maxPowerH1, setMaxPowerH1] = useState(0);
    const [h1Status, setH1Status] = useState<ChargeState>("available");
    const [busyH1, setBusyH1] = useState(false);
    const [cpCmd1, setCpCmd1] = useState<"start" | "stop" | null>(null);
    const [activeLimiter, setActiveLimiter] = useState<null | "current" | "power">(null);
    const [lastSaved, setLastSaved] = useState({ maxCurrentH1: 0, maxPowerH1: 0 });
    const isDirty = maxCurrentH1 !== lastSaved.maxCurrentH1 || maxPowerH1 !== lastSaved.maxPowerH1;
    const isDirtyCurrent = maxCurrentH1 !== lastSaved.maxCurrentH1;
    const isDirtyPower = maxPowerH1 !== lastSaved.maxPowerH1;
    const isGlobalDisabled = !!busyH1;

    async function applySettings() {
        if (!SN) { console.warn("[Head1] no SN"); return; }
        setSaving(true); setErr(null);
        try {
            const bodyMAX: Record<string, number | string> = { SN: SN };
            if (activeLimiter === "current") { if (isDirtyCurrent) bodyMAX["dynamic_max_current1"] = maxCurrentH1; }
            else if (activeLimiter === "power") { if (isDirtyPower) bodyMAX["dynamic_max_power1"] = maxPowerH1; }
            else { if (isDirtyCurrent) bodyMAX["dynamic_max_current1"] = maxCurrentH1; if (isDirtyPower) bodyMAX["dynamic_max_power1"] = maxPowerH1; }
            const hasChange = ("dynamic_max_current1" in bodyMAX) || ("dynamic_max_power1" in bodyMAX);
            if (hasChange) {
                const resMAX = await fetch(`${API_BASE}/setting/PLC/MAX`, { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(bodyMAX) });
                if (!resMAX.ok) { const t = await resMAX.text().catch(() => ""); throw new Error(`MAX failed: ${resMAX.status} ${t}`); }
                setLastSaved((prev) => ({ maxCurrentH1: ("dynamic_max_current1" in bodyMAX) ? maxCurrentH1 : prev.maxCurrentH1, maxPowerH1: ("dynamic_max_power1" in bodyMAX) ? maxPowerH1 : prev.maxPowerH1 }));
            }
            if (cpCmd1) {
                const bodyCP = { SN: SN, cp_status1: cpCmd1 };
                const resCP = await fetch(`${API_BASE}/setting/PLC/CP`, { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(bodyCP) });
                if (!resCP.ok) { const t = await resCP.text().catch(() => ""); throw new Error(`CP failed: ${resCP.status} ${t}`); }
                setCpCmd1(null);
            }
            setActiveLimiter(null);
        } catch (e: any) { console.error(e); setErr(e?.message || t("saveFailed", lang)); } finally { setSaving(false); }
    }

    const presentCurrent1 = useMemo(() => toNum(data?.present_current1), [data?.present_current1]);
    const maxCurrentSlider = useMemo(() => { const n = presentCurrent1; return n !== null ? Math.max(1, Math.round(n)) : 500; }, [presentCurrent1]);
    useEffect(() => { setMaxCurrentH1((v) => Math.min(v, maxCurrentSlider)); }, [maxCurrentSlider]);

    const presentPowerW1 = useMemo(() => {
        const p = toNum(data?.present_power1); if (p !== null) return p;
        const v = toNum((data as any)?.measured_voltage1); const i = toNum(data?.present_current1);
        if (v !== null && i !== null) return v * i; return null;
    }, [data?.present_power1, (data as any)?.measured_voltage1, data?.present_current1]);

    const maxPowerSlider = useMemo(() => { if (presentPowerW1 === null) return 500; return Math.max(1, Math.round(presentPowerW1 / 1000)); }, [presentPowerW1]);
    useEffect(() => { setMaxPowerH1((v) => Math.min(v, maxPowerSlider)); }, [maxPowerSlider]);

    useEffect(() => {
        const snFromUrl = searchParams.get("SN");
        if (snFromUrl) { setSN(snFromUrl); localStorage.setItem("selected_sn", snFromUrl); return; }
        setSN(localStorage.getItem("selected_sn"));
    }, [searchParams]);

    useEffect(() => {
        if (!SN) return;
        setLoading(true); setErr(null);
        const es = new EventSource(`${API_BASE}/setting?SN=${encodeURIComponent(SN)}`, { withCredentials: true });
        const onInit = (e: MessageEvent) => { try { setData(JSON.parse(e.data)); setLoading(false); } catch { setErr(t("badInitData", lang)); setLoading(false); } };
        es.addEventListener("init", onInit);
        es.onmessage = (e) => { try { setData(JSON.parse(e.data)); } catch { } };
        es.onerror = () => { setErr(t("sseDisconnected", lang)); setLoading(false); };
        return () => { es.removeEventListener("init", onInit); es.close(); };
    }, [SN]);

    useEffect(() => {
        if (!data) return;
        setH1Status(statusFromCP(data.CP_status1));
        const curA = toNum(data.dynamic_max_current1); if (curA !== null) setMaxCurrentH1(Math.round(curA));
        const powW = toNum(data.dynamic_max_power1); if (powW !== null) setMaxPowerH1(Math.round(powW / 1000));
        if (!initSavedRef.current) { setLastSaved({ maxCurrentH1: curA !== null ? Math.round(curA) : 0, maxPowerH1: powW !== null ? Math.round(powW / 1000) : 0 }); initSavedRef.current = true; }
    }, [data]);

    const soc1 = useMemo(() => { const n = toNum(data?.SOC1); if (n === null) return 0; return Math.max(0, Math.min(100, n)); }, [data]);

    async function sendCpCommand(action: "start" | "stop") {
        if (!SN) throw new Error("no SN");
        const res = await fetch(`${API_BASE}/setting/PLC/CP`, { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify({ SN, cp_status1: action }) });
        if (!res.ok) { const t = await res.text().catch(() => ""); throw new Error(`CP ${action} failed: ${res.status} ${t}`); }
        return res.json();
    }

    const startH1 = async () => {
        if (!window.confirm(t("confirmStart", lang))) return;
        try { setBusyH1(true); setCpCmd1("start"); if (h1Status !== "preparing") return; await sendCpCommand("start"); } catch (e) { console.error(e); setH1Status("faulted"); } finally { setBusyH1(false); }
    };

    const stopH1 = async () => {
        if (!window.confirm(t("confirmStop", lang))) return;
        try { setBusyH1(true); setCpCmd1("stop"); await sendCpCommand("stop"); } catch (e) { console.error(e); setH1Status("faulted"); } finally { setBusyH1(false); }
    };

    const hasStation = !!SN; const hasData = !!data;
    const dynMaxCurrent1 = toNum(data?.dynamic_max_current1);
    const disableCurrent = !(hasStation && hasData);
    const disablePower = !(hasStation && hasData && dynMaxCurrent1 !== null);
    const lastUpdated = data?.timestamp ? new Date(data.timestamp).toLocaleString("th-TH") : null;

    return (
        <Card 
        // title={<div className="tw-flex tw-items-center tw-justify-between tw-gap-3"><span>Head1</span>{lastUpdated && <span className="tw-text-xs !tw-text-blue-gray-500">อัปเดตล่าสุด: {lastUpdated}</span>}</div>}
        >
            {(loading || err) && (<div className="tw-px-3 tw-py-2">{loading && <div className="tw-text-sm tw-text-blue-gray-600">{t("loading", lang)}</div>}{err && <div className="tw-text-sm tw-text-red-600">{err}</div>}</div>)}
            <div className="tw-space-y-8">
                <div className="tw-space-y-6">
                    <LimitRow label="Dynamic Max Current H1" unit="A" value={maxCurrentH1} onChange={(v) => { if (isGlobalDisabled) return; if (activeLimiter === null) setActiveLimiter("current"); if (activeLimiter === null || activeLimiter === "current") setMaxCurrentH1(v); }} min={0} max={maxCurrentSlider} disabled={isGlobalDisabled || disableCurrent || (activeLimiter !== null && activeLimiter !== "current")} />
                    <div className="tw-flex tw-justify-between tw-items-center tw-mt-1">
                        <span className="tw-text-xs tw-text-blue-gray-500">{activeLimiter === "current" ? t("editingCurrent", lang) : activeLimiter === "power" ? t("lockedWhilePower", lang) : t("readyToEdit", lang)}</span>
                        <button type="button" onClick={() => { if (!isGlobalDisabled) { setMaxCurrentH1(lastSaved.maxCurrentH1); setActiveLimiter(null); } }} disabled={isGlobalDisabled || activeLimiter !== "current"} className={["tw-inline-flex tw-items-center tw-gap-1 tw-text-xs tw-font-semibold tw-rounded-md tw-px-2 tw-py-1 tw-border tw-border-blue-gray-200 hover:tw-bg-blue-gray-50", activeLimiter !== "current" ? "tw-opacity-60 tw-cursor-not-allowed" : ""].join(" ")}>
                            <ArrowPathIcon className="tw-w-3 tw-h-3" />{t("resetCurrent", lang)}
                        </button>
                    </div>
                    <LimitRow label="Dynamic Max Power H1" unit="kW" value={maxPowerH1} onChange={(v) => { if (isGlobalDisabled) return; if (activeLimiter === null) setActiveLimiter("power"); if (activeLimiter === null || activeLimiter === "power") setMaxPowerH1(v); }} min={0} max={maxPowerSlider} disabled={isGlobalDisabled || disablePower || (activeLimiter !== null && activeLimiter !== "power")} />
                    <div className="tw-flex tw-justify-between tw-items-center tw-mt-1">
                        <span className="tw-text-xs tw-text-blue-gray-500">{activeLimiter === "power" ? t("editingPower", lang) : activeLimiter === "current" ? t("lockedWhileCurrent", lang) : t("readyToEdit", lang)}</span>
                        <button type="button" onClick={() => { if (!isGlobalDisabled) { setMaxPowerH1(lastSaved.maxPowerH1); setActiveLimiter(null); } }} disabled={isGlobalDisabled || activeLimiter !== "power"} className={["tw-inline-flex tw-items-center tw-gap-1 tw-text-xs tw-font-semibold tw-rounded-md tw-px-2 tw-py-1 tw-border tw-border-blue-gray-200 hover:tw-bg-blue-gray-50", activeLimiter !== "power" ? "tw-opacity-60 tw-cursor-not-allowed" : ""].join(" ")}>
                            <ArrowPathIcon className="tw-w-3 tw-h-3" />{t("resetPower", lang)}
                        </button>
                    </div>
                    <div className="tw-flex tw-justify-end">
                        <button type="button" onClick={applySettings} disabled={isGlobalDisabled || !isDirty} className={["tw-inline-flex tw-items-center tw-justify-center tw-rounded-lg tw-h-8 tw-px-4 tw-text-xs tw-font-semibold tw-text-white tw-bg-black hover:tw-bg-black/90 tw-shadow-sm tw-transition", (!isDirty || isGlobalDisabled) ? "tw-opacity-60 tw-cursor-not-allowed" : ""].join(" ")}>
                            {saving ? t("sending", lang) : t("submit", lang)}
                        </button>
                    </div>
                </div>
                <HeadRow title={t("chargerHead", lang)} status={h1Status} busy={busyH1} soc={soc1 ?? 0} onStart={startH1} onStop={stopH1} lang={lang} />
            </div>
        </Card>
    );
}