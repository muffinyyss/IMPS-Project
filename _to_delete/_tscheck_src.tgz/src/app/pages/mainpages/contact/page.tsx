"use client";

import React from "react";
import { PhoneIcon, EnvelopeIcon } from "@heroicons/react/24/outline";
import { apiFetch } from "@/utils/api";
import useLanguage, { type Lang } from "@/utils/useLanguage";

const T = {
    title: { th: "ติดต่อเรา", en: "Contact US" },
    intro: {
        th: "Lorem Ipsum เป็นข้อความจำลองของอุตสาหกรรมการพิมพ์และการเรียงพิมพ์ ซึ่งถูกใช้เป็นข้อความจำลองมาตรฐานของอุตสาหกรรมมาตั้งแต่ปี ค.ศ. 1500",
        en: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
    },
    sendUsAMessage: { th: "ส่งข้อความถึงเรา", en: "Send us a message" },
    successMsg: { th: "ขอบคุณที่ติดต่อเรา! เราจะติดต่อกลับโดยเร็วที่สุด", en: "Thank you for contacting us! We will get back to you as soon as possible." },
    errorMsg: { th: "เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง", en: "Something went wrong. Please try again." },
    firstName: { th: "ชื่อ", en: "First name" },
    lastName: { th: "นามสกุล", en: "Last name" },
    email: { th: "อีเมล", en: "Email" },
    phone: { th: "เบอร์โทรศัพท์", en: "Phone number" },
    message: { th: "ข้อความ", en: "Message" },
    sending: { th: "กำลังส่ง...", en: "Sending..." },
    send: { th: "ส่ง", en: "Send" },
} as const;

const t = (k: keyof typeof T, lang: Lang) => T[k][lang];

export default function ContactPage() {
    const { lang } = useLanguage();
    const [form, setForm] = React.useState({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        message: "",
    });
    const [isSubmitting, setIsSubmitting] = React.useState(false);
    const [submitStatus, setSubmitStatus] = React.useState<"idle" | "success" | "error">("idle");

    const onChange: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement> = (e) => {
        const { name, value } = e.target;
        setForm((p) => ({ ...p, [name]: value }));
    };

    const onSubmit: React.FormEventHandler<HTMLFormElement> = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        setSubmitStatus("idle");

        try {
            const res = await apiFetch("/contact", {   // ← เปลี่ยน endpoint ให้ตรง API จริง
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    first_name: form.firstName,
                    last_name: form.lastName,
                    email: form.email,
                    phone: form.phone,
                    message: form.message,
                }),
            });

            if (!res.ok) throw new Error("submit failed");

            setSubmitStatus("success");
            setForm({ firstName: "", lastName: "", email: "", phone: "", message: "" });
        } catch {
            // ถ้า 401 → apiFetch เด้ง login ให้แล้ว
            // ถ้า network error → apiFetch แสดง toast ให้แล้ว
            setSubmitStatus("error");
        } finally {
            setIsSubmitting(false);
        }
    };

    const inputCls =
        "tw-w-full tw-border tw-border-gray-300 tw-rounded-md tw-px-4 tw-py-2 tw-text-gray-900 " +
        "tw-outline-none focus:tw-ring-2 focus:tw-ring-black focus:tw-border-black";

    return (
        <div className="tw-min-h-screen tw-flex tw-flex-col tw-bg-white">
            <main className="tw-flex-1">
                <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-min-h-[70vh]">
                    {/* LEFT: Info */}
                    <aside className="tw-bg-yellow-500 tw-text-black">
                        <div className="tw-max-w-xl tw-px-6 md:tw-px-10 tw-py-14 md:tw-py-20">
                            <h1 className="tw-text-3xl tw-font-extrabold">{t("title", lang)}</h1>
                            <p className="tw-mt-6 tw-leading-7 tw-text-black/80">
                                {t("intro", lang)}
                            </p>

                            <div className="tw-mt-10 tw-space-y-5">
                                <div className="tw-flex tw-items-center tw-gap-3">
                                    <PhoneIcon className="tw-w-5 tw-h-5" aria-hidden="true" />
                                    <span className="tw-font-medium">+66 123 4567 89</span>
                                </div>
                                <div className="tw-flex tw-items-center tw-gap-3">
                                    <EnvelopeIcon className="tw-w-5 tw-h-5" aria-hidden="true" />
                                    <span className="tw-font-medium">service@email.com</span>
                                </div>
                            </div>
                        </div>
                    </aside>

                    {/* RIGHT: Form */}
                    <section className="tw-bg-white">
                        <div className="tw-px-6 md:tw-px-10 tw-py-14 md:tw-py-20">
                            <h2 className="tw-text-2xl tw-font-semibold">{t("sendUsAMessage", lang)}</h2>

                            {/* Status messages */}
                            {submitStatus === "success" && (
                                <div className="tw-mt-4 tw-rounded-md tw-bg-green-50 tw-border tw-border-green-200 tw-px-4 tw-py-3 tw-text-green-800 tw-text-sm">
                                    {t("successMsg", lang)}
                                </div>
                            )}
                            {submitStatus === "error" && (
                                <div className="tw-mt-4 tw-rounded-md tw-bg-red-50 tw-border tw-border-red-200 tw-px-4 tw-py-3 tw-text-red-800 tw-text-sm">
                                    {t("errorMsg", lang)}
                                </div>
                            )}

                            <form onSubmit={onSubmit} className="tw-mt-8 tw-space-y-6">
                                {/* First & Last name */}
                                <div className="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 tw-gap-6">
                                    <div>
                                        <label className="tw-block tw-text-sm tw-font-medium tw-mb-2">{t("firstName", lang)}</label>
                                        <input
                                            name="firstName"
                                            value={form.firstName}
                                            onChange={onChange}
                                            className={inputCls}
                                            autoComplete="given-name"
                                            required
                                        />
                                    </div>
                                    <div>
                                        <label className="tw-block tw-text-sm tw-font-medium tw-mb-2">{t("lastName", lang)}</label>
                                        <input
                                            name="lastName"
                                            value={form.lastName}
                                            onChange={onChange}
                                            className={inputCls}
                                            autoComplete="family-name"
                                            required
                                        />
                                    </div>
                                </div>

                                {/* Email */}
                                <div>
                                    <label className="tw-block tw-text-sm tw-font-medium tw-mb-2">{t("email", lang)}</label>
                                    <input
                                        type="email"
                                        name="email"
                                        value={form.email}
                                        onChange={onChange}
                                        className={inputCls}
                                        autoComplete="email"
                                        required
                                    />
                                </div>

                                {/* Phone */}
                                <div>
                                    <label className="tw-block tw-text-sm tw-font-medium tw-mb-2">{t("phone", lang)}</label>
                                    <input
                                        type="tel"
                                        name="phone"
                                        value={form.phone}
                                        onChange={onChange}
                                        className={inputCls}
                                        autoComplete="tel"
                                    />
                                </div>

                                {/* Message */}
                                <div>
                                    <label className="tw-block tw-text-sm tw-font-medium tw-mb-2">{t("message", lang)}</label>
                                    <textarea
                                        name="message"
                                        value={form.message}
                                        onChange={onChange}
                                        className={inputCls + " tw-min-h-[220px]"}
                                    />
                                </div>

                                <div className="tw-pt-2">
                                    <button
                                        type="submit"
                                        disabled={isSubmitting}
                                        className="tw-inline-flex tw-items-center tw-justify-center tw-rounded-md tw-bg-black tw-text-white tw-px-6 tw-py-3 tw-font-medium hover:tw-opacity-90 disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
                                    >
                                        {isSubmitting ? t("sending", lang) : t("send", lang)}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </main>
        </div>
    );
}